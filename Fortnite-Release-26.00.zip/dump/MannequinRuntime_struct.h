// Enum MannequinRuntime.ECreativeMannequinAnalyticsInteractType
enum class ECreativeMannequinAnalyticsInteractType : uint8 {
	Equip = 0,
	OpenStore = 1,
	ECreativeMannequinAnalyticsInteractType_MAX = 2
};

