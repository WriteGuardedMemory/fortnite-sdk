// Class CreativeVideoPlayerUI.CreativeVideoPlayerFullScreenWidget
// Size: 0x460 (Inherited: 0x3e8)
struct UCreativeVideoPlayerFullScreenWidget : UCommonActivatableWidget {
	char pad_3E8[0x18]; // 0x3e8(0x18)
	struct USoundSourceBus* SourceBus; // 0x400(0x08)
	struct USoundClass* SoundClass; // 0x408(0x08)
	struct FDataTableRowHandle HoldToSkipAction; // 0x410(0x10)
	struct UCommonButtonLegacy* Button_Skip; // 0x420(0x08)
	struct UImage* Image_VideoTexture; // 0x428(0x08)
	float SkipButtonTimeout; // 0x430(0x04)
	char pad_434[0x14]; // 0x434(0x14)
	struct UAudioComponent* SoundComponent; // 0x448(0x08)
	char pad_450[0x10]; // 0x450(0x10)

	void SetExternalComponents(struct UMediaTexture* VideoTextureExt, struct USoundSourceBus* ExtSourceBus); // Function CreativeVideoPlayerUI.CreativeVideoPlayerFullScreenWidget.SetExternalComponents // (Final|Native|Public|BlueprintCallable) // @ game+0xaa61760
	void OnSkipButtonActionProgress(float HeldPercent); // Function CreativeVideoPlayerUI.CreativeVideoPlayerFullScreenWidget.OnSkipButtonActionProgress // (Final|Native|Private) // @ game+0xaa61670
	void OnSkipButtonActionComplete(); // Function CreativeVideoPlayerUI.CreativeVideoPlayerFullScreenWidget.OnSkipButtonActionComplete // (Final|Native|Private) // @ game+0xaa61650
};

