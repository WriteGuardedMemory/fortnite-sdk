// Class FallTeleportationRuntime.FortFallTeleportSpawnerComponent
// Size: 0x168 (Inherited: 0xa0)
struct UFortFallTeleportSpawnerComponent : UActorComponent {
	struct TSoftClassPtr<UObject> PlayerPawnReceiverClass; // 0xa0(0x20)
	struct UFortFallTeleportComponentBase* ComponentToAddClass; // 0xc0(0x08)
	struct FScalableFloat TeleportEnabled; // 0xc8(0x28)
	struct FScalableFloat RemoveComponentRequestTimeOffset; // 0xf0(0x28)
	char pad_118[0x50]; // 0x118(0x50)

	void HandleWarmupCountdownEndTimeUpdated(float NewEndTime); // Function FallTeleportationRuntime.FortFallTeleportSpawnerComponent.HandleWarmupCountdownEndTimeUpdated // (Final|Native|Protected) // @ game+0xabd5b40
	void HandleGamePhaseChanged(struct FFortGamePhaseUpdatedEvent& Event); // Function FallTeleportationRuntime.FortFallTeleportSpawnerComponent.HandleGamePhaseChanged // (Final|Native|Protected|HasOutParms) // @ game+0xabd5d70
};

// Class FallTeleportationRuntime.FortFallTeleportCheatManager
// Size: 0x28 (Inherited: 0x28)
struct UFortFallTeleportCheatManager : UChildCheatManager {

	void EnableFallTeleportationIndefinitely(); // Function FallTeleportationRuntime.FortFallTeleportCheatManager.EnableFallTeleportationIndefinitely // (Final|Exec|Native|Private) // @ game+0x3982d70
};

// Class FallTeleportationRuntime.FortFallTeleportComponentBase
// Size: 0x1f0 (Inherited: 0xa0)
struct UFortFallTeleportComponentBase : UActorComponent {
	struct FScalableFloat TeleportEnabled; // 0xa0(0x28)
	struct FScalableFloat ContinuousTeleportUpdateEnabled; // 0xc8(0x28)
	struct FScalableFloat ForceTeleportZHeight; // 0xf0(0x28)
	struct FScalableFloat SphereTraceRadius; // 0x118(0x28)
	float WalkingLocationUpdateRate; // 0x140(0x04)
	float ZHeightThresholdCheckRate; // 0x144(0x04)
	float TeleportZModifier; // 0x148(0x04)
	float DistanceFromPawnToTraceLocation; // 0x14c(0x04)
	struct TArray<struct AActor*> TeleportOnBlocklist; // 0x150(0x10)
	struct FName NoTeleportActorTag; // 0x160(0x04)
	char pad_164[0x4]; // 0x164(0x04)
	struct FVector SafeManualLocation; // 0x168(0x18)
	struct UGameplayEffect* TeleportGEClass; // 0x180(0x08)
	struct FVector TeleportLocation; // 0x188(0x18)
	struct FVector FallbackLocation; // 0x1a0(0x18)
	bool bValidFallbackLocation; // 0x1b8(0x01)
	bool bTeleporting; // 0x1b9(0x01)
	char pad_1BA[0x2]; // 0x1ba(0x02)
	int32_t TeleportLimitBeforeFail; // 0x1bc(0x04)
	int32_t TeleportCount; // 0x1c0(0x04)
	char pad_1C4[0x4]; // 0x1c4(0x04)
	struct AFortPlayerPawnAthena* OwningPawn; // 0x1c8(0x08)
	char pad_1D0[0x20]; // 0x1d0(0x20)

	void UpdateLastGroundLocation(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function FallTeleportationRuntime.FortFallTeleportComponentBase.UpdateLastGroundLocation // (Final|Native|Protected) // @ game+0xabd64e0
	bool IsValidActorToTeleportOn(struct AActor* ActorToTeleportOn); // Function FallTeleportationRuntime.FortFallTeleportComponentBase.IsValidActorToTeleportOn // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabd6330
	bool IsTeleportLocationValid(struct FVector& LocationToTest); // Function FallTeleportationRuntime.FortFallTeleportComponentBase.IsTeleportLocationValid // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xabd6230
};

