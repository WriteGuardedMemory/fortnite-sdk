// Class DataflowEngine.DataflowBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDataflowBlueprintLibrary : UBlueprintFunctionLibrary {

	void EvaluateTerminalNodeByName(struct UDataflow* Dataflow, struct FName TerminalNodeName, struct UObject* ResultAsset); // Function DataflowEngine.DataflowBlueprintLibrary.EvaluateTerminalNodeByName // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3605fd0
};

// Class DataflowEngine.DataflowEdNode
// Size: 0xc0 (Inherited: 0x98)
struct UDataflowEdNode : UEdGraphNode {
	char pad_98[0x20]; // 0x98(0x20)
	bool bRenderInAssetEditor; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
};

// Class DataflowEngine.Dataflow
// Size: 0xa8 (Inherited: 0x60)
struct UDataflow : UEdGraph {
	char pad_60[0x28]; // 0x60(0x28)
	bool bActive; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct TArray<struct UObject*> Targets; // 0x90(0x10)
	struct UMaterial* Material; // 0xa0(0x08)
};

