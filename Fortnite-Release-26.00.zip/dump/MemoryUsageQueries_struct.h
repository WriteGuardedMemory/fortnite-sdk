// ScriptStruct MemoryUsageQueries.CollectionInfo
// Size: 0x38 (Inherited: 0x00)
struct FCollectionInfo {
	struct FString Name; // 0x00(0x10)
	struct TArray<struct FString> Includes; // 0x10(0x10)
	struct TArray<struct FString> Excludes; // 0x20(0x10)
	float BudgetMB; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

