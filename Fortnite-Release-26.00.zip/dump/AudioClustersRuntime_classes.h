// Class AudioClustersRuntime.AudioClusterConfig
// Size: 0x30 (Inherited: 0x28)
struct UAudioClusterConfig : UObject {
	struct UAudioClusterBehavior* Behavior; // 0x28(0x08)
};

// Class AudioClustersRuntime.AudioClusterConfigMap
// Size: 0x78 (Inherited: 0x28)
struct UAudioClusterConfigMap : UObject {
	struct TMap<struct FGameplayTag, struct UAudioClusterConfig*> TagConfigMap; // 0x28(0x50)
};

// Class AudioClustersRuntime.AudioClusterBehavior
// Size: 0x30 (Inherited: 0x28)
struct UAudioClusterBehavior : UObject {
	char pad_28[0x8]; // 0x28(0x08)

	void OnStop(); // Function AudioClustersRuntime.AudioClusterBehavior.OnStop // (Native|Event|Protected|BlueprintEvent) // @ game+0x3b35ce0
	void OnStart(); // Function AudioClustersRuntime.AudioClusterBehavior.OnStart // (Native|Event|Protected|BlueprintEvent) // @ game+0x3b35d00
	void OnSizeUpdated(int32_t Size); // Function AudioClustersRuntime.AudioClusterBehavior.OnSizeUpdated // (Native|Event|Protected|BlueprintEvent) // @ game+0xabdf490
	void OnPositionUpdated(struct FVector& Position); // Function AudioClustersRuntime.AudioClusterBehavior.OnPositionUpdated // (Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0xabdf580
	void OnActorRemoved(struct AActor* Actor); // Function AudioClustersRuntime.AudioClusterBehavior.OnActorRemoved // (Native|Event|Protected|BlueprintEvent) // @ game+0x52a5560
	void OnActorAdded(struct AActor* Actor); // Function AudioClustersRuntime.AudioClusterBehavior.OnActorAdded // (Native|Event|Protected|BlueprintEvent) // @ game+0xabdf670
};

// Class AudioClustersRuntime.AudioClustersSubsystem
// Size: 0x38 (Inherited: 0x30)
struct UAudioClustersSubsystem : UWorldSubsystem {
	char pad_30[0x8]; // 0x30(0x08)

	void UpdateClusters(float DeltaTimeSeconds); // Function AudioClustersRuntime.AudioClustersSubsystem.UpdateClusters // (Final|Native|Public|BlueprintCallable) // @ game+0xabe11e0
	bool Unregister(struct FAudioClusterActorInfo& ActorInfo); // Function AudioClustersRuntime.AudioClustersSubsystem.Unregister // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xabe12d0
	bool SetParam(struct FGameplayTag& tag, double Value); // Function AudioClustersRuntime.AudioClustersSubsystem.SetParam // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xabe1710
	void SetListenerPosition(struct FVector& InListenerPosition); // Function AudioClustersRuntime.AudioClustersSubsystem.SetListenerPosition // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xabe1630
	bool RemoveConfigMap(struct UAudioClusterConfigMap* Map); // Function AudioClustersRuntime.AudioClustersSubsystem.RemoveConfigMap // (Final|Native|Public|BlueprintCallable) // @ game+0xabe0bd0
	bool RegisterOneShot(struct FAudioClusterOneShotInfo& OneShotInfo); // Function AudioClustersRuntime.AudioClustersSubsystem.RegisterOneShot // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xabe13d0
	bool Register(struct FAudioClusterActorInfo& ActorInfo); // Function AudioClustersRuntime.AudioClustersSubsystem.Register // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xabe1530
	bool AddConfigMap(struct UAudioClusterConfigMap* Map); // Function AudioClustersRuntime.AudioClustersSubsystem.AddConfigMap // (Final|Native|Public|BlueprintCallable) // @ game+0xabe0eb0
};

