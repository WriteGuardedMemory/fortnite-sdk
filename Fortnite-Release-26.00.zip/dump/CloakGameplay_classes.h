// Class CloakGameplay.FortGameCueNotifyLoop_Cloak
// Size: 0xa08 (Inherited: 0x990)
struct AFortGameCueNotifyLoop_Cloak : AFortGameplayCueNotify_Loop {
	struct AFortPlayerPawn* TargetPlayer; // 0x990(0x08)
	float VisibilityLevel; // 0x998(0x04)
	float StationaryVisMult; // 0x99c(0x04)
	float MaxSpeedVisMult; // 0x9a0(0x04)
	float SpeedForMaxVis; // 0x9a4(0x04)
	float VisibilityMinFriendly; // 0x9a8(0x04)
	float VisibilityMinNonfriendly; // 0x9ac(0x04)
	float VisibilityLevelChangeRate; // 0x9b0(0x04)
	char pad_9B4[0x4]; // 0x9b4(0x04)
	struct TMap<struct FName, struct FFortGameCueCloakModifier> CloakModifiersByNameMap; // 0x9b8(0x50)

	float TickVisibilityLevel(float DeltaSeconds); // Function CloakGameplay.FortGameCueNotifyLoop_Cloak.TickVisibilityLevel // (Final|Native|Protected|BlueprintCallable) // @ game+0xa9e7b50
	bool SetModifierEnabled(struct FName& ModifierName, bool bNewEnabled); // Function CloakGameplay.FortGameCueNotifyLoop_Cloak.SetModifierEnabled // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0xa9e7670
	bool SetModifierCanBeEnabled(struct FName& ModifierName, bool bNewCanBeEnabled); // Function CloakGameplay.FortGameCueNotifyLoop_Cloak.SetModifierCanBeEnabled // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0xa9e78e0
	bool GetCurrentModifierValues(float& OutVisibilityMultiplier, float& OutVisibilityAddition, struct FName& ModifierName); // Function CloakGameplay.FortGameCueNotifyLoop_Cloak.GetCurrentModifierValues // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9e7380
};

