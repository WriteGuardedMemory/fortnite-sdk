// Enum CRD_AudioPlayerRuntime.ECreativeAudioPlayerTargetListener
enum class ECreativeAudioPlayerTargetListener : uint8 {
	None = 0,
	Instigator = 1,
	RegisteredPlayers = 2,
	NonRegisteredPlayers = 4,
	Everyone = 6,
	ECreativeAudioPlayerTargetListener_MAX = 7
};

// Enum CRD_AudioPlayerRuntime.ECreativeAudioPlayerTargetLocation
enum class ECreativeAudioPlayerTargetLocation : uint8 {
	None = 0,
	Device = 1,
	LocalPlayer = 2,
	RegisteredPlayers = 4,
	InstigatingPlayer = 8,
	All = 15,
	ECreativeAudioPlayerTargetLocation_MAX = 16
};

// Enum CRD_AudioPlayerRuntime.EAutoplayOptions
enum class EAutoplayOptions : uint8 {
	None = 0,
	Create = 1,
	WaitingForPlayer = 2,
	Countdown = 4,
	Gameplay = 8,
	RoundEnd = 16,
	GameEnd = 32,
	EAutoplayOptions_MAX = 33
};

// ScriptStruct CRD_AudioPlayerRuntime.CreativeAudioPlayerData
// Size: 0x40 (Inherited: 0x00)
struct FCreativeAudioPlayerData {
	struct FUniqueNetIdRepl NetId; // 0x00(0x30)
	struct APawn* Pawn; // 0x30(0x08)
	float ServerAudioStartTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

