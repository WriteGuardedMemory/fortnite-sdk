// Class CRD_ModalDialogUI.CreativeModalDialogAllowedConversionFunction
// Size: 0x28 (Inherited: 0x28)
struct UCreativeModalDialogAllowedConversionFunction : UBlueprintFunctionLibrary {

	enum class ECreativeModalDialogViewmodelResponse GetResponseNone(struct FWidgetEventField Field); // Function CRD_ModalDialogUI.CreativeModalDialogAllowedConversionFunction.GetResponseNone // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad0470
	enum class ECreativeModalDialogViewmodelResponse GetResponseButton6(struct FWidgetEventField Field); // Function CRD_ModalDialogUI.CreativeModalDialogAllowedConversionFunction.GetResponseButton6 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad0540
	enum class ECreativeModalDialogViewmodelResponse GetResponseButton5(struct FWidgetEventField Field); // Function CRD_ModalDialogUI.CreativeModalDialogAllowedConversionFunction.GetResponseButton5 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad0610
	enum class ECreativeModalDialogViewmodelResponse GetResponseButton4(struct FWidgetEventField Field); // Function CRD_ModalDialogUI.CreativeModalDialogAllowedConversionFunction.GetResponseButton4 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad06e0
	enum class ECreativeModalDialogViewmodelResponse GetResponseButton3(struct FWidgetEventField Field); // Function CRD_ModalDialogUI.CreativeModalDialogAllowedConversionFunction.GetResponseButton3 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad07b0
	enum class ECreativeModalDialogViewmodelResponse GetResponseButton2(struct FWidgetEventField Field); // Function CRD_ModalDialogUI.CreativeModalDialogAllowedConversionFunction.GetResponseButton2 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad0880
	enum class ECreativeModalDialogViewmodelResponse GetResponseButton1(struct FWidgetEventField Field); // Function CRD_ModalDialogUI.CreativeModalDialogAllowedConversionFunction.GetResponseButton1 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad0950
};

// Class CRD_ModalDialogUI.CreativeModalDialogConversionFunction
// Size: 0x28 (Inherited: 0x28)
struct UCreativeModalDialogConversionFunction : UCreativeModalDialogAllowedConversionFunction {

	enum class ECreativeModalDialogViewmodelResponse TranslateResponse(struct FWidgetEventField Field, enum class ECreativeModalDialogViewmodelResponse Response); // Function CRD_ModalDialogUI.CreativeModalDialogConversionFunction.TranslateResponse // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad1a40
	int32_t GetRowIndexForButtonFromContentAlignment(enum class ECreativeModalDialogAlignmentOption AlignmentOption, int32_t ButtonIndex, int32_t WideMaxColumns, int32_t TallMaxColumns, int32_t DefaultMaxColumns); // Function CRD_ModalDialogUI.CreativeModalDialogConversionFunction.GetRowIndexForButtonFromContentAlignment // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad16b0
	struct FMargin GetMarginFromContentAlignment(enum class ECreativeModalDialogAlignmentOption AlignmentOption, float TallMarginAmount, float WideMarginAmount, float CenteredFullMarginAmount, float DefaultMarginAmount); // Function CRD_ModalDialogUI.CreativeModalDialogConversionFunction.GetMarginFromContentAlignment // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad0f80
	float GetFloatingValueFromContentAlignment(enum class ECreativeModalDialogAlignmentOption AlignmentOption, float TallValue, float WideValue, float CenteredFullValue, float DefaultValue); // Function CRD_ModalDialogUI.CreativeModalDialogConversionFunction.GetFloatingValueFromContentAlignment // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad0bd0
	int32_t GetColumnIndexForButtonFromContentAlignment(enum class ECreativeModalDialogAlignmentOption AlignmentOption, int32_t ButtonIndex, int32_t WideMaxColumns, int32_t TallMaxColumns, int32_t DefaultMaxColumns); // Function CRD_ModalDialogUI.CreativeModalDialogConversionFunction.GetColumnIndexForButtonFromContentAlignment // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad1320
	enum class ECreativeModalDialogViewmodelResponse AssignCreativeModalDialogViewmodelResponse(struct FMVVMEventField Field, enum class ECreativeModalDialogViewmodelResponse Response); // Function CRD_ModalDialogUI.CreativeModalDialogConversionFunction.AssignCreativeModalDialogViewmodelResponse // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaad1a40
};

// Class CRD_ModalDialogUI.CreativeModalDialogViewmodel
// Size: 0x1f0 (Inherited: 0x68)
struct UCreativeModalDialogViewmodel : UMVVMViewModelBase {
	struct FText Title; // 0x68(0x18)
	struct FText Body; // 0x80(0x18)
	struct UDataTable* TextStyleSet; // 0x98(0x08)
	struct FText Button01_MainText; // 0xa0(0x18)
	struct FText Button02_MainText; // 0xb8(0x18)
	struct FText Button03_MainText; // 0xd0(0x18)
	struct FText Button04_MainText; // 0xe8(0x18)
	struct FText Button05_MainText; // 0x100(0x18)
	struct FText Button06_MainText; // 0x118(0x18)
	struct FText Button01_SubText; // 0x130(0x18)
	struct FText Button02_SubText; // 0x148(0x18)
	struct FText Button03_SubText; // 0x160(0x18)
	struct FText Button04_SubText; // 0x178(0x18)
	struct FText Button05_SubText; // 0x190(0x18)
	struct FText Button06_SubText; // 0x1a8(0x18)
	struct UTexture2D* Art01_Image; // 0x1c0(0x08)
	struct UTexture2D* Art02_Image; // 0x1c8(0x08)
	enum class ECreativeModalDialogAlignmentOption ContentAlignment; // 0x1d0(0x01)
	bool bShowBackground; // 0x1d1(0x01)
	char pad_1D2[0x2]; // 0x1d2(0x02)
	float DialogBackgroundAlpha; // 0x1d4(0x04)
	enum class ECreativeModalDialogTimerOption TimerOption; // 0x1d8(0x01)
	char pad_1D9[0x3]; // 0x1d9(0x03)
	float Timeout; // 0x1dc(0x04)
	float RemainingTimeForTimeout; // 0x1e0(0x04)
	int32_t NumberOfButtons; // 0x1e4(0x04)
	enum class ECreativeModalBackActionBoundButtonOption BackActionBoundButton; // 0x1e8(0x01)
	enum class ECreativeModalDialogViewmodelResponse Response; // 0x1e9(0x01)
	char pad_1EA[0x6]; // 0x1ea(0x06)

	bool ShouldButton6UseFallbackDefaultInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.ShouldButton6UseFallbackDefaultInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad26b0
	bool ShouldButton5UseFallbackDefaultInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.ShouldButton5UseFallbackDefaultInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad26f0
	bool ShouldButton4UseFallbackDefaultInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.ShouldButton4UseFallbackDefaultInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2730
	bool ShouldButton3UseFallbackDefaultInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.ShouldButton3UseFallbackDefaultInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2770
	bool ShouldButton2UseFallbackDefaultInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.ShouldButton2UseFallbackDefaultInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad27b0
	bool ShouldButton1UseFallbackDefaultInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.ShouldButton1UseFallbackDefaultInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad27f0
	bool IsTimerVisible(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.IsTimerVisible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2370
	bool IsButton6Visible(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.IsButton6Visible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2830
	bool IsButton5Visible(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.IsButton5Visible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2860
	bool IsButton4Visible(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.IsButton4Visible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2890
	bool IsButton3Visible(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.IsButton3Visible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad28c0
	bool IsButton2Visible(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.IsButton2Visible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad28f0
	bool IsButton1Visible(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.IsButton1Visible // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2920
	enum class EVerticalAlignment GetVerticalAlignment(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetVerticalAlignment // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2070
	enum class ESlateVisibility GetTimerVisibility(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetTimerVisibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad21c0
	float GetTimeoutProgress(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetTimeoutProgress // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2340
	enum class EHorizontalAlignment GetHorizontalAlignment(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetHorizontalAlignment // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2100
	enum class ESlateVisibility GetButton6Visibility(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton6Visibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2220
	struct FDataTableRowHandle GetButton6TriggeringInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton6TriggeringInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad23b0
	enum class ESlateVisibility GetButton5Visibility(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton5Visibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2250
	struct FDataTableRowHandle GetButton5TriggeringInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton5TriggeringInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2430
	enum class ESlateVisibility GetButton4Visibility(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton4Visibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2280
	struct FDataTableRowHandle GetButton4TriggeringInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton4TriggeringInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad24b0
	enum class ESlateVisibility GetButton3Visibility(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton3Visibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad22b0
	struct FDataTableRowHandle GetButton3TriggeringInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton3TriggeringInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2530
	enum class ESlateVisibility GetButton2Visibility(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton2Visibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad22e0
	struct FDataTableRowHandle GetButton2TriggeringInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton2TriggeringInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad25b0
	enum class ESlateVisibility GetButton1Visibility(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton1Visibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2310
	struct FDataTableRowHandle GetButton1TriggeringInputAction(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetButton1TriggeringInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2630
	enum class ESlateVisibility GetBackgroundVisibility(); // Function CRD_ModalDialogUI.CreativeModalDialogViewmodel.GetBackgroundVisibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaad2190
};

// Class CRD_ModalDialogUI.CreativeModalDialogWidget
// Size: 0x3f8 (Inherited: 0x3e8)
struct UCreativeModalDialogWidget : UCommonActivatableWidget {
	struct FDataTableRowHandle MainMenuInputRowHandle; // 0x3e8(0x10)
};

