// Enum FortniteAIServer.SwitchSeatType
enum class SwitchSeatType : uint8 {
	ToDriver = 0,
	ToPassenger = 1,
	ToGunner = 2,
	ToSpotter = 3,
	SwitchSeatType_MAX = 4
};

// Enum FortniteAIServer.EFortAthenaStateTreeTaskFeatureExecutionMode
enum class EFortAthenaStateTreeTaskFeatureExecutionMode : uint8 {
	DoNotExecute = 0,
	ExecuteOnEnter = 1,
	ExecuteOnExit = 2,
	EFortAthenaStateTreeTaskFeatureExecutionMode_MAX = 3
};

// Enum FortniteAIServer.SeatStatusType
enum class SeatStatusType : uint8 {
	Driver = 0,
	Passenger = 1,
	Gunner = 2,
	Spotter = 3,
	SeatStatusType_MAX = 4
};

// Enum FortniteAIServer.EFortWorldConditionPlayerHasConvertedNPCCondition
enum class EFortWorldConditionPlayerHasConvertedNPCCondition : uint8 {
	HasReachedConvertedNPCLimit = 0,
	HasAnotherConvertedNPC = 1,
	EFortWorldConditionPlayerHasConvertedNPCCondition_MAX = 2
};

// Enum FortniteAIServer.EFortPointsFromNavGraphGoalPathDistanceFilterOperator
enum class EFortPointsFromNavGraphGoalPathDistanceFilterOperator : uint8 {
	AllGoalsInRange = 0,
	AnyGoalInRange = 1,
	EFortPointsFromNavGraphGoalPathDistanceFilterOperator_MAX = 2
};

// Enum FortniteAIServer.EFortTestGoalActorDot
enum class EFortTestGoalActorDot : uint8 {
	Dot3D = 0,
	Dot2D = 1,
	EFortTestGoalActorDot_MAX = 2
};

// Enum FortniteAIServer.EDistanceMode
enum class EDistanceMode : uint8 {
	DistItemToContext = 0,
	DistItemGoalActorToContext = 1,
	DistItemToItemGoalActor = 2,
	EDistanceMode_MAX = 3
};

// Enum FortniteAIServer.ECountAIAssignedToType
enum class ECountAIAssignedToType : uint8 {
	Goal = 0,
	Actor = 1,
	Assignment = 2,
	ECountAIAssignedToType_MAX = 3
};

// Enum FortniteAIServer.EFortAthenaAICanMoveState
enum class EFortAthenaAICanMoveState : uint8 {
	None = 0,
	Failed_AgentOffNavmesh = 1,
	Failed_GoalOffNavmesh = 2,
	Failed_Falling = 3,
	Success = 4,
	Success_Partial = 5,
	EFortAthenaAICanMoveState_MAX = 6
};

// Enum FortniteAIServer.EEvasiveManeuverType
enum class EEvasiveManeuverType : uint8 {
	Crouch = 0,
	Dodge = 1,
	Jump = 2,
	JetpackStrafe = 3,
	None = 4,
	EEvasiveManeuverType_MAX = 5
};

// Enum FortniteAIServer.EFreeFallingMode
enum class EFreeFallingMode : uint8 {
	Idle = 0,
	Random = 1,
	TowardNearestAlly = 2,
	PatrolPath = 3,
	EFreeFallingMode_MAX = 4
};

// Enum FortniteAIServer.EFocusingBehavior
enum class EFocusingBehavior : uint8 {
	FocusCurrentTarget = 0,
	IgnoreThreatAfterTimer = 1,
	IgnoreThreatAlways = 2,
	IgnoreThreatToFlee = 3,
	LookAtInvestigate = 4,
	LookAtAmbush = 5,
	LookAtHeardSound = 6,
	LookAtScanAround = 7,
	LookAtScanAroundOnly = 8,
	Invalid = 9,
	EFocusingBehavior_MAX = 10
};

// Enum FortniteAIServer.EPathTestQueryType
enum class EPathTestQueryType : uint8 {
	NavmeshRaycast2D = 0,
	HierarchicalQuery = 1,
	RegularPathFinding = 2,
	EPathTestQueryType_MAX = 3
};

// Enum FortniteAIServer.EBTSetBlackboardBoolExitActions
enum class EBTSetBlackboardBoolExitActions : uint8 {
	Invert = 0,
	Revert = 1,
	Keep = 2,
	EBTSetBlackboardBoolExitActions_MAX = 3
};

// Enum FortniteAIServer.EGlideBehavior
enum class EGlideBehavior : uint8 {
	GlideFocusOnDestination = 0,
	GlideSurveyArea = 1,
	EGlideBehavior_MAX = 2
};

// Enum FortniteAIServer.EGlideMovementType
enum class EGlideMovementType : uint8 {
	GlideMovementLinear = 0,
	GlideMovementSpiral = 1,
	GlideMovementSerpentine = 2,
	EGlideMovementType_MAX = 3
};

// Enum FortniteAIServer.EActionState
enum class EActionState : uint8 {
	TryingToEquip = 0,
	EquippingItem = 1,
	UsingItem = 2,
	WaitingItemTermination = 3,
	WaitBeforeEquippingNextItem = 4,
	ActionEndedWithNoError = 5,
	ActionEndedWithError = 6,
	EActionState_MAX = 7
};

// Enum FortniteAIServer.EEncampmentRole
enum class EEncampmentRole : uint8 {
	Guard = 0,
	Build = 1,
	Count = 2,
	EEncampmentRole_MAX = 3
};

// Enum FortniteAIServer.EHasMatchingGameplayTagContainerTestType
enum class EHasMatchingGameplayTagContainerTestType : uint8 {
	Any = 0,
	All = 1,
	EHasMatchingGameplayTagContainerTestType_MAX = 2
};

// Enum FortniteAIServer.EFortAthenaArithmeticOperation
enum class EFortAthenaArithmeticOperation : uint8 {
	Add = 0,
	Subtract = 1,
	Multiply = 2,
	Divide = 3,
	EFortAthenaArithmeticOperation_MAX = 4
};

// Enum FortniteAIServer.EFortAthenaPlayContextualAnimExecutionMethod
enum class EFortAthenaPlayContextualAnimExecutionMethod : uint8 {
	StartInteraction = 0,
	JoinInteraction = 1,
	TransitionAllActors = 2,
	TransitionSingleActor = 3,
	EFortAthenaPlayContextualAnimExecutionMethod_MAX = 4
};

// ScriptStruct FortniteAIServer.FortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData
// Size: 0x20 (Inherited: 0x00)
struct FFortAthenaHandleSoftDisableGuardStateTreeTaskInstanceData {
	struct FStateTreeStructRef SoftDisableStateReference; // 0x00(0x10)
	struct TArray<struct AActor*> ActorsToTeleportOnFailure; // 0x10(0x10)
};

// ScriptStruct FortniteAIServer.FortAthenaHandleSoftDisableGuardStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaHandleSoftDisableGuardStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaSoftDisableStateTreeParameter
// Size: 0x10 (Inherited: 0x00)
struct FFortAthenaSoftDisableStateTreeParameter {
	struct TArray<struct AActor*> ActorsToTeleportOnExit; // 0x00(0x10)
};

// ScriptStruct FortniteAIServer.FortAthenaHandleSoftDisableStateTreeTaskInstanceData
// Size: 0x28 (Inherited: 0x00)
struct FFortAthenaHandleSoftDisableStateTreeTaskInstanceData {
	struct TArray<struct AActor*> ActorsToCleanup; // 0x00(0x10)
	bool bHasReceivedSoftDisableEvent; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	struct FGameplayTag ReceivedSoftDisableEvent; // 0x14(0x04)
	struct FFortAthenaSoftDisableStateTreeParameter OutState; // 0x18(0x10)
};

// ScriptStruct FortniteAIServer.FortAthenaHandleSoftDisableStateTreeTask
// Size: 0x48 (Inherited: 0x20)
struct FFortAthenaHandleSoftDisableStateTreeTask : FStateTreeTaskCommonBase {
	struct FGameplayTag StateTreeEventTag; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FVector TeleportOnNavmeshQueryBoxExtents; // 0x28(0x18)
	int32_t MaxTeleportToTryPerActor; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaPickRandomMontageConfig
// Size: 0x10 (Inherited: 0x00)
struct FFortAthenaPickRandomMontageConfig {
	struct UAnimMontage* Montage; // 0x00(0x08)
	int32_t RandomWeight; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaPickRandomMontageStateTreeTaskInstanceData
// Size: 0x18 (Inherited: 0x00)
struct FFortAthenaPickRandomMontageStateTreeTaskInstanceData {
	struct TArray<struct FFortAthenaPickRandomMontageConfig> PossibleMontages; // 0x00(0x10)
	struct UAnimMontage* PickedMontage; // 0x10(0x08)
};

// ScriptStruct FortniteAIServer.FortAthenaPickRandomMontageStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaPickRandomMontageStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaToggleAllowInteractStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FFortAthenaToggleAllowInteractStateTreeTaskInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	struct AActor* TargetActor; // 0x08(0x08)
};

// ScriptStruct FortniteAIServer.FortAthenaToggleAllowInteractStateTreeTaskTreeTask
// Size: 0x28 (Inherited: 0x20)
struct FFortAthenaToggleAllowInteractStateTreeTaskTreeTask : FStateTreeTaskCommonBase {
	enum class EFortAthenaStateTreeTaskFeatureExecutionMode AddExecutionMode; // 0x20(0x04)
	enum class EFortAthenaStateTreeTaskFeatureExecutionMode RemoveExecutionMode; // 0x24(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaTrackEventConsumeStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FFortAthenaTrackEventConsumeStateTreeTaskInstanceData {
	struct FStateTreeStructRef ReferencedEvent; // 0x00(0x10)
};

// ScriptStruct FortniteAIServer.FortAthenaTrackEventConsumeStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaTrackEventConsumeStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaTrackEventStateTreeTaskStateTreeParameter
// Size: 0x08 (Inherited: 0x00)
struct FFortAthenaTrackEventStateTreeTaskStateTreeParameter {
	bool bHasReceivedTrackedEvent; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FGameplayTag ReceivedEventTag; // 0x04(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaTrackEventStateTreeTaskInstanceData
// Size: 0x08 (Inherited: 0x00)
struct FFortAthenaTrackEventStateTreeTaskInstanceData {
	struct FFortAthenaTrackEventStateTreeTaskStateTreeParameter OutParameter; // 0x00(0x08)
};

// ScriptStruct FortniteAIServer.FortAthenaTrackEventStateTreeTask
// Size: 0x70 (Inherited: 0x20)
struct FFortAthenaTrackEventStateTreeTask : FStateTreeTaskCommonBase {
	struct FGameplayTagQuery EventTagQuery; // 0x20(0x48)
	struct FGameplayTag StateTreeEventTag; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaWorldConditionInstanceData
// Size: 0x50 (Inherited: 0x00)
struct FFortAthenaWorldConditionInstanceData {
	struct AActor* ActorA; // 0x00(0x08)
	struct AActor* ActorB; // 0x08(0x08)
	struct AActor* ActorC; // 0x10(0x08)
	bool bOutResult; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FWorldConditionQueryState QueryState; // 0x20(0x30)
};

// ScriptStruct FortniteAIServer.FortAthenaWorldConditionInstanceDataStateTreeTask
// Size: 0x40 (Inherited: 0x20)
struct FFortAthenaWorldConditionInstanceDataStateTreeTask : FStateTreeTaskCommonBase {
	struct FWorldConditionQueryDefinition Conditions; // 0x20(0x18)
	struct FGameplayTag StateTreeEventTag; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct FortniteAIServer.FortBTService_InjectionTagKey
// Size: 0x08 (Inherited: 0x00)
struct FFortBTService_InjectionTagKey {
	struct FGameplayTag InjectionTag; // 0x00(0x04)
	struct FName InjectionKeyName; // 0x04(0x04)
};

// ScriptStruct FortniteAIServer.FortWorldConditionGameplayTagActorQueryState
// Size: 0x08 (Inherited: 0x00)
struct FFortWorldConditionGameplayTagActorQueryState {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct FortniteAIServer.FortWorldConditionGameplayTagActor
// Size: 0x40 (Inherited: 0x10)
struct FFortWorldConditionGameplayTagActor : FWorldConditionCommonBase {
	struct FWorldConditionContextDataRef ActorContextRef; // 0x10(0x08)
	struct FGameplayTagContainer TagContainerToCheck; // 0x18(0x20)
	enum class EHasMatchingGameplayTagContainerTestType TestType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct FortniteAIServer.FortWorldConditionPlayerHasConvertedNPC
// Size: 0x20 (Inherited: 0x10)
struct FFortWorldConditionPlayerHasConvertedNPC : FWorldConditionCommonActorBase {
	struct FWorldConditionContextDataRef ActorRef; // 0x10(0x08)
	enum class EFortWorldConditionPlayerHasConvertedNPCCondition ConditionToCheck; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct FortniteAIServer.FortWorldConditionTimeOfDay
// Size: 0x20 (Inherited: 0x10)
struct FFortWorldConditionTimeOfDay : FWorldConditionCommonBase {
	struct FWorldConditionContextDataRef ActorContextRef; // 0x10(0x08)
	int32_t ValidTimesOfDay; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct FortniteAIServer.GameFeatureFortAIEvaluatorEntry
// Size: 0x48 (Inherited: 0x00)
struct FGameFeatureFortAIEvaluatorEntry {
	struct TSoftObjectPtr<UBehaviorTree> TreeAsset; // 0x00(0x20)
	struct FGameplayTag InjectionTag; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TSoftClassPtr<UObject> AIEvaluatorClass; // 0x28(0x20)
};

// ScriptStruct FortniteAIServer.FortPointOnCurveRange
// Size: 0x08 (Inherited: 0x00)
struct FFortPointOnCurveRange {
	float MinPercentage; // 0x00(0x04)
	float MaxPercentage; // 0x04(0x04)
};

// ScriptStruct FortniteAIServer.FortPointsOnCurve
// Size: 0x30 (Inherited: 0x00)
struct FFortPointsOnCurve {
	struct TSoftObjectPtr<UCurveFloat> Curve; // 0x00(0x20)
	struct TArray<struct FFortPointOnCurveRange> RangesForPointsOnCurve; // 0x20(0x10)
};

// ScriptStruct FortniteAIServer.FortQueryGenerator_PerceivedActors_Settings
// Size: 0x40 (Inherited: 0x00)
struct FFortQueryGenerator_PerceivedActors_Settings {
	bool bIgnoreDBNOPawns; // 0x00(0x01)
	bool bIgnoreSleepingAIs; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FAIDataProviderFloatValue MaxTimeSincePerceived; // 0x08(0x38)
};

// ScriptStruct FortniteAIServer.FortGameplayTagQueryPerDifficulty
// Size: 0x60 (Inherited: 0x00)
struct FFortGameplayTagQueryPerDifficulty {
	struct FDataTableRowHandle DifficultyInfo; // 0x00(0x10)
	struct FGameplayTagQuery TagQueryToMatch; // 0x10(0x48)
	float Difficulty; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// ScriptStruct FortniteAIServer.GoalDistanceData
// Size: 0x98 (Inherited: 0x00)
struct FGoalDistanceData {
	bool bIgnoreScreeningDistance; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FAIDataProviderFloatValue ScreeningTestMaxDistance; // 0x08(0x38)
	struct TSoftObjectPtr<UCurveFloat> TestScoreCurve; // 0x40(0x20)
	struct FAIDataProviderFloatValue CurveDistanceScale; // 0x60(0x38)
};

// ScriptStruct FortniteAIServer.FlankingLocationInfo
// Size: 0x20 (Inherited: 0x00)
struct FFlankingLocationInfo {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct FortniteAIServer.FailedToReachPOI
// Size: 0x08 (Inherited: 0x00)
struct FFailedToReachPOI {
	int32_t BotPOIID; // 0x00(0x04)
	int32_t FailCount; // 0x04(0x04)
};

// ScriptStruct FortniteAIServer.SmartObjectActivityResult
// Size: 0x10 (Inherited: 0x00)
struct FSmartObjectActivityResult {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct FortniteAIServer.GameplayAbilityEvaluatorModule
// Size: 0x28 (Inherited: 0x00)
struct FGameplayAbilityEvaluatorModule {
	struct FGameplayTagContainer GameplayAbilityTag; // 0x00(0x20)
	struct UAbilitySystemComponent* CachedAbilitySystemComponent; // 0x20(0x08)
};

// ScriptStruct FortniteAIServer.GameplayTagActorHasMatchingGameplayTagInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FGameplayTagActorHasMatchingGameplayTagInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	struct FGameplayTag TagToCheck; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct FortniteAIServer.GameplayTagActorHasMatchingGameplayTagCondition
// Size: 0x28 (Inherited: 0x20)
struct FGameplayTagActorHasMatchingGameplayTagCondition : FStateTreeConditionCommonBase {
	bool bInvert; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct FortniteAIServer.GameplayTagActorHasMatchingGameplayTagContainerInstanceData
// Size: 0x28 (Inherited: 0x00)
struct FGameplayTagActorHasMatchingGameplayTagContainerInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	struct FGameplayTagContainer TagContainerToCheck; // 0x08(0x20)
};

// ScriptStruct FortniteAIServer.GameplayTagActorHasMatchingGameplayContainerTagCondition
// Size: 0x28 (Inherited: 0x20)
struct FGameplayTagActorHasMatchingGameplayContainerTagCondition : FStateTreeConditionCommonBase {
	enum class EHasMatchingGameplayTagContainerTestType TestType; // 0x20(0x01)
	bool bInvert; // 0x21(0x01)
	char pad_22[0x6]; // 0x22(0x06)
};

// ScriptStruct FortniteAIServer.FortAthenaAddGameplayTagsStateTreeTaskInstanceData
// Size: 0x28 (Inherited: 0x00)
struct FFortAthenaAddGameplayTagsStateTreeTaskInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	struct FGameplayTagContainer Tags; // 0x08(0x20)
};

// ScriptStruct FortniteAIServer.FortAthenaAddGameplayTagsStateTreeTask
// Size: 0x30 (Inherited: 0x20)
struct FFortAthenaAddGameplayTagsStateTreeTask : FStateTreeTaskCommonBase {
	bool bReplicateChange; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	enum class EFortAthenaStateTreeTaskFeatureExecutionMode AddExecutionMode; // 0x24(0x04)
	enum class EFortAthenaStateTreeTaskFeatureExecutionMode RemoveExecutionMode; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaArithmeticStateTreeTask
// Size: 0x28 (Inherited: 0x20)
struct FFortAthenaArithmeticStateTreeTask : FStateTreeTaskCommonBase {
	enum class EGameplayInteractionTaskTrigger OperationTrigger; // 0x20(0x01)
	enum class EFortAthenaArithmeticOperation Operation; // 0x21(0x01)
	char pad_22[0x6]; // 0x22(0x06)
};

// ScriptStruct FortniteAIServer.FortAthenaIntArithmeticStateTreeTaskInstanceData
// Size: 0x18 (Inherited: 0x00)
struct FFortAthenaIntArithmeticStateTreeTaskInstanceData {
	int32_t FirstOperand; // 0x00(0x04)
	int32_t SecondOperand; // 0x04(0x04)
	struct FStateTreeStructRef ReferencedResult; // 0x08(0x10)
};

// ScriptStruct FortniteAIServer.FortAthenaIntArithmeticStateTreeTask
// Size: 0x28 (Inherited: 0x28)
struct FFortAthenaIntArithmeticStateTreeTask : FFortAthenaArithmeticStateTreeTask {
};

// ScriptStruct FortniteAIServer.FortAthenaFocusAtStateTreeTaskInstanceData
// Size: 0x90 (Inherited: 0x00)
struct FFortAthenaFocusAtStateTreeTaskInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	struct AActor* FocusActor; // 0x08(0x08)
	struct FVector FocusActorOffset; // 0x10(0x18)
	struct FVector FocusWorldPoint; // 0x28(0x18)
	bool bSetBackOnExit; // 0x40(0x01)
	char pad_41[0x4f]; // 0x41(0x4f)
};

// ScriptStruct FortniteAIServer.FortAthenaFocusAtStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaFocusAtStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaIntStateTreeParameter
// Size: 0x04 (Inherited: 0x00)
struct FFortAthenaIntStateTreeParameter {
	int32_t Int; // 0x00(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaMakeIntVariableStateTreeTaskInstanceData
// Size: 0x08 (Inherited: 0x00)
struct FFortAthenaMakeIntVariableStateTreeTaskInstanceData {
	int32_t DefaultIntValue; // 0x00(0x04)
	struct FFortAthenaIntStateTreeParameter OutInt; // 0x04(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaMakeIntVariableStateTreeTask
// Size: 0x28 (Inherited: 0x20)
struct FFortAthenaMakeIntVariableStateTreeTask : FStateTreeTaskCommonBase {
	bool bResetOnReselect; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct FortniteAIServer.FortAthenaPlayContextualAnimStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaPlayContextualAnimStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaPlayInteractionStateTreeTaskActorInfo
// Size: 0x24 (Inherited: 0x00)
struct FFortAthenaPlayInteractionStateTreeTaskActorInfo {
	char pad_0[0x24]; // 0x00(0x24)
};

// ScriptStruct FortniteAIServer.FortAthenaStateTreeCrouchTaskInstanceData
// Size: 0x08 (Inherited: 0x00)
struct FFortAthenaStateTreeCrouchTaskInstanceData {
	struct AActor* Actor; // 0x00(0x08)
};

// ScriptStruct FortniteAIServer.FortAthenaStateTreeCrouchTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaStateTreeCrouchTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaStateTreeInteractTaskInstanceData
// Size: 0x20 (Inherited: 0x00)
struct FFortAthenaStateTreeInteractTaskInstanceData {
	enum class TInteractionType InteractType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct AActor* Actor; // 0x08(0x08)
	struct AActor* InteractTargetActor; // 0x10(0x08)
	float InteractDuration; // 0x18(0x04)
	float Timer; // 0x1c(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaStateTreeInteractTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaStateTreeInteractTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaStateTreeLookAroundTaskInstanceData
// Size: 0x18 (Inherited: 0x00)
struct FFortAthenaStateTreeLookAroundTaskInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	float LookAtDurationMin; // 0x08(0x04)
	float LookAtDurationMax; // 0x0c(0x04)
	float LookAtDuration; // 0x10(0x04)
	float Timer; // 0x14(0x04)
};

// ScriptStruct FortniteAIServer.FortAthenaStateTreeLookAroundTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaStateTreeLookAroundTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaTeleportToActorStateTreeTaskInstanceData
// Size: 0x40 (Inherited: 0x00)
struct FFortAthenaTeleportToActorStateTreeTaskInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	struct AActor* TargetActor; // 0x08(0x08)
	struct FVector TeleportRelativeLocation; // 0x10(0x18)
	struct FRotator TeleportRelativeRotation; // 0x28(0x18)
};

// ScriptStruct FortniteAIServer.FortAthenaTeleportToActorStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FFortAthenaTeleportToActorStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct FortniteAIServer.FortAthenaToggleGameplayEffectStateTreeTaskInstanceData
// Size: 0xc8 (Inherited: 0x00)
struct FFortAthenaToggleGameplayEffectStateTreeTaskInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	struct AActor* TargetActor; // 0x08(0x08)
	struct TArray<struct UGameplayEffect*> GameplayEffectClassesToAdd; // 0x10(0x10)
	bool bAutomaticallyRemoveAddedEffectsOnExit; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct TArray<struct UGameplayEffect*> GameplayEffectClassesToRemove; // 0x28(0x10)
	struct FGameplayTagContainer GameplayEffectsByTagsToRemove; // 0x38(0x20)
	struct FGameplayTagContainer GameplayEffectsBySourceTagsToRemove; // 0x58(0x20)
	struct FGameplayTagContainer GameplayEffectsByAppliedTagsToRemove; // 0x78(0x20)
	struct FGameplayTagContainer GameplayEffectsByGrantedTagsToRemove; // 0x98(0x20)
	char pad_B8[0x10]; // 0xb8(0x10)
};

// ScriptStruct FortniteAIServer.FortAthenaToggleGameplayEffectStateTreeTask
// Size: 0x28 (Inherited: 0x20)
struct FFortAthenaToggleGameplayEffectStateTreeTask : FStateTreeTaskCommonBase {
	enum class EFortAthenaStateTreeTaskFeatureExecutionMode AddExecutionMode; // 0x20(0x04)
	enum class EFortAthenaStateTreeTaskFeatureExecutionMode RemoveExecutionMode; // 0x24(0x04)
};

