// Enum MLDeformerFramework.EMLDeformerVizMode
enum class EMLDeformerVizMode : uint8 {
	TrainingData = 0,
	TestData = 1,
	EMLDeformerVizMode_MAX = 2
};

// Enum MLDeformerFramework.EMLDeformerHeatMapMode
enum class EMLDeformerHeatMapMode : uint8 {
	Activations = 0,
	GroundTruth = 1,
	EMLDeformerHeatMapMode_MAX = 2
};

// Enum MLDeformerFramework.EMLDeformerMaskChannel
enum class EMLDeformerMaskChannel : uint8 {
	Disabled = 0,
	VertexColorRed = 1,
	VertexColorGreen = 2,
	VertexColorBlue = 3,
	VertexColorAlpha = 4,
	EMLDeformerMaskChannel_MAX = 5
};

// ScriptStruct MLDeformerFramework.MLDeformerCurveReference
// Size: 0x04 (Inherited: 0x00)
struct FMLDeformerCurveReference {
	struct FName CurveName; // 0x00(0x04)
};

// ScriptStruct MLDeformerFramework.MLDeformerMorphModelQualityLevel
// Size: 0x04 (Inherited: 0x00)
struct FMLDeformerMorphModelQualityLevel {
	int32_t MaxActiveMorphs; // 0x00(0x04)
};

