// Class FortAudioClustersRuntime.FortAudioClustersSettings
// Size: 0x80 (Inherited: 0x30)
struct UFortAudioClustersSettings : UDeveloperSettings {
	struct TMap<struct FGameplayTag, double> ParameterDefaults; // 0x30(0x50)
};

// Class FortAudioClustersRuntime.FortAudioClustersSubsystem
// Size: 0x40 (Inherited: 0x40)
struct UFortAudioClustersSubsystem : UTickableWorldSubsystem {
};

// Class FortAudioClustersRuntime.GameFeatureAction_AddAudioCluster
// Size: 0xf0 (Inherited: 0x28)
struct UGameFeatureAction_AddAudioCluster : UGameFeatureAction {
	struct TArray<struct FGameFeatureAudioClusterEntry> Clusters; // 0x28(0x10)
	struct TMap<struct FName, struct FGameplayTag> OverrideTable; // 0x38(0x50)
	struct FName DisabledActorTag; // 0x88(0x04)
	char pad_8C[0x64]; // 0x8c(0x64)

	void HandleRegisteredActorDeath(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function FortAudioClustersRuntime.GameFeatureAction_AddAudioCluster.HandleRegisteredActorDeath // (Final|Native|Private|HasOutParms|HasDefaults) // @ game+0xabe3e30
};

// Class FortAudioClustersRuntime.GameFeatureAction_AddAudioClusterConfigMaps
// Size: 0x88 (Inherited: 0x28)
struct UGameFeatureAction_AddAudioClusterConfigMaps : UGameFeatureAction {
	struct TArray<struct TSoftObjectPtr<UAudioClusterConfigMap>> ConfigMaps; // 0x28(0x10)
	char pad_38[0x50]; // 0x38(0x50)
};

