// Class HeistBasesGameplayRuntime.FortGameStateComponent_HeistDisplayCaseItemManager
// Size: 0x168 (Inherited: 0xa0)
struct UFortGameStateComponent_HeistDisplayCaseItemManager : UFortGameStateComponent {
	struct FMulticastInlineDelegate OnDisplayCaseItemManagerReady; // 0xa0(0x10)
	struct TArray<struct UFortWorldItemDefinition*> AllDisplayCaseItems; // 0xb0(0x10)
	char pad_C0[0xa8]; // 0xc0(0xa8)

	bool IsDataReady(); // Function HeistBasesGameplayRuntime.FortGameStateComponent_HeistDisplayCaseItemManager.IsDataReady // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa96b580
	void HandlePlaylistDataReady(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function HeistBasesGameplayRuntime.FortGameStateComponent_HeistDisplayCaseItemManager.HandlePlaylistDataReady // (Final|Native|Private|HasOutParms) // @ game+0xa96b210
	struct UFortWorldItemDefinition* GetDisplayCaseItem(struct FGameplayTag DisplayCaseGroupTag); // Function HeistBasesGameplayRuntime.FortGameStateComponent_HeistDisplayCaseItemManager.GetDisplayCaseItem // (Final|Native|Public|BlueprintCallable) // @ game+0xa96b490
};

// Class HeistBasesGameplayRuntime.FortHeistDisplayCase
// Size: 0xc50 (Inherited: 0xb80)
struct AFortHeistDisplayCase : ABuildingSMActor {
	char pad_B80[0x8]; // 0xb80(0x08)
	bool bReplicateLongInteractionDetails; // 0xb88(0x01)
	char bCanBeMarked : 1; // 0xb89(0x01)
	char bBlockMarking : 1; // 0xb89(0x01)
	char pad_B89_2 : 6; // 0xb89(0x01)
	char pad_B8A[0x6]; // 0xb8a(0x06)
	struct FMarkedActorDisplayInfo MarkerDisplay; // 0xb90(0xa8)
	struct FVector MarkerPositionOffset; // 0xc38(0x18)

	void OnServerNotifyStartDisplayCaseLongUse(struct AFortPlayerPawn* InteractingPawn); // Function HeistBasesGameplayRuntime.FortHeistDisplayCase.OnServerNotifyStartDisplayCaseLongUse // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnServerNotifyEndDisplayCaseLongUse(struct AFortPlayerPawn* InteractingPawn); // Function HeistBasesGameplayRuntime.FortHeistDisplayCase.OnServerNotifyEndDisplayCaseLongUse // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

