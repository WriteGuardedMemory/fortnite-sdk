// Class FortniteGameFramework.FGF_Character
// Size: 0x6c0 (Inherited: 0x660)
struct AFGF_Character : ACharacter {
	char pad_660[0x60]; // 0x660(0x60)
};

// Class FortniteGameFramework.FGF_GameMode
// Size: 0x3d0 (Inherited: 0x378)
struct AFGF_GameMode : AGameMode {
	char pad_378[0x58]; // 0x378(0x58)
};

// Class FortniteGameFramework.FGF_GameState
// Size: 0x360 (Inherited: 0x300)
struct AFGF_GameState : AGameState {
	char pad_300[0x60]; // 0x300(0x60)
};

// Class FortniteGameFramework.FGF_PlayerController
// Size: 0x8a8 (Inherited: 0x850)
struct AFGF_PlayerController : APlayerController {
	char pad_850[0x58]; // 0x850(0x58)
};

// Class FortniteGameFramework.FGF_PlayerState
// Size: 0x3a0 (Inherited: 0x348)
struct AFGF_PlayerState : APlayerState {
	char pad_348[0x58]; // 0x348(0x58)
};

// Class FortniteGameFramework.ObjectBasedStateTreeSchema
// Size: 0x28 (Inherited: 0x28)
struct UObjectBasedStateTreeSchema : UStateTreeSchema {
};

// Class FortniteGameFramework.StateTreeManagerComponent
// Size: 0x1e0 (Inherited: 0xa0)
struct UStateTreeManagerComponent : UActorComponent {
	struct TArray<struct FStateTreeRuntimeData> StateTreeRuntimeDataList; // 0xa0(0x10)
	struct TArray<struct FStateTreeClientSimulationData> SimulatedDataList; // 0xb0(0x10)
	struct FStateChangeDataArray ReplicatedStateChanges; // 0xc0(0x120)
};

// Class FortniteGameFramework.StateTreeTaskObject
// Size: 0x50 (Inherited: 0x48)
struct UStateTreeTaskObject : UStateTreeTaskBlueprintBase {
	bool bReplicates; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

