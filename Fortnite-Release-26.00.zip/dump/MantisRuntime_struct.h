// Enum MantisRuntime.EFortMantisTechniqueActivationInputType
enum class EFortMantisTechniqueActivationInputType : uint8 {
	None = 0,
	Primary = 1,
	Secondary = 2,
	Max_Invalid = 3,
	EFortMantisTechniqueActivationInputType_MAX = 4
};

// Enum MantisRuntime.EFortMantisTechniqueActivationTimingType
enum class EFortMantisTechniqueActivationTimingType : uint8 {
	None = 0,
	Pressed = 1,
	Released = 2,
	EFortMantisTechniqueActivationTimingType_MAX = 3
};

// Enum MantisRuntime.EFortMantisTechniqueAnimationType
enum class EFortMantisTechniqueAnimationType : uint8 {
	SingleMontage = 0,
	DynamicMontage = 1,
	AnimInstance = 2,
	EFortMantisTechniqueAnimationType_MAX = 3
};

// Enum MantisRuntime.EFortMantisTechniqueRootMotionType
enum class EFortMantisTechniqueRootMotionType : uint8 {
	None = 0,
	ExtractFromMontageAndWarp = 1,
	EFortMantisTechniqueRootMotionType_MAX = 2
};

// Enum MantisRuntime.EFortMantisNotifyEvent
enum class EFortMantisNotifyEvent : uint8 {
	Invalid = 0,
	Branch = 1,
	EndTechnique = 2,
	EFortMantisNotifyEvent_MAX = 3
};

// Enum MantisRuntime.EFortMantisNotifyWindow
enum class EFortMantisNotifyWindow : uint8 {
	Invalid = 0,
	Input = 1,
	Execution = 2,
	Damage = 3,
	RootMotionWarp = 4,
	EFortMantisNotifyWindow_MAX = 5
};

// Enum MantisRuntime.EFortMantisNotifyRotationWarpRateRule
enum class EFortMantisNotifyRotationWarpRateRule : uint8 {
	Snap = 0,
	WindowDurationLerp = 1,
	EFortMantisNotifyRotationWarpRateRule_MAX = 2
};

// Enum MantisRuntime.EFortMantisBranchRule
enum class EFortMantisBranchRule : uint8 {
	Off = 0,
	Any = 1,
	Starter = 2,
	EFortMantisBranchRule_MAX = 3
};

// Enum MantisRuntime.EFortMantisBranchPath
enum class EFortMantisBranchPath : uint8 {
	Default = 0,
	 = 1,
	 = 2,
	 = 3,
	 = 4,
	 = 5,
	Blocked = 6,
	EFortMantisBranchPath_MAX = 7
};

// ScriptStruct MantisRuntime.FortMantisTechniqueMetadata
// Size: 0x140 (Inherited: 0x00)
struct FFortMantisTechniqueMetadata {
	struct TMap<struct FGameplayTag, int32_t> IntValues; // 0x00(0x50)
	struct TMap<struct FGameplayTag, float> FloatValues; // 0x50(0x50)
	struct TMap<struct FGameplayTag, struct FVector> VectorValues; // 0xa0(0x50)
	struct TMap<struct FGameplayTag, struct FString> StringValues; // 0xf0(0x50)
};

// ScriptStruct MantisRuntime.FortRootMotionSource_Mantis
// Size: 0x160 (Inherited: 0xe0)
struct FFortRootMotionSource_Mantis : FRootMotionSource {
	float CurrentTechniqueTime; // 0xd8(0x04)
	struct UAnimMontage* TechniqueMontage; // 0xe0(0x08)
	struct FFortMantisRootMotionWarpInfo WarpInfo; // 0xe8(0x28)
	struct FVector LatestRepMovementLocation; // 0x110(0x18)
	char pad_12C[0x34]; // 0x12c(0x34)
};

// ScriptStruct MantisRuntime.FortMantisRootMotionWarpInfo
// Size: 0x28 (Inherited: 0x00)
struct FFortMantisRootMotionWarpInfo {
	struct TWeakObjectPtr<struct AActor> WarpTarget; // 0x00(0x08)
	struct FVector_NetQuantize LastValidWarpTargetLocation; // 0x08(0x18)
	char pad_20_0 : 1; // 0x20(0x01)
	char bAllowTranslationWarp : 1; // 0x20(0x01)
	char bAllowRotationWarp : 1; // 0x20(0x01)
	char bSnapshotTargetLocation : 1; // 0x20(0x01)
	char pad_20_4 : 4; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct MantisRuntime.FortMantisTargetData
// Size: 0x180 (Inherited: 0x08)
struct FFortMantisTargetData : FGameplayAbilityTargetData {
	struct FFortMantisRootMotionWarpInfo TechniqueWarpInfo; // 0x08(0x28)
	int32_t TechniqueDataIndex; // 0x30(0x04)
	bool bIsLockedOn; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	struct FName DynamicMontageName; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FFortMantisTechniqueMetadata TechniqueMetadata; // 0x40(0x140)
};

// ScriptStruct MantisRuntime.FortMantisTechniqueCharacterSettings
// Size: 0x18 (Inherited: 0x00)
struct FFortMantisTechniqueCharacterSettings {
	bool bDetachCharacterRotationFromCamera; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float ReattachCharacterRotationBlendTime; // 0x04(0x04)
	float ReattachCharacterRotationBlendExponent; // 0x08(0x04)
	float WindupCharacterRotationRate; // 0x0c(0x04)
	float ExecutionCharacterRotationRate; // 0x10(0x04)
	float RecoveryCharacterRotationRate; // 0x14(0x04)
};

// ScriptStruct MantisRuntime.FortMantisTechniqueData
// Size: 0x150 (Inherited: 0x00)
struct FFortMantisTechniqueData {
	struct FName Name; // 0x00(0x04)
	bool bStartsSequence; // 0x04(0x01)
	bool bEndsSequence; // 0x05(0x01)
	char pad_6[0x2]; // 0x06(0x02)
	int32_t MaxConsecutiveBranchesToSelf; // 0x08(0x04)
	enum class EFortMantisTechniqueAnimationType AnimationType; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct UAnimMontage* Montage; // 0x10(0x08)
	struct TMap<struct FName, struct UAnimMontage*> DynamicMontages; // 0x18(0x50)
	struct FName DefaultDynamicMontageName; // 0x68(0x04)
	enum class EFortMantisTechniqueRootMotionType RootMotionType; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	float InputWindowDelay; // 0x70(0x04)
	enum class EFortMantisTechniqueActivationInputType ActivationInputType; // 0x74(0x01)
	enum class EFortMantisTechniqueActivationTimingType ActivationTimingType; // 0x75(0x01)
	char pad_76[0x2]; // 0x76(0x02)
	float MinInputHoldDuration; // 0x78(0x04)
	float MaxInputHoldDuration; // 0x7c(0x04)
	struct FGameplayTagContainer ActivationGameplayCues; // 0x80(0x20)
	struct FGameplayTagQuery ActivationTagQuery; // 0xa0(0x48)
	struct FGameplayTagQuery OngoingTagQuery; // 0xe8(0x48)
	struct FGameplayTag ActivationApplicationTag; // 0x130(0x04)
	struct FGameplayTag DamageApplicationTag; // 0x134(0x04)
	struct FFortMantisTechniqueCharacterSettings CharacterSettings; // 0x138(0x18)
};

// ScriptStruct MantisRuntime.FortMantisTechniqueBranch
// Size: 0x0c (Inherited: 0x00)
struct FFortMantisTechniqueBranch {
	struct FName FromTechnique; // 0x00(0x04)
	struct FName ToTechnique; // 0x04(0x04)
	enum class EFortMantisBranchPath BranchPath; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct MantisRuntime.FortMantisMontageData
// Size: 0x18 (Inherited: 0x00)
struct FFortMantisMontageData {
	struct UAnimMontage* Montage; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
};

// ScriptStruct MantisRuntime.FortMantisReplicatedAnimInstanceInfo
// Size: 0x10 (Inherited: 0x00)
struct FFortMantisReplicatedAnimInstanceInfo {
	bool bIsTechniqueActive; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName ActiveTechniqueName; // 0x04(0x04)
	int32_t ActiveTechniqueIndex; // 0x08(0x04)
	int32_t ActiveTechniqueConsecutiveBranchesToSelf; // 0x0c(0x04)
};

// ScriptStruct MantisRuntime.FortMantisRootMotionWarpInfoNetSerializerConfig
// Size: 0x10 (Inherited: 0x10)
struct FFortMantisRootMotionWarpInfoNetSerializerConfig : FNetSerializerConfig {
};

