// Enum LagerRuntime.ELivingWorldPointProviderSpawnLimiterBehavior
enum class ELivingWorldPointProviderSpawnLimiterBehavior : uint8 {
	Lifetime = 0,
	Concurrent = 1,
	ELivingWorldPointProviderSpawnLimiterBehavior_MAX = 2
};

// Enum LagerRuntime.ELivingWorldCalendarEventConditionBehavior
enum class ELivingWorldCalendarEventConditionBehavior : uint8 {
	IsActive = 0,
	Ratio = 1,
	ELivingWorldCalendarEventConditionBehavior_MAX = 2
};

// Enum LagerRuntime.ELivingWorldCalendarEventConditionRatioBehavior
enum class ELivingWorldCalendarEventConditionRatioBehavior : uint8 {
	Less = 0,
	LessOrEqual = 1,
	Greater = 2,
	GreaterOrEqual = 3,
	InBetween = 4,
	ELivingWorldCalendarEventConditionRatioBehavior_MAX = 5
};

// Enum LagerRuntime.EFortAthenaLivingWorldEventRuntimeDeactivationReason
enum class EFortAthenaLivingWorldEventRuntimeDeactivationReason : uint8 {
	None = 0,
	NoValidEventData = 1,
	RandomDeactivation = 2,
	CalendarEvent = 3,
	MatchedPrefabAndNormalActor = 4,
	ActorDescDoesntMatchAnySpawnerData = 5,
	EFortAthenaLivingWorldEventRuntimeDeactivationReason_MAX = 6
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldPrefabActorSpawnerData
// Size: 0x110 (Inherited: 0x00)
struct FFortAthenaLivingWorldPrefabActorSpawnerData {
	struct FGuid ActorSpawnerGuid; // 0x00(0x10)
	struct FFortAthenaLivingWorldActorSpawnDescription ActorDescription; // 0x10(0x100)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldActorSpawnDescription
// Size: 0x100 (Inherited: 0x00)
struct FFortAthenaLivingWorldActorSpawnDescription {
	struct TSoftClassPtr<UObject> ActorClass; // 0x00(0x20)
	struct TSoftClassPtr<UObject> SpawnerData; // 0x20(0x20)
	struct FGameplayTagQuery SpawnerDataTagQuery; // 0x40(0x48)
	struct FScalableFloat ActorDensityValue; // 0x88(0x28)
	struct FScalableFloat DensityComputationRangeOverride; // 0xb0(0x28)
	struct TArray<struct FFortAthenaLivingWorldEventTagDensityRegistration> TagDensityRegistrations; // 0xd8(0x10)
	struct TArray<struct FFortAthenaLivingWorldTagTimer> PostDestructionTagDensityPersistenceDuration; // 0xe8(0x10)
	bool bPreloadOnClient; // 0xf8(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldTagTimer
// Size: 0x30 (Inherited: 0x00)
struct FFortAthenaLivingWorldTagTimer {
	char pad_0[0x8]; // 0x00(0x08)
	struct FScalableFloat Duration; // 0x08(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldEventTagDensityRegistration
// Size: 0x58 (Inherited: 0x00)
struct FFortAthenaLivingWorldEventTagDensityRegistration {
	struct FGameplayTag tag; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FScalableFloat Range; // 0x08(0x28)
	struct FScalableFloat DensityValue; // 0x30(0x28)
};

// ScriptStruct LagerRuntime.PointProviderTagDebugColor
// Size: 0x28 (Inherited: 0x00)
struct FPointProviderTagDebugColor {
	struct FGameplayTagContainer Tags; // 0x00(0x20)
	struct FColor Color; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldPointProviderSpawnLimiter
// Size: 0x68 (Inherited: 0x00)
struct FFortAthenaLivingWorldPointProviderSpawnLimiter {
	char pad_0[0x8]; // 0x00(0x08)
	enum class ELivingWorldPointProviderSpawnLimiterBehavior Behavior; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FScalableFloat MaxNumberOfSpawn; // 0x10(0x28)
	struct FScalableFloat MaxNumberOfEventInstance; // 0x38(0x28)
	bool bResetLimitWhenEnabling; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldConditionContainer
// Size: 0x18 (Inherited: 0x00)
struct FFortAthenaLivingWorldConditionContainer {
	struct UObject* Owner; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldCondition_TrackedPlayerPresence
// Size: 0x68 (Inherited: 0x10)
struct FFortAthenaLivingWorldCondition_TrackedPlayerPresence : FWorldConditionCommonActorBase {
	struct FWorldConditionContextDataRef ActorRef; // 0x10(0x08)
	struct FScalableFloat MinDistanceToPlayer; // 0x18(0x28)
	struct FScalableFloat MaxDistanceToPlayer; // 0x40(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldDensityCondition
// Size: 0x98 (Inherited: 0x10)
struct FFortAthenaLivingWorldDensityCondition : FWorldConditionCommonActorBase {
	struct FWorldConditionContextDataRef ActorRef; // 0x10(0x08)
	struct FGameplayTag tag; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FScalableFloat Distance; // 0x20(0x28)
	struct FScalableFloat MaxDensity; // 0x48(0x28)
	struct FScalableFloat MinDensity; // 0x70(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldDespawnCondition
// Size: 0x48 (Inherited: 0x00)
struct FFortAthenaLivingWorldDespawnCondition {
	struct FWorldConditionQueryDefinition DespawnWorldCondition; // 0x00(0x18)
	float TimeAsCandidateBeforeDespawn; // 0x18(0x04)
	float TimeAsCandidateBeforeDespawnDeviation; // 0x1c(0x04)
	bool bUseCustomDeathTag; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FGameplayTagContainer DeathTagContainer; // 0x28(0x20)
};

// ScriptStruct LagerRuntime.FortAthenaLinearEncounterPlayerParticipationData
// Size: 0x40 (Inherited: 0x00)
struct FFortAthenaLinearEncounterPlayerParticipationData {
	char pad_0[0x40]; // 0x00(0x40)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldActorUpdateHandler
// Size: 0xb0 (Inherited: 0x00)
struct FFortAthenaLivingWorldActorUpdateHandler {
	struct UFortAthenaLivingWorldManager* LivingWorldManager; // 0x00(0x08)
	char pad_8[0xa8]; // 0x08(0xa8)
};

// ScriptStruct LagerRuntime.FortLivingWorldEventTableVariation
// Size: 0x48 (Inherited: 0x00)
struct FFortLivingWorldEventTableVariation {
	struct TSoftObjectPtr<UDataTable> EventTableVariation; // 0x00(0x20)
	struct FScalableFloat VariationWeight; // 0x20(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldCategory
// Size: 0xe8 (Inherited: 0x08)
struct FFortAthenaLivingWorldCategory : FTableRowBase {
	struct TSoftObjectPtr<UDataTable> EventTable; // 0x08(0x20)
	struct TArray<struct FFortLivingWorldEventTableVariation> EventTableVariations; // 0x28(0x10)
	int32_t MaxCount; // 0x38(0x04)
	int32_t MaxSpawnedCount; // 0x3c(0x04)
	int32_t EventInstanceMaxCount; // 0x40(0x04)
	int32_t EventInstanceMaxSpawnedCount; // 0x44(0x04)
	struct FWorldConditionQueryDefinition CanSpawnCondition; // 0x48(0x18)
	float Priority; // 0x60(0x04)
	bool bExcludeFromGlobalAIBudget; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	struct FGameplayTagQuery RequirePlaylistTagQuery; // 0x68(0x48)
	struct TArray<struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter>> Encounters; // 0xb0(0x10)
	struct FScalableFloat IsEnabled; // 0xc0(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldTagDensityGridData
// Size: 0x30 (Inherited: 0x00)
struct FFortAthenaLivingWorldTagDensityGridData {
	struct FGameplayTag tag; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FScalableFloat GridCellSize; // 0x08(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldCategoryTableData
// Size: 0x50 (Inherited: 0x00)
struct FFortAthenaLivingWorldCategoryTableData {
	struct FName Name; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UDataTable> CategoryTable; // 0x08(0x20)
	struct FScalableFloat IsEnabled; // 0x28(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaActorDensityDebugInfo
// Size: 0x48 (Inherited: 0x00)
struct FFortAthenaActorDensityDebugInfo {
	struct FString ActorName; // 0x00(0x10)
	struct FVector ActorPosition; // 0x10(0x18)
	struct FIntVector MinCellIndex; // 0x28(0x0c)
	struct FIntVector MaxCellIndex; // 0x34(0x0c)
	float DensityValue; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldDensityGrid
// Size: 0x158 (Inherited: 0xc0)
struct FFortAthenaLivingWorldDensityGrid : FFortSpatialGrid {
	char pad_C0[0x98]; // 0xc0(0x98)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldEncounterStage
// Size: 0x70 (Inherited: 0x00)
struct FFortAthenaLivingWorldEncounterStage {
	struct TSoftObjectPtr<UDataTable> EventTable; // 0x00(0x20)
	struct FScalableFloat MaximumConcurrentNumberOfAI; // 0x20(0x28)
	struct FScalableFloat MaxSpawnCountPerEventGeneration; // 0x48(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldEventDespawnCondition
// Size: 0x18 (Inherited: 0x00)
struct FFortAthenaLivingWorldEventDespawnCondition {
	bool bCanBeDespawned; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float MinDistanceToPlayer; // 0x04(0x04)
	float TimeAsCandidateBeforeDespawn; // 0x08(0x04)
	enum class EAthenaGamePhaseStep CanStartDespawningPhaseStep; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	int32_t CanStartDespawningSafeZonePhase; // 0x10(0x04)
	bool bCanDespawnWhenInCombatWithPlayer; // 0x14(0x01)
	bool bCanDespawnInTheStorm; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldEventTagDensityCondition
// Size: 0x0c (Inherited: 0x00)
struct FFortAthenaLivingWorldEventTagDensityCondition {
	struct FGameplayTag tag; // 0x00(0x04)
	float Distance; // 0x04(0x04)
	float MaxDensity; // 0x08(0x04)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldEventDataEntry
// Size: 0x48 (Inherited: 0x00)
struct FFortAthenaLivingWorldEventDataEntry {
	struct TSoftObjectPtr<UFortAthenaLivingWorldEventData> EventData; // 0x00(0x20)
	struct FScalableFloat Weight; // 0x20(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldEvent
// Size: 0x1a8 (Inherited: 0x08)
struct FFortAthenaLivingWorldEvent : FTableRowBase {
	struct TSoftObjectPtr<UFortAthenaLivingWorldEventData> EventData; // 0x08(0x20)
	struct TArray<struct FFortAthenaLivingWorldEventDataEntry> EventDatas; // 0x28(0x10)
	struct FScalableFloat IsEnabled; // 0x38(0x28)
	struct TArray<float> MaxCount; // 0x60(0x10)
	struct TArray<float> MaxSpawnedCount; // 0x70(0x10)
	struct TArray<float> EventInstanceMaxCount; // 0x80(0x10)
	struct TArray<float> EventInstanceMaxSpawnedCount; // 0x90(0x10)
	float Weight; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct TArray<float> MinRespawnTime; // 0xa8(0x10)
	struct TArray<float> MaxRespawnTime; // 0xb8(0x10)
	struct TArray<float> InstantDeathMinRespawnTime; // 0xc8(0x10)
	struct TArray<float> InstantDeathMaxRespawnTime; // 0xd8(0x10)
	bool bOnlyInSafeZone; // 0xe8(0x01)
	bool bOnlyInNextSafeZone; // 0xe9(0x01)
	bool bOnlyInNextSafeZoneIfStormShrinking; // 0xea(0x01)
	char pad_EB[0x5]; // 0xeb(0x05)
	struct FWorldConditionQueryDefinition CanSpawnCondition; // 0xf0(0x18)
	enum class EAthenaGamePhaseStep ActivationGamePhaseStep; // 0x108(0x01)
	char pad_109[0x3]; // 0x109(0x03)
	int32_t ActivationSafezoneIndex; // 0x10c(0x04)
	float ActivationMinDelay; // 0x110(0x04)
	float ActivationMaxDelay; // 0x114(0x04)
	float DeactivationMinDelay; // 0x118(0x04)
	float DeactivationMaxDelay; // 0x11c(0x04)
	struct TArray<struct FFortAthenaLivingWorldEventTagDensityCondition> TagDensityConditions; // 0x120(0x10)
	bool bCheckForActorDensity; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	float MaxActorDensityOverride; // 0x134(0x04)
	float MinDistanceToPlayer; // 0x138(0x04)
	float MaxDistanceToPlayer; // 0x13c(0x04)
	bool bCanSpawnWithoutMatchingPlayerDistance; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	float RandomActivationChance; // 0x144(0x04)
	struct FFortAthenaLivingWorldEventDespawnCondition DespawnCondition; // 0x148(0x18)
	struct TArray<struct FFortAthenaLivingWorldDespawnCondition> DespawnConditions; // 0x160(0x10)
	struct FGameplayTagContainer RequirePlaylistTags; // 0x170(0x20)
	struct FLivingWorldCalendarEventConditions CalendarEventConditions; // 0x190(0x18)
};

// ScriptStruct LagerRuntime.LivingWorldCalendarEventConditions
// Size: 0x18 (Inherited: 0x00)
struct FLivingWorldCalendarEventConditions {
	struct TArray<struct FLivingWorldCalendarEventCondition> Conditions; // 0x00(0x10)
	bool IsActiveWithoutSeasonalManager; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct LagerRuntime.LivingWorldCalendarEventCondition
// Size: 0x10 (Inherited: 0x00)
struct FLivingWorldCalendarEventCondition {
	struct FName CalendarEventName; // 0x00(0x04)
	enum class ELivingWorldCalendarEventConditionBehavior Behavior; // 0x04(0x01)
	bool ShouldEventBeActive; // 0x05(0x01)
	enum class ELivingWorldCalendarEventConditionRatioBehavior RatioBehavior; // 0x06(0x01)
	char pad_7[0x1]; // 0x07(0x01)
	float RatioValue; // 0x08(0x04)
	float RatioMaxValue; // 0x0c(0x04)
};

// ScriptStruct LagerRuntime.PointProviderFilterEntry
// Size: 0x88 (Inherited: 0x00)
struct FPointProviderFilterEntry {
	struct FGameplayTagQuery ProviderFiltersTagQuery; // 0x00(0x48)
	struct FLivingWorldCalendarEventConditions CalendarEventConditions; // 0x48(0x18)
	struct FScalableFloat Weight; // 0x60(0x28)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldEventDataActorSpawnDescription
// Size: 0x130 (Inherited: 0x100)
struct FFortAthenaLivingWorldEventDataActorSpawnDescription : FFortAthenaLivingWorldActorSpawnDescription {
	bool bSpawnAroundDefaultPoint; // 0x100(0x01)
	bool bUpdateDefaultPosition; // 0x101(0x01)
	bool bSharePreviousActorEQSResult; // 0x102(0x01)
	char pad_103[0x5]; // 0x103(0x05)
	struct UEnvQuery* SpawnAroundEnvironmentQuery; // 0x108(0x08)
	enum class EEnvQueryRunMode SpawnAroundEnvironmentQueryRunMode; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	struct FSoftClassPath SpawnAroundNavigationSourceOverride; // 0x118(0x18)
};

// ScriptStruct LagerRuntime.FortLivingWorldConfigOverride
// Size: 0x68 (Inherited: 0x00)
struct FFortLivingWorldConfigOverride {
	struct TSoftObjectPtr<UWorld> SourceWorld; // 0x00(0x20)
	struct FGameplayTagContainer PlaylistTag; // 0x20(0x20)
	struct TSoftObjectPtr<UFortAthenaLivingWorldConfigData> LagerConfig; // 0x40(0x20)
	struct FFortReleaseVersion StartVersion; // 0x60(0x04)
	struct FFortReleaseVersion EndVersion; // 0x64(0x04)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldPlayerTracker
// Size: 0xb0 (Inherited: 0x00)
struct FFortAthenaLivingWorldPlayerTracker {
	struct TSet<struct AFortAthenaAIBotController*> TrackedBotControllers; // 0x00(0x50)
	struct TArray<struct AFortPlayerPawn*> TrackedPlayerPawns; // 0x50(0x10)
	struct TArray<struct AController*> TrackedPlayerControllers; // 0x60(0x10)
	char pad_70[0x40]; // 0x70(0x40)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldPointProviderFilterRules
// Size: 0x38 (Inherited: 0x00)
struct FFortAthenaLivingWorldPointProviderFilterRules {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldPreloader
// Size: 0xe0 (Inherited: 0x00)
struct FFortAthenaLivingWorldPreloader {
	struct UFortAthenaLivingWorldManager* LivingWorldManager; // 0x00(0x08)
	struct TArray<struct UFortAthenaSpawnerDataBase*> LoadedSpawnerDataClass; // 0x08(0x10)
	struct TArray<struct AActor*> LoadedActorClasses; // 0x18(0x10)
	char pad_28[0xb8]; // 0x28(0xb8)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldTaggedSpawnActionClass
// Size: 0x10 (Inherited: 0x00)
struct FFortAthenaLivingWorldTaggedSpawnActionClass {
	struct FGameplayTag SpawnActionTag; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UFortAthenaLivingWorldSpawnAction* SpawnActionClass; // 0x08(0x08)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldCategoryTableDataList
// Size: 0x10 (Inherited: 0x00)
struct FFortAthenaLivingWorldCategoryTableDataList {
	struct TArray<struct FFortAthenaLivingWorldCategoryTableData> CategoryTableDatas; // 0x00(0x10)
};

// ScriptStruct LagerRuntime.LivingWorldSpawnAroundPlayerConfiguration
// Size: 0x38 (Inherited: 0x00)
struct FLivingWorldSpawnAroundPlayerConfiguration {
	struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter> Encounter; // 0x00(0x20)
	struct TArray<struct AFortAthenaPointAroundPlayerProvider*> PointProviderClasses; // 0x20(0x10)
	bool bRegisterReservoir; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct LagerRuntime.LivingWorldSpawnAroundPlayerRuntimeData
// Size: 0x18 (Inherited: 0x00)
struct FLivingWorldSpawnAroundPlayerRuntimeData {
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> PointAroundPlayerProviders; // 0x00(0x10)
	struct UFortAthenaLivingWorldEncounterInstance* Encounter; // 0x10(0x08)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldPointProviderSelector
// Size: 0x08 (Inherited: 0x00)
struct FFortAthenaLivingWorldPointProviderSelector {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct LagerRuntime.FortAthenaLivingWorldTagQueryToSeatMapping
// Size: 0x50 (Inherited: 0x00)
struct FFortAthenaLivingWorldTagQueryToSeatMapping {
	struct FGameplayTagQuery TagQuery; // 0x00(0x48)
	int32_t SeatIndex; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

