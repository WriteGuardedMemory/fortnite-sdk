// Class DanceVolume.DanceSynchronizerComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UDanceSynchronizerComponent : UActorComponent {
	char bShouldHalfOrDoubleTimeDances : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	struct FDanceBeatInfo BeatInfo; // 0xa4(0x08)
	enum class EDanceBeatSyncMode SyncMode; // 0xac(0x01)
	char pad_AD[0x3]; // 0xad(0x03)
	float Tempo; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct AFortPlayerPawn* OwnerPlayerPawn; // 0xb8(0x08)
	struct USkeletalMeshComponent* OwnerMeshComponent; // 0xc0(0x08)
	struct USkeletalMeshComponent* LeaderMeshComponent; // 0xc8(0x08)
	char pad_D0[0x8]; // 0xd0(0x08)

	void StopOwnerEmoteAudio(); // Function DanceVolume.DanceSynchronizerComponent.StopOwnerEmoteAudio // (Final|Native|Public|BlueprintCallable) // @ game+0xaaa04d0
	void SetTempo(float NewTempo); // Function DanceVolume.DanceSynchronizerComponent.SetTempo // (Final|Native|Public|BlueprintCallable) // @ game+0xaaa09f0
	void SetDanceBeatInfo(struct FDanceBeatInfo& NewDanceBeatInfo); // Function DanceVolume.DanceSynchronizerComponent.SetDanceBeatInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaaa0ae0
	void SetBeatSyncMode(enum class EDanceBeatSyncMode NewMode); // Function DanceVolume.DanceSynchronizerComponent.SetBeatSyncMode // (Final|Native|Public|BlueprintCallable) // @ game+0xaaa0900
	void OnRep_SyncMode(); // Function DanceVolume.DanceSynchronizerComponent.OnRep_SyncMode // (Final|Native|Private) // @ game+0xaaa0460
	bool IsTempoSyncEnabled(); // Function DanceVolume.DanceSynchronizerComponent.IsTempoSyncEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xaaa08d0
	struct USkeletalMeshComponent* GetOwnerSkeletalMeshComponent(); // Function DanceVolume.DanceSynchronizerComponent.GetOwnerSkeletalMeshComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x44efc70
	struct AFortPlayerPawn* GetOwnerFortPlayerPawn(); // Function DanceVolume.DanceSynchronizerComponent.GetOwnerFortPlayerPawn // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x85a4910
	float CalculateDanceMontagePlayRate(float CurrentTempo, struct UAnimMontage* Montage, struct FDanceBeatInfo& DanceBeatInfo); // Function DanceVolume.DanceSynchronizerComponent.CalculateDanceMontagePlayRate // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xaaa0600
};

// Class DanceVolume.DanceVolumeLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDanceVolumeLibrary : UBlueprintFunctionLibrary {

	struct UFortItemDefinition* GetLastEmoteExecuted(struct AController* Controller); // Function DanceVolume.DanceVolumeLibrary.GetLastEmoteExecuted // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xaaa2260
	void ForceStopMontage(struct AFortPawn* FortPawn); // Function DanceVolume.DanceVolumeLibrary.ForceStopMontage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaaa23a0
};

