// Class EventModeUI.FocusButton
// Size: 0x428 (Inherited: 0x418)
struct UFocusButton : UBacchusActionButton {
	struct UPaperSprite* StartFocusingSprite; // 0x418(0x08)
	struct UPaperSprite* StopFocusingSprite; // 0x420(0x08)

	void HandleEventModeFocusingChanged(bool bIsEventModeFocusing); // Function EventModeUI.FocusButton.HandleEventModeFocusingChanged // (Final|Native|Private) // @ game+0xabaf4d0
	void HandleCanUseEventModeFocusChanged(bool bCanUseEventModeFocus); // Function EventModeUI.FocusButton.HandleCanUseEventModeFocusChanged // (Final|Native|Private) // @ game+0xabaf5f0
};

// Class EventModeUI.FortEventModeEmotesWidget
// Size: 0x3a8 (Inherited: 0x310)
struct UFortEventModeEmotesWidget : UFortHUDElementWidget {
	struct TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote1; // 0x310(0x20)
	struct TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote2; // 0x330(0x20)
	struct TSoftObjectPtr<UFortMontageItemDefinitionBase> Emote3; // 0x350(0x20)
	struct TArray<struct TSoftObjectPtr<UFortMontageItemDefinitionBase>> RandomEmotes; // 0x370(0x10)
	char pad_380[0x8]; // 0x380(0x08)
	struct URichTextBlock* Text_Emote1; // 0x388(0x08)
	struct URichTextBlock* Text_Emote2; // 0x390(0x08)
	struct URichTextBlock* Text_Emote3; // 0x398(0x08)
	struct URichTextBlock* Text_EmoteRandom; // 0x3a0(0x08)

	void OnFocusStateChanged(bool bIsFocusing); // Function EventModeUI.FortEventModeEmotesWidget.OnFocusStateChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnFocusAvailableChanged(bool bIsFocusAvailable); // Function EventModeUI.FortEventModeEmotesWidget.OnFocusAvailableChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventModeUI.FortMobileActionButtonBehavior_Focus
// Size: 0x128 (Inherited: 0x120)
struct UFortMobileActionButtonBehavior_Focus : UFortMobileActionButtonBehavior {
	struct UPaperSprite* StopFocusingSprite; // 0x120(0x08)

	void HandleEventModeFocusingChanged(bool bIsEventModeFocusing); // Function EventModeUI.FortMobileActionButtonBehavior_Focus.HandleEventModeFocusingChanged // (Final|Native|Private) // @ game+0x9adfed0
	void HandleCanUseEventModeFocusChanged(bool bCanUseEventModeFocus); // Function EventModeUI.FortMobileActionButtonBehavior_Focus.HandleCanUseEventModeFocusChanged // (Final|Native|Private) // @ game+0x9ae1130
};

