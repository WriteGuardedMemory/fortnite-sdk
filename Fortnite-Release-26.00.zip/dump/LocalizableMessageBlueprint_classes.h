// Class LocalizableMessageBlueprint.LocalizableMessageLibrary
// Size: 0x28 (Inherited: 0x28)
struct ULocalizableMessageLibrary : UBlueprintFunctionLibrary {

	void Reset_LocalizableMessage(struct FLocalizableMessage& Message); // Function LocalizableMessageBlueprint.LocalizableMessageLibrary.Reset_LocalizableMessage // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa570ee0
	bool IsEmpty_LocalizableMessage(struct FLocalizableMessage& Message); // Function LocalizableMessageBlueprint.LocalizableMessageLibrary.IsEmpty_LocalizableMessage // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa5711a0
	struct FText Conv_LocalizableMessageToText(struct UObject* WorldContextObject, struct FLocalizableMessage& Message); // Function LocalizableMessageBlueprint.LocalizableMessageLibrary.Conv_LocalizableMessageToText // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa571390
};

