// Class AscenderCodeRuntime.FortCheatManager_AscenderZipline
// Size: 0x28 (Inherited: 0x28)
struct UFortCheatManager_AscenderZipline : UChildCheatManager {

	void RemoveAscenders(bool bRemoveAscendersOn); // Function AscenderCodeRuntime.FortCheatManager_AscenderZipline.RemoveAscenders // (Final|Exec|Native|Public) // @ game+0x34b0aa0
};

// Class AscenderCodeRuntime.FortAscenderZipline
// Size: 0xfe0 (Inherited: 0xc88)
struct AFortAscenderZipline : AFortAthenaSplineZipline {
	struct FMulticastInlineDelegate OnAscenderSetupComplete; // 0xc88(0x10)
	struct FName SplineTopAttachPointName; // 0xc98(0x04)
	bool bAutoFindSplineEndLocation; // 0xc9c(0x01)
	char pad_C9D[0x3]; // 0xc9d(0x03)
	float SplineOffsetFromGround; // 0xca0(0x04)
	float CableOffsetFromSplineEnd; // 0xca4(0x04)
	float SplineLength; // 0xca8(0x04)
	char pad_CAC[0x4]; // 0xcac(0x04)
	struct UStaticMesh* SplineStaticMesh; // 0xcb0(0x08)
	enum class ESplineMeshAxis MeshForwardAxis; // 0xcb8(0x01)
	bool bHandleReturning; // 0xcb9(0x01)
	char pad_CBA[0x2]; // 0xcba(0x02)
	float HandleReturnSpeed; // 0xcbc(0x04)
	bool bCableDropping; // 0xcc0(0x01)
	char pad_CC1[0x3]; // 0xcc1(0x03)
	float CableDropSpeed; // 0xcc4(0x04)
	float YawRotationOffsetWhileUsingHandle; // 0xcc8(0x04)
	float YawRotationOffsetWhileSlidingDown; // 0xccc(0x04)
	bool bUseComplexSplineCollision; // 0xcd0(0x01)
	char pad_CD1[0x3]; // 0xcd1(0x03)
	float SimpleSplineCollisionRadius; // 0xcd4(0x04)
	float SimpleSplineCollisionHeightExtension; // 0xcd8(0x04)
	char pad_CDC[0x4]; // 0xcdc(0x04)
	struct FScalableFloat DescendMinDistanceFromBottom; // 0xce0(0x28)
	struct FScalableFloat AscendReachedEndHorizontalLaunchSpeed; // 0xd08(0x28)
	struct FScalableFloat AscendReachedEndVerticalLaunchSpeed; // 0xd30(0x28)
	struct FScalableFloat AscendJumpedOffHorizontalLaunchSpeed; // 0xd58(0x28)
	struct FScalableFloat AscendJumpedOffVerticalLaunchSpeed; // 0xd80(0x28)
	struct FScalableFloat DescendReachedEndHorizontalLaunchSpeed; // 0xda8(0x28)
	struct FScalableFloat DescendReachedEndVerticalLaunchSpeed; // 0xdd0(0x28)
	struct FScalableFloat DescendJumpedOffHorizontalLaunchSpeed; // 0xdf8(0x28)
	struct FScalableFloat DescendJumpedOffVerticalLaunchSpeed; // 0xe20(0x28)
	struct FScalableFloat HandleActorHitPlayerHorizontalLaunchSpeed; // 0xe48(0x28)
	struct FScalableFloat HandleActorHitPlayerVerticalLaunchSpeed; // 0xe70(0x28)
	struct FVector HandleDestroyBuildingsOverlapExtents; // 0xe98(0x18)
	struct FVector PlayerDestroyBuildingsOverlapExtents; // 0xeb0(0x18)
	struct FVector InitialSplineEndLocation; // 0xec8(0x18)
	struct FVector CurrentSplineEndLocation; // 0xee0(0x18)
	struct FVector TargetSplineEndLocation; // 0xef8(0x18)
	struct FVector CurrentHandleLocation; // 0xf10(0x18)
	struct TWeakObjectPtr<struct UPrimitiveComponent> CurrentInteractComponent; // 0xf28(0x08)
	struct TWeakObjectPtr<struct AFortPlayerPawn> PawnUsingHandle; // 0xf30(0x08)
	struct TWeakObjectPtr<struct AFortPlayerPawn> PreviousPawnUsingHandle; // 0xf38(0x08)
	struct USplineMeshComponent* SplineMesh; // 0xf40(0x08)
	struct UCapsuleComponent* SimpleSplineMeshCollision; // 0xf48(0x08)
	struct TWeakObjectPtr<struct ABuildingActor> FloorActor; // 0xf50(0x08)
	struct TArray<struct TWeakObjectPtr<struct AFortPlayerPawn>> RotationLockedPawns; // 0xf58(0x10)
	char pad_F68[0x68]; // 0xf68(0x68)
	struct UFortLinkToActorComponent* LinkToActorComponent; // 0xfd0(0x08)
	struct UFortZiplineLinkComponent* ZiplineLinkComponent; // 0xfd8(0x08)

	void SetupAscender(bool bFromConstruction, bool bFromReplication); // Function AscenderCodeRuntime.FortAscenderZipline.SetupAscender // (Final|Native|Protected|BlueprintCallable) // @ game+0xa7ae420
	void OnRep_TargetSplineEndLocation(); // Function AscenderCodeRuntime.FortAscenderZipline.OnRep_TargetSplineEndLocation // (Final|Native|Protected) // @ game+0xa7ae5c0
	void OnRep_PawnUsingHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.OnRep_PawnUsingHandle // (Final|Native|Protected) // @ game+0xa7ae5a0
	void OnRep_InitialSplineEndLocation(); // Function AscenderCodeRuntime.FortAscenderZipline.OnRep_InitialSplineEndLocation // (Final|Native|Protected) // @ game+0xa7ae6b0
	void HandlePawnUsingHandleDied(struct AFortPawn* DeadPawn); // Function AscenderCodeRuntime.FortAscenderZipline.HandlePawnUsingHandleDied // (Final|Native|Protected) // @ game+0xa7ae880
	void HandleFloorActorHealthChanged(); // Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorHealthChanged // (Final|Native|Protected) // @ game+0xa7ae770
	void HandleFloorActorDestroyed(struct AActor* Actor); // Function AscenderCodeRuntime.FortAscenderZipline.HandleFloorActorDestroyed // (Final|Native|Protected) // @ game+0xa7ae790
	struct UPrimitiveComponent* GetTopComponent(); // Function AscenderCodeRuntime.FortAscenderZipline.GetTopComponent // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1b027f0
	struct AFortPlayerPawn* GetPawnUsingHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.GetPawnUsingHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7ae970
	struct UPrimitiveComponent* GetInteractComponentOverride(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent); // Function AscenderCodeRuntime.FortAscenderZipline.GetInteractComponentOverride // (Native|Event|Public|BlueprintEvent|Const) // @ game+0xa7ae9f0
	struct UPrimitiveComponent* GetHandleComponent(); // Function AscenderCodeRuntime.FortAscenderZipline.GetHandleComponent // (Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1b027f0
	void BP_HandleUpdatedLoweringHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringHandle // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void BP_HandleUpdatedLoweringCable(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleUpdatedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void BP_HandleStoppedLoweringHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringHandle // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void BP_HandleStoppedLoweringCable(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStoppedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void BP_HandleStartedLoweringHandle(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringHandle // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void BP_HandleStartedLoweringCable(); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandleStartedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void BP_HandlePlayerStoppedUsingHandle(struct AFortPlayerPawn* Player); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStoppedUsingHandle // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void BP_HandlePlayerStartedUsingHandle(struct AFortPlayerPawn* Player); // Function AscenderCodeRuntime.FortAscenderZipline.BP_HandlePlayerStartedUsingHandle // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void ApplyStructureDamage(struct ABuildingSMActor* BuildingActor, struct AActor* DamageSource); // Function AscenderCodeRuntime.FortAscenderZipline.ApplyStructureDamage // (Event|Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0x1b027f0
};

