// ScriptStruct DataflowCore.DataflowConnection
// Size: 0x38 (Inherited: 0x00)
struct FDataflowConnection {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct DataflowCore.DataflowInput
// Size: 0x40 (Inherited: 0x38)
struct FDataflowInput : FDataflowConnection {
	char pad_38[0x8]; // 0x38(0x08)
};

// ScriptStruct DataflowCore.DataflowOutput
// Size: 0x60 (Inherited: 0x38)
struct FDataflowOutput : FDataflowConnection {
	char pad_38[0x28]; // 0x38(0x28)
};

// ScriptStruct DataflowCore.DataflowNode
// Size: 0xe8 (Inherited: 0x00)
struct FDataflowNode {
	char pad_0[0xc8]; // 0x00(0xc8)
	bool bActive; // 0xc8(0x01)
	char pad_C9[0x1f]; // 0xc9(0x1f)
};

// ScriptStruct DataflowCore.DataflowOverrideNode
// Size: 0x108 (Inherited: 0xe8)
struct FDataflowOverrideNode : FDataflowNode {
	struct FName Key; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FString Default; // 0xf0(0x10)
	bool IsOverriden; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
};

// ScriptStruct DataflowCore.DataflowSelection
// Size: 0x20 (Inherited: 0x00)
struct FDataflowSelection {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct DataflowCore.DataflowTransformSelection
// Size: 0x20 (Inherited: 0x20)
struct FDataflowTransformSelection : FDataflowSelection {
};

// ScriptStruct DataflowCore.DataflowVertexSelection
// Size: 0x20 (Inherited: 0x20)
struct FDataflowVertexSelection : FDataflowSelection {
};

// ScriptStruct DataflowCore.DataflowFaceSelection
// Size: 0x20 (Inherited: 0x20)
struct FDataflowFaceSelection : FDataflowSelection {
};

// ScriptStruct DataflowCore.NodeColors
// Size: 0x20 (Inherited: 0x00)
struct FNodeColors {
	struct FLinearColor NodeTitleColor; // 0x00(0x10)
	struct FLinearColor NodeBodyTintColor; // 0x10(0x10)
};

// ScriptStruct DataflowCore.DataflowTerminalNode
// Size: 0xe8 (Inherited: 0xe8)
struct FDataflowTerminalNode : FDataflowNode {
};

