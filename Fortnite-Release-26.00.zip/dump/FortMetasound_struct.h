// Enum FortMetasound.EFortAudioAffiliation
enum class EFortAudioAffiliation : uint8 {
	Local = 0,
	Friendly = 1,
	Enemy = 2,
	Neutral = 3,
	EFortAudioAffiliation_MAX = 4
};

