// Class ComputeFramework.ComputeDataInterface
// Size: 0x28 (Inherited: 0x28)
struct UComputeDataInterface : UObject {
};

// Class ComputeFramework.ComputeDataProvider
// Size: 0x28 (Inherited: 0x28)
struct UComputeDataProvider : UObject {
};

// Class ComputeFramework.ComputeKernelSource
// Size: 0x98 (Inherited: 0x28)
struct UComputeKernelSource : UObject {
	struct FString EntryPoint; // 0x28(0x10)
	struct FIntVector GroupSize; // 0x38(0x0c)
	char pad_44[0x4]; // 0x44(0x04)
	struct FComputeKernelPermutationSet PermutationSet; // 0x48(0x10)
	struct FComputeKernelDefinitionSet DefinitionsSet; // 0x58(0x10)
	struct TArray<struct UComputeSource*> AdditionalSources; // 0x68(0x10)
	struct TArray<struct FShaderFunctionDefinition> ExternalInputs; // 0x78(0x10)
	struct TArray<struct FShaderFunctionDefinition> ExternalOutputs; // 0x88(0x10)
};

// Class ComputeFramework.ComputeSource
// Size: 0x38 (Inherited: 0x28)
struct UComputeSource : UObject {
	struct TArray<struct UComputeSource*> AdditionalSources; // 0x28(0x10)
};

// Class ComputeFramework.ComputeGraph
// Size: 0x90 (Inherited: 0x28)
struct UComputeGraph : UObject {
	struct TArray<struct UComputeKernel*> KernelInvocations; // 0x28(0x10)
	struct TArray<struct UComputeDataInterface*> DataInterfaces; // 0x38(0x10)
	struct TArray<struct FComputeGraphEdge> GraphEdges; // 0x48(0x10)
	struct TArray<ClassPtrProperty> Bindings; // 0x58(0x10)
	struct TArray<int32_t> DataInterfaceToBinding; // 0x68(0x10)
	char pad_78[0x18]; // 0x78(0x18)
};

// Class ComputeFramework.ComputeGraphComponent
// Size: 0xc0 (Inherited: 0xa0)
struct UComputeGraphComponent : UActorComponent {
	struct UComputeGraph* ComputeGraph; // 0xa0(0x08)
	struct FComputeGraphInstance ComputeGraphInstance; // 0xa8(0x18)

	void QueueExecute(); // Function ComputeFramework.ComputeGraphComponent.QueueExecute // (Final|Native|Public|BlueprintCallable) // @ game+0xacb6200
	void DestroyDataProviders(); // Function ComputeFramework.ComputeGraphComponent.DestroyDataProviders // (Final|Native|Public|BlueprintCallable) // @ game+0xacb6240
	void CreateDataProviders(int32_t InBindingIndex, struct UObject* InBindingObject); // Function ComputeFramework.ComputeGraphComponent.CreateDataProviders // (Final|Native|Public|BlueprintCallable) // @ game+0xacb6270
};

// Class ComputeFramework.ComputeKernel
// Size: 0x38 (Inherited: 0x28)
struct UComputeKernel : UObject {
	struct UComputeKernelSource* KernelSource; // 0x28(0x08)
	int32_t KernelFlags; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class ComputeFramework.ComputeKernelFromText
// Size: 0xa8 (Inherited: 0x98)
struct UComputeKernelFromText : UComputeKernelSource {
	struct FFilePath SourceFile; // 0x98(0x10)
};

// Class ComputeFramework.ComputeSourceFromText
// Size: 0x48 (Inherited: 0x38)
struct UComputeSourceFromText : UComputeSource {
	struct FFilePath SourceFile; // 0x38(0x10)
};

