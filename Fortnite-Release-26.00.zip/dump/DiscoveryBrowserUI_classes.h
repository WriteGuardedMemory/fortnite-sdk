// Class DiscoveryBrowserUI.FortActivityBrowserTabButton
// Size: 0x14a0 (Inherited: 0x14a0)
struct UFortActivityBrowserTabButton : UFortTabButton {

	void OnFavoriteChanged(bool bIsFavorite); // Function DiscoveryBrowserUI.FortActivityBrowserTabButton.OnFavoriteChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityBrowser
// Size: 0x648 (Inherited: 0x3e8)
struct UFortActivityBrowser : UCommonActivatableWidget {
	char pad_3E8[0x8]; // 0x3e8(0x08)
	struct UCommonActivatableWidgetSwitcher* Switcher_TabActivityBrowserViews; // 0x3f0(0x08)
	struct UCommonButtonBase* Button_Back; // 0x3f8(0x08)
	struct UCommonButtonBase* Button_ShowCustomMatchmakingModal; // 0x400(0x08)
	struct UCommonButtonBase* Button_BackToTop; // 0x408(0x08)
	struct UCommonButtonBase* Button_MobileShowGameDetails; // 0x410(0x08)
	struct UCommonButtonBase* Button_MobileAccept; // 0x418(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x420(0x08)
	struct UCommonButtonBase* Button_JoinAsSpectator; // 0x428(0x08)
	struct UCommonButtonBase* Button_ShowSpectateMatchModal; // 0x430(0x08)
	struct UFortTabListWidgetBase_Legacy* TabList_BrowserTabs; // 0x438(0x08)
	struct FPrimaryContentSetup PrimaryContentSetup; // 0x440(0x03)
	char pad_443[0x5]; // 0x443(0x05)
	struct UFortTabButton* TabButtonClass; // 0x448(0x08)
	struct UFortActivityDetailsModal* ActivityDetailsModalClass; // 0x450(0x08)
	struct UFortActivityModeSetSelectionModal* ActivityModeSetSelectionModalClass; // 0x458(0x08)
	struct UCommonActivatableWidget* ActivityModeSetFirstTimeNotificationModalClass; // 0x460(0x08)
	struct UFortActivityBrowserAttributionsModal* AttributionsModalClass; // 0x468(0x08)
	struct UFortActivityCreatorPageView* CreatorPageViewClass; // 0x470(0x08)
	struct UFortActivityCategoryPageView* CategoryPageViewClass; // 0x478(0x08)
	struct TSoftClassPtr<UObject> SoftCustomMatchmakingModalClass; // 0x480(0x20)
	struct TSoftClassPtr<UObject> SoftSpectateMatchModalClass; // 0x4a0(0x20)
	struct UFortCampaignPurchaseScreen* CampaignPurchaseScreenClass; // 0x4c0(0x08)
	struct UCommonActivatableWidget* CCUModalClass; // 0x4c8(0x08)
	struct TMap<struct FName, struct UFortActivityBrowserColorSchemeAsset*> ColorSchemes; // 0x4d0(0x50)
	struct FText MobileAcceptButtonBaseText; // 0x520(0x18)
	struct UFortCreativeDiscoverySurfaceManager* Manager; // 0x538(0x08)
	struct TWeakObjectPtr<struct UFortActivityBrowserPlayWithFriendsTile> LastSelectedPlayWithFriendsTile; // 0x540(0x08)
	char pad_548[0x10]; // 0x548(0x10)
	struct UFortGameActivity* SelectedGameActivity; // 0x558(0x08)
	char pad_560[0xb0]; // 0x560(0xb0)
	struct UFortActivityBrowserColorSchemeAsset* CurrentColorScheme; // 0x610(0x08)
	char pad_618[0x8]; // 0x618(0x08)
	struct UFortActivityCategoryPageView* CachedCategoryPageView; // 0x620(0x08)
	struct UFortActivityCreatorPageView* CachedCreatorPageView; // 0x628(0x08)
	bool bCCUModalEnabled; // 0x630(0x01)
	char pad_631[0x17]; // 0x631(0x17)

	void OnSwapColorScheme(bool bInIsUsingAlternateColorScheme); // Function DiscoveryBrowserUI.FortActivityBrowser.OnSwapColorScheme // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayerQueueTypeChanged(enum class EPlayerQueueType PlayerQueueType); // Function DiscoveryBrowserUI.FortActivityBrowser.OnPlayerQueueTypeChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEnableColorScheme(bool bIsColorSchemeActive); // Function DiscoveryBrowserUI.FortActivityBrowser.OnEnableColorScheme // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnActivitySelected(); // Function DiscoveryBrowserUI.FortActivityBrowser.OnActivitySelected // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandleTabChanged(struct FName TabId); // Function DiscoveryBrowserUI.FortActivityBrowser.HandleTabChanged // (Final|Native|Private) // @ game+0xab2c730
};

// Class DiscoveryBrowserUI.FortActivityBrowserColorSchemeAsset
// Size: 0x80 (Inherited: 0x30)
struct UFortActivityBrowserColorSchemeAsset : UDataAsset {
	struct TMap<struct UMaterialParameterCollection*, struct FColorSchemeParamaterValues> MaterialCollectionOverrides; // 0x30(0x50)
};

// Class DiscoveryBrowserUI.FortActivityBrowserListView
// Size: 0x4c0 (Inherited: 0x290)
struct UFortActivityBrowserListView : UListViewBase {
	char pad_290[0xe8]; // 0x290(0xe8)
	float DirectionalNavigationTimeThreshold; // 0x378(0x04)
	bool bLockPositionForController; // 0x37c(0x01)
	char pad_37D[0x3]; // 0x37d(0x03)
	int32_t LockedPositionAt; // 0x380(0x04)
	char pad_384[0x4]; // 0x384(0x04)
	struct UFortActivityBrowserRow* PromotedActivityClass; // 0x388(0x08)
	struct UFortActivityBrowserRow* DiscoverItemRowClass; // 0x390(0x08)
	struct TMap<struct FName, struct UFortActivityBrowserRow*> RowTypes; // 0x398(0x50)
	char pad_3E8[0xd8]; // 0x3e8(0xd8)
};

// Class DiscoveryBrowserUI.FortActivityBrowserTileBase
// Size: 0x14d0 (Inherited: 0x1470)
struct UFortActivityBrowserTileBase : UCommonButtonBase {
	char pad_1470[0x60]; // 0x1470(0x60)
};

// Class DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile
// Size: 0x15a0 (Inherited: 0x14d0)
struct UFortActivityBrowserPlayWithFriendsTile : UFortActivityBrowserTileBase {
	int32_t MaxNamesToDisplay; // 0x14d0(0x04)
	int32_t MaxPortraitsToDisplay; // 0x14d4(0x04)
	char pad_14D8[0x10]; // 0x14d8(0x10)
	struct UFortJoinablePartyPortraitsDisplay* PartyMembersAvatarsDisplay; // 0x14e8(0x08)
	struct UFortCTAButton* WBP_CTA_ButtonPrimary; // 0x14f0(0x08)
	bool bIsActiveInvite; // 0x14f8(0x01)
	char pad_14F9[0x3]; // 0x14f9(0x03)
	int32_t CurrentPartySize; // 0x14fc(0x04)
	bool bIsPartyPrivate; // 0x1500(0x01)
	char pad_1501[0x7]; // 0x1501(0x07)
	struct UFortGameActivity* CachedGameActivity; // 0x1508(0x08)
	char pad_1510[0x10]; // 0x1510(0x10)
	struct TWeakObjectPtr<struct USocialUser> CachedTargetSocialUser; // 0x1520(0x08)
	struct FText CurrentCTAButtonText; // 0x1528(0x18)
	struct FText JoinPartyText; // 0x1540(0x18)
	struct FText RequestToJoinText; // 0x1558(0x18)
	char pad_1570[0x30]; // 0x1570(0x30)

	void UpdateSingleFriendName(struct FText& SingleFriendName); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateSingleFriendName // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void UpdateRichPresence(struct FText& RichPresence); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateRichPresence // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void UpdatePartyMemberNames(struct FText& Names); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdatePartyMemberNames // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void UpdateOtherPlayersSubText(struct FText& OtherPlayersSubText); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateOtherPlayersSubText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void UpdateLastInteraction(struct FText& LastInteraction); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateLastInteraction // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void UpdateIslandThumbnail(struct UTexture* ThumbnailTexture); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.UpdateIslandThumbnail // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnTileActiveChanged(bool bIsTileActive); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.OnTileActiveChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnTextureLoadingComplete(struct UTexture* ThumbnailTexture); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.OnTextureLoadingComplete // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnTextureBeginLoading(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.OnTextureBeginLoading // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandleCTAButtonClicked(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.HandleCTAButtonClicked // (Final|Native|Protected|BlueprintCallable) // @ game+0xab3b0a0
	int32_t GetMaxPartySize(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.GetMaxPartySize // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab3afb0
	struct FText GetCTAButtonText(); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.GetCTAButtonText // (Final|Native|Public|BlueprintCallable) // @ game+0xab3b0c0
	void BP_PartyInformationUpdated(bool bInIsTileSelected); // Function DiscoveryBrowserUI.FortActivityBrowserPlayWithFriendsTile.BP_PartyInformationUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityBrowserRow
// Size: 0x390 (Inherited: 0x2d0)
struct UFortActivityBrowserRow : UCommonUserWidget {
	char pad_2D0[0xb0]; // 0x2d0(0xb0)
	struct UCommonTextBlock* Text_CategoryName; // 0x380(0x08)
	float MinimumVisibilityPercentageForRowActivation; // 0x388(0x04)
	char pad_38C[0x4]; // 0x38c(0x04)

	void OnRowPeekStateChanged(bool bIsInPeekState); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowPeekStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRowMoveUp(bool bMovingOffscreen); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveUp // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRowMoveDown(bool bMovingOffscreen); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowMoveDown // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRowIsSelectedChanged(bool bIsSelected); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsSelectedChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRowIsActiveChanged(bool bIsActive); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnRowIsActiveChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnCategoryItemChanged(bool bPlayAnimation); // Function DiscoveryBrowserUI.FortActivityBrowserRow.OnCategoryItemChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool GetIsSelected(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsSelected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab3ec60
	bool GetIsInPeekState(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsInPeekState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab3ec30
	bool GetIsActive(); // Function DiscoveryBrowserUI.FortActivityBrowserRow.GetIsActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8639fe0
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowHero
// Size: 0x410 (Inherited: 0x390)
struct UFortActivityBrowserRowHero : UFortActivityBrowserRow {
	struct UFortActivityListView* ListView_Activities; // 0x390(0x08)
	struct UFortSwipePanel* SwipePanel_Navigation; // 0x398(0x08)
	char pad_3A0[0x3]; // 0x3a0(0x03)
	bool bPlayDetailsAnimationOnScreenOpen; // 0x3a3(0x01)
	float DetailsDisplayUpdateDelay; // 0x3a4(0x04)
	struct UFortActivityDetailsDisplay* DetailsDisplay_SelectedActivity; // 0x3a8(0x08)
	struct UFortActivityVideoCycle* ActivityVideoCycleWidget; // 0x3b0(0x08)
	char pad_3B8[0x20]; // 0x3b8(0x20)
	struct UWidgetAnimation* BoundKeyArtOutroAnimation; // 0x3d8(0x08)
	char pad_3E0[0x2]; // 0x3e0(0x02)
	bool bShouldAutoCycle; // 0x3e2(0x01)
	char pad_3E3[0x2d]; // 0x3e3(0x2d)

	void OnVideoStarted(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnVideoEndReached(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnVideoEndReached // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnUpdateDetailsDisplay(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnUpdateDetailsDisplay // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnTileClicked(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnTileClicked // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRowHeroFocusChanged(bool bHasFocus); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnRowHeroFocusChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnQueryStatusChanged(bool bIsActive); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryStatusChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnQueryActivitiesFinished(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnQueryActivitiesFinished // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPreviewImageChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayKeyArtOutro(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtOutro // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayKeyArtIntro(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnPlayKeyArtIntro // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnListViewFinishedAddingEntries(int32_t ActivityCount); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnListViewFinishedAddingEntries // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnActivityUpdated(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.OnActivityUpdated // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool IsShowingSeasonalContent(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsShowingSeasonalContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab3fe30
	bool IsInOutroState(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsInOutroState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab3fdf0
	bool IsImageLoading(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.IsImageLoading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab3fe10
	void HandleActivityVideoCycleStarted(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleStarted // (Final|Native|Private) // @ game+0xab3fd00
	void HandleActivityVideoCycleEndReached(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.HandleActivityVideoCycleEndReached // (Final|Native|Private) // @ game+0xab3fcb0
	struct UWidgetAnimation* GetKeyArtOutroAnimation(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetKeyArtOutroAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xab3fda0
	float GetCyclingPauseDelay(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetCyclingPauseDelay // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab3fee0
	float GetCyclingDelay(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetCyclingDelay // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab3ff20
	struct UTexture* GetCurrentTexture(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.GetCurrentTexture // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xab3fd70
	void CycleNextActivity(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CycleNextActivity // (Final|Native|Public|BlueprintCallable) // @ game+0xab3fdd0
	void CheckUpdateDetailsDelay(); // Function DiscoveryBrowserUI.FortActivityBrowserRowHero.CheckUpdateDetailsDelay // (Final|Native|Private) // @ game+0xab3fd50
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowList
// Size: 0x3b0 (Inherited: 0x390)
struct UFortActivityBrowserRowList : UFortActivityBrowserRow {
	struct UFortActivityListView* ListView_Activities; // 0x390(0x08)
	struct UCommonButtonBase* Button_PageLeft; // 0x398(0x08)
	struct UCommonButtonBase* Button_PageRight; // 0x3a0(0x08)
	char pad_3A8[0x8]; // 0x3a8(0x08)

	void OnQueryStatusChanged(bool bIsActive); // Function DiscoveryBrowserUI.FortActivityBrowserRowList.OnQueryStatusChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowPromoted
// Size: 0x398 (Inherited: 0x390)
struct UFortActivityBrowserRowPromoted : UFortActivityBrowserRow {
	struct UCommonTextBlock* Text_ActivityName; // 0x390(0x08)

	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityBrowserRowPromoted.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityBrowserView
// Size: 0x4e0 (Inherited: 0x438)
struct UFortActivityBrowserView : UFortActivityView {
	char pad_438[0x8]; // 0x438(0x08)
	bool bShowCustomMatchmakingModalButton; // 0x440(0x01)
	bool bShowSpectateMatchModalButton; // 0x441(0x01)
	bool bShowMobileGameDetailsButton; // 0x442(0x01)
	bool bShowMobileAcceptButton; // 0x443(0x01)
	bool bShowBackToTopButton; // 0x444(0x01)
	char pad_445[0x3]; // 0x445(0x03)
	struct FName DiscoverySurfaceName; // 0x448(0x04)
	char pad_44C[0x94]; // 0x44c(0x94)

	void OnSurfaceDataDirty(); // Function DiscoveryBrowserUI.FortActivityBrowserView.OnSurfaceDataDirty // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	enum class EFortInvalidActivityReason GetInvalidActivityReason(); // Function DiscoveryBrowserUI.FortActivityBrowserView.GetInvalidActivityReason // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab4cc70
};

// Class DiscoveryBrowserUI.FortActivityBrowserRowView
// Size: 0x670 (Inherited: 0x4e0)
struct UFortActivityBrowserRowView : UFortActivityBrowserView {
	char pad_4E0[0x8]; // 0x4e0(0x08)
	float MouseWheelScrollTimeThreshold; // 0x4e8(0x04)
	char pad_4EC[0x4]; // 0x4ec(0x04)
	struct UFortActivityBrowserListView* BrowserList_Activities; // 0x4f0(0x08)
	char pad_4F8[0x60]; // 0x4f8(0x60)
	struct FName TabNameID; // 0x558(0x04)
	char pad_55C[0x4]; // 0x55c(0x04)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x560(0xf0)
	struct UFortSwipePanel* SwipePanel_Navigation; // 0x650(0x08)
	char pad_658[0x18]; // 0x658(0x18)

	void OnRowChanged(int32_t NewCategoryIndex); // Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnRowChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnQueryActivitiesFinished(); // Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnQueryActivitiesFinished // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnActivityUpdated(); // Function DiscoveryBrowserUI.FortActivityBrowserRowView.OnActivityUpdated // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityBrowserTile
// Size: 0x1510 (Inherited: 0x14d0)
struct UFortActivityBrowserTile : UFortActivityBrowserTileBase {
	struct UFortActivityTileDetailsDisplay* Display_TileDetails; // 0x14d0(0x08)
	char pad_14D8[0x38]; // 0x14d8(0x38)

	void HandleActivitySelected(); // Function DiscoveryBrowserUI.FortActivityBrowserTile.HandleActivitySelected // (Final|Native|Private) // @ game+0xab4bff0
};

// Class DiscoveryBrowserUI.FortActivityPlayerBrowserView
// Size: 0x610 (Inherited: 0x4e0)
struct UFortActivityPlayerBrowserView : UFortActivityBrowserView {
	char pad_4E0[0x8]; // 0x4e0(0x08)
	struct UFortGameActivityProvider* ActivityProvider; // 0x4e8(0x08)
	struct UFortActivityTileView* TileView_PlayerActivities; // 0x4f0(0x08)
	struct FName TabNameID; // 0x4f8(0x04)
	char pad_4FC[0x4]; // 0x4fc(0x04)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x500(0xf0)
	enum class EFortCreativeDiscoveryPlayHistoryType PlayHistoryProviderType; // 0x5f0(0x01)
	char pad_5F1[0x1f]; // 0x5f1(0x1f)

	void PlayViewIntro(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.PlayViewIntro // (Final|Native|Public|BlueprintCallable) // @ game+0xab63760
	void OnQueryActivitiesStarted(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnQueryActivitiesStarted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnQueryActivitiesComplete(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnQueryActivitiesComplete // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayViewIntro(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.OnPlayViewIntro // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_OnTileViewUpdated(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserView.BP_OnTileViewUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityCategoryPageView
// Size: 0x650 (Inherited: 0x610)
struct UFortActivityCategoryPageView : UFortActivityPlayerBrowserView {
	char pad_610[0x8]; // 0x610(0x08)
	struct UCommonRichTextBlock* Text_CategoryTitle; // 0x618(0x08)
	struct UCommonButtonBase* Button_BackToTop; // 0x620(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x628(0x08)
	struct UCommonButtonBase* Button_MobileAccept; // 0x630(0x08)
	struct UCommonButtonBase* Button_Back; // 0x638(0x08)
	struct UCommonButtonBase* Button_MobileShowGameDetails; // 0x640(0x08)
	char pad_648[0x8]; // 0x648(0x08)
};

// Class DiscoveryBrowserUI.FortActivityTileViewTileBase
// Size: 0x1500 (Inherited: 0x1470)
struct UFortActivityTileViewTileBase : UCommonButtonBase {
	char pad_1470[0x90]; // 0x1470(0x90)
};

// Class DiscoveryBrowserUI.FortActivityCategoryTile
// Size: 0x1510 (Inherited: 0x1500)
struct UFortActivityCategoryTile : UFortActivityTileViewTileBase {
	struct UCommonTextBlock* Text_CategoryTitle; // 0x1500(0x08)
	char pad_1508[0x8]; // 0x1508(0x08)

	void OnTileActiveSet(bool bIsTileActive); // Function DiscoveryBrowserUI.FortActivityCategoryTile.OnTileActiveSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityCategoryTilePanel
// Size: 0x340 (Inherited: 0x2d0)
struct UFortActivityCategoryTilePanel : UCommonUserWidget {
	struct UFortActivityTileView* TileView_Categories; // 0x2d0(0x08)
	struct UCommonTextBlock* Text_Title; // 0x2d8(0x08)
	int32_t TileViewQueryThreshold; // 0x2e0(0x04)
	char pad_2E4[0x4]; // 0x2e4(0x04)
	struct UFortCreativeDiscoveryActivityProvider* CachedActivityProvider; // 0x2e8(0x08)
	char pad_2F0[0x50]; // 0x2f0(0x50)
};

// Class DiscoveryBrowserUI.FortActivityCategoryView
// Size: 0x600 (Inherited: 0x4e0)
struct UFortActivityCategoryView : UFortActivityBrowserView {
	char pad_4E0[0x8]; // 0x4e0(0x08)
	struct FName TabNameID; // 0x4e8(0x04)
	char pad_4EC[0x4]; // 0x4ec(0x04)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x4f0(0xf0)
	struct UFortActivityCategoryTilePanel* TilePanel_Featured; // 0x5e0(0x08)
	struct UFortActivityCategoryTilePanel* TilePanel_All; // 0x5e8(0x08)
	struct UFortActivityCategoryTilePanel* CurrentSelectedPanel; // 0x5f0(0x08)
	char pad_5F8[0x8]; // 0x5f8(0x08)

	void OnSurfaceDataReady(); // Function DiscoveryBrowserUI.FortActivityCategoryView.OnSurfaceDataReady // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnCategoryTilePanelSelected(struct UFortActivityCategoryTilePanel* SelectedPanel); // Function DiscoveryBrowserUI.FortActivityCategoryView.OnCategoryTilePanelSelected // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	struct UFortActivityCategoryTilePanel* NavigateFromPanel(enum class EUINavigation Direction, struct UFortActivityCategoryTilePanel* NavigatingPanel); // Function DiscoveryBrowserUI.FortActivityCategoryView.NavigateFromPanel // (Final|Native|Protected|BlueprintCallable) // @ game+0xab50770
	struct UFortActivityCategoryTilePanel* GetTopMostVisiblePanel(); // Function DiscoveryBrowserUI.FortActivityCategoryView.GetTopMostVisiblePanel // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x866f570
	struct UFortActivityCategoryTilePanel* GetCurrentSelectedPanel(); // Function DiscoveryBrowserUI.FortActivityCategoryView.GetCurrentSelectedPanel // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x7e06240
};

// Class DiscoveryBrowserUI.FortActivityCreateView
// Size: 0x600 (Inherited: 0x4e0)
struct UFortActivityCreateView : UFortActivityBrowserView {
	char pad_4E0[0x8]; // 0x4e0(0x08)
	struct FName TabNameID; // 0x4e8(0x04)
	char pad_4EC[0x4]; // 0x4ec(0x04)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x4f0(0xf0)
	struct UCommonButtonBase* Button_Create; // 0x5e0(0x08)
	char pad_5E8[0x18]; // 0x5e8(0x18)

	void OnCreativeActivityUpdated(); // Function DiscoveryBrowserUI.FortActivityCreateView.OnCreativeActivityUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	enum class EFortInvalidActivityReason GetInvalidCreativeActivityReason(); // Function DiscoveryBrowserUI.FortActivityCreateView.GetInvalidCreativeActivityReason // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab51610
};

// Class DiscoveryBrowserUI.FortActivityCreatorPageView
// Size: 0x6e0 (Inherited: 0x650)
struct UFortActivityCreatorPageView : UFortActivityCategoryPageView {
	char pad_650[0x8]; // 0x650(0x08)
	struct UFortGameActivity* ActivityDetailsSelectedGameActivity; // 0x658(0x08)
	char pad_660[0x20]; // 0x660(0x20)
	int32_t AmountOfCreatorLinkEntriesQueried; // 0x680(0x04)
	int32_t ProcessedCreatorLinkEntries; // 0x684(0x04)
	int32_t AmountOfEntriesQueried; // 0x688(0x04)
	char pad_68C[0x54]; // 0x68c(0x54)

	void OnNoContentFoundForCreator(); // Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnNoContentFoundForCreator // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnCreatorActivitiesQueryFinished(); // Function DiscoveryBrowserUI.FortActivityCreatorPageView.OnCreatorActivitiesQueryFinished // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityDiscoverView
// Size: 0x710 (Inherited: 0x670)
struct UFortActivityDiscoverView : UFortActivityBrowserRowView {
	bool bPlayDetailsAnimationOnScreenOpen; // 0x670(0x01)
	char pad_671[0x3]; // 0x671(0x03)
	float DetailsDisplayUpdateDelay; // 0x674(0x04)
	struct UFortActivatableMovieWidget* MovieWidgetClass; // 0x678(0x08)
	struct UFortActivityDetailsDisplay* DetailsDisplay_SelectedActivity; // 0x680(0x08)
	struct UFortActivityDetailsDisplay* DetailsDisplay_PromotedActivity; // 0x688(0x08)
	struct UPanelWidget* Panel_VideoSlot; // 0x690(0x08)
	struct UPanelWidget* Panel_PromotedVideoSlot; // 0x698(0x08)
	struct UFortActivatableMovieWidget* ActivityMovieWidget; // 0x6a0(0x08)
	struct UFortActivatableMovieWidget* PromotedActivityMovieWidget; // 0x6a8(0x08)
	char pad_6B0[0x48]; // 0x6b0(0x48)
	struct UWidgetAnimation* BoundKeyArtOutroAnimation; // 0x6f8(0x08)
	char pad_700[0x10]; // 0x700(0x10)

	void OnUpdateDetailsDisplay(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnUpdateDetailsDisplay // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPreviewImageChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayKeyArtOutro(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtOutro // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayKeyArtIntro(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnPlayKeyArtIntro // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnMoviePreEndEvent(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePreEndEvent // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnMoviePlayingChanged(bool bIsPlaying); // Function DiscoveryBrowserUI.FortActivityDiscoverView.OnMoviePlayingChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool IsShowingSeasonalContent(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingSeasonalContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab549c0
	bool IsShowingPromotedContent(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.IsShowingPromotedContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab54a00
	bool IsInOutroState(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.IsInOutroState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab54960
	bool IsImageLoading(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.IsImageLoading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab54980
	void HandleMovieWidgetMediaStarted(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaStarted // (Final|Native|Private) // @ game+0xab548c0
	void HandleMovieWidgetMediaPreEndEvent(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.HandleMovieWidgetMediaPreEndEvent // (Final|Native|Private) // @ game+0xab54870
	struct UFortActivatableMovieWidget* GetPromotedMovieWidget(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.GetPromotedMovieWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x39c6290
	struct UFortActivatableMovieWidget* GetMovieWidget(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.GetMovieWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab549a0
	struct UWidgetAnimation* GetKeyArtOutroAnimation(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.GetKeyArtOutroAnimation // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xab54930
	struct UTexture* GetCurrentTexture(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.GetCurrentTexture // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0xab54900
	void CheckUpdateDetailsDelay(); // Function DiscoveryBrowserUI.FortActivityDiscoverView.CheckUpdateDetailsDelay // (Final|Native|Private) // @ game+0xab548e0
};

// Class DiscoveryBrowserUI.FortActivityDiscoverViewV2
// Size: 0x6c0 (Inherited: 0x670)
struct UFortActivityDiscoverViewV2 : UFortActivityBrowserRowView {
	char pad_670[0x30]; // 0x670(0x30)
	struct UFortActivitySelector* ActivitySelector; // 0x6a0(0x08)
	struct UFortActivityDetailsModal* ActivityDetailsModalClass; // 0x6a8(0x08)
	struct UFortActivityCreatorPageView* ActivityCreatorPageViewClass; // 0x6b0(0x08)
	char pad_6B8[0x8]; // 0x6b8(0x08)

	bool IsShowingSeasonalContent(); // Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingSeasonalContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab549c0
	bool IsShowingPromotedContent(); // Function DiscoveryBrowserUI.FortActivityDiscoverViewV2.IsShowingPromotedContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab54a00
};

// Class DiscoveryBrowserUI.FortActivityFavoriteBrowserView
// Size: 0x610 (Inherited: 0x610)
struct UFortActivityFavoriteBrowserView : UFortActivityPlayerBrowserView {
};

// Class DiscoveryBrowserUI.FortActivityListItemWrapper
// Size: 0x40 (Inherited: 0x28)
struct UFortActivityListItemWrapper : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct UFortGameActivity* GameActivity; // 0x38(0x08)
};

// Class DiscoveryBrowserUI.FortActivityListView
// Size: 0x418 (Inherited: 0x290)
struct UFortActivityListView : UListViewBase {
	char pad_290[0xe8]; // 0x290(0xe8)
	float DirectionalNavigationTimeThreshold; // 0x378(0x04)
	enum class EOrientation Orientation; // 0x37c(0x01)
	char pad_37D[0x3]; // 0x37d(0x03)
	float EntrySpacing; // 0x380(0x04)
	bool bCircularNavigationEnabled; // 0x384(0x01)
	char pad_385[0x3]; // 0x385(0x03)
	struct TMap<enum class EActivityBrowserTileStyle, struct UFortActivityBrowserTileBase*> TileTypes; // 0x388(0x50)
	char pad_3D8[0x40]; // 0x3d8(0x40)

	int32_t GetInViewCount(); // Function DiscoveryBrowserUI.FortActivityListView.GetInViewCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab59de0
};

// Class DiscoveryBrowserUI.FortActivityLobbyTile
// Size: 0x1530 (Inherited: 0x14c0)
struct UFortActivityLobbyTile : UCommonButtonLegacy {
	struct UCommonTextBlock* Text_ActivityName; // 0x14c0(0x08)
	struct UFortActivityBrowserTag* ActivityBrowserTag_EpicOriginal; // 0x14c8(0x08)
	struct UFortActivityModeSetSelectionModal* ActivityModeSetSelectionModalClass; // 0x14d0(0x08)
	struct UFortGameActivityProvider* ActivityProvider; // 0x14d8(0x08)
	struct TArray<struct UFortGameActivity*> CachedQueriedActivities; // 0x14e0(0x10)
	char pad_14F0[0x40]; // 0x14f0(0x40)

	void TrySendFirstTimeNotification(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.TrySendFirstTimeNotification // (Final|Native|Public|BlueprintCallable) // @ game+0xab5ae90
	void ShowModeSetSelectionModal(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.ShowModeSetSelectionModal // (Final|Native|Public|BlueprintCallable) // @ game+0xab5aeb0
	void OnShowChildActivityFirstTimeNotification(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityFirstTimeNotification // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnShowChildActivityChangedNotification(struct FText& DisplayName); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnShowChildActivityChangedNotification // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnHideChildActivityFirstTimeNotification(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnHideChildActivityFirstTimeNotification // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnDetailsUpdated(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.OnDetailsUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool IsModeSetActivity(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.IsModeSetActivity // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab5afd0
	bool IsActivityEpicCreated(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.IsActivityEpicCreated // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab5b040
	struct FText GetChildActivityDisplayName(); // Function DiscoveryBrowserUI.FortActivityLobbyTile.GetChildActivityDisplayName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab5aed0
};

// Class DiscoveryBrowserUI.FortActivityModeSetSelectionModal
// Size: 0x468 (Inherited: 0x3e8)
struct UFortActivityModeSetSelectionModal : UCommonActivatableWidget {
	struct UCommonTextBlock* Text_ActivityName; // 0x3e8(0x08)
	char pad_3F0[0x40]; // 0x3f0(0x40)
	struct UCommonButtonBase* Button_Back; // 0x430(0x08)
	struct UCommonButtonBase* Button_BackBoard; // 0x438(0x08)
	struct UFortActivityModeSetSelection* List_SubModeList; // 0x440(0x08)
	struct UFortActivitySquadFillButton* Button_ActivitySquadFill; // 0x448(0x08)
	struct UFortActivityPrivacyButton* Button_ActivityPrivacy; // 0x450(0x08)
	struct UFortActivityHabaneroButton* Button_Activity_Habanero; // 0x458(0x08)
	char pad_460[0x8]; // 0x460(0x08)

	void SetIsRankedSwitchAvailable(bool bIsRankedSwitchAvailable); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.SetIsRankedSwitchAvailable // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetHabaneroValues(bool bHabaneroEnabled, bool bHabaneroExists); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.SetHabaneroValues // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SaveSelectionAndClose(); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.SaveSelectionAndClose // (Final|Native|Protected|BlueprintCallable) // @ game+0xab60c80
	void OnSubModeSelectionChanged(); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSubModeSelected(); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnSubModeSelected // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnActivityChanged(struct UFortGameActivity* GameActivity, struct FString StartingSelectedMnemonic); // Function DiscoveryBrowserUI.FortActivityModeSetSelectionModal.OnActivityChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityPlayerBrowserTile
// Size: 0x1550 (Inherited: 0x1500)
struct UFortActivityPlayerBrowserTile : UFortActivityTileViewTileBase {
	struct UFortActivityTileDetailsDisplay* Display_TileDetails; // 0x1500(0x08)
	struct UCommonTextBlock* Text_LastPlayedDate; // 0x1508(0x08)
	char pad_1510[0x40]; // 0x1510(0x40)

	void HandleActivitySelected(); // Function DiscoveryBrowserUI.FortActivityPlayerBrowserTile.HandleActivitySelected // (Final|Native|Private) // @ game+0xab62e10
};

// Class DiscoveryBrowserUI.FortActivityPlayerView
// Size: 0x620 (Inherited: 0x4e0)
struct UFortActivityPlayerView : UFortActivityBrowserView {
	char pad_4E0[0x8]; // 0x4e0(0x08)
	struct FName TabNameID; // 0x4e8(0x04)
	char pad_4EC[0x4]; // 0x4ec(0x04)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x4f0(0xf0)
	struct UCommonButtonBase* TabButtonClass; // 0x5e0(0x08)
	struct UFortTabListWidgetBase_Legacy* TabList_PlayerViewTabs; // 0x5e8(0x08)
	struct UCommonActivatableWidgetSwitcher* Switcher_PlayerBrowserViews; // 0x5f0(0x08)
	struct UFortActivityPlayerBrowserView* BrowserView_Favorites; // 0x5f8(0x08)
	struct UFortActivityPlayerBrowserView* BrowserView_History; // 0x600(0x08)
	char pad_608[0x18]; // 0x608(0x18)
};

// Class DiscoveryBrowserUI.FortActivityPlayerViewTabButton
// Size: 0x14a0 (Inherited: 0x14a0)
struct UFortActivityPlayerViewTabButton : UFortTabButton {
	struct UCommonTextBlock* Text_Count; // 0x1498(0x08)
};

// Class DiscoveryBrowserUI.FortActivitySearchView
// Size: 0x640 (Inherited: 0x4e0)
struct UFortActivitySearchView : UFortActivityBrowserView {
	char pad_4E0[0x8]; // 0x4e0(0x08)
	struct FName TabNameID; // 0x4e8(0x04)
	char pad_4EC[0x4]; // 0x4ec(0x04)
	struct FFortTabButtonLabelInfo TabButtonLabelInfo; // 0x4f0(0xf0)
	struct UEditableText* EditableText_IslandLink; // 0x5e0(0x08)
	char pad_5E8[0x58]; // 0x5e8(0x58)

	void OnActivityValidated(enum class EFortActivityValidationResult ValidateResult); // Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityValidated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnActivityClear(); // Function DiscoveryBrowserUI.FortActivitySearchView.OnActivityClear // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandleTextCommitted(struct FText& InText, enum class ETextCommit CommitInfo); // Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextCommitted // (Final|Native|Private|HasOutParms) // @ game+0xab66a10
	void HandleTextChanged(struct FText& Text); // Function DiscoveryBrowserUI.FortActivitySearchView.HandleTextChanged // (Final|Native|Private|HasOutParms) // @ game+0xab668c0
};

// Class DiscoveryBrowserUI.FortActivitySeasonalBrowserView
// Size: 0x610 (Inherited: 0x610)
struct UFortActivitySeasonalBrowserView : UFortActivityPlayerBrowserView {
};

// Class DiscoveryBrowserUI.FortActivitySelector
// Size: 0xd0 (Inherited: 0x28)
struct UFortActivitySelector : UObject {
	char pad_28[0x18]; // 0x28(0x18)
	struct UFortGameActivity* SelectedGameActivity; // 0x40(0x08)
	char pad_48[0x8]; // 0x48(0x08)
	struct TMap<struct FName, struct UFortActivityBrowserColorSchemeAsset*> ColorSchemes; // 0x50(0x50)
	struct UFortActivityBrowserColorSchemeAsset* CurrentColorScheme; // 0xa0(0x08)
	char pad_A8[0x20]; // 0xa8(0x20)
	struct UFortActivityCreatorPageView* CachedCreatorPageView; // 0xc8(0x08)

	void OnSwapColorScheme(bool bInIsUsingAlternateColorScheme); // Function DiscoveryBrowserUI.FortActivitySelector.OnSwapColorScheme // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEnableColorScheme(bool bIsColorSchemeActive); // Function DiscoveryBrowserUI.FortActivitySelector.OnEnableColorScheme // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class DiscoveryBrowserUI.FortActivityTileDetailsDisplay
// Size: 0x15b0 (Inherited: 0x1470)
struct UFortActivityTileDetailsDisplay : UCommonButtonBase {
	struct FMulticastInlineDelegate OnActivitySelectedDelegate; // 0x1470(0x10)
	struct FMulticastInlineDelegate OnActivityUnSelectedDelegate; // 0x1480(0x10)
	bool bShowDetailsButton; // 0x1490(0x01)
	char pad_1491[0x3]; // 0x1491(0x03)
	int32_t DefaultColumnSize; // 0x1494(0x04)
	struct UCommonTextBlock* Text_ActivityName; // 0x1498(0x08)
	struct UCommonTextBlock* Text_PlayerCount; // 0x14a0(0x08)
	struct UCommonButtonBase* Button_Favorite; // 0x14a8(0x08)
	struct UCommonButtonBase* Button_Details; // 0x14b0(0x08)
	struct UFortActivityBrowserTag* ActivityBrowserTag_EpicOriginal; // 0x14b8(0x08)
	struct UTextBlock* Text_DebugId; // 0x14c0(0x08)
	struct UFortSqueegeeWidgetInjectionSlot* SqueegeeInjectionSlot; // 0x14c8(0x08)
	struct UFortActivityVideoCycle* ActivityVideoCycleWidget; // 0x14d0(0x08)
	struct TMap<uint32_t, enum class ECreativeLinkPreviewSize> MinColumnSizeToImageSize; // 0x14d8(0x50)
	char MaxMobileColumnSize; // 0x1528(0x01)
	char MinMobileColumnSize; // 0x1529(0x01)
	bool bIsVideoEnabledForDynamicTileSizingV2; // 0x152a(0x01)
	char pad_152B[0x85]; // 0x152b(0x85)

	void UpdateCCU(int32_t CCUCount); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.UpdateCCU // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void StopTileVideo(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.StopTileVideo // (Final|Native|Protected|BlueprintCallable) // @ game+0xab6b0a0
	void StartTileVideo(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.StartTileVideo // (Final|Native|Protected|BlueprintCallable) // @ game+0xab6b1c0
	void ShouldPlayTileVideo(bool& bOutResult); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.ShouldPlayTileVideo // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x1b027f0
	void OnUpdateColumnSize(int32_t NewColumnSize); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnUpdateColumnSize // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnTileActiveSet(bool bIsTileActive); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnTileActiveSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRequiresPurchaseChanged(bool bRequiresPurchase); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnRequiresPurchaseChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPartySizeChanged(int32_t PartySize); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnPartySizeChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnLogoImageChanged(bool bIsLoading, struct UTexture* Texture); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLogoImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnLocalPlayerPromotedToLeader(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerPromotedToLeader // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnLocalPlayerDemoted(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnLocalPlayerDemoted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnIsFavoriteChanged(bool bIsFavorite); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnIsFavoriteChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnFriendsPlayingChanged(int32_t NumPlaying); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnFriendsPlayingChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnDetailsUpdated(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnDetailsUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnActivityUnSelected__DelegateSignature(); // DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivityUnSelected__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnActivitySelected__DelegateSignature(); // DelegateFunction DiscoveryBrowserUI.FortActivityTileDetailsDisplay.OnActivitySelected__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	bool IsModeSetActivity(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsModeSetActivity // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab6b1e0
	bool IsActivityLocked(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityLocked // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab6b470
	bool IsActivityFavorited(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.IsActivityFavorited // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab6b2b0
	enum class EFortInvalidActivityReason GetInvalidActivityReason(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.GetInvalidActivityReason // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab6b000
	struct FString GetActivityCreatorDisplayText(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.GetActivityCreatorDisplayText // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab6b300
	bool DoesActivityRequirePurchase(); // Function DiscoveryBrowserUI.FortActivityTileDetailsDisplay.DoesActivityRequirePurchase // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab6b230
};

// Class DiscoveryBrowserUI.FortActivityTileView
// Size: 0xc00 (Inherited: 0xc00)
struct UFortActivityTileView : UCommonTileView {

	void SetListenForMouseWheelInput(bool bListenForInput); // Function DiscoveryBrowserUI.FortActivityTileView.SetListenForMouseWheelInput // (Final|Native|Public|BlueprintCallable) // @ game+0xab6d960
};

// Class DiscoveryBrowserUI.FortDiscoverItemBrowserRow
// Size: 0x3e0 (Inherited: 0x390)
struct UFortDiscoverItemBrowserRow : UFortActivityBrowserRow {
	struct UFortDiscoverItemListView* ListView_Tiles; // 0x390(0x08)
	struct UCommonButtonBase* Button_PageLeft; // 0x398(0x08)
	struct UCommonButtonBase* Button_PageRight; // 0x3a0(0x08)
	char pad_3A8[0x38]; // 0x3a8(0x38)
};

// Class DiscoveryBrowserUI.FortDiscoverItemListView
// Size: 0x3d0 (Inherited: 0x290)
struct UFortDiscoverItemListView : UListViewBase {
	char pad_290[0xe8]; // 0x290(0xe8)
	float DirectionalNavigationTimeThreshold; // 0x378(0x04)
	char pad_37C[0x4]; // 0x37c(0x04)
	struct UFortActivityBrowserPlayWithFriendsTile* PlayWithFriendsEntryWidgetClass; // 0x380(0x08)
	enum class EOrientation Orientation; // 0x388(0x01)
	char pad_389[0x3]; // 0x389(0x03)
	float EntrySpacing; // 0x38c(0x04)
	bool bCircularNavigationEnabled; // 0x390(0x01)
	char pad_391[0x3f]; // 0x391(0x3f)

	int32_t GetInViewCount(); // Function DiscoveryBrowserUI.FortDiscoverItemListView.GetInViewCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab6ff80
};

// Class DiscoveryBrowserUI.ActivityLibraryComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UActivityLibraryComponent : UActorComponent {
	char pad_A0[0x10]; // 0xa0(0x10)
};

// Class DiscoveryBrowserUI.FortActivityBrowserContext
// Size: 0x48 (Inherited: 0x30)
struct UFortActivityBrowserContext : UGameInstanceSubsystem {
	char pad_30[0x18]; // 0x30(0x18)
};

// Class DiscoveryBrowserUI.OverrideMatchmakingUIComponent
// Size: 0x100 (Inherited: 0xa0)
struct UOverrideMatchmakingUIComponent : UActorComponent {
	struct FMatchmakingUIOverride MatchmakingUIOverride; // 0xa0(0x60)
};

