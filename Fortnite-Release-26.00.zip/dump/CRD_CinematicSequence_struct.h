// Enum CRD_CinematicSequence.ECinematicSequenceVisibility
enum class ECinematicSequenceVisibility : uint8 {
	InstigatorOnly = 0,
	InstigatingTeam = 1,
	Everyone = 2,
	ECinematicSequenceVisibility_MAX = 3
};

