// Class GameHubRuntime.GameHubBaseMutator
// Size: 0x348 (Inherited: 0x338)
struct AGameHubBaseMutator : AFortAthenaMutator {
	char pad_338[0x10]; // 0x338(0x10)
};

// Class GameHubRuntime.GameHubPlayerSpawningComponent
// Size: 0xd0 (Inherited: 0xb0)
struct UGameHubPlayerSpawningComponent : UPlayspaceComponent_PlayerSpawning {
	struct FGameplayTagContainer PlayerStartRequirements; // 0xb0(0x20)
};

// Class GameHubRuntime.GameHubPlayspace
// Size: 0x6c0 (Inherited: 0x698)
struct AGameHubPlayspace : AFortPlayspace {
	bool bSimulatePlayerDamage; // 0x698(0x01)
	char pad_699[0x7]; // 0x699(0x07)
	struct FGameplayTagContainer PlayerStartRequirements; // 0x6a0(0x20)
};

