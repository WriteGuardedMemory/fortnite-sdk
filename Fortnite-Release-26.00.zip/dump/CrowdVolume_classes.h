// Class CrowdVolume.CrowdSpawner
// Size: 0x2e0 (Inherited: 0x2a0)
struct UCrowdSpawner : USceneComponent {
	char pad_2A0[0x40]; // 0x2a0(0x40)

	void SpawnCrowd(int32_t Width, int32_t Depth, int32_t Height, int32_t Precision, int32_t CharacterScaleRandomness, int32_t CharacterAngleRandomness, int32_t Density); // Function CrowdVolume.CrowdSpawner.SpawnCrowd // (Final|Native|Public|BlueprintCallable) // @ game+0xaa9e730
	void RefreshTrackedActors(struct UPlayspaceComponent_SpatialActorTracker* InPlaySpaceComponent_SpatialActorTracker); // Function CrowdVolume.CrowdSpawner.RefreshTrackedActors // (Final|Native|Public|BlueprintCallable) // @ game+0xaa0ad70
};

