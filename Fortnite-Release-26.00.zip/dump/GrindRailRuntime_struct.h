// Enum GrindRailRuntime.EGrindRailBoosterMode
enum class EGrindRailBoosterMode : uint8 {
	SpeedUp = 0,
	SlowDown = 1,
	NoEffect = 2,
	EGrindRailBoosterMode_MAX = 3
};

// ScriptStruct GrindRailRuntime.FortAnimInput_GrindRail
// Size: 0x18 (Inherited: 0x00)
struct FFortAnimInput_GrindRail {
	char bAimFWD : 1; // 0x00(0x01)
	char bAimBWD : 1; // 0x00(0x01)
	char bAimLFT : 1; // 0x00(0x01)
	char bAimRGT : 1; // 0x00(0x01)
	char pad_0_4 : 4; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float AimFWDDeltaAngleDegrees; // 0x04(0x04)
	float AimBWDDeltaAngleDegrees; // 0x08(0x04)
	float AimLFTDeltaAngleDegrees; // 0x0c(0x04)
	float AimRGTDeltaAngleDegrees; // 0x10(0x04)
	float PawnToSplineDeltaYawAngleDegrees; // 0x14(0x04)
};

// ScriptStruct GrindRailRuntime.FortAnimNode_GrindRailSlopeWarping
// Size: 0x340 (Inherited: 0x2e8)
struct FFortAnimNode_GrindRailSlopeWarping : FFortAnimNode_SlopeWarping {
	float BaseSplineRadius; // 0x2e8(0x04)
	char bAbsentCurveMeansFootDown : 1; // 0x2ec(0x01)
	char pad_2EC_1 : 7; // 0x2ec(0x01)
	char pad_2ED[0x3]; // 0x2ed(0x03)
	struct FName LFootOnGroundCurveName; // 0x2f0(0x04)
	char bLeftCurveHighMeansFootDown : 1; // 0x2f4(0x01)
	char pad_2F4_1 : 7; // 0x2f4(0x01)
	char pad_2F5[0x3]; // 0x2f5(0x03)
	struct FName RFootOnGroundCurveName; // 0x2f8(0x04)
	char bRightCurveHighMeansFootDown : 1; // 0x2fc(0x01)
	char pad_2FC_1 : 7; // 0x2fc(0x01)
	char pad_2FD[0x3]; // 0x2fd(0x03)
	struct FBoneReference LeftFootFKBone; // 0x300(0x0c)
	char pad_30C[0x34]; // 0x30c(0x34)
};

// ScriptStruct GrindRailRuntime.GrindRailBoosterInfo
// Size: 0x0c (Inherited: 0x00)
struct FGrindRailBoosterInfo {
	float MinDistanceAlongSpline; // 0x00(0x04)
	float MaxDistanceAlongSpline; // 0x04(0x04)
	enum class EGrindRailBoosterMode PositiveMode; // 0x08(0x01)
	enum class EGrindRailBoosterMode NegativeMode; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
};

// ScriptStruct GrindRailRuntime.FortRailPointSnapData
// Size: 0x10 (Inherited: 0x00)
struct FFortRailPointSnapData {
	struct AFortGrindRail* RailToSnapTo; // 0x00(0x08)
	int32_t PointToSnapTo; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct GrindRailRuntime.GrindRailSpeedSettings
// Size: 0x18 (Inherited: 0x00)
struct FGrindRailSpeedSettings {
	float SprintAcceleration; // 0x00(0x04)
	float MaxLeanAcceleration; // 0x04(0x04)
	float MinLeanAcceleration; // 0x08(0x04)
	float ShootingSpeedMultiplier; // 0x0c(0x04)
	float GravityForceWhenGoingUp; // 0x10(0x04)
	float GravityForceWhenGoingDown; // 0x14(0x04)
};

// ScriptStruct GrindRailRuntime.GrindRailStatus
// Size: 0x10 (Inherited: 0x00)
struct FGrindRailStatus {
	struct TWeakObjectPtr<struct AFortGrindRail> GrindingRail; // 0x00(0x08)
	float CurrentSpeedAlongSpline; // 0x08(0x04)
	float CurrentDistanceAlongSpline; // 0x0c(0x04)
};

