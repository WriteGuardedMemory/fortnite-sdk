// Class MetasoundEngine.MetasoundGeneratorHandle
// Size: 0xe0 (Inherited: 0x28)
struct UMetasoundGeneratorHandle : UObject {
	char pad_28[0xb8]; // 0x28(0xb8)

	bool WatchOutput(struct FName OutputName, struct FDelegate& OnOutputValueChanged, struct FName AnalyzerName, struct FName AnalyzerOutputName); // Function MetasoundEngine.MetasoundGeneratorHandle.WatchOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6932f70
	void OnOutputValueChangedMulticast__DelegateSignature(struct FName Name, struct FMetaSoundOutput& Output); // DelegateFunction MetasoundEngine.MetasoundGeneratorHandle.OnOutputValueChangedMulticast__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x1b027f0
	struct UMetasoundGeneratorHandle* CreateMetaSoundGeneratorHandle(struct UAudioComponent* OnComponent); // Function MetasoundEngine.MetasoundGeneratorHandle.CreateMetaSoundGeneratorHandle // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6933540
	bool ApplyParameterPack(struct UMetasoundParameterPack* pack); // Function MetasoundEngine.MetasoundGeneratorHandle.ApplyParameterPack // (Final|Native|Public|BlueprintCallable) // @ game+0x6933260
};

// Class MetasoundEngine.MetasoundOutputBlueprintAccess
// Size: 0x28 (Inherited: 0x28)
struct UMetasoundOutputBlueprintAccess : UBlueprintFunctionLibrary {

	bool IsTime(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsTime // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6933be0
	bool IsString(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsString // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6933f30
	bool IsInt32(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsInt32 // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x69344f0
	bool IsFloat(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsFloat // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x69347e0
	bool IsBool(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsBool // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6934210
	float GetTimeSeconds(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetTimeSeconds // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6933a00
	struct FString GetString(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetString // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6933cf0
	int32_t GetInt32(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetInt32 // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6934320
	float GetFloat(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetFloat // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6934600
	bool GetBool(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetBool // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6934040
};

// Class MetasoundEngine.MetaSoundOutputSubsystem
// Size: 0x50 (Inherited: 0x40)
struct UMetaSoundOutputSubsystem : UTickableWorldSubsystem {
	struct TArray<struct UMetasoundGeneratorHandle*> TrackedGenerators; // 0x40(0x10)

	bool WatchOutput(struct UAudioComponent* AudioComponent, struct FName OutputName, struct FDelegate& OnOutputValueChanged, struct FName AnalyzerName, struct FName AnalyzerOutputName); // Function MetasoundEngine.MetaSoundOutputSubsystem.WatchOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6934be0
};

// Class MetasoundEngine.MetaSoundSettings
// Size: 0x78 (Inherited: 0x30)
struct UMetaSoundSettings : UDeveloperSettings {
	bool bAutoUpdateEnabled; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct FMetasoundFrontendClassName> AutoUpdateDenylist; // 0x38(0x10)
	struct TArray<struct FDefaultMetaSoundAssetAutoUpdateSettings> AutoUpdateAssetDenylist; // 0x48(0x10)
	bool bAutoUpdateLogWarningOnDroppedConnection; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct TArray<struct FDirectoryPath> DirectoriesToRegister; // 0x60(0x10)
	int32_t DenyListCacheChangeID; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class MetasoundEngine.MetasoundEditorGraphBase
// Size: 0x60 (Inherited: 0x60)
struct UMetasoundEditorGraphBase : UEdGraph {
};

// Class MetasoundEngine.MetaSoundPatch
// Size: 0x350 (Inherited: 0x28)
struct UMetaSoundPatch : UObject {
	char pad_28[0x70]; // 0x28(0x70)
	struct FMetasoundFrontendDocument RootMetaSoundDocument; // 0x98(0x1b8)
	struct TSet<struct FString> ReferencedAssetClassKeys; // 0x250(0x50)
	struct TSet<struct UObject*> ReferencedAssetClassObjects; // 0x2a0(0x50)
	struct TSet<struct FSoftObjectPath> ReferenceAssetClassCache; // 0x2f0(0x50)
	struct FGuid AssetClassID; // 0x340(0x10)
};

// Class MetasoundEngine.MetaSoundAssetSubsystem
// Size: 0x1e0 (Inherited: 0x30)
struct UMetaSoundAssetSubsystem : UEngineSubsystem {
	char pad_30[0x8]; // 0x30(0x08)
	struct TArray<struct FMetaSoundAsyncAssetDependencies> LoadingDependencies; // 0x38(0x10)
	char pad_48[0x198]; // 0x48(0x198)

	void UnregisterAssetClassesInDirectories(struct TArray<struct FMetaSoundAssetDirectory>& Directories); // Function MetasoundEngine.MetaSoundAssetSubsystem.UnregisterAssetClassesInDirectories // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69432c0
	void RegisterAssetClassesInDirectories(struct TArray<struct FMetaSoundAssetDirectory>& Directories); // Function MetasoundEngine.MetaSoundAssetSubsystem.RegisterAssetClassesInDirectories // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6943540
};

// Class MetasoundEngine.MetaSoundBuilderBase
// Size: 0x60 (Inherited: 0x28)
struct UMetaSoundBuilderBase : UObject {
	struct FMetaSoundFrontendDocumentBuilder Builder; // 0x28(0x30)
	bool bIsAttached; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)

	void SetNodeInputDefault(struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, struct FMetasoundFrontendLiteral& Literal, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.SetNodeInputDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6948b80
	void SetGraphInputDefault(struct FName InputName, struct FMetasoundFrontendLiteral& Literal, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.SetGraphInputDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6948810
	void RemoveNodeInputDefault(struct FMetaSoundBuilderNodeInputHandle& InputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveNodeInputDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6948f20
	void RemoveNode(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69490e0
	void RemoveInterface(struct FName InterfaceName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveInterface // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69492a0
	void RemoveGraphOutput(struct FName Name, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveGraphOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6949430
	void RemoveGraphInput(struct FName Name, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveGraphInput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69495c0
	bool NodesAreConnected(struct FMetaSoundBuilderNodeOutputHandle& OutputHandle, struct FMetaSoundBuilderNodeInputHandle& InputHandle); // Function MetasoundEngine.MetaSoundBuilderBase.NodesAreConnected // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6949ca0
	bool NodeOutputIsConnected(struct FMetaSoundBuilderNodeOutputHandle& OutputHandle); // Function MetasoundEngine.MetaSoundBuilderBase.NodeOutputIsConnected // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6949a40
	bool NodeInputIsConnected(struct FMetaSoundBuilderNodeInputHandle& InputHandle); // Function MetasoundEngine.MetaSoundBuilderBase.NodeInputIsConnected // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6949b70
	bool IsPreset(); // Function MetasoundEngine.MetaSoundBuilderBase.IsPreset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6949a00
	bool InterfaceIsDeclared(struct FName InterfaceName); // Function MetasoundEngine.MetaSoundBuilderBase.InterfaceIsDeclared // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6949ea0
	struct UObject* GetReferencedPresetAsset(); // Function MetasoundEngine.MetaSoundBuilderBase.GetReferencedPresetAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6949f90
	void GetNodeOutputData(struct FMetaSoundBuilderNodeOutputHandle& OutputHandle, struct FName& Name, struct FName& DataType, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.GetNodeOutputData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6949fc0
	struct FMetasoundFrontendLiteral GetNodeInputDefault(struct FMetaSoundBuilderNodeInputHandle& InputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.GetNodeInputDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694a630
	void GetNodeInputData(struct FMetaSoundBuilderNodeInputHandle& InputHandle, struct FName& Name, struct FName& DataType, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.GetNodeInputData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694a960
	struct FMetasoundFrontendLiteral GetNodeInputClassDefault(struct FMetaSoundBuilderNodeInputHandle& InputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.GetNodeInputClassDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694a300
	struct TArray<struct FMetaSoundBuilderNodeOutputHandle> FindNodeOutputsByDataType(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult, struct FName DataType); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeOutputsByDataType // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694b460
	struct TArray<struct FMetaSoundBuilderNodeOutputHandle> FindNodeOutputs(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeOutputs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694b720
	struct FMetaSoundNodeHandle FindNodeOutputParent(struct FMetaSoundBuilderNodeOutputHandle& OutputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeOutputParent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694aec0
	struct FMetaSoundBuilderNodeOutputHandle FindNodeOutputByName(struct FMetaSoundNodeHandle& NodeHandle, struct FName OutputName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeOutputByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694b970
	struct TArray<struct FMetaSoundBuilderNodeInputHandle> FindNodeInputsByDataType(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult, struct FName DataType); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeInputsByDataType // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694bbb0
	struct TArray<struct FMetaSoundBuilderNodeInputHandle> FindNodeInputs(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeInputs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694be70
	struct FMetaSoundNodeHandle FindNodeInputParent(struct FMetaSoundBuilderNodeInputHandle& InputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeInputParent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694aec0
	struct FMetaSoundBuilderNodeInputHandle FindNodeInputByName(struct FMetaSoundNodeHandle& NodeHandle, struct FName InputName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeInputByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694c0c0
	struct FMetasoundFrontendVersion FindNodeClassVersion(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeClassVersion // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694aca0
	struct TArray<struct FMetaSoundNodeHandle> FindInterfaceOutputNodes(struct FName InterfaceName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindInterfaceOutputNodes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694b0a0
	struct TArray<struct FMetaSoundNodeHandle> FindInterfaceInputNodes(struct FName InterfaceName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindInterfaceInputNodes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694b280
	struct FMetaSoundNodeHandle FindGraphOutputNode(struct FName OutputName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindGraphOutputNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694c300
	struct FMetaSoundNodeHandle FindGraphInputNode(struct FName InputName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindGraphInputNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694c490
	void DisconnectNodesByInterfaceBindings(struct FMetaSoundNodeHandle& FromNodeHandle, struct FMetaSoundNodeHandle& ToNodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.DisconnectNodesByInterfaceBindings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694c620
	void DisconnectNodes(struct FMetaSoundBuilderNodeOutputHandle& NodeOutputHandle, struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.DisconnectNodes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694cc00
	void DisconnectNodeOutput(struct FMetaSoundBuilderNodeOutputHandle& NodeOutputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.DisconnectNodeOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694c880
	void DisconnectNodeInput(struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.DisconnectNodeInput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694ca40
	void ConvertToPreset(struct TScriptInterface<IMetaSoundDocumentInterface>& ReferencedNodeClass, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConvertToPreset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6949750
	void ConvertFromPreset(enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConvertFromPreset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6949900
	bool ContainsNodeOutput(struct FMetaSoundBuilderNodeOutputHandle& Output); // Function MetasoundEngine.MetaSoundBuilderBase.ContainsNodeOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x694cf10
	bool ContainsNodeInput(struct FMetaSoundBuilderNodeInputHandle& Input); // Function MetasoundEngine.MetaSoundBuilderBase.ContainsNodeInput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x694d040
	bool ContainsNode(struct FMetaSoundNodeHandle& Node); // Function MetasoundEngine.MetaSoundBuilderBase.ContainsNode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x694d170
	void ConnectNodesByInterfaceBindings(struct FMetaSoundNodeHandle& FromNodeHandle, struct FMetaSoundNodeHandle& ToNodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodesByInterfaceBindings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694dd10
	void ConnectNodes(struct FMetaSoundBuilderNodeOutputHandle& NodeOutputHandle, struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694df70
	void ConnectNodeOutputToGraphOutput(struct FName GraphOutputName, struct FMetaSoundBuilderNodeOutputHandle& NodeOutputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodeOutputToGraphOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694d4d0
	struct TArray<struct FMetaSoundBuilderNodeInputHandle> ConnectNodeOutputsToMatchingGraphInterfaceOutputs(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodeOutputsToMatchingGraphInterfaceOutputs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694da10
	void ConnectNodeInputToGraphInput(struct FName GraphInputName, struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodeInputToGraphInput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694d290
	struct TArray<struct FMetaSoundBuilderNodeOutputHandle> ConnectNodeInputsToMatchingGraphInterfaceInputs(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodeInputsToMatchingGraphInterfaceInputs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694d710
	struct FMetaSoundNodeHandle AddNodeByClassName(struct FMetasoundFrontendClassName& ClassName, int32_t MajorVersion, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.AddNodeByClassName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694e1d0
	struct FMetaSoundNodeHandle AddNode(struct TScriptInterface<IMetaSoundDocumentInterface>& NodeClass, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.AddNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694e440
	void AddInterface(struct FName InterfaceName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.AddInterface // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694e600
	struct FMetaSoundBuilderNodeInputHandle AddGraphOutputNode(struct FName Name, struct FName DataType, struct FMetasoundFrontendLiteral DefaultValue, enum class EMetaSoundBuilderResult& OutResult, bool bIsConstructorOutput); // Function MetasoundEngine.MetaSoundBuilderBase.AddGraphOutputNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694e790
	struct FMetaSoundBuilderNodeOutputHandle AddGraphInputNode(struct FName Name, struct FName DataType, struct FMetasoundFrontendLiteral DefaultValue, enum class EMetaSoundBuilderResult& OutResult, bool bIsConstructorInput); // Function MetasoundEngine.MetaSoundBuilderBase.AddGraphInputNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x694ed70
};

// Class MetasoundEngine.MetaSoundPatchBuilder
// Size: 0x60 (Inherited: 0x60)
struct UMetaSoundPatchBuilder : UMetaSoundBuilderBase {

	struct TScriptInterface<IMetaSoundDocumentInterface> Build(struct UObject* Parent, struct FMetaSoundBuilderOptions& Options); // Function MetasoundEngine.MetaSoundPatchBuilder.Build // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x694ff00
};

// Class MetasoundEngine.MetaSoundSourceBuilder
// Size: 0x68 (Inherited: 0x60)
struct UMetaSoundSourceBuilder : UMetaSoundBuilderBase {
	char pad_60[0x8]; // 0x60(0x08)

	void SetFormat(enum class EMetaSoundOutputAudioFormat OutputFormat, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundSourceBuilder.SetFormat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6950160
	bool GetLiveUpdatesEnabled(); // Function MetasoundEngine.MetaSoundSourceBuilder.GetLiveUpdatesEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x69502f0
	struct TScriptInterface<IMetaSoundDocumentInterface> Build(struct UObject* Parent, struct FMetaSoundBuilderOptions& Options); // Function MetasoundEngine.MetaSoundSourceBuilder.Build // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x694ff00
	void Audition(struct UObject* Parent, struct UAudioComponent* AudioComponent, struct FDelegate OnCreateGenerator, bool bLiveUpdatesEnabled); // Function MetasoundEngine.MetaSoundSourceBuilder.Audition // (Final|Native|Public|BlueprintCallable) // @ game+0x6950320
};

// Class MetasoundEngine.MetaSoundBuilderSubsystem
// Size: 0xd8 (Inherited: 0x30)
struct UMetaSoundBuilderSubsystem : UEngineSubsystem {
	char pad_30[0x8]; // 0x30(0x08)
	struct TMap<struct FName, struct UMetaSoundBuilderBase*> NamedBuilders; // 0x38(0x50)
	struct TMap<struct FName, struct TWeakObjectPtr<struct UMetaSoundBuilderBase>> AssetBuilders; // 0x88(0x50)

	bool UnregisterSourceBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.UnregisterSourceBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x69507a0
	bool UnregisterPatchBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.UnregisterPatchBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x69507a0
	bool UnregisterBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.UnregisterBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x69507a0
	void RegisterSourceBuilder(struct FName BuilderName, struct UMetaSoundSourceBuilder* Builder); // Function MetasoundEngine.MetaSoundBuilderSubsystem.RegisterSourceBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x69508a0
	void RegisterPatchBuilder(struct FName BuilderName, struct UMetaSoundPatchBuilder* Builder); // Function MetasoundEngine.MetaSoundBuilderSubsystem.RegisterPatchBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x69508a0
	void RegisterBuilder(struct FName BuilderName, struct UMetaSoundBuilderBase* Builder); // Function MetasoundEngine.MetaSoundBuilderSubsystem.RegisterBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x69508a0
	bool IsInterfaceRegistered(struct FName InInterfaceName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.IsInterfaceRegistered // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6950af0
	struct UMetaSoundSourceBuilder* FindSourceBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.FindSourceBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x6950d00
	struct UMetaSoundPatchBuilder* FindPatchBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.FindPatchBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x6950e40
	struct UMetaSoundBuilderBase* FindBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.FindBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x6950f80
	struct FMetasoundFrontendLiteral CreateStringMetaSoundLiteral(struct FString Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateStringMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6951660
	struct FMetasoundFrontendLiteral CreateStringArrayMetaSoundLiteral(struct TArray<struct FString>& Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateStringArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69513e0
	struct UMetaSoundSourceBuilder* CreateSourcePresetBuilder(struct FName BuilderName, struct TScriptInterface<IMetaSoundDocumentInterface>& ReferencedSourceClass, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateSourcePresetBuilder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6952840
	struct UMetaSoundSourceBuilder* CreateSourceBuilder(struct FName BuilderName, struct FMetaSoundBuilderNodeOutputHandle& OnPlayNodeOutput, struct FMetaSoundBuilderNodeInputHandle& OnFinishedNodeInput, struct TArray<struct FMetaSoundBuilderNodeInputHandle>& AudioOutNodeInputs, enum class EMetaSoundBuilderResult& OutResult, enum class EMetaSoundOutputAudioFormat OutputFormat, bool bIsOneShot); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateSourceBuilder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6952d00
	struct UMetaSoundPatchBuilder* CreatePatchPresetBuilder(struct FName BuilderName, struct TScriptInterface<IMetaSoundDocumentInterface>& ReferencedPatchClass, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreatePatchPresetBuilder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6952aa0
	struct UMetaSoundPatchBuilder* CreatePatchBuilder(struct FName BuilderName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreatePatchBuilder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6953210
	struct FMetasoundFrontendLiteral CreateObjectMetaSoundLiteral(struct UObject* Value); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateObjectMetaSoundLiteral // (Final|Native|Public|BlueprintCallable) // @ game+0x69519e0
	struct FMetasoundFrontendLiteral CreateObjectArrayMetaSoundLiteral(struct TArray<struct UObject*>& Value); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateObjectArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69518a0
	struct FMetasoundFrontendLiteral CreateMetaSoundLiteralFromParam(struct FAudioParameter& Param); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateMetaSoundLiteralFromParam // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6951070
	struct FMetasoundFrontendLiteral CreateIntMetaSoundLiteral(int32_t Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateIntMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6951d50
	struct FMetasoundFrontendLiteral CreateIntArrayMetaSoundLiteral(struct TArray<int32_t>& Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateIntArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6951af0
	struct FMetasoundFrontendLiteral CreateFloatMetaSoundLiteral(float Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateFloatMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69521b0
	struct FMetasoundFrontendLiteral CreateFloatArrayMetaSoundLiteral(struct TArray<float>& Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateFloatArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6951f50
	struct FMetasoundFrontendLiteral CreateBoolMetaSoundLiteral(bool Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateBoolMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6952620
	struct FMetasoundFrontendLiteral CreateBoolArrayMetaSoundLiteral(struct TArray<bool>& Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateBoolArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69523c0
};

// Class MetasoundEngine.MetaSoundSource
// Size: 0x880 (Inherited: 0x480)
struct UMetaSoundSource : USoundWaveProcedural {
	char pad_480[0x70]; // 0x480(0x70)
	struct FMetasoundFrontendDocument RootMetaSoundDocument; // 0x4f0(0x1b8)
	struct TSet<struct FString> ReferencedAssetClassKeys; // 0x6a8(0x50)
	struct TSet<struct UObject*> ReferencedAssetClassObjects; // 0x6f8(0x50)
	struct TSet<struct FSoftObjectPath> ReferenceAssetClassCache; // 0x748(0x50)
	enum class EMetaSoundOutputAudioFormat OutputFormat; // 0x798(0x01)
	char pad_799[0x3]; // 0x799(0x03)
	struct FGuid AssetClassID; // 0x79c(0x10)
	char pad_7AC[0xd4]; // 0x7ac(0xd4)
};

