// Class GameSubCatalog.McpVerifierModeSelector
// Size: 0x48 (Inherited: 0x28)
struct UMcpVerifierModeSelector : UObject {
	uint32_t RangeStart; // 0x28(0x04)
	uint32_t RangeEnd; // 0x2c(0x04)
	struct FString Salt; // 0x30(0x10)
	enum class EVerifierModeOverride VerifierModeOverride; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	int32_t ReceiptRefactorVersionOverride; // 0x44(0x04)
};

