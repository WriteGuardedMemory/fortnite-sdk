// Class CosmeticsFrameworkFlowgraph.OrderedOperation
// Size: 0x28 (Inherited: 0x28)
struct UOrderedOperation : UObject {
};

