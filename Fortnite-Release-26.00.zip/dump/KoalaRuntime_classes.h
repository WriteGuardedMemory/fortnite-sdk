// Class KoalaRuntime.FortContextualTutorial_GameplayEventKoala
// Size: 0x178 (Inherited: 0x170)
struct UFortContextualTutorial_GameplayEventKoala : UFortContextualTutorial_GameplayEvent {
	char pad_170[0x8]; // 0x170(0x08)
};

// Class KoalaRuntime.KoalaAnalytics
// Size: 0x28 (Inherited: 0x28)
struct UKoalaAnalytics : UObject {
};

// Class KoalaRuntime.KoalaGlobals
// Size: 0x28 (Inherited: 0x28)
struct UKoalaGlobals : UObject {
};

