// Class MediaAssets.MediaSourceRendererInterface
// Size: 0x28 (Inherited: 0x28)
struct UMediaSourceRendererInterface : UInterface {
};

// Class MediaAssets.MediaTexture
// Size: 0x220 (Inherited: 0x138)
struct UMediaTexture : UTexture {
	enum class TextureAddress AddressX; // 0x138(0x01)
	enum class TextureAddress AddressY; // 0x139(0x01)
	bool AutoClear; // 0x13a(0x01)
	char pad_13B[0x1]; // 0x13b(0x01)
	struct FLinearColor ClearColor; // 0x13c(0x10)
	bool EnableGenMips; // 0x14c(0x01)
	char NumMips; // 0x14d(0x01)
	bool NewStyleOutput; // 0x14e(0x01)
	enum class MediaTextureOutputFormat OutputFormat; // 0x14f(0x01)
	float CurrentAspectRatio; // 0x150(0x04)
	enum class MediaTextureOrientation CurrentOrientation; // 0x154(0x01)
	char pad_155[0x3]; // 0x155(0x03)
	struct UMediaPlayer* MediaPlayer; // 0x158(0x08)
	char pad_160[0xc0]; // 0x160(0xc0)

	void UpdateResource(); // Function MediaAssets.MediaTexture.UpdateResource // (Native|Public|BlueprintCallable) // @ game+0x3aeb8e0
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer); // Function MediaAssets.MediaTexture.SetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aeb900
	int32_t GetWidth(); // Function MediaAssets.MediaTexture.GetWidth // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aeba60
	int32_t GetTextureNumMips(); // Function MediaAssets.MediaTexture.GetTextureNumMips // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aeba40
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaTexture.GetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aeba10
	int32_t GetHeight(); // Function MediaAssets.MediaTexture.GetHeight // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aeba80
	float GetAspectRatio(); // Function MediaAssets.MediaTexture.GetAspectRatio // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aebaa0
};

// Class MediaAssets.MediaSource
// Size: 0x80 (Inherited: 0x28)
struct UMediaSource : UObject {
	char pad_28[0x58]; // 0x28(0x58)

	bool Validate(); // Function MediaAssets.MediaSource.Validate // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b01760
	void SetMediaOptionString(struct FName& Key, struct FString Value); // Function MediaAssets.MediaSource.SetMediaOptionString // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3b00f20
	void SetMediaOptionInt64(struct FName& Key, int64_t Value); // Function MediaAssets.MediaSource.SetMediaOptionInt64 // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3b01240
	void SetMediaOptionFloat(struct FName& Key, float Value); // Function MediaAssets.MediaSource.SetMediaOptionFloat // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3b01450
	void SetMediaOptionBool(struct FName& Key, bool Value); // Function MediaAssets.MediaSource.SetMediaOptionBool // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3b015d0
	struct FString GetUrl(); // Function MediaAssets.MediaSource.GetUrl // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b01790
};

// Class MediaAssets.BaseMediaSource
// Size: 0x88 (Inherited: 0x80)
struct UBaseMediaSource : UMediaSource {
	struct FName PlayerName; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
};

// Class MediaAssets.FileMediaSource
// Size: 0xb0 (Inherited: 0x88)
struct UFileMediaSource : UBaseMediaSource {
	struct FString FilePath; // 0x88(0x10)
	bool PrecacheFile; // 0x98(0x01)
	char pad_99[0x17]; // 0x99(0x17)

	void SetFilePath(struct FString Path); // Function MediaAssets.FileMediaSource.SetFilePath // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aec640
};

// Class MediaAssets.MediaComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UMediaComponent : UActorComponent {
	struct UMediaTexture* MediaTexture; // 0xa0(0x08)
	struct UMediaPlayer* MediaPlayer; // 0xa8(0x08)

	struct UMediaTexture* GetMediaTexture(); // Function MediaAssets.MediaComponent.GetMediaTexture // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aedd40
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaComponent.GetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aedd60
};

// Class MediaAssets.MediaTimeStampInfo
// Size: 0x38 (Inherited: 0x28)
struct UMediaTimeStampInfo : UObject {
	struct FTimespan Time; // 0x28(0x08)
	int64_t SequenceIndex; // 0x30(0x08)
};

// Class MediaAssets.MediaPlayer
// Size: 0x168 (Inherited: 0x28)
struct UMediaPlayer : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FMulticastInlineDelegate OnEndReached; // 0x30(0x10)
	struct FMulticastInlineDelegate OnMediaClosed; // 0x40(0x10)
	struct FMulticastInlineDelegate OnMediaOpened; // 0x50(0x10)
	struct FMulticastInlineDelegate OnMediaOpenFailed; // 0x60(0x10)
	struct FMulticastInlineDelegate OnPlaybackResumed; // 0x70(0x10)
	struct FMulticastInlineDelegate OnPlaybackSuspended; // 0x80(0x10)
	struct FMulticastInlineDelegate OnSeekCompleted; // 0x90(0x10)
	struct FMulticastInlineDelegate OnTracksChanged; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnMetadataChanged; // 0xb0(0x10)
	struct FTimespan CacheAhead; // 0xc0(0x08)
	struct FTimespan CacheBehind; // 0xc8(0x08)
	struct FTimespan CacheBehindGame; // 0xd0(0x08)
	bool NativeAudioOut; // 0xd8(0x01)
	bool PlayOnOpen; // 0xd9(0x01)
	char pad_DA[0x2]; // 0xda(0x02)
	char Shuffle : 1; // 0xdc(0x01)
	char Loop : 1; // 0xdc(0x01)
	char pad_DC_2 : 6; // 0xdc(0x01)
	char pad_DD[0x3]; // 0xdd(0x03)
	struct UMediaPlaylist* Playlist; // 0xe0(0x08)
	int32_t PlaylistIndex; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FTimespan TimeDelay; // 0xf0(0x08)
	float HorizontalFieldOfView; // 0xf8(0x04)
	float VerticalFieldOfView; // 0xfc(0x04)
	struct FRotator ViewRotation; // 0x100(0x18)
	char pad_118[0x28]; // 0x118(0x28)
	struct FGuid PlayerGuid; // 0x140(0x10)
	char pad_150[0x18]; // 0x150(0x18)

	bool SupportsSeeking(); // Function MediaAssets.MediaPlayer.SupportsSeeking // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aee730
	bool SupportsScrubbing(); // Function MediaAssets.MediaPlayer.SupportsScrubbing // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aee760
	bool SupportsRate(float Rate, bool Unthinned); // Function MediaAssets.MediaPlayer.SupportsRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aee860
	bool SetViewRotation(struct FRotator& Rotation, bool Absolute); // Function MediaAssets.MediaPlayer.SetViewRotation // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3aeec80
	bool SetViewField(float Horizontal, float Vertical, bool Absolute); // Function MediaAssets.MediaPlayer.SetViewField // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aeee10
	bool SetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex, float FrameRate); // Function MediaAssets.MediaPlayer.SetVideoTrackFrameRate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aef140
	bool SetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.SetTrackFormat // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aef440
	void SetTimeDelay(struct FTimespan TimeDelay); // Function MediaAssets.MediaPlayer.SetTimeDelay // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3aeea80
	bool SetRate(float Rate); // Function MediaAssets.MediaPlayer.SetRate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aef770
	bool SetNativeVolume(float Volume); // Function MediaAssets.MediaPlayer.SetNativeVolume // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aef660
	void SetMediaOptions(struct UMediaSource* Options); // Function MediaAssets.MediaPlayer.SetMediaOptions // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aef870
	bool SetLooping(bool Looping); // Function MediaAssets.MediaPlayer.SetLooping // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aef9d0
	void SetDesiredPlayerName(struct FName PlayerName); // Function MediaAssets.MediaPlayer.SetDesiredPlayerName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aefac0
	void SetBlockOnTime(struct FTimespan& Time); // Function MediaAssets.MediaPlayer.SetBlockOnTime // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3aefbb0
	bool SelectTrack(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.SelectTrack // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aefca0
	bool Seek(struct FTimespan& Time); // Function MediaAssets.MediaPlayer.Seek // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3aefe20
	bool Rewind(); // Function MediaAssets.MediaPlayer.Rewind // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aeff20
	bool Reopen(); // Function MediaAssets.MediaPlayer.Reopen // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3aeff50
	bool Previous(); // Function MediaAssets.MediaPlayer.Previous // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af0030
	void PlayAndSeek(); // Function MediaAssets.MediaPlayer.PlayAndSeek // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af0060
	bool Play(); // Function MediaAssets.MediaPlayer.Play // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af0080
	bool Pause(); // Function MediaAssets.MediaPlayer.Pause // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af00b0
	bool OpenUrl(struct FString URL); // Function MediaAssets.MediaPlayer.OpenUrl // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af00e0
	bool OpenSourceWithOptions(struct UMediaSource* MediaSource, struct FMediaPlayerOptions& Options); // Function MediaAssets.MediaPlayer.OpenSourceWithOptions // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3af0be0
	void OpenSourceLatent(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UMediaSource* MediaSource, struct FMediaPlayerOptions& Options, bool& bSuccess); // Function MediaAssets.MediaPlayer.OpenSourceLatent // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3af0200
	bool OpenSource(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlayer.OpenSource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af1130
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int32_t Index); // Function MediaAssets.MediaPlayer.OpenPlaylistIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af15c0
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist); // Function MediaAssets.MediaPlayer.OpenPlaylist // (Final|Native|Public|BlueprintCallable) // @ game+0x3af1a60
	bool OpenFile(struct FString FilePath); // Function MediaAssets.MediaPlayer.OpenFile // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af1e60
	bool Next(); // Function MediaAssets.MediaPlayer.Next // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af2690
	bool IsReady(); // Function MediaAssets.MediaPlayer.IsReady // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af26c0
	bool IsPreparing(); // Function MediaAssets.MediaPlayer.IsPreparing // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2720
	bool IsPlaying(); // Function MediaAssets.MediaPlayer.IsPlaying // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2760
	bool IsPaused(); // Function MediaAssets.MediaPlayer.IsPaused // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af27a0
	bool IsLooping(); // Function MediaAssets.MediaPlayer.IsLooping // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af27d0
	bool IsConnecting(); // Function MediaAssets.MediaPlayer.IsConnecting // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2800
	bool IsClosed(); // Function MediaAssets.MediaPlayer.IsClosed // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af26f0
	bool IsBuffering(); // Function MediaAssets.MediaPlayer.IsBuffering // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2900
	bool HasError(); // Function MediaAssets.MediaPlayer.HasError // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2a00
	struct FRotator GetViewRotation(); // Function MediaAssets.MediaPlayer.GetViewRotation // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2a70
	struct FString GetVideoTrackType(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2bb0
	struct FFloatRange GetVideoTrackFrameRates(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackFrameRates // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2d90
	float GetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackFrameRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2fe0
	struct FIntPoint GetVideoTrackDimensions(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackDimensions // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3170
	float GetVideoTrackAspectRatio(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackAspectRatio // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af33c0
	float GetVerticalFieldOfView(); // Function MediaAssets.MediaPlayer.GetVerticalFieldOfView // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3620
	struct FString GetUrl(); // Function MediaAssets.MediaPlayer.GetUrl // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3750
	struct FString GetTrackLanguage(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackLanguage // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3780
	int32_t GetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackFormat // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af39b0
	struct FText GetTrackDisplayName(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackDisplayName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3b40
	struct UMediaTimeStampInfo* GetTimeStamp(); // Function MediaAssets.MediaPlayer.GetTimeStamp // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3e30
	struct FTimespan GetTimeDelay(); // Function MediaAssets.MediaPlayer.GetTimeDelay // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af2a40
	struct FTimespan GetTime(); // Function MediaAssets.MediaPlayer.GetTime // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3f10
	void GetSupportedRates(struct TArray<struct FFloatRange>& OutRates, bool Unthinned); // Function MediaAssets.MediaPlayer.GetSupportedRates // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3f50
	int32_t GetSelectedTrack(enum class EMediaPlayerTrack TrackType); // Function MediaAssets.MediaPlayer.GetSelectedTrack // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4120
	float GetRate(); // Function MediaAssets.MediaPlayer.GetRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4220
	int32_t GetPlaylistIndex(); // Function MediaAssets.MediaPlayer.GetPlaylistIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4260
	struct UMediaPlaylist* GetPlaylist(); // Function MediaAssets.MediaPlayer.GetPlaylist // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4280
	struct FName GetPlayerName(); // Function MediaAssets.MediaPlayer.GetPlayerName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4300
	int32_t GetNumTracks(enum class EMediaPlayerTrack TrackType); // Function MediaAssets.MediaPlayer.GetNumTracks // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4570
	int32_t GetNumTrackFormats(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetNumTrackFormats // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4340
	struct FText GetMediaName(); // Function MediaAssets.MediaPlayer.GetMediaName // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4710
	struct TMap<struct FString, struct FMediaMetadataItemsBPT> GetMediaMetadataItems(); // Function MediaAssets.MediaPlayer.GetMediaMetadataItems // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aee610
	float GetHorizontalFieldOfView(); // Function MediaAssets.MediaPlayer.GetHorizontalFieldOfView // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af47a0
	struct FTimespan GetDuration(); // Function MediaAssets.MediaPlayer.GetDuration // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af48d0
	struct UMediaTimeStampInfo* GetDisplayTimeStamp(); // Function MediaAssets.MediaPlayer.GetDisplayTimeStamp // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3db0
	struct FTimespan GetDisplayTime(); // Function MediaAssets.MediaPlayer.GetDisplayTime // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af3eb0
	struct FName GetDesiredPlayerName(); // Function MediaAssets.MediaPlayer.GetDesiredPlayerName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af49b0
	struct FString GetAudioTrackType(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af49e0
	int32_t GetAudioTrackSampleRate(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackSampleRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4bc0
	int32_t GetAudioTrackChannels(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackChannels // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af4de0
	void Close(); // Function MediaAssets.MediaPlayer.Close // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af5000
	bool CanPlayUrl(struct FString URL); // Function MediaAssets.MediaPlayer.CanPlayUrl // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af5020
	bool CanPlaySource(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlayer.CanPlaySource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3af5220
	bool CanPause(); // Function MediaAssets.MediaPlayer.CanPause // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3af5480
};

// Class MediaAssets.MediaPlayerProxyInterface
// Size: 0x28 (Inherited: 0x28)
struct UMediaPlayerProxyInterface : UInterface {
};

// Class MediaAssets.MediaPlaylist
// Size: 0x38 (Inherited: 0x28)
struct UMediaPlaylist : UObject {
	struct TArray<struct UMediaSource*> Items; // 0x28(0x10)

	bool Replace(int32_t Index, struct UMediaSource* Replacement); // Function MediaAssets.MediaPlaylist.Replace // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afbd60
	bool RemoveAt(int32_t Index); // Function MediaAssets.MediaPlaylist.RemoveAt // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afbf10
	bool Remove(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlaylist.Remove // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afc040
	int32_t Num(); // Function MediaAssets.MediaPlaylist.Num // (Final|Native|Public|BlueprintCallable) // @ game+0x3afc220
	void Insert(struct UMediaSource* MediaSource, int32_t Index); // Function MediaAssets.MediaPlaylist.Insert // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afc240
	struct UMediaSource* GetRandom(int32_t& OutIndex); // Function MediaAssets.MediaPlaylist.GetRandom // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3afc410
	struct UMediaSource* GetPrevious(int32_t& InOutIndex); // Function MediaAssets.MediaPlaylist.GetPrevious // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3afc510
	struct UMediaSource* GetNext(int32_t& InOutIndex); // Function MediaAssets.MediaPlaylist.GetNext // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3afc640
	struct UMediaSource* Get(int32_t Index); // Function MediaAssets.MediaPlaylist.Get // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afc770
	bool AddUrl(struct FString URL); // Function MediaAssets.MediaPlaylist.AddUrl // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afc890
	bool AddFile(struct FString FilePath); // Function MediaAssets.MediaPlaylist.AddFile // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afcab0
	bool Add(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlaylist.Add // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afd220
};

// Class MediaAssets.MediaSoundComponent
// Size: 0x9e0 (Inherited: 0x900)
struct UMediaSoundComponent : USynthComponent {
	enum class EMediaSoundChannels Channels; // 0x900(0x04)
	bool DynamicRateAdjustment; // 0x904(0x01)
	char pad_905[0x3]; // 0x905(0x03)
	float RateAdjustmentFactor; // 0x908(0x04)
	struct FFloatRange RateAdjustmentRange; // 0x90c(0x10)
	char pad_91C[0x4]; // 0x91c(0x04)
	struct UMediaPlayer* MediaPlayer; // 0x920(0x08)
	char pad_928[0xb8]; // 0x928(0xb8)

	void SetSpectralAnalysisSettings(struct TArray<float> InFrequenciesToAnalyze, enum class EMediaSoundComponentFFTSize InFFTSize); // Function MediaAssets.MediaSoundComponent.SetSpectralAnalysisSettings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afe590
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer); // Function MediaAssets.MediaSoundComponent.SetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afe960
	void SetEnvelopeFollowingsettings(int32_t AttackTimeMsec, int32_t ReleaseTimeMsec); // Function MediaAssets.MediaSoundComponent.SetEnvelopeFollowingsettings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afddd0
	void SetEnableSpectralAnalysis(bool bInSpectralAnalysisEnabled); // Function MediaAssets.MediaSoundComponent.SetEnableSpectralAnalysis // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afe840
	void SetEnableEnvelopeFollowing(bool bInEnvelopeFollowing); // Function MediaAssets.MediaSoundComponent.SetEnableEnvelopeFollowing // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afdf90
	struct TArray<struct FMediaSoundComponentSpectralData> GetSpectralData(); // Function MediaAssets.MediaSoundComponent.GetSpectralData // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afe360
	struct TArray<struct FMediaSoundComponentSpectralData> GetNormalizedSpectralData(); // Function MediaAssets.MediaSoundComponent.GetNormalizedSpectralData // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3afe0c0
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaSoundComponent.GetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3afea80
	float GetEnvelopeValue(); // Function MediaAssets.MediaSoundComponent.GetEnvelopeValue // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3afdd90
	bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings& OutAttenuationSettings); // Function MediaAssets.MediaSoundComponent.BP_GetAttenuationSettingsToApply // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3afeab0
};

// Class MediaAssets.PlatformMediaSource
// Size: 0x88 (Inherited: 0x80)
struct UPlatformMediaSource : UMediaSource {
	struct UMediaSource* MediaSource; // 0x80(0x08)
};

// Class MediaAssets.StreamMediaSource
// Size: 0x98 (Inherited: 0x88)
struct UStreamMediaSource : UBaseMediaSource {
	struct FString StreamUrl; // 0x88(0x10)
};

// Class MediaAssets.TimeSynchronizableMediaSource
// Size: 0xa0 (Inherited: 0x88)
struct UTimeSynchronizableMediaSource : UBaseMediaSource {
	bool bUseTimeSynchronization; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	int32_t FrameDelay; // 0x8c(0x04)
	double TimeDelay; // 0x90(0x08)
	bool bAutoDetectInput; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class MediaAssets.MediaBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UMediaBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	void EnumerateWebcamCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateWebcamCaptureDevices // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3b06550
	void EnumerateVideoCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateVideoCaptureDevices // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3b06780
	void EnumerateAudioCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateAudioCaptureDevices // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3b069b0
};

