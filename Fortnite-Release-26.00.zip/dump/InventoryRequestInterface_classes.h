// Class InventoryRequestInterface.PersistenceInventoryRequestInterface
// Size: 0x28 (Inherited: 0x28)
struct UPersistenceInventoryRequestInterface : UInterface {
};

