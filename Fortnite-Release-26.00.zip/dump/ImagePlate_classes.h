// Class ImagePlate.ImagePlate
// Size: 0x298 (Inherited: 0x290)
struct AImagePlate : AActor {
	struct UImagePlateComponent* ImagePlate; // 0x290(0x08)
};

// Class ImagePlate.ImagePlateComponent
// Size: 0x6c0 (Inherited: 0x570)
struct UImagePlateComponent : UPrimitiveComponent {
	struct FImagePlateParameters Plate; // 0x568(0x40)
	char pad_5B0[0x110]; // 0x5b0(0x110)

	void SetImagePlate(struct FImagePlateParameters Plate); // Function ImagePlate.ImagePlateComponent.SetImagePlate // (Final|Native|Public|BlueprintCallable) // @ game+0xb350950
	void OnRenderTextureChanged(); // Function ImagePlate.ImagePlateComponent.OnRenderTextureChanged // (Final|Native|Public) // @ game+0xb3508e0
	struct FImagePlateParameters GetPlate(); // Function ImagePlate.ImagePlateComponent.GetPlate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb350900
};

// Class ImagePlate.ImagePlateSettings
// Size: 0x38 (Inherited: 0x28)
struct UImagePlateSettings : UObject {
	struct FString ProxyName; // 0x28(0x10)
};

// Class ImagePlate.ImagePlateFileSequence
// Size: 0x50 (Inherited: 0x28)
struct UImagePlateFileSequence : UObject {
	struct FDirectoryPath SequencePath; // 0x28(0x10)
	struct FString FileWildcard; // 0x38(0x10)
	float FrameRate; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class ImagePlate.ImagePlateFrustumComponent
// Size: 0x570 (Inherited: 0x570)
struct UImagePlateFrustumComponent : UPrimitiveComponent {
};

