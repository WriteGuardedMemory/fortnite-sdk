// Class DynamicAthenaHUD.DynamicAthenaHUDDirector
// Size: 0x2d0 (Inherited: 0x2b0)
struct ADynamicAthenaHUDDirector : ADynamicUIDirectorBase {
	struct UDynamicUIScene* VehicleHUDScene; // 0x2b0(0x08)
	struct UDynamicUIScene* CreativeQuickbarScene; // 0x2b8(0x08)
	struct UDynamicUIScene* TournamentScene; // 0x2c0(0x08)
	struct UDynamicUIScene* ArenaTournamentScene; // 0x2c8(0x08)

	void HandleExitingVehicle(); // Function DynamicAthenaHUD.DynamicAthenaHUDDirector.HandleExitingVehicle // (Final|Native|Private) // @ game+0xab8ddf0
	void HandleEnteringVehicle(); // Function DynamicAthenaHUD.DynamicAthenaHUDDirector.HandleEnteringVehicle // (Final|Native|Private) // @ game+0xab8de20
	void HandleCreativeQuickbarEquippedChanged(bool bIsQuickbarEquipped); // Function DynamicAthenaHUD.DynamicAthenaHUDDirector.HandleCreativeQuickbarEquippedChanged // (Final|Native|Private) // @ game+0xab8dce0
};

