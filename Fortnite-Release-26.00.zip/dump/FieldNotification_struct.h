// ScriptStruct FieldNotification.FieldNotificationId
// Size: 0x04 (Inherited: 0x00)
struct FFieldNotificationId {
	struct FName FieldName; // 0x00(0x04)
};

