// Enum EpicStreamMediaSource.UCPTypes
enum class UCPTypes : uint8 {
	UCPAudio = 0,
	UCPVideo = 1,
	UCPBoth = 2,
	UCPNone = 3,
	UCPTypes_MAX = 4
};

// Enum EpicStreamMediaSource.EStreamMediaContainerType
enum class EStreamMediaContainerType : uint8 {
	CONTAINER_DASH = 0,
	CONTAINER_HLS = 1,
	CONTAINER_MP4 = 2,
	CONTAINER_UNKNOWN = 3,
	CONTAINER_MAX = 4
};

