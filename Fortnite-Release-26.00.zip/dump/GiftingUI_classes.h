// Class GiftingUI.AthenaGiftConfirmedPanel
// Size: 0x418 (Inherited: 0x3e8)
struct UAthenaGiftConfirmedPanel : UCommonActivatableWidget {
	char pad_3E8[0x18]; // 0x3e8(0x18)
	struct URichTextBlock* Text_RecipientInfo; // 0x400(0x08)
	struct UCommonButtonBase* Button_Back; // 0x408(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x410(0x08)
};

// Class GiftingUI.AthenaGiftingConfirmationScreen
// Size: 0x540 (Inherited: 0x3e8)
struct UAthenaGiftingConfirmationScreen : UCommonActivatableWidget {
	char pad_3E8[0x30]; // 0x3e8(0x30)
	struct UFortStoreFrontOfferInfo* PresentedGiftableOfferInfo; // 0x418(0x08)
	struct UFortStoreFrontOfferInfo* PresentedOptionalTokenOfferInfo; // 0x420(0x08)
	char pad_428[0xbc]; // 0x428(0xbc)
	float MinGiftSubmissionDelay; // 0x4e4(0x04)
	float MaxGiftSubmissionDelay; // 0x4e8(0x04)
	char pad_4EC[0x14]; // 0x4ec(0x14)
	struct UCommonButtonBase* Button_WrapOptions; // 0x500(0x08)
	struct UCommonButtonBase* Button_Back; // 0x508(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x510(0x08)
	struct UCommonButtonBase* Button_MtxWallet; // 0x518(0x08)
	struct UAthenaGiftingPurchasePanel* Panel_GiftingPurchase; // 0x520(0x08)
	struct UAthenaGiftingWrapOptionsPanel* Panel_WrapOptions; // 0x528(0x08)
	struct UAthenaGiftConfirmedPanel* Panel_GiftConfirmed; // 0x530(0x08)
	struct UAthenaGiftingErrorsPanel* Panel_GiftingErrors; // 0x538(0x08)

	void OnPresentationModeChanged(enum class EGiftingPresentationMode NewMode); // Function GiftingUI.AthenaGiftingConfirmationScreen.OnPresentationModeChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandleTokenOfferPurchaseComplete(bool bSuccess, struct TArray<struct FPurchasedItemInfo>& PurchasedItems); // Function GiftingUI.AthenaGiftingConfirmationScreen.HandleTokenOfferPurchaseComplete // (Final|Native|Private|HasOutParms) // @ game+0xabf22b0
	void HandleGiftSent(bool bSuccess, struct TArray<struct FString>& IneligibleAccounts, struct TArray<struct FString>& ErrorCodes); // Function GiftingUI.AthenaGiftingConfirmationScreen.HandleGiftSent // (Final|Native|Private|HasOutParms) // @ game+0xabf2490
	void Dismiss(bool bGiftConfirmed); // Function GiftingUI.AthenaGiftingConfirmationScreen.Dismiss // (Final|Native|Private|BlueprintCallable) // @ game+0xabf21c0
};

// Class GiftingUI.AthenaGiftingErrorsPanel
// Size: 0x448 (Inherited: 0x3e8)
struct UAthenaGiftingErrorsPanel : UCommonActivatableWidget {
	char pad_3E8[0x30]; // 0x3e8(0x30)
	struct URichTextBlock* Text_RecipientInfo; // 0x418(0x08)
	struct URichTextBlock* Text_Title; // 0x420(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x428(0x08)
	struct UCommonButtonBase* Button_Back; // 0x430(0x08)
	struct UCommonButtonBase* Button_Continue; // 0x438(0x08)
	struct UTileView* TileView_Items; // 0x440(0x08)

	void UpdateGiftEligibility(bool bStillGiftable); // Function GiftingUI.AthenaGiftingErrorsPanel.UpdateGiftEligibility // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class GiftingUI.AthenaGiftingPriceWidget
// Size: 0x2f0 (Inherited: 0x2d0)
struct UAthenaGiftingPriceWidget : UCommonUserWidget {
	struct UCommonTextBlock* Text_RealMoneyPrice; // 0x2d0(0x08)
	struct UCommonTextBlock* Text_FinalPrice; // 0x2d8(0x08)
	struct UCommonTextBlock* Text_RegularPrice; // 0x2e0(0x08)
	struct UWidget* Overlay_SalePrice; // 0x2e8(0x08)

	void SetPresentationMode(enum class EGiftingPricePresentationMode Mode); // Function GiftingUI.AthenaGiftingPriceWidget.SetPresentationMode // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class GiftingUI.AthenaGiftingPurchaseButton
// Size: 0x1520 (Inherited: 0x1510)
struct UAthenaGiftingPurchaseButton : UFortHoldableButton {
	struct UAthenaGiftingPriceWidget* Widget_Price; // 0x1508(0x08)
	struct UCommonTextBlock* Text_Title; // 0x1510(0x08)
};

// Class GiftingUI.AthenaGiftingPurchasePanel
// Size: 0x430 (Inherited: 0x3e8)
struct UAthenaGiftingPurchasePanel : UCommonActivatableWidget {
	char pad_3E8[0x18]; // 0x3e8(0x18)
	struct UAthenaGiftingPurchaseButton* Button_PurchaseGift; // 0x400(0x08)
	struct UFortSocialAvatarIcon* Avatar_MemberIcon; // 0x408(0x08)
	struct UCommonTextBlock* Text_SocialNameInfo; // 0x410(0x08)
	struct UCommonTextBlock* Text_ItemsCount; // 0x418(0x08)
	struct UCommonTextBlock* Text_OfferName; // 0x420(0x08)
	struct UTileView* TileView_Items; // 0x428(0x08)

	void PlayIntroAnimation(); // Function GiftingUI.AthenaGiftingPurchasePanel.PlayIntroAnimation // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class GiftingUI.AthenaGiftingScreen
// Size: 0x8e8 (Inherited: 0x708)
struct UAthenaGiftingScreen : UFortItemPreviewScreen {
	char pad_708[0x8]; // 0x708(0x08)
	struct UFortGiftingUserSearchWidget* SearchWidget_SocialSearchWidget; // 0x710(0x08)
	struct UFortGiftingSocialUserListView* ListView_Recipients; // 0x718(0x08)
	struct UTileView* TileView_Items; // 0x720(0x08)
	struct UCommonButtonBase* Button_Back; // 0x728(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x730(0x08)
	struct UCommonButtonBase* Button_GiftingPolicy; // 0x738(0x08)
	struct UCommonButtonBase* Button_CameraControl; // 0x740(0x08)
	struct UCommonTextBlock* Text_OfferName; // 0x748(0x08)
	struct UCommonTextBlock* Text_VBucksOffCount; // 0x750(0x08)
	struct UCommonTextBlock* Text_ShownItemIndex; // 0x758(0x08)
	struct UCommonRichTextBlock* Text_NoContent; // 0x760(0x08)
	struct UCommonRichTextBlock* RichText_OfferItemOwnedCount; // 0x768(0x08)
	struct UOverlay* Container_VBucksOffViolator; // 0x770(0x08)
	struct UCommonRichTextBlock* RichText_GiftCount; // 0x778(0x08)
	struct UAthenaGiftingPriceWidget* Widget_Price; // 0x780(0x08)
	struct UAthenaLockerItemInfo* Widget_ItemInfo; // 0x788(0x08)
	struct UDynamicEntryBox* EntryBox_FilterTabs; // 0x790(0x08)
	struct UCommonActionWidget* ActionWidget_FilterTabsPrevious; // 0x798(0x08)
	struct UCommonActionWidget* ActionWidget_FilterTabsNext; // 0x7a0(0x08)
	struct UAthenaGiftingConfirmationScreen* ActivatableWidget_GiftingConfirmation; // 0x7a8(0x08)
	float ItemCyclingInterval; // 0x7b0(0x04)
	char pad_7B4[0x4]; // 0x7b4(0x04)
	struct FDataTableRowHandle FilterTabsPreviousAction; // 0x7b8(0x10)
	struct FDataTableRowHandle FilterTabsNextAction; // 0x7c8(0x10)
	struct FText RegularGiftingPolicy; // 0x7d8(0x18)
	struct FText BattlePassGiftingPolicy; // 0x7f0(0x18)
	char pad_808[0x60]; // 0x808(0x60)
	struct TMap<struct UCommonButtonBase*, enum class EFilterType> FilterMap; // 0x868(0x50)
	struct UCommonButtonGroupBase* FilterGroup; // 0x8b8(0x08)
	struct TArray<struct UFortItemDefinition*> ItemDefinitions; // 0x8c0(0x10)
	struct UFortItemDefinition* PresentedItemDefinition; // 0x8d0(0x08)
	struct UFortStoreFrontOfferInfo* GiftableOfferInfo; // 0x8d8(0x08)
	struct UFortStoreFrontOfferInfo* OptionalTokenOfferInfo; // 0x8e0(0x08)

	void OnShowSearchWarningText(bool bShow); // Function GiftingUI.AthenaGiftingScreen.OnShowSearchWarningText // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnShownItemChanged(); // Function GiftingUI.AthenaGiftingScreen.OnShownItemChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSetupFilterTabButton(struct UCommonButtonBase* Button, enum class EFilterType FilterType); // Function GiftingUI.AthenaGiftingScreen.OnSetupFilterTabButton // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPresentationModeChanged(enum class EGiftingScreenPresentationMode Mode); // Function GiftingUI.AthenaGiftingScreen.OnPresentationModeChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPartyListUpdated(bool bEmpty); // Function GiftingUI.AthenaGiftingScreen.OnPartyListUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnFriendSelectionChanged(); // Function GiftingUI.AthenaGiftingScreen.OnFriendSelectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnFilterChanged(enum class EFilterType FilterType); // Function GiftingUI.AthenaGiftingScreen.OnFilterChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BlockScreenContent(bool bBlockScreen, struct FText& ContentBlockedText); // Function GiftingUI.AthenaGiftingScreen.BlockScreenContent // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class GiftingUI.AthenaGiftingWrapOptionsPanel
// Size: 0x450 (Inherited: 0x3e8)
struct UAthenaGiftingWrapOptionsPanel : UCommonActivatableWidget {
	char pad_3E8[0x28]; // 0x3e8(0x28)
	struct TArray<struct TSoftObjectPtr<UFortGiftBoxItemDefinition>> GiftBoxes; // 0x410(0x10)
	struct TArray<struct UFortGiftBoxItemDefinition*> GiftBoxItemDefs; // 0x420(0x10)
	char pad_430[0x10]; // 0x430(0x10)
	struct UCommonButtonLegacy* Button_ConfirmWrap; // 0x440(0x08)
	struct UTileView* TileView_WrapOptions; // 0x448(0x08)
};

// Class GiftingUI.FortGiftingSocialUserListEntry
// Size: 0x15c0 (Inherited: 0x14e0)
struct UFortGiftingSocialUserListEntry : USocialListEntryBase {
	char pad_14E0[0xb8]; // 0x14e0(0xb8)
	struct UFortSocialAvatarIcon* Avatar_MemberIcon; // 0x1598(0x08)
	struct USocialNameTextBlock* Text_SocialName; // 0x15a0(0x08)
	struct UCommonRichTextBlock* RichText_EligibilityStatus; // 0x15a8(0x08)
	struct UCommonRichTextBlock* RichText_OwnedItems; // 0x15b0(0x08)
	struct UAthenaGiftingPriceWidget* Widget_Price; // 0x15b8(0x08)

	void SetPresentationMode(enum class ERecipientPresentationMode Mode); // Function GiftingUI.FortGiftingSocialUserListEntry.SetPresentationMode // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnUserItemSet(); // Function GiftingUI.FortGiftingSocialUserListEntry.OnUserItemSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRecipientStatusUpdated(); // Function GiftingUI.FortGiftingSocialUserListEntry.OnRecipientStatusUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_OnTouchSelectionConfirmed(); // Function GiftingUI.FortGiftingSocialUserListEntry.BP_OnTouchSelectionConfirmed // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_OnHighlightedStateChanged(bool bInIsHighlighted, bool bPlayAnimation); // Function GiftingUI.FortGiftingSocialUserListEntry.BP_OnHighlightedStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class GiftingUI.FortGiftingSocialUserListView
// Size: 0x498 (Inherited: 0x3a0)
struct UFortGiftingSocialUserListView : USocialUserListViewBase {
	float RefreshRecipientStatusDelay; // 0x3a0(0x04)
	char pad_3A4[0xf4]; // 0x3a4(0xf4)
};

// Class GiftingUI.FortGiftingUserSearchWidget
// Size: 0x318 (Inherited: 0x2d0)
struct UFortGiftingUserSearchWidget : UCommonUserWidget {
	struct UEditableText* EditableText_SearchFriends; // 0x2d0(0x08)
	struct UCommonButtonBase* Button_ClearQuery; // 0x2d8(0x08)
	struct UCommonButtonBase* Button_SubmitQuery; // 0x2e0(0x08)
	char pad_2E8[0x30]; // 0x2e8(0x30)

	void OnSearchCommit(bool bSearchStringShort); // Function GiftingUI.FortGiftingUserSearchWidget.OnSearchCommit // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandleSearchFriendsTextEntered(struct FText& Text, enum class ETextCommit CommitMethod); // Function GiftingUI.FortGiftingUserSearchWidget.HandleSearchFriendsTextEntered // (Final|Native|Private|HasOutParms) // @ game+0xac048b0
	void HandleSearchFriendsTextChanged(struct FText& Text); // Function GiftingUI.FortGiftingUserSearchWidget.HandleSearchFriendsTextChanged // (Final|Native|Private|HasOutParms) // @ game+0xac04c10
	void FocusEditableText(); // Function GiftingUI.FortGiftingUserSearchWidget.FocusEditableText // (Final|Native|Protected|BlueprintCallable) // @ game+0xac04d50
};

// Class GiftingUI.FortGiftingWrapOptionListEntry
// Size: 0x14e0 (Inherited: 0x14c0)
struct UFortGiftingWrapOptionListEntry : UCommonButtonLegacy {
	char pad_14C0[0x8]; // 0x14c0(0x08)
	struct UFortGiftBoxItemDefinition* GiftBoxDefinition; // 0x14c8(0x08)
	struct UCommonLazyImage* Image_Gift; // 0x14d0(0x08)
	char pad_14D8[0x8]; // 0x14d8(0x08)
};

// Class GiftingUI.FortGiftingData
// Size: 0x4b8 (Inherited: 0x498)
struct UFortGiftingData : UFortGameFeatureData {
	struct TSoftClassPtr<UObject> GiftingScreenClass; // 0x498(0x20)
};

