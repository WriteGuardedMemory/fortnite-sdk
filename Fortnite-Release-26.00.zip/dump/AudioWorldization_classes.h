// Class AudioWorldization.AudioWorldizationReflectionProbe
// Size: 0x2e0 (Inherited: 0x290)
struct AAudioWorldizationReflectionProbe : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct USubmixSendVolumeComponent* SubmixSends; // 0x298(0x08)
	struct UAudioGameplayVolumeComponent* AGVComponent; // 0x2a0(0x08)
	char pad_2A8[0x38]; // 0x2a8(0x38)
};

// Class AudioWorldization.AudioWorldizationDefaultSettings
// Size: 0xc8 (Inherited: 0x30)
struct UAudioWorldizationDefaultSettings : UDeveloperSettings {
	struct FAudioWorldizationGlobalSettings GlobalSettings; // 0x30(0x30)
	struct FAudioWorldizationSettings DefaultSettings; // 0x60(0x58)
	struct TArray<struct FSoftObjectPath> ModulationParameters; // 0xb8(0x10)
};

// Class AudioWorldization.AudioWorldizationSubsystem
// Size: 0x168 (Inherited: 0x40)
struct UAudioWorldizationSubsystem : UTickableWorldSubsystem {
	struct USoundControlBus* EnclosureBus; // 0x40(0x08)
	struct USoundControlBus* WallDistanceBus; // 0x48(0x08)
	struct USoundControlBus* ListenerAzimuthBus; // 0x50(0x08)
	char pad_58[0x30]; // 0x58(0x30)
	struct FAudioWorldizationSettings CurrentSettings; // 0x88(0x58)
	struct AAudioWorldizationReflectionProbe* VolumeActor; // 0xe0(0x08)
	struct UAudioWorldizationTracePolicyBase* TracePolicy; // 0xe8(0x08)
	struct UAudioWorldizationTraceDirectionPolicyBase* TraceDirectionPolicy; // 0xf0(0x08)
	char pad_F8[0x40]; // 0xf8(0x40)
	struct TArray<struct FAudioWorldizationSettings> SettingsStack; // 0x138(0x10)
	struct TArray<struct USoundControlBus*> QuadrantEnclosureBuses; // 0x148(0x10)
	struct TArray<struct USoundControlBus*> QuadrantWallDistanceBuses; // 0x158(0x10)

	void SetWorldizationSettings(struct FAudioWorldizationSettings& InSettings); // Function AudioWorldization.AudioWorldizationSubsystem.SetWorldizationSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6f4f230
	void SetEnabled(bool bNewEnabled); // Function AudioWorldization.AudioWorldizationSubsystem.SetEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x6f4f450
	void SetDefaultSettings(); // Function AudioWorldization.AudioWorldizationSubsystem.SetDefaultSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x6f4f120
	void RemoveWorldizationSettings(struct FName InIdentifier); // Function AudioWorldization.AudioWorldizationSubsystem.RemoveWorldizationSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x6f4f140
	struct TArray<struct FAudioSphereTraceResult> GetTraceResults(); // Function AudioWorldization.AudioWorldizationSubsystem.GetTraceResults // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f4f050
	float GetEnclosureFactor(); // Function AudioWorldization.AudioWorldizationSubsystem.GetEnclosureFactor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f4f100
	float GetAverageTraceDistance(); // Function AudioWorldization.AudioWorldizationSubsystem.GetAverageTraceDistance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f4f0e0
};

// Class AudioWorldization.AudioWorldizationTraceDirectionPolicyBase
// Size: 0x28 (Inherited: 0x28)
struct UAudioWorldizationTraceDirectionPolicyBase : UObject {
};

// Class AudioWorldization.AudioWorldizationTraceDirectionPolicyDefault
// Size: 0x28 (Inherited: 0x28)
struct UAudioWorldizationTraceDirectionPolicyDefault : UAudioWorldizationTraceDirectionPolicyBase {
};

// Class AudioWorldization.AudioWorldizationTracePolicyBase
// Size: 0x28 (Inherited: 0x28)
struct UAudioWorldizationTracePolicyBase : UObject {
};

// Class AudioWorldization.AudioWorldizationTracePolicyDefault
// Size: 0x28 (Inherited: 0x28)
struct UAudioWorldizationTracePolicyDefault : UAudioWorldizationTracePolicyBase {
};

// Class AudioWorldization.GameFeatureAction_SetAudioWorldizationSettings
// Size: 0xd0 (Inherited: 0x28)
struct UGameFeatureAction_SetAudioWorldizationSettings : UGameFeatureAction {
	struct FAudioWorldizationSettings Settings; // 0x28(0x58)
	char pad_80[0x50]; // 0x80(0x50)
};

