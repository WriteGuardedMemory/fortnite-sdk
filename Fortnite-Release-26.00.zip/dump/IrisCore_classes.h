// Class IrisCore.DataStream
// Size: 0x28 (Inherited: 0x28)
struct UDataStream : UObject {
};

// Class IrisCore.DataStreamDefinitions
// Size: 0x40 (Inherited: 0x28)
struct UDataStreamDefinitions : UObject {
	struct TArray<struct FDataStreamDefinition> DataStreamDefinitions; // 0x28(0x10)
	char pad_38[0x8]; // 0x38(0x08)
};

// Class IrisCore.DataStreamManager
// Size: 0x30 (Inherited: 0x28)
struct UDataStreamManager : UDataStream {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class IrisCore.NetObjectFilterConfig
// Size: 0x30 (Inherited: 0x28)
struct UNetObjectFilterConfig : UObject {
	enum class ENetFilterType FilterType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// Class IrisCore.FilterOutNetObjectFilterConfig
// Size: 0x30 (Inherited: 0x30)
struct UFilterOutNetObjectFilterConfig : UNetObjectFilterConfig {
};

// Class IrisCore.NetObjectFilter
// Size: 0x50 (Inherited: 0x28)
struct UNetObjectFilter : UObject {
	char pad_28[0x28]; // 0x28(0x28)
};

// Class IrisCore.FilterOutNetObjectFilter
// Size: 0x50 (Inherited: 0x50)
struct UFilterOutNetObjectFilter : UNetObjectFilter {
};

// Class IrisCore.IrisObjectReferencePackageMap
// Size: 0xe8 (Inherited: 0xe0)
struct UIrisObjectReferencePackageMap : UPackageMap {
	char pad_E0[0x8]; // 0xe0(0x08)
};

// Class IrisCore.NetObjectPrioritizer
// Size: 0x28 (Inherited: 0x28)
struct UNetObjectPrioritizer : UObject {
};

// Class IrisCore.LocationBasedNetObjectPrioritizer
// Size: 0x60 (Inherited: 0x28)
struct ULocationBasedNetObjectPrioritizer : UNetObjectPrioritizer {
	char pad_28[0x38]; // 0x28(0x38)
};

// Class IrisCore.NetBlobHandler
// Size: 0x38 (Inherited: 0x28)
struct UNetBlobHandler : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class IrisCore.NetBlobHandlerDefinitions
// Size: 0x38 (Inherited: 0x28)
struct UNetBlobHandlerDefinitions : UObject {
	struct TArray<struct FNetBlobHandlerDefinition> NetBlobHandlerDefinitions; // 0x28(0x10)
};

// Class IrisCore.NetObjectBlobHandler
// Size: 0x38 (Inherited: 0x38)
struct UNetObjectBlobHandler : UNetBlobHandler {
};

// Class IrisCore.NetObjectConnectionFilterConfig
// Size: 0x38 (Inherited: 0x30)
struct UNetObjectConnectionFilterConfig : UNetObjectFilterConfig {
	uint16_t MaxObjectCount; // 0x30(0x02)
	char pad_32[0x6]; // 0x32(0x06)
};

// Class IrisCore.NetObjectConnectionFilter
// Size: 0xa0 (Inherited: 0x50)
struct UNetObjectConnectionFilter : UNetObjectFilter {
	char pad_50[0x50]; // 0x50(0x50)
};

// Class IrisCore.NetObjectPrioritizerConfig
// Size: 0x28 (Inherited: 0x28)
struct UNetObjectPrioritizerConfig : UObject {
};

// Class IrisCore.NetObjectCountLimiterConfig
// Size: 0x40 (Inherited: 0x28)
struct UNetObjectCountLimiterConfig : UNetObjectPrioritizerConfig {
	enum class ENetObjectCountLimiterMode Mode; // 0x28(0x04)
	uint32_t MaxObjectCount; // 0x2c(0x04)
	float Priority; // 0x30(0x04)
	float OwningConnectionPriority; // 0x34(0x04)
	bool bEnableOwnedObjectsFastLane; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class IrisCore.NetObjectCountLimiter
// Size: 0x90 (Inherited: 0x28)
struct UNetObjectCountLimiter : UNetObjectPrioritizer {
	char pad_28[0x68]; // 0x28(0x68)
};

// Class IrisCore.NetObjectFilterDefinitions
// Size: 0x38 (Inherited: 0x28)
struct UNetObjectFilterDefinitions : UObject {
	struct TArray<struct FNetObjectFilterDefinition> NetObjectFilterDefinitions; // 0x28(0x10)
};

// Class IrisCore.NetObjectGridFilterConfig
// Size: 0x78 (Inherited: 0x30)
struct UNetObjectGridFilterConfig : UNetObjectFilterConfig {
	uint32_t ViewPosRelevancyFrameCount; // 0x30(0x04)
	float CellSizeX; // 0x34(0x04)
	float CellSizeY; // 0x38(0x04)
	float MaxCullDistance; // 0x3c(0x04)
	float DefaultCullDistance; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FVector MinPos; // 0x48(0x18)
	struct FVector MaxPos; // 0x60(0x18)
};

// Class IrisCore.NetObjectGridFilter
// Size: 0xf8 (Inherited: 0x50)
struct UNetObjectGridFilter : UNetObjectFilter {
	char pad_50[0xa8]; // 0x50(0xa8)
};

// Class IrisCore.NetObjectGridWorldLocFilter
// Size: 0x100 (Inherited: 0xf8)
struct UNetObjectGridWorldLocFilter : UNetObjectGridFilter {
	char pad_F8[0x8]; // 0xf8(0x08)
};

// Class IrisCore.NetObjectGridFragmentLocFilter
// Size: 0x148 (Inherited: 0xf8)
struct UNetObjectGridFragmentLocFilter : UNetObjectGridFilter {
	char pad_F8[0x50]; // 0xf8(0x50)
};

// Class IrisCore.NetObjectPrioritizerDefinitions
// Size: 0x38 (Inherited: 0x28)
struct UNetObjectPrioritizerDefinitions : UObject {
	struct TArray<struct FNetObjectPrioritizerDefinition> NetObjectPrioritizerDefinitions; // 0x28(0x10)
};

// Class IrisCore.NetRPCHandler
// Size: 0x40 (Inherited: 0x38)
struct UNetRPCHandler : UNetBlobHandler {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class IrisCore.NetTokenDataStream
// Size: 0x78 (Inherited: 0x28)
struct UNetTokenDataStream : UDataStream {
	char pad_28[0x50]; // 0x28(0x50)
};

// Class IrisCore.NopNetObjectFilterConfig
// Size: 0x30 (Inherited: 0x30)
struct UNopNetObjectFilterConfig : UNetObjectFilterConfig {
};

// Class IrisCore.NopNetObjectFilter
// Size: 0x50 (Inherited: 0x50)
struct UNopNetObjectFilter : UNetObjectFilter {
};

// Class IrisCore.ReplicationBridge
// Size: 0x110 (Inherited: 0x28)
struct UReplicationBridge : UObject {
	char pad_28[0xe8]; // 0x28(0xe8)
};

// Class IrisCore.ObjectReplicationBridge
// Size: 0x4b0 (Inherited: 0x110)
struct UObjectReplicationBridge : UReplicationBridge {
	char pad_110[0x3a0]; // 0x110(0x3a0)
};

// Class IrisCore.ObjectReplicationBridgeConfig
// Size: 0x70 (Inherited: 0x28)
struct UObjectReplicationBridgeConfig : UObject {
	struct TArray<struct FObjectReplicationBridgePollConfig> PollConfigs; // 0x28(0x10)
	struct TArray<struct FObjectReplicationBridgeFilterConfig> FilterConfigs; // 0x38(0x10)
	struct TArray<struct FObjectReplicationBridgePrioritizerConfig> PrioritizerConfigs; // 0x48(0x10)
	struct TArray<struct FObjectReplicationBridgeDeltaCompressionConfig> DeltaCompressionConfigs; // 0x58(0x10)
	struct FName DefaultSpatialFilterName; // 0x68(0x04)
	struct FName RequiredNetDriverChannelClassName; // 0x6c(0x04)
};

// Class IrisCore.SequentialPartialNetBlobHandlerConfig
// Size: 0x30 (Inherited: 0x28)
struct USequentialPartialNetBlobHandlerConfig : UObject {
	uint32_t MaxPartBitCount; // 0x28(0x04)
	uint32_t MaxPartCount; // 0x2c(0x04)
};

// Class IrisCore.PartialNetObjectAttachmentHandlerConfig
// Size: 0x38 (Inherited: 0x30)
struct UPartialNetObjectAttachmentHandlerConfig : USequentialPartialNetBlobHandlerConfig {
	uint32_t BitCountSplitThreshold; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class IrisCore.SequentialPartialNetBlobHandler
// Size: 0x48 (Inherited: 0x38)
struct USequentialPartialNetBlobHandler : UNetBlobHandler {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class IrisCore.PartialNetObjectAttachmentHandler
// Size: 0x48 (Inherited: 0x48)
struct UPartialNetObjectAttachmentHandler : USequentialPartialNetBlobHandler {
};

// Class IrisCore.ReplicationDataStream
// Size: 0x38 (Inherited: 0x28)
struct UReplicationDataStream : UDataStream {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class IrisCore.ReplicationSystem
// Size: 0x58 (Inherited: 0x28)
struct UReplicationSystem : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct UReplicationBridge* ReplicationBridge; // 0x38(0x08)
	char pad_40[0x18]; // 0x40(0x18)
};

// Class IrisCore.SphereNetObjectPrioritizerConfig
// Size: 0x40 (Inherited: 0x28)
struct USphereNetObjectPrioritizerConfig : UNetObjectPrioritizerConfig {
	float InnerRadius; // 0x28(0x04)
	float OuterRadius; // 0x2c(0x04)
	float InnerPriority; // 0x30(0x04)
	float OuterPriority; // 0x34(0x04)
	float OutsidePriority; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class IrisCore.SphereNetObjectPrioritizer
// Size: 0x68 (Inherited: 0x60)
struct USphereNetObjectPrioritizer : ULocationBasedNetObjectPrioritizer {
	char pad_60[0x8]; // 0x60(0x08)
};

// Class IrisCore.SphereWithOwnerBoostNetObjectPrioritizerConfig
// Size: 0x48 (Inherited: 0x40)
struct USphereWithOwnerBoostNetObjectPrioritizerConfig : USphereNetObjectPrioritizerConfig {
	float OwnerPriorityBoost; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class IrisCore.SphereWithOwnerBoostNetObjectPrioritizer
// Size: 0xa0 (Inherited: 0x68)
struct USphereWithOwnerBoostNetObjectPrioritizer : USphereNetObjectPrioritizer {
	char pad_68[0x38]; // 0x68(0x38)
};

// Class IrisCore.ReplicationStateDescriptorConfig
// Size: 0x38 (Inherited: 0x28)
struct UReplicationStateDescriptorConfig : UObject {
	struct TArray<struct FSupportsStructNetSerializerConfig> SupportsStructNetSerializerList; // 0x28(0x10)
};

