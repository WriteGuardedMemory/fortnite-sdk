// Class GeometryCache.GeometryCache
// Size: 0x90 (Inherited: 0x28)
struct UGeometryCache : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct UMaterialInterface*> Materials; // 0x30(0x10)
	struct TArray<struct FName> MaterialSlotNames; // 0x40(0x10)
	struct TArray<struct UGeometryCacheTrack*> Tracks; // 0x50(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x60(0x10)
	char pad_70[0x10]; // 0x70(0x10)
	int32_t StartFrame; // 0x80(0x04)
	int32_t EndFrame; // 0x84(0x04)
	uint64_t Hash; // 0x88(0x08)
};

// Class GeometryCache.GeometryCacheActor
// Size: 0x298 (Inherited: 0x290)
struct AGeometryCacheActor : AActor {
	struct UGeometryCacheComponent* GeometryCacheComponent; // 0x290(0x08)

	struct UGeometryCacheComponent* GetGeometryCacheComponent(); // Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x35cd9c0
};

// Class GeometryCache.GeometryCacheCodecBase
// Size: 0x38 (Inherited: 0x28)
struct UGeometryCacheCodecBase : UObject {
	struct TArray<int32_t> TopologyRanges; // 0x28(0x10)
};

// Class GeometryCache.GeometryCacheCodecRaw
// Size: 0x40 (Inherited: 0x38)
struct UGeometryCacheCodecRaw : UGeometryCacheCodecBase {
	int32_t DummyProperty; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class GeometryCache.GeometryCacheCodecV1
// Size: 0x40 (Inherited: 0x38)
struct UGeometryCacheCodecV1 : UGeometryCacheCodecBase {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class GeometryCache.GeometryCacheComponent
// Size: 0x630 (Inherited: 0x5a0)
struct UGeometryCacheComponent : UMeshComponent {
	struct UGeometryCache* GeometryCache; // 0x5a0(0x08)
	bool bRunning; // 0x5a8(0x01)
	bool bLooping; // 0x5a9(0x01)
	bool bExtrapolateFrames; // 0x5aa(0x01)
	char pad_5AB[0x1]; // 0x5ab(0x01)
	float StartTimeOffset; // 0x5ac(0x04)
	float PlaybackSpeed; // 0x5b0(0x04)
	float MotionVectorScale; // 0x5b4(0x04)
	int32_t NumTracks; // 0x5b8(0x04)
	float ElapsedTime; // 0x5bc(0x04)
	char pad_5C0[0x4c]; // 0x5c0(0x4c)
	float Duration; // 0x60c(0x04)
	bool bManualTick; // 0x610(0x01)
	bool bOverrideWireframeColor; // 0x611(0x01)
	char pad_612[0x2]; // 0x612(0x02)
	struct FLinearColor WireframeOverrideColor; // 0x614(0x10)
	char pad_624[0xc]; // 0x624(0x0c)

	void TickAtThisTime(float Time, bool bInIsRunning, bool bInBackwards, bool bInIsLooping); // Function GeometryCache.GeometryCacheComponent.TickAtThisTime // (Final|Native|Public|BlueprintCallable) // @ game+0xad471f0
	void Stop(); // Function GeometryCache.GeometryCacheComponent.Stop // (Final|Native|Public|BlueprintCallable) // @ game+0xad47ec0
	void SetWireframeOverrideColor(struct FLinearColor Color); // Function GeometryCache.GeometryCacheComponent.SetWireframeOverrideColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xad474f0
	void SetStartTimeOffset(float NewStartTimeOffset); // Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset // (Final|Native|Public|BlueprintCallable) // @ game+0xad477a0
	void SetPlaybackSpeed(float NewPlaybackSpeed); // Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed // (Final|Native|Public|BlueprintCallable) // @ game+0xad47b00
	void SetOverrideWireframeColor(bool bOverride); // Function GeometryCache.GeometryCacheComponent.SetOverrideWireframeColor // (Final|Native|Public|BlueprintCallable) // @ game+0xad475f0
	void SetMotionVectorScale(float NewMotionVectorScale); // Function GeometryCache.GeometryCacheComponent.SetMotionVectorScale // (Final|Native|Public|BlueprintCallable) // @ game+0xad479c0
	void SetLooping(bool bNewLooping); // Function GeometryCache.GeometryCacheComponent.SetLooping // (Final|Native|Public|BlueprintCallable) // @ game+0xad47d50
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache); // Function GeometryCache.GeometryCacheComponent.SetGeometryCache // (Final|Native|Public|BlueprintCallable) // @ game+0xad478d0
	void SetExtrapolateFrames(bool bNewExtrapolating); // Function GeometryCache.GeometryCacheComponent.SetExtrapolateFrames // (Final|Native|Public|BlueprintCallable) // @ game+0xad47c40
	void PlayReversedFromEnd(); // Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd // (Final|Native|Public|BlueprintCallable) // @ game+0xad47f10
	void PlayReversed(); // Function GeometryCache.GeometryCacheComponent.PlayReversed // (Final|Native|Public|BlueprintCallable) // @ game+0xad47f70
	void PlayFromStart(); // Function GeometryCache.GeometryCacheComponent.PlayFromStart // (Final|Native|Public|BlueprintCallable) // @ game+0xad47fc0
	void Play(); // Function GeometryCache.GeometryCacheComponent.Play // (Final|Native|Public|BlueprintCallable) // @ game+0xad48020
	void Pause(); // Function GeometryCache.GeometryCacheComponent.Pause // (Final|Native|Public|BlueprintCallable) // @ game+0xad47ee0
	bool IsPlayingReversed(); // Function GeometryCache.GeometryCacheComponent.IsPlayingReversed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47e60
	bool IsPlaying(); // Function GeometryCache.GeometryCacheComponent.IsPlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47ea0
	bool IsLooping(); // Function GeometryCache.GeometryCacheComponent.IsLooping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47e40
	bool IsExtrapolatingFrames(); // Function GeometryCache.GeometryCacheComponent.IsExtrapolatingFrames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47d30
	struct FLinearColor GetWireframeOverrideColor(); // Function GeometryCache.GeometryCacheComponent.GetWireframeOverrideColor // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xad474c0
	float GetStartTimeOffset(); // Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad478b0
	float GetPlaybackSpeed(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47c00
	float GetPlaybackDirection(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackDirection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47740
	bool GetOverrideWireframeColor(); // Function GeometryCache.GeometryCacheComponent.GetOverrideWireframeColor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad475d0
	int32_t GetNumberOfFrames(); // Function GeometryCache.GeometryCacheComponent.GetNumberOfFrames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad476e0
	float GetMotionVectorScale(); // Function GeometryCache.GeometryCacheComponent.GetMotionVectorScale // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47ac0
	float GetDuration(); // Function GeometryCache.GeometryCacheComponent.GetDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47720
	float GetAnimationTime(); // Function GeometryCache.GeometryCacheComponent.GetAnimationTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad47760
};

// Class GeometryCache.GeometryCacheTrack
// Size: 0x58 (Inherited: 0x28)
struct UGeometryCacheTrack : UObject {
	float Duration; // 0x28(0x04)
	char pad_2C[0x2c]; // 0x2c(0x2c)
};

// Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0x80 (Inherited: 0x58)
struct UGeometryCacheTrack_FlipbookAnimation : UGeometryCacheTrack {
	uint32_t NumMeshSamples; // 0x58(0x04)
	char pad_5C[0x24]; // 0x5c(0x24)

	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime); // Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample // (Final|Native|Public|HasOutParms) // @ game+0xad51ab0
};

// Class GeometryCache.GeometryCacheTrackStreamable
// Size: 0xd8 (Inherited: 0x58)
struct UGeometryCacheTrackStreamable : UGeometryCacheTrack {
	struct UGeometryCacheCodecBase* Codec; // 0x58(0x08)
	char pad_60[0x68]; // 0x60(0x68)
	float StartSampleTime; // 0xc8(0x04)
	char pad_CC[0xc]; // 0xcc(0x0c)
};

// Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0x120 (Inherited: 0x58)
struct UGeometryCacheTrack_TransformAnimation : UGeometryCacheTrack {
	char pad_58[0xc8]; // 0x58(0xc8)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh // (Final|Native|Public|HasOutParms) // @ game+0xad53520
};

// Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0x120 (Inherited: 0x58)
struct UGeometryCacheTrack_TransformGroupAnimation : UGeometryCacheTrack {
	char pad_58[0xc8]; // 0x58(0xc8)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh // (Final|Native|Public|HasOutParms) // @ game+0xad53520
};

// Class GeometryCache.NiagaraGeometryCacheRendererProperties
// Size: 0x268 (Inherited: 0xb0)
struct UNiagaraGeometryCacheRendererProperties : UNiagaraRendererProperties {
	struct TArray<struct FNiagaraGeometryCacheReference> GeometryCaches; // 0xb0(0x10)
	enum class ENiagaraRendererSourceDataMode SourceMode; // 0xc0(0x01)
	bool bIsLooping; // 0xc1(0x01)
	char pad_C2[0x2]; // 0xc2(0x02)
	uint32_t ComponentCountLimit; // 0xc4(0x04)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0xc8(0x28)
	struct FNiagaraVariableAttributeBinding RotationBinding; // 0xf0(0x28)
	struct FNiagaraVariableAttributeBinding ScaleBinding; // 0x118(0x28)
	struct FNiagaraVariableAttributeBinding ElapsedTimeBinding; // 0x140(0x28)
	struct FNiagaraVariableAttributeBinding EnabledBinding; // 0x168(0x28)
	struct FNiagaraVariableAttributeBinding ArrayIndexBinding; // 0x190(0x28)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x1b8(0x28)
	int32_t RendererVisibility; // 0x1e0(0x04)
	bool bAssignComponentsOnParticleID; // 0x1e4(0x01)
	char pad_1E5[0x3]; // 0x1e5(0x03)
	struct FNiagaraRendererMaterialParameters MaterialParameters; // 0x1e8(0x50)
	char pad_238[0x30]; // 0x238(0x30)
};

