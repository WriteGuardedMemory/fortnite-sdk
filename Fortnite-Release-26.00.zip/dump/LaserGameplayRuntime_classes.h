// Class LaserGameplayRuntime.LaserCapsuleComponent
// Size: 0x5a0 (Inherited: 0x590)
struct ULaserCapsuleComponent : UCapsuleComponent {
	enum class ECollisionEnabled CollisionWhenEnabled; // 0x590(0x01)
	enum class ECollisionEnabled CollisionWhenDisabled; // 0x591(0x01)
	char pad_592[0xe]; // 0x592(0x0e)
};

// Class LaserGameplayRuntime.LaserGridEditorComponent
// Size: 0xa8 (Inherited: 0xa0)
struct ULaserGridEditorComponent : UActorComponent {
	int32_t VisualizeLaserGridPatternIndex; // 0xa0(0x04)
	bool bVisualizeOutletIndex; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
};

// Class LaserGameplayRuntime.BuildingGameplayActorLaserGrid
// Size: 0xd90 (Inherited: 0x978)
struct ABuildingGameplayActorLaserGrid : ABuildingGameplayActor {
	struct FMulticastInlineDelegate OnLaserGridTriggered; // 0x978(0x10)
	struct FMulticastInlineDelegate OnLaserGridOutletDestroyed; // 0x988(0x10)
	struct TArray<struct FLaserGridPattern> LaserGridPatterns; // 0x998(0x10)
	float LaserPatternChangeWarningTime; // 0x9a8(0x04)
	char pad_9AC[0x4]; // 0x9ac(0x04)
	struct TMap<int32_t, struct ABuildingActor*> LaserOutletToBuildingAttachmentMap; // 0x9b0(0x50)
	struct FGameplayTagContainer IgnoreActorTags; // 0xa00(0x20)
	struct ULaserCapsuleComponent* LaserCapsuleComponentClass; // 0xa20(0x08)
	struct FRotator LaserCapsuleCollisionRotationOffset; // 0xa28(0x18)
	int32_t LaserCustomDataIndexForRandomizedVisuals; // 0xa40(0x04)
	char pad_A44[0x4]; // 0xa44(0x04)
	struct FLaserGridConnectionArray LaserGridConnections; // 0xa48(0x118)
	struct TArray<struct FLaserGridConnectionEntry> LocalLaserGridConnections; // 0xb60(0x10)
	struct FTransform LaserConnectionOffset; // 0xb70(0x60)
	struct FVector LaserOutletConnectionOffset; // 0xbd0(0x18)
	struct USoundBase* SoundOutletTransitionOn; // 0xbe8(0x08)
	struct USoundBase* SoundLaserTransitionPrimaryOutlet; // 0xbf0(0x08)
	struct USoundBase* SoundLaserTransitionSecondaryOutlet; // 0xbf8(0x08)
	struct USoundBase* SoundLaserTransition; // 0xc00(0x08)
	int32_t OutletMaterialCustomDataIndex_EmissiveEnabled; // 0xc08(0x04)
	int32_t OutletMaterialCustomDataIndex_DisableEmissivePulse; // 0xc0c(0x04)
	int32_t OutletMaterialCustomDataIndex_AnimTimestamp; // 0xc10(0x04)
	int32_t OutletMaterialCustomDataIndex_AnimTimestampDuration; // 0xc14(0x04)
	float MaterialCosineWavePeriod; // 0xc18(0x04)
	char pad_C1C[0x4]; // 0xc1c(0x04)
	struct FVector2D OutletMaterialTransitionOffTimestampOffset; // 0xc20(0x10)
	int32_t LaserMaterialCustomDataIndex_PulseEnabled; // 0xc30(0x04)
	int32_t LaserMaterialCustomDataIndex_RandomFlickeringSpeed; // 0xc34(0x04)
	int32_t LaserMaterialCustomDataIndex_AnimTimestamp; // 0xc38(0x04)
	int32_t LaserMaterialCustomDataIndex_PulseTimeOffset; // 0xc3c(0x04)
	struct FVector2D LaserMaterialRandomFlickeringSpeed; // 0xc40(0x10)
	struct FLaserGridOutletArray LaserGridOutlets; // 0xc50(0x120)
	struct UHierarchicalInstancedStaticMeshComponent* HISMComponentOutlet; // 0xd70(0x08)
	struct UHierarchicalInstancedStaticMeshComponent* HISMComponentLaser; // 0xd78(0x08)
	bool bEnabled; // 0xd80(0x01)
	char pad_D81[0x3]; // 0xd81(0x03)
	int32_t LaserGridPatternIndex; // 0xd84(0x04)
	struct FTimerHandle LaserPatternTimerHandle; // 0xd88(0x08)

	void SetLaserGridEnable(bool bEnable); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.SetLaserGridEnable // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0x34b0aa0
	void OnRep_LaserGridConnections(); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.OnRep_LaserGridConnections // (Final|Native|Private) // @ game+0xa96e1b0
	void OnRep_bEnabled(); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.OnRep_bEnabled // (Final|Native|Private) // @ game+0xa96e1d0
	void LaserGridTriggered(struct FLaserGridConnectionEntry& LaserConnectionData, struct AActor* TriggeringActor); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.LaserGridTriggered // (BlueprintAuthorityOnly|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void LaserGridStateUpdated(bool bLaserGridEnabled); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.LaserGridStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandlePatternTimerComplete_PreTransition(); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.HandlePatternTimerComplete_PreTransition // (Final|Native|Private) // @ game+0x3982d70
	void HandlePatternTimerComplete_PostTransition(); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.HandlePatternTimerComplete_PostTransition // (Final|Native|Private) // @ game+0x3982d70
	void HandleLaserCollisionOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.HandleLaserCollisionOverlap // (Final|Native|Private|HasOutParms) // @ game+0x6fe0d40
	void HandleAttachedBuildingActorDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector Momentum); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.HandleAttachedBuildingActorDied // (Final|Native|Private|HasDefaults) // @ game+0x78001f0
	void GetActiveLaserGridConnections(struct TArray<struct FLaserGridConnectionEntry>& OutActiveLaserGridConnections); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.GetActiveLaserGridConnections // (Final|Native|Public|HasOutParms|BlueprintCallable|Const) // @ game+0xa96e330
	void CosmeticDestroyOutletInstance(struct FLaserGridOutletEntry& OutletEntry); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.CosmeticDestroyOutletInstance // (BlueprintCosmetic|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	bool CanActorTriggerLaserGrid(struct AActor* TriggeringActor); // Function LaserGameplayRuntime.BuildingGameplayActorLaserGrid.CanActorTriggerLaserGrid // (BlueprintAuthorityOnly|Native|Event|Protected|BlueprintEvent|Const) // @ game+0xa96e230
};

