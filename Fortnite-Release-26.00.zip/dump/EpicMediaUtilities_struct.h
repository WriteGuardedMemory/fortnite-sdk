// ScriptStruct EpicMediaUtilities.EpicMediaImageDataExt
// Size: 0x30 (Inherited: 0x00)
struct FEpicMediaImageDataExt {
	struct FString URL; // 0x00(0x10)
	struct FString FullUrl; // 0x10(0x10)
	int32_t Width; // 0x20(0x04)
	int32_t Height; // 0x24(0x04)
	float AspectRatio; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct EpicMediaUtilities.EpicMediaAudioOnlyPeriodDataExt
// Size: 0x28 (Inherited: 0x00)
struct FEpicMediaAudioOnlyPeriodDataExt {
	struct FLinearColor Color; // 0x00(0x10)
	bool bColorSet; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	double StartFrame; // 0x18(0x08)
	double EndFrame; // 0x20(0x08)
};

// ScriptStruct EpicMediaUtilities.EpicMediaVolumeChangeDataExt
// Size: 0x28 (Inherited: 0x00)
struct FEpicMediaVolumeChangeDataExt {
	double Frame; // 0x00(0x08)
	double Level; // 0x08(0x08)
	double Lerp; // 0x10(0x08)
	char pad_18[0x10]; // 0x18(0x10)
};

// ScriptStruct EpicMediaUtilities.EpicMediaPlaylistExt
// Size: 0xa0 (Inherited: 0x00)
struct FEpicMediaPlaylistExt {
	struct FString Language; // 0x00(0x10)
	struct FString Type; // 0x10(0x10)
	struct FString URL; // 0x20(0x10)
	struct FString RelUrl; // 0x30(0x10)
	struct FString Data; // 0x40(0x10)
	double Duration; // 0x50(0x08)
	double FPS; // 0x58(0x08)
	struct TArray<struct FEpicMediaImageDataExt> Images; // 0x60(0x10)
	struct TArray<struct FEpicMediaAudioOnlyPeriodDataExt> AudioOnlyPeriods; // 0x70(0x10)
	struct TArray<struct FEpicMediaVolumeChangeDataExt> VolumeChanges; // 0x80(0x10)
	double SkipBoundaryTime; // 0x90(0x08)
	double PreEndEventTime; // 0x98(0x08)
};

// ScriptStruct EpicMediaUtilities.EpicMediaRegionLockExt
// Size: 0xa8 (Inherited: 0x00)
struct FEpicMediaRegionLockExt {
	bool AllowOnError; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Type; // 0x08(0x10)
	struct TArray<struct FString> AllowList; // 0x18(0x10)
	struct TArray<struct FString> DenyList; // 0x28(0x10)
	struct TMap<struct FString, struct FString> Limits; // 0x38(0x50)
	struct FString ContentId; // 0x88(0x10)
	char pad_98[0x10]; // 0x98(0x10)
};

// ScriptStruct EpicMediaUtilities.EpicMediaAudioMetadataTrackIndicesExt
// Size: 0x10 (Inherited: 0x00)
struct FEpicMediaAudioMetadataTrackIndicesExt {
	struct TArray<int32_t> Indices; // 0x00(0x10)
};

// ScriptStruct EpicMediaUtilities.EpicMediaAudioMetadataTrackExt
// Size: 0x50 (Inherited: 0x00)
struct FEpicMediaAudioMetadataTrackExt {
	struct TMap<struct FString, struct FEpicMediaAudioMetadataTrackIndicesExt> TrackData; // 0x00(0x50)
};

// ScriptStruct EpicMediaUtilities.EpicMediaAudioMetadataDataExt
// Size: 0xb0 (Inherited: 0x00)
struct FEpicMediaAudioMetadataDataExt {
	struct FString ShortName; // 0x00(0x10)
	int32_t SongID; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Title; // 0x18(0x10)
	struct FString Artist; // 0x28(0x10)
	struct FString Album; // 0x38(0x10)
	struct FString Genre; // 0x48(0x10)
	int32_t Year; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct TMap<struct FString, int32_t> Difficulty; // 0x60(0x50)
};

// ScriptStruct EpicMediaUtilities.EpicMediaAudioMetadataExt
// Size: 0x130 (Inherited: 0x00)
struct FEpicMediaAudioMetadataExt {
	struct TMap<struct FString, struct FEpicMediaAudioMetadataTrackIndicesExt> Tracks; // 0x00(0x50)
	struct TArray<float> Pans; // 0x50(0x10)
	struct TArray<float> Volumes; // 0x60(0x10)
	struct TArray<char> Midi; // 0x70(0x10)
	struct FEpicMediaAudioMetadataDataExt MetadataData; // 0x80(0xb0)
};

// ScriptStruct EpicMediaUtilities.EpicMediaMetadataExt
// Size: 0x290 (Inherited: 0x00)
struct FEpicMediaMetadataExt {
	struct TArray<struct FEpicMediaPlaylistExt> Playlists; // 0x00(0x10)
	struct TArray<struct FEpicMediaPlaylistExt> StateStreamPlaylists; // 0x10(0x10)
	struct TArray<struct FEpicMediaPlaylistExt> SelectedPlaylists; // 0x20(0x10)
	struct FString Type; // 0x30(0x10)
	struct FString Envelope; // 0x40(0x10)
	struct FString Limits; // 0x50(0x10)
	struct FString Subtitles; // 0x60(0x10)
	struct FString UserContentProtection; // 0x70(0x10)
	bool Sharelock; // 0x80(0x01)
	bool AudioOnly; // 0x81(0x01)
	char pad_82[0x2]; // 0x82(0x02)
	float AspectRatio; // 0x84(0x04)
	bool PartySync; // 0x88(0x01)
	bool Live; // 0x89(0x01)
	char pad_8A[0x6]; // 0x8a(0x06)
	struct FString DenyHTTPCode; // 0x90(0x10)
	struct FEpicMediaRegionLockExt RegionLockData; // 0xa0(0xa8)
	struct FEpicMediaAudioMetadataExt AudioMetadata; // 0x148(0x130)
	bool bQuicksilverEP; // 0x278(0x01)
	char pad_279[0x17]; // 0x279(0x17)
};

