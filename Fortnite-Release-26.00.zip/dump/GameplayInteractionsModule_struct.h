// Enum GameplayInteractionsModule.EGameplayTaskActuationResult
enum class EGameplayTaskActuationResult : uint8 {
	None = 0,
	RequestFailed = 1,
	Failed = 2,
	Succeeded = 3,
	EGameplayTaskActuationResult_MAX = 4
};

// Enum GameplayInteractionsModule.EGameplayInteractionAbortReason
enum class EGameplayInteractionAbortReason : uint8 {
	Unset = 0,
	ExternalAbort = 1,
	InternalAbort = 2,
	EGameplayInteractionAbortReason_MAX = 3
};

// Enum GameplayInteractionsModule.EGameplayInteractionModifyGameplayTagOperation
enum class EGameplayInteractionModifyGameplayTagOperation : uint8 {
	Add = 0,
	Remove = 1,
	EGameplayInteractionModifyGameplayTagOperation_MAX = 2
};

// Enum GameplayInteractionsModule.EGameplayInteractionTaskModify
enum class EGameplayInteractionTaskModify : uint8 {
	OnEnterStateUndoOnExitState = 0,
	OnEnterState = 1,
	OnExitState = 2,
	OnExitStateFailed = 3,
	OnExitStateSucceeded = 4,
	EGameplayInteractionTaskModify_MAX = 5
};

// Enum GameplayInteractionsModule.EGameplayInteractionTaskTrigger
enum class EGameplayInteractionTaskTrigger : uint8 {
	OnEnterState = 0,
	OnExitState = 1,
	OnExitStateFailed = 2,
	OnExitStateSucceeded = 3,
	EGameplayInteractionTaskTrigger_MAX = 4
};

// Enum GameplayInteractionsModule.EGameplayInteractionMatchSlotTagSource
enum class EGameplayInteractionMatchSlotTagSource : uint8 {
	ActivityTags = 0,
	RuntimeTags = 1,
	EGameplayInteractionMatchSlotTagSource_MAX = 2
};

// Enum GameplayInteractionsModule.EGameplayInteractionSlotReferenceType
enum class EGameplayInteractionSlotReferenceType : uint8 {
	ByActivityTag = 0,
	ByLinkTag = 1,
	EGameplayInteractionSlotReferenceType_MAX = 2
};

// Enum GameplayInteractionsModule.EGameplayInteractionSyncSlotTransitionState
enum class EGameplayInteractionSyncSlotTransitionState : uint8 {
	WaitingForFromTag = 0,
	WaitingForToTag = 1,
	Completed = 2,
	EGameplayInteractionSyncSlotTransitionState_MAX = 3
};

// Enum GameplayInteractionsModule.EPlayContextualAnimExecutionMethod
enum class EPlayContextualAnimExecutionMethod : uint8 {
	StartInteraction = 0,
	JoinInteraction = 1,
	TransitionAllActors = 2,
	TransitionSingleActor = 3,
	EPlayContextualAnimExecutionMethod_MAX = 4
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionContext
// Size: 0x68 (Inherited: 0x00)
struct FGameplayInteractionContext {
	struct FStateTreeInstanceData StateTreeInstanceData; // 0x00(0x10)
	struct FSmartObjectClaimHandle ClaimedHandle; // 0x10(0x20)
	struct FSmartObjectSlotEntranceHandle SlotEntranceHandle; // 0x30(0x18)
	struct FGameplayInteractionAbortContext AbortContext; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct AActor* ContextActor; // 0x50(0x08)
	struct AActor* SmartObjectActor; // 0x58(0x08)
	struct UGameplayInteractionSmartObjectBehaviorDefinition* Definition; // 0x60(0x08)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionAbortContext
// Size: 0x01 (Inherited: 0x00)
struct FGameplayInteractionAbortContext {
	enum class EGameplayInteractionAbortReason Reason; // 0x00(0x01)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSlotUserData
// Size: 0x08 (Inherited: 0x01)
struct FGameplayInteractionSlotUserData : FSmartObjectSlotStateData {
	char pad_1[0x7]; // 0x01(0x07)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FGameplayInteractionStateTreeTask : FStateTreeTaskBase {
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionStateTreeCondition
// Size: 0x20 (Inherited: 0x20)
struct FGameplayInteractionStateTreeCondition : FStateTreeConditionBase {
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionMatchSlotTagsConditionInstanceData
// Size: 0x30 (Inherited: 0x00)
struct FGameplayInteractionMatchSlotTagsConditionInstanceData {
	struct FSmartObjectSlotHandle Slot; // 0x00(0x10)
	struct FGameplayTagContainer TagsToMatch; // 0x10(0x20)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSlotTagsMatchCondition
// Size: 0x28 (Inherited: 0x20)
struct FGameplayInteractionSlotTagsMatchCondition : FGameplayInteractionStateTreeCondition {
	enum class EGameplayInteractionMatchSlotTagSource Source; // 0x20(0x01)
	enum class EGameplayContainerMatchType MatchType; // 0x21(0x01)
	bool bExactMatch; // 0x22(0x01)
	bool bInvert; // 0x23(0x01)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionQuerySlotTagsConditionInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FGameplayInteractionQuerySlotTagsConditionInstanceData {
	struct FSmartObjectSlotHandle Slot; // 0x00(0x10)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionQuerySlotTagCondition
// Size: 0x78 (Inherited: 0x20)
struct FGameplayInteractionQuerySlotTagCondition : FGameplayInteractionStateTreeCondition {
	enum class EGameplayInteractionMatchSlotTagSource Source; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FGameplayTagQuery TagQuery; // 0x28(0x48)
	bool bInvert; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionIsSlotHandleValidConditionInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FGameplayInteractionIsSlotHandleValidConditionInstanceData {
	struct FSmartObjectSlotHandle Slot; // 0x00(0x10)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionIsSlotHandleValidCondition
// Size: 0x28 (Inherited: 0x20)
struct FGameplayInteractionIsSlotHandleValidCondition : FGameplayInteractionStateTreeCondition {
	bool bInvert; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionFindSlotTaskInstanceData
// Size: 0x20 (Inherited: 0x00)
struct FGameplayInteractionFindSlotTaskInstanceData {
	struct FSmartObjectSlotHandle ReferenceSlot; // 0x00(0x10)
	struct FSmartObjectSlotHandle ResultSlot; // 0x10(0x10)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionFindSlotTask
// Size: 0x30 (Inherited: 0x20)
struct FGameplayInteractionFindSlotTask : FGameplayInteractionStateTreeTask {
	enum class EGameplayInteractionSlotReferenceType ReferenceType; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	struct FGameplayTag FindByTag; // 0x24(0x04)
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionGetSlotActorTaskInstanceData
// Size: 0x18 (Inherited: 0x00)
struct FGameplayInteractionGetSlotActorTaskInstanceData {
	struct FSmartObjectSlotHandle TargetSlot; // 0x00(0x10)
	struct AActor* ResultActor; // 0x10(0x08)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionGetSlotActorTask
// Size: 0x28 (Inherited: 0x20)
struct FGameplayInteractionGetSlotActorTask : FGameplayInteractionStateTreeTask {
	bool bFailIfNotFound; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionListenSlotEventsTaskInstanceData
// Size: 0x18 (Inherited: 0x00)
struct FGameplayInteractionListenSlotEventsTaskInstanceData {
	struct FSmartObjectSlotHandle TargetSlot; // 0x00(0x10)
	char pad_10[0x8]; // 0x10(0x08)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionListenSlotEventsTask
// Size: 0x28 (Inherited: 0x20)
struct FGameplayInteractionListenSlotEventsTask : FGameplayInteractionStateTreeTask {
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionModifySlotTagTaskInstanceData
// Size: 0x18 (Inherited: 0x00)
struct FGameplayInteractionModifySlotTagTaskInstanceData {
	struct FSmartObjectSlotHandle TargetSlot; // 0x00(0x10)
	bool bTagRemoved; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionModifySlotTagTask
// Size: 0x30 (Inherited: 0x20)
struct FGameplayInteractionModifySlotTagTask : FGameplayInteractionStateTreeTask {
	enum class EGameplayInteractionTaskModify Modify; // 0x20(0x01)
	bool bHandleExternalStopAsFailure; // 0x21(0x01)
	enum class EGameplayInteractionModifyGameplayTagOperation Operation; // 0x22(0x01)
	char pad_23[0x1]; // 0x23(0x01)
	struct FGameplayTag tag; // 0x24(0x04)
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSendSlotEventTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FGameplayInteractionSendSlotEventTaskInstanceData {
	struct FSmartObjectSlotHandle TargetSlot; // 0x00(0x10)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSendSlotEventTask
// Size: 0x40 (Inherited: 0x20)
struct FGameplayInteractionSendSlotEventTask : FGameplayInteractionStateTreeTask {
	struct FGameplayTag EventTag; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FInstancedStruct Payload; // 0x28(0x10)
	enum class EGameplayInteractionTaskTrigger Trigger; // 0x38(0x01)
	bool bHandleExternalStopAsFailure; // 0x39(0x01)
	bool bShouldTriggerOnReselect; // 0x3a(0x01)
	char pad_3B[0x5]; // 0x3b(0x05)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSetSlotEnabledInstanceData
// Size: 0x18 (Inherited: 0x00)
struct FGameplayInteractionSetSlotEnabledInstanceData {
	struct FSmartObjectSlotHandle TargetSlot; // 0x00(0x10)
	bool bInitialState; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSetSlotEnabledTask
// Size: 0x28 (Inherited: 0x20)
struct FGameplayInteractionSetSlotEnabledTask : FGameplayInteractionStateTreeTask {
	enum class EGameplayInteractionTaskModify Modify; // 0x20(0x01)
	bool bHandleExternalStopAsFailure; // 0x21(0x01)
	bool bEnableSlot; // 0x22(0x01)
	char pad_23[0x5]; // 0x23(0x05)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSyncSlotTagStateInstanceData
// Size: 0x20 (Inherited: 0x00)
struct FGameplayInteractionSyncSlotTagStateInstanceData {
	struct FSmartObjectSlotHandle TargetSlot; // 0x00(0x10)
	char pad_10[0x10]; // 0x10(0x10)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSyncSlotTagStateTask
// Size: 0x30 (Inherited: 0x20)
struct FGameplayInteractionSyncSlotTagStateTask : FGameplayInteractionStateTreeTask {
	struct FGameplayTag TagToMonitor; // 0x20(0x04)
	struct FGameplayTag BreakEventTag; // 0x24(0x04)
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSyncSlotTagTransitionInstanceData
// Size: 0x20 (Inherited: 0x00)
struct FGameplayInteractionSyncSlotTagTransitionInstanceData {
	struct FSmartObjectSlotHandle TargetSlot; // 0x00(0x10)
	char pad_10[0x10]; // 0x10(0x10)
};

// ScriptStruct GameplayInteractionsModule.GameplayInteractionSyncSlotTagTransitionTask
// Size: 0x30 (Inherited: 0x20)
struct FGameplayInteractionSyncSlotTagTransitionTask : FGameplayInteractionStateTreeTask {
	struct FGameplayTag TransitionFromTag; // 0x20(0x04)
	struct FGameplayTag TransitionToTag; // 0x24(0x04)
	struct FGameplayTag TransitionEventTag; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct GameplayInteractionsModule.PlayMontageStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FPlayMontageStateTreeTaskInstanceData {
	struct AActor* Actor; // 0x00(0x08)
	float ComputedDuration; // 0x08(0x04)
	float Time; // 0x0c(0x04)
};

// ScriptStruct GameplayInteractionsModule.PlayMontageStateTreeTask
// Size: 0x28 (Inherited: 0x20)
struct FPlayMontageStateTreeTask : FGameplayInteractionStateTreeTask {
	struct UAnimMontage* Montage; // 0x20(0x08)
};

// ScriptStruct GameplayInteractionsModule.StateTreeTask_FindSlotEntranceLocation_InstanceData
// Size: 0xa0 (Inherited: 0x00)
struct FStateTreeTask_FindSlotEntranceLocation_InstanceData {
	struct AActor* UserActor; // 0x00(0x08)
	struct FSmartObjectSlotHandle ReferenceSlot; // 0x08(0x10)
	char pad_18[0x8]; // 0x18(0x08)
	struct FTransform EntryTransform; // 0x20(0x60)
	struct FGameplayTagContainer EntranceTags; // 0x80(0x20)
};

// ScriptStruct GameplayInteractionsModule.StateTreeTask_FindSlotEntranceLocation
// Size: 0x38 (Inherited: 0x20)
struct FStateTreeTask_FindSlotEntranceLocation : FGameplayInteractionStateTreeTask {
	enum class FSmartObjectSlotEntrySelectionMethod SelectMethod; // 0x20(0x01)
	bool bProjectNavigationLocation; // 0x21(0x01)
	bool bTraceGroundLocation; // 0x22(0x01)
	bool bCheckTransitionTrajectory; // 0x23(0x01)
	bool bCheckEntranceLocationOverlap; // 0x24(0x01)
	bool bCheckSlotLocationOverlap; // 0x25(0x01)
	bool bUseSlotLocationAsFallbackCandidate; // 0x26(0x01)
	enum class ESmartObjectSlotNavigationLocationType LocationType; // 0x27(0x01)
	struct USmartObjectSlotValidationFilter* ValidationFilter; // 0x28(0x08)
	char pad_30[0x8]; // 0x30(0x08)
};

// ScriptStruct GameplayInteractionsModule.StateTreeTask_GetSlotEntranceLocation_InstanceData
// Size: 0x38 (Inherited: 0x00)
struct FStateTreeTask_GetSlotEntranceLocation_InstanceData {
	struct FSmartObjectSlotEntranceHandle SlotEntranceHandle; // 0x00(0x18)
	struct FGameplayTagContainer EntranceTags; // 0x18(0x20)
};

// ScriptStruct GameplayInteractionsModule.StateTreeTask_GetSlotEntranceLocation
// Size: 0x28 (Inherited: 0x20)
struct FStateTreeTask_GetSlotEntranceLocation : FGameplayInteractionStateTreeTask {
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct GameplayInteractionsModule.StateTreeTask_PlayContextualAnim
// Size: 0x20 (Inherited: 0x20)
struct FStateTreeTask_PlayContextualAnim : FStateTreeTaskCommonBase {
};

