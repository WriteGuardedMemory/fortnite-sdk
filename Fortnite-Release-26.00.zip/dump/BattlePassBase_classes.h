// Class BattlePassBase.BattlePassSubPageInterface
// Size: 0x28 (Inherited: 0x28)
struct UBattlePassSubPageInterface : UInterface {

	void OnEnterSubPage(); // Function BattlePassBase.BattlePassSubPageInterface.OnEnterSubPage // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class BattlePassBase.BattlePassLandingPageBase
// Size: 0x538 (Inherited: 0x3e8)
struct UBattlePassLandingPageBase : UCommonActivatableWidget {
	char pad_3E8[0x120]; // 0x3e8(0x120)
	struct UBattlePassLandingPageButton* LastHoveredPageButton; // 0x508(0x08)
	struct UCommonButtonGroupBase* LandingPageButtonGroupBase; // 0x510(0x08)
	char pad_518[0x20]; // 0x518(0x20)
};

// Class BattlePassBase.BattlePassLandingPageButton
// Size: 0x16f0 (Inherited: 0x1470)
struct UBattlePassLandingPageButton : UCommonButtonBase {
	enum class EBattlePassView SubPageType; // 0x1470(0x01)
	enum class EBattlePassFeatures FeatureType; // 0x1471(0x01)
	char pad_1472[0x6]; // 0x1472(0x06)
	struct FBattlePassLandingPageEntryPreviewInfo PreviewInfo; // 0x1478(0x90)
	bool bNeedsBattlePass; // 0x1508(0x01)
	char pad_1509[0x7]; // 0x1509(0x07)
	struct UFortChallengeBundleScheduleDefinition* DelayQuestSchedule; // 0x1510(0x08)
	int32_t DelayDaysSinceSeasonStart; // 0x1518(0x04)
	char pad_151C[0x4]; // 0x151c(0x04)
	struct UFortItemDefinition* RequiredItem; // 0x1520(0x08)
	struct UFortBangWrapper_NUI* BangWrapper; // 0x1528(0x08)
	bool bUsesTelemetry; // 0x1530(0x01)
	char pad_1531[0x3]; // 0x1531(0x03)
	struct FIntPoint Telemetry_Size; // 0x1534(0x08)
	struct FIntPoint Telemetry_Position; // 0x153c(0x08)
	char pad_1544[0x4]; // 0x1544(0x04)
	struct FBattlePassLandingPageButtonTexts DefaultTexts; // 0x1548(0x48)
	struct FBattlePassLandingPageButtonTexts DelayedTexts; // 0x1590(0x48)
	struct FBattlePassLandingPageButtonTexts SubscribedTexts; // 0x15d8(0x48)
	struct FBattlePassLandingPageButtonDisplayBehaviorData DisplayBehaviorData; // 0x1620(0x18)
	char pad_1638[0xb8]; // 0x1638(0xb8)

	void OnSubscriptionTextureLoaded(struct UTexture2D* Texture); // Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionTextureLoaded // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSubscriptionOwnershipUpdated(bool bOwnsSubsciption); // Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionOwnershipUpdated // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnShowDisplayDetails(); // Function BattlePassBase.BattlePassLandingPageButton.OnShowDisplayDetails // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnSetTileImageMaterial(struct UMaterialInstance* Material); // Function BattlePassBase.BattlePassLandingPageButton.OnSetTileImageMaterial // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnDisplayDetailsUpdated(struct FBattlePassLandingPageButtonDisplayDetails& NewDisplayDetails); // Function BattlePassBase.BattlePassLandingPageButton.OnDisplayDetailsUpdated // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	struct FBattlePassLandingPageButtonDisplayDetails GetBattlePassDisplayDetails(); // Function BattlePassBase.BattlePassLandingPageButton.GetBattlePassDisplayDetails // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7deea0
};

// Class BattlePassBase.BattlePassRewardPageBase
// Size: 0x500 (Inherited: 0x3e8)
struct UBattlePassRewardPageBase : UCommonActivatableWidget {
	char pad_3E8[0x118]; // 0x3e8(0x118)
};

// Class BattlePassBase.BattlePassUIGameFeatureAction
// Size: 0x88 (Inherited: 0x28)
struct UBattlePassUIGameFeatureAction : UFortUIGameFeatureAction {
	struct TSoftClassPtr<UObject> BattlePassScreenClass; // 0x28(0x20)
	struct TSoftClassPtr<UObject> BattlePassResourceWidgetClass; // 0x48(0x20)
	struct TSoftClassPtr<UObject> BattlePassInfoModalClass; // 0x68(0x20)
};

// Class BattlePassBase.FortBattlePassCustomSkinCategoryTile
// Size: 0x360 (Inherited: 0x2a8)
struct UFortBattlePassCustomSkinCategoryTile : UUserWidget {
	char pad_2A8[0x20]; // 0x2a8(0x20)
	struct UProgressBar* ProgressBar; // 0x2c8(0x08)
	struct UFortDynamicEntryBox* FortDynamicEntryBox_Items; // 0x2d0(0x08)
	struct URichTextBlock* Text_CategoryTitle; // 0x2d8(0x08)
	struct UFortBattlePassTile* PreviewedTile; // 0x2e0(0x08)
	int32_t OwnedRewards; // 0x2e8(0x04)
	char pad_2EC[0x74]; // 0x2ec(0x74)

	void SetPreviewedTile(int32_t Index); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.SetPreviewedTile // (Final|Native|Public|BlueprintCallable) // @ game+0xa7e1690
	void OnOwnedTilesUpdated(int32_t CurrentlyOwnedRewards, int32_t TotalRewards, float CategoryProgress); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnOwnedTilesUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnLockedStateChanged(bool bCategoryLocked); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnLockedProgressUpdated(int32_t CurrentlyOwnedBeforeCategory, int32_t TotalRewardsBeforeCategory, float LockedProgress); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedProgressUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void FocusTile(int32_t Index); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.FocusTile // (Final|Native|Public|BlueprintCallable) // @ game+0xa7e1550
};

// Class BattlePassBase.FortBattlePassCustomSkinPageBase
// Size: 0x5b0 (Inherited: 0x3e8)
struct UFortBattlePassCustomSkinPageBase : UCommonActivatableWidget {
	char pad_3E8[0x1a0]; // 0x3e8(0x1a0)
	struct UScrollBox* ScrollBox_Categories; // 0x588(0x08)
	struct UFortDynamicEntryBox* FortDynamicEntryBox_Categories; // 0x590(0x08)
	char pad_598[0x8]; // 0x598(0x08)
	struct UBattlePassEnabledInputData* EquipEnabledData; // 0x5a0(0x08)
	char pad_5A8[0x8]; // 0x5a8(0x08)
};

// Class BattlePassBase.FortBattlePassBulkBuyPageBase
// Size: 0x588 (Inherited: 0x3e8)
struct UFortBattlePassBulkBuyPageBase : UCommonActivatableWidget {
	char pad_3E8[0x118]; // 0x3e8(0x118)
	struct UCommonButtonBase* Button_Addition; // 0x500(0x08)
	struct UCommonButtonBase* Button_Subtraction; // 0x508(0x08)
	struct UDynamicEntryBox* DynamicEntryBox_TilesEntries; // 0x510(0x08)
	struct UCommonVisibilitySwitcher* Switcher_BottomButtons; // 0x518(0x08)
	struct UFortCTAButton* Button_BuyLevels; // 0x520(0x08)
	struct UFortCTAButton* Button_ClaimReward; // 0x528(0x08)
	struct UWidget* Widget_LevelUpMessagePremium; // 0x530(0x08)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0x538(0x08)
	char pad_540[0x18]; // 0x540(0x18)
	struct UAthenaSeasonItemDefinition* SeasonItemDefinition; // 0x558(0x08)
	struct UFortBattlePassTile* FocusedReward; // 0x560(0x08)
	char pad_568[0x18]; // 0x568(0x18)
	struct UScrollBox* ScrollBox_Pages; // 0x580(0x08)

	void OnRewardCountChanged(int32_t Count); // Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnRewardCountChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPageRangeChanged(int32_t FromPage, int32_t ToPage); // Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnPageRangeChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnCostChanged(int32_t Cost); // Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnCostChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void HandleUserScrolled(float ScrollAmount); // Function BattlePassBase.FortBattlePassBulkBuyPageBase.HandleUserScrolled // (Final|Native|Protected) // @ game+0xa7e5660
};

// Class BattlePassBase.FortBattlePassCheckBoxButton
// Size: 0x1480 (Inherited: 0x1470)
struct UFortBattlePassCheckBoxButton : UCommonButtonBase {
	char pad_1470[0x10]; // 0x1470(0x10)

	void OnStateChanged(bool bNewIsChecked); // Function BattlePassBase.FortBattlePassCheckBoxButton.OnStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class BattlePassBase.FortBattlePassContext
// Size: 0xa8 (Inherited: 0x30)
struct UFortBattlePassContext : UBlueprintContextBase {
	char pad_30[0x8]; // 0x30(0x08)
	struct TArray<struct UFortPersistentResourceItemDefinition*> CustomizationPageSeasonalResources; // 0x38(0x10)
	struct TArray<struct UFortPersistentResourceItemDefinition*> AllSeasonalResources; // 0x48(0x10)
	struct TMap<enum class ERewardPageType, struct FSeasonalResourceList> RewardPageSeasonalResources; // 0x58(0x50)

	struct TArray<struct FSeasonCurrencyMcpData> GetSeasonalCurrencies(); // Function BattlePassBase.FortBattlePassContext.GetSeasonalCurrencies // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7e81f0
	struct FText GetLevelPurchaseDisclaimerText(); // Function BattlePassBase.FortBattlePassContext.GetLevelPurchaseDisclaimerText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7e7ef0
	struct FText GetDefaultDisclaimerText(); // Function BattlePassBase.FortBattlePassContext.GetDefaultDisclaimerText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7e8070
	struct FText GetCurrentSeasonNumberAsText(bool bFullText); // Function BattlePassBase.FortBattlePassContext.GetCurrentSeasonNumberAsText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b66590
	struct FText GetCurrentChapterAsText(bool bFullText); // Function BattlePassBase.FortBattlePassContext.GetCurrentChapterAsText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b663e0
	bool CanPurchaseBattlePassLevel(); // Function BattlePassBase.FortBattlePassContext.CanPurchaseBattlePassLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7e8460
};

// Class BattlePassBase.FortBattlePassResourcesWidgetBase
// Size: 0x2e0 (Inherited: 0x2d0)
struct UFortBattlePassResourcesWidgetBase : UFortGlobalSeasonResourceWidget {
	struct UFortBattlePassResourceCounter* ResourceCounterClass; // 0x2d0(0x08)
	struct UDynamicEntryBox* EntryBox_ResourceCounters; // 0x2d8(0x08)

	void ShowResourcesInfoModal(); // Function BattlePassBase.FortBattlePassResourcesWidgetBase.ShowResourcesInfoModal // (Final|Native|Protected|BlueprintCallable) // @ game+0xa7ed4b0
	void OnShowMoreInfo(bool bShouldShowMoreInfo); // Function BattlePassBase.FortBattlePassResourcesWidgetBase.OnShowMoreInfo // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class BattlePassBase.FortBattlePassCurrencyPanel
// Size: 0x320 (Inherited: 0x2e0)
struct UFortBattlePassCurrencyPanel : UFortBattlePassResourcesWidgetBase {
	struct UHorizontalBox* HBox_BattleStarContainer; // 0x2e0(0x08)
	struct UCommonTextBlock* Text_BattleStar; // 0x2e8(0x08)
	struct UHorizontalBox* HBox_CustomSkinContainer; // 0x2f0(0x08)
	struct UCommonTextBlock* Text_CustomSkin; // 0x2f8(0x08)
	char pad_300[0x20]; // 0x300(0x20)
};

// Class BattlePassBase.FortBattlePassDynamicIcon
// Size: 0x2f0 (Inherited: 0x2a8)
struct UFortBattlePassDynamicIcon : UUserWidget {
	struct TSoftObjectPtr<UObject> BattlePassDefaultIcon; // 0x2a8(0x20)
	struct TSoftObjectPtr<UObject> BattlePassOwnedIcon; // 0x2c8(0x20)
	struct UFortLazyImage* LazyImage_BattlePassIcon; // 0x2e8(0x08)

	void OnBattlePassInfoUpdated(bool bOwnsBattlePass); // Function BattlePassBase.FortBattlePassDynamicIcon.OnBattlePassInfoUpdated // (Event|Protected|BlueprintEvent|Const) // @ game+0x1b027f0
};

// Class BattlePassBase.FortBattlePassLevelCount
// Size: 0x2b8 (Inherited: 0x2a8)
struct UFortBattlePassLevelCount : UUserWidget {
	struct UCommonTextBlock* Text_LevelCount; // 0x2a8(0x08)
	char pad_2B0[0x8]; // 0x2b0(0x08)
};

// Class BattlePassBase.FortBattlePassPrerequisiteHeader
// Size: 0x2b0 (Inherited: 0x2a8)
struct UFortBattlePassPrerequisiteHeader : UUserWidget {
	struct UTextBlock* Text_Prerequisite; // 0x2a8(0x08)
};

// Class BattlePassBase.FortBattlePassPurchaseResourcesWidget
// Size: 0x4a8 (Inherited: 0x3e8)
struct UFortBattlePassPurchaseResourcesWidget : UCommonActivatableWidget {
	char pad_3E8[0x8]; // 0x3e8(0x08)
	struct UCommonButtonBase* Button_Addition; // 0x3f0(0x08)
	struct UCommonButtonBase* Button_BatchAddition; // 0x3f8(0x08)
	struct UCommonButtonBase* Button_Subtraction; // 0x400(0x08)
	struct UCommonButtonBase* Button_BatchSubtraction; // 0x408(0x08)
	struct UCommonVisibilitySwitcher* Switcher_PurchaseButtons; // 0x410(0x08)
	struct UFortHoldableButton* Button_Purchase; // 0x418(0x08)
	struct UCommonButtonBase* Button_GetVBucks; // 0x420(0x08)
	struct UCommonButtonBase* Button_ReloadMtx; // 0x428(0x08)
	struct UCommonButtonBase* Button_Back; // 0x430(0x08)
	struct UFortBattlePassCheckBoxButton* CheckBox_Bundle; // 0x438(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x440(0x08)
	int32_t CurrentLevel; // 0x448(0x04)
	bool bIsOfferActive; // 0x44c(0x01)
	char pad_44D[0x3]; // 0x44d(0x03)
	int32_t CurrentVBucks; // 0x450(0x04)
	int32_t CurrentBattleStars; // 0x454(0x04)
	int32_t BatchNum; // 0x458(0x04)
	bool bOfferUnavailable; // 0x45c(0x01)
	char pad_45D[0x3]; // 0x45d(0x03)
	int32_t MaxBundleLevel; // 0x460(0x04)
	int32_t MaxLevel; // 0x464(0x04)
	int32_t MaxLevelPurchases; // 0x468(0x04)
	int32_t BundleAmount; // 0x46c(0x04)
	struct UFortItemDefinition* LevelPreviewItem; // 0x470(0x08)
	struct UAthenaSeasonItemData_BattleStar* BattleStarData; // 0x478(0x08)
	char pad_480[0x28]; // 0x480(0x28)

	void OnUpdatePageUnlockText(struct FText& PageUnlockText); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnUpdatePageUnlockText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnTotalPriceChanged(int32_t NewPrice); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnTotalPriceChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPurchaseAmountChanged(int32_t NewAmount, int32_t LevelsLeft); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnPurchaseAmountChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnOfferUnavailable(); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnOfferUnavailable // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnAmountChangeButtonClicked(); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnAmountChangeButtonClicked // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool IsReloadMtxEnabled(); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.IsReloadMtxEnabled // (Final|Native|Protected|BlueprintCallable) // @ game+0xa7ea8d0
	void HandlePurchaseMultiComplete(bool bSuccess, struct TArray<struct FPurchasedItemInfo>& PurchasedItems, struct TArray<struct FString>& OfferIdList); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseMultiComplete // (Final|Native|Private|HasOutParms) // @ game+0xa7ea370
	void HandlePurchaseComplete(bool bSuccess, struct TArray<struct FPurchasedItemInfo>& PurchasedItems, struct FString OfferId); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseComplete // (Final|Native|Private|HasOutParms) // @ game+0xa7ea630
};

// Class BattlePassBase.FortBattlePassResourceCounter
// Size: 0x2f0 (Inherited: 0x2d0)
struct UFortBattlePassResourceCounter : UCommonUserWidget {
	struct UCommonTextBlock* Text_ResourceName; // 0x2d0(0x08)
	struct UFortLazyImage* LazyImage_ResourceIcon; // 0x2d8(0x08)
	struct UCommonTextBlock* Text_ResourceCount; // 0x2e0(0x08)
	struct UFortPersistentResourceItemDefinition* CurrentResource; // 0x2e8(0x08)
};

// Class BattlePassBase.FortBattlePassRewardGrid
// Size: 0x4b8 (Inherited: 0x3e8)
struct UFortBattlePassRewardGrid : UCommonActivatableWidget {
	char pad_3E8[0x68]; // 0x3e8(0x68)
	struct UFortBattlePassTileBase* GridTileClass; // 0x450(0x08)
	struct UFortBattlePassTileBase* GridEmptyTileClass; // 0x458(0x08)
	struct FVector2D GridCellPadding; // 0x460(0x10)
	struct UFortBattlePassRewardGridHeader* PageHeader; // 0x470(0x08)
	struct UGridPanel* GridPanel_Rewards; // 0x478(0x08)
	struct UFortBattlePassTileBase* DefaultFocusTile; // 0x480(0x08)
	struct TWeakObjectPtr<struct UCommonButtonBase> LastFocusedTile; // 0x488(0x08)
	char pad_490[0x28]; // 0x490(0x28)

	void OnPageUnselected(); // Function BattlePassBase.FortBattlePassRewardGrid.OnPageUnselected // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPageSelected(); // Function BattlePassBase.FortBattlePassRewardGrid.OnPageSelected // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class BattlePassBase.FortBattlePassRewardGridHeader
// Size: 0x2b0 (Inherited: 0x2a8)
struct UFortBattlePassRewardGridHeader : UUserWidget {
	char pad_2A8[0x8]; // 0x2a8(0x08)

	void OnSetPageType(enum class ERewardPageType PageType); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageType // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnSetPageCustomName(struct FText& CustomName); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageCustomName // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnPageUnlocked(int32_t PurchasedRewards, int32_t TotalRewards); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageUnlocked // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPageNumberSet(int32_t InPageNumber); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageNumberSet // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPageLocked(int32_t RequiredLevel, int32_t RequiredRewards, bool IsTimeLocked, struct FTimespan TimeRemaining); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageLocked // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnBattlePassLevelSet(int32_t BattlePassLevel); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnBattlePassLevelSet // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	int32_t GetPageNumber(); // Function BattlePassBase.FortBattlePassRewardGridHeader.GetPageNumber // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7edf60
};

// Class BattlePassBase.FortBattlePassRewardTrack
// Size: 0x488 (Inherited: 0x3e8)
struct UFortBattlePassRewardTrack : UCommonActivatableWidget {
	char pad_3E8[0x50]; // 0x3e8(0x50)
	struct UFortBattlePassTileBase* RewardTileClass; // 0x438(0x08)
	struct UFortBattlePassTileBase* RewardEmptyTileClass; // 0x440(0x08)
	struct UFortBattlePassPrerequisiteHeader* PrerequisiteHeaderClass; // 0x448(0x08)
	struct FVector2D GridCellPadding; // 0x450(0x10)
	struct UGridPanel* GridPanel_Rewards; // 0x460(0x08)
	struct UFortBattlePassTileBase* DefaultFocusTile; // 0x468(0x08)
	struct TWeakObjectPtr<struct UCommonButtonBase> LastFocusedTile; // 0x470(0x08)
	char pad_478[0x10]; // 0x478(0x10)

	void OnPageUnselected(); // Function BattlePassBase.FortBattlePassRewardTrack.OnPageUnselected // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPageSelected(); // Function BattlePassBase.FortBattlePassRewardTrack.OnPageSelected // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class BattlePassBase.FortBattlePassTileBase
// Size: 0x15d0 (Inherited: 0x1510)
struct UFortBattlePassTileBase : UFortHoldableButton {
	enum class ERewardPageType RewardPageType; // 0x1510(0x01)
	char pad_1511[0x7]; // 0x1511(0x07)
	struct USizeBox* SizeBox_Content; // 0x1518(0x08)
	struct TMap<struct FName, struct FLinearColor> TileColors; // 0x1520(0x50)
	struct FLinearColor OverlayDimColor; // 0x1570(0x10)
	struct FVector2D TileDesiredCellSpan; // 0x1580(0x10)
	float UnitHeight; // 0x1590(0x04)
	float UnitWidth; // 0x1594(0x04)
	char pad_1598[0x38]; // 0x1598(0x38)

	void SetState(enum class BattlePassTileAvailabilityStates NewState); // Function BattlePassBase.FortBattlePassTileBase.SetState // (Final|Native|Protected|BlueprintCallable) // @ game+0xa7f1f90
	void SetSize(enum class EPageItemTileSize TileSize, struct FVector2D& CellSpacing); // Function BattlePassBase.FortBattlePassTileBase.SetSize // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa7f2080
	void OnStateChanged(enum class BattlePassTileAvailabilityStates NewState); // Function BattlePassBase.FortBattlePassTileBase.OnStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSizeChanged(struct FVector2D& NewSize); // Function BattlePassBase.FortBattlePassTileBase.OnSizeChanged // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnSetTileColors(); // Function BattlePassBase.FortBattlePassTileBase.OnSetTileColors // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSetRequiresBattlePass(bool bRequiresBP); // Function BattlePassBase.FortBattlePassTileBase.OnSetRequiresBattlePass // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRevealed(); // Function BattlePassBase.FortBattlePassTileBase.OnRevealed // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPeeked(); // Function BattlePassBase.FortBattlePassTileBase.OnPeeked // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool IsOwned(); // Function BattlePassBase.FortBattlePassTileBase.IsOwned // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7f2280
	bool IsLocked(); // Function BattlePassBase.FortBattlePassTileBase.IsLocked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7f22b0
	bool IsAvailable(); // Function BattlePassBase.FortBattlePassTileBase.IsAvailable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7f2210
	enum class BattlePassTileAvailabilityStates GetState(); // Function BattlePassBase.FortBattlePassTileBase.GetState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7f1f70
	bool AreAnyGrantedItemsEquipped(); // Function BattlePassBase.FortBattlePassTileBase.AreAnyGrantedItemsEquipped // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7f2240
};

// Class BattlePassBase.FortBattlePassTile
// Size: 0x1640 (Inherited: 0x15d0)
struct UFortBattlePassTile : UFortBattlePassTileBase {
	char pad_15D0[0x18]; // 0x15d0(0x18)
	struct UFortLazyImage* Image_RewardItem; // 0x15e8(0x08)
	struct UImage* Image_Currency; // 0x15f0(0x08)
	bool bIsOnBulkBuyMode; // 0x15f8(0x01)
	char pad_15F9[0x47]; // 0x15f9(0x47)

	void OnUnpreviewed(); // Function BattlePassBase.FortBattlePassTile.OnUnpreviewed // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnUnhighlighted(); // Function BattlePassBase.FortBattlePassTile.OnUnhighlighted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnTilePreviewCycled(); // Function BattlePassBase.FortBattlePassTile.OnTilePreviewCycled // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSetTrack(bool bIsFreeTrack, bool bOwnsBattlePass); // Function BattlePassBase.FortBattlePassTile.OnSetTrack // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSetCurrencyAndPrice(enum class EBattlePassCurrencyType Currency, int32_t Price); // Function BattlePassBase.FortBattlePassTile.OnSetCurrencyAndPrice // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnPreviewed(); // Function BattlePassBase.FortBattlePassTile.OnPreviewed // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnLockedStateUpdated(bool OwnsBattlePass, bool ParentUnlocked, bool HasRemainingPrerequisites, bool bIsDelayed); // Function BattlePassBase.FortBattlePassTile.OnLockedStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnLockedProgressUpdated(float Progress, int32_t CurrentlyOwnedRewards, int32_t NeededRewards); // Function BattlePassBase.FortBattlePassTile.OnLockedProgressUpdated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnHighlighted(); // Function BattlePassBase.FortBattlePassTile.OnHighlighted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnAffordabilityChanged(bool bHasEnougCurrency); // Function BattlePassBase.FortBattlePassTile.OnAffordabilityChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool IsAffordable(); // Function BattlePassBase.FortBattlePassTile.IsAffordable // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7efdd0
	bool HasPrerequisites(); // Function BattlePassBase.FortBattlePassTile.HasPrerequisites // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7efe80
};

// Class BattlePassBase.FortBattlePassTutorialTooltip
// Size: 0x2e0 (Inherited: 0x2d0)
struct UFortBattlePassTutorialTooltip : UCommonUserWidget {
	struct UCommonRichTextBlock* Text_Tooltip; // 0x2d0(0x08)
	char pad_2D8[0x8]; // 0x2d8(0x08)

	void ShowTooltip(); // Function BattlePassBase.FortBattlePassTutorialTooltip.ShowTooltip // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetTooltipEnabled(bool bEnable); // Function BattlePassBase.FortBattlePassTutorialTooltip.SetTooltipEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa7f2aa0
	void SetText(struct FText Text); // Function BattlePassBase.FortBattlePassTutorialTooltip.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0xa7f2bc0
	void HideTooltip(); // Function BattlePassBase.FortBattlePassTutorialTooltip.HideTooltip // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class BattlePassBase.RebootRallyQuestPanel
// Size: 0x2a8 (Inherited: 0x2a8)
struct URebootRallyQuestPanel : UUserWidget {

	void OnRebootRallyEligibilityUpdated(bool bEligible); // Function BattlePassBase.RebootRallyQuestPanel.OnRebootRallyEligibilityUpdated // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

