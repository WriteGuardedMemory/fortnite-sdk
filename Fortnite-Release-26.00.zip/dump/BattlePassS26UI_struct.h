// Enum BattlePassS26UI.EBattlePassStatusBarTypeS26
enum class EBattlePassStatusBarTypeS26 : uint8 {
	Hidden = 0,
	Prerequisite = 1,
	Delayed = 2,
	Unclaimable = 3,
	Claimable = 4,
	Special = 5,
	Owned = 6,
	EBattlePassStatusBarTypeS26_MAX = 7
};

