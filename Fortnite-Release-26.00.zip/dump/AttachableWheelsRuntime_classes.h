// Class AttachableWheelsRuntime.AttachableWheel
// Size: 0x318 (Inherited: 0x290)
struct AAttachableWheel : AActor {
	struct UStaticMeshComponent* WheelMeshComponent; // 0x290(0x08)
	struct FRotator WheelOrientation; // 0x298(0x18)
	float WheelDistance; // 0x2b0(0x04)
	char pad_2B4[0x4]; // 0x2b4(0x04)
	struct UPhysicsConstraintComponent* AxleConstraint; // 0x2b8(0x08)
	struct FAttachableWheelAttachData AttachData; // 0x2c0(0x58)

	void OnRep_AttachData(struct FAttachableWheelAttachData& AttachDataPrev); // Function AttachableWheelsRuntime.AttachableWheel.OnRep_AttachData // (Final|Native|Protected|HasOutParms) // @ game+0xafe90e0
	void OnPhysicsStateChanged(struct UPrimitiveComponent* PrimitiveComponent, enum class EComponentPhysicsStateChange StateChange); // Function AttachableWheelsRuntime.AttachableWheel.OnPhysicsStateChanged // (Final|Native|Protected) // @ game+0xafe8f60
	void OnDetached(struct UPrimitiveComponent* DetachedComponent); // Function AttachableWheelsRuntime.AttachableWheel.OnDetached // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnAttached(struct UPrimitiveComponent* AttachedComponent); // Function AttachableWheelsRuntime.AttachableWheel.OnAttached // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool GetWorldSpaceAttachData(struct FAttachableWheelAttachData& OutAttachData, struct UPrimitiveComponent* PrimitiveComponent, struct FName BodyName); // Function AttachableWheelsRuntime.AttachableWheel.GetWorldSpaceAttachData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xafe9250
	struct UPrimitiveComponent* GetAttachedComponent(); // Function AttachableWheelsRuntime.AttachableWheel.GetAttachedComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xafe94d0
	void DrawDebug(); // Function AttachableWheelsRuntime.AttachableWheel.DrawDebug // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x3982d70
	bool DetachFrom(struct UPrimitiveComponent* InComponent); // Function AttachableWheelsRuntime.AttachableWheel.DetachFrom // (Final|Native|Public|BlueprintCallable) // @ game+0xafe9500
	void Detach(); // Function AttachableWheelsRuntime.AttachableWheel.Detach // (Final|Native|Public|BlueprintCallable) // @ game+0xafe9650
	bool AttachTo(struct UPrimitiveComponent* InComponent, struct FVector& WorldLocation, struct FVector& AxleDirection); // Function AttachableWheelsRuntime.AttachableWheel.AttachTo // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xafe9760
	bool AttachInPlace(struct UPrimitiveComponent* InComponent); // Function AttachableWheelsRuntime.AttachableWheel.AttachInPlace // (Final|Native|Public|BlueprintCallable) // @ game+0xafe9670
};

// Class AttachableWheelsRuntime.AttachableWheelsComponent
// Size: 0xf0 (Inherited: 0xa0)
struct UAttachableWheelsComponent : UActorComponent {
	struct TSet<struct AAttachableWheel*> AttachedWheels; // 0xa0(0x50)

	void OnWheelDetached(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelDetached // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnWheelAttached(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelAttached // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool HandleWheelDetached_Internal(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelDetached_Internal // (Final|Native|Protected) // @ game+0xafec490
	bool HandleWheelAttached_Internal(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelAttached_Internal // (Final|Native|Protected) // @ game+0xafec580
	struct TArray<struct AAttachableWheel*> GetAttachedWheels(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheels // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xafecbd0
	struct AAttachableWheel* GetAttachedWheelClosestOnAxis(struct FVector& Point, float& OutClosetDistanceToAxis, struct FVector& OutClosestPointOnAxis, struct FVector& OutClosestAxis); // Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheelClosestOnAxis // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xafec670
	void DrawDebug(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.DrawDebug // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x3982d70
	int32_t DetachAllWheels(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.DetachAllWheels // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xafecca0
};

