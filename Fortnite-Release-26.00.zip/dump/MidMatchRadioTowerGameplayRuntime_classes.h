// Class MidMatchRadioTowerGameplayRuntime.RemoveFoliageBoxComponent
// Size: 0x5b0 (Inherited: 0x5b0)
struct URemoveFoliageBoxComponent : UBoxComponent {
};

