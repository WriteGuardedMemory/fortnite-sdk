// Class CustomizableObject.CustomizableInstancePrivateData
// Size: 0x2c8 (Inherited: 0x28)
struct UCustomizableInstancePrivateData : UObject {
	struct TArray<struct FGeneratedMaterial> GeneratedMaterials; // 0x28(0x10)
	struct TArray<struct FGeneratedTexture> GeneratedTextures; // 0x38(0x10)
	char pad_48[0x60]; // 0x48(0x60)
	struct TMap<struct FString, struct TWeakObjectPtr<struct UTexture2D>> TextureReuseCache; // 0xa8(0x50)
	char pad_F8[0x88]; // 0xf8(0x88)
	struct TArray<struct FCustomizableInstanceComponentData> ComponentsData; // 0x180(0x10)
	struct TArray<struct UMaterialInterface*> ReferencedMaterials; // 0x190(0x10)
	char pad_1A0[0x60]; // 0x1a0(0x60)
	struct TArray<struct UPhysicsAsset*> ClothingPhysicsAssets; // 0x200(0x10)
	struct TArray<struct UAnimInstance*> GatheredAnimBPs; // 0x210(0x10)
	struct FGameplayTagContainer AnimBPGameplayTags; // 0x220(0x20)
	struct TMap<struct UAnimInstance*, struct FAnimBpGeneratedPhysicsAssets> AnimBpPhysicsAssets; // 0x240(0x50)
	char pad_290[0x38]; // 0x290(0x38)
};

// Class CustomizableObject.CustomizableObjectExtension
// Size: 0x28 (Inherited: 0x28)
struct UCustomizableObjectExtension : UObject {
};

// Class CustomizableObject.CustomizableInstanceLODManagementBase
// Size: 0x28 (Inherited: 0x28)
struct UCustomizableInstanceLODManagementBase : UObject {
};

// Class CustomizableObject.CustomizableInstanceLODManagement
// Size: 0x80 (Inherited: 0x28)
struct UCustomizableInstanceLODManagement : UCustomizableInstanceLODManagementBase {
	char pad_28[0x58]; // 0x28(0x58)
};

// Class CustomizableObject.MutableMaskOutCache
// Size: 0xc8 (Inherited: 0x28)
struct UMutableMaskOutCache : UObject {
	struct TMap<struct FString, struct FString> Materials; // 0x28(0x50)
	struct TMap<struct FString, struct FMaskOutTexture> Textures; // 0x78(0x50)
};

// Class CustomizableObject.CustomizableObjectBulk
// Size: 0x38 (Inherited: 0x28)
struct UCustomizableObjectBulk : UObject {
	struct TArray<struct FString> BulkDataFileNames; // 0x28(0x10)
};

// Class CustomizableObject.CustomizableObject
// Size: 0x430 (Inherited: 0x28)
struct UCustomizableObject : UObject {
	struct TArray<struct FMutableRefSkeletalMeshData> ReferenceSkeletalMeshesData; // 0x28(0x10)
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> ReferencedMaterials; // 0x38(0x10)
	struct TArray<struct FName> ReferencedMaterialSlotNames; // 0x48(0x10)
	struct TArray<struct TSoftObjectPtr<USkeleton>> ReferencedSkeletons; // 0x58(0x10)
	struct TArray<struct TSoftObjectPtr<UTexture>> ReferencedPassThroughTextures; // 0x68(0x10)
	struct FMutableLODSettings LODSettings; // 0x78(0x10)
	struct TArray<struct FMutableModelImageProperties> ImageProperties; // 0x88(0x10)
	struct TArray<struct FMorphTargetInfo> ContributingMorphTargetsInfo; // 0x98(0x10)
	struct TArray<struct FMorphTargetVertexData> MorphTargetReconstructionData; // 0xa8(0x10)
	struct TArray<struct FCustomizableObjectClothConfigData> ClothSharedConfigsData; // 0xb8(0x10)
	struct TArray<struct FCustomizableObjectClothingAssetData> ContributingClothingAssetsData; // 0xc8(0x10)
	struct TArray<struct FCustomizableObjectMeshToMeshVertData> ClothMeshToMeshVertData; // 0xd8(0x10)
	struct TArray<struct FMutableSkinWeightProfileInfo> SkinWeightProfilesInfo; // 0xe8(0x10)
	struct TArray<struct FCustomizableObjectExtensionData> AlwaysLoadedExtensionData; // 0xf8(0x10)
	struct TArray<struct FCustomizableObjectStreamedExtensionData> StreamedExtensionData; // 0x108(0x10)
	int32_t NumMeshComponentsInRoot; // 0x118(0x04)
	char pad_11C[0x14]; // 0x11c(0x14)
	struct TArray<struct FMutableModelParameterProperties> ParameterProperties; // 0x130(0x10)
	char pad_140[0x50]; // 0x140(0x50)
	struct TMap<struct FString, struct FParameterUIData> ParameterUIDataMap; // 0x190(0x50)
	struct TArray<struct FName> LowPriorityTextures; // 0x1e0(0x10)
	struct TMap<struct FString, struct FParameterUIData> StateUIDataMap; // 0x1f0(0x50)
	struct TMap<struct FString, struct TSoftObjectPtr<UPhysicsAsset>> PhysicsAssetsMap; // 0x240(0x50)
	struct TMap<struct FString, struct TSoftClassPtr<UObject>> AnimBPAssetsMap; // 0x290(0x50)
	struct TArray<struct FAnimBpOverridePhysicsAssetsInfo> AnimBpOverridePhysiscAssetsInfo; // 0x2e0(0x10)
	struct TArray<struct FMutableRefSocket> SocketArray; // 0x2f0(0x10)
	struct TSoftObjectPtr<UMutableMaskOutCache> MaskOutCache; // 0x300(0x20)
	struct TMap<uint64_t, struct FMutableStreamableBlock> HashToStreamableBlock; // 0x320(0x50)
	struct TArray<struct FString> CustomizableObjectClassTags; // 0x370(0x10)
	struct TArray<struct FString> PopulationClassTags; // 0x380(0x10)
	struct TMap<struct FString, struct FParameterTags> CustomizableObjectParametersTags; // 0x390(0x50)
	struct TArray<struct FName> BoneNames; // 0x3e0(0x10)
	char pad_3F0[0x10]; // 0x3f0(0x10)
	struct UMutableMaskOutCache* MaskOutCache_HardRef; // 0x400(0x08)
	struct FGuid CompilationGuid; // 0x408(0x10)
	struct UCustomizableObjectBulk* BulkData; // 0x418(0x08)
	char pad_420[0x10]; // 0x420(0x10)

	void UnloadReferenceSkeletalMeshes(); // Function CustomizableObject.CustomizableObject.UnloadReferenceSkeletalMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0x523f640
	void UnloadMaskOutCache(); // Function CustomizableObject.CustomizableObject.UnloadMaskOutCache // (Final|Native|Public|BlueprintCallable) // @ game+0x523f6a0
	void LoadReferenceSkeletalMeshesAsync(); // Function CustomizableObject.CustomizableObject.LoadReferenceSkeletalMeshesAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x523f680
	void LoadMaskOutCache(); // Function CustomizableObject.CustomizableObject.LoadMaskOutCache // (Final|Native|Public|BlueprintCallable) // @ game+0x523f6c0
	bool IsParameterMultidimensional(struct FString InParameterName); // Function CustomizableObject.CustomizableObject.IsParameterMultidimensional // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523e600
	bool IsCompiled(); // Function CustomizableObject.CustomizableObject.IsCompiled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523d840
	struct FParameterUIData GetStateUIMetadataFromIndex(int32_t StateIndex); // Function CustomizableObject.CustomizableObject.GetStateUIMetadataFromIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523ddf0
	struct FParameterUIData GetStateUIMetadata(struct FString StateName); // Function CustomizableObject.CustomizableObject.GetStateUIMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523df60
	struct FString GetStateParameterName(struct FString StateName, int32_t ParameterIndex); // Function CustomizableObject.CustomizableObject.GetStateParameterName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523e0b0
	int32_t GetStateParameterCount(struct FString StateName); // Function CustomizableObject.CustomizableObject.GetStateParameterCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523e330
	struct FString GetStateName(int32_t StateIndex); // Function CustomizableObject.CustomizableObject.GetStateName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523e490
	int32_t GetStateCount(); // Function CustomizableObject.CustomizableObject.GetStateCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523e5c0
	void GetProjectorParameterDefaultValue(struct FString InParameterName, struct FVector3f& OutPos, struct FVector3f& OutDirection, struct FVector3f& OutUp, struct FVector3f& OutScale, float& OutAngle, enum class ECustomizableObjectProjectorType& OutType); // Function CustomizableObject.CustomizableObject.GetProjectorParameterDefaultValue // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x523e7c0
	struct FParameterUIData GetParameterUIMetadataFromIndex(int32_t ParamIndex); // Function CustomizableObject.CustomizableObject.GetParameterUIMetadataFromIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523d8a0
	struct FParameterUIData GetParameterUIMetadata(struct FString ParamName); // Function CustomizableObject.CustomizableObject.GetParameterUIMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523dca0
	enum class EMutableParameterType GetParameterTypeByName(struct FString Name); // Function CustomizableObject.CustomizableObject.GetParameterTypeByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523fbd0
	enum class EMutableParameterType GetParameterType(int32_t ParamIndex); // Function CustomizableObject.CustomizableObject.GetParameterType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523fcf0
	struct FString GetParameterName(int32_t ParamIndex); // Function CustomizableObject.CustomizableObject.GetParameterName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523fad0
	int32_t GetParameterDescriptionCount(struct FString ParamName); // Function CustomizableObject.CustomizableObject.GetParameterDescriptionCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523f9c0
	int32_t GetParameterCount(); // Function CustomizableObject.CustomizableObject.GetParameterCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523ff90
	int32_t GetIntParameterNumOptions(int32_t ParamIndex); // Function CustomizableObject.CustomizableObject.GetIntParameterNumOptions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523f8d0
	int32_t GetIntParameterDefaultValue(struct FString InParameterName); // Function CustomizableObject.CustomizableObject.GetIntParameterDefaultValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523f180
	struct FString GetIntParameterAvailableOption(int32_t ParamIndex, int32_t K); // Function CustomizableObject.CustomizableObject.GetIntParameterAvailableOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523f740
	float GetFloatParameterDefaultValue(struct FString InParameterName); // Function CustomizableObject.CustomizableObject.GetFloatParameterDefaultValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523f3e0
	int32_t GetComponentCount(); // Function CustomizableObject.CustomizableObject.GetComponentCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523ffb0
	struct FLinearColor GetColorParameterDefaultValue(struct FString InParameterName); // Function CustomizableObject.CustomizableObject.GetColorParameterDefaultValue // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x523ecd0
	bool GetBoolParameterDefaultValue(struct FString InParameterName); // Function CustomizableObject.CustomizableObject.GetBoolParameterDefaultValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523ef30
	int32_t FindParameter(struct FString Name); // Function CustomizableObject.CustomizableObject.FindParameter // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x523fe20
	struct UCustomizableObjectInstance* CreateInstance(); // Function CustomizableObject.CustomizableObject.CreateInstance // (Final|Native|Public|BlueprintCallable) // @ game+0x523d870
};

// Class CustomizableObject.DGGUI
// Size: 0x2a8 (Inherited: 0x2a8)
struct UDGGUI : UUserWidget {

	void SetCustomizableSkeletalComponent(struct UCustomizableSkeletalComponent* CustomizableSkeletalComponent); // Function CustomizableObject.DGGUI.SetCustomizableSkeletalComponent // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	struct UCustomizableSkeletalComponent* GetCustomizableSkeletalComponent(); // Function CustomizableObject.DGGUI.GetCustomizableSkeletalComponent // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class CustomizableObject.CustomizableObjectInstance
// Size: 0x390 (Inherited: 0x28)
struct UCustomizableObjectInstance : UObject {
	struct FMulticastInlineDelegate BeginUpdateDelegate; // 0x28(0x10)
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate UpdatedDelegate; // 0x50(0x10)
	char pad_60[0x18]; // 0x60(0x18)
	struct FMulticastInlineDelegate BeginDestroyDelegate; // 0x78(0x10)
	char pad_88[0x68]; // 0x88(0x68)
	struct TArray<struct USkeletalMesh*> SkeletalMeshes; // 0xf0(0x10)
	struct FString SkeletalMeshStatus; // 0x100(0x10)
	char pad_110[0x48]; // 0x110(0x48)
	struct FCustomizableObjectInstanceDescriptor Descriptor; // 0x158(0x128)
	struct UCustomizableInstancePrivateData* PrivateData; // 0x280(0x08)
	char pad_288[0x48]; // 0x288(0x48)
	struct UCustomizableObject* CustomizableObject; // 0x2d0(0x08)
	struct TArray<struct FCustomizableObjectBoolParameterValue> BoolParameters; // 0x2d8(0x10)
	struct TArray<struct FCustomizableObjectIntParameterValue> IntParameters; // 0x2e8(0x10)
	struct TArray<struct FCustomizableObjectFloatParameterValue> FloatParameters; // 0x2f8(0x10)
	struct TArray<struct FCustomizableObjectTextureParameterValue> TextureParameters; // 0x308(0x10)
	struct TArray<struct FCustomizableObjectVectorParameterValue> VectorParameters; // 0x318(0x10)
	struct TArray<struct FCustomizableObjectProjectorParameterValue> ProjectorParameters; // 0x328(0x10)
	struct TMap<struct FName, struct FMultilayerProjector> MultilayerProjectors; // 0x338(0x50)
	char pad_388[0x8]; // 0x388(0x08)

	void UpdateSkeletalMeshAsyncResult(struct FDelegate Callback, bool bIgnoreCloseDist, bool bForceHighPriority); // Function CustomizableObject.CustomizableObjectInstance.UpdateSkeletalMeshAsyncResult // (Final|Native|Public|BlueprintCallable) // @ game+0x524ced0
	void UpdateSkeletalMeshAsync(bool bIgnoreCloseDist, bool bForceHighPriority); // Function CustomizableObject.CustomizableObjectInstance.UpdateSkeletalMeshAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x524d130
	void SetVectorParameterSelectedOption(struct FString VectorParamName, struct FLinearColor& VectorValue); // Function CustomizableObject.CustomizableObjectInstance.SetVectorParameterSelectedOption // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x524a2e0
	void SetTextureParameterSelectedOptionT(struct FString TextureParamName, struct UTexture2D* TextureValue, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.SetTextureParameterSelectedOptionT // (Final|Native|Public|BlueprintCallable) // @ game+0x524ad90
	void SetTextureParameterSelectedOption(struct FString TextureParamName, struct FString TextureValue, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.SetTextureParameterSelectedOption // (Final|Native|Public|BlueprintCallable) // @ game+0x524aff0
	void SetReplacePhysicsAssets(bool bReplaceEnabled); // Function CustomizableObject.CustomizableObjectInstance.SetReplacePhysicsAssets // (Final|Native|Public|BlueprintCallable) // @ game+0x5244f10
	void SetRandomValues(); // Function CustomizableObject.CustomizableObjectInstance.SetRandomValues // (Final|Native|Public|BlueprintCallable) // @ game+0x524d2e0
	void SetProjectorValue(struct FString ProjectorParamName, struct FVector& OutPos, struct FVector& OutDirection, struct FVector& OutUp, struct FVector& OutScale, float OutAngle, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.SetProjectorValue // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5249df0
	void SetObject(struct UCustomizableObject* InObject); // Function CustomizableObject.CustomizableObjectInstance.SetObject // (Final|Native|Public|BlueprintCallable) // @ game+0x524d8e0
	void SetIntParameterSelectedOption(struct FString ParamName, struct FString SelectedOptionName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.SetIntParameterSelectedOption // (Final|Native|Public|BlueprintCallable) // @ game+0x524bbf0
	void SetFloatParameterSelectedOption(struct FString FloatParamName, float FloatValue, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.SetFloatParameterSelectedOption // (Final|Native|Public|BlueprintCallable) // @ game+0x524b610
	void SetCurrentState(struct FString StateName); // Function CustomizableObject.CustomizableObjectInstance.SetCurrentState // (Final|Native|Public|BlueprintCallable) // @ game+0x524d610
	void SetColorParameterSelectedOption(struct FString ColorParamName, struct FLinearColor& ColorValue); // Function CustomizableObject.CustomizableObjectInstance.SetColorParameterSelectedOption // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x524a920
	void SetBuildParameterRelevancy(bool Value); // Function CustomizableObject.CustomizableObjectInstance.SetBuildParameterRelevancy // (Final|Native|Public|BlueprintCallable) // @ game+0x524d7b0
	void SetBuildParameterDecorations(bool Value); // Function CustomizableObject.CustomizableObjectInstance.SetBuildParameterDecorations // (Final|Native|Public|BlueprintCallable) // @ game+0x34b0aa0
	void SetBoolParameterSelectedOption(struct FString BoolParamName, bool BoolValue); // Function CustomizableObject.CustomizableObjectInstance.SetBoolParameterSelectedOption // (Final|Native|Public|BlueprintCallable) // @ game+0x524a4b0
	int32_t RemoveValueFromProjectorRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromProjectorRange // (Final|Native|Public|BlueprintCallable) // @ game+0x5247000
	int32_t RemoveValueFromIntRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromIntRange // (Final|Native|Public|BlueprintCallable) // @ game+0x52472a0
	int32_t RemoveValueFromFloatRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.RemoveValueFromFloatRange // (Final|Native|Public|BlueprintCallable) // @ game+0x5247150
	void RemoveMultilayerProjector(struct FName& ProjectorParamName); // Function CustomizableObject.CustomizableObjectInstance.RemoveMultilayerProjector // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5246e10
	void MultilayerProjectorUpdateVirtualLayer(struct FName& ProjectorParamName, struct FName& ID, struct FMultilayerProjectorVirtualLayer& Layer); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorUpdateVirtualLayer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5245370
	void MultilayerProjectorUpdateLayer(struct FName& ProjectorParamName, int32_t Index, struct FMultilayerProjectorLayer& Layer); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorUpdateLayer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5246240
	void MultilayerProjectorRemoveVirtualLayer(struct FName& ProjectorParamName, struct FName& ID); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorRemoveVirtualLayer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x52459c0
	void MultilayerProjectorRemoveLayerAt(struct FName& ProjectorParamName, int32_t Index); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorRemoveLayerAt // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5246820
	int32_t MultilayerProjectorNumLayers(struct FName& ProjectorParamName); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorNumLayers // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5246c80
	struct TArray<struct FName> MultilayerProjectorGetVirtualLayers(struct FName& ProjectorParamName); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetVirtualLayers // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5246030
	struct FMultilayerProjectorVirtualLayer MultilayerProjectorGetVirtualLayer(struct FName& ProjectorParamName, struct FName& ID); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetVirtualLayer // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5245620
	struct FMultilayerProjectorLayer MultilayerProjectorGetLayer(struct FName& ProjectorParamName, int32_t Index); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorGetLayer // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5246530
	struct FMultilayerProjectorVirtualLayer MultilayerProjectorFindOrCreateVirtualLayer(struct FName& ProjectorParamName, struct FName& ID); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorFindOrCreateVirtualLayer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5245bf0
	void MultilayerProjectorCreateVirtualLayer(struct FName& ProjectorParamName, struct FName& ID); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorCreateVirtualLayer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5245ea0
	void MultilayerProjectorCreateLayer(struct FName& ProjectorParamName, int32_t Index); // Function CustomizableObject.CustomizableObjectInstance.MultilayerProjectorCreateLayer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5246a50
	bool IsParamMultidimensional(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.IsParamMultidimensional // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524c7a0
	bool IsParameterRelevant(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.IsParameterRelevant // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524c960
	bool HasAnySkeletalMesh(); // Function CustomizableObject.CustomizableObjectInstance.HasAnySkeletalMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524d4a0
	bool HasAnyParameters(); // Function CustomizableObject.CustomizableObjectInstance.HasAnyParameters // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524d320
	struct TArray<struct FCustomizableObjectVectorParameterValue> GetVectorParameters(); // Function CustomizableObject.CustomizableObjectInstance.GetVectorParameters // (Final|Native|Public|BlueprintCallable) // @ game+0x524d3b0
	int32_t GetTextureValueRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetTextureValueRange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524c240
	struct FName GetTextureParameterSelectedOption(struct FString TextureParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetTextureParameterSelectedOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524b280
	struct TArray<struct FCustomizableObjectTextureParameterValue> GetTextureParameters(); // Function CustomizableObject.CustomizableObjectInstance.GetTextureParameters // (Final|Native|Public|BlueprintCallable) // @ game+0x524d3e0
	struct USkeletalMesh* GetSkeletalMesh(int32_t ComponentIndex); // Function CustomizableObject.CustomizableObjectInstance.GetSkeletalMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524d4f0
	int32_t GetProjectorValueRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorValueRange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524c660
	void GetProjectorValue(struct FString ProjectorParamName, struct FVector& OutPos, struct FVector& OutDirection, struct FVector& OutUp, struct FVector& OutScale, float& OutAngle, enum class ECustomizableObjectProjectorType& OutType, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorValue // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x52495e0
	struct FVector GetProjectorUp(struct FString ParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorUp // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5248a50
	struct FVector GetProjectorScale(struct FString ParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorScale // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5248670
	struct FVector GetProjectorPosition(struct FString ParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorPosition // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5249210
	enum class ECustomizableObjectProjectorType GetProjectorParameterType(struct FString ParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameterType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5247f70
	struct TArray<struct FCustomizableObjectProjectorParameterValue> GetProjectorParameters(); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorParameters // (Final|Native|Public|BlueprintCallable) // @ game+0x524d380
	struct FVector GetProjectorDirection(struct FString ParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorDirection // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5248e30
	float GetProjectorAngle(struct FString ParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetProjectorAngle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52482f0
	struct UTexture2D* GetParameterDescription(struct FString ParamName, int32_t DescIndex); // Function CustomizableObject.CustomizableObjectInstance.GetParameterDescription // (Final|Native|Public|BlueprintCallable) // @ game+0x524cb20
	int32_t GetNumComponents(); // Function CustomizableObject.CustomizableObjectInstance.GetNumComponents // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5244ed0
	int32_t GetIntValueRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetIntValueRange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524c4c0
	struct FString GetIntParameterSelectedOption(struct FString ParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetIntParameterSelectedOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524be80
	struct TArray<struct FCustomizableObjectIntParameterValue> GetIntParameters(); // Function CustomizableObject.CustomizableObjectInstance.GetIntParameters // (Final|Native|Public|BlueprintCallable) // @ game+0x524d440
	int32_t GetFloatValueRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.GetFloatValueRange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524c380
	float GetFloatParameterSelectedOption(struct FString FloatParamName, int32_t RangeIndex); // Function CustomizableObject.CustomizableObjectInstance.GetFloatParameterSelectedOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524b870
	struct TArray<struct FCustomizableObjectFloatParameterValue> GetFloatParameters(); // Function CustomizableObject.CustomizableObjectInstance.GetFloatParameters // (Final|Native|Public|BlueprintCallable) // @ game+0x524d410
	struct UCustomizableObject* GetCustomizableObject(); // Function CustomizableObject.CustomizableObjectInstance.GetCustomizableObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524d8c0
	struct FString GetCurrentState(); // Function CustomizableObject.CustomizableObjectInstance.GetCurrentState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524d730
	struct FLinearColor GetColorParameterSelectedOption(struct FString ColorParamName); // Function CustomizableObject.CustomizableObjectInstance.GetColorParameterSelectedOption // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x524aae0
	bool GetBuildParameterRelevancy(); // Function CustomizableObject.CustomizableObjectInstance.GetBuildParameterRelevancy // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524d8a0
	bool GetBuildParameterDecorations(); // Function CustomizableObject.CustomizableObjectInstance.GetBuildParameterDecorations // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x42ab9f0
	bool GetBoolParameterSelectedOption(struct FString BoolParamName); // Function CustomizableObject.CustomizableObjectInstance.GetBoolParameterSelectedOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x524a680
	struct TArray<struct FCustomizableObjectBoolParameterValue> GetBoolParameters(); // Function CustomizableObject.CustomizableObjectInstance.GetBoolParameters // (Final|Native|Public|BlueprintCallable) // @ game+0x524d470
	struct UAnimInstance* GetAnimBP(int32_t ComponentIndex, struct FName& Slot); // Function CustomizableObject.CustomizableObjectInstance.GetAnimBP // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x52451e0
	struct FGameplayTagContainer GetAnimationGameplayTags(); // Function CustomizableObject.CustomizableObjectInstance.GetAnimationGameplayTags // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52451b0
	void ForEachAnimInstance(int32_t ComponentIndex, struct FDelegate Delegate); // Function CustomizableObject.CustomizableObjectInstance.ForEachAnimInstance // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x5245020
	int32_t FindVectorParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindVectorParameterNameIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5247a70
	int32_t FindProjectorParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindProjectorParameterNameIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5247940
	int32_t FindIntParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindIntParameterNameIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5247e00
	int32_t FindFloatParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindFloatParameterNameIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5247cd0
	int32_t FindBoolParameterNameIndex(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.FindBoolParameterNameIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5247ba0
	bool CreateMultiLayerProjector(struct FName& ProjectorParamName); // Function CustomizableObject.CustomizableObjectInstance.CreateMultiLayerProjector // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5246f00
	struct UCustomizableObjectInstance* CloneStatic(struct UObject* Outer); // Function CustomizableObject.CustomizableObjectInstance.CloneStatic // (Final|Native|Public|BlueprintCallable) // @ game+0x524cce0
	struct UCustomizableObjectInstance* Clone(); // Function CustomizableObject.CustomizableObjectInstance.Clone // (Final|Native|Public|BlueprintCallable) // @ game+0x524ce70
	int32_t AddValueToProjectorRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.AddValueToProjectorRange // (Final|Native|Public|BlueprintCallable) // @ game+0x52473d0
	int32_t AddValueToIntRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.AddValueToIntRange // (Final|Native|Public|BlueprintCallable) // @ game+0x52476e0
	int32_t AddValueToFloatRange(struct FString ParamName); // Function CustomizableObject.CustomizableObjectInstance.AddValueToFloatRange // (Final|Native|Public|BlueprintCallable) // @ game+0x5247570
};

// Class CustomizableObject.MutableTextureMipDataProviderFactory
// Size: 0x50 (Inherited: 0x28)
struct UMutableTextureMipDataProviderFactory : UTextureMipDataProviderFactory {
	struct UCustomizableObjectInstance* CustomizableObjectInstance; // 0x28(0x08)
	char pad_30[0x20]; // 0x30(0x20)
};

// Class CustomizableObject.CustomizableObjectExtensionDataContainer
// Size: 0x38 (Inherited: 0x28)
struct UCustomizableObjectExtensionDataContainer : UObject {
	struct FCustomizableObjectExtensionData Data; // 0x28(0x10)
};

// Class CustomizableObject.CustomizableSystemImageProvider
// Size: 0x28 (Inherited: 0x28)
struct UCustomizableSystemImageProvider : UObject {
};

// Class CustomizableObject.CustomizableObjectSystem
// Size: 0x158 (Inherited: 0x28)
struct UCustomizableObjectSystem : UObject {
	struct TArray<struct FPendingReleaseSkeletalMeshInfo> PendingReleaseSkeletalMesh; // 0x28(0x10)
	struct UDefaultImageProvider* DefaultImageProvider; // 0x38(0x08)
	struct UCustomizableInstanceLODManagementBase* DefaultInstanceLODManagement; // 0x40(0x08)
	struct UCustomizableInstanceLODManagementBase* CurrentInstanceLODManagement; // 0x48(0x08)
	struct TArray<struct UTexture2D*> ProtectedCachedTextures; // 0x50(0x10)
	char pad_60[0xf8]; // 0x60(0xf8)

	void SetReleaseMutableTexturesImmediately(bool bReleaseTextures); // Function CustomizableObject.CustomizableObjectSystem.SetReleaseMutableTexturesImmediately // (Final|Native|Public|BlueprintCallable) // @ game+0x52794a0
	int32_t GetTotalInstances(); // Function CustomizableObject.CustomizableObjectSystem.GetTotalInstances // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5279600
	int32_t GetTextureMemoryUsed(); // Function CustomizableObject.CustomizableObjectSystem.GetTextureMemoryUsed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52795d0
	struct FString GetPluginVersion(); // Function CustomizableObject.CustomizableObjectSystem.GetPluginVersion // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5279690
	int32_t GetNumPendingInstances(); // Function CustomizableObject.CustomizableObjectSystem.GetNumPendingInstances // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5279630
	int32_t GetNumInstances(); // Function CustomizableObject.CustomizableObjectSystem.GetNumInstances // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5279660
	struct UCustomizableObjectSystem* GetInstance(); // Function CustomizableObject.CustomizableObjectSystem.GetInstance // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5279700
	int32_t GetAverageBuildTime(); // Function CustomizableObject.CustomizableObjectSystem.GetAverageBuildTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5279590
};

// Class CustomizableObject.CustomizableSkeletalComponent
// Size: 0x2e0 (Inherited: 0x2a0)
struct UCustomizableSkeletalComponent : USceneComponent {
	char pad_2A0[0x4]; // 0x2a0(0x04)
	float SkippedLastRenderTime; // 0x2a4(0x04)
	struct UCustomizableObjectInstance* CustomizableObjectInstance; // 0x2a8(0x08)
	int32_t ComponentIndex; // 0x2b0(0x04)
	char pad_2B4[0x2c]; // 0x2b4(0x2c)

	void UpdateSkeletalMeshAsyncResult(struct FDelegate Callback, bool bIgnoreCloseDist, bool bForceHighPriority); // Function CustomizableObject.CustomizableSkeletalComponent.UpdateSkeletalMeshAsyncResult // (Final|Native|Public|BlueprintCallable) // @ game+0x52850c0
	void UpdateSkeletalMeshAsync(bool bNeverSkipUpdate); // Function CustomizableObject.CustomizableSkeletalComponent.UpdateSkeletalMeshAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x5285320
};

// Class CustomizableObject.CustomizableSkeletalMeshActor
// Size: 0x338 (Inherited: 0x310)
struct ACustomizableSkeletalMeshActor : ASkeletalMeshActor {
	struct TArray<struct UCustomizableSkeletalComponent*> CustomizableSkeletalComponents; // 0x310(0x10)
	struct TArray<struct USkeletalMeshComponent*> SkeletalMeshComponents; // 0x320(0x10)
	struct UCustomizableSkeletalComponent* CustomizableSkeletalComponent; // 0x330(0x08)
};

// Class CustomizableObject.DefaultImageProvider
// Size: 0x78 (Inherited: 0x28)
struct UDefaultImageProvider : UCustomizableSystemImageProvider {
	struct TMap<struct FName, struct UTexture2D*> Textures; // 0x28(0x50)
};

