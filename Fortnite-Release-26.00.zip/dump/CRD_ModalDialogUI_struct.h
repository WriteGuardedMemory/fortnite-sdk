// Enum CRD_ModalDialogUI.ECreativeModalDialogViewmodelResponse
enum class ECreativeModalDialogViewmodelResponse : uint8 {
	None = 0,
	Button1 = 1,
	Button2 = 2,
	Button3 = 3,
	Button4 = 4,
	Button5 = 5,
	Button6 = 6,
	ECreativeModalDialogViewmodelResponse_MAX = 7
};

