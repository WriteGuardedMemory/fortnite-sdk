// Class CreativeDebugMenuRuntime.FortControllerComponent_CreativeDebugger
// Size: 0x1e0 (Inherited: 0xa8)
struct UFortControllerComponent_CreativeDebugger : UFortControllerComponent {
	char pad_A8[0x8]; // 0xa8(0x08)
	struct FScalableFloat DebuggerEnabledByDataRegistry; // 0xb0(0x28)
	struct FScalableFloat VerseDebugDrawEnabledByDataRegistry; // 0xd8(0x28)
	struct FScalableFloat NavigationMeshEnabledByDataRegistry; // 0x100(0x28)
	struct FScalableFloat NavigationPathsEnabledByDataRegistry; // 0x128(0x28)
	struct FScalableFloat GhostModeEnabledByDataRegistry; // 0x150(0x28)
	struct FScalableFloat InvincibilityEnabledByDataRegistry; // 0x178(0x28)
	struct FScalableFloat FastIterationEnabledByDataRegistry; // 0x1a0(0x28)
	struct UFortControllerComponent_AIDebugger* AIDebuggerClass; // 0x1c8(0x08)
	char pad_1D0[0x10]; // 0x1d0(0x10)

	void OnPlayerSpawned(struct AFortPlayerController* PC); // Function CreativeDebugMenuRuntime.FortControllerComponent_CreativeDebugger.OnPlayerSpawned // (Final|Native|Public) // @ game+0xaa35a90
	void OnMutatorUpdated(); // Function CreativeDebugMenuRuntime.FortControllerComponent_CreativeDebugger.OnMutatorUpdated // (Final|Native|Public) // @ game+0xaa35b80
	void OnMinigameStateChanged(struct AFortMinigame* Minigame, enum class EFortMinigameState MinigameState); // Function CreativeDebugMenuRuntime.FortControllerComponent_CreativeDebugger.OnMinigameStateChanged // (Final|Native|Public) // @ game+0xaa35910
};

