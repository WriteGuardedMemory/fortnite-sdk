// Class GameplayBehaviorSmartObjectsModule.GameplayBehaviorSmartObjectBehaviorDefinition
// Size: 0x30 (Inherited: 0x28)
struct UGameplayBehaviorSmartObjectBehaviorDefinition : USmartObjectBehaviorDefinition {
	struct UGameplayBehaviorConfig* GameplayBehaviorConfig; // 0x28(0x08)
};

// Class GameplayBehaviorSmartObjectsModule.AITask_UseGameplayBehaviorSmartObject
// Size: 0xd8 (Inherited: 0x68)
struct UAITask_UseGameplayBehaviorSmartObject : UAITask {
	struct FMulticastInlineDelegate OnSucceeded; // 0x68(0x10)
	struct FMulticastInlineDelegate OnFailed; // 0x78(0x10)
	struct FMulticastInlineDelegate OnMoveToFailed; // 0x88(0x10)
	struct UAITask_MoveTo* MoveToTask; // 0x98(0x08)
	struct UGameplayBehavior* GameplayBehavior; // 0xa0(0x08)
	char pad_A8[0x30]; // 0xa8(0x30)

	struct UAITask_UseGameplayBehaviorSmartObject* UseSmartObjectWithGameplayBehavior(struct AAIController* Controller, struct FSmartObjectClaimHandle ClaimHandle, bool bLockAILogic); // Function GameplayBehaviorSmartObjectsModule.AITask_UseGameplayBehaviorSmartObject.UseSmartObjectWithGameplayBehavior // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6e9acb0
	struct UAITask_UseGameplayBehaviorSmartObject* UseGameplayBehaviorSmartObject(struct AAIController* Controller, struct AActor* SmartObjectActor, struct USmartObjectComponent* SmartObjectComponent, bool bLockAILogic); // Function GameplayBehaviorSmartObjectsModule.AITask_UseGameplayBehaviorSmartObject.UseGameplayBehaviorSmartObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6e9a690
	struct UAITask_UseGameplayBehaviorSmartObject* MoveToAndUseSmartObjectWithGameplayBehavior(struct AAIController* Controller, struct FSmartObjectClaimHandle ClaimHandle, bool bLockAILogic); // Function GameplayBehaviorSmartObjectsModule.AITask_UseGameplayBehaviorSmartObject.MoveToAndUseSmartObjectWithGameplayBehavior // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6e9a9b0
};

// Class GameplayBehaviorSmartObjectsModule.BTTask_FindAndUseGameplayBehaviorSmartObject
// Size: 0x118 (Inherited: 0x70)
struct UBTTask_FindAndUseGameplayBehaviorSmartObject : UBTTaskNode {
	struct FGameplayTagQuery ActivityRequirements; // 0x70(0x48)
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0xb8(0x48)
	float Radius; // 0x100(0x04)
	char pad_104[0x14]; // 0x104(0x14)
};

// Class GameplayBehaviorSmartObjectsModule.GameplayBehaviorSmartObjectsBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UGameplayBehaviorSmartObjectsBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	bool UseGameplayBehaviorSmartObject(struct AActor* Avatar, struct AActor* SmartObject); // Function GameplayBehaviorSmartObjectsModule.GameplayBehaviorSmartObjectsBlueprintFunctionLibrary.UseGameplayBehaviorSmartObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6e9d290
};

