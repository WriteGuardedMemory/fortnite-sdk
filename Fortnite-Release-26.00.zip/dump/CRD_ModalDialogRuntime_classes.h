// Class CRD_ModalDialogRuntime.ModalDialogVariant
// Size: 0x408 (Inherited: 0x3e8)
struct UModalDialogVariant : UCommonActivatableWidget {
	struct UWidgetAnimation* BoundAnim_Open; // 0x3e8(0x08)
	struct UWidgetAnimation* BoundAnim_Response; // 0x3f0(0x08)
	struct FMulticastInlineDelegate OnResponseAnimationFinished; // 0x3f8(0x10)

	void OnResponseAnimationFinished__DelegateSignature(); // DelegateFunction CRD_ModalDialogRuntime.ModalDialogVariant.OnResponseAnimationFinished__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	bool HasResponseAnimation(); // Function CRD_ModalDialogRuntime.ModalDialogVariant.HasResponseAnimation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaacfbd0
	void HandleResponseAnimationFinished(); // Function CRD_ModalDialogRuntime.ModalDialogVariant.HandleResponseAnimationFinished // (Final|Native|Private) // @ game+0xaacfba0
	void AttemptToPlayResponseAnimation(); // Function CRD_ModalDialogRuntime.ModalDialogVariant.AttemptToPlayResponseAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xaacfc50
	void AttemptToPlayOpenAnimation(); // Function CRD_ModalDialogRuntime.ModalDialogVariant.AttemptToPlayOpenAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xaacfc00
};

