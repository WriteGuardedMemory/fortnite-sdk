// Class EpicMediaSchedule.EpicMediaSchedule
// Size: 0xf8 (Inherited: 0xa0)
struct UEpicMediaSchedule : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
};

