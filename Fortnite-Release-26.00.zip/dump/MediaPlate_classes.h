// Class MediaPlate.MediaPlate
// Size: 0x2a0 (Inherited: 0x290)
struct AMediaPlate : AActor {
	struct UMediaPlateComponent* MediaPlateComponent; // 0x290(0x08)
	struct UStaticMeshComponent* StaticMeshComponent; // 0x298(0x08)
};

// Class MediaPlate.MediaPlateAssetUserData
// Size: 0x38 (Inherited: 0x28)
struct UMediaPlateAssetUserData : UAssetUserData {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class MediaPlate.MediaPlateComponent
// Size: 0x168 (Inherited: 0xa0)
struct UMediaPlateComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	bool bPlayOnOpen; // 0xa8(0x01)
	bool bAutoPlay; // 0xa9(0x01)
	bool bEnableAudio; // 0xaa(0x01)
	char pad_AB[0x1]; // 0xab(0x01)
	float StartTime; // 0xac(0x04)
	struct UMediaSoundComponent* SoundComponent; // 0xb0(0x08)
	struct UStaticMeshComponent* StaticMeshComponent; // 0xb8(0x08)
	struct TArray<struct UStaticMeshComponent*> Letterboxes; // 0xc0(0x10)
	struct UMediaPlaylist* MediaPlaylist; // 0xd0(0x08)
	int32_t PlaylistIndex; // 0xd8(0x04)
	struct FMediaSourceCacheSettings CacheSettings; // 0xdc(0x08)
	bool bIsMediaPlatePlaying; // 0xe4(0x01)
	char pad_E5[0x7]; // 0xe5(0x07)
	bool bPlayOnlyWhenVisible; // 0xec(0x01)
	bool bLoop; // 0xed(0x01)
	enum class EMediaTextureVisibleMipsTiles VisibleMipsTilesCalculations; // 0xee(0x01)
	char pad_EF[0x1]; // 0xef(0x01)
	float MipMapBias; // 0xf0(0x04)
	bool bIsAspectRatioAuto; // 0xf4(0x01)
	bool bEnableMipMapUpscaling; // 0xf5(0x01)
	char pad_F6[0x2]; // 0xf6(0x02)
	int32_t MipLevelToUpscale; // 0xf8(0x04)
	float LetterboxAspectRatio; // 0xfc(0x04)
	char pad_100[0x8]; // 0x100(0x08)
	struct FVector2D MeshRange; // 0x108(0x10)
	struct TArray<struct UMediaTexture*> MediaTextures; // 0x118(0x10)
	struct UMediaPlayer* MediaPlayer; // 0x128(0x08)
	char pad_130[0x38]; // 0x130(0x38)

	void SetPlayOnlyWhenVisible(bool bInPlayOnlyWhenVisible); // Function MediaPlate.MediaPlateComponent.SetPlayOnlyWhenVisible // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1a870
	void SetMeshRange(struct FVector2D InMeshRange); // Function MediaPlate.MediaPlateComponent.SetMeshRange // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xbb1a9a0
	void SetLoop(bool bInLoop); // Function MediaPlate.MediaPlateComponent.SetLoop // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1aa90
	void SetLetterboxAspectRatio(float AspectRatio); // Function MediaPlate.MediaPlateComponent.SetLetterboxAspectRatio // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1a660
	void SetIsAspectRatioAuto(bool bInIsAspectRatioAuto); // Function MediaPlate.MediaPlateComponent.SetIsAspectRatioAuto // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1a770
	bool Seek(struct FTimespan& Time); // Function MediaPlate.MediaPlateComponent.Seek // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbb1ac30
	bool Rewind(); // Function MediaPlate.MediaPlateComponent.Rewind // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1ad40
	void Play(); // Function MediaPlate.MediaPlateComponent.Play // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1add0
	void Pause(); // Function MediaPlate.MediaPlateComponent.Pause // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1ad90
	void Open(); // Function MediaPlate.MediaPlateComponent.Open // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1ae10
	void OnMediaOpened(struct FString DeviceUrl); // Function MediaPlate.MediaPlateComponent.OnMediaOpened // (Final|Native|Private) // @ game+0xbb1a4a0
	void OnMediaEnd(); // Function MediaPlate.MediaPlateComponent.OnMediaEnd // (Final|Native|Private) // @ game+0xbb1a480
	bool IsMediaPlatePlaying(); // Function MediaPlate.MediaPlateComponent.IsMediaPlatePlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb1abb0
	struct FVector2D GetMeshRange(); // Function MediaPlate.MediaPlateComponent.GetMeshRange // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb1a970
	struct UMediaTexture* GetMediaTexture(int32_t Index); // Function MediaPlate.MediaPlateComponent.GetMediaTexture // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1ae30
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaPlate.MediaPlateComponent.GetMediaPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0xa5f6480
	bool GetLoop(); // Function MediaPlate.MediaPlateComponent.GetLoop // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbb1ab90
	float GetLetterboxAspectRatio(); // Function MediaPlate.MediaPlateComponent.GetLetterboxAspectRatio // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1a750
	bool GetIsAspectRatioAuto(); // Function MediaPlate.MediaPlateComponent.GetIsAspectRatioAuto // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7fa1f70
	void Close(); // Function MediaPlate.MediaPlateComponent.Close // (Final|Native|Public|BlueprintCallable) // @ game+0xbb1abd0
};

