// Class EpicMediaBasePlayer.EpicBaseStreamingVideo
// Size: 0x148 (Inherited: 0x28)
struct UEpicBaseStreamingVideo : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FMulticastInlineDelegate VideoOnTerminalError; // 0x30(0x10)
	struct FMulticastInlineDelegate VideoOnSuccess; // 0x40(0x10)
	struct FMulticastInlineDelegate VideoOnClosed; // 0x50(0x10)
	struct FMulticastInlineDelegate VideoOnEndReached; // 0x60(0x10)
	struct FMulticastInlineDelegate VideoOnOpenTimeout; // 0x70(0x10)
	struct FMulticastInlineDelegate VideoOnResumed; // 0x80(0x10)
	struct UEpicStreamMediaSource* MediaSource; // 0x90(0x08)
	struct UMediaPlayer* MediaPlayer; // 0x98(0x08)
	struct FIntPoint VideoSize; // 0xa0(0x08)
	char pad_A8[0x88]; // 0xa8(0x88)
	struct USoundSubmixBase* DefaultSubmix; // 0x130(0x08)
	struct USoundSubmixBase* LicensedSubmix; // 0x138(0x08)
	struct UMediaSoundComponent* MediaSoundComponent; // 0x140(0x08)

	void Stop(bool bRelease, bool bStopPlayer); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.Stop // (Native|Public|BlueprintCallable) // @ game+0x616f480
	void Start(struct FString InVUID, struct UMediaTexture* InVideoTexture); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.Start // (Final|Native|Public|BlueprintCallable) // @ game+0x616f610
	void SetVideoSize(int32_t Width, int32_t Height); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.SetVideoSize // (Final|Native|Public|BlueprintCallable) // @ game+0x616f0c0
	void SetSyncTimes(struct FDateTime InNowTime, struct FDateTime InStartTime, bool DynamicStart, float InOffset_s, float InDelay_s); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.SetSyncTimes // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x616e9d0
	void SetSoundSubmixes(struct UMediaSoundComponent* InSoundComponent, struct USoundSubmixBase* InDefault, struct USoundSubmixBase* InLicensed); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.SetSoundSubmixes // (Final|Native|Public|BlueprintCallable) // @ game+0x616ee30
	void SetOpenTimeout(double InTimeoutTime); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.SetOpenTimeout // (Final|Native|Public|BlueprintCallable) // @ game+0x616f250
	void SetCreateAudioComponent(bool bInCreateAudioComponent); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.SetCreateAudioComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x616ed40
	bool RetryOnError(bool bFromPlayer); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.RetryOnError // (Final|Native|Private) // @ game+0x616e2b0
	void Release(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.Release // (Native|Public|BlueprintCallable) // @ game+0x2740f50
	bool Open(struct FMediaPlayerOptions InMediaOptions); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.Open // (Native|Public|BlueprintCallable) // @ game+0x616f340
	void OnSuccessfulURL(struct FString URL); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.OnSuccessfulURL // (Final|Native|Private) // @ game+0x616e500
	void OnFailedURL(struct FString URL); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.OnFailedURL // (Final|Native|Private) // @ game+0x616e3a0
	bool Init(struct UMediaTexture* InVideoTexture, struct UMediaPlayer* InMediaPlayer, struct UEpicStreamMediaSource* InMediaSource, bool InCDNFailover); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.Init // (Native|Public|BlueprintCallable) // @ game+0x616f7e0
	void HandleMediaResumed(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.HandleMediaResumed // (Native|Protected) // @ game+0x3e76cd0
	void HandleMediaOpenedFailed(struct FString FailedUrl); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.HandleMediaOpenedFailed // (Final|Native|Protected) // @ game+0x616e660
	void HandleMediaOpened(struct FString OpenedUrl); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.HandleMediaOpened // (Final|Native|Protected) // @ game+0x616e7e0
	void HandleMediaEndReached(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.HandleMediaEndReached // (Final|Native|Protected) // @ game+0x616e7c0
	void HandleMediaClosed(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.HandleMediaClosed // (Final|Native|Protected) // @ game+0x616e970
	void HandleLicensedAudioTreatmentChanged(enum class UCPTypes UCPType); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.HandleLicensedAudioTreatmentChanged // (Final|Native|Private) // @ game+0x616e1c0
	struct UMediaSoundComponent* GetSoundComponent(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.GetSoundComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x3c7eeb0
	struct UEpicStreamMediaSource* GetMediaSource(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.GetMediaSource // (Final|Native|Public|BlueprintCallable) // @ game+0x3ea9980
	struct FMediaPlayerOptions GetMediaPlayerOptions(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.GetMediaPlayerOptions // (Native|Public) // @ game+0x616f050
	struct UMediaPlayer* GetMediaPlayer(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.GetMediaPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x616f0a0
	bool GetLicensedAudio(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.GetLicensedAudio // (Final|Native|Public|BlueprintCallable) // @ game+0x3726320
	void ClearSyncTimes(); // Function EpicMediaBasePlayer.EpicBaseStreamingVideo.ClearSyncTimes // (Final|Native|Public|BlueprintCallable) // @ game+0x616e990
};

