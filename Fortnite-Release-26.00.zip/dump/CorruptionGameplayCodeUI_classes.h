// Class CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget
// Size: 0x330 (Inherited: 0x328)
struct UFortPowerupReticleExtensionWidget : UFortWeaponReticleExtensionWidgetBase {
	enum class EPowerupHeatState LastPowerupHeatState; // 0x328(0x01)
	char pad_329[0x7]; // 0x329(0x07)

	float GetOverheatingMaxValue(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetOverheatingMaxValue // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa965ac0
	float GetCurrentOverheatValue(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetCurrentOverheatValue // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa965b70
	float GetCurrentOverheatPercent(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetCurrentOverheatPercent // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9659f0
};

