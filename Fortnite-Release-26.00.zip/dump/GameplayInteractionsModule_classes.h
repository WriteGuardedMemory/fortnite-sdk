// Class GameplayInteractionsModule.GameplayInteractionSmartObjectBehaviorDefinition
// Size: 0x40 (Inherited: 0x28)
struct UGameplayInteractionSmartObjectBehaviorDefinition : USmartObjectBehaviorDefinition {
	struct FStateTreeReference StateTreeReference; // 0x28(0x18)
};

// Class GameplayInteractionsModule.AITask_UseGameplayInteraction
// Size: 0x140 (Inherited: 0x68)
struct UAITask_UseGameplayInteraction : UAITask {
	struct FMulticastInlineDelegate OnFinished; // 0x68(0x10)
	struct FMulticastInlineDelegate OnSucceeded; // 0x78(0x10)
	struct FMulticastInlineDelegate OnFailed; // 0x88(0x10)
	struct FMulticastInlineDelegate OnMoveToFailed; // 0x98(0x10)
	struct FGameplayInteractionContext GameplayInteractionContext; // 0xa8(0x68)
	struct UAITask_MoveTo* MoveToTask; // 0x110(0x08)
	struct FSmartObjectClaimHandle ClaimedHandle; // 0x118(0x20)
	struct FGameplayInteractionAbortContext AbortContext; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)

	struct UAITask_UseGameplayInteraction* UseSmartObjectWithGameplayInteraction(struct AAIController* Controller, struct FSmartObjectClaimHandle ClaimHandle, bool bLockAILogic); // Function GameplayInteractionsModule.AITask_UseGameplayInteraction.UseSmartObjectWithGameplayInteraction // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6e85300
	void RequestAbort(); // Function GameplayInteractionsModule.AITask_UseGameplayInteraction.RequestAbort // (Final|Native|Public|BlueprintCallable) // @ game+0x6e85070
	struct UAITask_UseGameplayInteraction* MoveToAndUseSmartObjectWithGameplayInteraction(struct AAIController* Controller, struct FSmartObjectClaimHandle ClaimHandle, bool bLockAILogic); // Function GameplayInteractionsModule.AITask_UseGameplayInteraction.MoveToAndUseSmartObjectWithGameplayInteraction // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6e85090
};

// Class GameplayInteractionsModule.GameplayInteractionStateTreeSchema
// Size: 0x48 (Inherited: 0x28)
struct UGameplayInteractionStateTreeSchema : UStateTreeSchema {
	struct AActor* ContextActorClass; // 0x28(0x08)
	struct AActor* SmartObjectActorClass; // 0x30(0x08)
	struct TArray<struct FStateTreeExternalDataDesc> ContextDataDescs; // 0x38(0x10)
};

// Class GameplayInteractionsModule.StateTreeTask_PlayContextualAnim_InstanceData
// Size: 0xa0 (Inherited: 0x28)
struct UStateTreeTask_PlayContextualAnim_InstanceData : UObject {
	struct AActor* PrimaryActor; // 0x28(0x08)
	struct AActor* SecondaryActor; // 0x30(0x08)
	struct FName SecondaryRole; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct AActor* TertiaryActor; // 0x40(0x08)
	struct FName TertiaryRole; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct UContextualAnimSceneAsset* SceneAsset; // 0x50(0x08)
	struct FName SectionName; // 0x58(0x04)
	enum class EPlayContextualAnimExecutionMethod ExecutionMethod; // 0x5c(0x01)
	bool bWaitForNotifyEventToEnd; // 0x5d(0x01)
	char pad_5E[0x2]; // 0x5e(0x02)
	struct FName NotifyEventNameToEnd; // 0x60(0x04)
	int32_t LoopsToRun; // 0x64(0x04)
	bool bLoopForever; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	float DelayBetweenLoops; // 0x6c(0x04)
	float RandomDeviationBetweenLoops; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct TArray<struct FContextualAnimWarpTarget> WarpTargets; // 0x78(0x10)
	char pad_88[0x18]; // 0x88(0x18)

	void OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // Function GameplayInteractionsModule.StateTreeTask_PlayContextualAnim_InstanceData.OnNotifyBeginReceived // (Final|Native|Public|HasOutParms) // @ game+0x6e8dac0
	void OnMontageEnded(struct UAnimMontage* EndedMontage, bool bInterrupted); // Function GameplayInteractionsModule.StateTreeTask_PlayContextualAnim_InstanceData.OnMontageEnded // (Final|Native|Public) // @ game+0x6e8dc60
};

