// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility
// Size: 0xba8 (Inherited: 0xb28)
struct UCreativeVideoPlayerFullscreenGameplayAbility : UFortGameplayAbility {
	struct UGameplayEffect* NoCollisionGameplayEffectClass; // 0xb28(0x08)
	struct UGameplayEffect* NoDamageGameplayEffectClass; // 0xb30(0x08)
	struct TArray<struct UGameplayEffect*> AnimationStateGameplayEffectClasses; // 0xb38(0x10)
	struct UUserWidget* FullscreenWidgetClass; // 0xb48(0x08)
	enum class ECreativeVideoPlayerFullscreenEffects FullscreenEffects; // 0xb50(0x01)
	bool bPromptToConfirmFullscreen; // 0xb51(0x01)
	bool bIsDismissable; // 0xb52(0x01)
	char pad_B53[0x5]; // 0xb53(0x05)
	struct UFortInputComponent* OverrideMovementInputComponent; // 0xb58(0x08)
	struct UFortInputComponent* SelectFullscreenModeInputComponent; // 0xb60(0x08)
	struct TArray<struct FActiveGameplayEffectHandle> ActiveGameplayEffects; // 0xb68(0x10)
	enum class ECreativeVideoPlayerFullscreenEffects RequestedFullscreenEffects; // 0xb78(0x01)
	char pad_B79[0x7]; // 0xb79(0x07)
	struct UUserWidget* VideoPlayerWidget; // 0xb80(0x08)
	struct UMediaTexture* ExtMediaTextureCached; // 0xb88(0x08)
	struct USoundSourceBus* ExtSourceBusCached; // 0xb90(0x08)
	struct UMediaSoundComponent* ExtMediaSoundComponentCached; // 0xb98(0x08)
	bool bExtComponentsSet; // 0xba0(0x01)
	bool bActivatedFullscreen; // 0xba1(0x01)
	char pad_BA2[0x6]; // 0xba2(0x06)

	void SetExternalComponents(struct UMediaTexture* ExtMediaTexture, struct USoundSourceBus* ExtSourceBus, struct UMediaSoundComponent* ExtMediaSoundComponent); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.SetExternalComponents // (Final|Native|Public|BlueprintCallable) // @ game+0xaa62bb0
	void ServerLeaveFullscreenMode(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerLeaveFullscreenMode // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x7135b50
	void ServerEnterFullscreenMode(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ServerEnterFullscreenMode // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x8daaea0
	void OnFullscreenUIEnds(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.OnFullscreenUIEnds // (Final|Native|Private) // @ game+0xaa62b90
	void HandleEnterFullscreenActionReleased(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionReleased // (Final|Native|Private) // @ game+0xaa62b40
	void HandleEnterFullscreenActionPressed(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.HandleEnterFullscreenActionPressed // (Final|Native|Private) // @ game+0x3982d70
	void ExitFullscreenState(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ExitFullscreenState // (Final|Native|Public|BlueprintCallable) // @ game+0xaa63070
	void EnterFullscreenStateWithOptions(struct FCreativeVideoPlayerFullscreenOptions Options); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenStateWithOptions // (Final|Native|Public|BlueprintCallable) // @ game+0xaa630b0
	void EnterFullscreenState(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.EnterFullscreenState // (Final|Native|Public|BlueprintCallable) // @ game+0xaa631e0
	void ClientTransitionToFullscreenVideo(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientTransitionToFullscreenVideo // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x7135b30
	void ClientLeaveFullscreenVideo(); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFullscreenGameplayAbility.ClientLeaveFullscreenVideo // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x7135b10
};

// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCreativeVideoPlayerFunctionLibrary : UBlueprintFunctionLibrary {

	void ShutdownFullscreenVideoMode(struct AController* Controller); // Function CreativeVideoPlayerRuntime.CreativeVideoPlayerFunctionLibrary.ShutdownFullscreenVideoMode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xaa64c00
};

// Class CreativeVideoPlayerRuntime.CreativeVideoPlayerWorldSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UCreativeVideoPlayerWorldSubsystem : UWorldSubsystem {
	struct FMulticastInlineDelegate OnNotifyFullscreenChange; // 0x30(0x10)
};

