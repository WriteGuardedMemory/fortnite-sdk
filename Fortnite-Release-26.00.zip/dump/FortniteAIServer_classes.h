// Class FortniteAIServer.FortAthenaAIBotEvaluator_Harvest
// Size: 0x218 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Harvest : UFortAthenaAIBotEvaluator_Movement {
	char pad_1A8[0x20]; // 0x1a8(0x20)
	struct UNavigationQueryFilter* ProjectionNavigationQueryFilterClass; // 0x1c8(0x08)
	struct UNavigationQueryFilter* ValidNavigationQueryFilterClassOverride; // 0x1d0(0x08)
	struct FScalableFloat MaximumTimeToHelpFromLastPlayerDamage; // 0x1d8(0x28)
	struct FName HarvestTargetKeyName; // 0x200(0x04)
	char pad_204[0x4]; // 0x204(0x04)
	struct FName HarvestTargetHitPointKeyName; // 0x208(0x04)
	char pad_20C[0x4]; // 0x20c(0x04)
	struct FName HarvestDestinationKeyName; // 0x210(0x04)
	char pad_214[0x4]; // 0x214(0x04)

	void HandleUnconverted(struct AFortPawn* UnconvertedPawn, enum class EUnconvertReason UnconvertReason); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Harvest.HandleUnconverted // (Final|Native|Private) // @ game+0xa43f640
	void HandleConverted(struct AFortPawn* InstigatorPawn, struct AFortPawn* ConvertedPawn); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Harvest.HandleConverted // (Final|Native|Private) // @ game+0xa43f7c0
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_ImitatePlayerEmote
// Size: 0x310 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_ImitatePlayerEmote : UFortAthenaAIBotEvaluator_Movement {
	char pad_1A8[0x38]; // 0x1a8(0x38)
	struct FScalableFloat MinDistanceFromPlayerToPlayEmote; // 0x1e0(0x28)
	struct FScalableFloat MaxImitationDuration; // 0x208(0x28)
	struct FFortNearbyActorsPerceptionConfiguration PerceptionConfiguration; // 0x230(0xd0)
	struct FName ImitatePlayerEmoteTargetActorKeyName; // 0x300(0x04)
	char pad_304[0x4]; // 0x304(0x04)
	struct FName ImitatePlayerEmoteShouldMoveKeyName; // 0x308(0x04)
	char pad_30C[0x4]; // 0x30c(0x04)

	void HandlePawnStoppedEmote(struct UFortItemDefinition* MontageItemDef, struct AFortPawn* PawnEmoting); // Function FortniteAIServer.FortAthenaAIBotEvaluator_ImitatePlayerEmote.HandlePawnStoppedEmote // (Final|Native|Protected) // @ game+0xa43fb70
	void HandlePawnStartedEmote(struct UFortItemDefinition* MontageItemDef, struct AFortPawn* PawnEmoting); // Function FortniteAIServer.FortAthenaAIBotEvaluator_ImitatePlayerEmote.HandlePawnStartedEmote // (Final|Native|Protected) // @ game+0xa43fd60
};

// Class FortniteAIServer.FortAthenaAIEvaluator_AbovePhysicsObject
// Size: 0xa0 (Inherited: 0xa0)
struct UFortAthenaAIEvaluator_AbovePhysicsObject : UFortAthenaAIEvaluator {
};

// Class FortniteAIServer.FortAthenaBTService_MovementStyle
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTService_MovementStyle : UBTService {
	enum class EFortMovementStyle MovementStyle; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAIServer.FortBTWorldConditionSchema
// Size: 0x48 (Inherited: 0x38)
struct UFortBTWorldConditionSchema : UWorldConditionSchema {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class FortniteAIServer.FortAthenaBTService_WorldCondition
// Size: 0xd8 (Inherited: 0x70)
struct UFortAthenaBTService_WorldCondition : UBTService {
	struct FWorldConditionQueryDefinition Conditions; // 0x70(0x18)
	struct FName ConditionsResultName; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct FWorldConditionQueryState QueryState; // 0x90(0x30)
	struct AAIController* CachedOwnerController; // 0xc0(0x08)
	struct AActor* CachedOwnerPawn; // 0xc8(0x08)
	char pad_D0[0x8]; // 0xd0(0x08)
};

// Class FortniteAIServer.FortAthenaBTTask_Harvest
// Size: 0x98 (Inherited: 0x70)
struct UFortAthenaBTTask_Harvest : UBTTaskNode {
	struct FName HarvestExecutionStatusKeyName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FName HarvestTargetKeyName; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FName HarvestTargetHitPointKeyName; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
	struct FName HarvestDestinationKeyName; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct FName WeaponTriggerMeleeKeyName; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

// Class FortniteAIServer.FortAthenaBTTask_VehicleSwitchSeat
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTTask_VehicleSwitchSeat : UBTTaskNode {
	enum class SwitchSeatType SwitchSeatType; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAIServer.FortStateTreeConditionSchema
// Size: 0x50 (Inherited: 0x38)
struct UFortStateTreeConditionSchema : UWorldConditionSchema {
	char pad_38[0x18]; // 0x38(0x18)
};

// Class FortniteAIServer.FortBTDecorator_AIBotVehicleSeatStatus
// Size: 0x70 (Inherited: 0x68)
struct UFortBTDecorator_AIBotVehicleSeatStatus : UBTDecorator {
	enum class SeatStatusType SeatType; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class FortniteAIServer.FortBTService_AIEvaluatorsInjector
// Size: 0x90 (Inherited: 0x70)
struct UFortBTService_AIEvaluatorsInjector : UBTService {
	struct TArray<struct UObject*> ReferenceHolder; // 0x70(0x10)
	struct TArray<struct FFortBTService_InjectionTagKey> InjectionTagsKeys; // 0x80(0x10)
};

// Class FortniteAIServer.FortBTService_ClearGoalAndAssignment
// Size: 0x70 (Inherited: 0x70)
struct UFortBTService_ClearGoalAndAssignment : UBTService {
};

// Class FortniteAIServer.FortGameFeatureAction_InjectAIBehavior
// Size: 0x48 (Inherited: 0x38)
struct UFortGameFeatureAction_InjectAIBehavior : UFortGameInstanceGameFeatureAction {
	struct TArray<struct FFortAISpawnerTagQueryInjectedBehavior> InjectedBehaviors; // 0x38(0x10)
};

// Class FortniteAIServer.FortInjectedBehaviorsComponent
// Size: 0xf0 (Inherited: 0xa0)
struct UFortInjectedBehaviorsComponent : UFortGameStateComponent {
	char pad_A0[0x50]; // 0xa0(0x50)
};

// Class FortniteAIServer.FortQueryContext_PlayspaceVolume
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_PlayspaceVolume : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryGenerator_GridInBox
// Size: 0x138 (Inherited: 0x88)
struct UFortQueryGenerator_GridInBox : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue BoxWidth; // 0x88(0x38)
	struct FAIDataProviderFloatValue BoxLength; // 0xc0(0x38)
	struct FAIDataProviderFloatValue SpaceBetween; // 0xf8(0x38)
	struct UEnvQueryContext* GenerateAround; // 0x130(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_GridInVolume
// Size: 0xc8 (Inherited: 0x88)
struct UFortQueryGenerator_GridInVolume : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue SpaceBetween; // 0x88(0x38)
	struct UEnvQueryContext* GenerateInVolume; // 0xc0(0x08)
};

// Class FortniteAIServer.FortWorldConditionTimeOfDayState
// Size: 0x60 (Inherited: 0x28)
struct UFortWorldConditionTimeOfDayState : UObject {
	char pad_28[0x38]; // 0x28(0x38)

	void HandleTimeOfDayPhaseChange(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function FortniteAIServer.FortWorldConditionTimeOfDayState.HandleTimeOfDayPhaseChange // (Final|Native|Private) // @ game+0xa4439b0
};

// Class FortniteAIServer.FortGameFeatureAction_InjectAIEvaluators
// Size: 0x38 (Inherited: 0x28)
struct UFortGameFeatureAction_InjectAIEvaluators : UGameFeatureAction {
	struct TArray<struct FGameFeatureFortAIEvaluatorEntry> AIEvaluatorList; // 0x28(0x10)
};

// Class FortniteAIServer.FortEnvQueryGenerator_ProjectedPoints
// Size: 0x90 (Inherited: 0x88)
struct UFortEnvQueryGenerator_ProjectedPoints : UEnvQueryGenerator_ProjectedPoints {
	struct FName OverridenAgentNameForNavmesh; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// Class FortniteAIServer.FortEnvQueryGenerator_SimpleGrid
// Size: 0x108 (Inherited: 0x90)
struct UFortEnvQueryGenerator_SimpleGrid : UFortEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue GridSize; // 0x90(0x38)
	struct FAIDataProviderFloatValue SpaceBetween; // 0xc8(0x38)
	struct UEnvQueryContext* GenerateAround; // 0x100(0x08)
};

// Class FortniteAIServer.FortBTService_ContextOverride
// Size: 0x70 (Inherited: 0x70)
struct UFortBTService_ContextOverride : UBTService {
};

// Class FortniteAIServer.FortBTContext_MoveUrgency
// Size: 0x78 (Inherited: 0x70)
struct UFortBTContext_MoveUrgency : UFortBTService_ContextOverride {
	enum class EFortMovementUrgency MoveUrgency; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAIServer.FortBTContext_SkipNotPerceivedGoals
// Size: 0x70 (Inherited: 0x70)
struct UFortBTContext_SkipNotPerceivedGoals : UFortBTService_ContextOverride {
};

// Class FortniteAIServer.FortBTContext_SuppressGoalUpdate
// Size: 0x78 (Inherited: 0x70)
struct UFortBTContext_SuppressGoalUpdate : UFortBTService_ContextOverride {
	bool bUnregisterFromGoalManager; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAIServer.FortBTDecorator_CanBeConsideredAirborne
// Size: 0x90 (Inherited: 0x90)
struct UFortBTDecorator_CanBeConsideredAirborne : UBTDecorator_BlackboardBase {
};

// Class FortniteAIServer.FortBTDecorator_DistanceBetween
// Size: 0xd0 (Inherited: 0x68)
struct UFortBTDecorator_DistanceBetween : UBTDecorator {
	enum class EArithmeticKeyOperation Operator; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FBlackboardKeySelector BlackboardKeyA; // 0x70(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x98(0x28)
	float SpecifiedDistance; // 0xc0(0x04)
	char bUseSelf : 1; // 0xc4(0x01)
	char bCalculateAs2D : 1; // 0xc4(0x01)
	char pad_C4_2 : 6; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	float DistanceCalculationUpdateRate; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_CanActivate
// Size: 0x100 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_CanActivate : UFortBTDecorator_QueryGameplayAbility {
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_CanHitTarget
// Size: 0x108 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_CanHitTarget : UFortBTDecorator_QueryGameplayAbility {
	char UseIdealYawRotationToTarget : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_CompareDistance
// Size: 0x110 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_CompareDistance : UFortBTDecorator_QueryGameplayAbility {
	struct TArray<struct FDistanceToTargetComparison> DistanceComparisons; // 0x100(0x10)
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_DoesTargetHaveProhibitedTags
// Size: 0x100 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_DoesTargetHaveProhibitedTags : UFortBTDecorator_QueryGameplayAbility {
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_HasGameplayAbility
// Size: 0xe0 (Inherited: 0x68)
struct UFortBTDecorator_GameplayAbility_HasGameplayAbility : UBTDecorator {
	struct FBlackboardKeySelector AbilityOwningActorKey; // 0x68(0x28)
	struct FGameplayTagContainer GameplayAbilityTag; // 0x90(0x20)
	struct FBlackboardKeySelector GameplayAbilityTagBlackboardKey; // 0xb0(0x28)
	bool bOnlyTestActiveAbility; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_HasNearbyPawns
// Size: 0x108 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_HasNearbyPawns : UFortBTDecorator_QueryGameplayAbility {
	float NearbyPawnDistance; // 0x100(0x04)
	bool bFilterAIPawns; // 0x104(0x01)
	bool bFilterPlayerPawns; // 0x105(0x01)
	char pad_106[0x2]; // 0x106(0x02)
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_IsClosestPawnInRange
// Size: 0x108 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_IsClosestPawnInRange : UFortBTDecorator_QueryGameplayAbility {
	float NearbyPawnDistance; // 0x100(0x04)
	bool bFilterAIPawns; // 0x104(0x01)
	bool bFilterPlayerPawns; // 0x105(0x01)
	char pad_106[0x2]; // 0x106(0x02)
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_IsOnCooldown
// Size: 0x100 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_IsOnCooldown : UFortBTDecorator_QueryGameplayAbility {
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_IsRotatedToAttackTarget
// Size: 0x100 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_IsRotatedToAttackTarget : UFortBTDecorator_QueryGameplayAbility {
};

// Class FortniteAIServer.FortBTDecorator_GameplayAbility_IsWithinMaxTargetSelectionRange
// Size: 0x100 (Inherited: 0x100)
struct UFortBTDecorator_GameplayAbility_IsWithinMaxTargetSelectionRange : UFortBTDecorator_QueryGameplayAbility {
};

// Class FortniteAIServer.FortBTDecorator_IsGoalPawn
// Size: 0x90 (Inherited: 0x90)
struct UFortBTDecorator_IsGoalPawn : UBTDecorator_BlackboardBase {
};

// Class FortniteAIServer.FortBTDecorator_IsInBotEndGame
// Size: 0x68 (Inherited: 0x68)
struct UFortBTDecorator_IsInBotEndGame : UBTDecorator {
};

// Class FortniteAIServer.FortBTDecorator_IsMoving
// Size: 0x148 (Inherited: 0x100)
struct UFortBTDecorator_IsMoving : UFortBTDecorator_QueryGameplayAbility {
	float UpdateInterval; // 0x100(0x04)
	float MinTime; // 0x104(0x04)
	bool bUseMinDist; // 0x108(0x01)
	char pad_109[0x3]; // 0x109(0x03)
	float MinDistMinTime; // 0x10c(0x04)
	struct FDistanceToTargetComparison MinDistanceComparison; // 0x110(0x38)
};

// Class FortniteAIServer.FortBTDecorator_IsTakerAirborne
// Size: 0x68 (Inherited: 0x68)
struct UFortBTDecorator_IsTakerAirborne : UBTDecorator {
};

// Class FortniteAIServer.FortBTDecorator_WeaponStatus
// Size: 0x98 (Inherited: 0x68)
struct UFortBTDecorator_WeaponStatus : UBTDecorator {
	float WeaponStatusUpdateRate; // 0x68(0x04)
	char bTestIfCurrentWeaponIsValid : 1; // 0x6c(0x01)
	char bCurrentWeaponShouldBeValid : 1; // 0x6c(0x01)
	char bTestAllowedCurrentWeaponTags : 1; // 0x6c(0x01)
	char pad_6C_3 : 5; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	struct FGameplayTagContainer AllowedCurrentWeaponTags; // 0x70(0x20)
	char bTestIfCurrentWeaponIsReloading : 1; // 0x90(0x01)
	char bCurrentWeaponShouldBeReloading : 1; // 0x90(0x01)
	char bTestIfCurrentWeaponHasAmmoInMagazine : 1; // 0x90(0x01)
	char bCurrentWeaponShouldHaveAmmoInMagazine : 1; // 0x90(0x01)
	char bTestIfCurrentWeaponHasExtraAmmo : 1; // 0x90(0x01)
	char bCurrentWeaponShouldHaveExtraAmmo : 1; // 0x90(0x01)
	char bAllInterestedTestsMustPass : 1; // 0x90(0x01)
	char pad_90_7 : 1; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class FortniteAIServer.FortBTService_ActivateAbility
// Size: 0xd0 (Inherited: 0x70)
struct UFortBTService_ActivateAbility : UBTService {
	struct FGameplayTagContainer AbilityTags; // 0x70(0x20)
	bool bRequireCanHitTargetWithAbility; // 0x90(0x01)
	bool bPawnTargetsOnly; // 0x91(0x01)
	char pad_92[0x6]; // 0x92(0x06)
	struct FGameplayTagContainer ProhibitedTargetTags; // 0x98(0x20)
	bool bCanActivateWhenMoving; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
	struct TArray<struct FDistanceToTargetComparison> DistanceChecks; // 0xc0(0x10)
};

// Class FortniteAIServer.FortBTService_UpdateBotMissionBuilding
// Size: 0xc0 (Inherited: 0x70)
struct UFortBTService_UpdateBotMissionBuilding : UBTService {
	struct FBlackboardKeySelector InterestLocationKey; // 0x70(0x28)
	struct FBlackboardKeySelector BuildOrderKey; // 0x98(0x28)
};

// Class FortniteAIServer.FortBTService_UpdateBotMissionGoal
// Size: 0xa0 (Inherited: 0x98)
struct UFortBTService_UpdateBotMissionGoal : UBTService_BlackboardBase {
	char bRequireInteraction : 1; // 0x98(0x01)
	char bRequireInteractionOrLocator : 1; // 0x98(0x01)
	char bRequireEncounter : 1; // 0x98(0x01)
	char bPickClosest : 1; // 0x98(0x01)
	char pad_98_4 : 4; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class FortniteAIServer.FortBTTask_BotMissionBuild
// Size: 0x98 (Inherited: 0x98)
struct UFortBTTask_BotMissionBuild : UBTTask_BlackboardBase {
};

// Class FortniteAIServer.FortBTTask_BotMissionInteract
// Size: 0x98 (Inherited: 0x98)
struct UFortBTTask_BotMissionInteract : UBTTask_BlackboardBase {
};

// Class FortniteAIServer.FortBTTask_ExecuteGameplayAbility
// Size: 0xc8 (Inherited: 0x78)
struct UFortBTTask_ExecuteGameplayAbility : UBTTask_GameplayTaskBase {
	struct FGameplayTagContainer GameplayAbilityTag; // 0x78(0x20)
	struct FBlackboardKeySelector GameplayAbilityTagBlackboardKey; // 0x98(0x28)
	bool bUseBlackboardTag; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class FortniteAIServer.FortBTTask_GameMoveTo
// Size: 0x120 (Inherited: 0xb0)
struct UFortBTTask_GameMoveTo : UBTTask_MoveTo {
	struct FBlackboardKeySelector FocalPointWhileMoving; // 0xb0(0x28)
	enum class EPathObstacleAction PathObstacleAction; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct AFortPawn* PushBumpedPawnClass; // 0xe0(0x08)
	struct FGameplayTag NavFilterTag; // 0xe8(0x04)
	char bDetectUnexpectedPathBlockingObstacles : 1; // 0xec(0x01)
	char bEnableSlowdownAtGoal : 1; // 0xec(0x01)
	char bStopAtGoal : 1; // 0xec(0x01)
	char bFinishMoveOnOverlap : 1; // 0xec(0x01)
	char pad_EC_4 : 4; // 0xec(0x01)
	char pad_ED[0x3]; // 0xed(0x03)
	struct FBlackboardKeySelector AcceptableRadiusKey; // 0xf0(0x28)
	char bDeimosFlavor : 1; // 0x118(0x01)
	char pad_118_1 : 7; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
};

// Class FortniteAIServer.FortBTTask_GameMoveDirectlyToward
// Size: 0x120 (Inherited: 0x120)
struct UFortBTTask_GameMoveDirectlyToward : UFortBTTask_GameMoveTo {
};

// Class FortniteAIServer.FortBTTask_RequestUndermining
// Size: 0x70 (Inherited: 0x70)
struct UFortBTTask_RequestUndermining : UBTTaskNode {
};

// Class FortniteAIServer.FortBTTask_RotateToFaceBBEntryWithTags
// Size: 0xc0 (Inherited: 0xa0)
struct UFortBTTask_RotateToFaceBBEntryWithTags : UBTTask_RotateToFaceBBEntry {
	struct FGameplayTagContainer TagsToApply; // 0xa0(0x20)
};

// Class FortniteAIServer.FortBTTask_SetFrustrationDiscouragement
// Size: 0x78 (Inherited: 0x70)
struct UFortBTTask_SetFrustrationDiscouragement : UBTTaskNode {
	float DiscouragementDuration; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class FortniteAIServer.FortBTTask_Sleep
// Size: 0x70 (Inherited: 0x70)
struct UFortBTTask_Sleep : UBTTaskNode {
};

// Class FortniteAIServer.FortBTTask_TakerMoveToNavmesh
// Size: 0xb0 (Inherited: 0xb0)
struct UFortBTTask_TakerMoveToNavmesh : UBTTask_MoveTo {
};

// Class FortniteAIServer.FortEQSPrevisActor
// Size: 0x2c8 (Inherited: 0x290)
struct AFortEQSPrevisActor : AActor {
	char pad_290[0x10]; // 0x290(0x10)
	struct USceneComponent* SceneRoot; // 0x2a0(0x08)
	struct FGameplayTagContainer GameplayTags; // 0x2a8(0x20)

	void SetQueryTemplate(struct UEnvQuery* InPrevisQueryTemplate); // Function FortniteAIServer.FortEQSPrevisActor.SetQueryTemplate // (Final|Native|Public|BlueprintCallable) // @ game+0x34e0930
	void PrepForPrevis(); // Function FortniteAIServer.FortEQSPrevisActor.PrepForPrevis // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class FortniteAIServer.FortQueryContext_AIPawnSpawnLocation
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_AIPawnSpawnLocation : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_AllBots
// Size: 0x78 (Inherited: 0x28)
struct UFortQueryContext_AllBots : UEnvQueryContext {
	bool bIncludeOnlyAthenaGameParticipantBots; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FGameplayTagQuery BotTagQuery; // 0x30(0x48)
};

// Class FortniteAIServer.FortQueryContext_AllEnemies
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_AllEnemies : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_AllGoals
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_AllGoals : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_AllPlayers
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_AllPlayers : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_AllPOIVolumes
// Size: 0x70 (Inherited: 0x28)
struct UFortQueryContext_AllPOIVolumes : UEnvQueryContext {
	struct FGameplayTagQuery VolumeLocationTagQuery; // 0x28(0x48)
};

// Class FortniteAIServer.FortQueryContext_AthenaCurrentSafeZoneCenter
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_AthenaCurrentSafeZoneCenter : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_AthenaCurrentSafeZoneIndicatorCenter
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_AthenaCurrentSafeZoneIndicatorCenter : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_AthenaSafeZonePredictedLocation
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_AthenaSafeZonePredictedLocation : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_BlackboardKeyLeader
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_BlackboardKeyLeader : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_BuildingRifts
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_BuildingRifts : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_EncounterFallbackTarget
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_EncounterFallbackTarget : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_EncounterGoalsCenterLocation
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_EncounterGoalsCenterLocation : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_EncounterGoalsOnGround
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_EncounterGoalsOnGround : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_EncounterPrimaryAssignmentGoals
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_EncounterPrimaryAssignmentGoals : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_EncounterProvidedQueryLocations
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_EncounterProvidedQueryLocations : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_EncounterQueryActor
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_EncounterQueryActor : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_EncounterRandomDirection
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_EncounterRandomDirection : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_EncounterTargetObjective
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_EncounterTargetObjective : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_Goal
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_Goal : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_GoalProviderRootAssignmentGoals
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_GoalProviderRootAssignmentGoals : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_Goal_SpawnLocation
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_Goal_SpawnLocation : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_NearbyAIPawns
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_NearbyAIPawns : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_NearbyAIPawnsMoveDestinations
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_NearbyAIPawnsMoveDestinations : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_NearbyFriendlyAIPawns
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_NearbyFriendlyAIPawns : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_NearbyFriendlyAIPawnsAndPlayerPawns
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_NearbyFriendlyAIPawnsAndPlayerPawns : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_NearbyFriends
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_NearbyFriends : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_RandomDirectionXY
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_RandomDirectionXY : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_SpawnSpotActorLocationOrAIPawnSpawnLocation
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_SpawnSpotActorLocationOrAIPawnSpawnLocation : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_StWStormShield
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_StWStormShield : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_TwoPointSolverPointA
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_TwoPointSolverPointA : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryContext_TwoPointSolverRotationA
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_TwoPointSolverRotationA : UEnvQueryContext {
};

// Class FortniteAIServer.FortQueryData_CurvesAroundLine
// Size: 0x90 (Inherited: 0x30)
struct UFortQueryData_CurvesAroundLine : UDataAsset {
	struct FFortPointsOnCurve PointsOnSideA; // 0x30(0x30)
	struct FFortPointsOnCurve PointsOnSideB; // 0x60(0x30)
};

// Class FortniteAIServer.FortQueryGenerator_ActorsAround
// Size: 0xd0 (Inherited: 0xd0)
struct UFortQueryGenerator_ActorsAround : UEnvQueryGenerator_ActorsOfClass {
};

// Class FortniteAIServer.FortQueryGenerator_Allies
// Size: 0x50 (Inherited: 0x50)
struct UFortQueryGenerator_Allies : UEnvQueryGenerator {
};

// Class FortniteAIServer.FortQueryGenerator_AssignmentGoal
// Size: 0x50 (Inherited: 0x50)
struct UFortQueryGenerator_AssignmentGoal : UEnvQueryGenerator {
};

// Class FortniteAIServer.FortQueryGenerator_BuildingRifts
// Size: 0x50 (Inherited: 0x50)
struct UFortQueryGenerator_BuildingRifts : UEnvQueryGenerator {
};

// Class FortniteAIServer.FortQueryGenerator_Buildings
// Size: 0x228 (Inherited: 0x50)
struct UFortQueryGenerator_Buildings : UEnvQueryGenerator {
	struct FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x50(0x30)
	struct UFortAIAssignmentSettings* AssignmentSettings; // 0x80(0x08)
	struct UEnvQueryContext* BuildingGridVolumeCenter; // 0x88(0x08)
	struct FAIDataProviderIntValue HorizontalBuildingCellRadius; // 0x90(0x38)
	struct FAIDataProviderIntValue BuildingCellsAbove; // 0xc8(0x38)
	struct FAIDataProviderIntValue BuildingCellsBelow; // 0x100(0x38)
	struct FAIDataProviderBoolValue bIncludeWalls; // 0x138(0x38)
	struct FAIDataProviderBoolValue bIncludeFloors; // 0x170(0x38)
	struct TArray<enum class EFloorPatternType> FloorPatternsToIgnore; // 0x1a8(0x10)
	struct FAIDataProviderBoolValue bIncludeCenterCell; // 0x1b8(0x38)
	struct FAIDataProviderIntValue MaxBuildingActorsPerVolumeCenterToCollect; // 0x1f0(0x38)
};

// Class FortniteAIServer.FortQueryGenerator_BuildingsOnCachedPath
// Size: 0x100 (Inherited: 0x50)
struct UFortQueryGenerator_BuildingsOnCachedPath : UEnvQueryGenerator {
	struct UEnvQueryContext* CachedPathSource; // 0x50(0x08)
	struct FAIDataProviderBoolValue bIncludeWalls; // 0x58(0x38)
	struct FAIDataProviderBoolValue bIncludeFloors; // 0x90(0x38)
	struct FAIDataProviderBoolValue bIncludeCenterCell; // 0xc8(0x38)
};

// Class FortniteAIServer.FortQueryGenerator_EncounterTargets
// Size: 0x50 (Inherited: 0x50)
struct UFortQueryGenerator_EncounterTargets : UEnvQueryGenerator {
};

// Class FortniteAIServer.FortQueryGenerator_Enemies
// Size: 0xd0 (Inherited: 0x50)
struct UFortQueryGenerator_Enemies : UEnvQueryGenerator {
	bool bPerceivedEnemiesOnly; // 0x50(0x01)
	bool bSleepCapableAIUsePerceivedEnemiesOnly; // 0x51(0x01)
	bool bIgnoreDBNOPawns; // 0x52(0x01)
	bool bIgnoreSleepingAIs; // 0x53(0x01)
	bool bAddEnemiesFromAbilityRange; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	struct FGameplayTagContainer AbilityTags; // 0x58(0x20)
	struct FGameplayTagContainer DistanceTags; // 0x78(0x20)
	struct FAIDataProviderFloatValue MaxTimeSincePerceived; // 0x98(0x38)
};

// Class FortniteAIServer.FortQueryGenerator_GoalActorsOfClass
// Size: 0x98 (Inherited: 0x50)
struct UFortQueryGenerator_GoalActorsOfClass : UEnvQueryGenerator {
	struct AActor* SearchedActorClass; // 0x50(0x08)
	struct FAIDataProviderFloatValue SearchRadius; // 0x58(0x38)
	struct UEnvQueryContext* SearchCenter; // 0x90(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_GoalOnCircle
// Size: 0x260 (Inherited: 0x220)
struct UFortQueryGenerator_GoalOnCircle : UEnvQueryGenerator_OnCircle {
	bool bIncludeCenterActorInGeneratedGoals; // 0x220(0x01)
	char pad_221[0x7]; // 0x221(0x07)
	struct UFortAIAssignmentSettings* OptionalAssignmentSettings; // 0x228(0x08)
	struct FFortAIAssignmentIdentifier OptionalAssignmentIdentifier; // 0x230(0x30)
};

// Class FortniteAIServer.FortQueryGenerator_GoalPlayerPawns
// Size: 0x58 (Inherited: 0x50)
struct UFortQueryGenerator_GoalPlayerPawns : UEnvQueryGenerator {
	bool bOnlyAthenaGameParticipants; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// Class FortniteAIServer.FortQueryGenerator_GoalTrackableAIObjects
// Size: 0xd0 (Inherited: 0x50)
struct UFortQueryGenerator_GoalTrackableAIObjects : UEnvQueryGenerator {
	struct FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x50(0x30)
	struct AActor* SearchedActorClass; // 0x80(0x08)
	struct FGameplayTag RequiredTag; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct FAIDataProviderFloatValue SearchRadius; // 0x90(0x38)
	struct UEnvQueryContext* SearchCenter; // 0xc8(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_HotspotSlots
// Size: 0xa0 (Inherited: 0x50)
struct UFortQueryGenerator_HotspotSlots : UEnvQueryGenerator {
	struct UEnvQueryContext* GenerateAround; // 0x50(0x08)
	struct FAIDataProviderFloatValue Radius; // 0x58(0x38)
	char bUseTetherZone : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct AFortAIHotSpot* HotspotClass; // 0x98(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_InfluenceMapPoints
// Size: 0xd0 (Inherited: 0x88)
struct UFortQueryGenerator_InfluenceMapPoints : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderIntValue Density; // 0x88(0x38)
	char bOnlyFlatSurface : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct UEnvQueryContext* GenerateAround; // 0xc8(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_LootGoalsAthena
// Size: 0x128 (Inherited: 0x50)
struct UFortQueryGenerator_LootGoalsAthena : UEnvQueryGenerator {
	struct FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x50(0x30)
	struct UFortAIAssignmentSettings* AssignmentSettings; // 0x80(0x08)
	struct FAIDataProviderFloatValue HorizontalHalfExtents; // 0x88(0x38)
	struct FAIDataProviderFloatValue VerticalHalfExtents; // 0xc0(0x38)
	struct UEnvQueryContext* SearchCenter; // 0xf8(0x08)
	char bAvailableLootOnly : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FGameplayTagContainer ExcludedAILootGameplayTags; // 0x108(0x20)
};

// Class FortniteAIServer.FortQueryGenerator_MissionPlacementActors
// Size: 0x98 (Inherited: 0x50)
struct UFortQueryGenerator_MissionPlacementActors : UEnvQueryGenerator {
	struct FGameplayTagQuery MissionPlacementActorTagQuery; // 0x50(0x48)
};

// Class FortniteAIServer.FortQueryGenerator_MutatorActorQueryResults
// Size: 0x50 (Inherited: 0x50)
struct UFortQueryGenerator_MutatorActorQueryResults : UEnvQueryGenerator {
};

// Class FortniteAIServer.FortQueryGenerator_MutatorBaseQueryResults
// Size: 0x50 (Inherited: 0x50)
struct UFortQueryGenerator_MutatorBaseQueryResults : UEnvQueryGenerator {
};

// Class FortniteAIServer.FortQueryGenerator_PerceivedActors
// Size: 0x128 (Inherited: 0x50)
struct UFortQueryGenerator_PerceivedActors : UEnvQueryGenerator {
	bool bGenerateHostileActorGoal; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	struct FFortQueryGenerator_PerceivedActors_Settings HostileActorSettings; // 0x58(0x40)
	bool bGenerateNeutralActorGoal; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FFortQueryGenerator_PerceivedActors_Settings NeutralActorSettings; // 0xa0(0x40)
	bool bGenerateFriendlyActorGoal; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
	struct FFortQueryGenerator_PerceivedActors_Settings FriendlyActorSettings; // 0xe8(0x40)
};

// Class FortniteAIServer.FortQueryGenerator_PointsAroundLine
// Size: 0x120 (Inherited: 0x88)
struct UFortQueryGenerator_PointsAroundLine : UEnvQueryGenerator_ProjectedPoints {
	struct UEnvQueryContext* GenerateAround; // 0x88(0x08)
	struct FAIDataProviderIntValue MaxPointsPerClusterLocation; // 0x90(0x38)
	struct FAIDataProviderFloatValue ClusterRadius; // 0xc8(0x38)
	struct TSoftObjectPtr<UFortQueryData_CurvesAroundLine> CurvesAroundLineAsset; // 0x100(0x20)
};

// Class FortniteAIServer.FortQueryGenerator_PointsFromNavGraph
// Size: 0x1d8 (Inherited: 0x88)
struct UFortQueryGenerator_PointsFromNavGraph : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue MinPathDistance; // 0x88(0x38)
	struct FAIDataProviderFloatValue MaxPathDistance; // 0xc0(0x38)
	struct FAIDataProviderIntValue Density; // 0xf8(0x38)
	struct FAIDataProviderFloatValue ExploreDirectionYaw; // 0x130(0x38)
	struct FEnvDirection ExploreDirection; // 0x168(0x20)
	float ExploreAngleDot; // 0x188(0x04)
	char pad_18C[0x4]; // 0x18c(0x04)
	struct FAIDataProviderFloatValue ExploreInnerRadius; // 0x190(0x38)
	char bLimitExplorationDirection : 1; // 0x1c8(0x01)
	char bOnlyFlatSurface : 1; // 0x1c8(0x01)
	char bUseParameterizedDirection : 1; // 0x1c8(0x01)
	char bUseHeightCheck : 1; // 0x1c8(0x01)
	char bFilterAllowTerrain : 1; // 0x1c8(0x01)
	char bFilterAllowBuildings : 1; // 0x1c8(0x01)
	char bFilterAllowDropdown : 1; // 0x1c8(0x01)
	char bFilterAllowClimbup : 1; // 0x1c8(0x01)
	char bFilterAllowSmash : 1; // 0x1c9(0x01)
	char pad_1C9_1 : 7; // 0x1c9(0x01)
	char pad_1CA[0x2]; // 0x1ca(0x02)
	enum class EFortPointsFromNavGraphGoalPathDistanceFilterOperator PathDistanceFilterOperator; // 0x1cc(0x01)
	char pad_1CD[0x3]; // 0x1cd(0x03)
	struct UEnvQueryContext* GenerateAround; // 0x1d0(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_PointsInVolume
// Size: 0x98 (Inherited: 0x50)
struct UFortQueryGenerator_PointsInVolume : UEnvQueryGenerator {
	struct FAIDataProviderIntValue NumberOfPoints; // 0x50(0x38)
	enum class EFortNamedNavmesh NavMeshToUse; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct UEnvQueryContext* GenerateIn; // 0x90(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_PointsOnBuildingActors
// Size: 0x250 (Inherited: 0x88)
struct UFortQueryGenerator_PointsOnBuildingActors : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue BoundingBoxExtentXY; // 0x88(0x38)
	struct FAIDataProviderFloatValue BoundingBoxExtentZ; // 0xc0(0x38)
	struct FAIDataProviderFloatValue PointDensity; // 0xf8(0x38)
	struct FAIDataProviderIntValue MaxGeneratedPoints; // 0x130(0x38)
	struct FFortTaggedActorOctreeFilter ActorLookupFilter; // 0x168(0xa8)
	struct FAIDataProviderFloatValue RandomChanceToSkip; // 0x210(0x38)
	struct UEnvQueryContext* GenerateAround; // 0x248(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_PointsOnBuildingGrid
// Size: 0x108 (Inherited: 0x88)
struct UFortQueryGenerator_PointsOnBuildingGrid : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderIntValue HorizontalGridSize; // 0x88(0x38)
	struct FAIDataProviderIntValue VerticalGridSize; // 0xc0(0x38)
	bool bStartGridFromBottom; // 0xf8(0x01)
	bool bUsePointInVerticalCenterOfCell; // 0xf9(0x01)
	char pad_FA[0x6]; // 0xfa(0x06)
	struct UEnvQueryContext* GenerateAround; // 0x100(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_PointsOnWaterShoreLine
// Size: 0xb0 (Inherited: 0x88)
struct UFortQueryGenerator_PointsOnWaterShoreLine : UEnvQueryGenerator_ProjectedPoints {
	struct UEnvQueryContext* GenerateAround; // 0x88(0x08)
	struct TSoftObjectPtr<UFortQueryData_CurvesAroundLine> CurvesAroundLineAsset; // 0x90(0x20)
};

// Class FortniteAIServer.FortQueryGenerator_RandomPointsInBoundingVolume
// Size: 0xc8 (Inherited: 0x88)
struct UFortQueryGenerator_RandomPointsInBoundingVolume : UEnvQueryGenerator_ProjectedPoints {
	struct UEnvQueryContext* GenerateIn; // 0x88(0x08)
	struct FAIDataProviderFloatValue RandomPointsCount; // 0x90(0x38)
};

// Class FortniteAIServer.FortQueryGenerator_SpecificAssignmentGoals
// Size: 0x90 (Inherited: 0x50)
struct UFortQueryGenerator_SpecificAssignmentGoals : UEnvQueryGenerator {
	struct FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x50(0x30)
	struct UFortAIAssignmentSettings* AssignmentSettings; // 0x80(0x08)
	struct UFortAIGoalProvider* GoalProvider; // 0x88(0x08)
};

// Class FortniteAIServer.FortQueryGenerator_SquadMembers
// Size: 0x168 (Inherited: 0x50)
struct UFortQueryGenerator_SquadMembers : UEnvQueryGenerator {
	struct FAIDataProviderBoolValue LookingForHumanPlayers; // 0x50(0x38)
	struct FAIDataProviderBoolValue LookingForPlayerBots; // 0x88(0x38)
	struct FAIDataProviderBoolValue LookingForNpcs; // 0xc0(0x38)
	struct FAIDataProviderBoolValue LookingForAiPawns; // 0xf8(0x38)
	struct FAIDataProviderBoolValue IncludeSelf; // 0x130(0x38)
};

// Class FortniteAIServer.FortQueryGenerator_TerrainDonut
// Size: 0x140 (Inherited: 0x50)
struct UFortQueryGenerator_TerrainDonut : UEnvQueryGenerator {
	struct UEnvQueryContext* Center; // 0x50(0x08)
	struct FAIDataProviderFloatValue Radius; // 0x58(0x38)
	struct FAIDataProviderFloatValue RadiusWidth; // 0x90(0x38)
	struct FAIDataProviderFloatValue SpacingArc; // 0xc8(0x38)
	struct FAIDataProviderIntValue NumRings; // 0x100(0x38)
	char bFilterAllowTerrain : 1; // 0x138(0x01)
	char bFilterAllowBuildings : 1; // 0x138(0x01)
	char pad_138_2 : 6; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
};

// Class FortniteAIServer.FortQueryGenerator_ValidSpawnRiftActors
// Size: 0x88 (Inherited: 0x50)
struct UFortQueryGenerator_ValidSpawnRiftActors : UEnvQueryGenerator {
	struct FAIDataProviderIntValue NumAIForGroup; // 0x50(0x38)
};

// Class FortniteAIServer.FortQueryItemType_PointOrSlot
// Size: 0x30 (Inherited: 0x30)
struct UFortQueryItemType_PointOrSlot : UEnvQueryItemType_Point {
};

// Class FortniteAIServer.FortQueryTest_GoalBase
// Size: 0x268 (Inherited: 0x1f8)
struct UFortQueryTest_GoalBase : UEnvQueryTest {
	char bScoreEnemies : 1; // 0x1f8(0x01)
	char bScoreEncounterGoals : 1; // 0x1f8(0x01)
	char bScoreWorldGoals : 1; // 0x1f8(0x01)
	char bScoreSpecificAssignments : 1; // 0x1f8(0x01)
	char pad_1F8_4 : 4; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct TArray<struct FFortAIAssignmentIdentifier> AssignmentIDs; // 0x200(0x10)
	struct TArray<struct FFortAIAssignmentIdentifier> ProhibitedAssignmentIDs; // 0x210(0x10)
	struct FGameplayTagQuery GoalActorTagQuery; // 0x220(0x48)
};

// Class FortniteAIServer.FortQueryTest_AssignmentTypeInterest
// Size: 0x428 (Inherited: 0x268)
struct UFortQueryTest_AssignmentTypeInterest : UFortQueryTest_GoalBase {
	struct FAIDataProviderFloatValue InvalidTypeStartInterest; // 0x268(0x38)
	struct FAIDataProviderFloatValue InvalidTypeEndInterest; // 0x2a0(0x38)
	struct FAIDataProviderFloatValue InvalidTypeTimeBeforeLerp; // 0x2d8(0x38)
	struct FAIDataProviderFloatValue InvalidTypeLerpDuration; // 0x310(0x38)
	struct FAIDataProviderFloatValue ValidTypeStartInterest; // 0x348(0x38)
	struct FAIDataProviderFloatValue ValidTypeEndInterest; // 0x380(0x38)
	struct FAIDataProviderFloatValue ValidTypeTimeBeforeLerp; // 0x3b8(0x38)
	struct FAIDataProviderFloatValue ValidTypeLerpDuration; // 0x3f0(0x38)
};

// Class FortniteAIServer.FortQueryTest_BuildingCriteria
// Size: 0x8b8 (Inherited: 0x268)
struct UFortQueryTest_BuildingCriteria : UFortQueryTest_GoalBase {
	struct FAIDataProviderFloatValue ScoreForGroundSupportedFloor; // 0x268(0x38)
	struct FAIDataProviderFloatValue ScoreForBeingGroundSupported; // 0x2a0(0x38)
	struct FAIDataProviderFloatValue ScoreForTraps; // 0x2d8(0x38)
	struct FAIDataProviderFloatValue ScoreForWalls; // 0x310(0x38)
	struct FAIDataProviderFloatValue ScoreForNavigableOpening; // 0x348(0x38)
	struct FFortAIAssignmentIdentifier RootAssignmentID; // 0x380(0x30)
	struct FAIDataProviderBoolValue bPreferCloserToRootAssignment; // 0x3b0(0x38)
	struct FAIDataProviderFloatValue ScoreForDistanceFromClosestRootAssignmentGoal; // 0x3e8(0x38)
	struct FAIDataProviderFloatValue MinDistanceForDistanceScoring; // 0x420(0x38)
	struct FAIDataProviderFloatValue MaxDistanceForDistanceScoring; // 0x458(0x38)
	struct FAIDataProviderFloatValue MaxHealthScore; // 0x490(0x38)
	struct FAIDataProviderBoolValue bPreferHigherHealth; // 0x4c8(0x38)
	struct FAIDataProviderFloatValue ClampMaxHealthValue; // 0x500(0x38)
	struct FAIDataProviderFloatValue ClampMinHealthValue; // 0x538(0x38)
	struct FAIDataProviderBoolValue bPreferHigherHealthPercentage; // 0x570(0x38)
	struct FAIDataProviderFloatValue MaxHealthPercentageScore; // 0x5a8(0x38)
	struct FAIDataProviderBoolValue bWantsBuildingRepairableByOwner; // 0x5e0(0x38)
	struct FAIDataProviderFloatValue RepairableBuildingScore; // 0x618(0x38)
	struct FAIDataProviderFloatValue NotRepairableBuildingScore; // 0x650(0x38)
	struct FAIDataProviderFloatValue NeedsRepairBuildingScore; // 0x688(0x38)
	struct FAIDataProviderFloatValue DoesntNeedsRepairBuildingScore; // 0x6c0(0x38)
	struct FAIDataProviderBoolValue bWantsDamagedByFriendly; // 0x6f8(0x38)
	struct FAIDataProviderFloatValue DamagedByFriendlyMaxLifespan; // 0x730(0x38)
	struct FAIDataProviderFloatValue DamagedByFriendlyMinDamage; // 0x768(0x38)
	struct FAIDataProviderFloatValue DamagedByFriendlyScore; // 0x7a0(0x38)
	struct FAIDataProviderBoolValue bWantsDamagedByEnemy; // 0x7d8(0x38)
	struct FAIDataProviderFloatValue DamagedByEnemyMaxLifespan; // 0x810(0x38)
	struct FAIDataProviderFloatValue DamagedByEnemyMinDamage; // 0x848(0x38)
	struct FAIDataProviderFloatValue DamagedByEnemyScore; // 0x880(0x38)
};

// Class FortniteAIServer.FortQueryTest_CanAttackTarget
// Size: 0x268 (Inherited: 0x268)
struct UFortQueryTest_CanAttackTarget : UFortQueryTest_GoalBase {
};

// Class FortniteAIServer.FortQueryTest_CanBeDamaged
// Size: 0x268 (Inherited: 0x268)
struct UFortQueryTest_CanBeDamaged : UFortQueryTest_GoalBase {
};

// Class FortniteAIServer.FortQueryTest_CanHitWithGameplayAbility
// Size: 0x228 (Inherited: 0x1f8)
struct UFortQueryTest_CanHitWithGameplayAbility : UEnvQueryTest {
	struct UEnvQueryContext* AIsUsingAbility; // 0x1f8(0x08)
	struct UEnvQueryContext* AbilityTargets; // 0x200(0x08)
	struct FGameplayTagContainer GameplayAbilityTag; // 0x208(0x20)
};

// Class FortniteAIServer.FortQueryTest_CurieState
// Size: 0x240 (Inherited: 0x1f8)
struct UFortQueryTest_CurieState : UEnvQueryTest {
	struct FGameplayTagQuery CurieStateQuery; // 0x1f8(0x48)
};

// Class FortniteAIServer.FortQueryTest_DecoyDistance
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_DecoyDistance : UEnvQueryTest {
	struct UEnvQueryContext* DistanceTo; // 0x1f8(0x08)
};

// Class FortniteAIServer.FortQueryTest_DeltaDistance
// Size: 0x208 (Inherited: 0x1f8)
struct UFortQueryTest_DeltaDistance : UEnvQueryTest {
	struct UEnvQueryContext* LocationProviderContext; // 0x1f8(0x08)
	bool bUseDistance2D; // 0x200(0x01)
	char pad_201[0x7]; // 0x201(0x07)
};

// Class FortniteAIServer.FortQueryTest_DistanceToActorBound
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_DistanceToActorBound : UEnvQueryTest {
	struct UEnvQueryContext* DistanceTo; // 0x1f8(0x08)
};

// Class FortniteAIServer.FortQueryTest_DistanceToIndestructibleBuilding
// Size: 0x1f8 (Inherited: 0x1f8)
struct UFortQueryTest_DistanceToIndestructibleBuilding : UEnvQueryTest {
};

// Class FortniteAIServer.FortQueryTest_EnvironmentalDanger
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_EnvironmentalDanger : UEnvQueryTest {
	bool bUse3DBoundsCheck; // 0x1f8(0x01)
	char pad_1F9[0x3]; // 0x1f9(0x03)
	struct FGameplayTag DangerSourceActorRegistryTag; // 0x1fc(0x04)
};

// Class FortniteAIServer.FortQueryTest_GameplayTagsPerDifficulty
// Size: 0x208 (Inherited: 0x1f8)
struct UFortQueryTest_GameplayTagsPerDifficulty : UEnvQueryTest {
	struct TArray<struct FFortGameplayTagQueryPerDifficulty> TagQueriesPerDifficulty; // 0x1f8(0x10)
};

// Class FortniteAIServer.FortQueryTest_GoalActorDot
// Size: 0x280 (Inherited: 0x268)
struct UFortQueryTest_GoalActorDot : UFortQueryTest_GoalBase {
	struct UEnvQueryContext* LineATo; // 0x268(0x08)
	struct UEnvQueryContext* LineBTo; // 0x270(0x08)
	enum class EFortTestGoalActorDot TestMode; // 0x278(0x01)
	bool bAbsoluteValue; // 0x279(0x01)
	char pad_27A[0x6]; // 0x27a(0x06)
};

// Class FortniteAIServer.FortQueryTest_GoalActorTimeSinceSpawn
// Size: 0x268 (Inherited: 0x268)
struct UFortQueryTest_GoalActorTimeSinceSpawn : UFortQueryTest_GoalBase {
};

// Class FortniteAIServer.FortQueryTest_GoalDiscouragement
// Size: 0x2a0 (Inherited: 0x268)
struct UFortQueryTest_GoalDiscouragement : UFortQueryTest_GoalBase {
	struct FAIDataProviderBoolValue DisableDiscouragementWhenUndermining; // 0x268(0x38)
};

// Class FortniteAIServer.FortQueryTest_GoalDistance
// Size: 0x280 (Inherited: 0x268)
struct UFortQueryTest_GoalDistance : UFortQueryTest_GoalBase {
	enum class EDistanceMode DistanceMode; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
	struct UEnvQueryContext* DistanceTo; // 0x270(0x08)
	enum class EEnvTestDistance TestMode; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)
};

// Class FortniteAIServer.FortQueryTest_GoalDistanceRanges
// Size: 0x290 (Inherited: 0x268)
struct UFortQueryTest_GoalDistanceRanges : UFortQueryTest_GoalBase {
	enum class EDistanceMode DistanceMode; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
	struct UEnvQueryContext* DistanceTo; // 0x270(0x08)
	enum class EEnvTestDistance ScreeningTestMode; // 0x278(0x01)
	enum class EEnvTestDistance TestMode; // 0x279(0x01)
	char pad_27A[0x6]; // 0x27a(0x06)
	struct TArray<struct FGoalDistanceData> GoalDistanceDataRanges; // 0x280(0x10)
};

// Class FortniteAIServer.FortQueryTest_GoalFrustrationDiscouragement
// Size: 0x268 (Inherited: 0x268)
struct UFortQueryTest_GoalFrustrationDiscouragement : UFortQueryTest_GoalBase {
};

// Class FortniteAIServer.FortQueryTest_GoalGameplayTags
// Size: 0x2c0 (Inherited: 0x268)
struct UFortQueryTest_GoalGameplayTags : UFortQueryTest_GoalBase {
	bool bShouldLookupQueryByTag; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
	struct FGameplayTagQuery TagQueryToMatch; // 0x270(0x48)
	struct FGameplayTag QueryLookupTag; // 0x2b8(0x04)
	bool bShouldPassWhenQueryNotFound; // 0x2bc(0x01)
	bool bRequireAllProvidedTagQueriesPass; // 0x2bd(0x01)
	char pad_2BE[0x2]; // 0x2be(0x02)
};

// Class FortniteAIServer.FortQueryTest_GoalMarkedByPlayer
// Size: 0x2e8 (Inherited: 0x268)
struct UFortQueryTest_GoalMarkedByPlayer : UFortQueryTest_GoalBase {
	struct FGameplayTagQuery OwnerTagQuery; // 0x268(0x48)
	struct FAIDataProviderBoolValue OnlyConverterMarkedTargets; // 0x2b0(0x38)
};

// Class FortniteAIServer.FortQueryTest_GoalNumberOfAIAssigned
// Size: 0x270 (Inherited: 0x268)
struct UFortQueryTest_GoalNumberOfAIAssigned : UFortQueryTest_GoalBase {
	enum class ECountAIAssignedToType TypeOfMatchToCount; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
};

// Class FortniteAIServer.FortQueryTest_GoalOverallDamageCaused
// Size: 0x268 (Inherited: 0x268)
struct UFortQueryTest_GoalOverallDamageCaused : UFortQueryTest_GoalBase {
};

// Class FortniteAIServer.FortQueryTest_GoalPickupFilter
// Size: 0x270 (Inherited: 0x268)
struct UFortQueryTest_GoalPickupFilter : UFortQueryTest_GoalBase {
	float MaxLifetime; // 0x268(0x04)
	enum class EFortPickupSpawnSource RequiredPickupSpawnSource; // 0x26c(0x01)
	char pad_26D[0x3]; // 0x26d(0x03)
};

// Class FortniteAIServer.FortQueryTest_GoalProject
// Size: 0x2a0 (Inherited: 0x268)
struct UFortQueryTest_GoalProject : UFortQueryTest_GoalBase {
	struct FEnvTraceData ProjectionData; // 0x268(0x38)
};

// Class FortniteAIServer.FortQueryTest_GoalStickiness
// Size: 0x380 (Inherited: 0x268)
struct UFortQueryTest_GoalStickiness : UFortQueryTest_GoalBase {
	struct FAIDataProviderFloatValue StartValueForGoal; // 0x268(0x38)
	struct FAIDataProviderFloatValue EndValueForGoal; // 0x2a0(0x38)
	struct FAIDataProviderFloatValue TimeBeforeValueLerp; // 0x2d8(0x38)
	struct FAIDataProviderFloatValue ValueLerpDuration; // 0x310(0x38)
	struct FAIDataProviderBoolValue ApplyStickinessToAllGoalsWithSameActor; // 0x348(0x38)
};

// Class FortniteAIServer.FortQueryTest_GoalType
// Size: 0x268 (Inherited: 0x268)
struct UFortQueryTest_GoalType : UFortQueryTest_GoalBase {
};

// Class FortniteAIServer.FortQueryTest_GoalWithinTetheredBounds
// Size: 0x268 (Inherited: 0x268)
struct UFortQueryTest_GoalWithinTetheredBounds : UFortQueryTest_GoalBase {
};

// Class FortniteAIServer.FortQueryTest_HasNearbyBuildings
// Size: 0x208 (Inherited: 0x1f8)
struct UFortQueryTest_HasNearbyBuildings : UEnvQueryTest {
	char bIncludeCenter : 1; // 0x1f8(0x01)
	char bIncludeFloors : 1; // 0x1f8(0x01)
	char bIncludeFloorsAbove : 1; // 0x1f8(0x01)
	char bIncludeWalls : 1; // 0x1f8(0x01)
	char pad_1F8_4 : 4; // 0x1f8(0x01)
	char pad_1F9[0x3]; // 0x1f9(0x03)
	int32_t ExtentXY; // 0x1fc(0x04)
	int32_t ExtentZ; // 0x200(0x04)
	char pad_204[0x4]; // 0x204(0x04)
};

// Class FortniteAIServer.FortQueryTest_HasNearbyEncounterGoals
// Size: 0x238 (Inherited: 0x1f8)
struct UFortQueryTest_HasNearbyEncounterGoals : UEnvQueryTest {
	char bOnlyActiveEncounters : 1; // 0x1f8(0x01)
	char pad_1F8_1 : 7; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct FAIDataProviderFloatValue TestDistance; // 0x200(0x38)
};

// Class FortniteAIServer.FortQueryTest_Health
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_Health : UEnvQueryTest {
	bool bUsePercentHealth; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
};

// Class FortniteAIServer.FortQueryTest_HealthAndShield
// Size: 0x2f0 (Inherited: 0x1f8)
struct UFortQueryTest_HealthAndShield : UEnvQueryTest {
	bool bConsiderHealth; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct FAIDataProviderFloatValue HealthMin; // 0x200(0x38)
	struct FAIDataProviderFloatValue HealthMax; // 0x238(0x38)
	bool bHealthAsPercent; // 0x270(0x01)
	bool bConsiderShield; // 0x271(0x01)
	char pad_272[0x6]; // 0x272(0x06)
	struct FAIDataProviderFloatValue ShieldMin; // 0x278(0x38)
	struct FAIDataProviderFloatValue ShieldMax; // 0x2b0(0x38)
	bool bShieldAsPercent; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
};

// Class FortniteAIServer.FortQueryTest_HotspotSlotOrientation
// Size: 0x238 (Inherited: 0x1f8)
struct UFortQueryTest_HotspotSlotOrientation : UEnvQueryTest {
	struct UEnvQueryContext* FaceToward; // 0x1f8(0x08)
	struct FAIDataProviderFloatValue DotThreshold; // 0x200(0x38)
};

// Class FortniteAIServer.FortQueryTest_HotspotSlotState
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_HotspotSlotState : UEnvQueryTest {
	enum class EAIHotSpotSlot SlotState; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
};

// Class FortniteAIServer.FortQueryTest_InfluenceScore
// Size: 0x1f8 (Inherited: 0x1f8)
struct UFortQueryTest_InfluenceScore : UEnvQueryTest {
};

// Class FortniteAIServer.FortQueryTest_InsideAIBotLeash
// Size: 0x1f8 (Inherited: 0x1f8)
struct UFortQueryTest_InsideAIBotLeash : UEnvQueryTest {
};

// Class FortniteAIServer.FortQueryTest_InsideAthenaLeash
// Size: 0x1f8 (Inherited: 0x1f8)
struct UFortQueryTest_InsideAthenaLeash : UEnvQueryTest {
};

// Class FortniteAIServer.FortQueryTest_InsideAthenaSafeZone
// Size: 0x240 (Inherited: 0x1f8)
struct UFortQueryTest_InsideAthenaSafeZone : UEnvQueryTest {
	bool bUseCurrentSafeZoneIndicatorRadius; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct FAIDataProviderIntValue SafeZoneIndex; // 0x200(0x38)
	bool bNextSafeZone; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
};

// Class FortniteAIServer.FortQueryTest_InsideBuilding
// Size: 0x1f8 (Inherited: 0x1f8)
struct UFortQueryTest_InsideBuilding : UEnvQueryTest {
};

// Class FortniteAIServer.FortQueryTest_InsideWater
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_InsideWater : UEnvQueryTest {
	float TestRadius; // 0x1f8(0x04)
	char pad_1FC[0x4]; // 0x1fc(0x04)
};

// Class FortniteAIServer.FortQueryTest_IsCloseToHotspotSlot
// Size: 0x240 (Inherited: 0x1f8)
struct UFortQueryTest_IsCloseToHotspotSlot : UEnvQueryTest {
	struct AFortAIHotSpot* HotspotClass; // 0x1f8(0x08)
	struct FAIDataProviderFloatValue Radius; // 0x200(0x38)
	bool bIgnoreItemsWithSlotData; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
};

// Class FortniteAIServer.FortQueryTest_IsCloseToPatrolWard
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_IsCloseToPatrolWard : UEnvQueryTest {
	enum class EWardAffectType WardEffectTypeFilter; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
};

// Class FortniteAIServer.FortQueryTest_IsGoalForAssignment
// Size: 0x230 (Inherited: 0x1f8)
struct UFortQueryTest_IsGoalForAssignment : UEnvQueryTest {
	bool bRetrieveRootAssignmentFromOwner; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct FFortAIAssignmentIdentifier RootAssignmentID; // 0x200(0x30)
};

// Class FortniteAIServer.FortQueryTest_IsGoalHostile
// Size: 0x320 (Inherited: 0x268)
struct UFortQueryTest_IsGoalHostile : UFortQueryTest_GoalBase {
	struct FGameplayTagQuery OwnerTagQuery; // 0x268(0x48)
	struct FGameplayTagQuery EnemyPawnTagsToConsider; // 0x2b0(0x48)
	struct FGameplayTagContainer BuildingTagsToConsider; // 0x2f8(0x20)
	bool bConsiderDefenders; // 0x318(0x01)
	char pad_319[0x7]; // 0x319(0x07)
};

// Class FortniteAIServer.FortQueryTest_IsInLeaderLOS
// Size: 0x250 (Inherited: 0x1f8)
struct UFortQueryTest_IsInLeaderLOS : UEnvQueryTest {
	struct FGameplayTagQuery OwnerTagQuery; // 0x1f8(0x48)
	bool bRequireLOSRayCast; // 0x240(0x01)
	char pad_241[0x3]; // 0x241(0x03)
	float RayCastLeaderVerticalOffset; // 0x244(0x04)
	float RayCastItemVerticalOffset; // 0x248(0x04)
	float MinDotProduct; // 0x24c(0x04)
};

// Class FortniteAIServer.FortQueryTest_IsObstructed
// Size: 0x388 (Inherited: 0x2e0)
struct UFortQueryTest_IsObstructed : UEnvQueryTest_Trace {
	struct FAIDataProviderBoolValue OverrideContextLocationXWithItemLocationX; // 0x2e0(0x38)
	struct FAIDataProviderBoolValue OverrideContextLocationYWithItemLocationY; // 0x318(0x38)
	struct FAIDataProviderBoolValue OverrideContextLocationZWithItemLocationZ; // 0x350(0x38)
};

// Class FortniteAIServer.FortQueryTest_IsObstructedOverlap
// Size: 0x388 (Inherited: 0x2e0)
struct UFortQueryTest_IsObstructedOverlap : UEnvQueryTest_Trace {
	struct FAIDataProviderBoolValue OverrideContextLocationXWithItemLocationX; // 0x2e0(0x38)
	struct FAIDataProviderBoolValue OverrideContextLocationYWithItemLocationY; // 0x318(0x38)
	struct FAIDataProviderBoolValue OverrideContextLocationZWithItemLocationZ; // 0x350(0x38)
};

// Class FortniteAIServer.FortQueryTest_MissionGameplayTagMatch
// Size: 0x260 (Inherited: 0x1f8)
struct UFortQueryTest_MissionGameplayTagMatch : UEnvQueryTest {
	struct FGameplayTagQuery MissionPlacementActorTagQuery; // 0x1f8(0x48)
	struct FGameplayTagContainer GameplayTagsToMatch; // 0x240(0x20)
};

// Class FortniteAIServer.FortQueryTest_MissionSameMap
// Size: 0x240 (Inherited: 0x1f8)
struct UFortQueryTest_MissionSameMap : UEnvQueryTest {
	struct FGameplayTagQuery MissionPlacementActorTagQuery; // 0x1f8(0x48)
};

// Class FortniteAIServer.FortQueryTest_NavGraphDistance
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_NavGraphDistance : UEnvQueryTest {
	struct UEnvQueryContext* DistanceTo; // 0x1f8(0x08)
};

// Class FortniteAIServer.FortQueryTest_OnFlatSurface
// Size: 0x208 (Inherited: 0x1f8)
struct UFortQueryTest_OnFlatSurface : UEnvQueryTest {
	float Radius; // 0x1f8(0x04)
	float ToleranceZ; // 0x1fc(0x04)
	float TraceOffsetUp; // 0x200(0x04)
	float TraceOffsetDown; // 0x204(0x04)
};

// Class FortniteAIServer.FortQueryTest_OnFlatSurfaceNoNavMesh
// Size: 0x218 (Inherited: 0x1f8)
struct UFortQueryTest_OnFlatSurfaceNoNavMesh : UEnvQueryTest {
	float Radius; // 0x1f8(0x04)
	float ZTolerance; // 0x1fc(0x04)
	float NormalTolerance; // 0x200(0x04)
	float TraceOffset; // 0x204(0x04)
	struct TArray<struct AActor*> ActorClassesToIgnoreInTrace; // 0x208(0x10)
};

// Class FortniteAIServer.FortQueryTest_PathfindingBatch
// Size: 0x2c0 (Inherited: 0x2b8)
struct UFortQueryTest_PathfindingBatch : UEnvQueryTest_PathfindingBatch {
	struct FGameplayTag NavFilterTag; // 0x2b8(0x04)
	char pad_2BC[0x4]; // 0x2bc(0x04)
};

// Class FortniteAIServer.FortQueryTest_PawnHealth
// Size: 0x270 (Inherited: 0x268)
struct UFortQueryTest_PawnHealth : UFortQueryTest_GoalBase {
	bool bUsePercentHealth; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
};

// Class FortniteAIServer.FortQueryTest_PawnIsDBNO
// Size: 0x268 (Inherited: 0x268)
struct UFortQueryTest_PawnIsDBNO : UFortQueryTest_GoalBase {
};

// Class FortniteAIServer.FortQueryTest_PerceptionAge
// Size: 0x208 (Inherited: 0x1f8)
struct UFortQueryTest_PerceptionAge : UEnvQueryTest {
	enum class ECorePerceptionTypes Sense; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct UAISense* SenseClass; // 0x200(0x08)
};

// Class FortniteAIServer.FortQueryTest_PerceptionAll
// Size: 0x478 (Inherited: 0x268)
struct UFortQueryTest_PerceptionAll : UFortQueryTest_GoalBase {
	struct FAIDataProviderFloatValue SenseScores[0x6]; // 0x268(0x150)
	struct TMap<struct UAISense*, struct FAIDataProviderFloatValue> AdditionalSenseScores; // 0x3b8(0x50)
	struct FAIDataProviderFloatValue MinSenseAge; // 0x408(0x38)
	struct FAIDataProviderFloatValue MaxSenseAge; // 0x440(0x38)
};

// Class FortniteAIServer.FortQueryTest_PerceptionExists
// Size: 0x208 (Inherited: 0x1f8)
struct UFortQueryTest_PerceptionExists : UEnvQueryTest {
	enum class ECorePerceptionTypes Sense; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct UAISense* SenseClass; // 0x200(0x08)
};

// Class FortniteAIServer.FortQueryTest_PickupDropper
// Size: 0x380 (Inherited: 0x268)
struct UFortQueryTest_PickupDropper : UFortQueryTest_GoalBase {
	struct FAIDataProviderFloatValue ValueConverterDroppedPickup; // 0x268(0x38)
	struct FAIDataProviderFloatValue ValueOtherDroppedPickupInitial; // 0x2a0(0x38)
	struct FAIDataProviderFloatValue ValueOtherDroppedPickupFinal; // 0x2d8(0x38)
	struct FAIDataProviderFloatValue TimeOtherDroppedPickupFinal; // 0x310(0x38)
	struct FAIDataProviderBoolValue LerpFromInitialToFinal; // 0x348(0x38)
};

// Class FortniteAIServer.FortQueryTest_PointInBuildingFoundation
// Size: 0x220 (Inherited: 0x1f8)
struct UFortQueryTest_PointInBuildingFoundation : UEnvQueryTest {
	struct UEnvQueryContext* BuildingFoundationContext; // 0x1f8(0x08)
	struct ABuildingFoundation* BuildingFoundationClass; // 0x200(0x08)
	struct FVector BoundingBoxScale; // 0x208(0x18)
};

// Class FortniteAIServer.FortQueryTest_PrimaryAssignment
// Size: 0x388 (Inherited: 0x268)
struct UFortQueryTest_PrimaryAssignment : UFortQueryTest_GoalBase {
	bool bUseItemActorLocation; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
	struct FAIDataProviderFloatValue DistanceClose; // 0x270(0x38)
	struct FAIDataProviderFloatValue DistanceFar; // 0x2a8(0x38)
	struct FAIDataProviderFloatValue PercentValueClose; // 0x2e0(0x38)
	struct FAIDataProviderFloatValue PercentValueRegular; // 0x318(0x38)
	struct FAIDataProviderFloatValue PercentValueFar; // 0x350(0x38)
};

// Class FortniteAIServer.FortQueryTest_ProjectOnNavMesh
// Size: 0x1f8 (Inherited: 0x1f8)
struct UFortQueryTest_ProjectOnNavMesh : UEnvQueryTest {
};

// Class FortniteAIServer.FortQueryTest_Random
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_Random : UEnvQueryTest {
	char bUseRandomSeedForAI : 1; // 0x1f8(0x01)
	char bUseRandomSeedForOthers : 1; // 0x1f8(0x01)
	char pad_1F8_2 : 6; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
};

// Class FortniteAIServer.FortQueryTest_TowardNextAthenaSafeZone
// Size: 0x250 (Inherited: 0x1f8)
struct UFortQueryTest_TowardNextAthenaSafeZone : UEnvQueryTest {
	struct FAIDataProviderIntValue SafeZoneIndex; // 0x1f8(0x38)
	bool bCheckAcceptanceAngleTowardNextCenter; // 0x230(0x01)
	char pad_231[0x3]; // 0x231(0x03)
	float AcceptanceAngleTowardNextCenter; // 0x234(0x04)
	struct TArray<int32_t> ExclusionSafeZoneIndex; // 0x238(0x10)
	char pad_248[0x8]; // 0x248(0x08)
};

// Class FortniteAIServer.FortQueryTest_ValidSurface
// Size: 0x318 (Inherited: 0x1f8)
struct UFortQueryTest_ValidSurface : UEnvQueryTest {
	struct FAIDataProviderFloatValue Radius; // 0x1f8(0x38)
	struct FAIDataProviderFloatValue TraceOffsetUp; // 0x230(0x38)
	struct FAIDataProviderFloatValue TraceOffsetDown; // 0x268(0x38)
	enum class ECollisionChannel TraceCollisionChannel; // 0x2a0(0x01)
	char pad_2A1[0x7]; // 0x2a1(0x07)
	struct FAIDataProviderFloatValue FlatSurfaceToleranceZ; // 0x2a8(0x38)
	struct TArray<struct TSoftObjectPtr<UPhysicalMaterial>> SurfaceMaterials; // 0x2e0(0x10)
	bool bAreSurfaceMaterialsValid; // 0x2f0(0x01)
	char pad_2F1[0x7]; // 0x2f1(0x07)
	struct TArray<struct TSoftClassPtr<UObject>> ValidHitActorClasses; // 0x2f8(0x10)
	struct TArray<struct TSoftClassPtr<UObject>> InvalidHitActorClasses; // 0x308(0x10)
};

// Class FortniteAIServer.FortQueryTest_WithinHotfixVolumeBounds
// Size: 0x220 (Inherited: 0x1f8)
struct UFortQueryTest_WithinHotfixVolumeBounds : UEnvQueryTest {
	struct UDataTable* BoundsTable; // 0x1f8(0x08)
	struct FVector BoundsExtentBuffer; // 0x200(0x18)
	bool bXYOnly; // 0x218(0x01)
	char pad_219[0x7]; // 0x219(0x07)
};

// Class FortniteAIServer.FortQueryTest_WithinTaggedArea
// Size: 0x260 (Inherited: 0x1f8)
struct UFortQueryTest_WithinTaggedArea : UEnvQueryTest {
	struct FGameplayTagQuery TagQuery; // 0x1f8(0x48)
	struct FVector AreaExtentBuffer; // 0x240(0x18)
	bool bAssumeInfiniteHeightForArea; // 0x258(0x01)
	char pad_259[0x7]; // 0x259(0x07)
};

// Class FortniteAIServer.FortGameplayInteractionSmartObjectBehaviorDefinition
// Size: 0x40 (Inherited: 0x40)
struct UFortGameplayInteractionSmartObjectBehaviorDefinition : UGameplayInteractionSmartObjectBehaviorDefinition {

	bool CanBeUsedBy(struct AActor* User, struct AActor* SmartObjectActor); // Function FortniteAIServer.FortGameplayInteractionSmartObjectBehaviorDefinition.CanBeUsedBy // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x95cf880
};

// Class FortniteAIServer.FortAthenaBTTask_BotAmbushPlayer
// Size: 0x108 (Inherited: 0x78)
struct UFortAthenaBTTask_BotAmbushPlayer : UBTTask_Wait {
	float FacingPrecision; // 0x78(0x04)
	float WeaponCooldown; // 0x7c(0x04)
	bool bClearBlackboardOnFinished; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FBlackboardKeySelector TargetedPlayerKeySelector; // 0x88(0x28)
	struct FBlackboardKeySelector MaxLocationErrorKeySelector; // 0xb0(0x28)
	struct FBlackboardKeySelector MinLocationErrorKeySelector; // 0xd8(0x28)
	char pad_100[0x8]; // 0x100(0x08)
};

// Class FortniteAIServer.FortAthenaBTDecorator_BehaviorControls
// Size: 0x70 (Inherited: 0x68)
struct UFortAthenaBTDecorator_BehaviorControls : UBTDecorator {
	enum class EBehaviorTreeBranches BehaviorTreeBranch; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_AimDownSight
// Size: 0xd8 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_AimDownSight : UFortAthenaAIBotEvaluator {
	struct FName WeaponKeyName; // 0xa8(0x04)
	struct FName ThrowableAttacksName; // 0xac(0x04)
	struct FName TargetActorName; // 0xb0(0x04)
	struct FName UrgentMovementName; // 0xb4(0x04)
	bool bSkipTargetChecks; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
	struct UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0xc0(0x08)
	char pad_C8[0x10]; // 0xc8(0x10)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Ambush
// Size: 0x210 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Ambush : UFortAthenaAIBotEvaluator_Movement {
	struct FName LastKnownPositionName; // 0x1a8(0x04)
	struct FName DestinationKeyName; // 0x1ac(0x04)
	struct FName MoveToDestinationKeyName; // 0x1b0(0x04)
	struct FName AggressivenessName; // 0x1b4(0x04)
	char pad_1B8[0x58]; // 0x1b8(0x58)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Attack
// Size: 0x1c0 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Attack : UFortAthenaAIBotEvaluator_Movement {
	char pad_1A8[0x4]; // 0x1a8(0x04)
	struct FName WeaponKeyName; // 0x1ac(0x04)
	struct FName MoveToDestinationKeyName; // 0x1b0(0x04)
	struct FName TargetActorName; // 0x1b4(0x04)
	char pad_1B8[0x8]; // 0x1b8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_AvoidThreat
// Size: 0x1d0 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_AvoidThreat : UFortAthenaAIBotEvaluator_Movement {
	struct FName AvoidThreatKeyName; // 0x1a8(0x04)
	struct FName AvoidThreatMovementStateKeyName; // 0x1ac(0x04)
	struct FName AvoidThreatDestinationKeyName; // 0x1b0(0x04)
	char pad_1B4[0xc]; // 0x1b4(0x0c)
	struct AActor* CurrentThreatActorAvoiding; // 0x1c0(0x08)
	struct UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet; // 0x1c8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Bunker
// Size: 0x260 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Bunker : UFortAthenaAIBotEvaluator_Movement {
	struct FName BuildExecutionStatusKeyName; // 0x1a8(0x04)
	struct FName HealingStatusKeyName; // 0x1ac(0x04)
	struct FGameplayTagContainer DangerTags; // 0x1b0(0x20)
	char pad_1D0[0x90]; // 0x1d0(0x90)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_CanMove
// Size: 0xb0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_CanMove : UFortAthenaAIBotEvaluator {
	struct FName CanMoveKeyName; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_CharacterLaunched
// Size: 0xe8 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_CharacterLaunched : UFortAthenaAIBotEvaluator {
	bool bSteerInSameDirectionAsLaunchVelocity; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	struct FName CharacterLaunchedExecutionStatusKeyName; // 0xac(0x04)
	struct FName SteerDirectionKeyName; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FVector LastLaunchVelocity; // 0xb8(0x18)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CachedMovementSkillSet; // 0xd0(0x08)
	char pad_D8[0x10]; // 0xd8(0x10)

	void OnZiplineStateChanged(bool bIsZiplining, struct AFortPlayerPawn* FortPlayerPawn); // Function FortniteAIServer.FortAthenaAIBotEvaluator_CharacterLaunched.OnZiplineStateChanged // (Final|Native|Private) // @ game+0xa4b6160
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Conversation
// Size: 0x230 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_Conversation : UFortAthenaAIBotEvaluator {
	struct FName IsInConversationStateName; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct TArray<struct FName> ExecutionStatusesToCheckedToAvoidStoppingWhenNearActorNames; // 0xb0(0x10)
	char pad_C0[0x10]; // 0xc0(0x10)
	struct TArray<struct FName> ExecutionStatusesToCheckForAllowToAvoidStoppingWhenNearActorNames; // 0xd0(0x10)
	char pad_E0[0x10]; // 0xe0(0x10)
	struct TArray<struct FName> MovementStatusesToCheckedToAvoidStoppingWhenNearActorNames; // 0xf0(0x10)
	char pad_100[0x10]; // 0x100(0x10)
	bool bForceStopIfNoPlayerNearby; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	struct UFortAthenaAIRuntimeParameters_Conversation* ConversationRuntimeParameters; // 0x118(0x08)
	struct AActor* ActorToFocus; // 0x120(0x08)
	char pad_128[0x108]; // 0x128(0x108)

	void OnPlayerPawnSpawned(struct AFortAthenaAIBotController* BotController, struct AFortPlayerPawnAthena* BotPawn); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Conversation.OnPlayerPawnSpawned // (Final|Native|Private) // @ game+0xa4b7840
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Converted
// Size: 0x218 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Converted : UFortAthenaAIBotEvaluator_Movement {
	struct FName ShouldMoveTowardsConverterName; // 0x1a8(0x04)
	struct FName ShouldTeleportTowardsConverterName; // 0x1ac(0x04)
	struct FName ConvertedAllowPatrolAroundName; // 0x1b0(0x04)
	struct FName ConvertedAllowScanAroundWhenWaitingName; // 0x1b4(0x04)
	struct FName ConvertedDestinationName; // 0x1b8(0x04)
	struct FName CrouchExecutionStatusName; // 0x1bc(0x04)
	struct FVector TeleportLocationProjectionExtent; // 0x1c0(0x18)
	struct FVector MovingFromLosLocationProjectionExtent; // 0x1d8(0x18)
	char pad_1F0[0x8]; // 0x1f0(0x08)
	struct AFortPawn* ConverterPawn; // 0x1f8(0x08)
	struct UFortAthenaAIRuntimeParameters_AIBotConvert* CachedAIBotConvertParameters; // 0x200(0x08)
	char pad_208[0x10]; // 0x208(0x10)

	void OnUnconvertedEvent(struct AFortPawn* UnconvertedPawn, enum class EUnconvertReason UnconvertReason); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Converted.OnUnconvertedEvent // (Final|Native|Protected) // @ game+0xa4b94c0
	void OnConvertedEvent(struct AFortPawn* InstigatorPawn, struct AFortPawn* ConvertedPawn); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Converted.OnConvertedEvent // (Final|Native|Protected) // @ game+0xa4b9660
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_DanceOnKill
// Size: 0xd0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_DanceOnKill : UFortAthenaAIBotEvaluator {
	struct FName LastKillPositionKeyName; // 0xa8(0x04)
	struct FName LastKillTimeKeyName; // 0xac(0x04)
	struct FName LastKillWasABotKeyName; // 0xb0(0x04)
	struct FName PlayEmoteExecutionStatusKeyName; // 0xb4(0x04)
	char pad_B8[0x10]; // 0xb8(0x10)
	struct UFortAthenaAIBotEmoteDigestedSkillSet* CacheEmoteDigestedSkillSet; // 0xc8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_TagQuery
// Size: 0xf8 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_TagQuery : UFortAthenaAIBotEvaluator {
	struct FGameplayTagQuery TagQuery; // 0xa8(0x48)
	struct UAbilitySystemComponent* CachedAbilitySystemComponent; // 0xf0(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_DangerDetection
// Size: 0x148 (Inherited: 0xf8)
struct UFortAthenaAIBotEvaluator_DangerDetection : UFortAthenaAIBotEvaluator_TagQuery {
	char pad_F8[0x10]; // 0xf8(0x10)
	struct UFortNavArea* DangerNavAreaClass; // 0x108(0x08)
	float TimeToCheckForDangerAfterValidQuery; // 0x110(0x04)
	float MaxRadiusToSearchForSafePlace; // 0x114(0x04)
	struct FName DangerZoneDetectedExecutionStatusName; // 0x118(0x04)
	struct FName DangerZoneDetectedSafeLocationKeyName; // 0x11c(0x04)
	char pad_120[0x8]; // 0x120(0x08)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CachedMovementSkillSet; // 0x128(0x08)
	struct UAthenaAIServiceZoneManager* CacheZoneManager; // 0x130(0x08)
	char pad_138[0x10]; // 0x138(0x10)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_DBNO
// Size: 0x200 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_DBNO : UFortAthenaAIBotEvaluator_Movement {
	struct FName DBNODestinationKeyName; // 0x1a8(0x04)
	char pad_1AC[0x2]; // 0x1ac(0x02)
	char bAllowReachSquadmates : 1; // 0x1ae(0x01)
	char bAllowReachSameFactionNPCs : 1; // 0x1ae(0x01)
	char pad_1AE_2 : 6; // 0x1ae(0x01)
	char pad_1AF[0x1]; // 0x1af(0x01)
	struct TArray<struct AFortPlayerPawnAthena*> AllyPawns; // 0x1b0(0x10)
	struct FVector CachedCurrentDestination; // 0x1c0(0x18)
	struct UFortAthenaAIBotDBNODigestedSkillSet* DBNOSkillSet; // 0x1d8(0x08)
	struct UFortAthenaAICoverComponent* CachedCoverComponent; // 0x1e0(0x08)
	struct UFortAthenaAIRuntimeParameters_DBNOBehavior* DBNOBehaviorRuntimeParameters; // 0x1e8(0x08)
	char pad_1F0[0x10]; // 0x1f0(0x10)

	void OnAllyPawnDBNOStateChanged(struct AFortPawn* InPlayer, bool bInIsDBNO); // Function FortniteAIServer.FortAthenaAIBotEvaluator_DBNO.OnAllyPawnDBNOStateChanged // (Final|Native|Private) // @ game+0xa4c2490
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_DefensiveBuilding
// Size: 0xc0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_DefensiveBuilding : UFortAthenaAIBotEvaluator {
	char pad_A8[0x8]; // 0xa8(0x08)
	struct UFortAthenaAIBotBuildingDigestedSkillSet* CachedBuildingDigestedSkillSet; // 0xb0(0x08)
	struct UFortAthenaAIBotBuildingComponent* CachedBuildingComponent; // 0xb8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Escape
// Size: 0x1d8 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Escape : UFortAthenaAIBotEvaluator_Movement {
	struct FGameplayTagContainer EscapeTags; // 0x1a8(0x20)
	float CooldownBetweenAggressivenessChanges; // 0x1c8(0x04)
	struct FName AggressivenessName; // 0x1cc(0x04)
	char pad_1D0[0x8]; // 0x1d0(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_EvasiveManeuvers
// Size: 0x290 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_EvasiveManeuvers : UFortAthenaAIBotEvaluator {
	char pad_A8[0xa8]; // 0xa8(0xa8)
	struct FName CrouchExecutionStatusName; // 0x150(0x04)
	struct FName JumpExecutionStatusName; // 0x154(0x04)
	struct FName JetpackStrafeExecutionStatusName; // 0x158(0x04)
	struct FName DodgeName; // 0x15c(0x04)
	struct FName DestinationKeyName; // 0x160(0x04)
	struct FName UrgentMoveKeyName; // 0x164(0x04)
	char pad_168[0xc]; // 0x168(0x0c)
	bool bDoCrouching; // 0x174(0x01)
	bool bDoDodging; // 0x175(0x01)
	bool bDoJumping; // 0x176(0x01)
	bool bDoJumpingDistanceCheck; // 0x177(0x01)
	bool bDoJetpackStrafing; // 0x178(0x01)
	bool bDoJetpackStrafingDistanceCheck; // 0x179(0x01)
	char pad_17A[0x2]; // 0x17a(0x02)
	float JetpackStrafingRequiredFuelPercent; // 0x17c(0x04)
	float JetpackStrafeNavPadding; // 0x180(0x04)
	char pad_184[0x4]; // 0x184(0x04)
	struct FGameplayTagQuery RequiredTagQuery; // 0x188(0x48)
	struct FGameplayTagQuery JetpackRequiredTagQuery; // 0x1d0(0x48)
	struct FGameplayTagQuery JumpRequiredTagQuery; // 0x218(0x48)
	struct UFortAthenaAIPerk_EvasiveManeuvers* ForcedPerkClass; // 0x260(0x08)
	struct UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet; // 0x268(0x08)
	char pad_270[0x20]; // 0x270(0x20)

	void OnMoveCompleted(struct FAIRequestID RequestID, enum class EPathFollowingResult MovementResult); // Function FortniteAIServer.FortAthenaAIBotEvaluator_EvasiveManeuvers.OnMoveCompleted // (Final|Native|Public) // @ game+0xa4c5240
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Flanking
// Size: 0x220 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Flanking : UFortAthenaAIBotEvaluator_Movement {
	struct AFortAIDirector* CachedAIDirector; // 0x1a8(0x08)
	struct UFortAthenaAIBotRangeAttackDigestedSkillSet* CachedRangeAttackDigestedSkillSet; // 0x1b0(0x08)
	struct FName FlankingExecutionStatusKeyName; // 0x1b8(0x04)
	struct FName FlankingMovementStateKeyName; // 0x1bc(0x04)
	struct FName FlankingDestinationKeyName; // 0x1c0(0x04)
	char pad_1C4[0xc]; // 0x1c4(0x0c)
	struct TArray<struct FFlankingLocationInfo> LocationsToEvaluate; // 0x1d0(0x10)
	struct TArray<struct FFlankingLocationInfo> BestLocations; // 0x1e0(0x10)
	struct TArray<struct TWeakObjectPtr<struct AActor>> ActorsInArea; // 0x1f0(0x10)
	char pad_200[0x20]; // 0x200(0x20)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Flee
// Size: 0x1e0 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Flee : UFortAthenaAIBotEvaluator_Movement {
	float MinDistanceFromTarget; // 0x1a8(0x04)
	float MinValidDistanceForFleeLocation; // 0x1ac(0x04)
	float FleeDistance; // 0x1b0(0x04)
	float MaxDistanceFromTargetWhenFleeing; // 0x1b4(0x04)
	float MinDistanceHysteresisWhenChangingTarget; // 0x1b8(0x04)
	struct FName FleeKeyName; // 0x1bc(0x04)
	struct FName FleeMovementStateKeyName; // 0x1c0(0x04)
	struct FName FleeDestinationKeyName; // 0x1c4(0x04)
	struct FName FleeActorKeyName; // 0x1c8(0x04)
	char pad_1CC[0xc]; // 0x1cc(0x0c)
	struct AActor* CurrentActorFleeingFrom; // 0x1d8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_FreeFalling
// Size: 0x1b0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_FreeFalling : UFortAthenaAIBotEvaluator {
	struct FName DiveExecutionStatusKeyName; // 0xa8(0x04)
	struct FName DiveDestinationKeyName; // 0xac(0x04)
	struct FName GlideExecutionStatusKeyName; // 0xb0(0x04)
	struct FName GlideDestinationKeyName; // 0xb4(0x04)
	struct FName JumpOffBusDestinationName; // 0xb8(0x04)
	char pad_BC[0xa]; // 0xbc(0x0a)
	bool bRandomlySelectFreeFallingMode; // 0xc6(0x01)
	char pad_C7[0x1]; // 0xc7(0x01)
	struct FScalableFloat IdleWeight; // 0xc8(0x28)
	struct FScalableFloat RandomWeight; // 0xf0(0x28)
	struct FScalableFloat TowardNearestAllyWeight; // 0x118(0x28)
	enum class EFreeFallingMode FreeFallingMode; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	float MaxOffsetRangeFromNearestAlly; // 0x144(0x04)
	char bShouldRecomputeDestinationWhenTowardNearestAlly : 1; // 0x148(0x01)
	char bShouldSearchAllyInSquad : 1; // 0x148(0x01)
	char bShouldSearchAllyInTeam : 1; // 0x148(0x01)
	char bGlideAllowed : 1; // 0x148(0x01)
	char pad_148_4 : 4; // 0x148(0x01)
	char pad_149[0x3]; // 0x149(0x03)
	float SkyTubeDivingStuckTimeThreshold; // 0x14c(0x04)
	char pad_150[0x20]; // 0x150(0x20)
	struct AFortPlayerStateAthena* NearestAlly; // 0x170(0x08)
	struct FVector CachedLatestDestination; // 0x178(0x18)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
	struct AFortSkyTube* CachedSkyTube; // 0x1a0(0x08)
	char pad_1A8[0x8]; // 0x1a8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Ground
// Size: 0x130 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_Ground : UFortAthenaAIBotEvaluator {
	struct FVector SurfaceTypeRaycastDir; // 0xa8(0x18)
	char pad_C0[0x68]; // 0xc0(0x68)
	struct UFortAthenaAIRuntimeParameters_Behavior* CachedBehaviorRuntimeParameters; // 0x128(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_HandleFocusing
// Size: 0x150 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_HandleFocusing : UFortAthenaAIBotEvaluator {
	struct FName TargetActorName; // 0xa8(0x04)
	struct FName InteractActorName; // 0xac(0x04)
	struct FName TargetLocationName; // 0xb0(0x04)
	struct FName FocusActorName; // 0xb4(0x04)
	struct FName FocalPointName; // 0xb8(0x04)
	struct FName WeaponFireName; // 0xbc(0x04)
	struct FName RangeAttackIsReadyToFireName; // 0xc0(0x04)
	struct FName WeaponTriggerMeleeName; // 0xc4(0x04)
	struct FName LastKnownPositionName; // 0xc8(0x04)
	struct FName TacticalSprintExecutionStatusName; // 0xcc(0x04)
	char pad_D0[0x14]; // 0xd0(0x14)
	enum class EFocusingBehavior FocusingBehavior; // 0xe4(0x01)
	enum class EFocusingBehavior NoRangedWeaponFocusBehavior; // 0xe5(0x01)
	bool bPrioritizeThreatOverCurrentTarget; // 0xe6(0x01)
	bool bUseTargetActorKeyAsFocusTarget; // 0xe7(0x01)
	bool bFocusOnTargetLocation; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	float AmbushMaxLKPLookAtAngleDegree; // 0xec(0x04)
	bool bStopFocusingWhenMoving; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	float ResumeFocusingWhenMovingDist; // 0xf4(0x04)
	float StopFocusingWhenMovingDist; // 0xf8(0x04)
	bool bResumeFocusWhileSliding; // 0xfc(0x01)
	char pad_FD[0x3]; // 0xfd(0x03)
	struct UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0x100(0x08)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet; // 0x108(0x08)
	struct AActor* LastTargetedThreat; // 0x110(0x08)
	char pad_118[0x8]; // 0x118(0x08)
	struct AActor* FocusActor; // 0x120(0x08)
	char pad_128[0x28]; // 0x128(0x28)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Heal
// Size: 0x118 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_Heal : UFortAthenaAIBotEvaluator {
	struct FName HealingObjectKeyName; // 0xa8(0x04)
	char pad_AC[0xc]; // 0xac(0x0c)
	struct FGameplayTagQuery RequiredTagQuery; // 0xb8(0x48)
	bool bAllowEvaluationRetry; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct UFortAthenaAIBotHealingDigestedSkillSet* HealingSkillSet; // 0x108(0x08)
	char pad_110[0x8]; // 0x110(0x08)

	void HandlePlayerHealthOrShieldChanged(); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Heal.HandlePlayerHealthOrShieldChanged // (Final|Native|Private) // @ game+0xa4d28f0
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_HitAndRun
// Size: 0x2a0 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_HitAndRun : UFortAthenaAIBotEvaluator_Movement {
	struct FScalableFloat AttackDurationBeforeEvade; // 0x1a8(0x28)
	struct FScalableFloat MeleeAttackMaxDistToEvade; // 0x1d0(0x28)
	struct FScalableFloat ClampEvadeDistanceEnable; // 0x1f8(0x28)
	struct FScalableFloat MinDistanceToEvade; // 0x220(0x28)
	struct FScalableFloat MaxDistanceToEvade; // 0x248(0x28)
	struct FName EvadeKeyName; // 0x270(0x04)
	struct FName EvadeMovementStateKeyName; // 0x274(0x04)
	struct FName EvadeDestinationKeyName; // 0x278(0x04)
	struct FName WeaponTriggerMeleeName; // 0x27c(0x04)
	char pad_280[0x10]; // 0x280(0x10)
	float MeleeAttackMaxDistToEvadeSqr; // 0x290(0x04)
	float MaxDistanceToEvadeSqr; // 0x294(0x04)
	char pad_298[0x8]; // 0x298(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_HolsterWeapon
// Size: 0xb0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_HolsterWeapon : UFortAthenaAIBotEvaluator {
	struct UFortAthenaAIRuntimeParameters_NPCBehavior* CachedNPCBehaviorParameters; // 0xa8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Investigate
// Size: 0x268 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Investigate : UFortAthenaAIBotEvaluator_Movement {
	struct FName LastKnownPositionName; // 0x1a8(0x04)
	struct FName DestinationKeyName; // 0x1ac(0x04)
	struct FName MoveToDestinationKeyName; // 0x1b0(0x04)
	struct FName AggressivenessName; // 0x1b4(0x04)
	struct FName CautiousKeyName; // 0x1b8(0x04)
	char pad_1BC[0x4]; // 0x1bc(0x04)
	struct UNavigationQueryFilter* SearchQueryFilterClass; // 0x1c0(0x08)
	char pad_1C8[0x10]; // 0x1c8(0x10)
	struct UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0x1d8(0x08)
	struct UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet; // 0x1e0(0x08)
	struct UFortAthenaAIBotUnstuckDigestedSkillSet* CachedUnstuckSkillSet; // 0x1e8(0x08)
	char pad_1F0[0x48]; // 0x1f0(0x48)
	struct AActor* InvestigatingSupportingActor; // 0x238(0x08)
	struct ABuildingSMActor* UnderminingBuildingActor; // 0x240(0x08)
	struct AActor* ExcludeReachingTarget; // 0x248(0x08)
	char pad_250[0x18]; // 0x250(0x18)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_JumpOffBus
// Size: 0xf0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_JumpOffBus : UFortAthenaAIBotEvaluator {
	struct FName JumpOffBusDestinationName; // 0xa8(0x04)
	struct FName JumpOffBusDestinationVolumeKeyName; // 0xac(0x04)
	char pad_B0[0x20]; // 0xb0(0x20)
	struct AFortPoiVolume* BusDroppingVolume; // 0xd0(0x08)
	struct AFortGameStateAthena* CachedAthenaGameState; // 0xd8(0x08)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet; // 0xe0(0x08)
	char pad_E8[0x8]; // 0xe8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_MeleeAttack
// Size: 0x1e8 (Inherited: 0x1c0)
struct UFortAthenaAIBotEvaluator_MeleeAttack : UFortAthenaAIBotEvaluator_Attack {
	char pad_1C0[0x4]; // 0x1c0(0x04)
	struct FName WeaponTriggerMeleeName; // 0x1c4(0x04)
	struct FName ThrowableAttacksAllowedName; // 0x1c8(0x04)
	struct FName TraversalBlockMeleeAttackName; // 0x1cc(0x04)
	char pad_1D0[0x8]; // 0x1d0(0x08)
	struct UFortAthenaAIBotAttackingDigestedSkillSet* AttackingSkillSet; // 0x1d8(0x08)
	char pad_1E0[0x8]; // 0x1e0(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Observe
// Size: 0xc8 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_Observe : UFortAthenaAIBotEvaluator {
	struct FName AggressivenessName; // 0xa8(0x04)
	struct FName ObserveDestinationKeyName; // 0xac(0x04)
	char pad_B0[0x4]; // 0xb0(0x04)
	bool bContinueMovementOnStart; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	float MaxMovementDuration; // 0xb8(0x04)
	char pad_BC[0xc]; // 0xbc(0x0c)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_PathExists
// Size: 0xc8 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_PathExists : UFortAthenaAIBotEvaluator {
	struct FName PathExistsKeyName; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FName GoalKeyName; // 0xb0(0x04)
	float AcceptableRadius; // 0xb4(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0xb8(0x08)
	enum class EPathTestQueryType PathQueryType; // 0xc0(0x01)
	char pad_C1[0x3]; // 0xc1(0x03)
	char bProjectGoalLocation : 1; // 0xc4(0x01)
	char bReachTestIncludesAgentRadius : 1; // 0xc4(0x01)
	char bReachTestIncludesGoalRadius : 1; // 0xc4(0x01)
	char pad_C4_3 : 5; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_PatrolAround
// Size: 0x238 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_PatrolAround : UFortAthenaAIBotEvaluator_Movement {
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x1a8(0x48)
	struct UNavigationQueryFilter* NavigationQueryFilterClass; // 0x1f0(0x08)
	bool bFallbackToPointWithNoCustomNavigationQueryFilter; // 0x1f8(0x01)
	char pad_1F9[0x3]; // 0x1f9(0x03)
	struct FName PatrolDestinationName; // 0x1fc(0x04)
	struct FName PatrolExecutionStatusName; // 0x200(0x04)
	struct FName PatrolMovementStateName; // 0x204(0x04)
	struct FName BestTargetActorName; // 0x208(0x04)
	char pad_20C[0x4]; // 0x20c(0x04)
	struct AFortGameModeAthena* CacheAthenaGameMode; // 0x210(0x08)
	char pad_218[0x20]; // 0x218(0x20)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_PlayEmote
// Size: 0x1c8 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_PlayEmote : UFortAthenaAIBotEvaluator_Movement {
	struct FName PlayEmoteExecutionStatusKeyName; // 0x1a8(0x04)
	struct FName PlayEmoteDestinationKeyName; // 0x1ac(0x04)
	char pad_1B0[0x8]; // 0x1b0(0x08)
	struct AActor* ExcludeReachingTarget; // 0x1b8(0x08)
	char pad_1C0[0x8]; // 0x1c0(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_PropagateAwareness
// Size: 0x130 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_PropagateAwareness : UFortAthenaAIBotEvaluator {
	struct FGameplayTagQuery AwarenessTagQuery; // 0xa8(0x48)
	struct UGameplayEffect* AwarenessGameplayEffectClass; // 0xf0(0x08)
	struct TArray<struct AFortPlayerPawnAthena*> AwareAllyPawns; // 0xf8(0x10)
	struct TArray<struct AFortPlayerPawnAthena*> AlreadyTestedPawns; // 0x108(0x10)
	struct UFortAthenaAIBotPropagateAwarenessDigestedSkillSet* PropagateAwarenessSkillSet; // 0x118(0x08)
	struct UFortAthenaAIRuntimeParameters_BehaviorTreeControl* BehaviorControlsRuntimeParameters; // 0x120(0x08)
	struct UFortAthenaAIRuntimeParameters_AffiliationBase* AffiliationRuntimeParameters; // 0x128(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_RangeAttack
// Size: 0x308 (Inherited: 0x1c0)
struct UFortAthenaAIBotEvaluator_RangeAttack : UFortAthenaAIBotEvaluator_Attack {
	char pad_1C0[0x18]; // 0x1c0(0x18)
	struct FName WeaponReloadName; // 0x1d8(0x04)
	struct FName WeaponFireName; // 0x1dc(0x04)
	struct FName RangeAttackIsReadyToFireName; // 0x1e0(0x04)
	struct FName WeaponTargetingName; // 0x1e4(0x04)
	struct FName AggressivenessName; // 0x1e8(0x04)
	struct FName HasLoSOnThreatName; // 0x1ec(0x04)
	struct FName UrgentMovementKeyName; // 0x1f0(0x04)
	char pad_1F4[0xe]; // 0x1f4(0x0e)
	bool bAlwaysAllowTargetingEvaluation; // 0x202(0x01)
	bool bSkipADSEvaluation; // 0x203(0x01)
	bool bConsiderLoF; // 0x204(0x01)
	char pad_205[0x3]; // 0x205(0x03)
	float RangeReachHysteresisRatio; // 0x208(0x04)
	char pad_20C[0x1c]; // 0x20c(0x1c)
	struct UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet; // 0x228(0x08)
	struct UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0x230(0x08)
	struct UFortAthenaAIBotPerceptionDigestedSkillSet* CachePerceptionDigestedSkillSet; // 0x238(0x08)
	struct UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet; // 0x240(0x08)
	struct UAthenaAIServiceZoneManager* CacheZoneManager; // 0x248(0x08)
	struct AActor* ExcludeReachingTarget; // 0x250(0x08)
	char pad_258[0xb0]; // 0x258(0xb0)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_ReachBeacon
// Size: 0x1c8 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_ReachBeacon : UFortAthenaAIBotEvaluator_Movement {
	struct FName ReachBeaconStatusKeyName; // 0x1a8(0x04)
	struct FName ReachBeaconMovementStateKeyName; // 0x1ac(0x04)
	struct FName ReachBeaconTargetKeyName; // 0x1b0(0x04)
	char pad_1B4[0x8]; // 0x1b4(0x08)
	struct TWeakObjectPtr<struct UFortAthenaBeaconComponent> CurrentBeacon; // 0x1bc(0x08)
	char pad_1C4[0x4]; // 0x1c4(0x04)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_RecoverLineOfSight
// Size: 0x210 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_RecoverLineOfSight : UFortAthenaAIBotEvaluator_Movement {
	struct FScalableFloat RecoveringLineOfSightMaxDuration; // 0x1a8(0x28)
	struct TArray<struct FName> ExecutionStatusToListenKeyNames; // 0x1d0(0x10)
	struct FName RecoverLineOfSightExecutionStatusKeyName; // 0x1e0(0x04)
	struct FName RecoverLineOfSightMovementStateKeyName; // 0x1e4(0x04)
	struct FName RecoverLineOfSightDestinationKeyName; // 0x1e8(0x04)
	char pad_1EC[0x24]; // 0x1ec(0x24)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_ReloadWeapon
// Size: 0xb0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_ReloadWeapon : UFortAthenaAIBotEvaluator {
	struct FName WeaponKeyName; // 0xa8(0x04)
	char pad_AC[0x2]; // 0xac(0x02)
	bool bCanReloadWeaponsInInventory; // 0xae(0x01)
	char pad_AF[0x1]; // 0xaf(0x01)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Retreat
// Size: 0x1d0 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Retreat : UFortAthenaAIBotEvaluator_Movement {
	struct FName RetreatDestinationName; // 0x1a8(0x04)
	char pad_1AC[0x4]; // 0x1ac(0x04)
	struct UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet; // 0x1b0(0x08)
	struct UFortAthenaAICoverComponent* CachedCoverComponent; // 0x1b8(0x08)
	char pad_1C0[0x10]; // 0x1c0(0x10)

	void HandlePlayerHealthOrShieldChanged(); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Retreat.HandlePlayerHealthOrShieldChanged // (Final|Native|Protected) // @ game+0xa4e8980
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Revive
// Size: 0x210 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Revive : UFortAthenaAIBotEvaluator_Movement {
	struct FScalableFloat LastReviveTargetExpiration; // 0x1a8(0x28)
	struct FName ReviveTargetKeyName; // 0x1d0(0x04)
	struct FName ReviveLastTargetKeyName; // 0x1d4(0x04)
	struct UFortAthenaAIRuntimeParameters_ReviveBehavior* ReviveBehaviorRuntimeParameters; // 0x1d8(0x08)
	struct AFortPlayerPawnAthena* CurrentReviveTarget; // 0x1e0(0x08)
	struct TArray<struct AFortPlayerPawnAthena*> DBNOAllyPawns; // 0x1e8(0x10)
	struct UFortAthenaAIBotReviveDigestedSkillSet* ReviveSkillSet; // 0x1f8(0x08)
	char pad_200[0x10]; // 0x200(0x10)

	void OnCurrentTargetRevived(struct AFortPlayerPawn* RevivedPawn); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Revive.OnCurrentTargetRevived // (Final|Native|Private) // @ game+0xa4e99b0
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_SandTunnel
// Size: 0x170 (Inherited: 0xf8)
struct UFortAthenaAIBotEvaluator_SandTunnel : UFortAthenaAIBotEvaluator_TagQuery {
	struct FName JumpExecutionStatusName; // 0xf8(0x04)
	struct FName LootInteractionExecutionStatusName; // 0xfc(0x04)
	struct FName WeaponTriggerMeleeName; // 0x100(0x04)
	struct FName WeaponFireName; // 0x104(0x04)
	char pad_108[0x8]; // 0x108(0x08)
	struct FGameplayTagQuery BuriedTagQuery; // 0x110(0x48)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementDigestedSkillSet; // 0x158(0x08)
	char pad_160[0x10]; // 0x160(0x10)

	void OnBotControllerAlertLevelChanged(struct AFortAthenaAIBotController* BotController, enum class EAlertLevel OldAlertLevel, enum class EAlertLevel NewAlertLevel); // Function FortniteAIServer.FortAthenaAIBotEvaluator_SandTunnel.OnBotControllerAlertLevelChanged // (Final|Native|Private) // @ game+0xa4eaf70
	void Jump(); // Function FortniteAIServer.FortAthenaAIBotEvaluator_SandTunnel.Jump // (Final|Native|Protected) // @ game+0xa4eb1a0
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_SelectNextDynamicPOI
// Size: 0x220 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_SelectNextDynamicPOI : UFortAthenaAIBotEvaluator_Movement {
	struct FName DynamicPOIExecutionStatusKeyName; // 0x1a8(0x04)
	struct FName DynamicPOILocationKeyName; // 0x1ac(0x04)
	char pad_1B0[0x8]; // 0x1b0(0x08)
	struct AFortTeamInfoAthena* CachedTeamInfo; // 0x1b8(0x08)
	struct UFortGameStateComponent_BattleRoyaleGamePhaseLogic* CachedGamePhaseLogic; // 0x1c0(0x08)
	char pad_1C8[0x38]; // 0x1c8(0x38)
	struct FTimerHandle NextSearchTimerHandle; // 0x200(0x08)
	struct TArray<struct FFailedToReachPOI> FailedBotPOIList; // 0x208(0x10)
	int32_t CachedSelectedBotPOIID; // 0x218(0x04)
	char pad_21C[0x4]; // 0x21c(0x04)

	void OnSafeZonePhaseChanged(struct FFortSafeZonePhaseUpdatedEvent& Event); // Function FortniteAIServer.FortAthenaAIBotEvaluator_SelectNextDynamicPOI.OnSafeZonePhaseChanged // (Final|Native|Private|HasOutParms) // @ game+0xa4ec970
	void OnGamePhaseLogicReady(struct FFortBattleRoyaleGamePhaseLogicComponentReadyEvent& Event); // Function FortniteAIServer.FortAthenaAIBotEvaluator_SelectNextDynamicPOI.OnGamePhaseLogicReady // (Final|Native|Private|HasOutParms) // @ game+0xa4eca60
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_SelectNextPOI
// Size: 0x1e0 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_SelectNextPOI : UFortAthenaAIBotEvaluator_Movement {
	struct FName NextPOIKeyName; // 0x1a8(0x04)
	struct FName MarkerLocationKeyName; // 0x1ac(0x04)
	char pad_1B0[0x8]; // 0x1b0(0x08)
	struct AFortPoiVolume* StartingGroundPOI; // 0x1b8(0x08)
	bool bCheckForStartingGroundPOI; // 0x1c0(0x01)
	char pad_1C1[0x3]; // 0x1c1(0x03)
	float CurrentPOICompletionTime; // 0x1c4(0x04)
	float DurationInsideCurrentPOI; // 0x1c8(0x04)
	char pad_1CC[0x4]; // 0x1cc(0x04)
	struct AFortTeamInfoAthena* CachedTeamInfo; // 0x1d0(0x08)
	struct UFortAthenaAIBotLootingDigestedSkillSet* CachedLootingSkillSet; // 0x1d8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_SelectVehicle
// Size: 0x288 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_SelectVehicle : UFortAthenaAIBotEvaluator_Movement {
	struct FName VehicleDestinationKeyName; // 0x1a8(0x04)
	struct FName SelectVehicleMovementStateKeyName; // 0x1ac(0x04)
	struct FName SelectVehicleStatusKeyName; // 0x1b0(0x04)
	struct FName SelectedVehicleKeyName; // 0x1b4(0x04)
	char pad_1B8[0x8]; // 0x1b8(0x08)
	struct FScalableFloat Enabled; // 0x1c0(0x28)
	float VehicleSearchRadius; // 0x1e8(0x04)
	bool bCanEnterOnlyWithHisConverter; // 0x1ec(0x01)
	bool bCanEnterAsDriver; // 0x1ed(0x01)
	bool bCanEnterVehiclesInWater; // 0x1ee(0x01)
	bool bCanEnterOutOfFuelVehicles; // 0x1ef(0x01)
	bool bCanEnterWithPlayerDriver; // 0x1f0(0x01)
	bool bCanEnterOnlyMatchingPatrols; // 0x1f1(0x01)
	char pad_1F2[0x6]; // 0x1f2(0x06)
	struct FGameplayTagQuery VehiclesFilterTagQuery; // 0x1f8(0x48)
	struct FGameplayTagQuery SeatsFilterTagQuery; // 0x240(0x48)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_SmartObjects
// Size: 0x220 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_SmartObjects : UFortAthenaAIBotEvaluator_Movement {
	struct UFortAthenaAIRuntimeParameters_SmartObjectBase* SmartObjectRuntimeParameters; // 0x1a8(0x08)
	struct USmartObjectSubsystem* SmartObjectSubsystem; // 0x1b0(0x08)
	char pad_1B8[0x8]; // 0x1b8(0x08)
	bool bEvaluateSOValidityAfterChosen; // 0x1c0(0x01)
	bool bEnableEntryLocationsSupport; // 0x1c1(0x01)
	char pad_1C2[0x6]; // 0x1c2(0x06)
	struct UCurveFloat* DistanceToWeightCurveForSlotPicking; // 0x1c8(0x08)
	struct USmartObjectSlotValidationFilter* OverridenFilterClassForEntryPoints; // 0x1d0(0x08)
	struct TArray<struct FName> ExecutionStatusesToCheckForAllowToAvoidGoingToSOKeyNames; // 0x1d8(0x10)
	char pad_1E8[0x10]; // 0x1e8(0x10)
	struct FName SmartObjectExecutionStatusKeyName; // 0x1f8(0x04)
	struct FName SmartObjectMovementStateKeyName; // 0x1fc(0x04)
	struct FName SmartObjectDestinationKeyName; // 0x200(0x04)
	struct FName SmartObjectDestinationRotationKeyName; // 0x204(0x04)
	struct FName SmartObjectShouldMoveKeyName; // 0x208(0x04)
	struct FName SmartObjectUrgencyKeyName; // 0x20c(0x04)
	char pad_210[0x10]; // 0x210(0x10)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Sprinting
// Size: 0x128 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_Sprinting : UFortAthenaAIBotEvaluator {
	struct FName AllowSprintKeyName; // 0xa8(0x04)
	struct FName AllowSlideKeyName; // 0xac(0x04)
	struct FName JumpExecutionStatusName; // 0xb0(0x04)
	struct FName TacticalSprintExecutionStatusName; // 0xb4(0x04)
	struct FName SlideExecutionStatusName; // 0xb8(0x04)
	struct FName UrgentMovementKeyName; // 0xbc(0x04)
	struct FName RangeAttackExecutionStatusName; // 0xc0(0x04)
	struct FName MeleeAttackExecutionStatusName; // 0xc4(0x04)
	struct FName ThrowableAttackExecutionStatusName; // 0xc8(0x04)
	char pad_CC[0x12]; // 0xcc(0x12)
	bool bSprintOnlyInWater; // 0xde(0x01)
	bool bSprintOnlyInUrgentMode; // 0xdf(0x01)
	struct UFortAthenaAIBotMovementDigestedSkillSet* MovementSkillSet; // 0xe0(0x08)
	struct UFortAthenaAIBotAimingDigestedSkillSet* AimingSkillSet; // 0xe8(0x08)
	float TacticalSprintTriggerChance; // 0xf0(0x04)
	float TacticalSprintTriggerChanceInUrgentMovement; // 0xf4(0x04)
	float TacticalSprintJumpTriggerChance; // 0xf8(0x04)
	char pad_FC[0x2c]; // 0xfc(0x2c)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_StealWall
// Size: 0x150 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_StealWall : UFortAthenaAIBotEvaluator {
	struct FName StealWallBuildTypeName; // 0xa8(0x04)
	struct FName StealWallBuildGridCoordName; // 0xac(0x04)
	struct FName TargetActorName; // 0xb0(0x04)
	char pad_B4[0xc]; // 0xb4(0x0c)
	struct UFortAthenaAIBotBuildingDigestedSkillSet* CacheBuildingDigestedSkillSet; // 0xc0(0x08)
	struct ABuildingActor* CurrentBuildingTarget; // 0xc8(0x08)
	char pad_D0[0x80]; // 0xd0(0x80)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_StepBack
// Size: 0x1d8 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_StepBack : UFortAthenaAIBotEvaluator_Movement {
	struct UFortAthenaAIBotRangeAttackDigestedSkillSet* CachedRangeAttackDigestedSkillSet; // 0x1a8(0x08)
	struct UAthenaAIServiceCover* CachedAIServiceCover; // 0x1b0(0x08)
	char pad_1B8[0x8]; // 0x1b8(0x08)
	struct FName StepBackExecutionStatusKeyName; // 0x1c0(0x04)
	struct FName StepBackMovementStateKeyName; // 0x1c4(0x04)
	struct FName StepBackDestinationKeyName; // 0x1c8(0x04)
	char pad_1CC[0xc]; // 0x1cc(0x0c)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Storm
// Size: 0x1e8 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Storm : UFortAthenaAIBotEvaluator_Movement {
	struct FName StormDestinationName; // 0x1a8(0x04)
	char pad_1AC[0xc]; // 0x1ac(0x0c)
	struct AFortGameModeAthena* CacheAthenaGameMode; // 0x1b8(0x08)
	struct UBehaviorTreeComponent* CachedBTComp; // 0x1c0(0x08)
	char pad_1C8[0x20]; // 0x1c8(0x20)

	void OnSafeZoneStateChanged(enum class EFortSafeZoneState NewState); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Storm.OnSafeZoneStateChanged // (Final|Native|Public) // @ game+0xa4f8540
	void OnSafeZonePhaseChanged(); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Storm.OnSafeZonePhaseChanged // (Final|Native|Public) // @ game+0xa4f8650
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_TagQueryToBBKey
// Size: 0x100 (Inherited: 0xf8)
struct UFortAthenaAIBotEvaluator_TagQueryToBBKey : UFortAthenaAIBotEvaluator_TagQuery {
	struct FName LinkedBBKeyName; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_TakeCover
// Size: 0x238 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_TakeCover : UFortAthenaAIBotEvaluator_Movement {
	struct UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet; // 0x1a8(0x08)
	struct UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0x1b0(0x08)
	struct UAthenaAIServiceCover* CachedAIServiceCover; // 0x1b8(0x08)
	struct FName DestinationKeyName; // 0x1c0(0x04)
	struct FName MoveToDestinationKeyName; // 0x1c4(0x04)
	struct FName HealingStatusKeyName; // 0x1c8(0x04)
	struct FName WeaponFireName; // 0x1cc(0x04)
	struct FName TargetActorName; // 0x1d0(0x04)
	struct FName BunkerStatusKeyName; // 0x1d4(0x04)
	char pad_1D8[0x10]; // 0x1d8(0x10)
	struct ABuildingActor* CachedCoverBuildingActor; // 0x1e8(0x08)
	struct TArray<struct ABuildingActor*> ExcludedBuildingActors; // 0x1f0(0x10)
	char pad_200[0x38]; // 0x200(0x38)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_ThrowableAttack
// Size: 0x210 (Inherited: 0x1c0)
struct UFortAthenaAIBotEvaluator_ThrowableAttack : UFortAthenaAIBotEvaluator_Attack {
	struct FName WeaponTriggerThrowableName; // 0x1c0(0x04)
	struct FName ThrowableAttackIsReadyToThrowName; // 0x1c4(0x04)
	char pad_1C8[0x8]; // 0x1c8(0x08)
	struct UFortAthenaAIBotAttackingDigestedSkillSet* AttackingSkillSet; // 0x1d0(0x08)
	struct UFortAthenaAIBotRangeAttackDigestedSkillSet* RangeAttackSkillSet; // 0x1d8(0x08)
	struct UFortAthenaAIBotAimingDigestedSkillSet* AimingSkillSet; // 0x1e0(0x08)
	struct UFortWorldItem* ChosenWeapon; // 0x1e8(0x08)
	struct AFortPawn* CachedFortPawn; // 0x1f0(0x08)
	char pad_1F8[0x18]; // 0x1f8(0x18)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_TrapOnPathDetected
// Size: 0xd8 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_TrapOnPathDetected : UFortAthenaAIBotEvaluator {
	struct UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0xa8(0x08)
	struct FName TrapOnPathKeyName; // 0xb0(0x04)
	struct FName TrapActorOnPathKeyName; // 0xb4(0x04)
	struct FName TargetActorName; // 0xb8(0x04)
	struct FName AlertLevelName; // 0xbc(0x04)
	struct FName RangeAttackExecutionStatusName; // 0xc0(0x04)
	char pad_C4[0xc]; // 0xc4(0x0c)
	struct ABuildingTrap* CurrentTrapTarget; // 0xd0(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_VehicleLeaveSeat
// Size: 0xb0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_VehicleLeaveSeat : UFortAthenaAIBotEvaluator {
	struct FName LeaveSeatStatusKeyName; // 0xa8(0x04)
	char pad_AC[0x2]; // 0xac(0x02)
	bool bLeaveSeatWhenPlayerInVehicle; // 0xae(0x01)
	bool bLeaveSeatWhenConverterLeave; // 0xaf(0x01)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_VehicleSwitchSeat
// Size: 0xb0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_VehicleSwitchSeat : UFortAthenaAIBotEvaluator {
	struct FName SwitchSeatStatusKeyName; // 0xa8(0x04)
	char pad_AC[0x2]; // 0xac(0x02)
	bool bSwitchToEmptyDriverSeat; // 0xae(0x01)
	char pad_AF[0x1]; // 0xaf(0x01)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_WaitForPassengers
// Size: 0xb0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_WaitForPassengers : UFortAthenaAIBotEvaluator {
	struct FName WaitForPassengersStatusKeyName; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Warmup
// Size: 0xd8 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_Warmup : UFortAthenaAIBotEvaluator {
	struct FName WarmupPlayEmoteExecutionStatusKeyName; // 0xa8(0x04)
	struct FName WarmupLootAndShootExecutionStatusKeyName; // 0xac(0x04)
	struct FName WarmupIdleExecutionStatusKeyName; // 0xb0(0x04)
	char pad_B4[0xc]; // 0xb4(0x0c)
	struct UFortAthenaAIBotWarmupDigestedSkillSet* CacheWarmupDigestedSkillSet; // 0xc0(0x08)
	char pad_C8[0x10]; // 0xc8(0x10)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_WeaponSelection
// Size: 0xe0 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_WeaponSelection : UFortAthenaAIBotEvaluator {
	struct FName ThrowableAttackIsReadyToThrowName; // 0xa8(0x04)
	struct FName WeaponKeyName; // 0xac(0x04)
	struct FName TargetActorName; // 0xb0(0x04)
	char pad_B4[0x14]; // 0xb4(0x14)
	struct UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackDigestedSkillSet; // 0xc8(0x08)
	struct UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingDigestedSkillSet; // 0xd0(0x08)
	struct UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0xd8(0x08)
};

// Class FortniteAIServer.FortAthenaAIBotEvaluator_Zipline
// Size: 0x248 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Zipline : UFortAthenaAIBotEvaluator_Movement {
	struct FName CurrentDestinationKeyName; // 0x1a8(0x04)
	struct FName ZiplineTargetKeyName; // 0x1ac(0x04)
	struct FName LastZiplineUsedName; // 0x1b0(0x04)
	struct FName ZiplineMoveExecutionStatusKeyName; // 0x1b4(0x04)
	struct FName ZiplineEntryLocationKeyName; // 0x1b8(0x04)
	struct FName ZiplineExitLocationKeyName; // 0x1bc(0x04)
	struct FName ZiplineLastUsageTimeName; // 0x1c0(0x04)
	struct FName ZiplineUsageExecutionStatusName; // 0x1c4(0x04)
	struct FScalableFloat WaitTimeBetweenZiplineRandomChoices; // 0x1c8(0x28)
	struct FScalableFloat ProbabilityToUseZipline; // 0x1f0(0x28)
	char pad_218[0x30]; // 0x218(0x30)

	void OnZiplineStateChanged(bool bIsZiplining, struct AFortPlayerPawn* FortPlayerPawn); // Function FortniteAIServer.FortAthenaAIBotEvaluator_Zipline.OnZiplineStateChanged // (Final|Native|Protected) // @ game+0xa4fe4b0
};

// Class FortniteAIServer.FortAthenaAIEvaluator_BlueprintBase
// Size: 0xd8 (Inherited: 0xa8)
struct UFortAthenaAIEvaluator_BlueprintBase : UFortAthenaAIBotEvaluator {
	bool bBlockWeaponActions; // 0xa8(0x01)
	bool bGameplayAbilityEvaluator; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
	struct FGameplayAbilityEvaluatorModule GameplayAbilityEvaluatorModule; // 0xb0(0x28)

	void OnExit(struct UBehaviorTreeComponent* OwnerComp); // Function FortniteAIServer.FortAthenaAIEvaluator_BlueprintBase.OnExit // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEnter(struct UBehaviorTreeComponent* OwnerComp); // Function FortniteAIServer.FortAthenaAIEvaluator_BlueprintBase.OnEnter // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool EvaluateStartingConditions(struct UBehaviorTreeComponent* OwnerComp); // Function FortniteAIServer.FortAthenaAIEvaluator_BlueprintBase.EvaluateStartingConditions // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0xa501950
	bool EvaluateOngoingConditions(struct UBehaviorTreeComponent* OwnerComp); // Function FortniteAIServer.FortAthenaAIEvaluator_BlueprintBase.EvaluateOngoingConditions // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0xa501850
};

// Class FortniteAIServer.FortAthenaAIEvaluator_DormantUntilPhase
// Size: 0x130 (Inherited: 0xa0)
struct UFortAthenaAIEvaluator_DormantUntilPhase : UFortAthenaAIEvaluator {
	struct FScalableFloat bIsEnabled; // 0xa0(0x28)
	bool bDisabledInCreative; // 0xc8(0x01)
	enum class EAthenaGamePhaseStep RequiredGamePhaseStep; // 0xc9(0x01)
	char pad_CA[0x6]; // 0xca(0x06)
	struct FScalableFloat DelayAfterPhase; // 0xd0(0x28)
	struct FScalableFloat RandomDeviationAfterPhase; // 0xf8(0x28)
	char pad_120[0x10]; // 0x120(0x10)

	void HandleGamePhaseStepChanged(struct TScriptInterface<IFortSafeZoneInterface>& SafeZoneInterface, enum class EAthenaGamePhaseStep GamePhaseStep); // Function FortniteAIServer.FortAthenaAIEvaluator_DormantUntilPhase.HandleGamePhaseStepChanged // (Final|Native|Private|HasOutParms) // @ game+0xa502130
};

// Class FortniteAIServer.FortAthenaAIEvaluator_FleeEnvDanger
// Size: 0xc8 (Inherited: 0xa0)
struct UFortAthenaAIEvaluator_FleeEnvDanger : UFortAthenaAIEvaluator {
	float MaximumCheckDistance; // 0xa0(0x04)
	float AdditionalFleeDistance; // 0xa4(0x04)
	struct FName EnvironmentalDangerExecutionStatusName; // 0xa8(0x04)
	struct FName EnvironmentalDangerFleeDirectionFromKeyName; // 0xac(0x04)
	struct FName EnvironmentalDangerFleeDirectionToKeyName; // 0xb0(0x04)
	struct FName EnvironmentalDangerFleeDistanceKeyName; // 0xb4(0x04)
	char pad_B8[0x8]; // 0xb8(0x08)
	struct AAIController* CachedController; // 0xc0(0x08)
};

// Class FortniteAIServer.FortAthenaAIEvaluator_FollowGroupLeader
// Size: 0x1c8 (Inherited: 0x1a8)
struct UFortAthenaAIEvaluator_FollowGroupLeader : UFortAthenaAIBotEvaluator_Movement {
	struct FName FollowGroupLeaderStatusKeyName; // 0x1a8(0x04)
	struct FName FollowGroupLeaderMovementStateKeyName; // 0x1ac(0x04)
	struct FName FollowGroupLeaderDestinationKeyName; // 0x1b0(0x04)
	struct FName TooFarFromLeaderKeyName; // 0x1b4(0x04)
	char pad_1B8[0x8]; // 0x1b8(0x08)
	struct UFortPawnComponent_AIGroup* CachedAIGroupComponent; // 0x1c0(0x08)
};

// Class FortniteAIServer.FortAthenaAIEvaluator_Leash
// Size: 0xc0 (Inherited: 0xa0)
struct UFortAthenaAIEvaluator_Leash : UFortAthenaAIEvaluator {
	struct FName GoalIsInsideLeashKeyName; // 0xa0(0x04)
	struct FName AIIsInsideLeashKeyName; // 0xa4(0x04)
	char pad_A8[0x8]; // 0xa8(0x08)
	struct UFortAthenaLeashComponent* CachedLeashComponent; // 0xb0(0x08)
	struct UFortAIGoalComponent* CachedAIGoalComponent; // 0xb8(0x08)
};

// Class FortniteAIServer.FortAthenaAIEvaluator_NearbyActorsPerception
// Size: 0x250 (Inherited: 0xa0)
struct UFortAthenaAIEvaluator_NearbyActorsPerception : UFortAthenaAIEvaluator {
	struct FName FoundNearbyActorKeyName; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FScalableFloat MinimumUpdateInterval; // 0xa8(0x28)
	int32_t RequiredTypes; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct FScalableFloat MinimumDistanceToActors; // 0xd8(0x28)
	struct TArray<enum class ETeamAttitude> RequiredAttitudes; // 0x100(0x10)
	bool bRequireLoS; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	struct FGameplayTagQuery RequiredTagsQuery; // 0x118(0x48)
	char pad_160[0xf0]; // 0x160(0xf0)
};

// Class FortniteAIServer.FortAthenaAIEvaluator_SpeechBubble
// Size: 0x250 (Inherited: 0x250)
struct UFortAthenaAIEvaluator_SpeechBubble : UFortAthenaAIEvaluator_NearbyActorsPerception {
	struct UFortPawnComponent_SpeechBubble* CachedSpeechBubbleComponent; // 0x248(0x08)
};

// Class FortniteAIServer.FortAthenaBTContext_SuppressAutomaticAttackCheck
// Size: 0x70 (Inherited: 0x70)
struct UFortAthenaBTContext_SuppressAutomaticAttackCheck : UFortBTService_ContextOverride {
};

// Class FortniteAIServer.FortAthenaBTService_AIEvaluator
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTService_AIEvaluator : UBTService {
	struct FGameplayTag InjectionTag; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct UFortAthenaAIEvaluator* AIEvaluatorClass; // 0x78(0x08)
};

// Class FortniteAIServer.FortAthenaBTService_ApplyGameplayTags
// Size: 0x90 (Inherited: 0x70)
struct UFortAthenaBTService_ApplyGameplayTags : UBTService {
	struct FGameplayTagContainer GameplayTagsToApply; // 0x70(0x20)
};

// Class FortniteAIServer.FortAthenaBTService_BuildConstruction
// Size: 0x88 (Inherited: 0x70)
struct UFortAthenaBTService_BuildConstruction : UBTService {
	struct FName StealWallBuildName; // 0x70(0x04)
	struct FName StealWallBuildTypeName; // 0x74(0x04)
	struct FName StealWallBuildGridCoordName; // 0x78(0x04)
	char pad_7C[0xc]; // 0x7c(0x0c)
};

// Class FortniteAIServer.FortAthenaBTService_Clamber
// Size: 0xa0 (Inherited: 0x70)
struct UFortAthenaBTService_Clamber : UBTService {
	struct FName ClamberExecutionStatusName; // 0x70(0x04)
	struct FName ClamberOriginLocationName; // 0x74(0x04)
	struct FName ClamberDestinationLocationName; // 0x78(0x04)
	struct FName ClamberAbilityStatusName; // 0x7c(0x04)
	struct FName JumpExecutionStatusName; // 0x80(0x04)
	struct FName CrouchExecutionStatusName; // 0x84(0x04)
	char pad_88[0xc]; // 0x88(0x0c)
	uint32_t FirstJumpRetryMaxCount; // 0x94(0x04)
	float FirstJumpRetryDelay; // 0x98(0x04)
	float FirstJumpClamberMaxStartDelay; // 0x9c(0x04)
};

// Class FortniteAIServer.FortAthenaBTService_CopyBlackboardVariable
// Size: 0xc8 (Inherited: 0x70)
struct UFortAthenaBTService_CopyBlackboardVariable : UBTService {
	struct FBlackboardKeySelector SourceBlackboardKey; // 0x70(0x28)
	struct FBlackboardKeySelector DestinationBlackboardKey; // 0x98(0x28)
	char bCopyOnBecomeRelevant : 1; // 0xc0(0x01)
	char bCopyOnCeaseRelevant : 1; // 0xc0(0x01)
	char bCopyWhenSourceValueChange : 1; // 0xc0(0x01)
	char pad_C0_3 : 5; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class FortniteAIServer.FortAthenaBTService_Crouch
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTService_Crouch : UBTService {
	struct FName CrouchExecutionStatusName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class FortniteAIServer.FortAthenaBTService_DontForgetCurrentThreat
// Size: 0x70 (Inherited: 0x70)
struct UFortAthenaBTService_DontForgetCurrentThreat : UBTService {
};

// Class FortniteAIServer.FortAthenaBTService_Escape
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTService_Escape : UBTService {
	struct FName EscapeKeyName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FName EscapeFromStormKeyName; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// Class FortniteAIServer.FortAthenaBTService_Interact
// Size: 0x140 (Inherited: 0x70)
struct UFortAthenaBTService_Interact : UBTService {
	struct FBlackboardKeySelector InteractExecutionStatusKeySelector; // 0x70(0x28)
	struct FBlackboardKeySelector InteractContextInfoKeySelector; // 0x98(0x28)
	struct FBlackboardKeySelector InteractObjectKeySelector; // 0xc0(0x28)
	struct FBlackboardKeySelector ExecutionStatusKeySelector; // 0xe8(0x28)
	struct FBlackboardKeySelector MovementStateKeySelector; // 0x110(0x28)
	enum class EInteractionBeingAttempted InteractionBeingAttempted; // 0x138(0x01)
	bool bRequireDistanceCheck; // 0x139(0x01)
	bool bRequireBlockedCheck; // 0x13a(0x01)
	char pad_13B[0x5]; // 0x13b(0x05)
};

// Class FortniteAIServer.FortAthenaBTService_Jump
// Size: 0x88 (Inherited: 0x70)
struct UFortAthenaBTService_Jump : UBTService {
	struct FName JumpExecutionStatusName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FName CrouchExecutionStatusName; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	float JumpInputReleaseDelay; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
};

// Class FortniteAIServer.FortAthenaBTService_JetpackStrafe
// Size: 0x98 (Inherited: 0x88)
struct UFortAthenaBTService_JetpackStrafe : UFortAthenaBTService_Jump {
	struct FName JetpackStrafeExecutionStatusName; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct UFortAthenaAIBotEvasiveManeuversDigestedSkillSet* CacheEMDigestedSkillSet; // 0x90(0x08)
};

// Class FortniteAIServer.FortAthenaBTService_JumpOffBus
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTService_JumpOffBus : UBTService {
	struct FName JumpOffBusExecutionStatusName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class FortniteAIServer.FortAthenaBTService_ManageWeapon
// Size: 0xb0 (Inherited: 0x70)
struct UFortAthenaBTService_ManageWeapon : UBTService {
	struct FName WeaponFireName; // 0x70(0x04)
	struct FName WeaponTriggerMeleeName; // 0x74(0x04)
	struct FName WeaponTriggerThrowableName; // 0x78(0x04)
	struct FName WeaponReloadName; // 0x7c(0x04)
	struct FName WeaponName; // 0x80(0x04)
	struct FName WeaponTargetingName; // 0x84(0x04)
	struct FName SprintExecutionStatusName; // 0x88(0x04)
	struct FName TacticalSprintExecutionStatusName; // 0x8c(0x04)
	struct FName HealingStatusKeyName; // 0x90(0x04)
	struct FName BlockWeaponActionsKeyName; // 0x94(0x04)
	char pad_98[0x14]; // 0x98(0x14)
	bool bEndChargeOnFireStop; // 0xac(0x01)
	char pad_AD[0x3]; // 0xad(0x03)

	void ManageWeaponTargeting(struct UBehaviorTreeComponent* OwnerComp); // Function FortniteAIServer.FortAthenaBTService_ManageWeapon.ManageWeaponTargeting // (Final|Native|Protected|Const) // @ game+0xa511e90
};

// Class FortniteAIServer.FortAthenaBTService_ManageVehicleWeapon
// Size: 0xb0 (Inherited: 0xb0)
struct UFortAthenaBTService_ManageVehicleWeapon : UFortAthenaBTService_ManageWeapon {
};

// Class FortniteAIServer.FortAthenaBTService_ModulateVehicleSpeedUsingDistBetween
// Size: 0xe0 (Inherited: 0x70)
struct UFortAthenaBTService_ModulateVehicleSpeedUsingDistBetween : UBTService {
	struct FBlackboardKeySelector BlackboardKeyA; // 0x70(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x98(0x28)
	float MinDistance; // 0xc0(0x04)
	float MaxDistance; // 0xc4(0x04)
	float MinDistanceSpeed; // 0xc8(0x04)
	float MaxDistanceSpeed; // 0xcc(0x04)
	bool bCalculateAs2D; // 0xd0(0x01)
	char pad_D1[0xf]; // 0xd1(0x0f)
};

// Class FortniteAIServer.FortAthenaBTService_Patrolling
// Size: 0x90 (Inherited: 0x70)
struct UFortAthenaBTService_Patrolling : UBTService {
	struct FName PatrollingAppendDestinationKeyName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	float AcceptableRadius; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0x80(0x08)
	char bAllowPartialPath : 1; // 0x88(0x01)
	char bProjectGoalLocation : 1; // 0x88(0x01)
	char pad_88_2 : 6; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// Class FortniteAIServer.FortAthenaBTService_PauseVehicle
// Size: 0x70 (Inherited: 0x70)
struct UFortAthenaBTService_PauseVehicle : UBTService {
};

// Class FortniteAIServer.FortAthenaBTService_PickUpLoot
// Size: 0x90 (Inherited: 0x70)
struct UFortAthenaBTService_PickUpLoot : UBTService {
	struct FName LootObjectKeyName; // 0x70(0x04)
	struct FName ExecutionStatusName; // 0x74(0x04)
	struct FName InteractionExecutionStatusName; // 0x78(0x04)
	struct FName InteractionContextInfoName; // 0x7c(0x04)
	struct FName MovementStateKeyName; // 0x80(0x04)
	char pad_84[0xc]; // 0x84(0x0c)
};

// Class FortniteAIServer.FortAthenaBTService_PropagatePatrolProgressToPassengers
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTService_PropagatePatrolProgressToPassengers : UBTService {
	struct FName PatrollingAppendDestinationKeyName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class FortniteAIServer.FortAthenaBTService_Revive
// Size: 0x90 (Inherited: 0x70)
struct UFortAthenaBTService_Revive : UBTService {
	struct FName ReviveTargetKeyName; // 0x70(0x04)
	struct FName ExecutionStatusName; // 0x74(0x04)
	struct FName MoveToPathMovementStateName; // 0x78(0x04)
	struct FName InteractionExecutionStatusName; // 0x7c(0x04)
	struct FName InteractionContextInfoName; // 0x80(0x04)
	bool bDisableLeash; // 0x84(0x01)
	char pad_85[0xb]; // 0x85(0x0b)
};

// Class FortniteAIServer.FortAthenaBTService_SetBlackboardBool
// Size: 0xa0 (Inherited: 0x70)
struct UFortAthenaBTService_SetBlackboardBool : UBTService {
	struct FBlackboardKeySelector BlackboardKey; // 0x70(0x28)
	bool bBlackboardValue; // 0x98(0x01)
	enum class EBTSetBlackboardBoolExitActions ExitAction; // 0x99(0x01)
	char pad_9A[0x6]; // 0x9a(0x06)
};

// Class FortniteAIServer.FortAthenaBTService_SetExecutionStatus
// Size: 0xa0 (Inherited: 0x98)
struct UFortAthenaBTService_SetExecutionStatus : UBTService_BlackboardBase {
	enum class EExecutionStatus ExecutionStatus; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class FortniteAIServer.FortAthenaBTService_Slide
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTService_Slide : UBTService {
	struct FName SlideExecutionStatusName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)

	void OnStopSliding(struct AFortPlayerPawn* Pawn); // Function FortniteAIServer.FortAthenaBTService_Slide.OnStopSliding // (Final|Native|Private) // @ game+0xa517de0
};

// Class FortniteAIServer.FortAthenaBTService_SmartObject
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTService_SmartObject : UBTService {
	struct FName SmartObjectStatusKeyName; // 0x70(0x04)
	struct FName SmartObjectDestinationKeyName; // 0x74(0x04)
	char pad_78[0x8]; // 0x78(0x08)
};

// Class FortniteAIServer.FortAthenaBTService_Sprinting
// Size: 0xc8 (Inherited: 0x70)
struct UFortAthenaBTService_Sprinting : UBTService {
	char pad_70[0x40]; // 0x70(0x40)
	struct FName SprintExecutionStatusName; // 0xb0(0x04)
	struct FName TacticalSprintExecutionStatusName; // 0xb4(0x04)
	struct FName TacticalSprintOverridenName; // 0xb8(0x04)
	char pad_BC[0xc]; // 0xbc(0x0c)
};

// Class FortniteAIServer.FortAthenaBTService_UpdateTarget
// Size: 0x70 (Inherited: 0x70)
struct UFortAthenaBTService_UpdateTarget : UBTService {
};

// Class FortniteAIServer.FortAthenaBTService_WaitForPassengers
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTService_WaitForPassengers : UBTService {
	struct FName WaitForPassengersStatusKeyName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class FortniteAIServer.FortAthenaBTService_Zipline
// Size: 0xb8 (Inherited: 0x70)
struct UFortAthenaBTService_Zipline : UBTService {
	struct FName ZiplineTargetName; // 0x70(0x04)
	struct FName InteractionExecutionStatusName; // 0x74(0x04)
	struct FName InteractionContextInfoName; // 0x78(0x04)
	struct FName UsageExecutionStatusName; // 0x7c(0x04)
	struct FName ZiplineEntryLocationName; // 0x80(0x04)
	struct FName ZiplineExitLocationKeyName; // 0x84(0x04)
	struct FName MoveToPathMovementStateName; // 0x88(0x04)
	struct FName MoveExecutionStatusName; // 0x8c(0x04)
	struct FName FocalPointName; // 0x90(0x04)
	char pad_94[0x24]; // 0x94(0x24)
};

// Class FortniteAIServer.FortAthenaBTTask_ActivateVehicleBoost
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTTask_ActivateVehicleBoost : UBTTaskNode {
	bool bActivateBoost; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	float BoostLength; // 0x74(0x04)
	bool bIgnoreMinimumDistanceLeft; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class FortniteAIServer.FortAthenaBTTask_MoveTo
// Size: 0xc0 (Inherited: 0xb0)
struct UFortAthenaBTTask_MoveTo : UBTTask_MoveTo {
	struct FName MovementResultKeyName; // 0xb0(0x04)
	struct FName ExecutionStatusKeyName; // 0xb4(0x04)
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class FortniteAIServer.FortAthenaBTTask_BotMoveTo
// Size: 0xc8 (Inherited: 0xc0)
struct UFortAthenaBTTask_BotMoveTo : UFortAthenaBTTask_MoveTo {
	struct FName NoSmashMoveGoalActorKeyName; // 0xc0(0x04)
	char pad_C4[0x2]; // 0xc4(0x02)
	char bAllowRandomWobble : 1; // 0xc6(0x01)
	char bIsUrgentMovement : 1; // 0xc6(0x01)
	char pad_C6_2 : 6; // 0xc6(0x01)
	char pad_C7[0x1]; // 0xc7(0x01)
};

// Class FortniteAIServer.FortAthenaBTTask_BotUnstuckTeleport
// Size: 0xf0 (Inherited: 0x70)
struct UFortAthenaBTTask_BotUnstuckTeleport : UBTTaskNode {
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x70(0x48)
	struct FName CanReachDestinationKeyName; // 0xb8(0x04)
	struct FName TeleportExecutionStatusKeyName; // 0xbc(0x04)
	struct FName LastPartialPathTimeKeyName; // 0xc0(0x04)
	struct FName LastPartialPathCountKeyName; // 0xc4(0x04)
	char pad_C8[0x20]; // 0xc8(0x20)
	struct UFortAthenaAIBotUnstuckDigestedSkillSet* UnstuckSkillSet; // 0xe8(0x08)
};

// Class FortniteAIServer.FortAthenaBTTask_BotWait
// Size: 0xa0 (Inherited: 0x78)
struct UFortAthenaBTTask_BotWait : UBTTask_Wait {
	struct FBlackboardKeySelector WaitCompleteKeySelector; // 0x78(0x28)
};

// Class FortniteAIServer.FortAthenaBTTask_Build
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTTask_Build : UBTTaskNode {
	struct FName ExecutionStatusKeyName; // 0x70(0x04)
	struct FName FocalPointName; // 0x74(0x04)
	char pad_78[0x8]; // 0x78(0x08)
};

// Class FortniteAIServer.FortAthenaBTTask_Conversation
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTTask_Conversation : UBTTaskNode {
	struct FName ConversationStatusKeyName; // 0x70(0x04)
	char pad_74[0x2]; // 0x74(0x02)
	bool bResetEvaluatorStatusKeyOnFinish; // 0x76(0x01)
	char pad_77[0x1]; // 0x77(0x01)
};

// Class FortniteAIServer.FortAthenaBTTask_Dive
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTTask_Dive : UBTTaskNode {
	struct FName ExecutionStatusKeyName; // 0x70(0x04)
	struct FName DiveDestinationKeyName; // 0x74(0x04)
	char pad_78[0x8]; // 0x78(0x08)
};

// Class FortniteAIServer.FortAthenaBTTask_EnterVehicle
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTTask_EnterVehicle : UBTTaskNode {
	struct FName SelectedVehicleKeyName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class FortniteAIServer.FortAthenaBTTask_Glide
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTTask_Glide : UBTTaskNode {
	struct FName ExecutionStatusKeyName; // 0x70(0x04)
	struct FName GlideDestinationKeyName; // 0x74(0x04)
	char pad_78[0x8]; // 0x78(0x08)
};

// Class FortniteAIServer.FortAthenaBTTask_Interact
// Size: 0xe8 (Inherited: 0x70)
struct UFortAthenaBTTask_Interact : UBTTaskNode {
	float AttemptInterval; // 0x70(0x04)
	int32_t MaxInteractAttempts; // 0x74(0x04)
	bool bShouldFocusOnInteraction; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct FBlackboardKeySelector InteractExecutionStatusKeySelector; // 0x80(0x28)
	struct FBlackboardKeySelector InteractContextInfoKeySelector; // 0xa8(0x28)
	struct FName FocalPointName; // 0xd0(0x04)
	struct FName InteractActorName; // 0xd4(0x04)
	struct FName JumpExecutionStatusName; // 0xd8(0x04)
	struct FName WeaponTriggerMeleeName; // 0xdc(0x04)
	char pad_E0[0x8]; // 0xe0(0x08)
};

// Class FortniteAIServer.FortAthenaBTTask_LeaveVehicle
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTTask_LeaveVehicle : UBTTaskNode {
	bool bWaitVehicleStop; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAIServer.FortAthenaBTTask_ModulateVehicleSpeed
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTTask_ModulateVehicleSpeed : UBTTaskNode {
	float NewDrivingSpeed; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class FortniteAIServer.FortAthenaBTTask_PauseVehicle
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTTask_PauseVehicle : UBTTaskNode {
	bool bPausePathFollow; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAIServer.FortAthenaBTTask_PlayEmote
// Size: 0x88 (Inherited: 0x70)
struct UFortAthenaBTTask_PlayEmote : UBTTaskNode {
	struct FName PlayEmoteExecutionStatusKeyName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct TArray<struct UAthenaDanceItemDefinition*> BespokeEmotes; // 0x78(0x10)
};

// Class FortniteAIServer.FortAthenaBTTask_ReverseVehicle
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTTask_ReverseVehicle : UBTTaskNode {
	bool bReverseVehicle; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAIServer.FortAthenaBTTask_RunDynamicSubtree
// Size: 0x90 (Inherited: 0x88)
struct UFortAthenaBTTask_RunDynamicSubtree : UBTTask_RunBehaviorDynamic {
	char bCallParentOnInstanceCreated : 1; // 0x88(0x01)
	char bUpdateBlackboardAsset : 1; // 0x88(0x01)
	char pad_88_2 : 6; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// Class FortniteAIServer.FortAthenaBTTask_SetAggressiveDriving
// Size: 0x78 (Inherited: 0x70)
struct UFortAthenaBTTask_SetAggressiveDriving : UBTTaskNode {
	bool bAggressiveDriving; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAIServer.FortAthenaBTTask_ShootTrap
// Size: 0xa8 (Inherited: 0x78)
struct UFortAthenaBTTask_ShootTrap : UBTTask_Wait {
	struct FBlackboardKeySelector TargetActorKey; // 0x78(0x28)
	struct FName TrapOnPathKeyName; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
};

// Class FortniteAIServer.FortAthenaBTTask_SteerMovement
// Size: 0xa0 (Inherited: 0x70)
struct UFortAthenaBTTask_SteerMovement : UBTTaskNode {
	struct FBlackboardKeySelector SteerDirectionKeySelector; // 0x70(0x28)
	char bSetControlRotation : 1; // 0x98(0x01)
	char pad_98_1 : 7; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class FortniteAIServer.FortAthenaBTTask_Undermine
// Size: 0x88 (Inherited: 0x70)
struct UFortAthenaBTTask_Undermine : UBTTaskNode {
	struct FName UndermineTargetKeyName; // 0x70(0x04)
	struct FName UndermineLocationImpactName; // 0x74(0x04)
	struct FName UndermineExecutionStatusKeyName; // 0x78(0x04)
	char pad_7C[0xc]; // 0x7c(0x0c)
};

// Class FortniteAIServer.FortAthenaBTTask_UseItem
// Size: 0x88 (Inherited: 0x70)
struct UFortAthenaBTTask_UseItem : UBTTaskNode {
	struct FName ActionObjectKeyName; // 0x70(0x04)
	struct FName ExecutionStatusKeyName; // 0x74(0x04)
	float MinWaitTimeBetweenUses; // 0x78(0x04)
	float MaxWaitTimeBetweenUses; // 0x7c(0x04)
	bool bValidateAbility; // 0x80(0x01)
	bool bResetActionObjectKey; // 0x81(0x01)
	bool bUseAlternateMode; // 0x82(0x01)
	char pad_83[0x5]; // 0x83(0x05)
};

// Class FortniteAIServer.FortAthenaBTTask_UseSmartObject
// Size: 0x110 (Inherited: 0x70)
struct UFortAthenaBTTask_UseSmartObject : UBTTaskNode {
	struct FName SmartObjectsStatusKeyName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FName SmartObjectDestinationRotationKeyName; // 0x78(0x04)
	char pad_7C[0x2]; // 0x7c(0x02)
	bool bHandleAbortWithSoftDisable; // 0x7e(0x01)
	char pad_7F[0x29]; // 0x7f(0x29)
	struct FGameplayInteractionContext GameplayInteractionContext; // 0xa8(0x68)
};

// Class FortniteAIServer.FortAthenaBTTask_VehicleHonk
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTTask_VehicleHonk : UBTTaskNode {
	float MaxHonkTime; // 0x70(0x04)
	float MinHonkTime; // 0x74(0x04)
	float MaxFlickerTime; // 0x78(0x04)
	float MinFlickerTime; // 0x7c(0x04)
};

// Class FortniteAIServer.FortAthenaBTTask_VehicleTurnTo
// Size: 0xa0 (Inherited: 0x98)
struct UFortAthenaBTTask_VehicleTurnTo : UBTTask_BlackboardBase {
	float Precision; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class FortniteAIServer.FortAthenaBTTask_VerseNPCMoveTo
// Size: 0xd8 (Inherited: 0xc0)
struct UFortAthenaBTTask_VerseNPCMoveTo : UFortAthenaBTTask_MoveTo {
	struct FName AcceptableRadiusKeyName; // 0xc0(0x04)
	struct FName AllowStrafeKeyName; // 0xc4(0x04)
	struct FName AllowPartialPathName; // 0xc8(0x04)
	char pad_CC[0xc]; // 0xcc(0x0c)
};

// Class FortniteAIServer.FortAthenaBTTask_Zipline
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTTask_Zipline : UBTTaskNode {
	struct FName UsageExecutionStatusName; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FName ZiplineTargetName; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)

	void OnZiplineStateChanged(bool bIsZiplining, struct AFortPlayerPawn* FortPlayerPawn); // Function FortniteAIServer.FortAthenaBTTask_Zipline.OnZiplineStateChanged // (Final|Native|Public) // @ game+0xa52d120
};

// Class FortniteAIServer.FortAthenaNpcEvaluator_Encampment
// Size: 0x450 (Inherited: 0x1a8)
struct UFortAthenaNpcEvaluator_Encampment : UFortAthenaAIBotEvaluator_Movement {
	struct FScalableFloat EncampmentEnable; // 0x1a8(0x28)
	struct FScalableFloat EncampmentTentativeDelayMin; // 0x1d0(0x28)
	struct FScalableFloat EncampmentTentativeDelayMax; // 0x1f8(0x28)
	struct FScalableFloat EncampmentDurationMin; // 0x220(0x28)
	struct FScalableFloat EncampmentDurationMax; // 0x248(0x28)
	struct FScalableFloat BuilderPercentage; // 0x270(0x28)
	struct FScalableFloat BuilderMinDistance; // 0x298(0x28)
	struct FScalableFloat BuilderMaxDistance; // 0x2c0(0x28)
	struct FScalableFloat GuardMinDistance; // 0x2e8(0x28)
	struct FScalableFloat GuardMaxDistance; // 0x310(0x28)
	struct FScalableFloat AllowInSwimming; // 0x338(0x28)
	struct FScalableFloat AllowInFalling; // 0x360(0x28)
	struct FScalableFloat MinSquadMembersCountToBuild; // 0x388(0x28)
	struct FName EncampmentStatusKeyName; // 0x3b0(0x04)
	char pad_3B4[0x4]; // 0x3b4(0x04)
	struct FName EncampmentMovementStateKeyName; // 0x3b8(0x04)
	char pad_3BC[0x4]; // 0x3bc(0x04)
	struct FName EncampmentCenterLocationKeyName; // 0x3c0(0x04)
	char pad_3C4[0x4]; // 0x3c4(0x04)
	struct FName EncampmentDestinationKeyName; // 0x3c8(0x04)
	char pad_3CC[0x4]; // 0x3cc(0x04)
	struct FName EncampmentAroundCampFireLocationKeyName; // 0x3d0(0x04)
	char pad_3D4[0x4]; // 0x3d4(0x04)
	struct FName EncampmentRoleKeyName; // 0x3d8(0x04)
	char pad_3DC[0x4]; // 0x3dc(0x04)
	struct FName DefensiveBuildName; // 0x3e0(0x04)
	char pad_3E4[0x6c]; // 0x3e4(0x6c)
};

// Class FortniteAIServer.FortAthenaNpcEvaluator_FollowPatrolPath
// Size: 0x1e0 (Inherited: 0x1a8)
struct UFortAthenaNpcEvaluator_FollowPatrolPath : UFortAthenaAIBotEvaluator_Movement {
	struct FName FollowPatrolPathKeyName; // 0x1a8(0x04)
	struct FName FollowPatrolPathMovementStateKeyName; // 0x1ac(0x04)
	struct FName FollowPatrolPathDestinationKeyName; // 0x1b0(0x04)
	char pad_1B4[0x8]; // 0x1b4(0x08)
	float ChanceToTakeABreak; // 0x1bc(0x04)
	float BreakDurationMin; // 0x1c0(0x04)
	float BreakDurationMax; // 0x1c4(0x04)
	char pad_1C8[0x18]; // 0x1c8(0x18)
};

// Class FortniteAIServer.FortAthenaNpcEvaluator_FollowSquadLeader
// Size: 0x2f8 (Inherited: 0x1a8)
struct UFortAthenaNpcEvaluator_FollowSquadLeader : UFortAthenaAIBotEvaluator_Movement {
	struct FScalableFloat FormationOffsetRadiusMin; // 0x1a8(0x28)
	struct FScalableFloat FormationOffsetRadiusMax; // 0x1d0(0x28)
	struct FScalableFloat TooFarFromSquadLeaderDistance; // 0x1f8(0x28)
	struct FScalableFloat MaxNoiseRadius; // 0x220(0x28)
	struct FScalableFloat MinDurationNoiseEvaluate; // 0x248(0x28)
	struct FScalableFloat MaxDurationNoiseEvaluate; // 0x270(0x28)
	struct FName FollowSquadLeaderStatusKeyName; // 0x298(0x04)
	char pad_29C[0x4]; // 0x29c(0x04)
	struct FName FollowSquadLeaderMovementStateKeyName; // 0x2a0(0x04)
	char pad_2A4[0x4]; // 0x2a4(0x04)
	struct FName FollowSquadLeaderDestinationKeyName; // 0x2a8(0x04)
	char pad_2AC[0x4]; // 0x2ac(0x04)
	struct FName TooFarFromLeaderKeyName; // 0x2b0(0x04)
	char pad_2B4[0x4]; // 0x2b4(0x04)
	struct FVector CachedSquadFormationOffset; // 0x2b8(0x18)
	struct FVector CachedNoiseOffset; // 0x2d0(0x18)
	float CachedTooFarFromSquadLeaderDistanceSqr; // 0x2e8(0x04)
	float LastNoiseOffsetUpdateTime; // 0x2ec(0x04)
	float DurationNoiseEvaluate; // 0x2f0(0x04)
	char pad_2F4[0x4]; // 0x2f4(0x04)
};

// Class FortniteAIServer.FortAthenaNpcEvaluator_Leash
// Size: 0x1e8 (Inherited: 0x1a8)
struct UFortAthenaNpcEvaluator_Leash : UFortAthenaAIBotEvaluator_Movement {
	struct FName LeashKeyName; // 0x1a8(0x04)
	struct FName LeashMovementStateKeyName; // 0x1ac(0x04)
	struct FName LeashDestinationKeyName; // 0x1b0(0x04)
	struct FName LeashLocationKeyName; // 0x1b4(0x04)
	struct FName LeashOuterRadiusKeyName; // 0x1b8(0x04)
	struct FName ShouldTeleportInLeashKeyName; // 0x1bc(0x04)
	bool bAlwaysForceMoveToLeashCenter; // 0x1c0(0x01)
	char pad_1C1[0x7]; // 0x1c1(0x07)
	struct UNavigationQueryFilter* AvoidObstaclesFilterClass; // 0x1c8(0x08)
	char pad_1D0[0x10]; // 0x1d0(0x10)
	struct UFortAthenaAIRuntimeParameters_Leash* LeashRuntimeParameters; // 0x1e0(0x08)
};

// Class FortniteAIServer.FortAthenaNpcEvaluator_Patrolling
// Size: 0x1f8 (Inherited: 0x1a8)
struct UFortAthenaNpcEvaluator_Patrolling : UFortAthenaAIBotEvaluator_Movement {
	struct FName PatrollingKeyName; // 0x1a8(0x04)
	struct FName PatrollingMovementStateKeyName; // 0x1ac(0x04)
	struct FName PatrollingDestinationKeyName; // 0x1b0(0x04)
	struct FName DynamicBlueprintStatusKeyName; // 0x1b4(0x04)
	struct FName DynamicBlueprintActorKeyName; // 0x1b8(0x04)
	struct FName PatrollingShouldMoveKeyName; // 0x1bc(0x04)
	struct FName PatrollingAppendDestinationKeyName; // 0x1c0(0x04)
	char pad_1C4[0x10]; // 0x1c4(0x10)
	float DistanceToTestPoint; // 0x1d4(0x04)
	bool bCanDisablePatrolling; // 0x1d8(0x01)
	bool bCanReenablePatrolling; // 0x1d9(0x01)
	char pad_1DA[0x2]; // 0x1da(0x02)
	float ReenableTimer; // 0x1dc(0x04)
	bool bCanSelectNearestPatrolPointAtStart; // 0x1e0(0x01)
	char pad_1E1[0x7]; // 0x1e1(0x07)
	struct UFortAthenaNpcPatrollingComponent* CachedNpcPatrollingComponent; // 0x1e8(0x08)
	char pad_1F0[0x8]; // 0x1f0(0x08)
};

// Class FortniteAIServer.FortQueryContext_BotPOIVolume
// Size: 0x48 (Inherited: 0x28)
struct UFortQueryContext_BotPOIVolume : UEnvQueryContext {
	bool bSetProjectedToNavmeshLocationAsContext; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FVector ProjectionExtent; // 0x30(0x18)
};

// Class FortniteAIServer.FortAthenaAttachToActorStateTreeTask
// Size: 0x90 (Inherited: 0x48)
struct UFortAthenaAttachToActorStateTreeTask : UStateTreeTaskBlueprintBase {
	struct AActor* Actor; // 0x48(0x08)
	struct AActor* TargetActor; // 0x50(0x08)
	enum class EFortAthenaStateTreeTaskFeatureExecutionMode AttachExecutionMode; // 0x58(0x04)
	bool bHandleAthenaMovComponent; // 0x5c(0x01)
	bool bSetPhysicsToQueryOnlyWhileAttached; // 0x5d(0x01)
	bool bTryToAttachToSkeletalMeshOnTargetActor; // 0x5e(0x01)
	bool bChangeBaseToSkeletalMeshOnTargetActor; // 0x5f(0x01)
	enum class EAttachmentRule AttachmentLocationRule; // 0x60(0x01)
	enum class EAttachmentRule AttachmentRotationRule; // 0x61(0x01)
	enum class EAttachmentRule AttachmentScaleRule; // 0x62(0x01)
	bool bWeldSimulatedBodiesOnAttach; // 0x63(0x01)
	struct FName AttachmentSocketName; // 0x64(0x04)
	enum class EFortAthenaStateTreeTaskFeatureExecutionMode DetachExecutionMode; // 0x68(0x04)
	bool bForceChangeBaseOnDetach; // 0x6c(0x01)
	enum class EDetachmentRule DetachmentLocationRule; // 0x6d(0x01)
	enum class EDetachmentRule DetachmentRotationRule; // 0x6e(0x01)
	enum class EDetachmentRule DetachmentScaleRule; // 0x6f(0x01)
	bool bCallModifyOnDetach; // 0x70(0x01)
	bool bHandleLaunchCharacter; // 0x71(0x01)
	bool bHasHandledLaunchCharacter; // 0x72(0x01)
	char pad_73[0x5]; // 0x73(0x05)
	struct AFortPawn* FortPawnActor; // 0x78(0x08)
	char pad_80[0x10]; // 0x80(0x10)
};

// Class FortniteAIServer.FortAthenaPlayContextualAnimTaskInstanceData
// Size: 0x100 (Inherited: 0x28)
struct UFortAthenaPlayContextualAnimTaskInstanceData : UObject {
	struct AActor* PrimaryActor; // 0x28(0x08)
	struct AActor* SecondaryActor; // 0x30(0x08)
	struct FName SecondaryRole; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct AActor* TertiaryActor; // 0x40(0x08)
	struct FName TertiaryRole; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct UContextualAnimSceneAsset* SceneAsset; // 0x50(0x08)
	struct FName SectionName; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FGameplayTagContainer PrimaryActorExternalTags; // 0x60(0x20)
	struct FGameplayTagContainer SecondaryActorExternalTags; // 0x80(0x20)
	struct FGameplayTagContainer TertiaryActorExternalTags; // 0xa0(0x20)
	enum class EFortAthenaPlayContextualAnimExecutionMethod ExecutionMethod; // 0xc0(0x01)
	bool bWaitForNotifyEventToEnd; // 0xc1(0x01)
	char pad_C2[0x2]; // 0xc2(0x02)
	struct FName NotifyEventNameToEnd; // 0xc4(0x04)
	int32_t LoopsToRun; // 0xc8(0x04)
	bool bLoopForever; // 0xcc(0x01)
	char pad_CD[0x3]; // 0xcd(0x03)
	float DelayBetweenLoops; // 0xd0(0x04)
	float RandomDeviationBetweenLoops; // 0xd4(0x04)
	struct TArray<struct FContextualAnimWarpTarget> WarpTargets; // 0xd8(0x10)
	char pad_E8[0x18]; // 0xe8(0x18)

	void OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // Function FortniteAIServer.FortAthenaPlayContextualAnimTaskInstanceData.OnNotifyBeginReceived // (Final|Native|Public|HasOutParms) // @ game+0xa53c910
	void OnMontageEnded(struct UAnimMontage* EndedMontage, bool bInterrupted); // Function FortniteAIServer.FortAthenaPlayContextualAnimTaskInstanceData.OnMontageEnded // (Final|Native|Public) // @ game+0xa53cab0
};

// Class FortniteAIServer.FortAthenaPlayInteractionStateTreeTask
// Size: 0xc8 (Inherited: 0x48)
struct UFortAthenaPlayInteractionStateTreeTask : UStateTreeTaskBlueprintBase {
	struct AActor* InteractorActor; // 0x48(0x08)
	struct AActor* InteractableActor; // 0x50(0x08)
	struct UAnimMontage* InteractorMontage; // 0x58(0x08)
	struct UAnimMontage* InteractableMontage; // 0x60(0x08)
	bool bWaitForNotifyEventToEnd; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	struct FName NotifyEventNameToEnd; // 0x6c(0x04)
	bool bAddMotionWarpingTargets; // 0x70(0x01)
	bool bDisableCollisionBetweenActors; // 0x71(0x01)
	bool bSetMovementModeToFlying; // 0x72(0x01)
	char pad_73[0x1]; // 0x73(0x01)
	int32_t LoopsToRun; // 0x74(0x04)
	bool bLoopForever; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	float DelayBetweenLoops; // 0x7c(0x04)
	float RandomDeviationBetweenLoops; // 0x80(0x04)
	bool bStopInteractorAnimMontageOnExit; // 0x84(0x01)
	bool bStopInteractableAnimMontageOnExit; // 0x85(0x01)
	char pad_86[0x42]; // 0x86(0x42)

	void OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // Function FortniteAIServer.FortAthenaPlayInteractionStateTreeTask.OnNotifyBeginReceived // (Final|Native|Private|HasOutParms) // @ game+0xa53ef00
	void OnMontageEnded(struct UAnimMontage* EndedMontage, bool bInterrupted); // Function FortniteAIServer.FortAthenaPlayInteractionStateTreeTask.OnMontageEnded // (Final|Native|Private) // @ game+0xa53f0a0
};

// Class FortniteAIServer.FortAthenaPlayMontageStateTreeTask
// Size: 0x90 (Inherited: 0x48)
struct UFortAthenaPlayMontageStateTreeTask : UStateTreeTaskBlueprintBase {
	struct AActor* Actor; // 0x48(0x08)
	struct UAnimMontage* Montage; // 0x50(0x08)
	bool bWaitForNotifyEventToEnd; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	struct FName NotifyEventNameToEnd; // 0x5c(0x04)
	bool bSetMovementModeToFlying; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	int32_t LoopsToRun; // 0x64(0x04)
	bool bLoopForever; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	float DelayBetweenLoops; // 0x6c(0x04)
	float RandomDeviationBetweenLoops; // 0x70(0x04)
	bool bStopAnimMontageOnExit; // 0x74(0x01)
	char pad_75[0x1b]; // 0x75(0x1b)

	void HandleNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // Function FortniteAIServer.FortAthenaPlayMontageStateTreeTask.HandleNotifyBeginReceived // (Final|Native|Private|HasOutParms) // @ game+0xa542170
	void HandleMontageEnded(struct UAnimMontage* EndedMontage, bool bInterrupted); // Function FortniteAIServer.FortAthenaPlayMontageStateTreeTask.HandleMontageEnded // (Final|Native|Private) // @ game+0xa542340
};

