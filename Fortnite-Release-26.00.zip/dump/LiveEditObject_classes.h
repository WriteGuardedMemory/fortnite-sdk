// Class LiveEditObject.LiveEditNetworkStreamChannel
// Size: 0x68 (Inherited: 0x68)
struct ULiveEditNetworkStreamChannel : UChannel {
};

// Class LiveEditObject.LiveEditLargeNetworkMessageChannel
// Size: 0xb0 (Inherited: 0x68)
struct ULiveEditLargeNetworkMessageChannel : ULiveEditNetworkStreamChannel {
	char pad_68[0x48]; // 0x68(0x48)
};

// Class LiveEditObject.LiveEditObjectChannel
// Size: 0x1a8 (Inherited: 0xb0)
struct ULiveEditObjectChannel : ULiveEditLargeNetworkMessageChannel {
	char pad_B0[0xf8]; // 0xb0(0xf8)
};

// Class LiveEditObject.LiveEditObjectConnection
// Size: 0x3a0 (Inherited: 0x28)
struct ULiveEditObjectConnection : UObject {
	char pad_28[0x378]; // 0x28(0x378)
};

// Class LiveEditObject.LiveEditObjectSubsystemState
// Size: 0x278 (Inherited: 0x28)
struct ULiveEditObjectSubsystemState : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct TArray<struct ULiveEditObjectConnection*> Connections; // 0x38(0x10)
	char pad_48[0x230]; // 0x48(0x230)
};

// Class LiveEditObject.LiveEditObjectSubsystem
// Size: 0x178 (Inherited: 0x30)
struct ULiveEditObjectSubsystem : UEngineSubsystem {
	char pad_30[0x8]; // 0x30(0x08)
	int32_t MaxBytesQueuedForReplication; // 0x38(0x04)
	int32_t NumPackageMapBunchesToDelayTickFor; // 0x3c(0x04)
	struct TArray<struct ULiveEditObjectSubsystemState*> NetDriverStates; // 0x40(0x10)
	char pad_50[0x128]; // 0x50(0x128)
};

// Class LiveEditObject.LiveEditObjectTestObject
// Size: 0x180 (Inherited: 0x28)
struct ULiveEditObjectTestObject : UObject {
	int32_t int32[0x3]; // 0x28(0x0c)
	char pad_34[0x4]; // 0x34(0x04)
	struct FLiveEditObjectTestStruct StructProperty; // 0x38(0x148)
};

