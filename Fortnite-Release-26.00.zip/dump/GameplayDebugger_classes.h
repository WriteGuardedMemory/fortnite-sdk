// Class GameplayDebugger.GameplayDebuggerCategoryReplicator
// Size: 0x348 (Inherited: 0x290)
struct AGameplayDebuggerCategoryReplicator : AActor {
	struct APlayerController* OwnerPC; // 0x290(0x08)
	bool bIsEnabled; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
	struct FGameplayDebuggerNetPack ReplicatedData; // 0x2a0(0x18)
	struct FGameplayDebuggerDebugActor DebugActor; // 0x2b8(0x10)
	struct FGameplayDebuggerVisLogSync VisLogSync; // 0x2c8(0x10)
	struct UGameplayDebuggerRenderingComponent* RenderingComp; // 0x2d8(0x08)
	char pad_2E0[0x68]; // 0x2e0(0x68)

	void ServerSetViewPoint(struct FVector InViewLocation, struct FVector InViewDirection); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSetViewPoint // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|HasDefaults|NetValidate) // @ game+0x4f66440
	void ServerSetEnabled(bool bEnable); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSetEnabled // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4f667c0
	void ServerSetDebugActor(struct AActor* Actor, bool bSelectInEditor); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSetDebugActor // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4f66600
	void ServerSetCategoryEnabled(int32_t CategoryId, bool bEnable); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSetCategoryEnabled // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4f66220
	void ServerSendExtensionInputEvent(int32_t ExtensionId, int32_t HandlerId); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSendExtensionInputEvent // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4f65ea0
	void ServerSendCategoryInputEvent(int32_t CategoryId, int32_t HandlerId); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSendCategoryInputEvent // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4f66060
	void ServerResetViewPoint(); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerResetViewPoint // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4f663e0
	void OnRep_ReplicatedData(); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.OnRep_ReplicatedData // (Final|RequiredAPI|Native|Protected) // @ game+0x4f668e0
	void ClientDataPackPacket(struct FGameplayDebuggerDataPackRPCParams Params); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ClientDataPackPacket // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x4f65d70
};

// Class GameplayDebugger.GameplayDebuggerConfig
// Size: 0x258 (Inherited: 0x28)
struct UGameplayDebuggerConfig : UObject {
	struct FKey ActivationKey; // 0x28(0x18)
	struct FKey CategoryRowNextKey; // 0x40(0x18)
	struct FKey CategoryRowPrevKey; // 0x58(0x18)
	struct FKey CategorySlot0; // 0x70(0x18)
	struct FKey CategorySlot1; // 0x88(0x18)
	struct FKey CategorySlot2; // 0xa0(0x18)
	struct FKey CategorySlot3; // 0xb8(0x18)
	struct FKey CategorySlot4; // 0xd0(0x18)
	struct FKey CategorySlot5; // 0xe8(0x18)
	struct FKey CategorySlot6; // 0x100(0x18)
	struct FKey CategorySlot7; // 0x118(0x18)
	struct FKey CategorySlot8; // 0x130(0x18)
	struct FKey CategorySlot9; // 0x148(0x18)
	float DebugCanvasPaddingLeft; // 0x160(0x04)
	float DebugCanvasPaddingRight; // 0x164(0x04)
	float DebugCanvasPaddingTop; // 0x168(0x04)
	float DebugCanvasPaddingBottom; // 0x16c(0x04)
	bool bDebugCanvasEnableTextShadow; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
	struct TArray<struct FGameplayDebuggerCategoryConfig> Categories; // 0x178(0x10)
	struct TArray<struct FGameplayDebuggerExtensionConfig> Extensions; // 0x188(0x10)
	char pad_198[0xc0]; // 0x198(0xc0)
};

// Class GameplayDebugger.GameplayDebuggerUserSettings
// Size: 0x40 (Inherited: 0x30)
struct UGameplayDebuggerUserSettings : UDeveloperSettings {
	char bEnableGameplayDebuggerInEditor : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float MaxViewDistance; // 0x34(0x04)
	float MaxViewAngle; // 0x38(0x04)
	int32_t FontSize; // 0x3c(0x04)
};

// Class GameplayDebugger.GameplayDebuggerLocalController
// Size: 0x88 (Inherited: 0x28)
struct UGameplayDebuggerLocalController : UObject {
	struct AGameplayDebuggerCategoryReplicator* CachedReplicator; // 0x28(0x08)
	struct AGameplayDebuggerPlayerManager* CachedPlayerManager; // 0x30(0x08)
	struct AActor* DebugActorCandidate; // 0x38(0x08)
	struct UFont* HUDFont; // 0x40(0x08)
	char pad_48[0x40]; // 0x48(0x40)
};

// Class GameplayDebugger.GameplayDebuggerPlayerManager
// Size: 0x2c0 (Inherited: 0x290)
struct AGameplayDebuggerPlayerManager : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct TArray<struct FGameplayDebuggerPlayerData> PlayerData; // 0x298(0x10)
	struct TArray<struct AGameplayDebuggerCategoryReplicator*> PendingRegistrations; // 0x2a8(0x10)
	char pad_2B8[0x8]; // 0x2b8(0x08)
};

// Class GameplayDebugger.GameplayDebuggerRenderingComponent
// Size: 0x620 (Inherited: 0x5c0)
struct UGameplayDebuggerRenderingComponent : UDebugDrawComponent {
	char pad_5C0[0x60]; // 0x5c0(0x60)
};

