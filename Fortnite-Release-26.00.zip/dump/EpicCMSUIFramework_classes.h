// Class EpicCMSUIFramework.EpicCMSImage
// Size: 0x4a0 (Inherited: 0x3b0)
struct UEpicCMSImage : UCommonLazyImage {
	struct FMulticastInlineDelegate OnImageLoadingComplete; // 0x3b0(0x10)
	bool bMatchImageSize; // 0x3c0(0x01)
	char pad_3C1[0xf]; // 0x3c1(0x0f)
	struct FSlateBrush LoadingFailFallback; // 0x3d0(0xc0)
	struct UTexture2D* ExternalMedia; // 0x490(0x08)
	bool bDownloadingExternalMedia; // 0x498(0x01)
	char pad_499[0x7]; // 0x499(0x07)

	void SetMediaURL(struct FString MediaUrl); // Function EpicCMSUIFramework.EpicCMSImage.SetMediaURL // (Final|Native|Public|BlueprintCallable) // @ game+0x5f681b0
};

// Class EpicCMSUIFramework.EpicCMSLayoutBase
// Size: 0x310 (Inherited: 0x2a8)
struct UEpicCMSLayoutBase : UUserWidget {
	struct TArray<struct FSlotDescription> CarouselSlotDescriptions; // 0x2a8(0x10)
	struct UEpicCMSTileCarousel* CarouselClass; // 0x2b8(0x08)
	char pad_2C0[0x50]; // 0x2c0(0x50)
};

// Class EpicCMSUIFramework.EpicCMSManager
// Size: 0xb0 (Inherited: 0x28)
struct UEpicCMSManager : UObject {
	char pad_28[0x88]; // 0x28(0x88)
};

// Class EpicCMSUIFramework.EpicCMSScreenBase
// Size: 0x598 (Inherited: 0x520)
struct UEpicCMSScreenBase : UCommonActivatablePanelLegacy {
	struct FString TileSetFieldName; // 0x520(0x10)
	struct TSoftObjectPtr<UDataTable> TileTypeToTileClassDataTable; // 0x530(0x20)
	struct TSoftClassPtr<UObject> LayoutErrorClass; // 0x550(0x20)
	struct TSoftObjectPtr<UDataTable> LayoutTypeToLayoutClassDataTable; // 0x570(0x20)
	char pad_590[0x8]; // 0x590(0x08)
};

// Class EpicCMSUIFramework.EpicCMSSimpleMessage
// Size: 0x2e8 (Inherited: 0x2d0)
struct UEpicCMSSimpleMessage : UCommonUserWidget {
	struct UCommonTextBlock* TitleText; // 0x2d0(0x08)
	struct UCommonTextBlock* BodyText; // 0x2d8(0x08)
	struct UEpicCMSImage* PrimaryImage; // 0x2e0(0x08)
};

// Class EpicCMSUIFramework.EpicCMSTileBase
// Size: 0x15d0 (Inherited: 0x14c0)
struct UEpicCMSTileBase : UCommonButtonLegacy {
	char pad_14C0[0x8]; // 0x14c0(0x08)
	struct UCommonTextStyle* DefaultTitleTextStyle; // 0x14c8(0x08)
	struct UCommonTextStyle* FeaturedTitleTextStyle; // 0x14d0(0x08)
	struct FText Title; // 0x14d8(0x18)
	struct FString Link; // 0x14f0(0x10)
	bool bDownloadingExternalMedia; // 0x1500(0x01)
	bool bRefreshingMcpCatalog; // 0x1501(0x01)
	char pad_1502[0x6]; // 0x1502(0x06)
	struct UTexture2D* ExternalMedia; // 0x1508(0x08)
	char pad_1510[0x18]; // 0x1510(0x18)
	struct UCommonLazyImage* LazyImage_Icon; // 0x1528(0x08)
	struct UCommonTextBlock* TitleTextBlock; // 0x1530(0x08)
	struct UCommonTextBlock* SubtitleTextBlock; // 0x1538(0x08)
	struct UCommonTextBlock* EyebrowTextBlock; // 0x1540(0x08)
	char pad_1548[0x88]; // 0x1548(0x88)

	void Launch(); // Function EpicCMSUIFramework.EpicCMSTileBase.Launch // (Final|Native|Protected|BlueprintCallable) // @ game+0x5f6da50
};

// Class EpicCMSUIFramework.EpicCMSTileCarousel
// Size: 0x2f8 (Inherited: 0x2a8)
struct UEpicCMSTileCarousel : UUserWidget {
	struct FSlateSound PreviousButtonSound; // 0x2a8(0x18)
	struct FSlateSound NextButtonSound; // 0x2c0(0x18)
	struct UCommonWidgetCarousel* Carousel; // 0x2d8(0x08)
	struct UWidget* NextPageButton; // 0x2e0(0x08)
	struct UWidget* PreviousPageButton; // 0x2e8(0x08)
	bool bShouldShowNavigationOnlyOnHover; // 0x2f0(0x01)
	bool bInputActionsForPaging; // 0x2f1(0x01)
	bool bIsShowingNavigation; // 0x2f2(0x01)
	char pad_2F3[0x5]; // 0x2f3(0x05)

	void SetCurrentPageByIndex(int32_t PageIndex); // Function EpicCMSUIFramework.EpicCMSTileCarousel.SetCurrentPageByIndex // (Final|Native|Protected|BlueprintCallable) // @ game+0x5f6e830
	void PreviousPage(); // Function EpicCMSUIFramework.EpicCMSTileCarousel.PreviousPage // (Final|Native|Protected|BlueprintCallable) // @ game+0x5f6e810
	void NextPage(); // Function EpicCMSUIFramework.EpicCMSTileCarousel.NextPage // (Final|Native|Protected|BlueprintCallable) // @ game+0x5f6e7f0
	void NavigationVisibilityChanged(bool bShowNavigation); // Function EpicCMSUIFramework.EpicCMSTileCarousel.NavigationVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandleTilePageAdded(struct UWidget* TileWidget); // Function EpicCMSUIFramework.EpicCMSTileCarousel.HandleTilePageAdded // (Native|Event|Protected|BlueprintEvent) // @ game+0x5f6e970
	int32_t GetCurrentPageIndex(); // Function EpicCMSUIFramework.EpicCMSTileCarousel.GetCurrentPageIndex // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f6e930
	void BeginAutoScrolling(); // Function EpicCMSUIFramework.EpicCMSTileCarousel.BeginAutoScrolling // (Final|Native|Public|BlueprintCallable) // @ game+0x5f6ea60
	void AddTilePage(struct UWidget* TilePageWidget); // Function EpicCMSUIFramework.EpicCMSTileCarousel.AddTilePage // (Final|Native|Public|BlueprintCallable) // @ game+0x5f6eaa0
};

