// Class LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler
// Size: 0x348 (Inherited: 0x290)
struct AFortAthenaLivingWorldPointProvidersEnabler : AActor {
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> EnabledLinkedPointProviders; // 0x290(0x10)
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> AvailableLinkedPointProviders; // 0x2a0(0x10)
	struct FGameplayTagContainer EnablerTags; // 0x2b0(0x20)
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> LinkedPointProviders; // 0x2d0(0x10)
	struct FScalableFloat PointProvidersToEnable; // 0x2e0(0x28)
	struct FScalableFloat EvaluateAutomatically; // 0x308(0x28)
	char pad_330[0x8]; // 0x330(0x08)
	struct FMulticastInlineDelegate OnCompletedEvaluationDelegate; // 0x338(0x10)

	void RemoveClosestPointProvidersToPoint(struct FVector& Point, float MaximumDistance, int32_t PointsToDisable); // Function LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler.RemoveClosestPointProvidersToPoint // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa6d6fe0
	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler.OnCurrentPlaylistLoaded // (Final|Native|Private|HasOutParms) // @ game+0x792bb20
	void OnCompletedEvaluation__DelegateSignature(struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>>& EnabledPointProviders); // DelegateFunction LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler.OnCompletedEvaluation__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x1b027f0
	bool HasCompletedEvaluation(); // Function LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler.HasCompletedEvaluation // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9cec600
	struct FGameplayTagContainer GetEnablerTags(); // Function LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler.GetEnablerTags // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6d7430
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> GetEnabledLinkedPointProviders(); // Function LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler.GetEnabledLinkedPointProviders // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6d7460
	void EvaluateAndEnablePointProviders(); // Function LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler.EvaluateAndEnablePointProviders // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3982d70
	bool DoesStartEnabled(); // Function LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler.DoesStartEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6d6f90
};

// Class LagerRuntime.FortAthenaLivingWorldPointProvidersEnabler_MiniMapDataOverride
// Size: 0x348 (Inherited: 0x348)
struct AFortAthenaLivingWorldPointProvidersEnabler_MiniMapDataOverride : AFortAthenaLivingWorldPointProvidersEnabler {
};

// Class LagerRuntime.FortAthenaLinearEncounterAnalyticComponent
// Size: 0xf8 (Inherited: 0xa0)
struct UFortAthenaLinearEncounterAnalyticComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)

	void OnStageCompleted(struct TArray<struct AFortPickup*>& SpawnedRewards); // Function LagerRuntime.FortAthenaLinearEncounterAnalyticComponent.OnStageCompleted // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4917470
	void OnEncounterStart(struct UFortAthenaLivingWorldEncounterInstance* InAttackerEncounter, struct UFortAthenaLivingWorldEncounterInstance* InDefenderEncounter); // Function LagerRuntime.FortAthenaLinearEncounterAnalyticComponent.OnEncounterStart // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x48d5980
	void OnEncounterEnd(); // Function LagerRuntime.FortAthenaLinearEncounterAnalyticComponent.OnEncounterEnd // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3982d70
	void OnDefenderSpawned(struct AActor* SpawnedDefender); // Function LagerRuntime.FortAthenaLinearEncounterAnalyticComponent.OnDefenderSpawned // (Final|Native|Private) // @ game+0xa6a7030
	void OnDefenderDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function LagerRuntime.FortAthenaLinearEncounterAnalyticComponent.OnDefenderDied // (Final|Native|Private|HasDefaults) // @ game+0xa6a6040
	void OnDefenderDidDamage(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function LagerRuntime.FortAthenaLinearEncounterAnalyticComponent.OnDefenderDidDamage // (Final|Native|Private|HasDefaults) // @ game+0xa6a65c0
	void OnDefenderDamaged(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function LagerRuntime.FortAthenaLinearEncounterAnalyticComponent.OnDefenderDamaged // (Final|Native|Private|HasDefaults) // @ game+0xa6a6b20
	void OnAttackerSpawned(struct AActor* SpawnedAttacker); // Function LagerRuntime.FortAthenaLinearEncounterAnalyticComponent.OnAttackerSpawned // (Final|Native|Private) // @ game+0xa6a5f60
};

// Class LagerRuntime.FortAthenaLivingWorldConditionSchema
// Size: 0x38 (Inherited: 0x38)
struct UFortAthenaLivingWorldConditionSchema : UWorldConditionSchema {
};

// Class LagerRuntime.FortAthenaLivingWorldEventDataConditionSchema
// Size: 0x40 (Inherited: 0x38)
struct UFortAthenaLivingWorldEventDataConditionSchema : UFortAthenaLivingWorldConditionSchema {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class LagerRuntime.FortAthenaLivingWorldConfigData
// Size: 0x230 (Inherited: 0x30)
struct UFortAthenaLivingWorldConfigData : UDataAsset {
	struct TArray<struct FFortAthenaLivingWorldCategoryTableData> CategoryTableDatas; // 0x30(0x10)
	struct FScalableFloat MaxActorCount; // 0x40(0x28)
	struct FScalableFloat MaxEventSpawnPerTick; // 0x68(0x28)
	struct FScalableFloat MaxActorDespawnPerTick; // 0x90(0x28)
	struct FScalableFloat MinimumEventGenerationInterval; // 0xb8(0x28)
	struct FScalableFloat MaxActorDensity; // 0xe0(0x28)
	struct FScalableFloat MaxActorUpdatesPerTick; // 0x108(0x28)
	struct FScalableFloat ActorDensityGridCellSize; // 0x130(0x28)
	struct FScalableFloat PointClusterSize; // 0x158(0x28)
	struct FScalableFloat MinNumberOfPlayerForAggressiveSpawning; // 0x180(0x28)
	struct TArray<struct FFortAthenaLivingWorldTagDensityGridData> TagDensityGridData; // 0x1a8(0x10)
	struct FGameplayTagQuery SingleUseSpawnerDataQuery; // 0x1b8(0x48)
	struct AFortAthenaLivingWorldEQSHelper* EQSActorHelperClass; // 0x200(0x08)
	struct FScalableFloat DelayEventGeneration; // 0x208(0x28)
};

// Class LagerRuntime.FortAthenaLivingWorldDebugDensityMiniMapIndicator
// Size: 0x1a0 (Inherited: 0x140)
struct UFortAthenaLivingWorldDebugDensityMiniMapIndicator : UFortMiniMapIndicator {
	struct TArray<struct FFortAthenaActorDensityDebugInfo> ActorDebugInfos; // 0x140(0x10)
	struct TArray<float> DensityGridValues; // 0x150(0x10)
	struct FVector GridOrigin; // 0x160(0x18)
	struct FIntVector MaxGridSize; // 0x178(0x0c)
	float CellSize; // 0x184(0x04)
	float MaxDensity; // 0x188(0x04)
	char pad_18C[0x4]; // 0x18c(0x04)
	struct FString DisplayName; // 0x190(0x10)
};

// Class LagerRuntime.FortAthenaLivingWorldDespawnConditionSchema
// Size: 0x40 (Inherited: 0x38)
struct UFortAthenaLivingWorldDespawnConditionSchema : UFortAthenaLivingWorldConditionSchema {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class LagerRuntime.FortAthenaLivingWorldEncounter
// Size: 0x68 (Inherited: 0x30)
struct UFortAthenaLivingWorldEncounter : UDataAsset {
	struct FScalableFloat IntervalBetweenEventGeneration; // 0x30(0x28)
	struct TArray<struct FFortAthenaLivingWorldEncounterStage> Stages; // 0x58(0x10)
};

// Class LagerRuntime.FortAthenaLivingWorldEncounterInstance
// Size: 0x180 (Inherited: 0x28)
struct UFortAthenaLivingWorldEncounterInstance : UObject {
	struct FMulticastInlineDelegate OnActorSpawned; // 0x28(0x10)
	struct FMulticastInlineDelegate OnFirstActorSpawned; // 0x38(0x10)
	struct FMulticastInlineDelegate OnActorDestroyed; // 0x48(0x10)
	struct FMulticastInlineDelegate OnLastActorDestroyed; // 0x58(0x10)
	struct FMulticastInlineDelegate OnActorDied; // 0x68(0x10)
	char pad_78[0x50]; // 0x78(0x50)
	struct FFortAthenaLivingWorldConditionContainer ConditionContainer; // 0xc8(0x18)
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> AllowedPointProviders; // 0xe0(0x10)
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> RegisteredPointProviders; // 0xf0(0x10)
	struct TArray<struct UFortAthenaLivingWorldEventData*> RuntimeCreatedEventDatas; // 0x100(0x10)
	char pad_110[0x20]; // 0x110(0x20)
	struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter> EncounterDefinition; // 0x130(0x20)
	struct AActor* ActorDensityReservoir; // 0x150(0x08)
	struct TArray<struct AActor*> SpawnedActors; // 0x158(0x10)
	char pad_168[0x8]; // 0x168(0x08)
	int32_t CurrentStageIndex; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
	bool bIsPaused; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)

	void StartEncounterStage(int32_t StageIndex); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.StartEncounterStage // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6ad320
	void ResumeEncounter(); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.ResumeEncounter // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6ad2e0
	void Reset(); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.Reset // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3982d70
	void RequestEventGeneration(); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.RequestEventGeneration // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6ad2a0
	void RemoveAllowedPointProvider(struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>& PointProvider); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.RemoveAllowedPointProvider // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa6acf50
	void PauseEncounter(); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.PauseEncounter // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6ad300
	bool OwnsActor(struct AActor* Actor); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.OwnsActor // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x77d51f0
	void OnEncounterActorDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.OnEncounterActorDied // (Final|Native|Private|HasDefaults) // @ game+0xa6acaa0
	void OnActorSpawned__DelegateSignature(struct AActor* SpawnedActor); // DelegateFunction LagerRuntime.FortAthenaLivingWorldEncounterInstance.OnActorSpawned__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnActorDied__DelegateSignature(struct AActor* DiedActor); // DelegateFunction LagerRuntime.FortAthenaLivingWorldEncounterInstance.OnActorDied__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnActorDestroyed__DelegateSignature(struct AActor* DestroyedActor); // DelegateFunction LagerRuntime.FortAthenaLivingWorldEncounterInstance.OnActorDestroyed__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	bool HasReachedMaxSpawnedCount(); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.HasReachedMaxSpawnedCount // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x42ab9f0
	int32_t GetTotalActorCount(); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.GetTotalActorCount // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7655580
	int32_t GetAliveSpawnedActorCount(); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.GetAliveSpawnedActorCount // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6ad190
	void AdvanceEncounterStage(); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.AdvanceEncounterStage // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6ad500
	void AddAllowedPointProvider(struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>& PointProvider); // Function LagerRuntime.FortAthenaLivingWorldEncounterInstance.AddAllowedPointProvider // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa6ad060
};

// Class LagerRuntime.FortAthenaLivingWorldEventData
// Size: 0x140 (Inherited: 0x30)
struct UFortAthenaLivingWorldEventData : UDataAsset {
	int32_t TimeOfDayFilters; // 0x30(0x04)
	float WaterLevelIndexMin; // 0x34(0x04)
	float WaterLevelIndexMax; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FWorldConditionQueryDefinition CanSpawnCondition; // 0x40(0x18)
	struct TArray<struct FFortAthenaLivingWorldDespawnCondition> DespawnConditions; // 0x58(0x10)
	struct FGameplayTagQuery ProviderFiltersTagQuery; // 0x68(0x48)
	struct TArray<struct FPointProviderFilterEntry> ProviderFiltersEntries; // 0xb0(0x10)
	struct FInstancedStruct PointProviderSelector; // 0xc0(0x10)
	struct TArray<struct FFortAthenaLivingWorldTaggedSpawnActionClass> SpawnActions; // 0xd0(0x10)
	struct FScalableFloat MinActorCountToSpawn; // 0xe0(0x28)
	struct FScalableFloat MaxActorCountToSpawn; // 0x108(0x28)
	struct TArray<struct FFortAthenaLivingWorldEventDataActorSpawnDescription> ActorDescriptions; // 0x130(0x10)
};

// Class LagerRuntime.FortAthenaLivingWorldManager
// Size: 0xaf0 (Inherited: 0xa0)
struct UFortAthenaLivingWorldManager : UGameStateComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	struct TSoftObjectPtr<UFortAthenaLivingWorldConfigData> DefaultLagerConfig; // 0xa8(0x20)
	struct TArray<struct FFortLivingWorldConfigOverride> LagerConfigOverrides; // 0xc8(0x10)
	struct FScalableFloat LagerEnabled; // 0xd8(0x28)
	struct TMap<struct FGameplayTag, struct UFortAthenaLivingWorldSpawnAction*> TaggedSpawnActionClassMap; // 0x100(0x50)
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> PointProviders; // 0x150(0x10)
	struct FSlateBrush SpecialActorMinimapIconBrush; // 0x160(0xc0)
	struct FVector2D SpecialActorMinimapIconScale; // 0x220(0x10)
	struct FSlateBrush SpecialActorCompassIconBrush; // 0x230(0xc0)
	struct FVector2D SpecialActorCompassIconScale; // 0x2f0(0x10)
	struct TArray<struct UFortAthenaSpawnerDataBase*> SpawnedSingleUseSpawnerData; // 0x300(0x10)
	struct UWorld* CachedWorld; // 0x310(0x08)
	struct UFortAthenaLivingWorldConfigData* CachedConfig; // 0x318(0x08)
	struct TArray<struct UFortAthenaLivingWorldEncounterInstance*> RunningEncounterInstances; // 0x320(0x10)
	struct UFortSeasonalEventManager* CachedSeasonalEventManager; // 0x330(0x08)
	struct TArray<struct TSoftClassPtr<UObject>> ActorClassToPreloadOnClient; // 0x338(0x10)
	struct FFortAthenaLivingWorldActorUpdateHandler ActorUpdateHandler; // 0x348(0xb0)
	struct FFortAthenaLivingWorldPlayerTracker PlayerTracker; // 0x3f8(0xb0)
	struct FFortAthenaLivingWorldPreloader Preloader; // 0x4a8(0xe0)
	struct FFortAthenaLivingWorldConditionContainer GlobalConditionContainer; // 0x588(0x18)
	char pad_5A0[0x258]; // 0x5a0(0x258)
	struct TArray<struct AActor*> RuntimePointProviderList; // 0x7f8(0x10)
	struct TSet<struct AActor*> RuntimePointProviderOwners; // 0x808(0x50)
	char pad_858[0x210]; // 0x858(0x210)
	struct TMap<struct UFortAthenaLivingWorldSpawnAction*, struct UFortAthenaLivingWorldSpawnAction*> SpawnActionCache; // 0xa68(0x50)
	struct AFortAthenaLivingWorldEQSHelper* EQSHelper; // 0xab8(0x08)
	struct UFortAthenaLivingWorldDebugDensityMiniMapIndicator* DebugDensityMinimapIndicator; // 0xac0(0x08)
	char pad_AC8[0x28]; // 0xac8(0x28)

	void UnregisterDensityReservoir(struct AActor* ActorDensityReservoir); // Function LagerRuntime.FortAthenaLivingWorldManager.UnregisterDensityReservoir // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6b3190
	bool TrySpawnEvent(struct FDataTableRowHandle EventEntry, struct FTransform SpawnLocation, struct FDelegate& OnRequestFinished, int32_t& RequestID); // Function LagerRuntime.FortAthenaLivingWorldManager.TrySpawnEvent // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa6b4ea0
	struct UFortAthenaLivingWorldEncounterInstance* StartEncounter(struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter> EncounterType, struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>>& EncounterPointProviders, struct AActor* ActorDensityReservoir); // Function LagerRuntime.FortAthenaLivingWorldManager.StartEncounter // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa6b2eb0
	void ResetEncounter(struct UFortAthenaLivingWorldEncounterInstance* EncounterInstance); // Function LagerRuntime.FortAthenaLivingWorldManager.ResetEncounter // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6b29a0
	void RequestEventGeneration(); // Function LagerRuntime.FortAthenaLivingWorldManager.RequestEventGeneration // (Final|Native|Public|BlueprintCallable) // @ game+0xa6b4d60
	void RegisterTagDensityReservoir(struct AActor* ActorDensityReservoir, struct TArray<struct FFortAthenaLivingWorldEventTagDensityRegistration>& TagsDensity); // Function LagerRuntime.FortAthenaLivingWorldManager.RegisterTagDensityReservoir // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa6b3280
	void RegisterDensityReservoir(struct AActor* ActorDensityReservoir, float Density, float Range); // Function LagerRuntime.FortAthenaLivingWorldManager.RegisterDensityReservoir // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6b40d0
	int32_t QueryEventBudget(struct FDataTableRowHandle EventEntry, struct AActor* SpawnLocation); // Function LagerRuntime.FortAthenaLivingWorldManager.QueryEventBudget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6b5310
	void OnWorldFinishedInitialization(struct FGameplayTagContainer& ContextTags); // Function LagerRuntime.FortAthenaLivingWorldManager.OnWorldFinishedInitialization // (Final|Native|Private|HasOutParms) // @ game+0xa6b1ec0
	void OnUnmanagedDensityReservoirActorDestroy(struct AActor* DestroyedActor); // Function LagerRuntime.FortAthenaLivingWorldManager.OnUnmanagedDensityReservoirActorDestroy // (Final|Native|Private) // @ game+0xa6b2280
	void OnSpawnedActorDestroy(struct AActor* DestroyedActor); // Function LagerRuntime.FortAthenaLivingWorldManager.OnSpawnedActorDestroy // (Final|Native|Private) // @ game+0xa6b2370
	void OnRep_DebugDensityMinimapIndicator(struct UFortAthenaLivingWorldDebugDensityMiniMapIndicator* OldMapIndicator); // Function LagerRuntime.FortAthenaLivingWorldManager.OnRep_DebugDensityMinimapIndicator // (Final|Native|Private) // @ game+0x34e0930
	void OnRep_ActorClassToPreloadOnClient(); // Function LagerRuntime.FortAthenaLivingWorldManager.OnRep_ActorClassToPreloadOnClient // (Final|Native|Private) // @ game+0xa6b1880
	void OnPatrolPathAdded(struct AFortAthenaPatrolPath* PatrolPath); // Function LagerRuntime.FortAthenaLivingWorldManager.OnPatrolPathAdded // (Final|Native|Private) // @ game+0xa6b18b0
	void OnDebugSpawnEventSpawned(struct TArray<struct AActor*>& SpawnedActors, bool bSuccess); // Function LagerRuntime.FortAthenaLivingWorldManager.OnDebugSpawnEventSpawned // (Final|Native|Private|HasOutParms) // @ game+0xa6b16b0
	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function LagerRuntime.FortAthenaLivingWorldManager.OnCurrentPlaylistLoaded // (Final|Native|Private|HasOutParms) // @ game+0xa6b2070
	void OnActorSpawned(struct AActor* Actor, int32_t RequestID); // Function LagerRuntime.FortAthenaLivingWorldManager.OnActorSpawned // (Final|Native|Private) // @ game+0xa6b2460
	void LWMTAM(struct FString Name); // Function LagerRuntime.FortAthenaLivingWorldManager.LWMTAM // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0xa6b5910
	void LWMF(); // Function LagerRuntime.FortAthenaLivingWorldManager.LWMF // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerUnregisterPointProvider(struct AActor* PointProvider); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerUnregisterPointProvider // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa6b5ac0
	void LivingWorldManagerToggleVerboseLogging(); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerToggleVerboseLogging // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerToggleGenerateEvents(); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerToggleGenerateEvents // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerToggleDensityDisplay(); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerToggleDensityDisplay // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerToggleActorMinimap(struct FString Name); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerToggleActorMinimap // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x7ff1010
	void LivingWorldManagerSwitchDensityDisplay(int32_t DensityMapIndex); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerSwitchDensityDisplay // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x42a9e30
	void LivingWorldManagerSetEventGenerationEnabled(bool bInGenerateEvents); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerSetEventGenerationEnabled // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x34b0aa0
	void LivingWorldManagerRegisterPointProvider(struct AActor* PointProvider); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerRegisterPointProvider // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa6b5ac0
	void LivingWorldManagerProviderDebugActor(int32_t ProviderIndex); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerProviderDebugActor // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x42a9e30
	void LivingWorldManagerGenerateEvents(); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerGenerateEvents // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerFlush(); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerFlush // (Final|BlueprintAuthorityOnly|Exec|Native|Public|BlueprintCallable) // @ game+0x3982d70
	void LivingWorldManagerDumpSpawnCount(); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerDumpSpawnCount // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerDumpPrefabLevelBounds(); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerDumpPrefabLevelBounds // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerDumpEventInstances(); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerDumpEventInstances // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerDebugEvent(struct FString EventName, int32_t DebugIndex, struct FString RuntimeSpawnDataName, struct FString EncounterName); // Function LagerRuntime.FortAthenaLivingWorldManager.LivingWorldManagerDebugEvent // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0xa6b54c0
	bool IsEncounterCategoryActive(struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter> EncounterType); // Function LagerRuntime.FortAthenaLivingWorldManager.IsEncounterCategoryActive // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6b27d0
	struct UFortAthenaLivingWorldEncounterInstance* GetOwningEncounter(struct AActor* Actor); // Function LagerRuntime.FortAthenaLivingWorldManager.GetOwningEncounter // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6b4a60
	struct UFortAthenaLivingWorldManager* GetLivingWorldManager(struct UObject* WorldContextObject); // Function LagerRuntime.FortAthenaLivingWorldManager.GetLivingWorldManager // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa6b5ba0
	void EndEncounter(struct UFortAthenaLivingWorldEncounterInstance* EncounterInstance); // Function LagerRuntime.FortAthenaLivingWorldManager.EndEncounter // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6b2c50
	void CancelSpawnRequest(int32_t RequestID); // Function LagerRuntime.FortAthenaLivingWorldManager.CancelSpawnRequest // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6b4da0
	bool BuildDataRegistryResolverScope_Implementation(struct TArray<struct FName>& InOutResolverScopes, int32_t& InOutPriority); // Function LagerRuntime.FortAthenaLivingWorldManager.BuildDataRegistryResolverScope_Implementation // (Native|Public|HasOutParms|Const) // @ game+0xa6b25e0
};

// Class LagerRuntime.FortAthenaLivingWorldNavigationInvokerComponent
// Size: 0x190 (Inherited: 0xa0)
struct UFortAthenaLivingWorldNavigationInvokerComponent : UActorComponent {
	struct FScalableFloat GenerationRadius; // 0xa0(0x28)
	struct FNavAgentSelector SupportedAgents; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct FScalableFloat DistanceToPlayer; // 0xd0(0x28)
	struct FScalableFloat DistanceToPlayerHysteresis; // 0xf8(0x28)
	struct FScalableFloat RegistrationDistanceToPlayer; // 0x120(0x28)
	struct FScalableFloat RegistrationDistanceToPlayerHysteresis; // 0x148(0x28)
	struct TWeakObjectPtr<struct UFortAthenaLivingWorldManager> LivingWorldManager; // 0x170(0x08)
	char pad_178[0x18]; // 0x178(0x18)

	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function LagerRuntime.FortAthenaLivingWorldNavigationInvokerComponent.OnCurrentPlaylistLoaded // (Final|Native|Protected|HasOutParms) // @ game+0x792bb20
};

// Class LagerRuntime.FortAthenaLivingWorldPointProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaLivingWorldPointProviderInterface : UInterface {

	float GetPointProviderMaxRadius(); // Function LagerRuntime.FortAthenaLivingWorldPointProviderInterface.GetPointProviderMaxRadius // (Native|Public|BlueprintCallable) // @ game+0xa6c4ee0
	struct FVector GetPointProviderLocation(); // Function LagerRuntime.FortAthenaLivingWorldPointProviderInterface.GetPointProviderLocation // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa6c4f10
	void GetFiltersTags(struct FGameplayTagContainer& FilterTags); // Function LagerRuntime.FortAthenaLivingWorldPointProviderInterface.GetFiltersTags // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6c4f70
	void EnablePointProvider(); // Function LagerRuntime.FortAthenaLivingWorldPointProviderInterface.EnablePointProvider // (Native|Public|BlueprintCallable) // @ game+0x43151e0
	void DisablePointProvider(); // Function LagerRuntime.FortAthenaLivingWorldPointProviderInterface.DisablePointProvider // (Native|Public|BlueprintCallable) // @ game+0xa6c4f50
};

// Class LagerRuntime.FortAthenaLivingWorldPrefabLevelStreaming
// Size: 0x1c0 (Inherited: 0x1c0)
struct UFortAthenaLivingWorldPrefabLevelStreaming : ULevelStreamingLevelInstance {
};

// Class LagerRuntime.FortAthenaLivingWorldPrefab
// Size: 0x918 (Inherited: 0x7c8)
struct AFortAthenaLivingWorldPrefab : AFortLevelInstancePrefab {
	struct TArray<struct FFortAthenaLivingWorldPrefabActorSpawnerData> ActorSpawnerDatas; // 0x7c8(0x10)
	struct FBox LocalLevelBounds; // 0x7d8(0x38)
	struct FBox LocalGrassRemovalBox; // 0x810(0x38)
	struct FMulticastInlineDelegate OnAllActorSpawnedDelegate; // 0x848(0x10)
	char pad_858[0x18]; // 0x858(0x18)
	struct TArray<struct TWeakObjectPtr<struct ABuildingActor>> BuildingsToKill; // 0x870(0x10)
	struct TArray<struct TWeakObjectPtr<struct AActor>> SpawnedActors; // 0x880(0x10)
	struct FDelegate FinishedDestroyingBuildingCallback; // 0x890(0x0c)
	bool bHasFinishedSpawn; // 0x89c(0x01)
	bool bHasRemovedFoliage; // 0x89d(0x01)
	char pad_89E[0x2]; // 0x89e(0x02)
	struct FScalableFloat bIsEnabled; // 0x8a0(0x28)
	struct FScalableFloat Weight; // 0x8c8(0x28)
	bool bShouldLevelBeVisible; // 0x8f0(0x01)
	bool bShouldSpawnerBeAllowedToSpawn; // 0x8f1(0x01)
	bool bShouldAlwaysSnapAboveLandscape; // 0x8f2(0x01)
	char pad_8F3[0x5]; // 0x8f3(0x05)
	struct FWorldConditionQueryDefinition CanSpawnCondition; // 0x8f8(0x18)
	char pad_910[0x8]; // 0x910(0x08)

	void RemoveFoliageInsideLevelBound(); // Function LagerRuntime.FortAthenaLivingWorldPrefab.RemoveFoliageInsideLevelBound // (Final|Native|Public|BlueprintCallable) // @ game+0xa6c6480
	void OnRep_ShouldLevelBeVisible(); // Function LagerRuntime.FortAthenaLivingWorldPrefab.OnRep_ShouldLevelBeVisible // (Final|Native|Protected) // @ game+0xa6c63f0
	void OnBuildingInLevelBoundsDestroyed__DelegateSignature(); // DelegateFunction LagerRuntime.FortAthenaLivingWorldPrefab.OnBuildingInLevelBoundsDestroyed__DelegateSignature // (Public|Delegate) // @ game+0x1b027f0
	void OnAllActorSpawnedDelegate__DelegateSignature(struct TArray<struct AActor*>& SpawnedActors); // DelegateFunction LagerRuntime.FortAthenaLivingWorldPrefab.OnAllActorSpawnedDelegate__DelegateSignature // (Public|Delegate|HasOutParms) // @ game+0x1b027f0
	void OnAllActorSpawned__DelegateSignature(struct TArray<struct AActor*>& SpawnedActors); // DelegateFunction LagerRuntime.FortAthenaLivingWorldPrefab.OnAllActorSpawned__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x1b027f0
	void MakeLevelVisible(); // Function LagerRuntime.FortAthenaLivingWorldPrefab.MakeLevelVisible // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6c66c0
	struct AFortAthenaLivingWorldPrefab* GetOwningLivingWorldPrefab(struct UObject* WorldContextObject); // Function LagerRuntime.FortAthenaLivingWorldPrefab.GetOwningLivingWorldPrefab // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa6c6840
	struct FBox GetLevelBounds(); // Function LagerRuntime.FortAthenaLivingWorldPrefab.GetLevelBounds // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6c6640
	void DestroyBuildingsInLevelBounds(struct FDelegate& FinishedDelegate); // Function LagerRuntime.FortAthenaLivingWorldPrefab.DestroyBuildingsInLevelBounds // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa6c6530
	void CallWhenAllActorHaveSpawned(struct FDelegate& DelegateToCall); // Function LagerRuntime.FortAthenaLivingWorldPrefab.CallWhenAllActorHaveSpawned // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa6c6730
	void AllowSpawnerToSpawn(); // Function LagerRuntime.FortAthenaLivingWorldPrefab.AllowSpawnerToSpawn // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6c6440
};

// Class LagerRuntime.FortAthenaLivingWorldPrefabActorSpawner
// Size: 0x3c0 (Inherited: 0x290)
struct AFortAthenaLivingWorldPrefabActorSpawner : AActor {
	struct FFortAthenaLivingWorldActorSpawnDescription ActorDescription; // 0x290(0x100)
	struct FMulticastInlineDelegate OnActorSpawnedDelegate; // 0x390(0x10)
	struct AFortAthenaPatrolPath* PatrolPath; // 0x3a0(0x08)
	struct FGuid Guid; // 0x3a8(0x10)
	struct TWeakObjectPtr<struct AActor> SpawnedActor; // 0x3b8(0x08)

	void OnSnapCompleted(struct UFortSnapOnSurfaceComponent* Component, struct FTransform& OldTransform, struct FTransform& NewTransfom); // Function LagerRuntime.FortAthenaLivingWorldPrefabActorSpawner.OnSnapCompleted // (Final|Native|Protected|HasOutParms|HasDefaults) // @ game+0xa6c88f0
	void OnActorSpawnedDelegate__DelegateSignature(struct AActor* SpawnedActor); // DelegateFunction LagerRuntime.FortAthenaLivingWorldPrefabActorSpawner.OnActorSpawnedDelegate__DelegateSignature // (Public|Delegate) // @ game+0x1b027f0
	void OnActorSpawned__DelegateSignature(struct AActor* SpawnedActor); // DelegateFunction LagerRuntime.FortAthenaLivingWorldPrefabActorSpawner.OnActorSpawned__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	struct AActor* GetSpawnedActor(); // Function LagerRuntime.FortAthenaLivingWorldPrefabActorSpawner.GetSpawnedActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a923c0
	void CallWhenActorSpawned(struct FDelegate& DelegateToCall); // Function LagerRuntime.FortAthenaLivingWorldPrefabActorSpawner.CallWhenActorSpawned // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa6c8bf0
};

// Class LagerRuntime.FortAthenaLivingWorldSpawnAction
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaLivingWorldSpawnAction : UObject {
};

// Class LagerRuntime.FortAthenaLivingWorldSpawnActionBlueprint
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaLivingWorldSpawnActionBlueprint : UFortAthenaLivingWorldSpawnAction {

	void K2_OnAllActorSpawned(struct TArray<struct AActor*>& SpawnedActor, struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>& SourcePointProvider); // Function LagerRuntime.FortAthenaLivingWorldSpawnActionBlueprint.K2_OnAllActorSpawned // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x1b027f0
};

// Class LagerRuntime.FortAthenaLivingWorldStaticPointProvider
// Size: 0x370 (Inherited: 0x290)
struct AFortAthenaLivingWorldStaticPointProvider : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct FFortAthenaLivingWorldPointProviderSpawnLimiter SpawnLimiter; // 0x298(0x68)
	struct FGameplayTagContainer FiltersTags; // 0x300(0x20)
	struct TArray<struct FTransform> SpawnPoints; // 0x320(0x10)
	bool bStartEnabled; // 0x330(0x01)
	bool bRandomizeStartPoint; // 0x331(0x01)
	bool bRandomizePointRotation; // 0x332(0x01)
	char pad_333[0x5]; // 0x333(0x05)
	struct FMulticastInlineDelegate OnActorSpawned; // 0x338(0x10)
	struct TArray<struct FPointProviderTagDebugColor> DebugColors; // 0x348(0x10)
	struct AFortGameStateAthena* CachedGameState; // 0x358(0x08)
	struct UFortAthenaLivingWorldManager* CachedLivingWorldManager; // 0x360(0x08)
	char pad_368[0x8]; // 0x368(0x08)

	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function LagerRuntime.FortAthenaLivingWorldStaticPointProvider.OnCurrentPlaylistLoaded // (Final|Native|Protected|HasOutParms) // @ game+0xa6cd010
	void OnActorSpawned__DelegateSignature(struct AActor* SpawnedActor); // DelegateFunction LagerRuntime.FortAthenaLivingWorldStaticPointProvider.OnActorSpawned__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void EnablePointProvider(); // Function LagerRuntime.FortAthenaLivingWorldStaticPointProvider.EnablePointProvider // (Native|Public|BlueprintCallable) // @ game+0xa6cd240
	void DisablePointProvider(); // Function LagerRuntime.FortAthenaLivingWorldStaticPointProvider.DisablePointProvider // (Native|Public|BlueprintCallable) // @ game+0xa6cd210
};

// Class LagerRuntime.FortAthenaLivingWorldVehiclePointProvider
// Size: 0x3c0 (Inherited: 0x370)
struct AFortAthenaLivingWorldVehiclePointProvider : AFortAthenaLivingWorldStaticPointProvider {
	struct FGameplayTagContainer ForceMods; // 0x370(0x20)
	struct FScalableFloat ForceModsAllowed; // 0x390(0x28)
	enum class EVehicleInitialOverlapBehavior InitialOverlapBehavior; // 0x3b8(0x01)
	char pad_3B9[0x7]; // 0x3b9(0x07)
};

// Class LagerRuntime.FortAthenaLivingWorldVolume
// Size: 0x5c0 (Inherited: 0x2c8)
struct AFortAthenaLivingWorldVolume : AVolume {
	char pad_2C8[0x8]; // 0x2c8(0x08)
	bool bStartEnabled; // 0x2d0(0x01)
	char pad_2D1[0x7]; // 0x2d1(0x07)
	struct FGameplayTagContainer FiltersTags; // 0x2d8(0x20)
	struct UEnvQuery* EnvironmentQuery; // 0x2f8(0x08)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0x300(0x10)
	bool bRemoveUsedPoint; // 0x310(0x01)
	bool bRemoveUsedPointPermenantly; // 0x311(0x01)
	char pad_312[0x6]; // 0x312(0x06)
	struct FFortAthenaLivingWorldPointProviderSpawnLimiter SpawnLimiter; // 0x318(0x68)
	struct FScalableFloat EQSRefreshInterval; // 0x380(0x28)
	struct FScalableFloat WaterLevelIndexMin; // 0x3a8(0x28)
	struct FScalableFloat WaterLevelIndexMax; // 0x3d0(0x28)
	struct AFortGameStateAthena* CachedGameState; // 0x3f8(0x08)
	struct FMulticastInlineDelegate OnActorSpawnedResult; // 0x400(0x10)
	struct FMulticastInlineDelegate OnPointProviderRegistered; // 0x410(0x10)
	struct UFortAthenaLivingWorldManager* CachedLivingWorldManager; // 0x420(0x08)
	char pad_428[0x198]; // 0x428(0x198)

	void SetSpawnRotation(struct FRotator& Rotation); // Function LagerRuntime.FortAthenaLivingWorldVolume.SetSpawnRotation // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa6cf890
	void SetFiltersTags(struct FGameplayTagContainer& TagContainer); // Function LagerRuntime.FortAthenaLivingWorldVolume.SetFiltersTags // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa6cf9a0
	void SetEQSQueryConfigParam(struct FName ParameterName, float Value); // Function LagerRuntime.FortAthenaLivingWorldVolume.SetEQSQueryConfigParam // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6cfc20
	void SetEQSQuery(struct UEnvQuery* Query); // Function LagerRuntime.FortAthenaLivingWorldVolume.SetEQSQuery // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6cfaf0
	void RunEQS(); // Function LagerRuntime.FortAthenaLivingWorldVolume.RunEQS // (Final|Native|Private) // @ game+0x3982d70
	void ResetSpawnRotation(); // Function LagerRuntime.FortAthenaLivingWorldVolume.ResetSpawnRotation // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xa6cf860
	void OnWorldFinishedInitialization(struct FGameplayTagContainer& ContextTags); // Function LagerRuntime.FortAthenaLivingWorldVolume.OnWorldFinishedInitialization // (Final|Native|Private|HasOutParms) // @ game+0xa6cf4f0
	void OnPointProviderRegistered__DelegateSignature(struct AFortAthenaLivingWorldVolume* PointProviderVolume); // DelegateFunction LagerRuntime.FortAthenaLivingWorldVolume.OnPointProviderRegistered__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function LagerRuntime.FortAthenaLivingWorldVolume.OnCurrentPlaylistLoaded // (Final|Native|Private|HasOutParms) // @ game+0xa6cf670
	void OnActorSpawnedResult__DelegateSignature(struct AActor* SpawnedActor, bool bResult); // DelegateFunction LagerRuntime.FortAthenaLivingWorldVolume.OnActorSpawnedResult__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	bool IsPointProviderEnabled(); // Function LagerRuntime.FortAthenaLivingWorldVolume.IsPointProviderEnabled // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9d45280
	void EnablePointProvider(); // Function LagerRuntime.FortAthenaLivingWorldVolume.EnablePointProvider // (Native|Public|BlueprintCallable) // @ game+0xa6cfdd0
	bool DoesStartEnabled(); // Function LagerRuntime.FortAthenaLivingWorldVolume.DoesStartEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9070cf0
	void DisablePointProvider(); // Function LagerRuntime.FortAthenaLivingWorldVolume.DisablePointProvider // (Native|Public|BlueprintCallable) // @ game+0xa6cfda0
};

// Class LagerRuntime.FortAthenaLivingWorldWardComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UFortAthenaLivingWorldWardComponent : UActorComponent {
	float DefaultRadius; // 0xa0(0x04)
	char pad_A4[0xc]; // 0xa4(0x0c)

	void SetWardRadius(float Radius); // Function LagerRuntime.FortAthenaLivingWorldWardComponent.SetWardRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x965b950
	void OnWorldFinishedInitialization(struct FGameplayTagContainer& ContextTags); // Function LagerRuntime.FortAthenaLivingWorldWardComponent.OnWorldFinishedInitialization // (Final|Native|Private|HasOutParms) // @ game+0xa6d2070
	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function LagerRuntime.FortAthenaLivingWorldWardComponent.OnCurrentPlaylistLoaded // (Final|Native|Private|HasOutParms) // @ game+0xa6d21b0
};

// Class LagerRuntime.FortAthenaPatrolPathPointProvider
// Size: 0x360 (Inherited: 0x290)
struct AFortAthenaPatrolPathPointProvider : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct FGameplayTagContainer FiltersTags; // 0x298(0x20)
	struct AFortAthenaPatrolPath* AssociatedPatrolPath; // 0x2b8(0x08)
	char bStartEnabled : 1; // 0x2c0(0x01)
	char bSpawnOnPatrolPath : 1; // 0x2c0(0x01)
	char bAlignOrientationToPath : 1; // 0x2c0(0x01)
	char pad_2C0_3 : 5; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct FFortAthenaLivingWorldPointProviderSpawnLimiter SpawnLimiter; // 0x2c8(0x68)
	struct FMulticastInlineDelegate OnActorSpawnedResult; // 0x330(0x10)
	struct TWeakObjectPtr<struct AFortAthenaPatrolPath> RuntimePatrolPathWeakPtr; // 0x340(0x08)
	struct AFortGameStateAthena* CachedGameState; // 0x348(0x08)
	struct UFortAthenaLivingWorldManager* CachedLivingWorldManager; // 0x350(0x08)
	char pad_358[0x8]; // 0x358(0x08)

	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function LagerRuntime.FortAthenaPatrolPathPointProvider.OnCurrentPlaylistLoaded // (Final|Native|Private|HasOutParms) // @ game+0xa6d2a10
	void OnActorSpawnedResult__DelegateSignature(struct AActor* SpawnedActor, bool bResult); // DelegateFunction LagerRuntime.FortAthenaPatrolPathPointProvider.OnActorSpawnedResult__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void EnablePointProvider(); // Function LagerRuntime.FortAthenaPatrolPathPointProvider.EnablePointProvider // (Native|Public|BlueprintCallable) // @ game+0xa6cd240
	void DisablePointProvider(); // Function LagerRuntime.FortAthenaPatrolPathPointProvider.DisablePointProvider // (Native|Public|BlueprintCallable) // @ game+0xa6cd210
};

// Class LagerRuntime.FortAthenaPointAroundPlayerProvider
// Size: 0x350 (Inherited: 0x290)
struct AFortAthenaPointAroundPlayerProvider : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct FGameplayTagContainer FiltersTags; // 0x298(0x20)
	struct UEnvQuery* QueryTemplate; // 0x2b8(0x08)
	enum class EEnvQueryRunMode RunMode; // 0x2c0(0x01)
	char bStartEnabled : 1; // 0x2c1(0x01)
	char bGenerateAroundPlayerBots : 1; // 0x2c1(0x01)
	char pad_2C1_2 : 6; // 0x2c1(0x01)
	char pad_2C2[0x2]; // 0x2c2(0x02)
	struct FGameplayTag IgnorePlayerWithTag; // 0x2c4(0x04)
	struct FFortAthenaLivingWorldPointProviderSpawnLimiter SpawnLimiter; // 0x2c8(0x68)
	struct FMulticastInlineDelegate OnActorSpawnedResult; // 0x330(0x10)
	struct AFortGameStateAthena* CachedGameState; // 0x340(0x08)
	char pad_348[0x8]; // 0x348(0x08)

	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function LagerRuntime.FortAthenaPointAroundPlayerProvider.OnCurrentPlaylistLoaded // (Final|Native|Private|HasOutParms) // @ game+0xa6d4130
	void OnActorSpawnedResult__DelegateSignature(struct AActor* SpawnedActor, bool bResult); // DelegateFunction LagerRuntime.FortAthenaPointAroundPlayerProvider.OnActorSpawnedResult__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void EnablePointProvider(); // Function LagerRuntime.FortAthenaPointAroundPlayerProvider.EnablePointProvider // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa6cd240
	void DisablePointProvider(); // Function LagerRuntime.FortAthenaPointAroundPlayerProvider.DisablePointProvider // (Native|Public|BlueprintCallable) // @ game+0xa6cd210
};

// Class LagerRuntime.FortCheatManager_LivingWorldManager
// Size: 0x70 (Inherited: 0x28)
struct UFortCheatManager_LivingWorldManager : UChildCheatManager {
	int32_t CheatTeleportToCount; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FString CheatTeleportLastEventDataName; // 0x30(0x10)
	int32_t CheatSpawnEventCount; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FString CheatSpawnEventName; // 0x48(0x10)
	int32_t CheatTriggerEventCount; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FString CheatTriggerEventName; // 0x60(0x10)

	void LWMTE(struct FString EventDataName); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LWMTE // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0xa6b5910
	void LWMSE(struct FString EventDataName, struct FString SpawnerDataNames); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LWMSE // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0xa6d4fb0
	void LWMS(struct FString EventDataName); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LWMS // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0xa6b5910
	void LivingWorldManagerTriggerEvent(struct FString EventDataName); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerTriggerEvent // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x7ff1010
	void LivingWorldManagerTeleportToSpawnPosition(struct FString EventDataName); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerTeleportToSpawnPosition // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x7ff1010
	void LivingWorldManagerTeleportTo(struct FString EventDataName); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerTeleportTo // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x7ff1010
	void LivingWorldManagerSpawnEventAtLocation(struct FString EventDataName, struct FVector Location, struct FRotator Rotation, struct FString SpawnerDataNames); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerSpawnEventAtLocation // (Final|BlueprintAuthorityOnly|Exec|Native|Public|HasDefaults) // @ game+0xa6d4c00
	void LivingWorldManagerSpawnEvent(struct FString EventDataName, struct FString SpawnerDataNames); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerSpawnEvent // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x754aa00
	void LivingWorldManagerSpawnAtLocation(struct FString EventDataName, struct FVector Location, struct FRotator Rotation); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerSpawnAtLocation // (Final|BlueprintAuthorityOnly|Exec|Native|Public|HasDefaults) // @ game+0xa6d5280
	void LivingWorldManagerSpawn(struct FString EventDataName); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerSpawn // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x7ff1010
	void LivingWorldManagerGDTNextDensityGrid(); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerGDTNextDensityGrid // (Final|Exec|Native|Public) // @ game+0x3982d70
	void LivingWorldManagerDisplaySpawnPoints(float MaxDisplayDistance); // Function LagerRuntime.FortCheatManager_LivingWorldManager.LivingWorldManagerDisplaySpawnPoints // (Final|Exec|Native|Public) // @ game+0x3de3420
};

// Class LagerRuntime.FortGameFeatureAction_AddCategoryTableToConfig
// Size: 0x78 (Inherited: 0x28)
struct UFortGameFeatureAction_AddCategoryTableToConfig : UGameFeatureAction {
	struct TMap<struct TSoftObjectPtr<UFortAthenaLivingWorldConfigData>, struct FFortAthenaLivingWorldCategoryTableDataList> ConfigToCategoryTableDatas; // 0x28(0x50)
};

// Class LagerRuntime.FortGameFeatureAction_AddLagerConfig
// Size: 0x38 (Inherited: 0x28)
struct UFortGameFeatureAction_AddLagerConfig : UGameFeatureAction {
	struct TArray<struct FFortLivingWorldConfigOverride> LagerConfigOverrides; // 0x28(0x10)
};

// Class LagerRuntime.FortGameFeatureAction_MapMarkerTagsProvider_PatrolPath
// Size: 0x28 (Inherited: 0x28)
struct UFortGameFeatureAction_MapMarkerTagsProvider_PatrolPath : UFortGameFeatureAction_MapMarkerTagsProvider {
};

// Class LagerRuntime.FortPawnComponent_LivingWorldSpawnAroundPlayer
// Size: 0xc8 (Inherited: 0xa8)
struct UFortPawnComponent_LivingWorldSpawnAroundPlayer : UFortPawnComponent {
	struct TArray<struct FLivingWorldSpawnAroundPlayerRuntimeData> RuntimeData; // 0xa8(0x10)
	struct TArray<struct FLivingWorldSpawnAroundPlayerConfiguration> PerPlayerConfigurations; // 0xb8(0x10)
};

// Class LagerRuntime.FortQueryTest_IsCloseToLivingWorldWard
// Size: 0x1f8 (Inherited: 0x1f8)
struct UFortQueryTest_IsCloseToLivingWorldWard : UEnvQueryTest {
};

// Class LagerRuntime.FortAthenaLivingWorldEQSHelper
// Size: 0x300 (Inherited: 0x290)
struct AFortAthenaLivingWorldEQSHelper : AActor {
	char pad_290[0x40]; // 0x290(0x40)
	struct FNavAgentProperties NavAgentProperties; // 0x2d0(0x30)
};

// Class LagerRuntime.FortAthenaLivingWorldSpawnAction_AddAIToGroup
// Size: 0x48 (Inherited: 0x28)
struct UFortAthenaLivingWorldSpawnAction_AddAIToGroup : UFortAthenaLivingWorldSpawnAction {
	struct FGameplayTagContainer GroupTags; // 0x28(0x20)
};

// Class LagerRuntime.FortAthenaLivingWorldSpawnAction_SeatPawnInVehicle
// Size: 0x38 (Inherited: 0x28)
struct UFortAthenaLivingWorldSpawnAction_SeatPawnInVehicle : UFortAthenaLivingWorldSpawnAction {
	struct TArray<struct FFortAthenaLivingWorldTagQueryToSeatMapping> SeatMappings; // 0x28(0x10)
};

