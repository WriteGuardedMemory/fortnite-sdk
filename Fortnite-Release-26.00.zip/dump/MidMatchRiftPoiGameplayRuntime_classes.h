// Class MidMatchRiftPoiGameplayRuntime.MidmatchRiftPoiCheatManager
// Size: 0x28 (Inherited: 0x28)
struct UMidmatchRiftPoiCheatManager : UChildCheatManager {

	void SpawnMidmatchPoiNearestLocation(struct FVector& Location); // Function MidMatchRiftPoiGameplayRuntime.MidmatchRiftPoiCheatManager.SpawnMidmatchPoiNearestLocation // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void SpawnMidmatchPoiFurthestLocation(struct FVector& Location); // Function MidMatchRiftPoiGameplayRuntime.MidmatchRiftPoiCheatManager.SpawnMidmatchPoiFurthestLocation // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void MidmatchRiftPoiSpawnNearestToPawnLocation(); // Function MidMatchRiftPoiGameplayRuntime.MidmatchRiftPoiCheatManager.MidmatchRiftPoiSpawnNearestToPawnLocation // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
	void MidmatchRiftPoiSpawnFurthestFromPawnLocation(); // Function MidMatchRiftPoiGameplayRuntime.MidmatchRiftPoiCheatManager.MidmatchRiftPoiSpawnFurthestFromPawnLocation // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x3982d70
};

// Class MidMatchRiftPoiGameplayRuntime.MidMatchRiftPoiManagerActor
// Size: 0x368 (Inherited: 0x290)
struct AMidMatchRiftPoiManagerActor : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	char bCanBeMarked : 1; // 0x298(0x01)
	char bBlockMarking : 1; // 0x298(0x01)
	char pad_298_2 : 6; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
	struct FMarkedActorDisplayInfo MarkerDisplay; // 0x2a0(0xa8)
	struct FVector MarkerPositionOffset; // 0x348(0x18)
	bool bDynamicLandBrushApplied; // 0x360(0x01)
	char pad_361[0x7]; // 0x361(0x07)

	void SetDynamicLandBrush(struct FSlateBrush& LandIcon); // Function MidMatchRiftPoiGameplayRuntime.MidMatchRiftPoiManagerActor.SetDynamicLandBrush // (Final|BlueprintCosmetic|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0xacb30f0
};

// Class MidMatchRiftPoiGameplayRuntime.MidmatchRiftPoiSpawnIndicator
// Size: 0x368 (Inherited: 0x290)
struct AMidmatchRiftPoiSpawnIndicator : AActor {
	char pad_290[0x10]; // 0x290(0x10)
	char bCanBeMarked : 1; // 0x2a0(0x01)
	char bBlockMarking : 1; // 0x2a0(0x01)
	char pad_2A0_2 : 6; // 0x2a0(0x01)
	char pad_2A1[0x7]; // 0x2a1(0x07)
	struct FMarkedActorDisplayInfo MarkerDisplay; // 0x2a8(0xa8)
	struct FVector MarkerPositionOffset; // 0x350(0x18)

	void TeleportVehicleActor(struct AActor* VehicleActor, struct FVector& TeleportLocation); // Function MidMatchRiftPoiGameplayRuntime.MidmatchRiftPoiSpawnIndicator.TeleportVehicleActor // (Final|BlueprintAuthorityOnly|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x7438d70
	bool IsActorInDataLayerInstance(struct AActor* Actor, struct UDataLayerInstance* DataLayerInstance); // Function MidMatchRiftPoiGameplayRuntime.MidmatchRiftPoiSpawnIndicator.IsActorInDataLayerInstance // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x944a670
};

