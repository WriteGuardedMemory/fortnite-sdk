// Enum MeshCosmeticsUI.ERedirectorTileDisplayMode
enum class ERedirectorTileDisplayMode : uint8 {
	DisplaySprayTexture = 0,
	ChangeOpacity = 1,
	SwitchTextures = 2,
	ERedirectorTileDisplayMode_MAX = 3
};

// ScriptStruct MeshCosmeticsUI.FortVariantSprayCustomizerChannelOptions
// Size: 0x18 (Inherited: 0x00)
struct FFortVariantSprayCustomizerChannelOptions {
	struct FRotator RotationOffset; // 0x00(0x18)
};

// ScriptStruct MeshCosmeticsUI.FortVariantSprayCustomizerCosmeticOptions
// Size: 0x60 (Inherited: 0x00)
struct FFortVariantSprayCustomizerCosmeticOptions {
	struct TArray<struct TSoftObjectPtr<UFortItemDefinition>> ItemShopPreviewStyles; // 0x00(0x10)
	struct TMap<struct FGameplayTag, struct FFortVariantSprayCustomizerChannelOptions> ChannelOptions; // 0x10(0x50)
};

// ScriptStruct MeshCosmeticsUI.FortVariantRedirectorTileLoadedEmoteToRandomize
// Size: 0x10 (Inherited: 0x00)
struct FFortVariantRedirectorTileLoadedEmoteToRandomize {
	struct UFortItemDefinition* LoadedEmote; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

