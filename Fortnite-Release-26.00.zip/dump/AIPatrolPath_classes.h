// Class AIPatrolPath.AIPatrolPathEditorComponent
// Size: 0x650 (Inherited: 0x5c0)
struct UAIPatrolPathEditorComponent : UDebugDrawComponent {
	char pad_5C0[0x90]; // 0x5c0(0x90)
};

// Class AIPatrolPath.AIPatrolPathComponent
// Size: 0x378 (Inherited: 0xa0)
struct UAIPatrolPathComponent : UActorComponent {
	char pad_A0[0x28]; // 0xa0(0x28)
	struct TArray<struct FString> SharedOptionNames; // 0xc8(0x10)
	struct TSoftClassPtr<UObject> DefaultAIPawn; // 0xd8(0x20)
	struct ABuildingActor* PathRendererClass; // 0xf8(0x08)
	bool bAllowPartialPaths; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FGameplayTagContainer UnableToPlaceNewDeviceTags; // 0x108(0x20)
	struct FNavAgentProperties CachedAIAgentProperties; // 0x128(0x30)
	struct UNavigationSystemV1* CachedNavSystem; // 0x158(0x08)
	struct ANavigationData* CachedNavData; // 0x160(0x08)
	struct UNavigationQueryFilter* CachedFilterClass; // 0x168(0x08)
	char pad_170[0x10]; // 0x170(0x10)
	struct FMulticastInlineDelegate OnPatrolPointFailedToReach; // 0x180(0x10)
	struct FMulticastInlineDelegate OnPatrolPointReached; // 0x190(0x10)
	struct FMulticastInlineDelegate OnPatrolPathStarted; // 0x1a0(0x10)
	struct FMulticastInlineDelegate OnPatrolPathStopped; // 0x1b0(0x10)
	char pad_1C0[0x8]; // 0x1c0(0x08)
	struct TArray<struct AActor*> PatrolPath; // 0x1c8(0x10)
	struct FPatrolPathSegmentDetails PathSegmentDetails; // 0x1d8(0x108)
	char pad_2E0[0x10]; // 0x2e0(0x10)
	struct UAIPatrolPathComponent* CopiedFrom; // 0x2f0(0x08)
	struct AActor* CurrentCloningNode; // 0x2f8(0x08)
	char pad_300[0x8]; // 0x300(0x08)
	struct UAIPatrolPathComponent* CopiedFromCut; // 0x308(0x08)
	struct AFortCreativePatrolPath* PatrolPathActor; // 0x310(0x08)
	struct AFortAthenaPatrolPoint* PatrolPointActor; // 0x318(0x08)
	struct TArray<struct UAIPatrolPathComponent*> MultiSelectActorToEnterList; // 0x320(0x10)
	char pad_330[0x40]; // 0x330(0x40)
	struct UAIPatrolPathEditorComponent* PatrolPathEditorComponent; // 0x370(0x08)

	void UpdateEditorComponent(); // Function AIPatrolPath.AIPatrolPathComponent.UpdateEditorComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x3982d70
	bool ShouldRenderPath(); // Function AIPatrolPath.AIPatrolPathComponent.ShouldRenderPath // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1b027f0
	void SetRenderPath(bool bRenderPath); // Function AIPatrolPath.AIPatrolPathComponent.SetRenderPath // (Final|Native|Public|BlueprintCallable) // @ game+0xaa74440
	void SetPatrolPathGroup(enum class EFortCreativePatrolPathGroup PatrolPathGroup); // Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathGroup // (Final|Native|Public|BlueprintCallable) // @ game+0xaa748d0
	void SetPatrolPathEnabled(bool bIsEnabled); // Function AIPatrolPath.AIPatrolPathComponent.SetPatrolPathEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0xaa746a0
	void SetPatrollingMode(enum class EPatrollingMode NewMode); // Function AIPatrolPath.AIPatrolPathComponent.SetPatrollingMode // (Final|Native|Public|BlueprintCallable) // @ game+0xaa747c0
	void RequestRenderPath(); // Function AIPatrolPath.AIPatrolPathComponent.RequestRenderPath // (Final|Native|Public|BlueprintCallable) // @ game+0xaa74420
	void RenderToNextPoint(); // Function AIPatrolPath.AIPatrolPathComponent.RenderToNextPoint // (Final|Native|Public|BlueprintCallable) // @ game+0xaa745c0
	void RenderToNextAndPreviousPoint(); // Function AIPatrolPath.AIPatrolPathComponent.RenderToNextAndPreviousPoint // (Final|Native|Public|BlueprintCallable) // @ game+0xaa74530
	bool RemovePoint(); // Function AIPatrolPath.AIPatrolPathComponent.RemovePoint // (Final|Native|Public|BlueprintCallable) // @ game+0xaa74bb0
	void PropagatePatrolPathPointIndexToDevice(int32_t NewPatrolPathPointIndex); // Function AIPatrolPath.AIPatrolPathComponent.PropagatePatrolPathPointIndexToDevice // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void PropagatePatrolPathIndexToDevice(int32_t NewPatrolPathIndex); // Function AIPatrolPath.AIPatrolPathComponent.PropagatePatrolPathIndexToDevice // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void PostFinishSpawningActor(); // Function AIPatrolPath.AIPatrolPathComponent.PostFinishSpawningActor // (Final|Native|Public|BlueprintCallable) // @ game+0xaa74400
	void PatrolPointReached(struct AFortAthenaPatrolPoint* PathPoint, struct AAIController* Instigator); // Function AIPatrolPath.AIPatrolPathComponent.PatrolPointReached // (Final|Native|Private) // @ game+0xaa73ff0
	void PatrolPointFailedToReach(struct AFortAthenaPatrolPoint* PathPoint, struct AAIController* Instigator); // Function AIPatrolPath.AIPatrolPathComponent.PatrolPointFailedToReach // (Final|Native|Private) // @ game+0xaa741e0
	void PatrolPathStopped(struct AAIController* Instigator); // Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStopped // (Final|Native|Private) // @ game+0xaa73dd0
	void PatrolPathStarted(struct AAIController* Instigator); // Function AIPatrolPath.AIPatrolPathComponent.PatrolPathStarted // (Final|Native|Private) // @ game+0xaa73ee0
	void OnPatrolPathActorAssigned(); // Function AIPatrolPath.AIPatrolPathComponent.OnPatrolPathActorAssigned // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPathExtremitiesChanged(bool bIsStart, bool bIsEnd); // Function AIPatrolPath.AIPatrolPathComponent.OnPathExtremitiesChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnAnyPropertyChanged(); // Function AIPatrolPath.AIPatrolPathComponent.OnAnyPropertyChanged // (Final|Native|Protected) // @ game+0x3982d70
	void NotifyEditorUserOptionChanged(struct TArray<struct FString>& UserOptions); // Function AIPatrolPath.AIPatrolPathComponent.NotifyEditorUserOptionChanged // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x7436410
	bool HasValidPatrolPath(); // Function AIPatrolPath.AIPatrolPathComponent.HasValidPatrolPath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa74e60
	int32_t GetPatrolPathPointIndexFromDevice(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndexFromDevice // (Event|Public|BlueprintEvent|Const) // @ game+0x1b027f0
	int32_t GetPatrolPathPointIndex(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPointIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa74b50
	struct UAIPatrolPathComponent* GetPatrolPathPoint(int32_t InPatrolPathIndex, int32_t InPatrolPathPointIndex); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathPoint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa74be0
	int32_t GetPatrolPathIndexFromDevice(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndexFromDevice // (Event|Public|BlueprintEvent|Const) // @ game+0x1b027f0
	int32_t GetPatrolPathIndex(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa74b80
	enum class EFortCreativePatrolPathGroup GetPatrolPathGroup(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolPathGroup // (Event|Public|BlueprintEvent|Const) // @ game+0x1b027f0
	enum class EPatrollingMode GetPatrollingMode(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrollingMode // (Event|Public|BlueprintEvent|Const) // @ game+0x1b027f0
	struct UNavigationQueryFilter* GetPatrolFilterOptions(); // Function AIPatrolPath.AIPatrolPathComponent.GetPatrolFilterOptions // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool GetNextAvailablePatrolPathIndex(int32_t& NextAvailableIndex); // Function AIPatrolPath.AIPatrolPathComponent.GetNextAvailablePatrolPathIndex // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa74d60
	struct TArray<struct UAIPatrolPathComponent*> GetLinkedPatrolPoints(); // Function AIPatrolPath.AIPatrolPathComponent.GetLinkedPatrolPoints // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa745e0
	void GeneratePathPoints(enum class EFortCreativePatrolPathGroup PatrolPathGroup, bool bGenerationCausedByDuplication); // Function AIPatrolPath.AIPatrolPathComponent.GeneratePathPoints // (Final|Native|Public|BlueprintCallable) // @ game+0xaa749c0
	bool CanNextPointBeReached(); // Function AIPatrolPath.AIPatrolPathComponent.CanNextPointBeReached // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa743d0
};

