// Class MetasoundFrontend.MetaSoundDocumentInterface
// Size: 0x28 (Inherited: 0x28)
struct UMetaSoundDocumentInterface : UInterface {
};

// Class MetasoundFrontend.MetasoundParameterPack
// Size: 0x40 (Inherited: 0x28)
struct UMetasoundParameterPack : UObject {
	char pad_28[0x18]; // 0x28(0x18)

	enum class ESetParamResult SetTrigger(struct FName ParameterName, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetTrigger // (Final|Native|Public|BlueprintCallable) // @ game+0x64c49f0
	enum class ESetParamResult SetString(struct FName ParameterName, struct FString InValue, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetString // (Final|Native|Public|BlueprintCallable) // @ game+0x64c4c00
	enum class ESetParamResult SetInt(struct FName ParameterName, int32_t InValue, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetInt // (Final|Native|Public|BlueprintCallable) // @ game+0x64c51b0
	enum class ESetParamResult SetFloat(struct FName ParameterName, float InValue, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x64c4f00
	enum class ESetParamResult SetBool(struct FName ParameterName, bool InValue, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetBool // (Final|Native|Public|BlueprintCallable) // @ game+0x64c5460
	struct UMetasoundParameterPack* MakeMetasoundParameterPack(); // Function MetasoundFrontend.MetasoundParameterPack.MakeMetasoundParameterPack // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x64c56b0
	bool HasTrigger(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasTrigger // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c3950
	bool HasString(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c3aa0
	bool HasInt(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasInt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c3d40
	bool HasFloat(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c3bf0
	bool HasBool(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasBool // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c3e90
	bool GetTrigger(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetTrigger // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c3fe0
	struct FString GetString(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetString // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c41d0
	int32_t GetInt(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetInt // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c4610
	float GetFloat(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c4430
	bool GetBool(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x64c4800
};

// Class MetasoundFrontend.MetaSoundBuilderDocument
// Size: 0x1f0 (Inherited: 0x28)
struct UMetaSoundBuilderDocument : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FMetasoundFrontendDocument Document; // 0x30(0x1b8)
	ClassPtrProperty MetaSoundUClass; // 0x1e8(0x08)
};

