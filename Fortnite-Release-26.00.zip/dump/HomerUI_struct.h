// Enum HomerUI.EHomerClipEventType
enum class EHomerClipEventType : uint8 {
	Emote = 0,
	Elimination = 1,
	COUNT = 2,
	EHomerClipEventType_MAX = 3
};

