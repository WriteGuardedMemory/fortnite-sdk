// Enum FortniteConversationRuntime.EInteractionRange
enum class EInteractionRange : uint8 {
	Preview = 0,
	Interaction = 1,
	EInteractionRange_MAX = 2
};

// ScriptStruct FortniteConversationRuntime.FortConversationEnterEvent
// Size: 0x08 (Inherited: 0x00)
struct FFortConversationEnterEvent {
	struct APlayerController* PlayerController; // 0x00(0x08)
};

// ScriptStruct FortniteConversationRuntime.FortConversationLeaveEvent
// Size: 0x08 (Inherited: 0x00)
struct FFortConversationLeaveEvent {
	struct APlayerController* PlayerController; // 0x00(0x08)
};

// ScriptStruct FortniteConversationRuntime.FortConversation_Spectator_EnterConversation
// Size: 0x01 (Inherited: 0x00)
struct FFortConversation_Spectator_EnterConversation {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct FortniteConversationRuntime.FortConversation_Spectator_LeaveConversation
// Size: 0x01 (Inherited: 0x00)
struct FFortConversation_Spectator_LeaveConversation {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct FortniteConversationRuntime.FortConversation_SetDialogMarkerClassEvent
// Size: 0x01 (Inherited: 0x00)
struct FFortConversation_SetDialogMarkerClassEvent {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct FortniteConversationRuntime.NPCConversationIndicatorMessage
// Size: 0x08 (Inherited: 0x00)
struct FNPCConversationIndicatorMessage {
	struct UFortNonPlayerConversationParticipantComponent* NPCConversationComponent; // 0x00(0x08)
};

// ScriptStruct FortniteConversationRuntime.FortConversation_NPC_AddIndicator
// Size: 0x08 (Inherited: 0x08)
struct FFortConversation_NPC_AddIndicator : FNPCConversationIndicatorMessage {
};

// ScriptStruct FortniteConversationRuntime.FortConversation_NPC_RemoveIndicator
// Size: 0x08 (Inherited: 0x08)
struct FFortConversation_NPC_RemoveIndicator : FNPCConversationIndicatorMessage {
};

// ScriptStruct FortniteConversationRuntime.ConversationSettingDialogMarkerData
// Size: 0x20 (Inherited: 0x00)
struct FConversationSettingDialogMarkerData {
	struct TSoftClassPtr<UObject> DialogMarkerSoftClass; // 0x00(0x20)
};

// ScriptStruct FortniteConversationRuntime.FortConversationConditionalMessage
// Size: 0x20 (Inherited: 0x00)
struct FFortConversationConditionalMessage {
	struct UFortConversationContextCondition* Condition; // 0x00(0x08)
	struct FText Message; // 0x08(0x18)
};

// ScriptStruct FortniteConversationRuntime.FortConversationNodeConditionalMessages
// Size: 0x10 (Inherited: 0x00)
struct FFortConversationNodeConditionalMessages {
	struct TArray<struct FFortConversationConditionalMessage> Messages; // 0x00(0x10)
};

