// VerseStruct EpicGamesTemporary.SpatialMath_transform
// Size: 0x60 (Inherited: 0x00)
struct FSpatialMath_transform {
	struct FSpatialMath_vector3 __verse_0xA376805D_Scale; // 0x00(0x18)
	char pad_18[0x8]; // 0x18(0x08)
	struct FVerseRotation __verse_0x78C70FF3_Rotation; // 0x20(0x20)
	struct FSpatialMath_vector3 __verse_0x4E05BF15_Translation; // 0x40(0x18)
	char pad_58[0x8]; // 0x58(0x08)
};

// VerseStruct EpicGamesTemporary.SpatialMath_vector2
// Size: 0x10 (Inherited: 0x00)
struct FSpatialMath_vector2 {
	double __verse_0x51F8FD2F_X; // 0x00(0x08)
	double __verse_0x349F4197_Y; // 0x08(0x08)
};

// VerseStruct EpicGamesTemporary.SpatialMath_vector2i
// Size: 0x10 (Inherited: 0x00)
struct FSpatialMath_vector2i {
	int64_t __verse_0x51F8FD2F_X; // 0x00(0x08)
	int64_t __verse_0x349F4197_Y; // 0x08(0x08)
};

// VerseStruct EpicGamesTemporary.SpatialMath_vector3
// Size: 0x18 (Inherited: 0x00)
struct FSpatialMath_vector3 {
	double __verse_0x51F8FD2F_X; // 0x00(0x08)
	double __verse_0x349F4197_Y; // 0x08(0x08)
	double __verse_0xDA30F485_Z; // 0x10(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_L_R
// Size: 0x01 (Inherited: 0x00)
struct Ftuple_L_R {
	char $StructPaddingDummy; // 0x00(0x01)
};

// VerseStruct EpicGamesTemporary.tuple_Lfloat_Mfloat_Mfloat_R
// Size: 0x18 (Inherited: 0x00)
struct Ftuple_Lfloat_Mfloat_Mfloat_R {
	double __verse_0x18E3F084_Elem0; // 0x00(0x08)
	double __verse_0x7D844C3C_Elem1; // 0x08(0x08)
	double __verse_0x932BF92E_Elem2; // 0x10(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lfloat_Mtuple_L_R_Mtuple_L_R_R
// Size: 0x0a (Inherited: 0x00)
struct Ftuple_Lfloat_Mtuple_L_R_Mtuple_L_R_R {
	double __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x08(0x01)
	struct Ftuple_L_R __verse_0x932BF92E_Elem2; // 0x09(0x01)
};

// VerseStruct EpicGamesTemporary.tuple_Lfloat_Mvector2_R
// Size: 0x18 (Inherited: 0x00)
struct Ftuple_Lfloat_Mvector2_R {
	double __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct FSpatialMath_vector2 __verse_0x7D844C3C_Elem1; // 0x08(0x10)
};

// VerseStruct EpicGamesTemporary.tuple_Lfloat_Mvector3_R
// Size: 0x20 (Inherited: 0x00)
struct Ftuple_Lfloat_Mvector3_R {
	double __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct FSpatialMath_vector3 __verse_0x7D844C3C_Elem1; // 0x08(0x18)
};

// VerseStruct EpicGamesTemporary.tuple_Lint_Mvector2i_R
// Size: 0x18 (Inherited: 0x00)
struct Ftuple_Lint_Mvector2i_R {
	int64_t __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct FSpatialMath_vector2i __verse_0x7D844C3C_Elem1; // 0x08(0x10)
};

// VerseStruct EpicGamesTemporary.tuple_Lrotation_Mrotation_Mfloat_R
// Size: 0x48 (Inherited: 0x00)
struct Ftuple_Lrotation_Mrotation_Mfloat_R {
	struct FVerseRotation __verse_0x18E3F084_Elem0; // 0x00(0x20)
	struct FVerseRotation __verse_0x7D844C3C_Elem1; // 0x20(0x20)
	double __verse_0x932BF92E_Elem2; // 0x40(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lrotation_Mrotation_R
// Size: 0x40 (Inherited: 0x00)
struct Ftuple_Lrotation_Mrotation_R {
	struct FVerseRotation __verse_0x18E3F084_Elem0; // 0x00(0x20)
	struct FVerseRotation __verse_0x7D844C3C_Elem1; // 0x20(0x20)
};

// VerseStruct EpicGamesTemporary.tuple_Lrotation_Mtuple_L_R_Mfloat_R
// Size: 0x30 (Inherited: 0x00)
struct Ftuple_Lrotation_Mtuple_L_R_Mfloat_R {
	struct FVerseRotation __verse_0x18E3F084_Elem0; // 0x00(0x20)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	double __verse_0x932BF92E_Elem2; // 0x28(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lrotation_Mtuple_L_R_Mrotation_R
// Size: 0x50 (Inherited: 0x00)
struct Ftuple_Lrotation_Mtuple_L_R_Mrotation_R {
	struct FVerseRotation __verse_0x18E3F084_Elem0; // 0x00(0x20)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x20(0x01)
	char pad_21[0xf]; // 0x21(0x0f)
	struct FVerseRotation __verse_0x932BF92E_Elem2; // 0x30(0x20)
};

// VerseStruct EpicGamesTemporary.tuple_Lrotation_Mtuple_L_R_Mtuple_L_R_R
// Size: 0x22 (Inherited: 0x00)
struct Ftuple_Lrotation_Mtuple_L_R_Mtuple_L_R_R {
	struct FVerseRotation __verse_0x18E3F084_Elem0; // 0x00(0x20)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x20(0x01)
	struct Ftuple_L_R __verse_0x932BF92E_Elem2; // 0x21(0x01)
};

// VerseStruct EpicGamesTemporary.tuple_Lrotation_Mtuple_L_R_Mvector3_R
// Size: 0x40 (Inherited: 0x00)
struct Ftuple_Lrotation_Mtuple_L_R_Mvector3_R {
	struct FVerseRotation __verse_0x18E3F084_Elem0; // 0x00(0x20)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FSpatialMath_vector3 __verse_0x932BF92E_Elem2; // 0x28(0x18)
};

// VerseStruct EpicGamesTemporary.tuple_Ltransform_Mvector3_R
// Size: 0x78 (Inherited: 0x00)
struct Ftuple_Ltransform_Mvector3_R {
	struct FSpatialMath_transform __verse_0x18E3F084_Elem0; // 0x00(0x60)
	struct FSpatialMath_vector3 __verse_0x7D844C3C_Elem1; // 0x60(0x18)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector2_Mfloat_R
// Size: 0x18 (Inherited: 0x00)
struct Ftuple_Lvector2_Mfloat_R {
	struct FSpatialMath_vector2 __verse_0x18E3F084_Elem0; // 0x00(0x10)
	double __verse_0x7D844C3C_Elem1; // 0x10(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector2_Mtuple_L_R_Mfloat_R
// Size: 0x20 (Inherited: 0x00)
struct Ftuple_Lvector2_Mtuple_L_R_Mfloat_R {
	struct FSpatialMath_vector2 __verse_0x18E3F084_Elem0; // 0x00(0x10)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	double __verse_0x932BF92E_Elem2; // 0x18(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector2_Mtuple_L_R_Mtuple_L_R_R
// Size: 0x12 (Inherited: 0x00)
struct Ftuple_Lvector2_Mtuple_L_R_Mtuple_L_R_R {
	struct FSpatialMath_vector2 __verse_0x18E3F084_Elem0; // 0x00(0x10)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x10(0x01)
	struct Ftuple_L_R __verse_0x932BF92E_Elem2; // 0x11(0x01)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector2_Mvector2_Mfloat_R
// Size: 0x28 (Inherited: 0x00)
struct Ftuple_Lvector2_Mvector2_Mfloat_R {
	struct FSpatialMath_vector2 __verse_0x18E3F084_Elem0; // 0x00(0x10)
	struct FSpatialMath_vector2 __verse_0x7D844C3C_Elem1; // 0x10(0x10)
	double __verse_0x932BF92E_Elem2; // 0x20(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector2_Mvector2_R
// Size: 0x20 (Inherited: 0x00)
struct Ftuple_Lvector2_Mvector2_R {
	struct FSpatialMath_vector2 __verse_0x18E3F084_Elem0; // 0x00(0x10)
	struct FSpatialMath_vector2 __verse_0x7D844C3C_Elem1; // 0x10(0x10)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector2i_Mint_R
// Size: 0x18 (Inherited: 0x00)
struct Ftuple_Lvector2i_Mint_R {
	struct FSpatialMath_vector2i __verse_0x18E3F084_Elem0; // 0x00(0x10)
	int64_t __verse_0x7D844C3C_Elem1; // 0x10(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector2i_Mvector2i_R
// Size: 0x20 (Inherited: 0x00)
struct Ftuple_Lvector2i_Mvector2i_R {
	struct FSpatialMath_vector2i __verse_0x18E3F084_Elem0; // 0x00(0x10)
	struct FSpatialMath_vector2i __verse_0x7D844C3C_Elem1; // 0x10(0x10)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector3_Mfloat_R
// Size: 0x20 (Inherited: 0x00)
struct Ftuple_Lvector3_Mfloat_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	double __verse_0x7D844C3C_Elem1; // 0x18(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector3_Mtuple_L_R_Mfloat_R
// Size: 0x28 (Inherited: 0x00)
struct Ftuple_Lvector3_Mtuple_L_R_Mfloat_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	double __verse_0x932BF92E_Elem2; // 0x20(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector3_Mtuple_L_R_Mtuple_L_R_R
// Size: 0x1a (Inherited: 0x00)
struct Ftuple_Lvector3_Mtuple_L_R_Mtuple_L_R_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x18(0x01)
	struct Ftuple_L_R __verse_0x932BF92E_Elem2; // 0x19(0x01)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector3_Mvector3_Mfloat_R
// Size: 0x38 (Inherited: 0x00)
struct Ftuple_Lvector3_Mvector3_Mfloat_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	struct FSpatialMath_vector3 __verse_0x7D844C3C_Elem1; // 0x18(0x18)
	double __verse_0x932BF92E_Elem2; // 0x30(0x08)
};

// VerseStruct EpicGamesTemporary.tuple_Lvector3_Mvector3_R
// Size: 0x30 (Inherited: 0x00)
struct Ftuple_Lvector3_Mvector3_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	struct FSpatialMath_vector3 __verse_0x7D844C3C_Elem1; // 0x18(0x18)
};

