// Class AssembledMeshSystem.AssembledMeshCoordinatorComponent
// Size: 0xa8 (Inherited: 0xa0)
struct UAssembledMeshCoordinatorComponent : UPlayerStateComponent {
	char pad_A0[0x8]; // 0xa0(0x08)

	void OnPlayerStatePawnSet(struct APlayerState* Player, struct APawn* NewPawn, struct APawn* OldPawn); // Function AssembledMeshSystem.AssembledMeshCoordinatorComponent.OnPlayerStatePawnSet // (Final|Native|Private) // @ game+0x52b0360
};

// Class AssembledMeshSystem.AssembledMeshSchema
// Size: 0x1a8 (Inherited: 0x30)
struct UAssembledMeshSchema : UPrimaryDataAsset {
	struct FGameplayTag MeshSchemaTag; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TSoftObjectPtr<UCustomizableObjectInstance> CustomizableObjectInstance; // 0x38(0x20)
	struct TSoftObjectPtr<UCustomizableObject> CustomizableObject; // 0x58(0x20)
	struct TMap<struct FString, struct FString> SelectedIntParams; // 0x78(0x50)
	struct TMap<struct FString, float> SelectedFloatParams; // 0xc8(0x50)
	struct FAssembledMeshAttachmentRules AttachmentRules; // 0x118(0x50)
	struct TSoftClassPtr<UObject> AnimClass; // 0x168(0x20)
	struct FGameplayTagContainer SoundLibraryTags; // 0x188(0x20)
};

// Class AssembledMeshSystem.AssembledMeshUserComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UAssembledMeshUserComponent : UActorComponent {
	char pad_A0[0x10]; // 0xa0(0x10)
	struct TArray<struct UAssembledMeshSchema*> MeshParts; // 0xb0(0x10)
	struct TArray<struct FAssembledComponentReferences> MeshPartComponents; // 0xc0(0x10)
	bool bAssignMeshPartsOnBeginPlay; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)

	void SetMeshPart(struct UAssembledMeshSchema* InMeshPart); // Function AssembledMeshSystem.AssembledMeshUserComponent.SetMeshPart // (Final|Native|Private|BlueprintCallable) // @ game+0x34e0930
	void OnRep_MeshParts(); // Function AssembledMeshSystem.AssembledMeshUserComponent.OnRep_MeshParts // (Final|Native|Private) // @ game+0x52b1b40
	struct UAssembledMeshSchema* GetMeshPart(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GetMeshPart // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x423efc0
	struct USkeletalMeshComponent* GetAttachToComponent(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GetAttachToComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x52b1c50
	void GatherAndAssignAssembledMeshParts(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GatherAndAssignAssembledMeshParts // (Native|Public) // @ game+0x45844a0
	void CustomizationCompleted(int32_t PartIndex); // Function AssembledMeshSystem.AssembledMeshUserComponent.CustomizationCompleted // (Final|Native|Private) // @ game+0x52b1b60
};

