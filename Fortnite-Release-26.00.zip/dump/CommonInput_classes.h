// Class CommonInput.CommonInputActionDomain
// Size: 0x40 (Inherited: 0x30)
struct UCommonInputActionDomain : UDataAsset {
	enum class ECommonInputEventFlowBehavior Behavior; // 0x30(0x04)
	enum class ECommonInputEventFlowBehavior InnerBehavior; // 0x34(0x04)
	bool bUseActionDomainDesiredInputConfig; // 0x38(0x01)
	enum class ECommonInputMode InputMode; // 0x39(0x01)
	enum class EMouseCaptureMode MouseCaptureMode; // 0x3a(0x01)
	char pad_3B[0x5]; // 0x3b(0x05)
};

// Class CommonInput.CommonInputActionDomainTable
// Size: 0x48 (Inherited: 0x30)
struct UCommonInputActionDomainTable : UDataAsset {
	struct TArray<struct UCommonInputActionDomain*> ActionDomains; // 0x30(0x10)
	enum class ECommonInputMode InputMode; // 0x40(0x01)
	enum class EMouseCaptureMode MouseCaptureMode; // 0x41(0x01)
	char pad_42[0x6]; // 0x42(0x06)
};

// Class CommonInput.CommonUIInputData
// Size: 0x78 (Inherited: 0x28)
struct UCommonUIInputData : UObject {
	struct FDataTableRowHandle DefaultClickAction; // 0x28(0x10)
	struct FDataTableRowHandle DefaultBackAction; // 0x38(0x10)
	struct TSoftClassPtr<UObject> DefaultHoldData; // 0x48(0x20)
	struct UInputAction* EnhancedInputClickAction; // 0x68(0x08)
	struct UInputAction* EnhancedInputBackAction; // 0x70(0x08)
};

// Class CommonInput.CommonUIHoldData
// Size: 0x40 (Inherited: 0x28)
struct UCommonUIHoldData : UObject {
	struct FInputHoldData KeyboardAndMouse; // 0x28(0x08)
	struct FInputHoldData Gamepad; // 0x30(0x08)
	struct FInputHoldData Touch; // 0x38(0x08)
};

// Class CommonInput.CommonInputBaseControllerData
// Size: 0xe8 (Inherited: 0x28)
struct UCommonInputBaseControllerData : UObject {
	enum class ECommonInputType InputType; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	struct FName GamepadName; // 0x2c(0x04)
	struct FText GamepadDisplayName; // 0x30(0x18)
	struct FText GamepadCategory; // 0x48(0x18)
	struct FText GamepadPlatformName; // 0x60(0x18)
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping; // 0x78(0x10)
	struct TSoftObjectPtr<UTexture2D> ControllerTexture; // 0x88(0x20)
	struct TSoftObjectPtr<UTexture2D> ControllerButtonMaskTexture; // 0xa8(0x20)
	struct TArray<struct FCommonInputKeyBrushConfiguration> InputBrushDataMap; // 0xc8(0x10)
	struct TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets; // 0xd8(0x10)

	struct TArray<struct FName> GetRegisteredGamepads(); // Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads // (Final|Native|Static|Public) // @ game+0x52f9100
};

// Class CommonInput.CommonInputPlatformSettings
// Size: 0x70 (Inherited: 0x40)
struct UCommonInputPlatformSettings : UPlatformSettings {
	enum class ECommonInputType DefaultInputType; // 0x40(0x01)
	bool bSupportsMouseAndKeyboard; // 0x41(0x01)
	bool bSupportsTouch; // 0x42(0x01)
	bool bSupportsGamepad; // 0x43(0x01)
	struct FName DefaultGamepadName; // 0x44(0x04)
	bool bCanChangeGamepadType; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TArray<struct TSoftClassPtr<UObject>> ControllerData; // 0x50(0x10)
	struct TArray<struct UCommonInputBaseControllerData*> ControllerDataClasses; // 0x60(0x10)
};

// Class CommonInput.CommonInputSettings
// Size: 0x108 (Inherited: 0x30)
struct UCommonInputSettings : UDeveloperSettings {
	struct TSoftClassPtr<UObject> InputData; // 0x30(0x20)
	struct FPerPlatformSettings PlatformInput; // 0x50(0x10)
	struct TMap<struct FName, struct FCommonInputPlatformBaseData> CommonInputPlatformData; // 0x60(0x50)
	bool bEnableInputMethodThrashingProtection; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	int32_t InputMethodThrashingLimit; // 0xb4(0x04)
	double InputMethodThrashingWindowInSeconds; // 0xb8(0x08)
	double InputMethodThrashingCooldownInSeconds; // 0xc0(0x08)
	bool bAllowOutOfFocusDeviceInput; // 0xc8(0x01)
	bool bEnableDefaultInputConfig; // 0xc9(0x01)
	bool bEnableEnhancedInputSupport; // 0xca(0x01)
	char pad_CB[0x5]; // 0xcb(0x05)
	struct TSoftObjectPtr<UCommonInputActionDomainTable> ActionDomainTable; // 0xd0(0x20)
	char pad_F0[0x8]; // 0xf0(0x08)
	struct UCommonUIInputData* InputDataClass; // 0xf8(0x08)
	struct UCommonInputActionDomainTable* ActionDomainTablePtr; // 0x100(0x08)

	bool IsEnhancedInputSupportEnabled(); // Function CommonInput.CommonInputSettings.IsEnhancedInputSupportEnabled // (Final|Native|Static|Public) // @ game+0x52fb400
};

// Class CommonInput.CommonInputSubsystem
// Size: 0x108 (Inherited: 0x30)
struct UCommonInputSubsystem : ULocalPlayerSubsystem {
	char pad_30[0x38]; // 0x30(0x38)
	struct FMulticastInlineDelegate OnInputMethodChanged; // 0x68(0x10)
	int32_t NumberOfInputMethodChangesRecently; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	double LastInputMethodChangeTime; // 0x80(0x08)
	double LastTimeInputMethodThrashingBegan; // 0x88(0x08)
	enum class ECommonInputType LastInputType; // 0x90(0x01)
	enum class ECommonInputType CurrentInputType; // 0x91(0x01)
	char pad_92[0x2]; // 0x92(0x02)
	struct FName GamepadInputType; // 0x94(0x04)
	struct TMap<struct FName, enum class ECommonInputType> CurrentInputLocks; // 0x98(0x50)
	char pad_E8[0x8]; // 0xe8(0x08)
	struct UCommonInputActionDomainTable* ActionDomainTable; // 0xf0(0x08)
	bool bIsGamepadSimulatedClick; // 0xf8(0x01)
	char pad_F9[0xf]; // 0xf9(0x0f)

	bool ShouldShowInputKeys(); // Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52fbc40
	void SetGamepadInputType(struct FName InGamepadInputType); // Function CommonInput.CommonInputSubsystem.SetGamepadInputType // (Final|Native|Public|BlueprintCallable) // @ game+0x52fbcb0
	void SetCurrentInputType(enum class ECommonInputType NewInputType); // Function CommonInput.CommonInputSubsystem.SetCurrentInputType // (Final|Native|Public|BlueprintCallable) // @ game+0x52fbdc0
	bool IsUsingPointerInput(); // Function CommonInput.CommonInputSubsystem.IsUsingPointerInput // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52fbc70
	bool IsInputMethodActive(enum class ECommonInputType InputMethod); // Function CommonInput.CommonInputSubsystem.IsInputMethodActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52fbf40
	enum class ECommonInputType GetDefaultInputType(); // Function CommonInput.CommonInputSubsystem.GetDefaultInputType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52fbeb0
	enum class ECommonInputType GetCurrentInputType(); // Function CommonInput.CommonInputSubsystem.GetCurrentInputType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52fbf20
	struct FName GetCurrentGamepadName(); // Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52fbda0
	void BroadcastInputMethodChanged(); // Function CommonInput.CommonInputSubsystem.BroadcastInputMethodChanged // (Final|Native|Protected) // @ game+0x52fbc20
};

