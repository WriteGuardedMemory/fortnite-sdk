// Class InterchangeEngine.InterchangeBlueprintPipelineBase
// Size: 0xa8 (Inherited: 0xa8)
struct UInterchangeBlueprintPipelineBase : UBlueprint {
};

// Class InterchangeEngine.InterchangeFilePickerBase
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeFilePickerBase : UObject {

	bool ScriptedFilePickerForTranslatorType(enum class EInterchangeTranslatorType TranslatorType, struct FInterchangeFilePickerParameters& Parameters, struct TArray<struct FString>& OutFilenames); // Function InterchangeEngine.InterchangeFilePickerBase.ScriptedFilePickerForTranslatorType // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xba00d10
	bool ScriptedFilePickerForTranslatorAssetType(enum class EInterchangeTranslatorAssetType TranslatorAssetType, struct FInterchangeFilePickerParameters& Parameters, struct TArray<struct FString>& OutFilenames); // Function InterchangeEngine.InterchangeFilePickerBase.ScriptedFilePickerForTranslatorAssetType // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xba01050
};

// Class InterchangeEngine.InterchangePipelineConfigurationBase
// Size: 0x28 (Inherited: 0x28)
struct UInterchangePipelineConfigurationBase : UObject {

	enum class EInterchangePipelineConfigurationDialogResult ScriptedShowScenePipelineConfigurationDialog(struct TArray<struct FInterchangeStackInfo>& PipelineStacks, struct TArray<struct UInterchangePipelineBase*>& OutPipelines, struct UInterchangeSourceData* SourceData); // Function InterchangeEngine.InterchangePipelineConfigurationBase.ScriptedShowScenePipelineConfigurationDialog // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xba01b20
	enum class EInterchangePipelineConfigurationDialogResult ScriptedShowReimportPipelineConfigurationDialog(struct TArray<struct FInterchangeStackInfo>& PipelineStacks, struct TArray<struct UInterchangePipelineBase*>& OutPipelines, struct UInterchangeSourceData* SourceData); // Function InterchangeEngine.InterchangePipelineConfigurationBase.ScriptedShowReimportPipelineConfigurationDialog // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xba017d0
	enum class EInterchangePipelineConfigurationDialogResult ScriptedShowPipelineConfigurationDialog(struct TArray<struct FInterchangeStackInfo>& PipelineStacks, struct TArray<struct UInterchangePipelineBase*>& OutPipelines, struct UInterchangeSourceData* SourceData); // Function InterchangeEngine.InterchangePipelineConfigurationBase.ScriptedShowPipelineConfigurationDialog // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0xba01e70
};

// Class InterchangeEngine.InterchangeProjectSettings
// Size: 0x218 (Inherited: 0x30)
struct UInterchangeProjectSettings : UDeveloperSettings {
	struct FInterchangeContentImportSettings ContentImportSettings; // 0x30(0x120)
	struct FInterchangeImportSettings SceneImportSettings; // 0x150(0x80)
	struct TSoftClassPtr<UObject> FilePickerClass; // 0x1d0(0x20)
	bool bStaticMeshUseSmoothEdgesIfSmoothingInformationIsMissing; // 0x1f0(0x01)
	char pad_1F1[0x7]; // 0x1f1(0x07)
	struct TSoftClassPtr<UObject> GenericPipelineClass; // 0x1f8(0x20)
};

// Class InterchangeEngine.InterchangePythonPipelineBase
// Size: 0xe8 (Inherited: 0xe8)
struct UInterchangePythonPipelineBase : UInterchangePipelineBase {
};

// Class InterchangeEngine.InterchangePythonPipelineAsset
// Size: 0x60 (Inherited: 0x28)
struct UInterchangePythonPipelineAsset : UObject {
	struct TSoftClassPtr<UObject> PythonClass; // 0x28(0x20)
	struct UInterchangePythonPipelineBase* GeneratedPipeline; // 0x48(0x08)
	struct FString JsonDefaultProperties; // 0x50(0x10)
};

// Class InterchangeEngine.InterchangeSceneImportAsset
// Size: 0x30 (Inherited: 0x28)
struct UInterchangeSceneImportAsset : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class InterchangeEngine.InterchangeAssetImportData
// Size: 0xa8 (Inherited: 0x28)
struct UInterchangeAssetImportData : UAssetImportData {
	struct FSoftObjectPath SceneImportAsset; // 0x28(0x18)
	struct FString NodeUniqueID; // 0x40(0x10)
	struct UInterchangeBaseNodeContainer* NodeContainer; // 0x50(0x08)
	struct TArray<struct UObject*> Pipelines; // 0x58(0x10)
	struct UInterchangeBaseNodeContainer* TransientNodeContainer; // 0x68(0x08)
	struct TArray<struct UObject*> TransientPipelines; // 0x70(0x10)
	char pad_80[0x28]; // 0x80(0x28)

	void SetPipelines(struct TArray<struct UObject*>& InPipelines); // Function InterchangeEngine.InterchangeAssetImportData.SetPipelines // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba040a0
	void SetNodeContainer(struct UInterchangeBaseNodeContainer* InNodeContainer); // Function InterchangeEngine.InterchangeAssetImportData.SetNodeContainer // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0xba04350
	struct FString ScriptGetFirstFilename(); // Function InterchangeEngine.InterchangeAssetImportData.ScriptGetFirstFilename // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x42ab020
	struct TArray<struct FString> ScriptExtractFilenames(); // Function InterchangeEngine.InterchangeAssetImportData.ScriptExtractFilenames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3bd2260
	struct TArray<struct FString> ScriptExtractDisplayLabels(); // Function InterchangeEngine.InterchangeAssetImportData.ScriptExtractDisplayLabels // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3bd2260
	struct UInterchangeBaseNode* GetStoredNode(struct FString InNodeUniqueId); // Function InterchangeEngine.InterchangeAssetImportData.GetStoredNode // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba03e90
	struct UInterchangeFactoryBaseNode* GetStoredFactoryNode(struct FString InNodeUniqueId); // Function InterchangeEngine.InterchangeAssetImportData.GetStoredFactoryNode // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba03c30
	struct TArray<struct UObject*> GetPipelines(); // Function InterchangeEngine.InterchangeAssetImportData.GetPipelines // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba04200
	int32_t GetNumberOfPipelines(); // Function InterchangeEngine.InterchangeAssetImportData.GetNumberOfPipelines // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba041c0
	struct UInterchangeBaseNodeContainer* GetNodeContainer(); // Function InterchangeEngine.InterchangeAssetImportData.GetNodeContainer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba045e0
};

// Class InterchangeEngine.InterchangePipelineStackOverride
// Size: 0x38 (Inherited: 0x28)
struct UInterchangePipelineStackOverride : UObject {
	struct TArray<struct FSoftObjectPath> OverridePipelines; // 0x28(0x10)

	void AddPythonPipeline(struct UInterchangePythonPipelineBase* PipelineBase); // Function InterchangeEngine.InterchangePipelineStackOverride.AddPythonPipeline // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xba07640
	void AddPipeline(struct UInterchangePipelineBase* PipelineBase); // Function InterchangeEngine.InterchangePipelineStackOverride.AddPipeline // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xba07640
	void AddBlueprintPipeline(struct UInterchangeBlueprintPipelineBase* PipelineBase); // Function InterchangeEngine.InterchangePipelineStackOverride.AddBlueprintPipeline // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xba07640
};

// Class InterchangeEngine.InterchangeManager
// Size: 0x1e0 (Inherited: 0x28)
struct UInterchangeManager : UObject {
	char pad_28[0xb0]; // 0x28(0xb0)
	struct TSet<ClassPtrProperty> RegisteredTranslatorsClass; // 0xd8(0x50)
	struct TMap<ClassPtrProperty, ClassPtrProperty> RegisteredFactoryClasses; // 0x128(0x50)
	struct TMap<ClassPtrProperty, struct UInterchangeWriterBase*> RegisteredWriters; // 0x178(0x50)
	char pad_1C8[0x18]; // 0x1c8(0x18)

	bool ImportScene(struct FString ContentPath, struct UInterchangeSourceData* SourceData, struct FImportAssetParameters& ImportAssetParameters); // Function InterchangeEngine.InterchangeManager.ImportScene // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba07d40
	bool ImportAsset(struct FString ContentPath, struct UInterchangeSourceData* SourceData, struct FImportAssetParameters& ImportAssetParameters); // Function InterchangeEngine.InterchangeManager.ImportAsset // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba082b0
	struct UObject* GetRegisteredFactoryClass(struct UObject* ClassToMake); // Function InterchangeEngine.InterchangeManager.GetRegisteredFactoryClass // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba07b30
	struct UInterchangeManager* GetInterchangeManagerScripted(); // Function InterchangeEngine.InterchangeManager.GetInterchangeManagerScripted // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xba08730
	bool ExportScene(struct UObject* World, bool bIsAutomated); // Function InterchangeEngine.InterchangeManager.ExportScene // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x966b210
	bool ExportAsset(struct UObject* Asset, bool bIsAutomated); // Function InterchangeEngine.InterchangeManager.ExportAsset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x966b210
	struct UInterchangeSourceData* CreateSourceData(struct FString InFilename); // Function InterchangeEngine.InterchangeManager.CreateSourceData // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0xba07c20
};

// Class InterchangeEngine.InterchangeMeshUtilities
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeMeshUtilities : UObject {
};

