// Class jg_test.jg_testBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct Ujg_testBPLibrary : UBlueprintFunctionLibrary {

	float jg_testSampleFunction(float Param); // Function jg_test.jg_testBPLibrary.jg_testSampleFunction // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xb8ef200
};

