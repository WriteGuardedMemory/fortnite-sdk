// Class FortCoreUI.FortCTAButtonViewModel
// Size: 0x98 (Inherited: 0x68)
struct UFortCTAButtonViewModel : UMVVMViewModelBase {
	struct FText Text; // 0x68(0x18)
	struct FText SecondaryText; // 0x80(0x18)
};

