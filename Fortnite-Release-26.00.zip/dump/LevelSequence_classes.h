// Class LevelSequence.DefaultLevelSequenceInstanceData
// Size: 0xa0 (Inherited: 0x28)
struct UDefaultLevelSequenceInstanceData : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct AActor* TransformOriginActor; // 0x30(0x08)
	char pad_38[0x8]; // 0x38(0x08)
	struct FTransform TransformOrigin; // 0x40(0x60)
};

// Class LevelSequence.AnimSequenceLevelSequenceLink
// Size: 0x50 (Inherited: 0x28)
struct UAnimSequenceLevelSequenceLink : UAssetUserData {
	struct FGuid SkelTrackGuid; // 0x28(0x10)
	struct FSoftObjectPath PathToLevelSequence; // 0x38(0x18)
};

// Class LevelSequence.LevelSequence
// Size: 0x220 (Inherited: 0x68)
struct ULevelSequence : UMovieSceneSequence {
	char pad_68[0x8]; // 0x68(0x08)
	struct UMovieScene* MovieScene; // 0x70(0x08)
	struct FLevelSequenceObjectReferenceMap ObjectReferences; // 0x78(0x50)
	struct FLevelSequenceBindingReferences BindingReferences; // 0xc8(0xf0)
	struct TMap<struct FString, struct FLevelSequenceObject> PossessedObjects; // 0x1b8(0x50)
	ClassPtrProperty DirectorClass; // 0x208(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x210(0x10)

	void RemoveMetaDataByClass(struct UObject* InClass); // Function LevelSequence.LevelSequence.RemoveMetaDataByClass // (Final|Native|Public|BlueprintCallable) // @ game+0x34e0930
	struct UObject* FindOrAddMetaDataByClass(struct UObject* InClass); // Function LevelSequence.LevelSequence.FindOrAddMetaDataByClass // (Final|Native|Public|BlueprintCallable) // @ game+0x3b166e0
	struct UObject* FindMetaDataByClass(struct UObject* InClass); // Function LevelSequence.LevelSequence.FindMetaDataByClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b166e0
	struct UObject* CopyMetaData(struct UObject* InMetaData); // Function LevelSequence.LevelSequence.CopyMetaData // (Final|Native|Public|BlueprintCallable) // @ game+0x3b166e0
};

// Class LevelSequence.LevelSequenceBurnInInitSettings
// Size: 0x28 (Inherited: 0x28)
struct ULevelSequenceBurnInInitSettings : UObject {
};

// Class LevelSequence.LevelSequenceBurnInOptions
// Size: 0x50 (Inherited: 0x28)
struct ULevelSequenceBurnInOptions : UObject {
	bool bUseBurnIn; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FSoftClassPath BurnInClass; // 0x30(0x18)
	struct ULevelSequenceBurnInInitSettings* Settings; // 0x48(0x08)

	void SetBurnIn(struct FSoftClassPath InBurnInClass); // Function LevelSequence.LevelSequenceBurnInOptions.SetBurnIn // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3b17ea0
};

// Class LevelSequence.LevelSequenceActor
// Size: 0x330 (Inherited: 0x290)
struct ALevelSequenceActor : AActor {
	char pad_290[0x18]; // 0x290(0x18)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x2a8(0x20)
	struct ULevelSequencePlayer* SequencePlayer; // 0x2c8(0x08)
	struct ULevelSequence* LevelSequenceAsset; // 0x2d0(0x08)
	struct FLevelSequenceCameraSettings CameraSettings; // 0x2d8(0x02)
	char pad_2DA[0x6]; // 0x2da(0x06)
	struct ULevelSequenceBurnInOptions* BurnInOptions; // 0x2e0(0x08)
	struct UMovieSceneBindingOverrides* BindingOverrides; // 0x2e8(0x08)
	char bAutoPlay : 1; // 0x2f0(0x01)
	char bOverrideInstanceData : 1; // 0x2f0(0x01)
	char bReplicatePlayback : 1; // 0x2f0(0x01)
	char pad_2F0_3 : 5; // 0x2f0(0x01)
	char pad_2F1[0x7]; // 0x2f1(0x07)
	struct UObject* DefaultInstanceData; // 0x2f8(0x08)
	struct ULevelSequenceBurnIn* BurnInInstance; // 0x300(0x08)
	bool bShowBurnin; // 0x308(0x01)
	char pad_309[0x7]; // 0x309(0x07)
	struct FWorldPartitionResolveData WorldPartitionResolveData; // 0x310(0x20)

	void ShowBurnin(); // Function LevelSequence.LevelSequenceActor.ShowBurnin // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b19260
	void SetSequence(struct ULevelSequence* InSequence); // Function LevelSequence.LevelSequenceActor.SetSequence // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b19400
	void SetReplicatePlayback(bool ReplicatePlayback); // Function LevelSequence.LevelSequenceActor.SetReplicatePlayback // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b192f0
	void SetBindingByTag(struct FName BindingTag, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.SetBindingByTag // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3b18d60
	void SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.SetBinding // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3b18fd0
	void ResetBindings(); // Function LevelSequence.LevelSequenceActor.ResetBindings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b18480
	void ResetBinding(struct FMovieSceneObjectBindingID Binding); // Function LevelSequence.LevelSequenceActor.ResetBinding // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b184a0
	void RemoveBindingByTag(struct FName tag, struct AActor* Actor); // Function LevelSequence.LevelSequenceActor.RemoveBindingByTag // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b185b0
	void RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Function LevelSequence.LevelSequenceActor.RemoveBinding // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b18730
	void OnLevelSequenceLoaded__DelegateSignature(); // DelegateFunction LevelSequence.LevelSequenceActor.OnLevelSequenceLoaded__DelegateSignature // (Public|Delegate) // @ game+0x1b027f0
	void HideBurnin(); // Function LevelSequence.LevelSequenceActor.HideBurnin // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b19290
	struct ULevelSequencePlayer* GetSequencePlayer(); // Function LevelSequence.LevelSequenceActor.GetSequencePlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b192b0
	struct ULevelSequence* GetSequence(); // Function LevelSequence.LevelSequenceActor.GetSequence // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b19520
	struct TArray<struct FMovieSceneObjectBindingID> FindNamedBindings(struct FName tag); // Function LevelSequence.LevelSequenceActor.FindNamedBindings // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b181d0
	struct FMovieSceneObjectBindingID FindNamedBinding(struct FName tag); // Function LevelSequence.LevelSequenceActor.FindNamedBinding // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b18340
	void AddBindingByTag(struct FName BindingTag, struct AActor* Actor, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.AddBindingByTag // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b188f0
	void AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.AddBinding // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b18b10
};

// Class LevelSequence.ReplicatedLevelSequenceActor
// Size: 0x330 (Inherited: 0x330)
struct AReplicatedLevelSequenceActor : ALevelSequenceActor {
};

// Class LevelSequence.LevelSequenceAnimSequenceLink
// Size: 0x38 (Inherited: 0x28)
struct ULevelSequenceAnimSequenceLink : UAssetUserData {
	struct TArray<struct FLevelSequenceAnimSequenceLinkItem> AnimSequenceLinks; // 0x28(0x10)
};

// Class LevelSequence.LevelSequenceBurnIn
// Size: 0x370 (Inherited: 0x2a8)
struct ULevelSequenceBurnIn : UUserWidget {
	struct FLevelSequencePlayerSnapshot FrameInformation; // 0x2a8(0xc0)
	struct ALevelSequenceActor* LevelSequenceActor; // 0x368(0x08)

	void SetSettings(struct UObject* InSettings); // Function LevelSequence.LevelSequenceBurnIn.SetSettings // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	struct ULevelSequenceBurnInInitSettings* GetSettingsClass(); // Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass // (RequiredAPI|Native|Event|Public|BlueprintEvent|Const) // @ game+0x3b20b00
};

// Class LevelSequence.LevelSequenceDirector
// Size: 0x38 (Inherited: 0x28)
struct ULevelSequenceDirector : UObject {
	struct ULevelSequencePlayer* Player; // 0x28(0x08)
	int32_t SubSequenceID; // 0x30(0x04)
	int32_t MovieScenePlayerIndex; // 0x34(0x04)

	void OnCreated(); // Function LevelSequence.LevelSequenceDirector.OnCreated // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	struct UMovieSceneSequence* GetSequence(); // Function LevelSequence.LevelSequenceDirector.GetSequence // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b20ec0
	struct FQualifiedFrameTime GetRootSequenceTime(); // Function LevelSequence.LevelSequenceDirector.GetRootSequenceTime // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b21790
	struct FQualifiedFrameTime GetMasterSequenceTime(); // Function LevelSequence.LevelSequenceDirector.GetMasterSequenceTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b21750
	struct FQualifiedFrameTime GetCurrentTime(); // Function LevelSequence.LevelSequenceDirector.GetCurrentTime // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b21570
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding); // Function LevelSequence.LevelSequenceDirector.GetBoundObjects // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b21410
	struct UObject* GetBoundObject(struct FMovieSceneObjectBindingID ObjectBinding); // Function LevelSequence.LevelSequenceDirector.GetBoundObject // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b211f0
	struct TArray<struct AActor*> GetBoundActors(struct FMovieSceneObjectBindingID ObjectBinding); // Function LevelSequence.LevelSequenceDirector.GetBoundActors // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b21090
	struct AActor* GetBoundActor(struct FMovieSceneObjectBindingID ObjectBinding); // Function LevelSequence.LevelSequenceDirector.GetBoundActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b20f70
};

// Class LevelSequence.LegacyLevelSequenceDirectorBlueprint
// Size: 0xa8 (Inherited: 0xa8)
struct ULegacyLevelSequenceDirectorBlueprint : UBlueprint {
};

// Class LevelSequence.LevelSequencePlayer
// Size: 0x5f8 (Inherited: 0x4c8)
struct ULevelSequencePlayer : UMovieSceneSequencePlayer {
	struct FMulticastInlineDelegate OnCameraCut; // 0x4c8(0x10)
	char pad_4D8[0x120]; // 0x4d8(0x120)

	struct UCameraComponent* GetActiveCameraComponent(); // Function LevelSequence.LevelSequencePlayer.GetActiveCameraComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b256d0
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor*& OutActor); // Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3b25750
};

// Class LevelSequence.LevelSequenceProjectSettings
// Size: 0x60 (Inherited: 0x30)
struct ULevelSequenceProjectSettings : UDeveloperSettings {
	bool bDefaultLockEngineToDisplayRate; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FString DefaultDisplayRate; // 0x38(0x10)
	struct FString DefaultTickResolution; // 0x48(0x10)
	enum class EUpdateClockSource DefaultClockSource; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class LevelSequence.LevelSequenceMediaController
// Size: 0x2b8 (Inherited: 0x290)
struct ALevelSequenceMediaController : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct ALevelSequenceActor* Sequence; // 0x298(0x08)
	struct UMediaComponent* MediaComponent; // 0x2a0(0x08)
	float ServerStartTimeSeconds; // 0x2a8(0x04)
	char pad_2AC[0xc]; // 0x2ac(0x0c)

	void SynchronizeToServer(float DesyncThresholdSeconds); // Function LevelSequence.LevelSequenceMediaController.SynchronizeToServer // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b28ba0
	void Play(); // Function LevelSequence.LevelSequenceMediaController.Play // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3b28d80
	void OnRep_ServerStartTimeSeconds(); // Function LevelSequence.LevelSequenceMediaController.OnRep_ServerStartTimeSeconds // (Final|RequiredAPI|Native|Private) // @ game+0x3b28b70
	struct ALevelSequenceActor* GetSequence(); // Function LevelSequence.LevelSequenceMediaController.GetSequence // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b28d60
	struct UMediaComponent* GetMediaComponent(); // Function LevelSequence.LevelSequenceMediaController.GetMediaComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3a2b7f0
};

