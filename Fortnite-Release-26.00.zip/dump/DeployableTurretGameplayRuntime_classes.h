// Class DeployableTurretGameplayRuntime.DeployableTurretLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDeployableTurretLibrary : UBlueprintFunctionLibrary {

	void FireAnalyticsEvent_DeployableTurretSessionEnd(struct UObject* WorldContextObject, struct FUniqueNetIdRepl& TurretOwnerAccountId, struct TArray<struct FFortAnalyticsEventAttribute>& Attributes); // Function DeployableTurretGameplayRuntime.DeployableTurretLibrary.FireAnalyticsEvent_DeployableTurretSessionEnd // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa966300
	float CalculateTargetingLaserScale(struct AActor* TurretActor, struct FTransform& CurrentTurretAimTransform, struct FVector& LaserOrigin, float MaxLaserRange, float DistMult); // Function DeployableTurretGameplayRuntime.DeployableTurretLibrary.CalculateTargetingLaserScale // (Final|BlueprintCosmetic|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa966650
};

