// Enum Chooser.EBoolColumnCellValue
enum class EBoolColumnCellValue : uint8 {
	MatchFalse = 0,
	MatchTrue = 1,
	MatchAny = 2,
	EBoolColumnCellValue_MAX = 3
};

// Enum Chooser.EObjectChooserResultType
enum class EObjectChooserResultType : uint8 {
	ObjectResult = 0,
	ClassResult = 1,
	EObjectChooserResultType_MAX = 2
};

// Enum Chooser.EContextObjectDirection
enum class EContextObjectDirection : uint8 {
	Read = 0,
	Write = 1,
	ReadWrite = 2,
	EContextObjectDirection_MAX = 3
};

// Enum Chooser.EObjectColumnCellValueComparison
enum class EObjectColumnCellValueComparison : uint8 {
	MatchEqual = 0,
	MatchNotEqual = 1,
	MatchAny = 2,
	Modulus = 3,
	EObjectColumnCellValueComparison_MAX = 4
};

// ScriptStruct Chooser.ChooserParameterBase
// Size: 0x08 (Inherited: 0x00)
struct FChooserParameterBase {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Chooser.ChooserParameterBoolBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterBoolBase : FChooserParameterBase {
};

// ScriptStruct Chooser.BoolContextProperty
// Size: 0x30 (Inherited: 0x08)
struct FBoolContextProperty : FChooserParameterBoolBase {
	struct TArray<struct FName> PropertyBindingChain; // 0x08(0x10)
	struct FChooserPropertyBinding Binding; // 0x18(0x18)
};

// ScriptStruct Chooser.ChooserPropertyBinding
// Size: 0x18 (Inherited: 0x00)
struct FChooserPropertyBinding {
	struct TArray<struct FName> PropertyBindingChain; // 0x00(0x10)
	int32_t ContextIndex; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Chooser.ChooserColumnBase
// Size: 0x08 (Inherited: 0x00)
struct FChooserColumnBase {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Chooser.BoolColumn
// Size: 0x28 (Inherited: 0x08)
struct FBoolColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<enum class EBoolColumnCellValue> RowValuesWithAny; // 0x18(0x10)
};

// ScriptStruct Chooser.ChooserEnumPropertyBinding
// Size: 0x18 (Inherited: 0x18)
struct FChooserEnumPropertyBinding : FChooserPropertyBinding {
};

// ScriptStruct Chooser.ChooserObjectPropertyBinding
// Size: 0x18 (Inherited: 0x18)
struct FChooserObjectPropertyBinding : FChooserPropertyBinding {
};

// ScriptStruct Chooser.ChooserStructPropertyBinding
// Size: 0x18 (Inherited: 0x18)
struct FChooserStructPropertyBinding : FChooserPropertyBinding {
};

// ScriptStruct Chooser.ContextObjectTypeBase
// Size: 0x04 (Inherited: 0x00)
struct FContextObjectTypeBase {
	enum class EContextObjectDirection Direction; // 0x00(0x04)
};

// ScriptStruct Chooser.ContextObjectTypeClass
// Size: 0x10 (Inherited: 0x04)
struct FContextObjectTypeClass : FContextObjectTypeBase {
	char pad_4[0x4]; // 0x04(0x04)
	ClassPtrProperty Class; // 0x08(0x08)
};

// ScriptStruct Chooser.ContextObjectTypeStruct
// Size: 0x10 (Inherited: 0x04)
struct FContextObjectTypeStruct : FContextObjectTypeBase {
	char pad_4[0x4]; // 0x04(0x04)
	struct UScriptStruct* Struct; // 0x08(0x08)
};

// ScriptStruct Chooser.ChooserParameterEnumBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterEnumBase : FChooserParameterBase {
};

// ScriptStruct Chooser.EnumContextProperty
// Size: 0x30 (Inherited: 0x08)
struct FEnumContextProperty : FChooserParameterEnumBase {
	struct TArray<struct FName> PropertyBindingChain; // 0x08(0x10)
	struct FChooserEnumPropertyBinding Binding; // 0x18(0x18)
};

// ScriptStruct Chooser.ChooserEnumRowData
// Size: 0x02 (Inherited: 0x00)
struct FChooserEnumRowData {
	bool CompareNotEqual; // 0x00(0x01)
	char Value; // 0x01(0x01)
};

// ScriptStruct Chooser.EnumColumn
// Size: 0x28 (Inherited: 0x08)
struct FEnumColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FChooserEnumRowData> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.ChooserParameterFloatBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterFloatBase : FChooserParameterBase {
};

// ScriptStruct Chooser.FloatContextProperty
// Size: 0x30 (Inherited: 0x08)
struct FFloatContextProperty : FChooserParameterFloatBase {
	struct TArray<struct FName> PropertyBindingChain; // 0x08(0x10)
	struct FChooserPropertyBinding Binding; // 0x18(0x18)
};

// ScriptStruct Chooser.ChooserFloatRangeRowData
// Size: 0x08 (Inherited: 0x00)
struct FChooserFloatRangeRowData {
	float min; // 0x00(0x04)
	float max; // 0x04(0x04)
};

// ScriptStruct Chooser.FloatRangeColumn
// Size: 0x28 (Inherited: 0x08)
struct FFloatRangeColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FChooserFloatRangeRowData> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.ChooserParameterGameplayTagBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterGameplayTagBase : FChooserParameterBase {
};

// ScriptStruct Chooser.GameplayTagContextProperty
// Size: 0x30 (Inherited: 0x08)
struct FGameplayTagContextProperty : FChooserParameterGameplayTagBase {
	struct TArray<struct FName> PropertyBindingChain; // 0x08(0x10)
	struct FChooserPropertyBinding Binding; // 0x18(0x18)
};

// ScriptStruct Chooser.GameplayTagColumn
// Size: 0x30 (Inherited: 0x08)
struct FGameplayTagColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	enum class EGameplayContainerMatchType TagMatchType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FGameplayTagContainer> RowValues; // 0x20(0x10)
};

// ScriptStruct Chooser.ChooserParameterObjectBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterObjectBase : FChooserParameterBase {
};

// ScriptStruct Chooser.ChooserRandomizationContext
// Size: 0x50 (Inherited: 0x00)
struct FChooserRandomizationContext {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct Chooser.ChooserParameterRandomizeBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterRandomizeBase : FChooserParameterBase {
};

// ScriptStruct Chooser.ChooserParameterStructBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterStructBase : FChooserParameterBase {
};

// ScriptStruct Chooser.ChooserEvaluationInputObject
// Size: 0x08 (Inherited: 0x00)
struct FChooserEvaluationInputObject {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Chooser.ChooserEvaluationContext
// Size: 0x50 (Inherited: 0x00)
struct FChooserEvaluationContext {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct Chooser.ObjectChooserBase
// Size: 0x08 (Inherited: 0x00)
struct FObjectChooserBase {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Chooser.AssetChooser
// Size: 0x10 (Inherited: 0x08)
struct FAssetChooser : FObjectChooserBase {
	struct UObject* Asset; // 0x08(0x08)
};

// ScriptStruct Chooser.ClassChooser
// Size: 0x10 (Inherited: 0x08)
struct FClassChooser : FObjectChooserBase {
	ClassPtrProperty Class; // 0x08(0x08)
};

// ScriptStruct Chooser.ObjectContextProperty
// Size: 0x20 (Inherited: 0x08)
struct FObjectContextProperty : FChooserParameterObjectBase {
	struct FChooserObjectPropertyBinding Binding; // 0x08(0x18)
};

// ScriptStruct Chooser.ChooserObjectRowData
// Size: 0x28 (Inherited: 0x00)
struct FChooserObjectRowData {
	enum class EObjectColumnCellValueComparison Comparison; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UObject> Value; // 0x08(0x20)
};

// ScriptStruct Chooser.ObjectColumn
// Size: 0x28 (Inherited: 0x08)
struct FObjectColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FChooserObjectRowData> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.OutputBoolColumn
// Size: 0x28 (Inherited: 0x08)
struct FOutputBoolColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<bool> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.ChooserOutputEnumRowData
// Size: 0x01 (Inherited: 0x00)
struct FChooserOutputEnumRowData {
	char Value; // 0x00(0x01)
};

// ScriptStruct Chooser.OutputEnumColumn
// Size: 0x28 (Inherited: 0x08)
struct FOutputEnumColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FChooserOutputEnumRowData> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.OutputFloatColumn
// Size: 0x28 (Inherited: 0x08)
struct FOutputFloatColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<double> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.StructContextProperty
// Size: 0x20 (Inherited: 0x08)
struct FStructContextProperty : FChooserParameterStructBase {
	struct FChooserStructPropertyBinding Binding; // 0x08(0x18)
};

// ScriptStruct Chooser.OutputStructColumn
// Size: 0x28 (Inherited: 0x08)
struct FOutputStructColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FInstancedStruct> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.RandomizeContextProperty
// Size: 0x20 (Inherited: 0x08)
struct FRandomizeContextProperty : FChooserParameterRandomizeBase {
	struct FChooserPropertyBinding Binding; // 0x08(0x18)
};

// ScriptStruct Chooser.RandomizeColumn
// Size: 0x30 (Inherited: 0x08)
struct FRandomizeColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	float RepeatProbabilityMultiplier; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<float> RowValues; // 0x20(0x10)
};

// ScriptStruct Chooser.EvaluateChooser
// Size: 0x10 (Inherited: 0x08)
struct FEvaluateChooser : FObjectChooserBase {
	struct UChooserTable* Chooser; // 0x08(0x08)
};

