// Class GrindRailRuntime.FortCameraModifier_Grinding
// Size: 0x9c0 (Inherited: 0x48)
struct UFortCameraModifier_Grinding : UCameraModifier {
	struct FScalableFloat bUseNativeCalculation; // 0x48(0x28)
	struct UCurveFloat* BlendInCurve; // 0x70(0x08)
	struct UCurveFloat* BlendOutCurve; // 0x78(0x08)
	struct FScalableFloat SnapToGrindingLocation; // 0x80(0x28)
	struct FScalableFloat ADSAlphaInterpSpeed; // 0xa8(0x28)
	struct FScalableFloat CurrentForwardInterpSpeed; // 0xd0(0x28)
	struct FScalableFloat MaxRightSpeedOldRangeForForward; // 0xf8(0x28)
	struct FScalableFloat MaxRightSpeedNewRangeForForward; // 0x120(0x28)
	struct FScalableFloat MinForwardSpeedOldRangeForForward; // 0x148(0x28)
	struct FScalableFloat MaxForwardSpeedOldRangeForForward; // 0x170(0x28)
	struct FScalableFloat MinForwardSpeedNewRangeForForward; // 0x198(0x28)
	struct FScalableFloat MaxForwardSpeedNewRangeForForward; // 0x1c0(0x28)
	struct FScalableFloat MinUpSpeedOldRangeForForward; // 0x1e8(0x28)
	struct FScalableFloat MaxUpSpeedOldRangeForForward; // 0x210(0x28)
	struct FScalableFloat MinUpSpeedNewRangeForForward; // 0x238(0x28)
	struct FScalableFloat MaxUpSpeedNewRangeForForward; // 0x260(0x28)
	struct FScalableFloat BaseForwardMultiplier; // 0x288(0x28)
	struct FScalableFloat SpeedUpBoosterForwardMultiplier; // 0x2b0(0x28)
	struct FScalableFloat SprintingForwardMultiplier; // 0x2d8(0x28)
	struct FScalableFloat RightSpeedOldRangeForRight; // 0x300(0x28)
	struct FScalableFloat RightSpeedNewRangeForRight; // 0x328(0x28)
	struct FScalableFloat MaxUpSpeedOldRangeForRight; // 0x350(0x28)
	struct FScalableFloat MaxUpSpeedNewRangeForRight; // 0x378(0x28)
	struct FScalableFloat MinForwardSpeedOldRangeForRight; // 0x3a0(0x28)
	struct FScalableFloat MaxForwardSpeedOldRangeForRight; // 0x3c8(0x28)
	struct FScalableFloat MinForwardSpeedNewRangeForRight; // 0x3f0(0x28)
	struct FScalableFloat MaxForwardSpeedNewRangeForRight; // 0x418(0x28)
	struct FScalableFloat BaseRightMultiplier; // 0x440(0x28)
	struct FScalableFloat SpeedUpBoostRightMultiplier; // 0x468(0x28)
	struct FScalableFloat SprintingRightMultiplier; // 0x490(0x28)
	struct FScalableFloat CurrentRightInterpSpeed; // 0x4b8(0x28)
	struct FScalableFloat UpSpeedOldRangeForUp; // 0x4e0(0x28)
	struct FScalableFloat UpSpeedNewRangeForUp; // 0x508(0x28)
	struct FScalableFloat CurrentUpInterpSpeed; // 0x530(0x28)
	struct FScalableFloat BaseUpMultiplier; // 0x558(0x28)
	struct FScalableFloat SpeedUpBoostUpMultiplier; // 0x580(0x28)
	struct FScalableFloat SprintingUpMultiplier; // 0x5a8(0x28)
	struct FScalableFloat MinForwardSpeedOldRangeForLean; // 0x5d0(0x28)
	struct FScalableFloat MaxForwardSpeedOldRangeForLean; // 0x5f8(0x28)
	struct FScalableFloat MinForwardSpeedNewRangeForLean; // 0x620(0x28)
	struct FScalableFloat MaxForwardSpeedNewRangeForLean; // 0x648(0x28)
	struct FScalableFloat MultiplierForMaxNewLeanRange; // 0x670(0x28)
	struct FScalableFloat CurrentLeanInterpSpeed; // 0x698(0x28)
	struct FScalableFloat MaxSpeedOldRangeForFOV; // 0x6c0(0x28)
	struct FScalableFloat MaxSpeedNewRangeForFOV; // 0x6e8(0x28)
	struct FScalableFloat BaseFOV; // 0x710(0x28)
	struct FScalableFloat SpeedUpBoosterFOV; // 0x738(0x28)
	struct FScalableFloat SprintingFOV; // 0x760(0x28)
	struct FScalableFloat CurrentFOVInterpSpeed; // 0x788(0x28)
	struct FScalableFloat DeltaDecreaseInZForOffset; // 0x7b0(0x28)
	struct FScalableFloat CurrentOffsetInterpSpeed; // 0x7d8(0x28)
	struct FScalableFloat StraightnessMultiplierForOffset; // 0x800(0x28)
	struct FScalableFloat FinalOffsetForwardDelta; // 0x828(0x28)
	struct FScalableFloat FinalOffsetUpDelta; // 0x850(0x28)
	struct FScalableFloat FinalOffsetRightDelta; // 0x878(0x28)
	char pad_8A0[0x50]; // 0x8a0(0x50)
	bool bCachedUseNativeCalculation; // 0x8f0(0x01)
	char pad_8F1[0xcf]; // 0x8f1(0xcf)
};

// Class GrindRailRuntime.FortGrindRail
// Size: 0xbd0 (Inherited: 0x978)
struct AFortGrindRail : ABuildingGameplayActor {
	struct FScalableFloat SpeedHardCap; // 0x978(0x28)
	struct FScalableFloat BaseMaxSpeed; // 0x9a0(0x28)
	struct FScalableFloat MaxSpeedIncreaseFromDownwardSlope; // 0x9c8(0x28)
	struct FScalableFloat MaxBaseAcceleration; // 0x9f0(0x28)
	struct FScalableFloat MinBaseAcceleration; // 0xa18(0x28)
	struct FScalableFloat MaxStartSpeed; // 0xa40(0x28)
	struct FScalableFloat MinStartSpeed; // 0xa68(0x28)
	struct FScalableFloat SprintingAcceleration; // 0xa90(0x28)
	struct FScalableFloat SprintingMaxSpeed; // 0xab8(0x28)
	struct TArray<struct USplineMeshComponent*> GrindRailMeshes; // 0xae0(0x10)
	struct TArray<struct FGrindRailBoosterInfo> BoosterInfos; // 0xaf0(0x10)
	struct USplineComponent* SplineComponent; // 0xb00(0x08)
	struct FScalableFloat EnableBoosters; // 0xb08(0x28)
	struct FScalableFloat EnableGrinding; // 0xb30(0x28)
	struct FScalableFloat EnableProjectileCollision; // 0xb58(0x28)
	bool bDisableBooster; // 0xb80(0x01)
	char pad_B81[0xf]; // 0xb81(0x0f)
	struct TSoftObjectPtr<AFortGrindRail> HeadConnectedRail; // 0xb90(0x20)
	struct TSoftObjectPtr<AFortGrindRail> TailConnectedRail; // 0xbb0(0x20)

	void UpdateTransientComponentTransforms(struct TArray<struct USceneComponent*> TransientSceneComponents); // Function GrindRailRuntime.FortGrindRail.UpdateTransientComponentTransforms // (Final|Native|Protected|BlueprintCallable) // @ game+0xa9ea380
	void SetupMeshInfo(struct USplineMeshComponent* SplineMeshComponent); // Function GrindRailRuntime.FortGrindRail.SetupMeshInfo // (Final|Native|Public|BlueprintCallable) // @ game+0xa9eade0
	void OnRep_DisableBooster(); // Function GrindRailRuntime.FortGrindRail.OnRep_DisableBooster // (Final|Native|Protected) // @ game+0xa9ea080
	void OnPlaylistDataReady(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function GrindRailRuntime.FortGrindRail.OnPlaylistDataReady // (Final|Native|Protected|HasOutParms) // @ game+0xa9ea0e0
	void OnPlayerEndedGrinding(struct AFortPlayerPawn* Pawn); // Function GrindRailRuntime.FortGrindRail.OnPlayerEndedGrinding // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayerBeganGrinding(struct AFortPlayerPawn* GrindingPawn); // Function GrindRailRuntime.FortGrindRail.OnPlayerBeganGrinding // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void NativeGetNextPositionToGrind(float DistanceToTravel, float CurrentDistanceAlongSpline, float RightLeanValue, struct FVector& OutNextLocation, bool& bGotToEnd, float& NextLocationOnRail, enum class EGrindRailBoosterMode& BoosterMode, bool& bHitObstacle, bool& bNewRail, float& DistanceAlongNewRail, struct AFortGrindRail*& TheNewRail, bool& bNewRailReverseDirection); // Function GrindRailRuntime.FortGrindRail.NativeGetNextPositionToGrind // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9ea630
	bool IsTipCapped(bool bStartTip); // Function GrindRailRuntime.FortGrindRail.IsTipCapped // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool IsGrindRailEnabled(); // Function GrindRailRuntime.FortGrindRail.IsGrindRailEnabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3a99ad0
	bool HasTailConnection(); // Function GrindRailRuntime.FortGrindRail.HasTailConnection // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9ea4e0
	bool HasHeadConnection(); // Function GrindRailRuntime.FortGrindRail.HasHeadConnection // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9ea510
	bool GetSpeedSettingsOverride(struct FGrindRailSpeedSettings& SpeedSettingsOverride); // Function GrindRailRuntime.FortGrindRail.GetSpeedSettingsOverride // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0xa9ea540
	void GenerateMeshesAlongSpline(); // Function GrindRailRuntime.FortGrindRail.GenerateMeshesAlongSpline // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void ForceClearBoosters(); // Function GrindRailRuntime.FortGrindRail.ForceClearBoosters // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BPRerunConstructionScript(); // Function GrindRailRuntime.FortGrindRail.BPRerunConstructionScript // (Final|Native|Public|BlueprintCallable) // @ game+0x3982d70
	bool AllowSprinting(); // Function GrindRailRuntime.FortGrindRail.AllowSprinting // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3a99ad0
};

// Class GrindRailRuntime.FortGrindRailConnector
// Size: 0x978 (Inherited: 0x978)
struct AFortGrindRailConnector : ABuildingGameplayActor {
};

// Class GrindRailRuntime.FortGrindRailLayerAnimInstance
// Size: 0x730 (Inherited: 0x450)
struct UFortGrindRailLayerAnimInstance : UFortBaseLayerAnimInstance {
	struct UAnimMontage* LancePickaxeMontage; // 0x448(0x08)
	struct UAnimMontage* ScythePickaxeMontage; // 0x450(0x08)
	struct UAnimMontage* FruitCakePickaxeMontage; // 0x458(0x08)
	struct FName LeanAlphaCurve; // 0x460(0x04)
	struct FName MeleeTwistCurve; // 0x464(0x04)
	struct FName InterruptibleCurve; // 0x468(0x04)
	struct TMap<struct FName, float> SlopeWarpingCurveMap; // 0x470(0x50)
	double LeanBwdVelocityThreshold; // 0x4c0(0x08)
	struct FCachedAnimRelevancyData BwdStartCachedData; // 0x4c8(0x14)
	double IsMovingThresholdSpeed; // 0x4e0(0x08)
	double NoisePlayRateSprintSpeedThreshold; // 0x4e8(0x08)
	struct FVector2D NoisePlayRateNormalSpeedInputRange; // 0x4f0(0x10)
	struct FVector2D NoisePlayRateNormalSpeedOutputRange; // 0x500(0x10)
	struct FVector2D NoisePlayRateHighSpeedInputRange; // 0x510(0x10)
	struct FVector2D NoisePlayRateHighSpeedOutputRange; // 0x520(0x10)
	struct FVector2D CombatNoisePlayRateSpeedInputRange; // 0x530(0x10)
	struct FVector2D CombatNoisePlayRateSpeedOutputRange; // 0x540(0x10)
	double CombatNoiseAlphaTargeting; // 0x550(0x08)
	double CombatNoiseAlphaNonTargeting; // 0x558(0x08)
	double RootLeanAlphaInterpSpeed; // 0x560(0x08)
	double SlopeWarpAlphaInterpSpeed; // 0x568(0x08)
	double SplineRelativeAimYawDeltaThreshold; // 0x570(0x08)
	double AimYawSmoothInterpolationCoefficient; // 0x578(0x08)
	double IsSmoothingYawThreshold; // 0x580(0x08)
	double LeanBWDThreshold; // 0x588(0x08)
	double MuteUpperBodyAlphaMeleeWeapon; // 0x590(0x08)
	double MuteUpperBodyAlphaNonMeleeWeapon; // 0x598(0x08)
	double MuteUpperBodyAlphaFruitcakePickaxe; // 0x5a0(0x08)
	double MuteUpperBodyAlphaLanceSyctheOrDualWeild; // 0x5a8(0x08)
	double BaseLeanDirection; // 0x5b0(0x08)
	bool bIsGrinding; // 0x5b8(0x01)
	char pad_5B9[0x7]; // 0x5b9(0x07)
	double CurrentSpeed; // 0x5c0(0x08)
	double LeanDirection; // 0x5c8(0x08)
	bool bSprinting; // 0x5d0(0x01)
	char pad_5D1[0x7]; // 0x5d1(0x07)
	double LeanForward; // 0x5d8(0x08)
	bool bIsWeaponActive; // 0x5e0(0x01)
	char pad_5E1[0x7]; // 0x5e1(0x07)
	struct FRotator SplineRelativeAim; // 0x5e8(0x18)
	struct FFortAnimInput_GrindRail GrindRailInput; // 0x600(0x18)
	struct TWeakObjectPtr<struct UFortPawnComponent_GrindRail> GrindingComponent; // 0x618(0x08)
	struct TWeakObjectPtr<struct UCharacterMovementComponent> MovementComponent; // 0x620(0x08)
	struct TWeakObjectPtr<struct AFortPlayerPawn> FortPlayerPawn; // 0x628(0x08)
	bool bIsFalling; // 0x630(0x01)
	char pad_631[0x7]; // 0x631(0x07)
	double LeanAlpha; // 0x638(0x08)
	bool bIsMoving; // 0x640(0x01)
	bool bShould180Turn; // 0x641(0x01)
	bool bShouldPlayEntry; // 0x642(0x01)
	char pad_643[0x5]; // 0x643(0x05)
	double NoisePlayRate; // 0x648(0x08)
	bool bIsLeanBwd; // 0x650(0x01)
	bool bIsLeft180Turn; // 0x651(0x01)
	bool bShould180TurnAgain; // 0x652(0x01)
	bool bIsTurning; // 0x653(0x01)
	bool bShouldExitLocomotion; // 0x654(0x01)
	bool bIsBoosting; // 0x655(0x01)
	bool bEarlyExitFromEntry; // 0x656(0x01)
	bool bAimFWD; // 0x657(0x01)
	bool bAimBWD; // 0x658(0x01)
	bool bAimLFT; // 0x659(0x01)
	bool bAimRGT; // 0x65a(0x01)
	char pad_65B[0x5]; // 0x65b(0x05)
	double AimFWDDeltaAngleDegrees; // 0x660(0x08)
	double AimBWDDeltaAngleDegrees; // 0x668(0x08)
	double AimLFTDeltaAngleDegrees; // 0x670(0x08)
	double AimRGTDeltaAngleDegrees; // 0x678(0x08)
	double NegativeYaw; // 0x680(0x08)
	struct FRotator MeleeTwistRot; // 0x688(0x18)
	double BwdStartCachedTime; // 0x6a0(0x08)
	double Velocity; // 0x6a8(0x08)
	bool bIsEntryLeft; // 0x6b0(0x01)
	bool bIsEntryFromAir; // 0x6b1(0x01)
	bool bIsEntryRight; // 0x6b2(0x01)
	bool bEnteredFromInteraction; // 0x6b3(0x01)
	char pad_6B4[0x4]; // 0x6b4(0x04)
	double SlopeWarpAlpha; // 0x6b8(0x08)
	double SplineRelativeAimYaw; // 0x6c0(0x08)
	double AimYawSmoothed; // 0x6c8(0x08)
	bool bIsSmoothingYaw; // 0x6d0(0x01)
	char pad_6D1[0x7]; // 0x6d1(0x07)
	double LastSplineRelativeAimYaw; // 0x6d8(0x08)
	double RootLeanAlpha; // 0x6e0(0x08)
	double MuteUpperBodyAlpha; // 0x6e8(0x08)
	bool bIsLanceType; // 0x6f0(0x01)
	bool bWasSprinting; // 0x6f1(0x01)
	bool bStateRuleToBoostLoop; // 0x6f2(0x01)
	bool bIsInAction; // 0x6f3(0x01)
	char pad_6F4[0x4]; // 0x6f4(0x04)
	double CombatNoisePlayRate; // 0x6f8(0x08)
	double CombatNoiseAlpha; // 0x700(0x08)
	bool bIsTwoHandedMelee; // 0x708(0x01)
	bool bShouldCorrectUpperBody; // 0x709(0x01)
	bool bBothHandsDown; // 0x70a(0x01)
	char pad_70B[0x5]; // 0x70b(0x05)
	double TurnInPlaceAnimCurveValue; // 0x710(0x08)
	double TurnRotationAmountCurveValue; // 0x718(0x08)
	char pad_720[0x10]; // 0x720(0x10)

	void HandleBegunGrinding(bool bWasAlreadyGrinding, bool bWasJumpingFromRail, bool bFromInteraction, struct FVector PreviousPlayerLocation); // Function GrindRailRuntime.FortGrindRailLayerAnimInstance.HandleBegunGrinding // (Final|Native|Public|HasDefaults) // @ game+0xa9ebaf0
	void AnimNotify_IdleEnter(struct UAnimNotify* Notify); // Function GrindRailRuntime.FortGrindRailLayerAnimInstance.AnimNotify_IdleEnter // (Final|Native|Public) // @ game+0xa9eba00
	void AnimNotify_EntryExit(struct UAnimNotify* Notify); // Function GrindRailRuntime.FortGrindRailLayerAnimInstance.AnimNotify_EntryExit // (Final|Native|Public) // @ game+0xa9eb910
	void AnimNotify_EntryEnter(struct UAnimNotify* Notify); // Function GrindRailRuntime.FortGrindRailLayerAnimInstance.AnimNotify_EntryEnter // (Final|Native|Public) // @ game+0xa9eba00
};

// Class GrindRailRuntime.GrindRailEditorComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UGrindRailEditorComponent : UActorComponent {
};

// Class GrindRailRuntime.GrindRailMovementControls
// Size: 0x30 (Inherited: 0x30)
struct UGrindRailMovementControls : UFortMovementControls {
};

// Class GrindRailRuntime.FortAthenaAIBotEvaluator_GrindRail
// Size: 0x110 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_GrindRail : UFortAthenaAIBotEvaluator {
	struct FGameplayTag GrindRailTag; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FScalableFloat GrindDuration; // 0xb0(0x28)
	struct FScalableFloat GrindDurationRandomDeviation; // 0xd8(0x28)
	char pad_100[0x10]; // 0x100(0x10)
};

// Class GrindRailRuntime.FortGameplayCueNotifyLoop_Grinding
// Size: 0xb20 (Inherited: 0x990)
struct AFortGameplayCueNotifyLoop_Grinding : AFortGameplayCueNotify_Loop {
	bool bFeetHasLanded; // 0x990(0x01)
	bool bEnableNativeAudioUpdate; // 0x991(0x01)
	char pad_992[0x2]; // 0x992(0x02)
	float ForwardChangedValueThreshold; // 0x994(0x04)
	struct FFortAudioFloatParameter Speed; // 0x998(0x38)
	struct FFortAudioFloatParameter Forward; // 0x9d0(0x38)
	struct FFortAudioFloatParameter Boost; // 0xa08(0x38)
	struct FFortAudioFloatParameter Curve; // 0xa40(0x38)
	struct FFortAudioFloatParameter IsGrinding; // 0xa78(0x38)
	struct FFortAudioFloatParameter IsSlowDown; // 0xab0(0x38)
	struct FName LeanForwardSpeedName; // 0xae8(0x04)
	struct FName TurnOnSpeedFXName; // 0xaec(0x04)
	float TurnOnSpeedFXThreshold; // 0xaf0(0x04)
	struct TWeakObjectPtr<struct UFXSystemComponent> EffectsComponent; // 0xaf4(0x08)
	char pad_AFC[0x4]; // 0xafc(0x04)
	struct UAudioComponent* AudioComponent; // 0xb00(0x08)
	struct AFortPlayerPawn* PlayerPawn; // 0xb08(0x08)
	struct UFortPawnComponent_GrindRail* GrindComponent; // 0xb10(0x08)
	char pad_B18[0x8]; // 0xb18(0x08)

	void OnForwardChanged(bool bNewState); // Function GrindRailRuntime.FortGameplayCueNotifyLoop_Grinding.OnForwardChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void CacheReferences(struct UAudioComponent* InAudioComponent, struct UFXSystemComponent* InEffectsComponent, struct AFortPlayerPawn* InPlayerPawn, struct UFortPawnComponent_GrindRail* InGrindComponent); // Function GrindRailRuntime.FortGameplayCueNotifyLoop_Grinding.CacheReferences // (Final|Native|Public|BlueprintCallable) // @ game+0xa9f04b0
};

// Class GrindRailRuntime.FortPawnComponent_GrindRail
// Size: 0xc28 (Inherited: 0xa8)
struct UFortPawnComponent_GrindRail : UFortPawnComponent {
	char pad_A8[0x10]; // 0xa8(0x10)
	bool bUseNativeSpeedCalculation; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
	struct FMulticastInlineDelegate GrindRailChangedDelegate; // 0xc0(0x10)
	struct FMulticastInlineDelegate BegunGrindingDelegate; // 0xd0(0x10)
	struct FMulticastInlineDelegate HitObstacleWhenGrindingDelegate; // 0xe0(0x10)
	struct FMulticastInlineDelegate BoosterModeChangedDelegate; // 0xf0(0x10)
	struct FMulticastInlineDelegate SprintingStateChangedDelegate; // 0x100(0x10)
	struct FMulticastInlineDelegate EndedGrindingDelegate; // 0x110(0x10)
	float LeanForward; // 0x120(0x04)
	float LeanRight; // 0x124(0x04)
	float BaseLeanRight; // 0x128(0x04)
	float CurrentSpeedAlongSpline; // 0x12c(0x04)
	struct FVector CurrentDirection; // 0x130(0x18)
	enum class EGrindRailBoosterMode CurrentBoosterMode; // 0x148(0x01)
	bool bShould180Turn; // 0x149(0x01)
	bool bShould180TurnAgain; // 0x14a(0x01)
	bool bUseProtoRotation; // 0x14b(0x01)
	char pad_14C[0x4]; // 0x14c(0x04)
	struct FScalableFloat BaseMaxLeanAngularSpeed; // 0x150(0x28)
	struct FScalableFloat BaseLeanInterpSpeed; // 0x178(0x28)
	struct TWeakObjectPtr<struct AFortGrindRail> ReplicatedGrindingRail; // 0x1a0(0x08)
	struct TWeakObjectPtr<struct AFortGrindRail> PreviousGrindingRail; // 0x1a8(0x08)
	struct TWeakObjectPtr<struct AFortGrindRail> GrindingRail; // 0x1b0(0x08)
	struct TWeakObjectPtr<struct AFortGrindRail> NextGrindingRail; // 0x1b8(0x08)
	bool bIsGrinding; // 0x1c0(0x01)
	bool bIsGrindJumping; // 0x1c1(0x01)
	bool bIsSprinting; // 0x1c2(0x01)
	bool bWeaponHolstered; // 0x1c3(0x01)
	bool bJumpInputReady; // 0x1c4(0x01)
	char pad_1C5[0x3]; // 0x1c5(0x03)
	float GrindStartDistance; // 0x1c8(0x04)
	float CurrentDistanceAlongSpline; // 0x1cc(0x04)
	struct FVector NativeLastRailLocation; // 0x1d0(0x18)
	float NativeMaxSpeed; // 0x1e8(0x04)
	char pad_1EC[0x4]; // 0x1ec(0x04)
	struct FRotator GoalRotation; // 0x1f0(0x18)
	bool bIs180Turning; // 0x208(0x01)
	char pad_209[0x3]; // 0x209(0x03)
	float HorizontalSplineAngleDeltaDegrees; // 0x20c(0x04)
	struct FScalableFloat MaxAllowedInclineSplinePitch; // 0x210(0x28)
	struct FScalableFloat MaxAllowedDeclineSplinePitch; // 0x238(0x28)
	struct FScalableFloat MaxAllowedShootingSplinePitch; // 0x260(0x28)
	struct FScalableFloat TurnAngleThreshold; // 0x288(0x28)
	struct FScalableFloat AnimatedTurnDuration; // 0x2b0(0x28)
	struct FScalableFloat BaseGrindRailYawRotationInterpSpeed; // 0x2d8(0x28)
	struct FScalableFloat InclineGrindRailPitchRotationInterpSpeed; // 0x300(0x28)
	struct FScalableFloat DeclineGrindRailPitchRotationInterpSpeed; // 0x328(0x28)
	struct FScalableFloat ShootingGrindRailRotationInterpSpeed; // 0x350(0x28)
	struct FScalableFloat NextGrindRailDetectionOffset; // 0x378(0x28)
	struct FGameplayTag CancelGrindingTag; // 0x3a0(0x04)
	char pad_3A4[0x4]; // 0x3a4(0x04)
	struct FScalableFloat GrindInteractionReentryCooldownTime; // 0x3a8(0x28)
	struct FScalableFloat ForceGrindingFromWalking; // 0x3d0(0x28)
	struct FScalableFloat MinTimeBeforeJumpSinceEntry; // 0x3f8(0x28)
	struct FScalableFloat CancelSprintLeanBackThreshold; // 0x420(0x28)
	struct FScalableFloat WeaponHolsterCooldown; // 0x448(0x28)
	struct FScalableFloat WeaponIsShootingCooldown; // 0x470(0x28)
	struct FScalableFloat GravityForceWhenGoingDown; // 0x498(0x28)
	struct FScalableFloat GravityForceWhenGoingUp; // 0x4c0(0x28)
	struct FScalableFloat BoosterSprintingAccelerationOnSlowDownBooster; // 0x4e8(0x28)
	struct FScalableFloat BoosterAccelerationOnSpeedUpBooster; // 0x510(0x28)
	struct FScalableFloat BoosterSlowDownBoosterDragMultiplier; // 0x538(0x28)
	struct FScalableFloat BoosterSlowDownBoosterGoalSpeed; // 0x560(0x28)
	struct FScalableFloat BoosterMaxSpeed; // 0x588(0x28)
	struct FScalableFloat ShootingMaxSpeedMultiplier; // 0x5b0(0x28)
	struct FScalableFloat AngleForMaxSpeedIncreaseFromDownwardSlope; // 0x5d8(0x28)
	struct FScalableFloat MaxSpeedIncreaseFromDownwardSlope; // 0x600(0x28)
	struct FScalableFloat MaxDragForSpeedSoftCap; // 0x628(0x28)
	struct FScalableFloat SpeedHardCap; // 0x650(0x28)
	struct FScalableFloat SprintingAcceleration; // 0x678(0x28)
	struct FScalableFloat SprintingMaxSpeed; // 0x6a0(0x28)
	struct FScalableFloat SpeedThresholdForTurn; // 0x6c8(0x28)
	struct FScalableFloat TimeToTurnAround; // 0x6f0(0x28)
	struct FScalableFloat SpeedForMaxLeanAcceleration; // 0x718(0x28)
	struct FScalableFloat SpeedForMinLeanAcceleration; // 0x740(0x28)
	struct FScalableFloat MaxLeanAcceleration; // 0x768(0x28)
	struct FScalableFloat MinLeanAcceleration; // 0x790(0x28)
	struct FScalableFloat CanAccelerateByLeaningIntoTurns; // 0x7b8(0x28)
	struct FScalableFloat CurvatureForMaxLeanIntoTurnsAcceleration; // 0x7e0(0x28)
	struct FScalableFloat LeanIntoTurnsMaxAcceleration; // 0x808(0x28)
	struct FScalableFloat IncreasedMaxSpeedFromLeanIntoTurn; // 0x830(0x28)
	struct FScalableFloat UseNewCalculationForSidewaysLeanBoost; // 0x858(0x28)
	struct FScalableFloat SidewaysLeanBoostReductionRate; // 0x880(0x28)
	struct FScalableFloat SpeedForMaxBaseAcceleration; // 0x8a8(0x28)
	struct FScalableFloat SpeedForMinBaseAcceleration; // 0x8d0(0x28)
	struct FScalableFloat MaxBaseAcceleration; // 0x8f8(0x28)
	struct FScalableFloat MinBaseAcceleration; // 0x920(0x28)
	struct FScalableFloat BaseGoalSpeed; // 0x948(0x28)
	struct FScalableFloat BaseMaxSpeed; // 0x970(0x28)
	struct FScalableFloat EnableFriction; // 0x998(0x28)
	struct FScalableFloat BaseGoalDecelerationSpeed; // 0x9c0(0x28)
	struct FScalableFloat FrictionWhenNotLeaning; // 0x9e8(0x28)
	struct FScalableFloat SpeedMultiplierOnHitRailCap; // 0xa10(0x28)
	struct FScalableFloat MinSpeedAfterBouncedOffRailCap; // 0xa38(0x28)
	char pad_A60[0x1c8]; // 0xa60(0x1c8)

	void SetMovementStatus(struct FVector& NewStatus); // Function GrindRailRuntime.FortPawnComponent_GrindRail.SetMovementStatus // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9f7f70
	void SetIsSprinting(bool bNewIsSprinting); // Function GrindRailRuntime.FortPawnComponent_GrindRail.SetIsSprinting // (Final|Native|Public|BlueprintCallable) // @ game+0xa9f7380
	void SetGrindDistanceOnSpline(float NewDistanceOnSpline); // Function GrindRailRuntime.FortPawnComponent_GrindRail.SetGrindDistanceOnSpline // (Final|Native|Public|BlueprintCallable) // @ game+0xa9f7e10
	void SetGrindBaseActor(struct AActor* NewBaseActor); // Function GrindRailRuntime.FortPawnComponent_GrindRail.SetGrindBaseActor // (Final|Native|Public|BlueprintCallable) // @ game+0xa9f7d20
	void ServerUpdateWeaponHolstered(bool bNewHolstered, bool bPlayEquipAnim); // Function GrindRailRuntime.FortPawnComponent_GrindRail.ServerUpdateWeaponHolstered // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0xa9f5d20
	void RemoveMoveIgnoreActors(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.RemoveMoveIgnoreActors // (Final|Native|Protected|BlueprintCallable) // @ game+0xa9f6ab0
	void OnWalkingBaseChanged(struct AFortPawn* Pawn, struct AActor* NewBase); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnWalkingBaseChanged // (Final|Native|Protected) // @ game+0xa9f6380
	void OnRep_IsSprinting(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnRep_IsSprinting // (Final|Native|Protected) // @ game+0xa9f6880
	void OnRep_GrindingRail(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnRep_GrindingRail // (Final|Native|Protected) // @ game+0xa9f69c0
	void OnRep_CurrentBoosterMode(enum class EGrindRailBoosterMode PreviousBoosterMode); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnRep_CurrentBoosterMode // (Final|Native|Protected) // @ game+0xa9f68c0
	void OnReloadInput(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnReloadInput // (Final|Native|Protected) // @ game+0xa9f6540
	void OnMovementModeChanged(struct ACharacter* InCharacter, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnMovementModeChanged // (Final|Native|Protected) // @ game+0xa9f6660
	void OnJumpInput(bool bPressed); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnJumpInput // (Final|Native|Protected) // @ game+0xa9f6570
	void OnIgnoredBuildingEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnIgnoredBuildingEndPlay // (Final|Native|Protected) // @ game+0xa9f5eb0
	void OnBaseMeshReady(struct AFortPlayerPawn* Pawn, struct USkeletalMeshComponent* MeshComponent); // Function GrindRailRuntime.FortPawnComponent_GrindRail.OnBaseMeshReady // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool NativeIsShooting(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.NativeIsShooting // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7960
	bool IsWeaponADS(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.IsWeaponADS // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f71d0
	bool IsWeaponActive(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.IsWeaponActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7200
	bool IsUsingToggleSprint(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.IsUsingToggleSprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7170
	bool IsUsingFirstPersonCamera(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.IsUsingFirstPersonCamera // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f71a0
	bool IsGrinding(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.IsGrinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7270
	void HandleSprintInput(bool bPressed); // Function GrindRailRuntime.FortPawnComponent_GrindRail.HandleSprintInput // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void HandleRailJump(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.HandleRailJump // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void HandleJumpOffEnd(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.HandleJumpOffEnd // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void HandleHitWhenGrinding(struct FHitResult& Hit); // Function GrindRailRuntime.FortPawnComponent_GrindRail.HandleHitWhenGrinding // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void HandleGrindingEndedFromReplication(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.HandleGrindingEndedFromReplication // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void HandleGrindingEnded(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.HandleGrindingEnded // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void HandleGrindingBegun(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.HandleGrindingBegun // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void HandleGrindFinishedAfterJumping(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.HandleGrindFinishedAfterJumping // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool GetWantsToGrind(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetWantsToGrind // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7a80
	float GetSpeedHardCap(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetSpeedHardCap // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7230
	struct FVector GetMovementStatus(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetMovementStatus // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7c60
	float GetLeanForwardSpeedNormalized(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetLeanForwardSpeedNormalized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7bf0
	float GetHorizontalSplineAngleDeltaDegrees(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetHorizontalSplineAngleDeltaDegrees // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7250
	bool GetGrindRequestJump(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetGrindRequestJump // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f79e0
	float GetGrindDistanceOnSpline(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetGrindDistanceOnSpline // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7bc0
	struct AActor* GetGrindBaseActor(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetGrindBaseActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7b20
	void GetCameraOrientedLeanValues(float RawLeanForward, float RawLeanRight, float& OrientedLeanForward, float& OrientedLeanRight); // Function GrindRailRuntime.FortPawnComponent_GrindRail.GetCameraOrientedLeanValues // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9f7690
	void EndGrinding(bool bSetEndMovementMode); // Function GrindRailRuntime.FortPawnComponent_GrindRail.EndGrinding // (Final|Native|Public|BlueprintCallable) // @ game+0xa9f7290
	void DrawDebugHUD(struct AHUD* HUD, struct UCanvas* Canvas); // Function GrindRailRuntime.FortPawnComponent_GrindRail.DrawDebugHUD // (Final|Native|Protected|Const) // @ game+0x48d5980
	bool CanBeginGrinding(); // Function GrindRailRuntime.FortPawnComponent_GrindRail.CanBeginGrinding // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c39ab0
	void CalculateVelocity(float DeltaTime, bool bReplayingMovement, struct FVector& OutVelocity); // Function GrindRailRuntime.FortPawnComponent_GrindRail.CalculateVelocity // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void BeginGrinding(struct AFortGrindRail* GrindRail, float OptionalStartDistance, bool bFromInteraction); // Function GrindRailRuntime.FortPawnComponent_GrindRail.BeginGrinding // (Final|Native|Public|BlueprintCallable) // @ game+0xa9f7470
	bool AttemptDestroyVehicleWhileGrinding(struct AFortAthenaVehicle* Vehicle); // Function GrindRailRuntime.FortPawnComponent_GrindRail.AttemptDestroyVehicleWhileGrinding // (Final|Native|Protected|BlueprintCallable) // @ game+0xa9f58a0
	void AddTemporaryMoveIgnoreActor(struct ABuildingActor* BuildingActor, float IgnoreDuration); // Function GrindRailRuntime.FortPawnComponent_GrindRail.AddTemporaryMoveIgnoreActor // (Final|Native|Protected|BlueprintCallable) // @ game+0xa9f6ad0
	bool AddMoveIgnoreActor(struct ABuildingActor* BuildingActor); // Function GrindRailRuntime.FortPawnComponent_GrindRail.AddMoveIgnoreActor // (Final|Native|Protected|BlueprintCallable) // @ game+0xa9f6c50
};

