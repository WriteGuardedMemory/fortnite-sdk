// Class InfernoRuntime.FortCurieElementAttachHandlerVoxelFire
// Size: 0x90 (Inherited: 0x90)
struct UFortCurieElementAttachHandlerVoxelFire : UFortCurieElementAttachHandlerFire {
};

// Class InfernoRuntime.FortCurieElementAttachConditionHandlerVoxelFire
// Size: 0x40 (Inherited: 0x40)
struct UFortCurieElementAttachConditionHandlerVoxelFire : UFortCurieElementAttachConditionHandlerFire {
};

// Class InfernoRuntime.FortCurieVoxelFirePropagationManagerConfig
// Size: 0x178 (Inherited: 0x130)
struct UFortCurieVoxelFirePropagationManagerConfig : UFortCurieFirePropagationManagerConfig {
	struct FFortCurieVoxelPropagationProperties DefaultPropagationProperties; // 0x130(0x18)
	struct FName PropagationPropertiesRegistry; // 0x148(0x04)
	float PropagationNoiseMinimum; // 0x14c(0x04)
	float PropagationNoiseMaximum; // 0x150(0x04)
	float PropagationSpeedNoiseRange; // 0x154(0x04)
	float PropagationMinimumSpeed; // 0x158(0x04)
	float PropagationMinimumTime; // 0x15c(0x04)
	float VoxelOverlapExpansionFactor; // 0x160(0x04)
	bool bAllowPerMaterialPropagationProperties; // 0x164(0x01)
	char pad_165[0x3]; // 0x165(0x03)
	float ActorPropagationInteractMagnitude; // 0x168(0x04)
	float MovedActorGrassIgnitionDelay; // 0x16c(0x04)
	float MovedActorGrassGridCellZExpansion; // 0x170(0x04)
	float MovedActorGroundTraceZRange; // 0x174(0x04)
};

// Class InfernoRuntime.FortCurieVoxelFirePropagationManager
// Size: 0x680 (Inherited: 0x30)
struct UFortCurieVoxelFirePropagationManager : UFortCurieManagerComponent {
	char pad_30[0x10]; // 0x30(0x10)
	struct FFortCurieVoxelFirePropagationManagerTickFunction PrimaryTickFunction; // 0x40(0x30)
	char pad_70[0x5f8]; // 0x70(0x5f8)
	struct UFortCurieVoxelFirePropagationManagerConfig* InternalManagerConfig; // 0x668(0x08)
	char pad_670[0x10]; // 0x670(0x10)
};

// Class InfernoRuntime.FortCurieVoxelFireDebugParticleDataInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortCurieVoxelFireDebugParticleDataInterface : UInterface {
};

// Class InfernoRuntime.FortCurieVoxelFireDebugNiagaraDataInterface
// Size: 0x38 (Inherited: 0x38)
struct UFortCurieVoxelFireDebugNiagaraDataInterface : UNiagaraDataInterface {
};

// Class InfernoRuntime.FortCurieVoxelFireNativeFXHandlerConfig
// Size: 0x1c0 (Inherited: 0x168)
struct UFortCurieVoxelFireNativeFXHandlerConfig : UFortCurieNativeFXHandlerConfig {
	struct UNiagaraSystem* WorldFireSystem; // 0x168(0x08)
	struct UNiagaraSystem* WorldFireDebugSystem; // 0x170(0x08)
	struct UTextureRenderTarget2D* LandscapeCharRenderTarget; // 0x178(0x08)
	struct UMaterialParameterCollection* MaterialParameterCollection; // 0x180(0x08)
	struct FName PlayerWorldFireSystemLightScalabilityParamName; // 0x188(0x04)
	struct FName LandscapeBiasParameterName; // 0x18c(0x04)
	struct FName LandscapeDivisorParameterName; // 0x190(0x04)
	float LandscapeFireRandomLocationRadius; // 0x194(0x04)
	float MinLandscapeFireSphericalBounds; // 0x198(0x04)
	float MaxLandscapeFireSphericalBounds; // 0x19c(0x04)
	float LandscapeCharInterpSpeed; // 0x1a0(0x04)
	float LandscapeIgnitionParticleMovementSpeed; // 0x1a4(0x04)
	bool bUseVoxelFireAmbientAudio; // 0x1a8(0x01)
	char pad_1A9[0x7]; // 0x1a9(0x07)
	struct USoundBase* StructureFireAmbientSound; // 0x1b0(0x08)
	struct USoundBase* GrassFireAmbientSound; // 0x1b8(0x08)
};

// Class InfernoRuntime.FortCurieVoxelFireNativeFXHandler
// Size: 0x368 (Inherited: 0x40)
struct UFortCurieVoxelFireNativeFXHandler : UFortCurieNativeFXHandler {
	char pad_40[0x30]; // 0x40(0x30)
	struct TSet<struct UFortCurieComponent*> PendingUpdateComponents; // 0x70(0x50)
	struct TSet<struct UFortCurieComponent*> PendingRemoveComponents; // 0xc0(0x50)
	char pad_110[0x50]; // 0x110(0x50)
	struct TArray<struct UFortCurieWorldNiagaraComponent*> WorldFireNiagaraSystems; // 0x160(0x10)
	struct TArray<struct UFortCurieWorldNiagaraComponent*> WorldFireDebugNiagaraSystems; // 0x170(0x10)
	float WorldSystemFireParticleSignificanceRequirement; // 0x180(0x04)
	float WorldSystemIgnitionParticleSignificanceRequirement; // 0x184(0x04)
	float AudioGrassFireSignificanceRequirement; // 0x188(0x04)
	float AudioActorFireSignificanceRequirement; // 0x18c(0x04)
	struct FRandomStream RandomStream; // 0x190(0x08)
	struct FBox GrassFireBounds; // 0x198(0x38)
	float LandscapeCharInterpSpeed; // 0x1d0(0x04)
	float TimeSinceAudioUpdate; // 0x1d4(0x04)
	struct TArray<struct FFortCurieVoxelFireParticleGrassData> CachedFireParticleGrassData; // 0x1d8(0x10)
	struct TArray<struct FFortCurieFireParticleActorData> CachedFireParticleActorData; // 0x1e8(0x10)
	char pad_1F8[0x60]; // 0x1f8(0x60)
	struct TSet<struct FFortSpatialCellIndex> CachedBurningGrassGridCells; // 0x258(0x50)
	struct TMap<struct FFortSpatialCellIndex, struct UAudioComponent*> GrassAudioMap; // 0x2a8(0x50)
	char pad_2F8[0x50]; // 0x2f8(0x50)
	struct TArray<struct UAudioComponent*> PreallocatedAudioComponents; // 0x348(0x10)
	struct FTimerHandle AudioComponentCleanupTimerHandle; // 0x358(0x08)
	double PreviousLandscapeCharTickTime; // 0x360(0x08)

	void OnUserSettingsEffectQualityChanged(); // Function InfernoRuntime.FortCurieVoxelFireNativeFXHandler.OnUserSettingsEffectQualityChanged // (Final|Native|Private) // @ game+0xac33d80
};

// Class InfernoRuntime.FortCurieVoxelFireParticleDataInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortCurieVoxelFireParticleDataInterface : UInterface {
};

// Class InfernoRuntime.FortCurieVoxelFireNiagaraDataInterface
// Size: 0x38 (Inherited: 0x38)
struct UFortCurieVoxelFireNiagaraDataInterface : UNiagaraDataInterface {
};

// Class InfernoRuntime.InfernoCurieVoxelFireAudioParticleDataInterface
// Size: 0x28 (Inherited: 0x28)
struct UInfernoCurieVoxelFireAudioParticleDataInterface : UInterface {
};

// Class InfernoRuntime.InfernoCurieVoxelFireAudioNiagaraDataInterface
// Size: 0x38 (Inherited: 0x38)
struct UInfernoCurieVoxelFireAudioNiagaraDataInterface : UNiagaraDataInterface {
};

