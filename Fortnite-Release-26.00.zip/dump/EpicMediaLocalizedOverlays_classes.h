// Class EpicMediaLocalizedOverlays.EpicMediaDownloadLocalizedOverlays
// Size: 0x90 (Inherited: 0x80)
struct UEpicMediaDownloadLocalizedOverlays : ULocalizedOverlays {
	struct UMediaPlayer* MediaPlayer; // 0x80(0x08)
	char pad_88[0x8]; // 0x88(0x08)
};

