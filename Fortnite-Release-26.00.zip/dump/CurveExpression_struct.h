// Enum CurveExpression.ERemapCurvesExpressionSource
enum class ERemapCurvesExpressionSource : uint8 {
	ExpressionList = 0,
	DataAsset = 1,
	ExpressionMap = 2,
	ERemapCurvesExpressionSource_MAX = 3
};

// ScriptStruct CurveExpression.AnimNode_RemapCurvesBase
// Size: 0x100 (Inherited: 0x10)
struct FAnimNode_RemapCurvesBase : FAnimNode_Base {
	struct FPoseLink SourcePose; // 0x10(0x10)
	enum class ERemapCurvesExpressionSource ExpressionSource; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FCurveExpressionList ExpressionList; // 0x28(0x10)
	struct UCurveExpressionsDataAsset* CurveExpressionsDataAsset; // 0x38(0x08)
	struct TMap<struct FName, struct FString> CurveExpressions; // 0x40(0x50)
	bool bExpressionsImmutable; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct TArray<struct FName> CachedConstantNames; // 0x98(0x10)
	char pad_A8[0x58]; // 0xa8(0x58)
};

// ScriptStruct CurveExpression.CurveExpressionList
// Size: 0x10 (Inherited: 0x00)
struct FCurveExpressionList {
	struct FString AssignmentExpressions; // 0x00(0x10)
};

// ScriptStruct CurveExpression.AnimNode_RemapCurves
// Size: 0x100 (Inherited: 0x100)
struct FAnimNode_RemapCurves : FAnimNode_RemapCurvesBase {
};

// ScriptStruct CurveExpression.AnimNode_RemapCurvesFromMesh
// Size: 0x178 (Inherited: 0x100)
struct FAnimNode_RemapCurvesFromMesh : FAnimNode_RemapCurvesBase {
	struct TWeakObjectPtr<struct USkeletalMeshComponent> SourceMeshComponent; // 0x100(0x08)
	bool bUseAttachedParent; // 0x108(0x01)
	char pad_109[0x6f]; // 0x109(0x6f)
};

