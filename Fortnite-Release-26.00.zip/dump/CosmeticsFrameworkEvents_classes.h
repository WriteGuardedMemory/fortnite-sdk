// Class CosmeticsFrameworkEvents.CosmeticsEventRegistrar
// Size: 0x28 (Inherited: 0x28)
struct UCosmeticsEventRegistrar : UInterface {

	struct FCosmeticsEventHandle RegisterOnCosmeticApplicationCompleted_BP(struct FDelegate& Delegate, int32_t Flags); // Function CosmeticsFrameworkEvents.CosmeticsEventRegistrar.RegisterOnCosmeticApplicationCompleted_BP // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6acce70
};

// Class CosmeticsFrameworkEvents.CosmeticsFinishable
// Size: 0x28 (Inherited: 0x28)
struct UCosmeticsFinishable : UInterface {
};

// Class CosmeticsFrameworkEvents.CosmeticsMeshTarget
// Size: 0x28 (Inherited: 0x28)
struct UCosmeticsMeshTarget : UInterface {
};

// Class CosmeticsFrameworkEvents.CosmeticsStreaming
// Size: 0x28 (Inherited: 0x28)
struct UCosmeticsStreaming : UInterface {
};

