// Class HeadMountedDisplay.HandKeypointConversion
// Size: 0x28 (Inherited: 0x28)
struct UHandKeypointConversion : UBlueprintFunctionLibrary {

	int32_t Conv_HandKeypointToInt32(enum class EHandKeypoint Input); // Function HeadMountedDisplay.HandKeypointConversion.Conv_HandKeypointToInt32 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x31ae7c0
};

// Class HeadMountedDisplay.MotionControllerComponent
// Size: 0x6e0 (Inherited: 0x570)
struct UMotionControllerComponent : UPrimitiveComponent {
	int32_t PlayerIndex; // 0x568(0x04)
	struct FName MotionSource; // 0x56c(0x04)
	char bDisableLowLatencyUpdate : 1; // 0x570(0x01)
	enum class ETrackingStatus CurrentTrackingStatus; // 0x574(0x01)
	bool bDisplayDeviceModel; // 0x575(0x01)
	struct FName DisplayModelSource; // 0x578(0x04)
	char pad_57E_1 : 7; // 0x57e(0x01)
	char pad_57F[0x1]; // 0x57f(0x01)
	struct UStaticMesh* CustomDisplayMesh; // 0x580(0x08)
	struct TArray<struct UMaterialInterface*> DisplayMeshMaterialOverrides; // 0x588(0x10)
	struct UPrimitiveComponent* DisplayComponent; // 0x598(0x08)
	char pad_5A0[0x140]; // 0x5a0(0x140)

	void SetTrackingSource(enum class EControllerHand NewSource); // Function HeadMountedDisplay.MotionControllerComponent.SetTrackingSource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x31b4220
	void SetTrackingMotionSource(struct FName NewSource); // Function HeadMountedDisplay.MotionControllerComponent.SetTrackingMotionSource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x31b40c0
	void SetShowDeviceModel(bool bShowControllerModel); // Function HeadMountedDisplay.MotionControllerComponent.SetShowDeviceModel // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x31b45e0
	void SetDisplayModelSource(struct FName NewDisplayModelSource); // Function HeadMountedDisplay.MotionControllerComponent.SetDisplayModelSource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x31b44e0
	void SetCustomDisplayMesh(struct UStaticMesh* NewDisplayMesh); // Function HeadMountedDisplay.MotionControllerComponent.SetCustomDisplayMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x31b4370
	void SetAssociatedPlayerIndex(int32_t NewPlayer); // Function HeadMountedDisplay.MotionControllerComponent.SetAssociatedPlayerIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x31b3fa0
	void OnMotionControllerUpdated(); // Function HeadMountedDisplay.MotionControllerComponent.OnMotionControllerUpdated // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool IsTracked(); // Function HeadMountedDisplay.MotionControllerComponent.IsTracked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x31b4350
	enum class EControllerHand GetTrackingSource(); // Function HeadMountedDisplay.MotionControllerComponent.GetTrackingSource // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x31b41e0
	float GetParameterValue(struct FName InName, bool& bValueFound); // Function HeadMountedDisplay.MotionControllerComponent.GetParameterValue // (Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x31b3dd0
	bool GetLinearVelocity(struct FVector& OutLinearVelocity); // Function HeadMountedDisplay.MotionControllerComponent.GetLinearVelocity // (Final|RequiredAPI|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x31b3b00
	bool GetLinearAcceleration(struct FVector& OutLinearAcceleration); // Function HeadMountedDisplay.MotionControllerComponent.GetLinearAcceleration // (Final|RequiredAPI|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x31b3900
	struct FVector GetHandJointPosition(int32_t jointIndex, bool& bValueFound); // Function HeadMountedDisplay.MotionControllerComponent.GetHandJointPosition // (Final|RequiredAPI|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x31b3c00
	bool GetAngularVelocity(struct FRotator& OutAngularVelocity); // Function HeadMountedDisplay.MotionControllerComponent.GetAngularVelocity // (Final|RequiredAPI|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x31b3a00
};

