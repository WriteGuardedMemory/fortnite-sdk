// Class CosmeticsFrameworkLoadouts.CosmeticLoadoutItemDefinition
// Size: 0x28 (Inherited: 0x28)
struct UCosmeticLoadoutItemDefinition : UInterface {
};

// Class CosmeticsFrameworkLoadouts.CosmeticLoadoutSchema
// Size: 0x40 (Inherited: 0x30)
struct UCosmeticLoadoutSchema : UPrimaryDataAsset {
	struct TArray<struct UCosmeticLoadoutSlotTemplate*> Slots; // 0x30(0x10)
};

// Class CosmeticsFrameworkLoadouts.CosmeticLoadoutSlotTemplate
// Size: 0xb0 (Inherited: 0x30)
struct UCosmeticLoadoutSlotTemplate : UPrimaryDataAsset {
	struct FGameplayTag SlotTag; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FGameplayTagContainer MetaTags; // 0x38(0x20)
	struct FCosmeticLoadoutSlotRequirements Requirements; // 0x58(0x50)
	struct FPrimaryAssetId DefaultCosmeticItemId; // 0xa8(0x08)

	struct FGameplayTag GetSlotTag(); // Function CosmeticsFrameworkLoadouts.CosmeticLoadoutSlotTemplate.GetSlotTag // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3afc220
	struct FCosmeticLoadoutSlotRequirements GetRequirements(); // Function CosmeticsFrameworkLoadouts.CosmeticLoadoutSlotTemplate.GetRequirements // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f4b370
	struct FGameplayTagContainer GetMetaTags(); // Function CosmeticsFrameworkLoadouts.CosmeticLoadoutSlotTemplate.GetMetaTags // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f4b3d0
	struct FPrimaryAssetId GetDefaultCosmeticItemId(); // Function CosmeticsFrameworkLoadouts.CosmeticLoadoutSlotTemplate.GetDefaultCosmeticItemId // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aedd60
};

