// Class ChronoWeaponGameplayRuntime.AnimInstance_ChronoPanRifle
// Size: 0x360 (Inherited: 0x350)
struct UAnimInstance_ChronoPanRifle : UAnimInstance {
	bool bIsFiring; // 0x348(0x01)
	bool bIsReloading; // 0x349(0x01)
	float MagRotationValue; // 0x34c(0x04)
	struct FName ResetMagRotationCurveName; // 0x350(0x04)
	char pad_35A[0x6]; // 0x35a(0x06)
};

