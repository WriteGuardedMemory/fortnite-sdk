// Class MannequinRuntime.MannequinAnalyticsComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UMannequinAnalyticsComponent : UActorComponent {

	void FireMannequinAnalytics_Interact(struct AFortPlayerController* Controller, enum class ECreativeMannequinAnalyticsInteractType InteractType, struct UFortItemDefinition* Character, struct UFortItemDefinition* BackBling); // Function MannequinRuntime.MannequinAnalyticsComponent.FireMannequinAnalytics_Interact // (Native|Public|BlueprintCallable|Const) // @ game+0xaacece0
};

