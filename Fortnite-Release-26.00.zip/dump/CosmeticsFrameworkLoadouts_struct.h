// ScriptStruct CosmeticsFrameworkLoadouts.CosmeticBackendLoadout
// Size: 0x40 (Inherited: 0x00)
struct FCosmeticBackendLoadout {
	struct TArray<struct FCosmeticBackendLoadoutSlot> Slots; // 0x00(0x10)
	struct FGameplayTagContainer UserTags; // 0x10(0x20)
	struct FString DisplayName; // 0x30(0x10)
};

// ScriptStruct CosmeticsFrameworkLoadouts.CosmeticBackendLoadoutSlot
// Size: 0x20 (Inherited: 0x00)
struct FCosmeticBackendLoadoutSlot {
	struct FPrimaryAssetId SlotTemplate; // 0x00(0x08)
	struct FPrimaryAssetId EquippedItem; // 0x08(0x08)
	struct TArray<struct FCosmeticCustomizationInfo> CustomizationInfo; // 0x10(0x10)
};

// ScriptStruct CosmeticsFrameworkLoadouts.CosmeticCustomizationInfo
// Size: 0x18 (Inherited: 0x00)
struct FCosmeticCustomizationInfo {
	struct FGameplayTag ChannelTag; // 0x00(0x04)
	struct FGameplayTag VariantTag; // 0x04(0x04)
	struct FString AdditionalData; // 0x08(0x10)
};

// ScriptStruct CosmeticsFrameworkLoadouts.CosmeticLoadoutSlotRequirements
// Size: 0x50 (Inherited: 0x00)
struct FCosmeticLoadoutSlotRequirements {
	struct FGameplayTagContainer RequiredTags; // 0x00(0x20)
	struct FGameplayTagContainer DeniedTags; // 0x20(0x20)
	struct TArray<struct TSoftClassPtr<UObject>> AllowedItemClasses; // 0x40(0x10)
};

