// Class HealthShieldRegenRuntime.FortHealthShieldRegenComponent
// Size: 0x198 (Inherited: 0xa0)
struct UFortHealthShieldRegenComponent : UActorComponent {
	char pad_A0[0xf8]; // 0xa0(0xf8)

	void ClearHealthShieldRegen_ShieldListenerDelegates(struct UGameplayAbility* OwningAbility); // Function HealthShieldRegenRuntime.FortHealthShieldRegenComponent.ClearHealthShieldRegen_ShieldListenerDelegates // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xac0abe0
	void ClearHealthShieldRegen_HealthListenerDelegates(struct UGameplayAbility* OwningAbility); // Function HealthShieldRegenRuntime.FortHealthShieldRegenComponent.ClearHealthShieldRegen_HealthListenerDelegates // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xac0a6a0
	void AssignHealthShieldRegen_ShieldListenerDelegates(struct UGameplayAbility* OwningAbility, struct FFortHealthShieldRegen_ShieldDelegateContainer Delegates); // Function HealthShieldRegenRuntime.FortHealthShieldRegenComponent.AssignHealthShieldRegen_ShieldListenerDelegates // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xac0ae50
	void AssignHealthShieldRegen_HealthListenerDelegates(struct UGameplayAbility* OwningAbility, struct FFortHealthShieldRegen_HealthDelegateContainer Delegates); // Function HealthShieldRegenRuntime.FortHealthShieldRegenComponent.AssignHealthShieldRegen_HealthListenerDelegates // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xac0a910
	bool AllowHealthShieldRegen(); // Function HealthShieldRegenRuntime.FortHealthShieldRegenComponent.AllowHealthShieldRegen // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xac0b170
};

