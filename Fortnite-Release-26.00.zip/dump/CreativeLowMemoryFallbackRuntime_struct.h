// ScriptStruct CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackUserFacingText
// Size: 0x48 (Inherited: 0x00)
struct FCreativeLowMemoryFallbackUserFacingText {
	struct FText ExitToMainMenuReasonText; // 0x00(0x18)
	struct FText WarningToastTitle; // 0x18(0x18)
	struct FText WarningToastDescription; // 0x30(0x18)
};

// ScriptStruct CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackFreeMemoryThresholds
// Size: 0x0c (Inherited: 0x00)
struct FCreativeLowMemoryFallbackFreeMemoryThresholds {
	float FallbackMB; // 0x00(0x04)
	float WarningMB; // 0x04(0x04)
	float RecoveryMB; // 0x08(0x04)
};

