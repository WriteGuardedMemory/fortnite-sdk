// Enum EpicMediaBasePlayer.EBaseMediaTerminalErrorReason
enum class EBaseMediaTerminalErrorReason : uint8 {
	Unknown = 0,
	Source = 1,
	Player = 2,
	UCP = 3,
	OpenTimeout = 4,
	EBaseMediaTerminalErrorReason_MAX = 5
};

// Enum EpicMediaBasePlayer.EBaseMediaDelayAction
enum class EBaseMediaDelayAction : uint8 {
	Open = 0,
	Stop = 1,
	Start = 2,
	EBaseMediaDelayAction_MAX = 3
};

// Enum EpicMediaBasePlayer.EBaseMediaPlayerState
enum class EBaseMediaPlayerState : uint8 {
	None = 0,
	Released = 1,
	Stopped = 2,
	Started = 3,
	Opened = 4,
	Error = 5,
	EBaseMediaPlayerState_MAX = 6
};

// ScriptStruct EpicMediaBasePlayer.BaseMediaDelayConfig
// Size: 0x50 (Inherited: 0x00)
struct FBaseMediaDelayConfig {
	char pad_0[0x48]; // 0x00(0x48)
	struct UMediaTexture* MediaTexture; // 0x48(0x08)
};

