// Enum GameplayDebugger.EGameplayDebuggerOverrideMode
enum class EGameplayDebuggerOverrideMode : uint8 {
	Enable = 0,
	Disable = 1,
	UseDefault = 2,
	EGameplayDebuggerOverrideMode_MAX = 3
};

// Enum GameplayDebugger.EGameplayDebuggerShape
enum class EGameplayDebuggerShape : uint8 {
	Invalid = 0,
	Point = 1,
	Segment = 2,
	Box = 3,
	Cone = 4,
	Cylinder = 5,
	Circle = 6,
	Rectangle = 7,
	Capsule = 8,
	Polygon = 9,
	Polyline = 10,
	Arrow = 11,
	EGameplayDebuggerShape_MAX = 12
};

// ScriptStruct GameplayDebugger.GameplayDebuggerDataPackRPCParams
// Size: 0x28 (Inherited: 0x00)
struct FGameplayDebuggerDataPackRPCParams {
	struct FName CategoryName; // 0x00(0x04)
	int32_t DataPackIdx; // 0x04(0x04)
	struct FGameplayDebuggerDataPackHeader Header; // 0x08(0x10)
	struct TArray<char> Data; // 0x18(0x10)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerDataPackHeader
// Size: 0x10 (Inherited: 0x00)
struct FGameplayDebuggerDataPackHeader {
	int16_t DataVersion; // 0x00(0x02)
	int16_t SyncCounter; // 0x02(0x02)
	int32_t DataSize; // 0x04(0x04)
	int32_t DataOffset; // 0x08(0x04)
	char bIsCompressed : 1; // 0x0c(0x01)
	char pad_C_1 : 7; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerCategoryData
// Size: 0x40 (Inherited: 0x00)
struct FGameplayDebuggerCategoryData {
	struct FName CategoryName; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FString> TextLines; // 0x08(0x10)
	struct TArray<struct FGameplayDebuggerShape> Shapes; // 0x18(0x10)
	struct TArray<struct FGameplayDebuggerDataPackHeader> DataPacks; // 0x28(0x10)
	bool bIsEnabled; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerShape
// Size: 0x28 (Inherited: 0x00)
struct FGameplayDebuggerShape {
	struct TArray<struct FVector> ShapeData; // 0x00(0x10)
	struct FString Description; // 0x10(0x10)
	struct FColor Color; // 0x20(0x04)
	enum class EGameplayDebuggerShape Type; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerNetPack
// Size: 0x18 (Inherited: 0x00)
struct FGameplayDebuggerNetPack {
	struct AGameplayDebuggerCategoryReplicator* Owner; // 0x00(0x08)
	struct TArray<struct FGameplayDebuggerCategoryData> SavedData; // 0x08(0x10)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerDebugActor
// Size: 0x10 (Inherited: 0x00)
struct FGameplayDebuggerDebugActor {
	struct TWeakObjectPtr<struct AActor> Actor; // 0x00(0x08)
	struct FName ActorName; // 0x08(0x04)
	int16_t SyncCounter; // 0x0c(0x02)
	char pad_E[0x2]; // 0x0e(0x02)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerVisLogSync
// Size: 0x10 (Inherited: 0x00)
struct FGameplayDebuggerVisLogSync {
	struct FString DeviceIDs; // 0x00(0x10)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerInputConfig
// Size: 0x30 (Inherited: 0x00)
struct FGameplayDebuggerInputConfig {
	struct FString ConfigName; // 0x00(0x10)
	struct FKey Key; // 0x10(0x18)
	char bModShift : 1; // 0x28(0x01)
	char bModCtrl : 1; // 0x28(0x01)
	char bModAlt : 1; // 0x28(0x01)
	char bModCmd : 1; // 0x28(0x01)
	char pad_28_4 : 4; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerCategoryConfig
// Size: 0x30 (Inherited: 0x00)
struct FGameplayDebuggerCategoryConfig {
	struct FString CategoryName; // 0x00(0x10)
	int32_t SlotIdx; // 0x10(0x04)
	enum class EGameplayDebuggerOverrideMode ActiveInGame; // 0x14(0x01)
	enum class EGameplayDebuggerOverrideMode ActiveInSimulate; // 0x15(0x01)
	enum class EGameplayDebuggerOverrideMode Hidden; // 0x16(0x01)
	char pad_17[0x1]; // 0x17(0x01)
	char bOverrideSlotIdx : 1; // 0x18(0x01)
	char pad_18_1 : 7; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FGameplayDebuggerInputConfig> InputHandlers; // 0x20(0x10)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerExtensionConfig
// Size: 0x28 (Inherited: 0x00)
struct FGameplayDebuggerExtensionConfig {
	struct FString ExtensionName; // 0x00(0x10)
	enum class EGameplayDebuggerOverrideMode UseExtension; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct TArray<struct FGameplayDebuggerInputConfig> InputHandlers; // 0x18(0x10)
};

// ScriptStruct GameplayDebugger.GameplayDebuggerPlayerData
// Size: 0x18 (Inherited: 0x00)
struct FGameplayDebuggerPlayerData {
	struct UGameplayDebuggerLocalController* Controller; // 0x00(0x08)
	struct UInputComponent* InputComponent; // 0x08(0x08)
	struct AGameplayDebuggerCategoryReplicator* Replicator; // 0x10(0x08)
};

