// Class GeometryFramework.MeshCommandChangeTarget
// Size: 0x28 (Inherited: 0x28)
struct UMeshCommandChangeTarget : UInterface {
};

// Class GeometryFramework.MeshReplacementCommandChangeTarget
// Size: 0x28 (Inherited: 0x28)
struct UMeshReplacementCommandChangeTarget : UInterface {
};

// Class GeometryFramework.MeshVertexCommandChangeTarget
// Size: 0x28 (Inherited: 0x28)
struct UMeshVertexCommandChangeTarget : UInterface {
};

// Class GeometryFramework.BaseDynamicMeshComponent
// Size: 0x610 (Inherited: 0x5a0)
struct UBaseDynamicMeshComponent : UMeshComponent {
	char pad_5A0[0x20]; // 0x5a0(0x20)
	bool bExplicitShowWireframe; // 0x5c0(0x01)
	char pad_5C1[0x3]; // 0x5c1(0x03)
	struct FLinearColor WireframeColor; // 0x5c4(0x10)
	enum class EDynamicMeshComponentColorOverrideMode ColorMode; // 0x5d4(0x01)
	char pad_5D5[0x3]; // 0x5d5(0x03)
	struct FColor ConstantColor; // 0x5d8(0x04)
	enum class EDynamicMeshVertexColorTransformMode ColorSpaceMode; // 0x5dc(0x01)
	bool bEnableFlatShading; // 0x5dd(0x01)
	bool bEnableViewModeOverrides; // 0x5de(0x01)
	char pad_5DF[0x1]; // 0x5df(0x01)
	struct UMaterialInterface* OverrideRenderMaterial; // 0x5e0(0x08)
	struct UMaterialInterface* SecondaryRenderMaterial; // 0x5e8(0x08)
	char pad_5F0[0x1]; // 0x5f0(0x01)
	bool bEnableRayTracing; // 0x5f1(0x01)
	char pad_5F2[0x6]; // 0x5f2(0x06)
	struct TArray<struct UMaterialInterface*> BaseMaterials; // 0x5f8(0x10)
	char pad_608[0x8]; // 0x608(0x08)

	void SetViewModeOverridesEnabled(bool bEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetViewModeOverridesEnabled // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fad50
	void SetVertexColorSpaceTransformMode(enum class EDynamicMeshVertexColorTransformMode NewMode); // Function GeometryFramework.BaseDynamicMeshComponent.SetVertexColorSpaceTransformMode // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fb050
	void SetShadowsEnabled(bool bEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetShadowsEnabled // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fae40
	void SetSecondaryRenderMaterial(struct UMaterialInterface* Material); // Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryRenderMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fa920
	void SetSecondaryBuffersVisibility(bool bSetVisible); // Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryBuffersVisibility // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fa7e0
	void SetOverrideRenderMaterial(struct UMaterialInterface* Material); // Function GeometryFramework.BaseDynamicMeshComponent.SetOverrideRenderMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fac30
	void SetEnableWireframeRenderPass(bool bEnable); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableWireframeRenderPass // (Native|Public|BlueprintCallable) // @ game+0xb7fb380
	void SetEnableRaytracing(bool bSetEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableRaytracing // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fa6f0
	void SetEnableFlatShading(bool bEnable); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableFlatShading // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7faf60
	void SetConstantOverrideColor(struct FColor NewColor); // Function GeometryFramework.BaseDynamicMeshComponent.SetConstantOverrideColor // (RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xb7fb180
	void SetColorOverrideMode(enum class EDynamicMeshComponentColorOverrideMode NewMode); // Function GeometryFramework.BaseDynamicMeshComponent.SetColorOverrideMode // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fb290
	bool HasOverrideRenderMaterial(int32_t K); // Function GeometryFramework.BaseDynamicMeshComponent.HasOverrideRenderMaterial // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7fab10
	bool GetViewModeOverridesEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetViewModeOverridesEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7fad20
	enum class EDynamicMeshVertexColorTransformMode GetVertexColorSpaceTransformMode(); // Function GeometryFramework.BaseDynamicMeshComponent.GetVertexColorSpaceTransformMode // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x74cec00
	bool GetShadowsEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetShadowsEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x74ce7e0
	struct UMaterialInterface* GetSecondaryRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryRenderMaterial // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7fa8d0
	bool GetSecondaryBuffersVisibility(); // Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryBuffersVisibility // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x74cddc0
	struct UMaterialInterface* GetOverrideRenderMaterial(int32_t MaterialIndex); // Function GeometryFramework.BaseDynamicMeshComponent.GetOverrideRenderMaterial // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7faa10
	bool GetFlatShadingEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetFlatShadingEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7faf30
	bool GetEnableWireframeRenderPass(); // Function GeometryFramework.BaseDynamicMeshComponent.GetEnableWireframeRenderPass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x74cee20
	bool GetEnableRaytracing(); // Function GeometryFramework.BaseDynamicMeshComponent.GetEnableRaytracing // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7fa6c0
	struct UDynamicMesh* GetDynamicMesh(); // Function GeometryFramework.BaseDynamicMeshComponent.GetDynamicMesh // (Native|Public|BlueprintCallable) // @ game+0xb7fb470
	struct FColor GetConstantOverrideColor(); // Function GeometryFramework.BaseDynamicMeshComponent.GetConstantOverrideColor // (Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7fb140
	enum class EDynamicMeshComponentColorOverrideMode GetColorOverrideMode(); // Function GeometryFramework.BaseDynamicMeshComponent.GetColorOverrideMode // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7fb260
	void ClearSecondaryRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.ClearSecondaryRenderMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fa900
	void ClearOverrideRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.ClearOverrideRenderMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fac10
};

// Class GeometryFramework.DynamicMeshComponent
// Size: 0x870 (Inherited: 0x610)
struct UDynamicMeshComponent : UBaseDynamicMeshComponent {
	struct UDynamicMesh* MeshObject; // 0x610(0x08)
	char pad_618[0x138]; // 0x618(0x138)
	enum class EDynamicMeshComponentTangentsMode TangentsType; // 0x750(0x01)
	char pad_751[0x3f]; // 0x751(0x3f)
	enum class ECollisionTraceFlag CollisionType; // 0x790(0x01)
	bool bUseAsyncCooking; // 0x791(0x01)
	bool bEnableComplexCollision; // 0x792(0x01)
	bool bDeferCollisionUpdates; // 0x793(0x01)
	char pad_794[0x4]; // 0x794(0x04)
	struct UBodySetup* MeshBodySetup; // 0x798(0x08)
	char pad_7A0[0x38]; // 0x7a0(0x38)
	struct FKAggregateGeom AggGeom; // 0x7d8(0x78)
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // 0x850(0x10)
	char pad_860[0x10]; // 0x860(0x10)

	bool ValidateMaterialSlots(bool bCreateIfMissing, bool bDeleteExtraSlots); // Function GeometryFramework.DynamicMeshComponent.ValidateMaterialSlots // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb800020
	void UpdateCollision(bool bOnlyIfPending); // Function GeometryFramework.DynamicMeshComponent.UpdateCollision // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7ffa60
	void SetTangentsType(enum class EDynamicMeshComponentTangentsMode NewTangentsType); // Function GeometryFramework.DynamicMeshComponent.SetTangentsType // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7fff20
	void SetDynamicMesh(struct UDynamicMesh* NewMesh); // Function GeometryFramework.DynamicMeshComponent.SetDynamicMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb8006a0
	void SetDeferredCollisionUpdatesEnabled(bool bEnabled, bool bImmediateUpdate); // Function GeometryFramework.DynamicMeshComponent.SetDeferredCollisionUpdatesEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7ffb50
	void SetComplexAsSimpleCollisionEnabled(bool bEnabled, bool bImmediateUpdate); // Function GeometryFramework.DynamicMeshComponent.SetComplexAsSimpleCollisionEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7ffd00
	void NotifyMeshVertexAttributesModified(bool bPositions, bool bNormals, bool bUVs, bool bColors); // Function GeometryFramework.DynamicMeshComponent.NotifyMeshVertexAttributesModified // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb800390
	void NotifyMeshModified(); // Function GeometryFramework.DynamicMeshComponent.NotifyMeshModified // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb800680
	enum class EDynamicMeshComponentTangentsMode GetTangentsTypePure(); // Function GeometryFramework.DynamicMeshComponent.GetTangentsTypePure // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7ffef0
	enum class EDynamicMeshComponentTangentsMode GetTangentsType(); // Function GeometryFramework.DynamicMeshComponent.GetTangentsType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7ffef0
	void EnableComplexAsSimpleCollision(); // Function GeometryFramework.DynamicMeshComponent.EnableComplexAsSimpleCollision // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7ffe80
	void ConfigureMaterialSet(struct TArray<struct UMaterialInterface*>& NewMaterialSet); // Function GeometryFramework.DynamicMeshComponent.ConfigureMaterialSet // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb800230
};

// Class GeometryFramework.DynamicMeshActor
// Size: 0x2a8 (Inherited: 0x290)
struct ADynamicMeshActor : AActor {
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0x290(0x08)
	bool bEnableComputeMeshPool; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
	struct UDynamicMeshPool* DynamicMeshPool; // 0x2a0(0x08)

	bool ReleaseComputeMesh(struct UDynamicMesh* Mesh); // Function GeometryFramework.DynamicMeshActor.ReleaseComputeMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb804160
	void ReleaseAllComputeMeshes(); // Function GeometryFramework.DynamicMeshActor.ReleaseAllComputeMeshes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb804120
	struct UDynamicMeshComponent* GetDynamicMeshComponent(); // Function GeometryFramework.DynamicMeshActor.GetDynamicMeshComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x35cd9c0
	struct UDynamicMeshPool* GetComputeMeshPool(); // Function GeometryFramework.DynamicMeshActor.GetComputeMeshPool // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb8043b0
	void FreeAllComputeMeshes(); // Function GeometryFramework.DynamicMeshActor.FreeAllComputeMeshes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb8040c0
	struct UDynamicMesh* AllocateComputeMesh(); // Function GeometryFramework.DynamicMeshActor.AllocateComputeMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb804340
};

// Class GeometryFramework.DynamicMeshGenerator
// Size: 0x28 (Inherited: 0x28)
struct UDynamicMeshGenerator : UObject {
};

// Class GeometryFramework.DynamicMesh
// Size: 0xb0 (Inherited: 0x28)
struct UDynamicMesh : UObject {
	char pad_28[0x48]; // 0x28(0x48)
	struct FMulticastInlineDelegate MeshModifiedBPEvent; // 0x70(0x10)
	char pad_80[0x20]; // 0x80(0x20)
	struct UDynamicMeshGenerator* MeshGenerator; // 0xa0(0x08)
	bool bEnableMeshGenerator; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)

	struct UDynamicMesh* ResetToCube(); // Function GeometryFramework.DynamicMesh.ResetToCube // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb804da0
	struct UDynamicMesh* Reset(); // Function GeometryFramework.DynamicMesh.Reset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb804e20
	bool IsEmpty(); // Function GeometryFramework.DynamicMesh.IsEmpty // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb804d70
	int32_t GetTriangleCount(); // Function GeometryFramework.DynamicMesh.GetTriangleCount // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb804d40
};

// Class GeometryFramework.DynamicMeshPool
// Size: 0x48 (Inherited: 0x28)
struct UDynamicMeshPool : UObject {
	struct TArray<struct UDynamicMesh*> CachedMeshes; // 0x28(0x10)
	struct TArray<struct UDynamicMesh*> AllCreatedMeshes; // 0x38(0x10)

	void ReturnMesh(struct UDynamicMesh* Mesh); // Function GeometryFramework.DynamicMeshPool.ReturnMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb8051e0
	void ReturnAllMeshes(); // Function GeometryFramework.DynamicMeshPool.ReturnAllMeshes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb8051c0
	struct UDynamicMesh* RequestMesh(); // Function GeometryFramework.DynamicMeshPool.RequestMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb805390
	void FreeAllMeshes(); // Function GeometryFramework.DynamicMeshPool.FreeAllMeshes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb805160
};

