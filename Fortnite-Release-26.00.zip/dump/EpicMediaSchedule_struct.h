// Enum EpicMediaSchedule.EEpicMediaScheduleRepeat
enum class EEpicMediaScheduleRepeat : uint8 {
	None = 0,
	Hourly = 1,
	Daily = 2,
	EEpicMediaScheduleRepeat_MAX = 3
};

// ScriptStruct EpicMediaSchedule.EpicMediaScheduleScheduleEntryHourly
// Size: 0x28 (Inherited: 0x00)
struct FEpicMediaScheduleScheduleEntryHourly {
	int32_t Minutes; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString VUID; // 0x08(0x10)
	int32_t DurationSeconds; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct ULevelSequence* Sequence; // 0x20(0x08)
};

// ScriptStruct EpicMediaSchedule.EpicMediaScheduleScheduleEntryDaily
// Size: 0x28 (Inherited: 0x00)
struct FEpicMediaScheduleScheduleEntryDaily {
	int32_t Hours; // 0x00(0x04)
	int32_t Minutes; // 0x04(0x04)
	struct FString VUID; // 0x08(0x10)
	int32_t DurationSeconds; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct ULevelSequence* Sequence; // 0x20(0x08)
};

// ScriptStruct EpicMediaSchedule.EpicMediaScheduleScheduleEntryAbsolute
// Size: 0x30 (Inherited: 0x00)
struct FEpicMediaScheduleScheduleEntryAbsolute {
	struct FString IsoStartTime; // 0x00(0x10)
	struct FString VUID; // 0x10(0x10)
	int32_t DurationSeconds; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct ULevelSequence* Sequence; // 0x28(0x08)
};

// ScriptStruct EpicMediaSchedule.EpicMediaScheduleScheduleInfo
// Size: 0x28 (Inherited: 0x00)
struct FEpicMediaScheduleScheduleInfo {
	struct FDateTime StartTime; // 0x00(0x08)
	struct FTimespan RelativeStartTime; // 0x08(0x08)
	struct FString VUID; // 0x10(0x10)
	struct ULevelSequence* Sequence; // 0x20(0x08)
};

