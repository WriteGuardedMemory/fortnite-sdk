// ScriptStruct CosmeticsFrameworkModifiers.SoftModifierClassPtr
// Size: 0x20 (Inherited: 0x00)
struct FSoftModifierClassPtr {
	struct TSoftClassPtr<UObject> SoftClass; // 0x00(0x20)
};

