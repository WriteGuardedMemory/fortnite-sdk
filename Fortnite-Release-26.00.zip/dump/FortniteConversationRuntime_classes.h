// Class FortniteConversationRuntime.FortConversationMarkerInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortConversationMarkerInterface : UInterface {
};

// Class FortniteConversationRuntime.FortConversationParticipantComponent
// Size: 0x1a0 (Inherited: 0x1a0)
struct UFortConversationParticipantComponent : UConversationParticipantComponent {
};

// Class FortniteConversationRuntime.FortConversationContextCondition
// Size: 0x28 (Inherited: 0x28)
struct UFortConversationContextCondition : UObject {

	bool DoesContextPass(struct FConversationContext& Context); // Function FortniteConversationRuntime.FortConversationContextCondition.DoesContextPass // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xa8215e0
};

// Class FortniteConversationRuntime.FortConversationContextCondition_ParticipantHasCID
// Size: 0x40 (Inherited: 0x28)
struct UFortConversationContextCondition_ParticipantHasCID : UFortConversationContextCondition {
	struct FGameplayTag ParticipantID; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FSoftObjectPath> AllowedCIDs; // 0x30(0x10)
};

// Class FortniteConversationRuntime.FortConversationContextCondition_ParticipantHasMetaTag
// Size: 0x30 (Inherited: 0x28)
struct UFortConversationContextCondition_ParticipantHasMetaTag : UFortConversationContextCondition {
	struct FGameplayTag ParticipantID; // 0x28(0x04)
	struct FGameplayTag MetaTag; // 0x2c(0x04)
};

// Class FortniteConversationRuntime.FortConversationContextCondition_ParticipantHasOwnedTag
// Size: 0x30 (Inherited: 0x28)
struct UFortConversationContextCondition_ParticipantHasOwnedTag : UFortConversationContextCondition {
	struct FGameplayTag ParticipantID; // 0x28(0x04)
	struct FGameplayTag OwnedTag; // 0x2c(0x04)
};

// Class FortniteConversationRuntime.FortConversationContextCondition_ParticipantControllerMeetsRequirement
// Size: 0x38 (Inherited: 0x28)
struct UFortConversationContextCondition_ParticipantControllerMeetsRequirement : UFortConversationContextCondition {
	struct FGameplayTag ParticipantID; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct UFortControllerRequirement* Requirement; // 0x30(0x08)
};

// Class FortniteConversationRuntime.FortConversationContextConditionHelpers
// Size: 0x28 (Inherited: 0x28)
struct UFortConversationContextConditionHelpers : UBlueprintFunctionLibrary {

	bool GetMessageForContext(struct FFortConversationNodeConditionalMessages& Messages, struct FConversationContext& Context, struct FText& OutText); // Function FortniteConversationRuntime.FortConversationContextConditionHelpers.GetMessageForContext // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0xa821c10
};

// Class FortniteConversationRuntime.FortConversationParamLibrary
// Size: 0x28 (Inherited: 0x28)
struct UFortConversationParamLibrary : UBlueprintFunctionLibrary {

	bool ExtractConversationParameterValue(struct TArray<struct FConversationNodeParameterPair>& ConversationParameters, struct FString DesiredParameterName, struct FString& ParameterValueOut); // Function FortniteConversationRuntime.FortConversationParamLibrary.ExtractConversationParameterValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa822050
};

// Class FortniteConversationRuntime.FortniteConversationGlobals
// Size: 0x28 (Inherited: 0x28)
struct UFortniteConversationGlobals : UObject {
};

// Class FortniteConversationRuntime.FortPlayerConversationComponent
// Size: 0x360 (Inherited: 0x1a0)
struct UFortPlayerConversationComponent : UFortConversationParticipantComponent {
	struct TArray<struct UFortNonPlayerConversationParticipantComponent*> ConversationParticipantsInRange; // 0x1a0(0x10)
	float GreetSphereRadius; // 0x1b0(0x04)
	float IconVisibilityRadius; // 0x1b4(0x04)
	float AbortConversationRange; // 0x1b8(0x04)
	struct FGameplayTag RidingOnActorTag; // 0x1bc(0x04)
	float RidingOnActorRangeMultiplierSquared; // 0x1c0(0x04)
	char pad_1C4[0x3c]; // 0x1c4(0x3c)
	struct TSet<struct UFortNonPlayerConversationParticipantComponent*> IndicatedNPCConversationComponents; // 0x200(0x50)
	char pad_250[0x8]; // 0x250(0x08)
	bool bMoveShouldAbortConversation; // 0x258(0x01)
	char pad_259[0x107]; // 0x259(0x107)

	void RequestServerAbortConversationWithParticipant(struct UFortNonPlayerConversationParticipantComponent* Participant); // Function FortniteConversationRuntime.FortPlayerConversationComponent.RequestServerAbortConversationWithParticipant // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0xa823280
	void RequestServerAbortConversation(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.RequestServerAbortConversation // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x73de110
	void HandleWeaponEquipped(struct AFortWeapon* NewWeapon, struct AFortWeapon* PrevWeapon); // Function FortniteConversationRuntime.FortPlayerConversationComponent.HandleWeaponEquipped // (Final|Native|Private) // @ game+0x48d5980
	void HandleViewTargetChanged(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.HandleViewTargetChanged // (Final|Native|Private) // @ game+0xa822f90
	void HandleFollowedPlayerChanged(struct AFortPlayerControllerSpectating* SpectatingPC, struct AFortPlayerState* FollowedPlayerState); // Function FortniteConversationRuntime.FortPlayerConversationComponent.HandleFollowedPlayerChanged // (Final|Native|Private) // @ game+0xa822fb0
	void HandleDBNOChanged(struct AFortPawn* Pawn, bool bIsDBNO); // Function FortniteConversationRuntime.FortPlayerConversationComponent.HandleDBNOChanged // (Final|Native|Private) // @ game+0x7438c10
	void ClientSpectatorOpenUI(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.ClientSpectatorOpenUI // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x73d1900
	void ClientSpectatorCloseUI(); // Function FortniteConversationRuntime.FortPlayerConversationComponent.ClientSpectatorCloseUI // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x530e010
	void ClientReceiveConversationGiftUINotification(struct FGiftUINotificationInfo ConversationGiftUINotification); // Function FortniteConversationRuntime.FortPlayerConversationComponent.ClientReceiveConversationGiftUINotification // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xa823160
};

