// Class CRD_HSRuntime.FortAthenaMutator_HenchmanSpawner
// Size: 0x498 (Inherited: 0x490)
struct AFortAthenaMutator_HenchmanSpawner : AFortAthenaMutator_GameModeBase {
	char pad_490[0x8]; // 0x490(0x08)
};

