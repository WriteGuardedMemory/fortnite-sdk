// Class FortSoundCueTemplates.FortSoundCueTemplateBase
// Size: 0x560 (Inherited: 0x560)
struct UFortSoundCueTemplateBase : USoundCueTemplate {
};

// Class FortSoundCueTemplates.EmoteBase
// Size: 0x560 (Inherited: 0x560)
struct UEmoteBase : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.EmoteFoley
// Size: 0x560 (Inherited: 0x560)
struct UEmoteFoley : UEmoteBase {
};

// Class FortSoundCueTemplates.EmoteMusic
// Size: 0x560 (Inherited: 0x560)
struct UEmoteMusic : UEmoteBase {
};

// Class FortSoundCueTemplates.EmoteMusic3P
// Size: 0x560 (Inherited: 0x560)
struct UEmoteMusic3P : UEmoteBase {
};

// Class FortSoundCueTemplates.PlayerFoleyBase
// Size: 0x560 (Inherited: 0x560)
struct UPlayerFoleyBase : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PlayerFoley
// Size: 0x560 (Inherited: 0x560)
struct UPlayerFoley : UPlayerFoleyBase {
};

// Class FortSoundCueTemplates.FootstepFoley
// Size: 0x560 (Inherited: 0x560)
struct UFootstepFoley : UPlayerFoley {
};

// Class FortSoundCueTemplates.FortSoundCueTemplateDefaults
// Size: 0x90 (Inherited: 0x30)
struct UFortSoundCueTemplateDefaults : UDataAsset {
	struct USoundClass* SoundClass; // 0x30(0x08)
	struct USoundAttenuation* Attenuation; // 0x38(0x08)
	struct USoundConcurrency* Concurrency; // 0x40(0x08)
	float VolumeMultiplier; // 0x48(0x04)
	float PitchMultiplier; // 0x4c(0x04)
	struct TArray<struct FFortSubmixPair> SubmixSends; // 0x50(0x10)
	struct TArray<struct FFortBusPair> PreEffectBusSends; // 0x60(0x10)
	struct TArray<struct FFortBusPair> PostEffectBusSends; // 0x70(0x10)
	struct USoundWave* LicensedTrackAlternative; // 0x80(0x08)
	struct USoundSubmixBase* LicensedSubmix; // 0x88(0x08)
};

// Class FortSoundCueTemplates.FortSoundCueTemplateDefaultSettings
// Size: 0x80 (Inherited: 0x30)
struct UFortSoundCueTemplateDefaultSettings : UDataAsset {
	struct TMap<struct UFortSoundCueTemplateBase*, struct UFortSoundCueTemplateDefaults*> TemplateDefaults; // 0x30(0x50)

	struct UFortSoundCueTemplateDefaults* GetSettingsForTemplateType(struct UFortSoundCueTemplateBase* TemplateType); // Function FortSoundCueTemplates.FortSoundCueTemplateDefaultSettings.GetSettingsForTemplateType // (Final|Native|Public) // @ game+0xb551af0
};

// Class FortSoundCueTemplates.FortSoundCueTemplateSettings
// Size: 0x50 (Inherited: 0x30)
struct UFortSoundCueTemplateSettings : UDeveloperSettings {
	struct TSoftObjectPtr<UFortSoundCueTemplateDefaultSettings> DefaultTemplateSettings; // 0x30(0x20)

	struct UFortSoundCueTemplateDefaults* GetDefaultSettingsForTemplateType(struct UFortSoundCueTemplateBase* TemplateType); // Function FortSoundCueTemplates.FortSoundCueTemplateSettings.GetDefaultSettingsForTemplateType // (Final|Native|Public|Const) // @ game+0xb551d40
};

// Class FortSoundCueTemplates.FortSoundCueTemplateSimple
// Size: 0x560 (Inherited: 0x560)
struct UFortSoundCueTemplateSimple : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.GliderThrustSCTDefaults
// Size: 0x1f0 (Inherited: 0x90)
struct UGliderThrustSCTDefaults : UFortSoundCueTemplateDefaults {
	struct FGliderThrustData Forward; // 0x90(0x58)
	struct FGliderThrustData Sideways; // 0xe8(0x58)
	struct FGliderThrustData Backwards; // 0x140(0x58)
	struct FGliderThrustData AnyDirection; // 0x198(0x58)
};

// Class FortSoundCueTemplates.GliderThrustLoop
// Size: 0x560 (Inherited: 0x560)
struct UGliderThrustLoop : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.GliderThrustStart
// Size: 0x560 (Inherited: 0x560)
struct UGliderThrustStart : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.GliderOpen
// Size: 0x560 (Inherited: 0x560)
struct UGliderOpen : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.GliderClose
// Size: 0x560 (Inherited: 0x560)
struct UGliderClose : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.MusicPack
// Size: 0x560 (Inherited: 0x560)
struct UMusicPack : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PhysicsStateSCTDefaults
// Size: 0x2d8 (Inherited: 0x90)
struct UPhysicsStateSCTDefaults : UFortSoundCueTemplateDefaults {
	struct FName SpeedParameterName; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FPhysicsStateData Rolling; // 0x98(0x90)
	struct FPhysicsStateData Sliding; // 0x128(0x90)
	struct FPhysicsStateData Flying; // 0x1b8(0x90)
	struct FPhysicsStateData Floating; // 0x248(0x90)
};

// Class FortSoundCueTemplates.PhysicsStateLoop
// Size: 0x560 (Inherited: 0x560)
struct UPhysicsStateLoop : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PhysicsImpactSCTDefaults
// Size: 0x1a0 (Inherited: 0x90)
struct UPhysicsImpactSCTDefaults : UFortSoundCueTemplateDefaults {
	struct FName ImpactTypeParameterName; // 0x90(0x04)
	struct FName StrengthParameterName; // 0x94(0x04)
	struct FPhysicsImpactData Light; // 0x98(0x58)
	struct FPhysicsImpactData Medium; // 0xf0(0x58)
	struct FPhysicsImpactData Heavy; // 0x148(0x58)
};

// Class FortSoundCueTemplates.PhysicsImpact
// Size: 0x560 (Inherited: 0x560)
struct UPhysicsImpact : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PickaxeSCTDefaults
// Size: 0xb0 (Inherited: 0x90)
struct UPickaxeSCTDefaults : UFortSoundCueTemplateDefaults {
	struct USoundAttenuation* CloseAttenuation; // 0x90(0x08)
	struct USoundAttenuation* DistantAttenuation; // 0x98(0x08)
	struct TArray<struct USoundWave*> DistantVariations; // 0xa0(0x10)
};

// Class FortSoundCueTemplates.PickaxeBase
// Size: 0x560 (Inherited: 0x560)
struct UPickaxeBase : UFortSoundCueTemplateBase {
};

// Class FortSoundCueTemplates.PickaxeSwing
// Size: 0x560 (Inherited: 0x560)
struct UPickaxeSwing : UPickaxeBase {
};

// Class FortSoundCueTemplates.PickaxeReady
// Size: 0x560 (Inherited: 0x560)
struct UPickaxeReady : UPickaxeBase {
};

// Class FortSoundCueTemplates.PickaxeImpactEnemy
// Size: 0x560 (Inherited: 0x560)
struct UPickaxeImpactEnemy : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.PlayerFoleyDefaults
// Size: 0xd8 (Inherited: 0x90)
struct UPlayerFoleyDefaults : UFortSoundCueTemplateDefaults {
	struct USoundClass* LocalPlayerSoundClass; // 0x90(0x08)
	struct USoundClass* TeammateSoundClass; // 0x98(0x08)
	struct USoundClass* HostileSoundClass; // 0xa0(0x08)
	struct USoundAttenuation* LocalPlayerAttenuation; // 0xa8(0x08)
	struct USoundAttenuation* AboveAttenuation; // 0xb0(0x08)
	struct USoundAttenuation* BelowAttenuation; // 0xb8(0x08)
	struct USoundAttenuation* ParallelAttenuation; // 0xc0(0x08)
	struct TArray<struct FDistanceDatum> ElevationCrossfadeDistances; // 0xc8(0x10)
};

// Class FortSoundCueTemplates.WeaponLowAmmo
// Size: 0x560 (Inherited: 0x560)
struct UWeaponLowAmmo : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.WeaponOutOfAmmo
// Size: 0x560 (Inherited: 0x560)
struct UWeaponOutOfAmmo : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.WeaponReloadStart
// Size: 0x560 (Inherited: 0x560)
struct UWeaponReloadStart : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.WeaponReloadInsert
// Size: 0x560 (Inherited: 0x560)
struct UWeaponReloadInsert : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.WeaponReloadEnd
// Size: 0x560 (Inherited: 0x560)
struct UWeaponReloadEnd : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.WeaponTargetingStart
// Size: 0x560 (Inherited: 0x560)
struct UWeaponTargetingStart : UFortSoundCueTemplateSimple {
};

// Class FortSoundCueTemplates.WeaponTargetingEnd
// Size: 0x560 (Inherited: 0x560)
struct UWeaponTargetingEnd : UFortSoundCueTemplateSimple {
};

