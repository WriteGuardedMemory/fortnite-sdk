// Class DynamicRollTablesRuntime.FortControllerComponent_DynamicRollPlayerComponent
// Size: 0x1a0 (Inherited: 0xa8)
struct UFortControllerComponent_DynamicRollPlayerComponent : UFortControllerComponent {
	struct UFortGamestateComponent_DynamicRollTableManager* AssociatedManagerClass; // 0xa8(0x08)
	struct FScalableFloat Enabled; // 0xb0(0x28)
	struct UFortGamestateComponent_DynamicRollTableManager* TableManager; // 0xd8(0x08)
	char pad_E0[0x64]; // 0xe0(0x64)
	struct FRandomStream SeededRNG; // 0x144(0x08)
	char pad_14C[0x54]; // 0x14c(0x54)

	struct TArray<struct FFortDynamicRollResult> AuthorityRollChoices(int32_t NumChoices, struct TArray<struct UFortItemDefinition*>& IgnoreItems); // Function DynamicRollTablesRuntime.FortControllerComponent_DynamicRollPlayerComponent.AuthorityRollChoices // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa8b8210
};

// Class DynamicRollTablesRuntime.FortGamestateComponent_DynamicRollTableManager
// Size: 0x2d8 (Inherited: 0xa0)
struct UFortGamestateComponent_DynamicRollTableManager : UFortGameStateComponent {
	char pad_A0[0x30]; // 0xa0(0x30)
	struct FDataRegistryType DataRegistryType_BaseWeights; // 0xd0(0x04)
	struct FDataRegistryType DataRegistryType_WeightModifiers; // 0xd4(0x04)
	struct FScalableFloat Enabled; // 0xd8(0x28)
	char pad_100[0x1d8]; // 0x100(0x1d8)

	void HandlePlaylistDataReady(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function DynamicRollTablesRuntime.FortGamestateComponent_DynamicRollTableManager.HandlePlaylistDataReady // (Final|Native|Private|HasOutParms) // @ game+0xa8bc950
};

