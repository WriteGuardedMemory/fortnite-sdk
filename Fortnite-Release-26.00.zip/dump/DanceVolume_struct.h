// Enum DanceVolume.EDanceBeatSyncMode
enum class EDanceBeatSyncMode : uint8 {
	Off = 0,
	Tempo = 1,
	Music = 2,
	EDanceBeatSyncMode_MAX = 3
};

// ScriptStruct DanceVolume.DanceBeatInfo
// Size: 0x08 (Inherited: 0x00)
struct FDanceBeatInfo {
	float LengthBeats; // 0x00(0x04)
	float StartOffsetMs; // 0x04(0x04)
};

