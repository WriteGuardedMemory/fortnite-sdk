// Class FortOvershieldHelpers.FortOvershieldHelperComponent
// Size: 0x148 (Inherited: 0xa0)
struct UFortOvershieldHelperComponent : UActorComponent {
	char pad_A0[0xa8]; // 0xa0(0xa8)

	void ClearOvershieldListenerDelegates(struct UGameplayAbility* OwningAbility); // Function FortOvershieldHelpers.FortOvershieldHelperComponent.ClearOvershieldListenerDelegates // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xafb2410
	void AssignOvershieldListenerDelegates(struct UGameplayAbility* OwningAbility, struct FFortOvershieldDelegateContainer Delegates); // Function FortOvershieldHelpers.FortOvershieldHelperComponent.AssignOvershieldListenerDelegates // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xafb2680
};

