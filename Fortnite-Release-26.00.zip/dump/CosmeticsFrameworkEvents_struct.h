// Enum CosmeticsFrameworkEvents.ECosmeticsEventBindingFlags
enum class ECosmeticsEventBindingFlags : uint8 {
	None = 0,
	ExecuteImmediately = 2,
	ExecuteOnce = 4,
	ECosmeticsEventBindingFlags_MAX = 5
};

// ScriptStruct CosmeticsFrameworkEvents.CosmeticsEventHandle
// Size: 0x01 (Inherited: 0x00)
struct FCosmeticsEventHandle {
	char pad_0[0x1]; // 0x00(0x01)
};

