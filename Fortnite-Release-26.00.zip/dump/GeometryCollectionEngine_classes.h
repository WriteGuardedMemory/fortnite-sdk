// Class GeometryCollectionEngine.GeometryCollectionExternalRenderInterface
// Size: 0x28 (Inherited: 0x28)
struct UGeometryCollectionExternalRenderInterface : UInterface {
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolSubSystem
// Size: 0x38 (Inherited: 0x30)
struct UGeometryCollectionISMPoolSubSystem : UWorldSubsystem {
	struct AGeometryCollectionISMPoolActor* ISMPoolActor; // 0x30(0x08)
};

// Class GeometryCollectionEngine.ChaosDestructionListener
// Size: 0x550 (Inherited: 0x2a0)
struct UChaosDestructionListener : USceneComponent {
	char bIsCollisionEventListeningEnabled : 1; // 0x2a0(0x01)
	char bIsBreakingEventListeningEnabled : 1; // 0x2a0(0x01)
	char bIsTrailingEventListeningEnabled : 1; // 0x2a0(0x01)
	char bIsRemovalEventListeningEnabled : 1; // 0x2a0(0x01)
	char pad_2A0_4 : 4; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	struct FChaosCollisionEventRequestSettings CollisionEventRequestSettings; // 0x2a4(0x18)
	struct FChaosBreakingEventRequestSettings BreakingEventRequestSettings; // 0x2bc(0x18)
	struct FChaosTrailingEventRequestSettings TrailingEventRequestSettings; // 0x2d4(0x18)
	struct FChaosRemovalEventRequestSettings RemovalEventRequestSettings; // 0x2ec(0x10)
	char pad_2FC[0x4]; // 0x2fc(0x04)
	struct TSet<struct AChaosSolverActor*> ChaosSolverActors; // 0x300(0x50)
	struct TSet<struct AGeometryCollectionActor*> GeometryCollectionActors; // 0x350(0x50)
	struct FMulticastInlineDelegate OnCollisionEvents; // 0x3a0(0x10)
	struct FMulticastInlineDelegate OnBreakingEvents; // 0x3b0(0x10)
	struct FMulticastInlineDelegate OnTrailingEvents; // 0x3c0(0x10)
	struct FMulticastInlineDelegate OnRemovalEvents; // 0x3d0(0x10)
	char pad_3E0[0x170]; // 0x3e0(0x170)

	void SortTrailingEvents(struct TArray<struct FChaosTrailingEventData>& TrailingEvents, enum class EChaosTrailingSortMethod SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortTrailingEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x36091b0
	void SortRemovalEvents(struct TArray<struct FChaosRemovalEventData>& RemovalEvents, enum class EChaosRemovalSortMethod SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortRemovalEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3608fd0
	void SortCollisionEvents(struct TArray<struct FChaosCollisionEventData>& CollisionEvents, enum class EChaosCollisionSortMethod SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortCollisionEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3609570
	void SortBreakingEvents(struct TArray<struct FChaosBreakingEventData>& BreakingEvents, enum class EChaosBreakingSortMethod SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortBreakingEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3609390
	void SetTrailingEventRequestSettings(struct FChaosTrailingEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventRequestSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3609c80
	void SetTrailingEventEnabled(bool bIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3609880
	void SetRemovalEventRequestSettings(struct FChaosRemovalEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetRemovalEventRequestSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3609b80
	void SetRemovalEventEnabled(bool bIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetRemovalEventEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3609780
	void SetCollisionEventRequestSettings(struct FChaosCollisionEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventRequestSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3609ea0
	void SetCollisionEventEnabled(bool bIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3609a80
	void SetBreakingEventRequestSettings(struct FChaosBreakingEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventRequestSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3609d90
	void SetBreakingEventEnabled(bool bIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3609980
	void RemoveGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor); // Function GeometryCollectionEngine.ChaosDestructionListener.RemoveGeometryCollectionActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3609fb0
	void RemoveChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor); // Function GeometryCollectionEngine.ChaosDestructionListener.RemoveChaosSolverActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x34e0930
	bool IsEventListening(); // Function GeometryCollectionEngine.ChaosDestructionListener.IsEventListening // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3609750
	void AddGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor); // Function GeometryCollectionEngine.ChaosDestructionListener.AddGeometryCollectionActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x360a170
	void AddChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor); // Function GeometryCollectionEngine.ChaosDestructionListener.AddChaosSolverActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x34e0930
};

// Class GeometryCollectionEngine.GeometryCollectionActor
// Size: 0x2a0 (Inherited: 0x290)
struct AGeometryCollectionActor : AActor {
	struct UGeometryCollectionComponent* GeometryCollectionComponent; // 0x290(0x08)
	struct UGeometryCollectionDebugDrawComponent* GeometryCollectionDebugDrawComponent; // 0x298(0x08)

	bool RaycastSingle(struct FVector Start, struct FVector End, struct FHitResult& OutHit); // Function GeometryCollectionEngine.GeometryCollectionActor.RaycastSingle // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x360e4b0
};

// Class GeometryCollectionEngine.GeometryCollectionCache
// Size: 0x50 (Inherited: 0x28)
struct UGeometryCollectionCache : UObject {
	struct FRecordedTransformTrack RecordedData; // 0x28(0x10)
	struct UGeometryCollection* SupportedCollection; // 0x38(0x08)
	struct FGuid CompatibleCollectionState; // 0x40(0x10)
};

// Class GeometryCollectionEngine.GeometryCollectionComponent
// Size: 0xbc0 (Inherited: 0x5a0)
struct UGeometryCollectionComponent : UMeshComponent {
	char pad_5A0[0x8]; // 0x5a0(0x08)
	struct AChaosSolverActor* ChaosSolverActor; // 0x5a8(0x08)
	char pad_5B0[0xe8]; // 0x5b0(0xe8)
	struct UGeometryCollection* RestCollection; // 0x698(0x08)
	struct TArray<struct AFieldSystemActor*> InitializationFields; // 0x6a0(0x10)
	bool Simulating; // 0x6b0(0x01)
	char pad_6B1[0x1]; // 0x6b1(0x01)
	enum class EObjectStateTypeEnum ObjectType; // 0x6b2(0x01)
	char pad_6B3[0x1]; // 0x6b3(0x01)
	int32_t GravityGroupIndex; // 0x6b4(0x04)
	bool bForceMotionBlur; // 0x6b8(0x01)
	bool EnableClustering; // 0x6b9(0x01)
	char pad_6BA[0x2]; // 0x6ba(0x02)
	int32_t ClusterGroupIndex; // 0x6bc(0x04)
	int32_t MaxClusterLevel; // 0x6c0(0x04)
	int32_t MaxSimulatedLevel; // 0x6c4(0x04)
	enum class EDamageModelTypeEnum DamageModel; // 0x6c8(0x01)
	char pad_6C9[0x7]; // 0x6c9(0x07)
	struct TArray<float> DamageThreshold; // 0x6d0(0x10)
	bool bUseSizeSpecificDamageThreshold; // 0x6e0(0x01)
	char pad_6E1[0x3]; // 0x6e1(0x03)
	struct FGeometryCollectionDamagePropagationData DamagePropagationData; // 0x6e4(0x0c)
	bool bEnableDamageFromCollision; // 0x6f0(0x01)
	bool bAllowRemovalOnSleep; // 0x6f1(0x01)
	bool bAllowRemovalOnBreak; // 0x6f2(0x01)
	enum class EClusterConnectionTypeEnum ClusterConnectionType; // 0x6f3(0x01)
	int32_t CollisionGroup; // 0x6f4(0x04)
	float CollisionSampleFraction; // 0x6f8(0x04)
	float LinearEtherDrag; // 0x6fc(0x04)
	float AngularEtherDrag; // 0x700(0x04)
	char pad_704[0x4]; // 0x704(0x04)
	struct UChaosPhysicalMaterial* PhysicalMaterial; // 0x708(0x08)
	enum class EInitialVelocityTypeEnum InitialVelocityType; // 0x710(0x01)
	char pad_711[0x7]; // 0x711(0x07)
	struct FVector InitialLinearVelocity; // 0x718(0x18)
	struct FVector InitialAngularVelocity; // 0x730(0x18)
	struct UPhysicalMaterial* PhysicalMaterialOverride; // 0x748(0x08)
	struct FGeomComponentCacheParameters CacheParameters; // 0x750(0x50)
	struct TArray<struct FTransform> RestTransforms; // 0x7a0(0x10)
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsStateChange; // 0x7b0(0x10)
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsLoadingStateChange; // 0x7c0(0x10)
	char pad_7D0[0x18]; // 0x7d0(0x18)
	struct FMulticastInlineDelegate OnChaosBreakEvent; // 0x7e8(0x10)
	struct FMulticastInlineDelegate OnChaosRemovalEvent; // 0x7f8(0x10)
	struct FMulticastInlineDelegate OnChaosCrumblingEvent; // 0x808(0x10)
	char pad_818[0x10]; // 0x818(0x10)
	float DesiredCacheTime; // 0x828(0x04)
	bool CachePlayback; // 0x82c(0x01)
	char pad_82D[0x3]; // 0x82d(0x03)
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // 0x830(0x10)
	bool bNotifyBreaks; // 0x840(0x01)
	bool bNotifyCollisions; // 0x841(0x01)
	bool bNotifyTrailing; // 0x842(0x01)
	bool bNotifyRemovals; // 0x843(0x01)
	bool bNotifyCrumblings; // 0x844(0x01)
	bool bCrumblingEventIncludesChildren; // 0x845(0x01)
	bool bNotifyGlobalBreaks; // 0x846(0x01)
	bool bNotifyGlobalCollisions; // 0x847(0x01)
	bool bNotifyGlobalRemovals; // 0x848(0x01)
	bool bNotifyGlobalCrumblings; // 0x849(0x01)
	bool bGlobalCrumblingEventIncludesChildren; // 0x84a(0x01)
	bool bStoreVelocities; // 0x84b(0x01)
	bool bShowBoneColors; // 0x84c(0x01)
	bool bUseRootProxyForNavigation; // 0x84d(0x01)
	bool bUpdateNavigationInTick; // 0x84e(0x01)
	char pad_84F[0x1]; // 0x84f(0x01)
	struct AGeometryCollectionISMPoolActor* ISMPool; // 0x850(0x08)
	bool bAutoAssignISMPool; // 0x858(0x01)
	bool bOverrideCustomRenderer; // 0x859(0x01)
	char pad_85A[0x6]; // 0x85a(0x06)
	ClassPtrProperty CustomRendererType; // 0x860(0x08)
	struct UGeometryCollectionExternalRenderInterface* CustomRenderer; // 0x868(0x08)
	bool bEnableReplication; // 0x870(0x01)
	bool bEnableAbandonAfterLevel; // 0x871(0x01)
	char pad_872[0x2]; // 0x872(0x02)
	struct FName AbandonedCollisionProfileName; // 0x874(0x04)
	struct TArray<struct FName> CollisionProfilePerLevel; // 0x878(0x10)
	char pad_888[0x10]; // 0x888(0x10)
	int32_t ReplicationAbandonClusterLevel; // 0x898(0x04)
	int32_t ReplicationAbandonAfterLevel; // 0x89c(0x04)
	int32_t ReplicationMaxPositionAndVelocityCorrectionLevel; // 0x8a0(0x04)
	char pad_8A4[0x4]; // 0x8a4(0x04)
	struct FGeometryCollectionRepData RepData; // 0x8a8(0x38)
	char pad_8E0[0x2a0]; // 0x8e0(0x2a0)
	struct UBodySetup* DummyBodySetup; // 0xb80(0x08)
	struct UChaosGameplayEventDispatcher* EventDispatcher; // 0xb88(0x08)
	struct TArray<struct UInstancedStaticMeshComponent*> EmbeddedGeometryComponents; // 0xb90(0x10)
	char pad_BA0[0x20]; // 0xba0(0x20)

	void SetRestCollection(struct UGeometryCollection* RestCollectionIn, bool bApplyAssetDefaults); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetRestCollection // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3611f80
	void SetPerParticleCollisionProfileName(struct TArray<int32_t>& BoneIds, struct FName ProfileName); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetPerParticleCollisionProfileName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3611930
	void SetPerLevelCollisionProfileNames(struct TArray<struct FName>& ProfileNames); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetPerLevelCollisionProfileNames // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3611bb0
	void SetNotifyRemovals(bool bNewNotifyRemovals); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyRemovals // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3610980
	void SetNotifyGlobalRemovals(bool bNewNotifyGlobalRemovals); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyGlobalRemovals // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3610320
	void SetNotifyGlobalCrumblings(bool bNewNotifyGlobalCrumblings, bool bGlobalNewCrumblingEventIncludesChildren); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyGlobalCrumblings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3610110
	void SetNotifyGlobalCollision(bool bNewNotifyGlobalCollisions); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyGlobalCollision // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x36104a0
	void SetNotifyGlobalBreaks(bool bNewNotifyGlobalBreaks); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyGlobalBreaks // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x36105c0
	void SetNotifyCrumblings(bool bNewNotifyCrumblings, bool bNewCrumblingEventIncludesChildren); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyCrumblings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3610700
	void SetNotifyBreaks(bool bNewNotifyBreaks); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyBreaks // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3610b30
	void SetLocalRestTransforms(struct TArray<struct FTransform>& Transforms, bool bOnlyLeaves); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetLocalRestTransforms // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x36124c0
	void SetEnableDamageFromCollision(bool bValue); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetEnableDamageFromCollision // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3611de0
	void SetDamageThreshold(struct TArray<float>& InDamageThreshold); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetDamageThreshold // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x36116b0
	void SetAnchoredByTransformedBox(struct FBox Box, struct FTransform Transform, bool bAnchored, int32_t MaxLevel); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetAnchoredByTransformedBox // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x36131a0
	void SetAnchoredByIndex(int32_t Index, bool bAnchored); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetAnchoredByIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x36137a0
	void SetAnchoredByBox(struct FBox WorldSpaceBox, bool bAnchored, int32_t MaxLevel); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetAnchoredByBox // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3613510
	void SetAbandonedParticleCollisionProfileName(struct FName CollisionProfile); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetAbandonedParticleCollisionProfileName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3611ce0
	void RemoveAllAnchors(); // Function GeometryCollectionEngine.GeometryCollectionComponent.RemoveAllAnchors // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3613180
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo); // Function GeometryCollectionEngine.GeometryCollectionComponent.ReceivePhysicsCollision // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnRep_RepData(); // Function GeometryCollectionEngine.GeometryCollectionComponent.OnRep_RepData // (Final|RequiredAPI|Native|Protected) // @ game+0x36100f0
	void NotifyGeometryCollectionPhysicsStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent); // DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsStateChange__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent); // DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	bool IsRootBroken(); // Function GeometryCollectionEngine.GeometryCollectionComponent.IsRootBroken // (Final|RequiredAPI|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x36100c0
	struct FTransform GetRootInitialTransform(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetRootInitialTransform // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3612790
	int32_t GetRootIndex(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetRootIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3612820
	struct FTransform GetRootCurrentTransform(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetRootCurrentTransform // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3612700
	void GetMassAndExtents(int32_t ItemIndex, float& OutMass, struct FBox& OutExtents); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetMassAndExtents // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3612280
	struct FBox GetLocalBounds(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetLocalBounds // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x36148f0
	struct TArray<struct FTransform> GetInitialLocalRestTransforms(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetInitialLocalRestTransforms // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3612690
	int32_t GetInitialLevel(int32_t ItemIndex); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetInitialLevel // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3612860
	struct FString GetDebugInfo(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetDebugInfo // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3611f10
	struct TArray<float> GetDamageThreshold(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetDamageThreshold // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3611800
	void CrumbleCluster(int32_t ItemIndex); // Function GeometryCollectionEngine.GeometryCollectionComponent.CrumbleCluster // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3613c10
	void CrumbleActiveClusters(); // Function GeometryCollectionEngine.GeometryCollectionComponent.CrumbleActiveClusters // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3613a70
	void ApplyPhysicsField(bool Enabled, enum class EGeometryCollectionPhysicsTypeEnum Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyPhysicsField // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3610ce0
	void ApplyLinearVelocity(int32_t ItemIndex, struct FVector& LinearVelocity); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyLinearVelocity // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3612c90
	void ApplyKinematicField(float Radius, struct FVector Position); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyKinematicField // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3611390
	void ApplyInternalStrain(int32_t ItemIndex, struct FVector& Location, float Radius, int32_t PropagationDepth, float PropagationFactor, float Strain); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyInternalStrain // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3613d50
	void ApplyExternalStrain(int32_t ItemIndex, struct FVector& Location, float Radius, int32_t PropagationDepth, float PropagationFactor, float Strain); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyExternalStrain // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3614320
	void ApplyBreakingLinearVelocity(int32_t ItemIndex, struct FVector& LinearVelocity); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyBreakingLinearVelocity // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3612fd0
	void ApplyBreakingAngularVelocity(int32_t ItemIndex, struct FVector& AngularVelocity); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyBreakingAngularVelocity // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3612fd0
	void ApplyAssetDefaults(); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyAssetDefaults // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3611910
	void ApplyAngularVelocity(int32_t ItemIndex, struct FVector& AngularVelocity); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyAngularVelocity // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3612950
};

// Class GeometryCollectionEngine.GeometryCollectionDebugDrawActor
// Size: 0x350 (Inherited: 0x290)
struct AGeometryCollectionDebugDrawActor : AActor {
	struct FGeometryCollectionDebugDrawWarningMessage WarningMessage; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
	struct FGeometryCollectionDebugDrawActorSelectedRigidBody SelectedRigidBody; // 0x298(0x18)
	bool bDebugDrawWholeCollection; // 0x2b0(0x01)
	bool bDebugDrawHierarchy; // 0x2b1(0x01)
	bool bDebugDrawClustering; // 0x2b2(0x01)
	enum class EGeometryCollectionDebugDrawActorHideGeometry HideGeometry; // 0x2b3(0x01)
	bool bShowRigidBodyId; // 0x2b4(0x01)
	bool bShowRigidBodyCollision; // 0x2b5(0x01)
	bool bCollisionAtOrigin; // 0x2b6(0x01)
	bool bShowRigidBodyTransform; // 0x2b7(0x01)
	bool bShowRigidBodyInertia; // 0x2b8(0x01)
	bool bShowRigidBodyVelocity; // 0x2b9(0x01)
	bool bShowRigidBodyForce; // 0x2ba(0x01)
	bool bShowRigidBodyInfos; // 0x2bb(0x01)
	bool bShowTransformIndex; // 0x2bc(0x01)
	bool bShowTransform; // 0x2bd(0x01)
	bool bShowParent; // 0x2be(0x01)
	bool bShowLevel; // 0x2bf(0x01)
	bool bShowConnectivityEdges; // 0x2c0(0x01)
	bool bShowGeometryIndex; // 0x2c1(0x01)
	bool bShowGeometryTransform; // 0x2c2(0x01)
	bool bShowBoundingBox; // 0x2c3(0x01)
	bool bShowFaces; // 0x2c4(0x01)
	bool bShowFaceIndices; // 0x2c5(0x01)
	bool bShowFaceNormals; // 0x2c6(0x01)
	bool bShowSingleFace; // 0x2c7(0x01)
	int32_t SingleFaceIndex; // 0x2c8(0x04)
	bool bShowVertices; // 0x2cc(0x01)
	bool bShowVertexIndices; // 0x2cd(0x01)
	bool bShowVertexNormals; // 0x2ce(0x01)
	bool bUseActiveVisualization; // 0x2cf(0x01)
	float PointThickness; // 0x2d0(0x04)
	float LineThickness; // 0x2d4(0x04)
	bool bTextShadow; // 0x2d8(0x01)
	char pad_2D9[0x3]; // 0x2d9(0x03)
	float TextScale; // 0x2dc(0x04)
	float NormalScale; // 0x2e0(0x04)
	float AxisScale; // 0x2e4(0x04)
	float ArrowScale; // 0x2e8(0x04)
	struct FColor RigidBodyIdColor; // 0x2ec(0x04)
	float RigidBodyTransformScale; // 0x2f0(0x04)
	struct FColor RigidBodyCollisionColor; // 0x2f4(0x04)
	struct FColor RigidBodyInertiaColor; // 0x2f8(0x04)
	struct FColor RigidBodyVelocityColor; // 0x2fc(0x04)
	struct FColor RigidBodyForceColor; // 0x300(0x04)
	struct FColor RigidBodyInfoColor; // 0x304(0x04)
	struct FColor TransformIndexColor; // 0x308(0x04)
	float TransformScale; // 0x30c(0x04)
	struct FColor LevelColor; // 0x310(0x04)
	struct FColor ParentColor; // 0x314(0x04)
	float ConnectivityEdgeThickness; // 0x318(0x04)
	struct FColor GeometryIndexColor; // 0x31c(0x04)
	float GeometryTransformScale; // 0x320(0x04)
	struct FColor BoundingBoxColor; // 0x324(0x04)
	struct FColor FaceColor; // 0x328(0x04)
	struct FColor FaceIndexColor; // 0x32c(0x04)
	struct FColor FaceNormalColor; // 0x330(0x04)
	struct FColor SingleFaceColor; // 0x334(0x04)
	struct FColor VertexColor; // 0x338(0x04)
	struct FColor VertexIndexColor; // 0x33c(0x04)
	struct FColor VertexNormalColor; // 0x340(0x04)
	char pad_344[0x4]; // 0x344(0x04)
	struct UBillboardComponent* SpriteComponent; // 0x348(0x08)
};

// Class GeometryCollectionEngine.GeometryCollectionDebugDrawComponent
// Size: 0xb8 (Inherited: 0xa0)
struct UGeometryCollectionDebugDrawComponent : UActorComponent {
	struct AGeometryCollectionDebugDrawActor* GeometryCollectionDebugDrawActor; // 0xa0(0x08)
	struct AGeometryCollectionRenderLevelSetActor* GeometryCollectionRenderLevelSetActor; // 0xa8(0x08)
	char pad_B0[0x8]; // 0xb0(0x08)
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolActor
// Size: 0x2a0 (Inherited: 0x290)
struct AGeometryCollectionISMPoolActor : AActor {
	struct UGeometryCollectionISMPoolComponent* ISMPoolComp; // 0x290(0x08)
	struct UGeometryCollectionISMPoolDebugDrawComponent* ISMPoolDebugDrawComp; // 0x298(0x08)
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolComponent
// Size: 0x370 (Inherited: 0x2a0)
struct UGeometryCollectionISMPoolComponent : USceneComponent {
	char pad_2A0[0xd0]; // 0x2a0(0xd0)
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolRenderer
// Size: 0xd0 (Inherited: 0x28)
struct UGeometryCollectionISMPoolRenderer : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct AGeometryCollectionISMPoolActor* ISMPoolActor; // 0x30(0x08)
	char pad_38[0x98]; // 0x38(0x98)
};

// Class GeometryCollectionEngine.GeometryCollection
// Size: 0x1e8 (Inherited: 0x28)
struct UGeometryCollection : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	bool EnableClustering; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t ClusterGroupIndex; // 0x3c(0x04)
	int32_t MaxClusterLevel; // 0x40(0x04)
	enum class EDamageModelTypeEnum DamageModel; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	struct TArray<float> DamageThreshold; // 0x48(0x10)
	bool bUseSizeSpecificDamageThreshold; // 0x58(0x01)
	bool PerClusterOnlyDamageThreshold; // 0x59(0x01)
	char pad_5A[0x2]; // 0x5a(0x02)
	struct FGeometryCollectionDamagePropagationData DamagePropagationData; // 0x5c(0x0c)
	enum class EClusterConnectionTypeEnum ClusterConnectionType; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	float ConnectionGraphBoundsFilteringMargin; // 0x6c(0x04)
	struct TArray<struct UMaterialInterface*> Materials; // 0x70(0x10)
	struct TArray<struct FGeometryCollectionEmbeddedExemplar> EmbeddedGeometryExemplar; // 0x80(0x10)
	bool bUseFullPrecisionUVs; // 0x90(0x01)
	bool bStripOnCook; // 0x91(0x01)
	bool bStripRenderDataOnCook; // 0x92(0x01)
	char pad_93[0x5]; // 0x93(0x05)
	ClassPtrProperty CustomRendererType; // 0x98(0x08)
	struct FGeometryCollectionProxyMeshData RootProxyData; // 0xa0(0x10)
	struct TArray<struct FGeometryCollectionAutoInstanceMesh> AutoInstanceMeshes; // 0xb0(0x10)
	bool EnableNanite; // 0xc0(0x01)
	bool bConvertVertexColorsToSRGB; // 0xc1(0x01)
	char pad_C2[0x6]; // 0xc2(0x06)
	struct UPhysicalMaterial* PhysicsMaterial; // 0xc8(0x08)
	bool bDensityFromPhysicsMaterial; // 0xd0(0x01)
	bool bMassAsDensity; // 0xd1(0x01)
	char pad_D2[0x2]; // 0xd2(0x02)
	float Mass; // 0xd4(0x04)
	float MinimumMassClamp; // 0xd8(0x04)
	bool bImportCollisionFromSource; // 0xdc(0x01)
	bool bScaleOnRemoval; // 0xdd(0x01)
	bool bRemoveOnMaxSleep; // 0xde(0x01)
	char pad_DF[0x1]; // 0xdf(0x01)
	struct FVector2D MaximumSleepTime; // 0xe0(0x10)
	struct FVector2D RemovalDuration; // 0xf0(0x10)
	bool bSlowMovingAsSleeping; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	float SlowMovingVelocityThreshold; // 0x104(0x04)
	struct TArray<struct FGeometryCollectionSizeSpecificData> SizeSpecificData; // 0x108(0x10)
	bool EnableRemovePiecesOnFracture; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
	struct TArray<struct UMaterialInterface*> RemoveOnFractureMaterials; // 0x120(0x10)
	struct UDataflow* DataflowAsset; // 0x130(0x08)
	struct FString DataflowTerminal; // 0x138(0x10)
	struct TMap<struct FString, struct FString> Overrides; // 0x148(0x50)
	struct FGuid PersistentGuid; // 0x198(0x10)
	struct FGuid StateGuid; // 0x1a8(0x10)
	int32_t RootIndex; // 0x1b8(0x04)
	int32_t BoneSelectedMaterialIndex; // 0x1bc(0x04)
	struct UMaterialInterface* BoneSelectedMaterial; // 0x1c0(0x08)
	char pad_1C8[0x10]; // 0x1c8(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x1d8(0x10)

	void SetEnableNanite(bool bValue); // Function GeometryCollectionEngine.GeometryCollection.SetEnableNanite // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3631890
	void SetConvertVertexColorsToSRGB(bool bValue); // Function GeometryCollectionEngine.GeometryCollection.SetConvertVertexColorsToSRGB // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x36317a0
};

// Class GeometryCollectionEngine.GeometryCollectionRenderLevelSetActor
// Size: 0x380 (Inherited: 0x290)
struct AGeometryCollectionRenderLevelSetActor : AActor {
	struct UVolumeTexture* TargetVolumeTexture; // 0x290(0x08)
	struct UMaterial* RayMarchMaterial; // 0x298(0x08)
	float SurfaceTolerance; // 0x2a0(0x04)
	float Isovalue; // 0x2a4(0x04)
	bool Enabled; // 0x2a8(0x01)
	bool RenderVolumeBoundingBox; // 0x2a9(0x01)
	char pad_2AA[0xd6]; // 0x2aa(0xd6)
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolDebugDrawComponent
// Size: 0x5d0 (Inherited: 0x5c0)
struct UGeometryCollectionISMPoolDebugDrawComponent : UDebugDrawComponent {
	bool bShowGlobalStats; // 0x5b8(0x01)
	bool bShowStats; // 0x5b9(0x01)
	bool bShowBounds; // 0x5ba(0x01)
	struct UInstancedStaticMeshComponent* SelectedComponent; // 0x5c0(0x08)
	char pad_5CB[0x5]; // 0x5cb(0x05)
};

