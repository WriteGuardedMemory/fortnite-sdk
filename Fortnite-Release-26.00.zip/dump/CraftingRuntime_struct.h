// Enum CraftingRuntime.ECraftingObjectState
enum class ECraftingObjectState : uint8 {
	Invalid = 0,
	Idle = 1,
	Crafting = 2,
	CraftingPaused = 3,
	CraftingPausedDecaying = 4,
	Ready = 5,
	OverCrafting = 6,
	Resetting = 7,
	TotalStates = 8,
	ECraftingObjectState_MAX = 9
};

// Enum CraftingRuntime.ECraftingIngredientReqError
enum class ECraftingIngredientReqError : uint8 {
	None = 0,
	NoItem = 1,
	NotEnough = 2,
	ECraftingIngredientReqError_MAX = 3
};

// ScriptStruct CraftingRuntime.CraftingObjectSuccessEvent
// Size: 0x20 (Inherited: 0x00)
struct FCraftingObjectSuccessEvent {
	struct AActor* CraftingObject; // 0x00(0x08)
	struct FCraftingMultiKey Key; // 0x08(0x08)
	struct AFortPlayerController* Instigator; // 0x10(0x08)
	struct FName FormulaRowName; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct CraftingRuntime.CraftingMultiKey
// Size: 0x08 (Inherited: 0x00)
struct FCraftingMultiKey {
	int64_t Key; // 0x00(0x08)
};

// ScriptStruct CraftingRuntime.CraftingObjectStateChangedEvent
// Size: 0x28 (Inherited: 0x00)
struct FCraftingObjectStateChangedEvent {
	struct AActor* CraftingObject; // 0x00(0x08)
	struct FCraftingMultiKey Key; // 0x08(0x08)
	struct AFortPlayerController* Instigator; // 0x10(0x08)
	enum class ECraftingObjectState CraftingState; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float CraftingStateStartTime; // 0x1c(0x04)
	float CraftingStateDuration; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct CraftingRuntime.CraftingObjectRepStateData
// Size: 0x28 (Inherited: 0x00)
struct FCraftingObjectRepStateData {
	struct FCraftingMultiKey Key; // 0x00(0x08)
	enum class ECraftingObjectState CraftingObjectState; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float StateChangeServerTime; // 0x0c(0x04)
	float PausedCraftingTime; // 0x10(0x04)
	struct FName CraftingFormulaRow; // 0x14(0x04)
	int32_t NumToCraft; // 0x18(0x04)
	struct TWeakObjectPtr<struct AFortPlayerController> CraftingInstigator; // 0x1c(0x08)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct CraftingRuntime.CraftingObjectServerStateData
// Size: 0x1f0 (Inherited: 0x00)
struct FCraftingObjectServerStateData {
	char bNextResultsHandledExternally : 1; // 0x00(0x01)
	char pad_0_1 : 7; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct AFortPickup* PendingPickupCraftingItem; // 0x08(0x08)
	struct FName PendingPickupCraftingFormula; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FFortItemEntry PendingPickupCraftingItemEntry; // 0x18(0x198)
	int32_t PendingPickupHeldCount; // 0x1b0(0x04)
	char pad_1B4[0x4]; // 0x1b4(0x04)
	struct TArray<struct FFortItemEntry> AllOfTheIngredientItems; // 0x1b8(0x10)
	struct TArray<int32_t> NonConsumedIngredientItemIndices; // 0x1c8(0x10)
	struct TArray<struct FItemAndCount> CraftingResults; // 0x1d8(0x10)
	struct FGameplayAbilitySpecHandle InstigatorWhileCraftingAbilitySpecHandle; // 0x1e8(0x04)
	char pad_1EC[0x4]; // 0x1ec(0x04)
};

// ScriptStruct CraftingRuntime.CraftingIngredientRequirement
// Size: 0x28 (Inherited: 0x00)
struct FCraftingIngredientRequirement {
	struct FGameplayTagContainer IngredientTags; // 0x00(0x20)
	int32_t Count; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct CraftingRuntime.CraftingUpgradeRule
// Size: 0x118 (Inherited: 0x00)
struct FCraftingUpgradeRule {
	struct FGameplayTagRequirements SourceItemTags; // 0x00(0x88)
	struct FGameplayTagRequirements TargetItemTags; // 0x88(0x88)
	char UpgradeFlags; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
};

// ScriptStruct CraftingRuntime.CraftingFormula
// Size: 0xa0 (Inherited: 0x08)
struct FCraftingFormula : FTableRowBase {
	struct FText DisplayName; // 0x08(0x18)
	char bEnabled : 1; // 0x20(0x01)
	char bAlwaysKnownFormula : 1; // 0x20(0x01)
	char bInstantlyConsumeIngredients : 1; // 0x20(0x01)
	char pad_20_3 : 5; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	struct FGameplayTag SourceObjectTag; // 0x24(0x04)
	struct FGameplayTag CategoryTag; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FCraftingIngredientRequirement> RequiredIngredients; // 0x30(0x10)
	struct FName ResultLootTierKey; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct TSoftClassPtr<UObject> WhileCraftingAbility; // 0x48(0x20)
	struct TArray<struct FCraftingUpgradeRule> UpgradeRules; // 0x68(0x10)
	float OverrideCraftingTime; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TSoftClassPtr<UObject> InstigatorWhileCraftingAbility; // 0x80(0x20)
};

// ScriptStruct CraftingRuntime.CraftingResult
// Size: 0x18 (Inherited: 0x00)
struct FCraftingResult {
	struct FName ResultLootTierKey; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FItemAndCount> Results; // 0x08(0x10)
};

// ScriptStruct CraftingRuntime.CraftingIngredientUIData
// Size: 0x48 (Inherited: 0x08)
struct FCraftingIngredientUIData : FTableRowBase {
	struct FGameplayTagContainer IngredientTags; // 0x08(0x20)
	struct TArray<struct TSoftObjectPtr<UFortItemDefinition>> ItemDefs; // 0x28(0x10)
	struct TArray<struct TSoftObjectPtr<UObject>> Icons; // 0x38(0x10)
};

// ScriptStruct CraftingRuntime.CraftingIngredientQueryState
// Size: 0x30 (Inherited: 0x00)
struct FCraftingIngredientQueryState {
	struct FCraftingIngredientRequirement Requirement; // 0x00(0x28)
	int32_t Owned; // 0x28(0x04)
	int32_t Missing; // 0x2c(0x04)
};

// ScriptStruct CraftingRuntime.CraftingMessage
// Size: 0x08 (Inherited: 0x00)
struct FCraftingMessage {
	struct AActor* CraftingObject; // 0x00(0x08)
};

