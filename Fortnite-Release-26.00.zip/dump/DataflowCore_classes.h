// Class DataflowCore.DataflowSettings
// Size: 0xd8 (Inherited: 0x30)
struct UDataflowSettings : UDeveloperSettings {
	struct FLinearColor ArrayPinTypeColor; // 0x30(0x10)
	struct FLinearColor ManagedArrayCollectionPinTypeColor; // 0x40(0x10)
	struct FLinearColor BoxPinTypeColor; // 0x50(0x10)
	struct FLinearColor SpherePinTypeColor; // 0x60(0x10)
	struct TMap<struct FName, struct FNodeColors> NodeColorsMap; // 0x70(0x50)
	char pad_C0[0x18]; // 0xc0(0x18)
};

