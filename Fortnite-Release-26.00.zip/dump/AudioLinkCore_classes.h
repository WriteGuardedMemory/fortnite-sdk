// Class AudioLinkCore.AudioLinkSettingsAbstract
// Size: 0x38 (Inherited: 0x28)
struct UAudioLinkSettingsAbstract : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

