// Class CollectionMapShared.AthenaCollectionScreenMapBase
// Size: 0x6b8 (Inherited: 0x630)
struct UAthenaCollectionScreenMapBase : UAthenaCollectionScreenBase {
	struct UAthenaFullScreenMapBase* MapWidget; // 0x630(0x08)
	struct UAthenaMapCollectionIcon* CollectionIconType; // 0x638(0x08)
	struct TMap<struct FGameplayTag, struct UAthenaMapCollectionIcon*> MapCollectionIcons; // 0x640(0x50)
	char pad_690[0x28]; // 0x690(0x28)
};

// Class CollectionMapShared.AthenaMapCollectionIcon
// Size: 0x370 (Inherited: 0x370)
struct UAthenaMapCollectionIcon : UAthenaMapNavigableIconCustom {

	void SetSecondaryIcon(struct TSoftObjectPtr<UObject>& SecondaryIcon); // Function CollectionMapShared.AthenaMapCollectionIcon.SetSecondaryIcon // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void SetIsKnown(bool bIsKnown); // Function CollectionMapShared.AthenaMapCollectionIcon.SetIsKnown // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

