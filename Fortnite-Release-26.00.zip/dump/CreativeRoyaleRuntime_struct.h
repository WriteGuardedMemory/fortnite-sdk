// Enum CreativeRoyaleRuntime.EFortPoiSwapUserContentState
enum class EFortPoiSwapUserContentState : uint8 {
	Unloaded = 0,
	Loading = 1,
	Loaded = 2,
	Unloading = 3,
	EFortPoiSwapUserContentState_MAX = 4
};

// ScriptStruct CreativeRoyaleRuntime.AttachedBuildingActorGuids
// Size: 0x10 (Inherited: 0x00)
struct FAttachedBuildingActorGuids {
	struct TArray<struct FGuid> AttachedBuildingActorGuids; // 0x00(0x10)
};

// ScriptStruct CreativeRoyaleRuntime.SpawnBuildingActorParameters
// Size: 0x70 (Inherited: 0x00)
struct FSpawnBuildingActorParameters {
	struct UObject* SpawnClass; // 0x00(0x08)
	struct TWeakObjectPtr<struct ULevel> SpawnLevel; // 0x08(0x08)
	struct FTransform SpawnTransform; // 0x10(0x60)
};

