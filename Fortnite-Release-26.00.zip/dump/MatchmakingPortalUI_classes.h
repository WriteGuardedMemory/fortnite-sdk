// Class MatchmakingPortalUI.FortMatchmakingPortalCountdown
// Size: 0x418 (Inherited: 0x3e8)
struct UFortMatchmakingPortalCountdown : UCommonActivatableWidget {
	char pad_3E8[0x8]; // 0x3e8(0x08)
	struct UInputComponent* MatchmakingPortalInputComponent; // 0x3f0(0x08)
	struct UFortActivityScalingTextBlock* Text_IslandName; // 0x3f8(0x08)
	float CountdownTime; // 0x400(0x04)
	char pad_404[0x4]; // 0x404(0x04)
	struct FMulticastInlineDelegate OnFinishedCountdown; // 0x408(0x10)

	void StartCountdown(); // Function MatchmakingPortalUI.FortMatchmakingPortalCountdown.StartCountdown // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1b027f0
	void HandleCancelClicked(); // Function MatchmakingPortalUI.FortMatchmakingPortalCountdown.HandleCancelClicked // (Final|Native|Protected|BlueprintCallable) // @ game+0xaca8060
	void FinishTimer(); // Function MatchmakingPortalUI.FortMatchmakingPortalCountdown.FinishTimer // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1b027f0
};

// Class MatchmakingPortalUI.FortMatchmakingPortalModal
// Size: 0x808 (Inherited: 0x438)
struct UFortMatchmakingPortalModal : UFortActivityView {
	struct FTimerHandle MatchmakingStartTimerHandle; // 0x438(0x08)
	char pad_440[0x358]; // 0x440(0x358)
	struct TArray<struct FString> XpTagMnemonicWhitelist; // 0x798(0x10)
	struct UCommonRichTextBlock* Text_ActivityOrigin; // 0x7a8(0x08)
	struct UCommonRichTextBlock* Text_LinkCode; // 0x7b0(0x08)
	struct UCommonTextBlock* Text_ActivityName; // 0x7b8(0x08)
	struct UCommonTextBlock* Text_ActivityDescription; // 0x7c0(0x08)
	struct UScrollBox* ScrollBox_ActivityDescription; // 0x7c8(0x08)
	struct UDynamicEntryBox* EntryBox_ActivityTags; // 0x7d0(0x08)
	struct UFortSimpleMaterialProgressBar* ProgressBar_ContentDownload; // 0x7d8(0x08)
	struct UCommonButtonBase* Button_AcceptPublic; // 0x7e0(0x08)
	struct UCommonButtonBase* Button_AcceptPrivate; // 0x7e8(0x08)
	struct UCommonButtonBase* Button_Favorite; // 0x7f0(0x08)
	struct UCommonButtonBase* Button_Cancel; // 0x7f8(0x08)
	struct UFortModalBackground* ModalBackground; // 0x800(0x08)

	void SetMatchmakingTimer(); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.SetMatchmakingTimer // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1b027f0
	void SetMatchmakingStateText(struct FText& MatchmakingStateText); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.SetMatchmakingStateText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void SendLinkCodeToParty(); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.SendLinkCodeToParty // (Final|Native|Protected|BlueprintCallable) // @ game+0xaca8c50
	void OnMatchmakingStopped(); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.OnMatchmakingStopped // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnMatchmakingStarted(struct FText& MatchmakingState); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.OnMatchmakingStarted // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnAdditionalContentUpdate(struct FText& MatchmakingState, float Progress, bool bShowProgressBar); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.OnAdditionalContentUpdate // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1b027f0
	bool IsDownloadRequired(); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.IsDownloadRequired // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xaca89c0
	void HandleOnMatchmakingError(); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.HandleOnMatchmakingError // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	enum class EFortInvalidActivityReason GetInvalidActivityReason(); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.GetInvalidActivityReason // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xaca8a10
	struct FText GetCreatorTextFormat(struct FText& CreatorName); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.GetCreatorTextFormat // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	struct TArray<struct FString> GetContentWarningStrings(); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.GetContentWarningStrings // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xaca8ab0
	struct FText GetCodeTextFormat(struct FText& IslandCode); // Function MatchmakingPortalUI.FortMatchmakingPortalModal.GetCodeTextFormat // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class MatchmakingPortalUI.FortMatchmakingPortalPopup
// Size: 0x518 (Inherited: 0x3f0)
struct UFortMatchmakingPortalPopup : UFortPortalHUDDetails {
	char pad_3F0[0x10]; // 0x3f0(0x10)
	struct UFortGameActivity* CachedGameActivity; // 0x400(0x08)
	struct UFortMatchmakingPortalModal* MatchmakingPortalModalWidget; // 0x408(0x08)
	struct UCommonActivatableWidget* MatchmakingFeedbackClass; // 0x410(0x08)
	struct UFortMatchmakingPortalCountdown* MatchmakingCountdownClass; // 0x418(0x08)
	struct FVector WorldPointerLocation; // 0x420(0x18)
	struct FText CreatorNameTextFormat; // 0x438(0x18)
	struct TWeakObjectPtr<struct UHeaderDescriptionHUDComponent> CachedHUDComponent; // 0x450(0x08)
	struct UFortMatchmakingPortalModal* IslandModal; // 0x458(0x08)
	struct FMatchmakingPortalPopupData CachedIslandData; // 0x460(0x60)
	struct FText InvalidLinkCodeWarningText; // 0x4c0(0x18)
	float MatchmakingFeedbackDelayTime; // 0x4d8(0x04)
	char bIsWithinPortalRange : 1; // 0x4dc(0x01)
	char pad_4DC_1 : 7; // 0x4dc(0x01)
	char pad_4DD[0x3]; // 0x4dd(0x03)
	struct UFortMatchmakingPortalCountdown* MatchmakingCountdownWidget; // 0x4e0(0x08)
	struct UCommonActivatableWidget* MatchmakingFeedbackContainerWidget; // 0x4e8(0x08)
	struct UFortAthenaCreativeMatchmakingWidget* MatchmakingFeedbackWidget; // 0x4f0(0x08)
	struct UCommonRichTextBlock* RichText_CreatorName; // 0x4f8(0x08)
	struct UCommonTextBlock* Text_IslandName; // 0x500(0x08)
	struct UDynamicEntryBox* EntryBox_ActivityTags; // 0x508(0x08)
	struct UFortKeybindWidget* GlobalActionKeybindWidget; // 0x510(0x08)

	void UpdateVisuals(struct UHeaderDescriptionHUDComponent* HUDComponent); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.UpdateVisuals // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnShowPortalPopup(bool bShow, bool bAnimate); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.OnShowPortalPopup // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayerCanInteractChanged(bool bPlayerCanInteract); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.OnPlayerCanInteractChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool IsInteractingDeviceAMatchmakingPortal(); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.IsInteractingDeviceAMatchmakingPortal // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool HasActivityToShow(); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.HasActivityToShow // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xacab550
	void HandleWidgetUpdate(); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.HandleWidgetUpdate // (Final|Native|Private) // @ game+0xacabaf0
	void HandleStartedRespawn(struct AFortPlayerControllerZone* PlayerController); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.HandleStartedRespawn // (Final|Native|Private) // @ game+0xacab880
	void HandleOnPortalDetailsVisibilityCheck(bool bShowWidget); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.HandleOnPortalDetailsVisibilityCheck // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x1b027f0
	void HandleLoadScreenChanged(struct AFortPlayerControllerAthena* PlayerController, bool bLoadScreenEnabled, struct FText HUDReason); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.HandleLoadScreenChanged // (Final|Native|Private) // @ game+0xacab5b0
	void HandleHUDShow(bool bShow, bool bShouldAnimate); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.HandleHUDShow // (Final|Native|Private) // @ game+0xacab970
	void HandleFinishedCountdown(); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.HandleFinishedCountdown // (Final|Native|Private) // @ game+0xacab590
	struct UFortAthenaCreativeMatchmakingWidget* GetMatchmakingFeedbackWidget(struct UCommonActivatableWidget* MatchmakingFeedbackContainer); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.GetMatchmakingFeedbackWidget // (Event|Protected|BlueprintEvent|Const) // @ game+0x1b027f0
	bool GetIslandData(struct FMatchmakingPortalPopupData& OutIslandData, struct UHeaderDescriptionHUDComponent* HUDComponent); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.GetIslandData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void BindOverlapEvents(); // Function MatchmakingPortalUI.FortMatchmakingPortalPopup.BindOverlapEvents // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class MatchmakingPortalUI.FortModalBackground
// Size: 0x420 (Inherited: 0x3e8)
struct UFortModalBackground : UCommonActivatableWidget {
	char pad_3E8[0x20]; // 0x3e8(0x20)
	struct UCommonButtonBase* Button_Back; // 0x408(0x08)
	struct UCommonButtonBase* Button_BackBoard; // 0x410(0x08)
	struct UCommonButtonBase* Button_MobileClose; // 0x418(0x08)

	void OnPreviewImageChanged(bool bIsLoading, struct UTexture* InTexture); // Function MatchmakingPortalUI.FortModalBackground.OnPreviewImageChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class MatchmakingPortalUI.FortUIGameFeatureAction_OverridePortalHUDDetails
// Size: 0x48 (Inherited: 0x28)
struct UFortUIGameFeatureAction_OverridePortalHUDDetails : UFortUIGameFeatureAction {
	struct TSoftClassPtr<UObject> SoftPortalHUDDetailsClass; // 0x28(0x20)
};

