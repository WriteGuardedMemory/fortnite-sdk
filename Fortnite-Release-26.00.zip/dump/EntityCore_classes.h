// Class EntityCore.EntityComponent
// Size: 0x58 (Inherited: 0x28)
struct UEntityComponent : UObject {
	char pad_28[0x30]; // 0x28(0x30)
};

// Class EntityCore.EntityDataBackedComponent
// Size: 0x60 (Inherited: 0x58)
struct UEntityDataBackedComponent : UEntityComponent {
	char pad_58[0x8]; // 0x58(0x08)
};

// Class EntityCore.EntityPositionComponent
// Size: 0x60 (Inherited: 0x60)
struct UEntityPositionComponent : UEntityDataBackedComponent {
};

// Class EntityCore.EntityRotationComponent
// Size: 0x60 (Inherited: 0x60)
struct UEntityRotationComponent : UEntityDataBackedComponent {
};

// Class EntityCore.EntityScaleComponent
// Size: 0x60 (Inherited: 0x60)
struct UEntityScaleComponent : UEntityDataBackedComponent {
};

// Class EntityCore.EntityCoreDataBackedRelativePositionComponent
// Size: 0x60 (Inherited: 0x60)
struct UEntityCoreDataBackedRelativePositionComponent : UEntityDataBackedComponent {
};

// Class EntityCore.Entity
// Size: 0x38 (Inherited: 0x28)
struct UEntity : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct ULevel* Level; // 0x30(0x08)
};

// Class EntityCore.EntityCoreSubsystem
// Size: 0x150 (Inherited: 0x30)
struct UEntityCoreSubsystem : UWorldSubsystem {
	char pad_30[0x10]; // 0x30(0x10)
	struct TMap<uint32_t, struct FEntityComponentContainer> ComponentMap; // 0x40(0x50)
	char pad_90[0x58]; // 0x90(0x58)
	struct TArray<struct UEntityComponent*> ComponentArray; // 0xe8(0x10)
	struct TMap<uint32_t, struct UEntity*> Entities; // 0xf8(0x50)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class EntityCore.EntityEnableableComponent
// Size: 0x78 (Inherited: 0x58)
struct UEntityEnableableComponent : UEntityComponent {
	char IsEnabled : 1; // 0x58(0x01)
	char LastIsEnabled : 1; // 0x58(0x01)
	char pad_58_2 : 6; // 0x58(0x01)
	char pad_59[0x1f]; // 0x59(0x1f)

	void OnRep_Enabled(); // Function EntityCore.EntityEnableableComponent.OnRep_Enabled // (Final|Native|Private) // @ game+0x542cf00
};

// Class EntityCore.EntityTickableComponent
// Size: 0xb0 (Inherited: 0x78)
struct UEntityTickableComponent : UEntityEnableableComponent {
	char pad_78[0x38]; // 0x78(0x38)
};

// Class EntityCore.EntityScriptComponent
// Size: 0xb0 (Inherited: 0xb0)
struct UEntityScriptComponent : UEntityTickableComponent {
};

