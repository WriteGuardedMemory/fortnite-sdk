// Class CosmeticsFrameworkModifiers.CosmeticModifierInterface
// Size: 0x28 (Inherited: 0x28)
struct UCosmeticModifierInterface : UInterface {
};

// Class CosmeticsFrameworkModifiers.CosmeticModifierOwnerInterface
// Size: 0x28 (Inherited: 0x28)
struct UCosmeticModifierOwnerInterface : UInterface {
};

// Class CosmeticsFrameworkModifiers.CosmeticModifierProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct UCosmeticModifierProviderInterface : UInterface {
};

