// Class Account.ExternalAccountProvider
// Size: 0x38 (Inherited: 0x28)
struct UExternalAccountProvider : UObject {
	struct TArray<struct FExternalAccountServiceConfig> Services; // 0x28(0x10)
};

// Class Account.OnlineAccountCommon
// Size: 0x880 (Inherited: 0x28)
struct UOnlineAccountCommon : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct FString AvailabilityServiceGameName; // 0x38(0x10)
	bool bRequireLightswitchAtStartup; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FString EulaKey; // 0x50(0x10)
	struct TArray<struct FString> EulaKeys; // 0x60(0x10)
	struct TMap<struct FString, struct FString> EulaKeyMapping; // 0x70(0x50)
	bool bEnableWaitingRoom; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct TArray<struct FWebEnvUrl> WebCreateEpicAccountUrl; // 0xc8(0x10)
	bool bAllowLocalLogout; // 0xd8(0x01)
	char pad_D9[0x37]; // 0xd9(0x37)
	float DefaultLoginStepTimeout; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
	struct TMap<struct FName, float> CustomLoginStepTimeouts; // 0x118(0x50)
	bool bEnableDevLoginStepTimeouts; // 0x168(0x01)
	char pad_169[0x67]; // 0x169(0x67)
	struct FString RedeemAccessUrl; // 0x1d0(0x10)
	struct FString RequestFreeAccessUrl; // 0x1e0(0x10)
	struct FString RealGameAccessUrl; // 0x1f0(0x10)
	float SkipRedeemOfflinePurchasesChance; // 0x200(0x04)
	bool bUseFreeAccessInsteadOfGameAccess; // 0x204(0x01)
	bool bShouldGrantFreeAccess; // 0x205(0x01)
	char pad_206[0x1]; // 0x206(0x01)
	bool bAllowHomeSharingAccess; // 0x207(0x01)
	bool bRequireUGCPrivilege; // 0x208(0x01)
	char pad_209[0x22f]; // 0x209(0x22f)
	float AccessGrantDelaySeconds; // 0x438(0x04)
	char pad_43C[0x4]; // 0x43c(0x04)
	struct UWaitingRoomState* WaitingRoomState; // 0x440(0x08)
	char pad_448[0x360]; // 0x448(0x360)
	bool bAutoCreateHeadlessAccount; // 0x7a8(0x01)
	char pad_7A9[0xd7]; // 0x7a9(0xd7)
};

// Class Account.WaitingRoomState
// Size: 0x88 (Inherited: 0x28)
struct UWaitingRoomState : UObject {
	char pad_28[0x34]; // 0x28(0x34)
	int32_t GracePeriodMins; // 0x5c(0x04)
	char pad_60[0x28]; // 0x60(0x28)
};

