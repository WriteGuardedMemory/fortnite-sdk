// BlueprintGeneratedClass CommonUIRichTextData.CommonUIRichTextData_C
// Size: 0x30 (Inherited: 0x30)
struct UCommonUIRichTextData_C : UCommonUIRichTextData {
};

