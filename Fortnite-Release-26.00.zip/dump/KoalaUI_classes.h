// Class KoalaUI.FortGameSettingRegistryExtension_Koala
// Size: 0x68 (Inherited: 0x28)
struct UFortGameSettingRegistryExtension_Koala : UFortGameSettingRegistryExtension {
	char pad_28[0x8]; // 0x28(0x08)
	struct FFortSettingNameExtensions SettingExtensions; // 0x30(0x18)
	char pad_48[0x20]; // 0x48(0x20)
};

// Class KoalaUI.FortSidebarPanelKoala
// Size: 0x420 (Inherited: 0x3e8)
struct UFortSidebarPanelKoala : UCommonActivatableWidget {
	char pad_3E8[0x18]; // 0x3e8(0x18)
	struct UCommonButtonBase* Button_KoalaDummy; // 0x400(0x08)
	struct UFortLazyImage* QrCodeImage; // 0x408(0x08)
	struct FString QRCodeURL; // 0x410(0x10)

	void OnConnectionChanged(bool bConnected); // Function KoalaUI.FortSidebarPanelKoala.OnConnectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class KoalaUI.FortUIGameFeatureAction_AttemptKoalaModal
// Size: 0x68 (Inherited: 0x30)
struct UFortUIGameFeatureAction_AttemptKoalaModal : UFortUIGameFeatureAction_PostFrontendFlowActions {
	struct TSoftClassPtr<UObject> KoalaGraphicsModalClass; // 0x30(0x20)
	char pad_50[0x18]; // 0x50(0x18)
};

// Class KoalaUI.KoalaGraphicsModal
// Size: 0x410 (Inherited: 0x3e8)
struct UKoalaGraphicsModal : UCommonActivatableWidget {
	char pad_3E8[0x18]; // 0x3e8(0x18)
	struct UCommonButtonBase* Button_KeepEnabled; // 0x400(0x08)
	struct UCommonButtonBase* Button_Disable; // 0x408(0x08)
};

// Class KoalaUI.KoalaHUDWidget
// Size: 0x540 (Inherited: 0x3e8)
struct UKoalaHUDWidget : UCommonActivatableWidget {
	char pad_3E8[0x8]; // 0x3e8(0x08)
	float ClipDebounceTime; // 0x3f0(0x04)
	float PlayerKilledPlayerReminderTime; // 0x3f4(0x04)
	float MatchEndedReminderTime; // 0x3f8(0x04)
	float ClipReminderCooldownTime; // 0x3fc(0x04)
	float EliminationClipReminderDelayTime; // 0x400(0x04)
	char pad_404[0x4]; // 0x404(0x04)
	struct USoundSubmix* ClipAudioSubmix; // 0x408(0x08)
	struct UCommonActionWidget* ClipActionWidget; // 0x410(0x08)
	struct FDataTableRowHandle ClipObjectInputAction; // 0x418(0x10)
	char pad_428[0x8]; // 0x428(0x08)
	struct TMap<int32_t, struct FKoalaClipInfo> ClipTracker; // 0x430(0x50)
	char pad_480[0x8]; // 0x480(0x08)
	int32_t LastClipID; // 0x488(0x04)
	char pad_48C[0x16]; // 0x48c(0x16)
	enum class EKoalaMockClipMode MockClipMode; // 0x4a2(0x01)
	char pad_4A3[0x1]; // 0x4a3(0x01)
	int32_t MockClipUploadShortTime; // 0x4a4(0x04)
	int32_t MockClipUploadLongTime; // 0x4a8(0x04)
	int32_t MockClipCreateShortTime; // 0x4ac(0x04)
	int32_t MockClipCreateLongTime; // 0x4b0(0x04)
	char pad_4B4[0x8c]; // 0x4b4(0x8c)

	void UnregisterClipButtonInput(); // Function KoalaUI.KoalaHUDWidget.UnregisterClipButtonInput // (Final|Native|Private) // @ game+0xac162f0
	void RegisterClipButtonInput(); // Function KoalaUI.KoalaHUDWidget.RegisterClipButtonInput // (Final|Native|Private) // @ game+0xac16310
	void OnTouchAreaMouseDown(); // Function KoalaUI.KoalaHUDWidget.OnTouchAreaMouseDown // (Final|Native|Protected|BlueprintCallable) // @ game+0xac16720
	void OnReminderTimerStarted(float Time); // Function KoalaUI.KoalaHUDWidget.OnReminderTimerStarted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnReminderEnded(); // Function KoalaUI.KoalaHUDWidget.OnReminderEnded // (Final|Native|Protected|BlueprintCallable) // @ game+0xac16740
	void OnRecordingStatusChanged(enum class EKoalaRecording InRecordingStatus); // Function KoalaUI.KoalaHUDWidget.OnRecordingStatusChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnInputProgress(float Progress); // Function KoalaUI.KoalaHUDWidget.OnInputProgress // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnInputComplete(); // Function KoalaUI.KoalaHUDWidget.OnInputComplete // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnConnectionChanged(enum class EKoalaConnectionStatus InStatus); // Function KoalaUI.KoalaHUDWidget.OnConnectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnClipStatusChanged(int32_t InClipID, enum class EKoalaClipStatus InClipStatus, float InUploadProgress); // Function KoalaUI.KoalaHUDWidget.OnClipStatusChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnAvailabilityChanged(enum class EKoalaAvailability Availability); // Function KoalaUI.KoalaHUDWidget.OnAvailabilityChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandlePlayerPawnEmoteStopped(struct UFortItemDefinition* MontageItemDef, struct AFortPawn* PawnEmoting); // Function KoalaUI.KoalaHUDWidget.HandlePlayerPawnEmoteStopped // (Final|Native|Private) // @ game+0xac16430
	void HandlePlayerMatchWon(); // Function KoalaUI.KoalaHUDWidget.HandlePlayerMatchWon // (Final|Native|Private) // @ game+0xac166c0
	void HandleLocalPlayerKilledPlayer(struct AFortPlayerStateAthena* Player); // Function KoalaUI.KoalaHUDWidget.HandleLocalPlayerKilledPlayer // (Final|Native|Private) // @ game+0xac16330
	int32_t GetUploadingClipCount(); // Function KoalaUI.KoalaHUDWidget.GetUploadingClipCount // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xac166f0
	int32_t GetTrackedClipCount(); // Function KoalaUI.KoalaHUDWidget.GetTrackedClipCount // (Final|Native|Protected|BlueprintCallable) // @ game+0x9c767a0
};

// Class KoalaUI.KoalaMainMenuButton
// Size: 0x1600 (Inherited: 0x15f0)
struct UKoalaMainMenuButton : UFortMainMenuButtonExtension {
	char pad_15F0[0x10]; // 0x15f0(0x10)
};

// Class KoalaUI.KoalaSettingDetailExtension
// Size: 0x2b8 (Inherited: 0x2b0)
struct UKoalaSettingDetailExtension : UFortSettingDetailExtension {
	char pad_2B0[0x8]; // 0x2b0(0x08)

	void OnConnectionChanged(bool bConnected); // Function KoalaUI.KoalaSettingDetailExtension.OnConnectionChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnAvailabilityChanged(bool bAvailable); // Function KoalaUI.KoalaSettingDetailExtension.OnAvailabilityChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

