// Class CreativeRoyaleRuntime.CreativeRoyaleIslandPlayspace
// Size: 0x710 (Inherited: 0x698)
struct ACreativeRoyaleIslandPlayspace : AFortPlayspace {
	struct UFortProjectEditComponent_CreativeRoyale* ProjectEditComponent; // 0x698(0x08)
	struct UPlayspaceComponent_PlayStopPauseManager* PlayStopPauseManager; // 0x6a0(0x08)
	struct UPlayspaceComponent_CreativeLoadingStateProxy* CreativeLoadingStateProxy; // 0x6a8(0x08)
	struct UPlayspaceComponent_SpatialGameplay* SpatialGameplayComponent; // 0x6b0(0x08)
	struct UPlayspaceComponent_DeviceTracking* DeviceTrackerComponent; // 0x6b8(0x08)
	struct UPlayspaceComponent_CreativeModifyEmotes* CreativeModifyEmotesComponent; // 0x6c0(0x08)
	struct UFortPlayspaceComponent_WorldTimeOfDayOverride* WorldTimeOfDayOverrideComponent; // 0x6c8(0x08)
	struct UCreativeRoyalePlayspaceComponent_LoadingScreen* LoadingScreenComponent; // 0x6d0(0x08)
	struct UPlayspaceComponent_ActorMemoryTracker* ActorMemoryTracker; // 0x6d8(0x08)
	struct UFortPoiSwapManager* FortPoiSwapManager; // 0x6e0(0x08)
	char pad_6E8[0x8]; // 0x6e8(0x08)
	struct TArray<struct AActor*> FoundActors; // 0x6f0(0x10)
	int32_t IslandMemoryBudget; // 0x700(0x04)
	float MaxMemorySamplingHeight; // 0x704(0x04)
	float MaxMemorySamplingCellSize; // 0x708(0x04)
	char pad_70C[0x4]; // 0x70c(0x04)
};

// Class CreativeRoyaleRuntime.FortPoiSwapManager
// Size: 0x140 (Inherited: 0xa0)
struct UFortPoiSwapManager : UActorComponent {
	struct FMulticastInlineDelegate OnPlayspaceLoadedContentDelegate; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnPlayspaceUnloadedContentDelegate; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnPrePlayspaceContentUnloadDelegate; // 0xc0(0x10)
	char pad_D0[0x50]; // 0xd0(0x50)
	struct TWeakObjectPtr<struct UFortMcpProfileCreative> CachedIslandOwnerProfile; // 0x120(0x08)
	struct FVector PoiPlotLocationOffset; // 0x128(0x18)

	void SwapPoi(struct AFortPoiVolume* PoiToSwap); // Function CreativeRoyaleRuntime.FortPoiSwapManager.SwapPoi // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x34e0930
	void SetPoiSubPlot(struct AFortPoiVolume* POIVolume, struct FString SubPlotName, struct FString SubPlotLinkCode); // Function CreativeRoyaleRuntime.FortPoiSwapManager.SetPoiSubPlot // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xaa3d6f0
	void OnPrePlayspaceContentUnload(struct AFortPoiSwapPlayspace* PoiSwapPlayspace); // Function CreativeRoyaleRuntime.FortPoiSwapManager.OnPrePlayspaceContentUnload // (Final|Native|Protected) // @ game+0xaa3d410
	void OnPlayspaceContentLoadingStateChanged(struct AFortPoiSwapPlayspace* PoiSwapPlayspace, enum class EFortPoiSwapUserContentState& ContentLoadingState); // Function CreativeRoyaleRuntime.FortPoiSwapManager.OnPlayspaceContentLoadingStateChanged // (Final|Native|Protected|HasOutParms) // @ game+0xaa3d510
	struct FString GetPoiSubPlotLinkCode(struct AFortPoiVolume* POIVolume); // Function CreativeRoyaleRuntime.FortPoiSwapManager.GetPoiSubPlotLinkCode // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa3d950
	struct AFortPoiSwapPlayspace* GetPlayspaceForPoi(struct AFortPoiVolume* POIVolume); // Function CreativeRoyaleRuntime.FortPoiSwapManager.GetPlayspaceForPoi // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa3db00
};

// Class CreativeRoyaleRuntime.FortPoiSwapPlayspace
// Size: 0x748 (Inherited: 0x698)
struct AFortPoiSwapPlayspace : AFortPlayspace {
	struct FMulticastInlineDelegate OnContentStateChangedDelegate; // 0x698(0x10)
	struct FMulticastInlineDelegate OnPreContentUnloadDelegate; // 0x6a8(0x10)
	struct USceneComponent* SceneComponent; // 0x6b8(0x08)
	struct UFortLevelSaveComponent* LevelSaveComponent; // 0x6c0(0x08)
	struct UPlaysetLevelStreamComponent* PlaysetLevelStreamComponent; // 0x6c8(0x08)
	struct TWeakObjectPtr<struct AFortPoiVolume> PoiToReplace; // 0x6d0(0x08)
	struct TWeakObjectPtr<struct UFortCreativeRealEstatePlotItem> PlotToLoad; // 0x6d8(0x08)
	struct TWeakObjectPtr<struct UFortCreativeRealEstatePlotItem> LoadedPlot; // 0x6e0(0x08)
	struct FOnlineLinkId LinkCodeToLoad; // 0x6e8(0x18)
	struct TArray<struct AActor*> SpawnedActors; // 0x700(0x10)
	char pad_710[0x38]; // 0x710(0x38)

	void OnUserContentUnloaded(struct FAsyncTaskResult& Result); // Function CreativeRoyaleRuntime.FortPoiSwapPlayspace.OnUserContentUnloaded // (Final|Native|Protected|HasOutParms) // @ game+0xaa3e1c0
	void OnUserContentLoaded(); // Function CreativeRoyaleRuntime.FortPoiSwapPlayspace.OnUserContentLoaded // (Final|Native|Protected) // @ game+0xaa3e340
};

// Class CreativeRoyaleRuntime.AthenaAIServicePlayerBots_CreativeRoyale
// Size: 0x1380 (Inherited: 0x1310)
struct UAthenaAIServicePlayerBots_CreativeRoyale : UAthenaAIServiceCreativePlayerBots {
	struct FScalableFloat PlayerBotsEnabled; // 0x1308(0x28)
	struct FScalableFloat BotsAllowedOnHumanTeam; // 0x1330(0x28)
	struct FScalableFloat ForceAllPlayerBotsToOneTeam; // 0x1358(0x28)

	void StartLootClustering(); // Function CreativeRoyaleRuntime.AthenaAIServicePlayerBots_CreativeRoyale.StartLootClustering // (Final|Native|Protected) // @ game+0xaa3e7b0
	void OnPlayerJoiningInProgress(struct AFortPlayerState* FortPlayerState); // Function CreativeRoyaleRuntime.AthenaAIServicePlayerBots_CreativeRoyale.OnPlayerJoiningInProgress // (Final|Native|Protected) // @ game+0xaa3e7d0
};

// Class CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset
// Size: 0x220 (Inherited: 0xa0)
struct UCreativeRoyalePlayspaceComponent_LevelReset : UPlayspaceComponent {
	struct TWeakObjectPtr<struct ULevelSaveRecord> CachedLevelSaveRecord; // 0xa0(0x08)
	bool bSpawnFromGameplay; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct TArray<struct TWeakObjectPtr<struct AActor>> SavedFoundActors; // 0xb0(0x10)
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct FSpawnBuildingActorParameters> SavedDeadActors; // 0xc0(0x50)
	struct TArray<struct TWeakObjectPtr<struct AActor>> SavedDamagedActors; // 0x110(0x10)
	struct TArray<struct TWeakObjectPtr<struct AActor>> FoundActorsDied; // 0x120(0x10)
	struct TArray<struct FGuid> FoundActorsDiedGuid; // 0x130(0x10)
	struct TMap<struct FGuid, struct FAttachedBuildingActorGuids> SavedParentWithAttachedBuildings; // 0x140(0x50)
	struct TMap<struct FGuid, struct TWeakObjectPtr<struct AActor>> CurrentActorForBuildingGuid; // 0x190(0x50)
	struct TArray<struct TWeakObjectPtr<struct AActor>> FoundActorsDamaged; // 0x1e0(0x10)
	struct TArray<struct FGuid> FoundActorsDamagedGuid; // 0x1f0(0x10)
	struct TWeakObjectPtr<struct UFortPoiSwapManager> CachedPoiSwapManager; // 0x200(0x08)
	char pad_208[0x18]; // 0x208(0x18)

	void SaveParentToAttachToInformation(struct FGuid ActorToAttachGuid, struct AActor* ActorToAttach); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.SaveParentToAttachToInformation // (Final|Native|Private|HasDefaults) // @ game+0xaa419d0
	void SaveDamagedActor(struct AActor* DamagedActor); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.SaveDamagedActor // (Final|Native|Private) // @ game+0x34e0930
	void SaveActorToBeRespawned(struct AActor* ActorToBeRespawned, bool bRemoveDamagedActor); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.SaveActorToBeRespawned // (Final|Native|Private) // @ game+0x7438c10
	void RestoreAttachedBuildingActors(struct FGuid SpawnableActorGuid, struct AActor* Actor); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.RestoreAttachedBuildingActors // (Final|Native|Private|HasDefaults) // @ game+0xaa41840
	void RespawnDeadActors(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.RespawnDeadActors // (Final|Native|Private) // @ game+0x3982d70
	void OnSpawningFromSaveFinish(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.OnSpawningFromSaveFinish // (Final|Native|Private) // @ game+0x3982d70
	void OnPlotLoadComplete(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.OnPlotLoadComplete // (Final|Native|Private) // @ game+0x3982d70
	void HandleMinigameStateChanged(struct AFortMinigame* Minigame, enum class EFortMinigameState NewMinigameState); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.HandleMinigameStateChanged // (Final|Native|Private) // @ game+0x77d5090
	void HandleBuildingDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.HandleBuildingDied // (Final|Native|Private|HasDefaults) // @ game+0x78001f0
	void HandleBuildingDestroyed(struct TWeakObjectPtr<struct ABuildingActor> DestroyedBuilding); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.HandleBuildingDestroyed // (Final|Native|Private) // @ game+0xaa41770
	void HandleBuildingDamaged(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.HandleBuildingDamaged // (Final|Native|Private|HasDefaults) // @ game+0x78001f0
	struct UFortPoiSwapManager* GetPoiSwapManager(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.GetPoiSwapManager // (Final|Native|Protected) // @ game+0xaa41400
	struct ULevelSaveRecord* GetLevelSaveRecord(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.GetLevelSaveRecord // (Final|Native|Private) // @ game+0x4519590
	void DestroyDamagedActors(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.DestroyDamagedActors // (Final|Native|Private) // @ game+0x3982d70
	void ClearFoundActors(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.ClearFoundActors // (Final|Native|Private) // @ game+0x3982d70
	void CachePoiSwapManager(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.CachePoiSwapManager // (Final|Native|Protected) // @ game+0xaa41430
	void BindActorToCallbacks(struct AActor* Actor); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.BindActorToCallbacks // (Final|Native|Private) // @ game+0xaa41450
	void AddActorToTrack(struct AActor* ActorToTrack); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LevelReset.AddActorToTrack // (Final|Native|Public) // @ game+0x34e0930
};

// Class CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen
// Size: 0x128 (Inherited: 0xa0)
struct UCreativeRoyalePlayspaceComponent_LoadingScreen : UPlayspaceComponent_LoadingScreen {
	bool bShouldDisplayLoadingScreenDuringPostGame; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct FText PlotNotFinishedLoadingContext; // 0xa8(0x18)
	struct FText MinigameResetContext; // 0xc0(0x18)
	char pad_D8[0x18]; // 0xd8(0x18)
	struct FScalableFloat FailsafeTimeoutLength; // 0xf0(0x28)
	char pad_118[0x10]; // 0x118(0x10)

	void OnPlotLoadComplete(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnPlotLoadComplete // (Final|Native|Private) // @ game+0xaa43660
	void OnPlayspaceUserAdded(struct FPlayspaceUser& AddedUser); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnPlayspaceUserAdded // (Final|Native|Private|HasOutParms) // @ game+0xaa43680
	void OnMinigameStateChanged(struct AFortMinigame* Minigame, enum class EFortMinigameState MinigameState); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_LoadingScreen.OnMinigameStateChanged // (Final|Native|Private) // @ game+0xaa43860
};

// Class CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_PlayerSpawning
// Size: 0xb0 (Inherited: 0xb0)
struct UCreativeRoyalePlayspaceComponent_PlayerSpawning : UFortPlayspaceComponent_PlayerSpawning {
};

// Class CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_RemoveItems
// Size: 0xc8 (Inherited: 0xa0)
struct UCreativeRoyalePlayspaceComponent_RemoveItems : UPlayspaceComponent {
	bool bSpawnFromGameplay; // 0xa0(0x01)
	char pad_A1[0x27]; // 0xa1(0x27)

	void OnSpawningFromSaveFinish(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_RemoveItems.OnSpawningFromSaveFinish // (Final|Native|Private) // @ game+0x3982d70
	void OnPlotLoadComplete(); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_RemoveItems.OnPlotLoadComplete // (Final|Native|Private) // @ game+0x3982d70
	void HandleMinigameStateChanged(struct AFortMinigame* Minigame, enum class EFortMinigameState NewMinigameState); // Function CreativeRoyaleRuntime.CreativeRoyalePlayspaceComponent_RemoveItems.HandleMinigameStateChanged // (Final|Native|Private) // @ game+0x77d5090
};

// Class CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace
// Size: 0x6d0 (Inherited: 0x698)
struct ACreativeRoyaleRootPlayspace : AFortPlayspace {
	char pad_698[0x18]; // 0x698(0x18)
	struct AFortPlayerControllerAthena* EditorIslandOwnerPlayerController; // 0x6b0(0x08)
	char pad_6B8[0x8]; // 0x6b8(0x08)
	bool bHasPlotLoaded; // 0x6c0(0x01)
	char pad_6C1[0xf]; // 0x6c1(0x0f)

	void TeleportPlayersToPlayerStarts(); // Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.TeleportPlayersToPlayerStarts // (Final|Native|Protected) // @ game+0x3982d70
	void OnRep_bHasPlotLoaded(); // Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.OnRep_bHasPlotLoaded // (Final|Native|Private) // @ game+0xaa45710
	void OnPlotLoadComplete(); // Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.OnPlotLoadComplete // (Final|Native|Private) // @ game+0xaa45740
	void Cheat_LoadEditorIsland(); // Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.Cheat_LoadEditorIsland // (Final|Native|Protected) // @ game+0x3982d70
	bool BuildDataRegistryResolverScope_Implementation(struct TArray<struct FName>& InOutResolverScopes, int32_t& InOutPriority); // Function CreativeRoyaleRuntime.CreativeRoyaleRootPlayspace.BuildDataRegistryResolverScope_Implementation // (Native|Public|HasOutParms|Const) // @ game+0xaa45770
};

// Class CreativeRoyaleRuntime.FortAthenaMutator_CreativeRoyaleSafeZoneOverride
// Size: 0x338 (Inherited: 0x338)
struct AFortAthenaMutator_CreativeRoyaleSafeZoneOverride : AFortAthenaMutator {
};

// Class CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale
// Size: 0x48 (Inherited: 0x38)
struct UFortCheatManager_CreativeRoyale : UFortCheatManager_Coupled {
	struct UFortCreativeRealEstatePlotItemDefinition* CreativeRoyaleEditPlotDefinition; // 0x38(0x08)
	struct FGameplayTag CreativeRoyaleVolumeTag; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)

	void TeleportToPlotAferLoad(); // Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.TeleportToPlotAferLoad // (Final|Native|Protected|Const) // @ game+0xaa46190
	void CreativeRoyaleTeleportToEditZone(); // Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleTeleportToEditZone // (Final|Exec|Native|Public|Const) // @ game+0x3982d70
	void CreativeRoyaleResetIslandFile(); // Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleResetIslandFile // (Final|Exec|Native|Public|Const) // @ game+0xaa461e0
	void CreativeRoyaleLoadEditPlot(); // Function CreativeRoyaleRuntime.FortCheatManager_CreativeRoyale.CreativeRoyaleLoadEditPlot // (Final|Exec|Native|Public|Const) // @ game+0x3982d70
};

// Class CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale
// Size: 0x510 (Inherited: 0x500)
struct UFortProjectEditComponent_CreativeRoyale : UFortProjectEditComponent {
	char pad_500[0x8]; // 0x500(0x08)
	struct UFortCreativeRealEstatePlotItemDefinition* CreativeRoyaleEditPlotDefinition; // 0x508(0x08)

	void OnPlayerLoggedIn(struct APlayerController* PlayerController); // Function CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale.OnPlayerLoggedIn // (Final|Native|Protected) // @ game+0x34e0930
	void LoadPlotFromProject(); // Function CreativeRoyaleRuntime.FortProjectEditComponent_CreativeRoyale.LoadPlotFromProject // (Final|Native|Protected) // @ game+0x3982d70
};

