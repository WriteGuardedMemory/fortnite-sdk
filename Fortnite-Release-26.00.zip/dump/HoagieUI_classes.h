// Class HoagieUI.FortHoagieVehicleReticle
// Size: 0x488 (Inherited: 0x480)
struct UFortHoagieVehicleReticle : UFortAthenaVehicleDashboardWidget {
	struct AFortHoagieVehicle* OwningHoagieVehicle; // 0x480(0x08)

	void OnSetupComplete(bool bVehicleUsesFuelSystem); // Function HoagieUI.FortHoagieVehicleReticle.OnSetupComplete // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

