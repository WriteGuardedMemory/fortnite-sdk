// Class HomerUI.FortHomerComponent
// Size: 0x128 (Inherited: 0xa0)
struct UFortHomerComponent : UActorComponent {
	char pad_A0[0x88]; // 0xa0(0x88)

	void HandlePawnEmoteStopped(struct UFortItemDefinition* MontageItemDef, struct AFortPawn* PawnEmoting); // Function HomerUI.FortHomerComponent.HandlePawnEmoteStopped // (Final|Native|Private) // @ game+0xac1e680
	void HandleLocalPlayerEliminatedPlayer(struct AFortPlayerStateAthena* Player); // Function HomerUI.FortHomerComponent.HandleLocalPlayerEliminatedPlayer // (Final|Native|Private) // @ game+0xac1e590
};

