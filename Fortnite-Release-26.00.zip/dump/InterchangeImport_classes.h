// Class InterchangeImport.InterchangeAnimationPayloadInterface
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeAnimationPayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeAnimationTrackSetFactory
// Size: 0x38 (Inherited: 0x30)
struct UInterchangeAnimationTrackSetFactory : UInterchangeFactoryBase {
	char pad_30[0x8]; // 0x30(0x08)
};

// Class InterchangeImport.InterchangeBlockedTexturePayloadInterface
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeBlockedTexturePayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeActorFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeActorFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeLightActorFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeLightActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeMeshPayloadInterface
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeMeshPayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeSceneImportAssetFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeSceneImportAssetFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeSceneVariantSetsFactory
// Size: 0x38 (Inherited: 0x30)
struct UInterchangeSceneVariantSetsFactory : UInterchangeFactoryBase {
	char pad_30[0x8]; // 0x30(0x08)
};

// Class InterchangeImport.InterchangeSlicedTexturePayloadInterface
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeSlicedTexturePayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeTextureLightProfilePayloadInterface
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeTextureLightProfilePayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeTexturePayloadInterface
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeTexturePayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeVariantSetPayloadInterface
// Size: 0x28 (Inherited: 0x28)
struct UInterchangeVariantSetPayloadInterface : UInterface {
};

// Class InterchangeImport.MaterialExpressionMaterialXRamp4
// Size: 0x180 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXRamp4 : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	struct FExpressionInput A; // 0xd8(0x28)
	struct FExpressionInput B; // 0x100(0x28)
	struct FExpressionInput C; // 0x128(0x28)
	struct FExpressionInput D; // 0x150(0x28)
	char ConstCoordinate; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)
};

// Class InterchangeImport.InterchangeAnimSequenceFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeAnimSequenceFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeFbxTranslator
// Size: 0x58 (Inherited: 0x38)
struct UInterchangeFbxTranslator : UInterchangeTranslatorBase {
	char pad_38[0x20]; // 0x38(0x20)
};

// Class InterchangeImport.InterchangeGLTFTranslator
// Size: 0x278 (Inherited: 0x38)
struct UInterchangeGLTFTranslator : UInterchangeTranslatorBase {
	char pad_38[0x240]; // 0x38(0x240)
};

// Class InterchangeImport.InterchangeMaterialXTranslator
// Size: 0x40 (Inherited: 0x38)
struct UInterchangeMaterialXTranslator : UInterchangeTranslatorBase {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class InterchangeImport.MaterialExpressionMaterialXAppend3Vector
// Size: 0x128 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXAppend3Vector : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput C; // 0x100(0x28)
};

// Class InterchangeImport.MaterialExpressionMaterialXAppend4Vector
// Size: 0x150 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXAppend4Vector : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput C; // 0x100(0x28)
	struct FExpressionInput D; // 0x128(0x28)
};

// Class InterchangeImport.MaterialExpressionMaterialXBurn
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXBurn : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXDifference
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXDifference : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXDisjointOver
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXDisjointOver : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXDodge
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXDodge : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXFractal3D
// Size: 0x1a8 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXFractal3D : UMaterialExpression {
	struct FExpressionInput Position; // 0xb0(0x28)
	struct FExpressionInput Amplitude; // 0xd8(0x28)
	float ConstAmplitude; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	struct FExpressionInput Octaves; // 0x108(0x28)
	int32_t ConstOctaves; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct FExpressionInput Lacunarity; // 0x138(0x28)
	float ConstLacunarity; // 0x160(0x04)
	char pad_164[0x4]; // 0x164(0x04)
	struct FExpressionInput Diminish; // 0x168(0x28)
	float ConstDiminish; // 0x190(0x04)
	float Scale; // 0x194(0x04)
	bool bTurbulence; // 0x198(0x01)
	char pad_199[0x3]; // 0x199(0x03)
	int32_t Levels; // 0x19c(0x04)
	float OutputMin; // 0x1a0(0x04)
	float OutputMax; // 0x1a4(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXIn
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXIn : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXLuminance
// Size: 0xf0 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXLuminance : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	struct FLinearColor LuminanceFactors; // 0xd8(0x10)
	enum class EMaterialXLuminanceMode LuminanceMode; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
};

// Class InterchangeImport.MaterialExpressionMaterialXMask
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXMask : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXMatte
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXMatte : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXMinus
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXMinus : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXOut
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXOut : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXOver
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXOver : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXOverlay
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXOverlay : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXPlace2D
// Size: 0x180 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXPlace2D : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	struct FExpressionInput Pivot; // 0xd8(0x28)
	struct FExpressionInput Scale; // 0x100(0x28)
	struct FExpressionInput Offset; // 0x128(0x28)
	struct FExpressionInput RotationAngle; // 0x150(0x28)
	float ConstRotationAngle; // 0x178(0x04)
	char ConstCoordinate; // 0x17c(0x01)
	char pad_17D[0x3]; // 0x17d(0x03)
};

// Class InterchangeImport.MaterialExpressionMaterialXPlus
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXPlus : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXPremult
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXPremult : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class InterchangeImport.MaterialExpressionMaterialXRampLeftRight
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXRampLeftRight : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	struct FExpressionInput A; // 0xd8(0x28)
	struct FExpressionInput B; // 0x100(0x28)
	char ConstCoordinate; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class InterchangeImport.MaterialExpressionMaterialXRampTopBottom
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXRampTopBottom : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	struct FExpressionInput A; // 0xd8(0x28)
	struct FExpressionInput B; // 0x100(0x28)
	char ConstCoordinate; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class InterchangeImport.MaterialExpressionMaterialXRemap
// Size: 0x188 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXRemap : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	struct FExpressionInput InputLow; // 0xd8(0x28)
	struct FExpressionInput InputHigh; // 0x100(0x28)
	struct FExpressionInput TargetLow; // 0x128(0x28)
	struct FExpressionInput TargetHigh; // 0x150(0x28)
	float InputLowDefault; // 0x178(0x04)
	float InputHighDefault; // 0x17c(0x04)
	float TargetLowDefault; // 0x180(0x04)
	float TargetHighDefault; // 0x184(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXRotate2D
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXRotate2D : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	struct FExpressionInput RotationAngle; // 0xd8(0x28)
	float ConstRotationAngle; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXScreen
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXScreen : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstAlpha; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXSplitLeftRight
// Size: 0x158 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXSplitLeftRight : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	struct FExpressionInput A; // 0xd8(0x28)
	struct FExpressionInput B; // 0x100(0x28)
	struct FExpressionInput Center; // 0x128(0x28)
	float ConstCenter; // 0x150(0x04)
	char ConstCoordinate; // 0x154(0x01)
	char pad_155[0x3]; // 0x155(0x03)
};

// Class InterchangeImport.MaterialExpressionMaterialXSplitTopBottom
// Size: 0x158 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXSplitTopBottom : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	struct FExpressionInput A; // 0xd8(0x28)
	struct FExpressionInput B; // 0x100(0x28)
	struct FExpressionInput Center; // 0x128(0x28)
	float ConstCenter; // 0x150(0x04)
	char ConstCoordinate; // 0x154(0x01)
	char pad_155[0x3]; // 0x155(0x03)
};

// Class InterchangeImport.MaterialExpressionMaterialXSwizzle
// Size: 0xe8 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXSwizzle : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	struct FString Channels; // 0xd8(0x10)
};

// Class InterchangeImport.MaterialExpressionMaterialXTextureSampleParameterBlur
// Size: 0x248 (Inherited: 0x238)
struct UMaterialExpressionMaterialXTextureSampleParameterBlur : UMaterialExpressionTextureSampleParameter2D {
	enum class EMAterialXTextureSampleBlurKernel KernelSize; // 0x238(0x04)
	float FilterSize; // 0x23c(0x04)
	float FilterOffset; // 0x240(0x04)
	enum class EMaterialXTextureSampleBlurFilter Filter; // 0x244(0x01)
	char pad_245[0x3]; // 0x245(0x03)
};

// Class InterchangeImport.MaterialExpressionMaterialXUnpremult
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionMaterialXUnpremult : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class InterchangeImport.InterchangeMaterialFactory
// Size: 0x38 (Inherited: 0x30)
struct UInterchangeMaterialFactory : UInterchangeFactoryBase {
	char pad_30[0x8]; // 0x30(0x08)
};

// Class InterchangeImport.InterchangeMaterialFunctionFactory
// Size: 0x38 (Inherited: 0x30)
struct UInterchangeMaterialFunctionFactory : UInterchangeFactoryBase {
	char pad_30[0x8]; // 0x30(0x08)
};

// Class InterchangeImport.InterchangeOBJTranslator
// Size: 0x50 (Inherited: 0x38)
struct UInterchangeOBJTranslator : UInterchangeTranslatorBase {
	char pad_38[0x18]; // 0x38(0x18)
};

// Class InterchangeImport.InterchangePhysicsAssetFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangePhysicsAssetFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeSkeletalMeshFactory
// Size: 0x60 (Inherited: 0x30)
struct UInterchangeSkeletalMeshFactory : UInterchangeFactoryBase {
	char pad_30[0x30]; // 0x30(0x30)
};

// Class InterchangeImport.InterchangeSkeletonFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeSkeletonFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeStaticMeshFactory
// Size: 0x48 (Inherited: 0x30)
struct UInterchangeStaticMeshFactory : UInterchangeFactoryBase {
	char pad_30[0x18]; // 0x30(0x18)
};

// Class InterchangeImport.InterchangeCineCameraActorFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeCineCameraActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeCameraActorFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeCameraActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeSkeletalMeshActorFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeSkeletalMeshActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeStaticMeshActorFactory
// Size: 0x30 (Inherited: 0x30)
struct UInterchangeStaticMeshActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeDDSTranslator
// Size: 0x48 (Inherited: 0x38)
struct UInterchangeDDSTranslator : UInterchangeTranslatorBase {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class InterchangeImport.InterchangeIESTranslator
// Size: 0x40 (Inherited: 0x38)
struct UInterchangeIESTranslator : UInterchangeTranslatorBase {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class InterchangeImport.InterchangeImageWrapperTranslator
// Size: 0x48 (Inherited: 0x38)
struct UInterchangeImageWrapperTranslator : UInterchangeTranslatorBase {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class InterchangeImport.InterchangeJPGTranslator
// Size: 0x40 (Inherited: 0x38)
struct UInterchangeJPGTranslator : UInterchangeTranslatorBase {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class InterchangeImport.InterchangePCXTranslator
// Size: 0x40 (Inherited: 0x38)
struct UInterchangePCXTranslator : UInterchangeTranslatorBase {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class InterchangeImport.InterchangePSDTranslator
// Size: 0x40 (Inherited: 0x38)
struct UInterchangePSDTranslator : UInterchangeTranslatorBase {
	char pad_38[0x8]; // 0x38(0x08)
};

// Class InterchangeImport.InterchangeTextureFactory
// Size: 0xc0 (Inherited: 0x30)
struct UInterchangeTextureFactory : UInterchangeFactoryBase {
	char pad_30[0x90]; // 0x30(0x90)
};

