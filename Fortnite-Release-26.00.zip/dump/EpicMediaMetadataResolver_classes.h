// Class EpicMediaMetadataResolver.EpicMediaMetadataResolver
// Size: 0x230 (Inherited: 0xa0)
struct UEpicMediaMetadataResolver : UActorComponent {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	struct FMulticastInlineDelegate MetadataResultExt; // 0xc0(0x10)
	struct UEpicMediaCDNHostnames* CDNHostNames; // 0xd0(0x08)
	char pad_D8[0x158]; // 0xd8(0x158)

	bool GetData(struct FString UID, bool bLive, struct FEpicMediaOptions InMediaOptions); // Function EpicMediaMetadataResolver.EpicMediaMetadataResolver.GetData // (Final|Native|Public|BlueprintCallable) // @ game+0x615c270
	bool GetBlurl(struct FString InVUID, bool bInBlurlLive, struct FEpicMediaOptions InMediaOptions); // Function EpicMediaMetadataResolver.EpicMediaMetadataResolver.GetBlurl // (Final|Native|Public|BlueprintCallable) // @ game+0x615b960
};

