// Class AudioMotorSim.AudioMotorModelComponent
// Size: 0x100 (Inherited: 0xa0)
struct UAudioMotorModelComponent : UActorComponent {
	struct TArray<struct FMotorSimEntry> SimComponents; // 0xa0(0x10)
	struct TArray<struct TScriptInterface<IAudioMotorSimOutput>> AudioComponents; // 0xb0(0x10)
	char pad_C0[0x40]; // 0xc0(0x40)

	void Update(struct FAudioMotorSimInputContext Input); // Function AudioMotorSim.AudioMotorModelComponent.Update // (Native|Public|BlueprintCallable) // @ game+0xa7839b0
	void StopOutput(); // Function AudioMotorSim.AudioMotorModelComponent.StopOutput // (Native|Public|BlueprintCallable) // @ game+0x3f4ccb0
	void StartOutput(); // Function AudioMotorSim.AudioMotorModelComponent.StartOutput // (Native|Public|BlueprintCallable) // @ game+0x508d080
	void Reset(); // Function AudioMotorSim.AudioMotorModelComponent.Reset // (Native|Public|BlueprintCallable) // @ game+0x45844a0
	void RemoveMotorSimComponent(struct TScriptInterface<IAudioMotorSim> InComponent); // Function AudioMotorSim.AudioMotorModelComponent.RemoveMotorSimComponent // (Final|Native|Public|BlueprintCallable) // @ game+0xa783340
	void RemoveMotorAudioComponent(struct TScriptInterface<IAudioMotorSimOutput> InComponent); // Function AudioMotorSim.AudioMotorModelComponent.RemoveMotorAudioComponent // (Final|Native|Public|BlueprintCallable) // @ game+0xa783630
	struct FAudioMotorSimRuntimeContext GetRuntimeInfo(); // Function AudioMotorSim.AudioMotorModelComponent.GetRuntimeInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa783310
	float GetRpm(); // Function AudioMotorSim.AudioMotorModelComponent.GetRpm // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3c398e0
	int32_t GetGear(); // Function AudioMotorSim.AudioMotorModelComponent.GetGear // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7cc76e0
	struct FAudioMotorSimInputContext GetCachedInputData(); // Function AudioMotorSim.AudioMotorModelComponent.GetCachedInputData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa7832c0
	void AddMotorSimComponent(struct TScriptInterface<IAudioMotorSim> InComponent, int32_t SortOrder); // Function AudioMotorSim.AudioMotorModelComponent.AddMotorSimComponent // (Final|Native|Public|BlueprintCallable) // @ game+0xa7834a0
	void AddMotorAudioComponent(struct TScriptInterface<IAudioMotorSimOutput> InComponent); // Function AudioMotorSim.AudioMotorModelComponent.AddMotorAudioComponent // (Final|Native|Public|BlueprintCallable) // @ game+0xa783880
};

// Class AudioMotorSim.AudioMotorSim
// Size: 0x28 (Inherited: 0x28)
struct UAudioMotorSim : UInterface {

	void Reset(); // Function AudioMotorSim.AudioMotorSim.Reset // (Native|Public|BlueprintCallable) // @ game+0x4f5bba0
};

// Class AudioMotorSim.AudioMotorSimComponent
// Size: 0xa8 (Inherited: 0xa0)
struct UAudioMotorSimComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)

	bool BP_Update(struct FAudioMotorSimInputContext& Input, struct FAudioMotorSimRuntimeContext& RuntimeInfo); // Function AudioMotorSim.AudioMotorSimComponent.BP_Update // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void BP_Reset(); // Function AudioMotorSim.AudioMotorSimComponent.BP_Reset // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1b027f0
};

// Class AudioMotorSim.AudioMotorSimOutput
// Size: 0x28 (Inherited: 0x28)
struct UAudioMotorSimOutput : UInterface {
};

