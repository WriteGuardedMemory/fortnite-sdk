// Enum EncountersRuntime.EEncounterMobSpawnType
enum class EEncounterMobSpawnType : uint8 {
	VolumeBased = 0,
	StaticPointBased = 1,
	EEncounterMobSpawnType_MAX = 2
};

// ScriptStruct EncountersRuntime.EncounterMobSpawnInfo
// Size: 0xa0 (Inherited: 0x00)
struct FEncounterMobSpawnInfo {
	struct FScalableFloat LeashRadiusInner; // 0x00(0x28)
	struct FScalableFloat LeashRadiusOuter; // 0x28(0x28)
	struct TWeakObjectPtr<struct AEncounterMobAnchor> EncounterAnchorPoint; // 0x50(0x08)
	enum class EEncounterMobSpawnType MobSpawnType; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FGameplayTagContainer PointProviderFilterTags; // 0x60(0x20)
	struct TArray<struct TWeakObjectPtr<struct AFortAthenaLivingWorldStaticPointProvider>> StaticPointProviders; // 0x80(0x10)
	struct UEnvQuery* PointProviderEQS; // 0x90(0x08)
	struct AFortAthenaLivingWorldVolume* PointProviderVolumeClass; // 0x98(0x08)
};

// ScriptStruct EncountersRuntime.EncounterMobSpawnData
// Size: 0xe0 (Inherited: 0x00)
struct FEncounterMobSpawnData {
	struct FString DevNotes; // 0x00(0x10)
	struct FGameplayTag MobIdentifier; // 0x10(0x04)
	bool bActiveOnStart; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter> MobEncounterData; // 0x18(0x20)
	bool bOverrideDefaultSpawnInfo; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FEncounterMobSpawnInfo MobSpawnInfo; // 0x40(0xa0)
};

// ScriptStruct EncountersRuntime.EncounterMobInstance
// Size: 0x58 (Inherited: 0x00)
struct FEncounterMobInstance {
	char pad_0[0x18]; // 0x00(0x18)
	struct AFortAthenaLivingWorldVolume* VolumePointProvider; // 0x18(0x08)
	char pad_20[0x10]; // 0x20(0x10)
	struct TArray<struct TScriptInterface<IFortAthenaLivingWorldPointProviderInterface>> CurrentPointProviders; // 0x30(0x10)
	char pad_40[0x18]; // 0x40(0x18)
};

// ScriptStruct EncountersRuntime.EncounterGetVariableBoolStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FEncounterGetVariableBoolStateTreeTaskInstanceData {
	struct FGameplayTag VariableIdentifier; // 0x00(0x04)
	bool bValue; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct AActor* UserActor; // 0x08(0x08)
};

// ScriptStruct EncountersRuntime.EncounterGetVariableBoolStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FEncounterGetVariableBoolStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.EncounterGetVariableFloatStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FEncounterGetVariableFloatStateTreeTaskInstanceData {
	struct FGameplayTag VariableIdentifier; // 0x00(0x04)
	float Value; // 0x04(0x04)
	struct AActor* UserActor; // 0x08(0x08)
};

// ScriptStruct EncountersRuntime.EncounterGetVariableFloatStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FEncounterGetVariableFloatStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.EncounterGetVariableGameplayTagStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FEncounterGetVariableGameplayTagStateTreeTaskInstanceData {
	struct FGameplayTag VariableIdentifier; // 0x00(0x04)
	struct FGameplayTag Value; // 0x04(0x04)
	struct AActor* UserActor; // 0x08(0x08)
};

// ScriptStruct EncountersRuntime.EncounterGetVariableGameplayTagStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FEncounterGetVariableGameplayTagStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.EncounterGetVariableIntStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FEncounterGetVariableIntStateTreeTaskInstanceData {
	struct FGameplayTag VariableIdentifier; // 0x00(0x04)
	int32_t Value; // 0x04(0x04)
	struct AActor* UserActor; // 0x08(0x08)
};

// ScriptStruct EncountersRuntime.EncounterGetVariableIntStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FEncounterGetVariableIntStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.EncounterGetVariableItemDefinitionStateTreeTaskInstanceData
// Size: 0x30 (Inherited: 0x00)
struct FEncounterGetVariableItemDefinitionStateTreeTaskInstanceData {
	struct FGameplayTag VariableIdentifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UFortWorldItemDefinition> Value; // 0x08(0x20)
	struct AActor* UserActor; // 0x28(0x08)
};

// ScriptStruct EncountersRuntime.EncounterGetVariableItemDefinitionStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FEncounterGetVariableItemDefinitionStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.EncounterGetVariableLWMEncounterStateTreeTaskInstanceData
// Size: 0x30 (Inherited: 0x00)
struct FEncounterGetVariableLWMEncounterStateTreeTaskInstanceData {
	struct FGameplayTag VariableIdentifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter> Value; // 0x08(0x20)
	struct AActor* UserActor; // 0x28(0x08)
};

// ScriptStruct EncountersRuntime.EncounterGetVariableLWMEncounterStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FEncounterGetVariableLWMEncounterStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.EncounterGetVariableTagQueryStateTreeTaskInstanceData
// Size: 0x58 (Inherited: 0x00)
struct FEncounterGetVariableTagQueryStateTreeTaskInstanceData {
	struct FGameplayTag VariableIdentifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FGameplayTagQuery Value; // 0x08(0x48)
	struct AActor* UserActor; // 0x50(0x08)
};

// ScriptStruct EncountersRuntime.EncounterGetVariableTagQueryStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FEncounterGetVariableTagQueryStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.EncounterPrefabEntry
// Size: 0x38 (Inherited: 0x00)
struct FEncounterPrefabEntry {
	struct UEncounterItemDefinition* EncounterDefinition; // 0x00(0x08)
	struct FGameplayTag EncounterIdentifierTag; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FScalableFloat Weight; // 0x10(0x28)
};

// ScriptStruct EncountersRuntime.EncounterVariable
// Size: 0x10 (Inherited: 0x00)
struct FEncounterVariable {
	char pad_0[0x8]; // 0x00(0x08)
	struct FGameplayTag VarName; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct EncountersRuntime.EncounterVariable_Boolean
// Size: 0x20 (Inherited: 0x10)
struct FEncounterVariable_Boolean : FEncounterVariable {
	struct FDataTableRowHandle RowValue; // 0x10(0x10)
};

// ScriptStruct EncountersRuntime.EncounterVariable_Float
// Size: 0x20 (Inherited: 0x10)
struct FEncounterVariable_Float : FEncounterVariable {
	struct FDataTableRowHandle RowValue; // 0x10(0x10)
};

// ScriptStruct EncountersRuntime.EncounterVariable_GameplayTag
// Size: 0x20 (Inherited: 0x10)
struct FEncounterVariable_GameplayTag : FEncounterVariable {
	struct FDataTableRowHandle RowValue; // 0x10(0x10)
};

// ScriptStruct EncountersRuntime.EncounterVariable_Integer
// Size: 0x20 (Inherited: 0x10)
struct FEncounterVariable_Integer : FEncounterVariable {
	struct FDataTableRowHandle RowValue; // 0x10(0x10)
};

// ScriptStruct EncountersRuntime.EncounterVariable_ItemDefinition
// Size: 0x20 (Inherited: 0x10)
struct FEncounterVariable_ItemDefinition : FEncounterVariable {
	struct FDataTableRowHandle RowValue; // 0x10(0x10)
};

// ScriptStruct EncountersRuntime.EncounterVariable_LWMEncounter
// Size: 0x20 (Inherited: 0x10)
struct FEncounterVariable_LWMEncounter : FEncounterVariable {
	struct FDataTableRowHandle RowValue; // 0x10(0x10)
};

// ScriptStruct EncountersRuntime.EncounterVariable_TagQuery
// Size: 0x20 (Inherited: 0x10)
struct FEncounterVariable_TagQuery : FEncounterVariable {
	struct FDataTableRowHandle RowValue; // 0x10(0x10)
};

// ScriptStruct EncountersRuntime.EncounterVarRow_Boolean
// Size: 0x10 (Inherited: 0x08)
struct FEncounterVarRow_Boolean : FTableRowBase {
	bool bValue; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EncountersRuntime.EncounterVarRow_Float
// Size: 0x10 (Inherited: 0x08)
struct FEncounterVarRow_Float : FTableRowBase {
	float Value; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct EncountersRuntime.EncounterVarRow_GameplayTag
// Size: 0x10 (Inherited: 0x08)
struct FEncounterVarRow_GameplayTag : FTableRowBase {
	struct FGameplayTag Value; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct EncountersRuntime.EncounterVarRow_Integer
// Size: 0x10 (Inherited: 0x08)
struct FEncounterVarRow_Integer : FTableRowBase {
	int32_t Value; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct EncountersRuntime.EncounterVarRow_ItemDefinition
// Size: 0x28 (Inherited: 0x08)
struct FEncounterVarRow_ItemDefinition : FTableRowBase {
	struct TSoftObjectPtr<UFortWorldItemDefinition> Value; // 0x08(0x20)
};

// ScriptStruct EncountersRuntime.EncounterVarRow_LWMEncounter
// Size: 0x28 (Inherited: 0x08)
struct FEncounterVarRow_LWMEncounter : FTableRowBase {
	struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter> Value; // 0x08(0x20)
};

// ScriptStruct EncountersRuntime.EncounterVarRow_TagQuery
// Size: 0x50 (Inherited: 0x08)
struct FEncounterVarRow_TagQuery : FTableRowBase {
	struct FGameplayTagQuery Value; // 0x08(0x48)
};

// ScriptStruct EncountersRuntime.EndAllMobEncountersStateTreeTaskInstanceData
// Size: 0x08 (Inherited: 0x00)
struct FEndAllMobEncountersStateTreeTaskInstanceData {
	struct AActor* UserActor; // 0x00(0x08)
};

// ScriptStruct EncountersRuntime.EndAllMobEncountersStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FEndAllMobEncountersStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.PauseMobEncounterStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FPauseMobEncounterStateTreeTaskInstanceData {
	struct FGameplayTag MobIdentifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct AActor* UserActor; // 0x08(0x08)
};

// ScriptStruct EncountersRuntime.PauseMobEncounterStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FPauseMobEncounterStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.ResumeMobEncounterStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FResumeMobEncounterStateTreeTaskInstanceData {
	struct FGameplayTag MobIdentifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct AActor* UserActor; // 0x08(0x08)
};

// ScriptStruct EncountersRuntime.ResumeMobEncounterStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FResumeMobEncounterStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.StartLWMEncounterStateTreeTaskInstanceData
// Size: 0x130 (Inherited: 0x00)
struct FStartLWMEncounterStateTreeTaskInstanceData {
	struct TSoftObjectPtr<UFortAthenaLivingWorldEncounter> LWMEncounter; // 0x00(0x20)
	struct FGameplayTagQuery PointProviderTagQuery; // 0x20(0x48)
	struct FGameplayTagQuery AnchorPointTagQuery; // 0x68(0x48)
	struct FScalableFloat LeashRadiusInner; // 0xb0(0x28)
	struct FScalableFloat LeashRadiusOuter; // 0xd8(0x28)
	struct AActor* UserActor; // 0x100(0x08)
	struct UStartLWMEncounterDelegateHandler* DelegateHandler; // 0x108(0x08)
	struct TWeakObjectPtr<struct UFortAthenaLivingWorldEncounterInstance> LWMInstance; // 0x110(0x08)
	struct TArray<struct TWeakObjectPtr<struct AFortPawn>> SpawnedMobPawns; // 0x118(0x10)
	struct TWeakObjectPtr<struct AEncounterMobAnchor> EncounterAnchorPoint; // 0x128(0x08)
};

// ScriptStruct EncountersRuntime.StartLWMEncounterStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FStartLWMEncounterStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.StartMobEncounterStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FStartMobEncounterStateTreeTaskInstanceData {
	struct FGameplayTag MobIdentifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct AActor* UserActor; // 0x08(0x08)
};

// ScriptStruct EncountersRuntime.StartMobEncounterStateTreeTask
// Size: 0x28 (Inherited: 0x20)
struct FStartMobEncounterStateTreeTask : FStateTreeTaskCommonBase {
	bool bStopEncounterOnExit; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct EncountersRuntime.StopMobEncounterStateTreeTaskInstanceData
// Size: 0x10 (Inherited: 0x00)
struct FStopMobEncounterStateTreeTaskInstanceData {
	struct FGameplayTag MobIdentifier; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct AActor* UserActor; // 0x08(0x08)
};

// ScriptStruct EncountersRuntime.StopMobEncounterStateTreeTask
// Size: 0x20 (Inherited: 0x20)
struct FStopMobEncounterStateTreeTask : FStateTreeTaskCommonBase {
};

// ScriptStruct EncountersRuntime.EncounterRewardBehavior
// Size: 0x38 (Inherited: 0x00)
struct FEncounterRewardBehavior {
	struct FVector RewardOffset; // 0x00(0x18)
	struct FVector RewardDirection; // 0x18(0x18)
	float RewardConeAngle; // 0x30(0x04)
	float RewardFlingMagnitude; // 0x34(0x04)
};

// ScriptStruct EncountersRuntime.EncounterObjectiveFilterCache
// Size: 0x70 (Inherited: 0x60)
struct FEncounterObjectiveFilterCache : FEventObjectiveFilterCache {
	char pad_60[0x10]; // 0x60(0x10)
};

// ScriptStruct EncountersRuntime.EncounterVerbTransitionStateTreeTaskInstanceData
// Size: 0x20 (Inherited: 0x00)
struct FEncounterVerbTransitionStateTreeTaskInstanceData {
	struct AActor* UserActor; // 0x00(0x08)
	char pad_8[0x18]; // 0x08(0x18)
};

// ScriptStruct EncountersRuntime.EncounterVerbTransitionStateTreeTask
// Size: 0x40 (Inherited: 0x20)
struct FEncounterVerbTransitionStateTreeTask : FStateTreeTaskCommonBase {
	struct FStateTreeStateLink TransitionTo; // 0x20(0x02)
	char pad_22[0x6]; // 0x22(0x06)
	struct TArray<struct FInstancedStruct> Verbs; // 0x28(0x10)
	int32_t ValueThreshold; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

