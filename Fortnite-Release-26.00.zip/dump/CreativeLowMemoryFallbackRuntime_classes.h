// Class CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackSettings
// Size: 0x138 (Inherited: 0x30)
struct UCreativeLowMemoryFallbackSettings : UDeveloperSettings {
	struct TSoftObjectPtr<UObject> WarningToastIcon; // 0x30(0x20)
	struct FCreativeLowMemoryFallbackUserFacingText DefaultText; // 0x50(0x48)
	struct TMap<struct TSoftObjectPtr<UFortPlaylist>, struct FCreativeLowMemoryFallbackFreeMemoryThresholds> PlaylistOverrideThresholds; // 0x98(0x50)
	struct TMap<struct TSoftObjectPtr<UFortPlaylist>, struct FCreativeLowMemoryFallbackUserFacingText> PlaylistOverrideText; // 0xe8(0x50)
};

// Class CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackWorldSubsystem
// Size: 0x68 (Inherited: 0x30)
struct UCreativeLowMemoryFallbackWorldSubsystem : UWorldSubsystem {
	struct FCreativeLowMemoryFallbackFreeMemoryThresholds CurrentThresholds; // 0x30(0x0c)
	char pad_3C[0x2c]; // 0x3c(0x2c)

	void OnPlaylistDataChanged(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function CreativeLowMemoryFallbackRuntime.CreativeLowMemoryFallbackWorldSubsystem.OnPlaylistDataChanged // (Final|Native|Private|HasOutParms) // @ game+0xaa3a8b0
};

