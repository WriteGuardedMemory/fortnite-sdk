// Class DamageNumbersUI.CommonUserWidget_DamageNumbers
// Size: 0x488 (Inherited: 0x2d0)
struct UCommonUserWidget_DamageNumbers : UCommonUserWidget {
	char pad_2D0[0x10]; // 0x2d0(0x10)
	struct FVector WorldSpacePos; // 0x2e0(0x18)
	struct FGameplayTag CheckAnimalTag; // 0x2f8(0x04)
	float Damage; // 0x2fc(0x04)
	float AdditionalVerticalScreenOffset; // 0x300(0x04)
	char pad_304[0x4]; // 0x304(0x04)
	double SpawnTime; // 0x308(0x08)
	struct FVector2D DamageNumberScaleVector; // 0x310(0x10)
	struct FVector2D ScreenSpaceOffsetFromHitActor; // 0x320(0x10)
	struct FVector2D InverseHUDScaleVector; // 0x330(0x10)
	struct AActor* HitActor; // 0x340(0x08)
	bool bHitAnimal; // 0x348(0x01)
	bool bHitVehicle; // 0x349(0x01)
	bool bIsPlayingCritAnimation; // 0x34a(0x01)
	char pad_34B[0x1]; // 0x34b(0x01)
	struct FLinearColor HitColor; // 0x34c(0x10)
	struct FLinearColor VehicleColor; // 0x35c(0x10)
	struct FLinearColor CritColor; // 0x36c(0x10)
	struct FLinearColor HealthColor; // 0x37c(0x10)
	struct FLinearColor ShieldColor; // 0x38c(0x10)
	struct FLinearColor CritColor_Text; // 0x39c(0x10)
	struct FLinearColor ShieldColor_Text; // 0x3ac(0x10)
	struct FLinearColor HealthColor_InnerStroke; // 0x3bc(0x10)
	struct FLinearColor ShieldColor_InnerStroke; // 0x3cc(0x10)
	struct FLinearColor CritColor_InnerStroke; // 0x3dc(0x10)
	struct FLinearColor DamageIconVehicleColor; // 0x3ec(0x10)
	struct FLinearColor DamageIconShieldColor; // 0x3fc(0x10)
	struct FLinearColor DamageIconShieldOutline1Color; // 0x40c(0x10)
	struct FLinearColor DamageIconShieldOutline2Color; // 0x41c(0x10)
	struct FLinearColor DamageIconVehicleOutline1Color; // 0x42c(0x10)
	struct FLinearColor DamageIconVehicleOutline2Color; // 0x43c(0x10)
	char pad_44C[0x4]; // 0x44c(0x04)
	struct UWidgetAnimation* OnDamage; // 0x450(0x08)
	struct UWidgetAnimation* OnDamage_Crit; // 0x458(0x08)
	struct UCommonTextBlock* Text_Number; // 0x460(0x08)
	struct UCommonTextBlock* Text_Number_Stroke; // 0x468(0x08)
	struct UImage* DamageTypeCrit; // 0x470(0x08)
	struct UImage* DamageTypeIcon; // 0x478(0x08)
	struct UImage* DamageTypeIcon_EMP; // 0x480(0x08)

	void UpdateScreenSpacePosition(); // Function DamageNumbersUI.CommonUserWidget_DamageNumbers.UpdateScreenSpacePosition // (Final|Native|Protected|BlueprintCallable) // @ game+0xab24830
	void Reset(); // Function DamageNumbersUI.CommonUserWidget_DamageNumbers.Reset // (Final|Native|Protected|BlueprintCallable) // @ game+0xab247e0
	void OnShieldBreak(bool bIsOvershield); // Function DamageNumbersUI.CommonUserWidget_DamageNumbers.OnShieldBreak // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnDamageDealt(double InDamage, struct AActor* InActor, bool bInShield, bool bInCrit, struct FVector InWorldSpacePos, bool bInEMP); // Function DamageNumbersUI.CommonUserWidget_DamageNumbers.OnDamageDealt // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xab24850
};

// Class DamageNumbersUI.FortUserWidget_DamageNumbers
// Size: 0x340 (Inherited: 0x2b8)
struct UFortUserWidget_DamageNumbers : UFortUserWidget {
	double VerticalShiftForNewDamage; // 0x2b8(0x08)
	double AccumulationTime; // 0x2c0(0x08)
	int32_t MaxNumberCount; // 0x2c8(0x04)
	char pad_2CC[0x4]; // 0x2cc(0x04)
	struct FVector OffsetFromPawnLocationDBNO; // 0x2d0(0x18)
	struct FVector OffsetFromPawnLocation; // 0x2e8(0x18)
	struct AFortPlayerPawn* BoundPawn; // 0x300(0x08)
	struct FGameplayTag HideDamageNumbersTag; // 0x308(0x04)
	struct FGameplayTag DamageAtLocTag; // 0x30c(0x04)
	struct FGameplayTagContainer TagsToNotDisplayDmgNumbersOnSpecificActors; // 0x310(0x20)
	struct UDynamicEntryBox* DynamicEntryBox_Numbers; // 0x330(0x08)
	struct FGameplayTag DamageCueEMPTag; // 0x338(0x04)
	bool bPrecreateDamageNumberEntries; // 0x33c(0x01)
	char pad_33D[0x3]; // 0x33d(0x03)

	void UpdateBinding(); // Function DamageNumbersUI.FortUserWidget_DamageNumbers.UpdateBinding // (Final|Native|Protected|BlueprintCallable) // @ game+0xab26b20
	void OnShieldBreak(bool bInOverShield); // Function DamageNumbersUI.FortUserWidget_DamageNumbers.OnShieldBreak // (Final|Native|Protected) // @ game+0xab258c0
	void OnPawnSet(); // Function DamageNumbersUI.FortUserWidget_DamageNumbers.OnPawnSet // (Final|Native|Protected|BlueprintCallable) // @ game+0xab26a70
	void OnDamageNumberFinishedAnimating(struct UCommonUserWidget_DamageNumbers* Widget); // Function DamageNumbersUI.FortUserWidget_DamageNumbers.OnDamageNumberFinishedAnimating // (Final|Native|Protected) // @ game+0xab253d0
	void OnDamageDealt(double InDamage, bool bInCritical, bool bInFatal, bool bInShield, struct AActor* HitActor, struct FVector HitLocation, struct FGameplayTagContainer Tags); // Function DamageNumbersUI.FortUserWidget_DamageNumbers.OnDamageDealt // (Final|Native|Protected|HasDefaults|BlueprintCallable) // @ game+0xab259b0
	void ClearBinding(); // Function DamageNumbersUI.FortUserWidget_DamageNumbers.ClearBinding // (Final|Native|Protected|BlueprintCallable) // @ game+0xab26b00
};

// Class DamageNumbersUI.FortGameSettingRegistryExtension_DamageNumbers
// Size: 0x28 (Inherited: 0x28)
struct UFortGameSettingRegistryExtension_DamageNumbers : UFortGameSettingRegistryExtension {
};

