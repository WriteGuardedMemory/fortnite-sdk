// Class EpicMediaCDNHostnames.EpicMediaCDNHostnames
// Size: 0x168 (Inherited: 0x28)
struct UEpicMediaCDNHostnames : UObject {
	struct TArray<float> CDNDistribution; // 0x28(0x10)
	char pad_38[0x130]; // 0x38(0x130)

	struct FString GetSelectedHostName(); // Function EpicMediaCDNHostnames.EpicMediaCDNHostnames.GetSelectedHostName // (Final|Native|Public|BlueprintCallable) // @ game+0x6152390
};

