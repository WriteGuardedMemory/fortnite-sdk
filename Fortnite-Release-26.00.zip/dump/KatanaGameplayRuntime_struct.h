// Enum KatanaGameplayRuntime.EFortKatanaPrimaryAttackVariation
enum class EFortKatanaPrimaryAttackVariation : uint8 {
	OnGroundFirst = 0,
	OnGroundSecond = 1,
	InAir = 2,
	EFortKatanaPrimaryAttackVariation_MAX = 3
};

// ScriptStruct KatanaGameplayRuntime.FortKatanaPrimaryAttackVariationInfo
// Size: 0x98 (Inherited: 0x00)
struct FFortKatanaPrimaryAttackVariationInfo {
	struct FScalableFloat Range; // 0x00(0x28)
	struct FScalableFloat OffsetFromTarget; // 0x28(0x28)
	struct FFortAbilityTargetSelectionList TargetSelectionList; // 0x50(0x48)
};

// ScriptStruct KatanaGameplayRuntime.FortKatanaDashTargetingInfo
// Size: 0x40 (Inherited: 0x00)
struct FFortKatanaDashTargetingInfo {
	struct FVector DashDirection; // 0x00(0x18)
	float DashDistance; // 0x18(0x04)
	struct TWeakObjectPtr<struct AActor> DashBlockingActor; // 0x1c(0x08)
	bool bWasDashDirectionAdjusted; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	struct TArray<struct AActor*> DamagedActors; // 0x28(0x10)
	float OutOfRangePercent; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct KatanaGameplayRuntime.RootMotionSource_KatanaDashForce
// Size: 0x120 (Inherited: 0x120)
struct FRootMotionSource_KatanaDashForce : FRootMotionSource_MoveToForce {
	float HeightAboveGround; // 0x118(0x04)
};

