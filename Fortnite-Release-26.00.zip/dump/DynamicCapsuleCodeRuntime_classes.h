// Class DynamicCapsuleCodeRuntime.DynamicCapsuleComponent
// Size: 0xf8 (Inherited: 0xa8)
struct UDynamicCapsuleComponent : UFortPawnComponent {
	struct TArray<struct FDynamicCapsuleEntry> DynamicCapsuleEntryStack; // 0xa8(0x10)
	struct FDynamicCapsuleState ReplicatedCapsuleState; // 0xb8(0x10)
	char pad_C8[0x30]; // 0xc8(0x30)

	void ServerRemoveDynamicCapsule(struct FGameplayTag tag); // Function DynamicCapsuleCodeRuntime.DynamicCapsuleComponent.ServerRemoveDynamicCapsule // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0xab8eee0
	void ServerApplyDynamicCapsule(struct FGameplayTag tag, float CapsuleRadius, float CapsuleHalfHeight, double NewRelativeMeshHeight); // Function DynamicCapsuleCodeRuntime.DynamicCapsuleComponent.ServerApplyDynamicCapsule // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0xab8f000
	bool RemoveDynamicCapsule(struct FGameplayTag& tag); // Function DynamicCapsuleCodeRuntime.DynamicCapsuleComponent.RemoveDynamicCapsule // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xab8f320
	void OnRep_ReplicatedCapsuleState(); // Function DynamicCapsuleCodeRuntime.DynamicCapsuleComponent.OnRep_ReplicatedCapsuleState // (Final|Native|Private) // @ game+0xab8eea0
	void OnRep_DynamicCapsuleEntryStack(); // Function DynamicCapsuleCodeRuntime.DynamicCapsuleComponent.OnRep_DynamicCapsuleEntryStack // (Final|Native|Private) // @ game+0xab8eec0
	bool ApplyDynamicCapsuleWithLocationAdjust(struct FGameplayTag& tag, float CapsuleRadius, float CapsuleHalfHeight, double NewRelativeMeshHeight); // Function DynamicCapsuleCodeRuntime.DynamicCapsuleComponent.ApplyDynamicCapsuleWithLocationAdjust // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xab8f420
	bool ApplyDynamicCapsule(struct FGameplayTag& tag, float CapsuleRadius, float CapsuleHalfHeight); // Function DynamicCapsuleCodeRuntime.DynamicCapsuleComponent.ApplyDynamicCapsule // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xab8f6f0
};

// Class DynamicCapsuleCodeRuntime.AnimNotifyState_SetCapsuleSize
// Size: 0x48 (Inherited: 0x30)
struct UAnimNotifyState_SetCapsuleSize : UAnimNotifyState {
	float TargetCapsuleRadius; // 0x30(0x04)
	float TargetCapsuleHalfHeight; // 0x34(0x04)
	bool bAdjustRelativeMeshHeight; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float TargetRelativeMeshHeight; // 0x3c(0x04)
	struct FGameplayTag CapsuleSizeTag; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class DynamicCapsuleCodeRuntime.JumpSlideComponent
// Size: 0xb0 (Inherited: 0xa8)
struct UJumpSlideComponent : UFortPawnComponent {
	char pad_A8[0x8]; // 0xa8(0x08)

	void OnMovementModeChange(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function DynamicCapsuleCodeRuntime.JumpSlideComponent.OnMovementModeChange // (Final|Native|Private) // @ game+0xab93db0
	void OnJumpSlideStart(); // Function DynamicCapsuleCodeRuntime.JumpSlideComponent.OnJumpSlideStart // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnJumpSlideEnd(); // Function DynamicCapsuleCodeRuntime.JumpSlideComponent.OnJumpSlideEnd // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

