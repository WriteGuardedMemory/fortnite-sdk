// Enum DynamicUI.EDynamicUIStrength
enum class EDynamicUIStrength : uint8 {
	Weak = 0,
	Medium = 1,
	Strong = 2,
	Required = 3,
	EDynamicUIStrength_MAX = 4
};

// Enum DynamicUI.EDynamicUIAnchor
enum class EDynamicUIAnchor : uint8 {
	TopLeft = 0,
	TopCenter = 1,
	TopRight = 2,
	CenterLeft = 3,
	CenterCenter = 4,
	CenterRight = 5,
	BottomLeft = 6,
	BottomCenter = 7,
	BottomRight = 8,
	MAX = 9
};

// Enum DynamicUI.EDynamicUIAspectRatioType
enum class EDynamicUIAspectRatioType : uint8 {
	 = 0,
	 = 1,
	 = 2,
	 = 3,
	 = 4,
	 = 5,
	Custom = 6,
	EDynamicUIAspectRatioType_MAX = 7
};

// Enum DynamicUI.EDynamicUISizeMatch
enum class EDynamicUISizeMatch : uint8 {
	Both = 0,
	Width = 1,
	Height = 2,
	EDynamicUISizeMatch_MAX = 3
};

// Enum DynamicUI.EDynamicUIZOrder
enum class EDynamicUIZOrder : int32 {
	Back = 1000,
	Middle = 2000,
	Front = 3000,
	Custom = 2500,
	CustomMin = 0,
	CustomMax = 5000,
	Loading = 30000,
	Top = 50000,
	EDynamicUIZOrder_MAX = 50001
};

// Enum DynamicUI.EDynamicUIUnallowedBehavior
enum class EDynamicUIUnallowedBehavior : uint8 {
	Hide = 0,
	Collapse = 1,
	Destroy = 2,
	EDynamicUIUnallowedBehavior_MAX = 3
};

// Enum DynamicUI.EDynamicUIDebugDisplayMode
enum class EDynamicUIDebugDisplayMode : uint8 {
	Hide = 0,
	ShowSelected = 1,
	ShowAll = 2,
	EDynamicUIDebugDisplayMode_MAX = 3
};

// Enum DynamicUI.EDynamicUIUnallowLayerComparison
enum class EDynamicUIUnallowLayerComparison : uint8 {
	Equal = 0,
	NotEqual = 1,
	Less = 2,
	LessOrEqual = 3,
	Greater = 4,
	GreaterOrEqual = 5,
	EDynamicUIUnallowLayerComparison_MAX = 6
};

// ScriptStruct DynamicUI.DynamicUIUnallowed
// Size: 0x30 (Inherited: 0x00)
struct FDynamicUIUnallowed {
	struct TSoftClassPtr<UObject> Widget; // 0x00(0x20)
	struct FName UniqueID; // 0x20(0x04)
	enum class EDynamicUIUnallowedBehavior Behavior; // 0x24(0x04)
	char bTargetAll : 1; // 0x28(0x01)
	char bUseUniqueID : 1; // 0x28(0x01)
	char pad_28_2 : 6; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct DynamicUI.DynamicUIManagerDebug
// Size: 0x01 (Inherited: 0x00)
struct FDynamicUIManagerDebug {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DynamicUI.DynamicUIPanelDebug
// Size: 0x01 (Inherited: 0x00)
struct FDynamicUIPanelDebug {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DynamicUI.DynamicUIAllowed
// Size: 0x68 (Inherited: 0x00)
struct FDynamicUIAllowed {
	struct TSoftClassPtr<UObject> Widget; // 0x00(0x20)
	enum class EDynamicUIZOrder ZOrder; // 0x20(0x04)
	int32_t CustomZOrder; // 0x24(0x04)
	struct FName UniqueID; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TSoftObjectPtr<UCommonInputActionDomain> ActionDomain; // 0x30(0x20)
	struct UDynamicUIConstraintBase* LayoutConstraint; // 0x50(0x08)
	struct UDynamicUISizeBase* SizeModifier; // 0x58(0x08)
	char LayerIDOverride; // 0x60(0x01)
	char bIsUnique : 1; // 0x61(0x01)
	char bUseActionDomain : 1; // 0x61(0x01)
	char bUseLayerOverride : 1; // 0x61(0x01)
	char pad_61_3 : 5; // 0x61(0x01)
	char pad_62[0x6]; // 0x62(0x06)
};

// ScriptStruct DynamicUI.DynamicUIAspectRatio
// Size: 0x08 (Inherited: 0x00)
struct FDynamicUIAspectRatio {
	enum class EDynamicUIAspectRatioType AspectRatio; // 0x00(0x04)
	float CustomAspectRatio; // 0x04(0x04)
};

// ScriptStruct DynamicUI.DynamicUIPreload
// Size: 0x20 (Inherited: 0x00)
struct FDynamicUIPreload {
	struct TSoftClassPtr<UObject> Widget; // 0x00(0x20)
};

// ScriptStruct DynamicUI.DynamicUISceneData
// Size: 0x01 (Inherited: 0x00)
struct FDynamicUISceneData {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DynamicUI.DynamicUIDirectorData
// Size: 0x30 (Inherited: 0x00)
struct FDynamicUIDirectorData {
	struct TSoftClassPtr<UObject> DirectorClass; // 0x00(0x20)
	struct TWeakObjectPtr<struct AActor> Instance; // 0x20(0x08)
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct DynamicUI.DynamicUIPlayerData
// Size: 0x90 (Inherited: 0x00)
struct FDynamicUIPlayerData {
	char pad_0[0x40]; // 0x00(0x40)
	struct TMap<struct FString, struct FDynamicUIDirectorData> ActiveDirectors; // 0x40(0x50)
};

// ScriptStruct DynamicUI.DynamicUIWidgetTarget
// Size: 0x60 (Inherited: 0x00)
struct FDynamicUIWidgetTarget {
	struct FName WidgetPath; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftClassPtr<UObject> WidgetClass; // 0x08(0x20)
	struct FName UniqueID; // 0x28(0x04)
	char bUseUniqueID : 1; // 0x2c(0x01)
	char pad_2C_1 : 7; // 0x2c(0x01)
	char pad_2D[0x33]; // 0x2d(0x33)
};

