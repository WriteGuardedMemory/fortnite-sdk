// Class DirtbikeRuntime.FortDirtbikeVehicle
// Size: 0x1fe0 (Inherited: 0x1fd0)
struct AFortDirtbikeVehicle : AFortMotorcycleVehicle {
	char pad_1FD0[0x10]; // 0x1fd0(0x10)
};

// Class DirtbikeRuntime.FortDirtbikeVehicleConfigs
// Size: 0xb80 (Inherited: 0xb80)
struct UFortDirtbikeVehicleConfigs : UFortMotorcycleVehicleConfigs {
};

