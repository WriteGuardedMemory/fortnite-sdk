// Class MidMatchObjectivesGameplayRuntime.FortGameStateComponent_MidMatchObjectiveParent
// Size: 0xa8 (Inherited: 0xa0)
struct UFortGameStateComponent_MidMatchObjectiveParent : UFortGameStateComponent {
	struct FName ObjectiveCompletedStatName; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)

	void SetObjectiveCompletedStat(char SquadId); // Function MidMatchObjectivesGameplayRuntime.FortGameStateComponent_MidMatchObjectiveParent.SetObjectiveCompletedStat // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x8da73d0
};

