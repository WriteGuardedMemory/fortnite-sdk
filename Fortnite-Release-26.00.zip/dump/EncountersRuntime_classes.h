// Class EncountersRuntime.EncounterMobAnchor
// Size: 0x2b0 (Inherited: 0x290)
struct AEncounterMobAnchor : AActor {
	struct FGameplayTagContainer FilterTags; // 0x290(0x20)
};

// Class EncountersRuntime.EncounterMobManagerComponent
// Size: 0x218 (Inherited: 0xa0)
struct UEncounterMobManagerComponent : UGameFrameworkComponent {
	struct TArray<struct FEncounterMobInstance> SpawnedMobs; // 0xa0(0x10)
	struct TArray<struct FEncounterMobSpawnData> MobEncounterSpawnData; // 0xb0(0x10)
	struct FEncounterMobSpawnInfo DefaultMobSpawnInfo; // 0xc0(0xa0)
	struct FScalableFloat LWMDensityWeight; // 0x160(0x28)
	struct FScalableFloat LWMDensityRange; // 0x188(0x28)
	struct FMulticastInlineDelegate OnEncounterStarted; // 0x1b0(0x10)
	struct FMulticastInlineDelegate OnEncounterPaused; // 0x1c0(0x10)
	struct FMulticastInlineDelegate OnEncounterResumed; // 0x1d0(0x10)
	struct FMulticastInlineDelegate OnEncounterActorSpawned; // 0x1e0(0x10)
	struct FMulticastInlineDelegate OnEncounterActorDead; // 0x1f0(0x10)
	struct FMulticastInlineDelegate OnEncounterEnded; // 0x200(0x10)
	struct TWeakObjectPtr<struct ALivingWorldEncounterPrefab> EncounterPrefab; // 0x210(0x08)

	bool StartMobEncounter(struct FGameplayTag& MobIdentifier); // Function EncountersRuntime.EncounterMobManagerComponent.StartMobEncounter // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xab98680
	void ResumeMobEncounter(struct FGameplayTag& MobIdentifier); // Function EncountersRuntime.EncounterMobManagerComponent.ResumeMobEncounter // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xab984a0
	void PauseMobEncounter(struct FGameplayTag& MobIdentifier); // Function EncountersRuntime.EncounterMobManagerComponent.PauseMobEncounter // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xab98590
	void OnMobPawnEndPlay(struct AActor* Mob, enum class EEndPlayReason EndPlayReason); // Function EncountersRuntime.EncounterMobManagerComponent.OnMobPawnEndPlay // (Final|Native|Private) // @ game+0xab98150
	void OnMobActorSpawn(struct AActor* SpawnedActor); // Function EncountersRuntime.EncounterMobManagerComponent.OnMobActorSpawn // (Final|Native|Private) // @ game+0xab97db0
	void OnMobActorDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector Momentum); // Function EncountersRuntime.EncounterMobManagerComponent.OnMobActorDied // (Final|Native|Private|HasDefaults) // @ game+0xab97890
	void OnEncounterStarted__DelegateSignature(struct FGameplayTag MobIdentifier); // DelegateFunction EncountersRuntime.EncounterMobManagerComponent.OnEncounterStarted__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnEncounterResumed__DelegateSignature(struct FGameplayTag MobIdentifier); // DelegateFunction EncountersRuntime.EncounterMobManagerComponent.OnEncounterResumed__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnEncounterPaused__DelegateSignature(struct FGameplayTag MobIdentifier); // DelegateFunction EncountersRuntime.EncounterMobManagerComponent.OnEncounterPaused__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnEncounterEnded__DelegateSignature(struct FGameplayTag MobIdentifier); // DelegateFunction EncountersRuntime.EncounterMobManagerComponent.OnEncounterEnded__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnEncounterActorSpawned__DelegateSignature(struct FGameplayTag MobIdentifier, struct AActor* SpawnedActor); // DelegateFunction EncountersRuntime.EncounterMobManagerComponent.OnEncounterActorSpawned__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void OnEncounterActorDead__DelegateSignature(struct FGameplayTag MobIdentifier, struct AActor* DamagedActor, struct AActor* DamageCauser); // DelegateFunction EncountersRuntime.EncounterMobManagerComponent.OnEncounterActorDead__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x1b027f0
	void EndMobEncounter(struct FGameplayTag& MobIdentifier); // Function EncountersRuntime.EncounterMobManagerComponent.EndMobEncounter // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xab983b0
	void EndAndCleanupAllMobEncounters(); // Function EncountersRuntime.EncounterMobManagerComponent.EndAndCleanupAllMobEncounters // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0xab98360
};

// Class EncountersRuntime.StartLWMEncounterDelegateHandler
// Size: 0x30 (Inherited: 0x28)
struct UStartLWMEncounterDelegateHandler : UObject {
	char pad_28[0x8]; // 0x28(0x08)

	void OnMobPawnEndPlay(struct AActor* Mob, enum class EEndPlayReason EndPlayReason); // Function EncountersRuntime.StartLWMEncounterDelegateHandler.OnMobPawnEndPlay // (Final|Native|Public) // @ game+0xab9b7d0
	void OnMobActorSpawn(struct AActor* SpawnedActor); // Function EncountersRuntime.StartLWMEncounterDelegateHandler.OnMobActorSpawn // (Final|Native|Public) // @ game+0xab9b4c0
	void OnMobActorDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector Momentum); // Function EncountersRuntime.StartLWMEncounterDelegateHandler.OnMobActorDied // (Final|Native|Public|HasDefaults) // @ game+0xab9afb0
};

// Class EncountersRuntime.EncounterActorSpawnerData
// Size: 0x88 (Inherited: 0x50)
struct UEncounterActorSpawnerData : UFortAthenaActorSpawnerData {
	struct FEncounterPrefabEntry EncounterEntry; // 0x50(0x38)
};

// Class EncountersRuntime.EncounterBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UEncounterBlueprintLibrary : UBlueprintFunctionLibrary {

	struct UEncounterMobManagerComponent* GetRelevantMobManagerComponentForActor(struct AActor* Actor); // Function EncountersRuntime.EncounterBlueprintLibrary.GetRelevantMobManagerComponentForActor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xab9c520
};

// Class EncountersRuntime.EncounterGameplayVolume
// Size: 0x3a8 (Inherited: 0x330)
struct AEncounterGameplayVolume : AGameplayVolume {
	char pad_330[0x18]; // 0x330(0x18)
	bool bShouldPersist; // 0x348(0x01)
	char pad_349[0x1f]; // 0x349(0x1f)
	struct FGuid SavedActorGuid; // 0x368(0x10)
	struct UEncounterStateTreeComponent* EncounterStateTreeComponent; // 0x378(0x08)
	char pad_380[0x28]; // 0x380(0x28)

	void OnCleanup(); // Function EncountersRuntime.EncounterGameplayVolume.OnCleanup // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool IsDoneCleaningUp(); // Function EncountersRuntime.EncounterGameplayVolume.IsDoneCleaningUp // (Native|Event|Public|BlueprintEvent|Const) // @ game+0xa791650
};

// Class EncountersRuntime.EncounterItem
// Size: 0xa8 (Inherited: 0x88)
struct UEncounterItem : UFortItem {
	struct UEncounterItemDefinition* EncounterItemDefinition; // 0x88(0x08)
	struct TWeakObjectPtr<struct ALivingWorldEncounterPrefab> EncounterPrefab; // 0x90(0x08)
	struct TWeakObjectPtr<struct UEncounterManagerComponent> EncounterManager; // 0x98(0x08)
	char pad_A0[0x8]; // 0xa0(0x08)
};

// Class EncountersRuntime.EncounterItemDefinition
// Size: 0x4b0 (Inherited: 0x378)
struct UEncounterItemDefinition : UFortItemDefinition {
	bool bAutoHandleSuccessFailure; // 0x378(0x01)
	char pad_379[0x7]; // 0x379(0x07)
	struct TSoftObjectPtr<UWorld> Level; // 0x380(0x20)
	struct UStateTree* StateTreeOverride; // 0x3a0(0x08)
	struct FGameplayCueTag ProximityGameplayCueTag; // 0x3a8(0x04)
	struct FGameplayCueTag ActorCleanupGameplayCueTag; // 0x3ac(0x04)
	struct TArray<struct FName> SuccessRewards; // 0x3b0(0x10)
	struct FEncounterRewardBehavior SuccessRewardBehavior; // 0x3c0(0x38)
	struct FGameplayCueTag ActorSuccessGameplayCueTag; // 0x3f8(0x04)
	struct FGameplayCueTag PlayerSuccessGameplayCueTag; // 0x3fc(0x04)
	struct TArray<struct FName> FailureRewards; // 0x400(0x10)
	struct FEncounterRewardBehavior FailureRewardBehavior; // 0x410(0x38)
	struct FGameplayCueTag ActorFailureGameplayCueTag; // 0x448(0x04)
	struct FGameplayCueTag PlayerFailureGameplayCueTag; // 0x44c(0x04)
	struct FScalableFloat LWMDensityWeight; // 0x450(0x28)
	struct FScalableFloat LWMDensityRange; // 0x478(0x28)
	struct TArray<struct FInstancedStruct> Vars; // 0x4a0(0x10)
};

// Class EncountersRuntime.EncounterManagerComponent
// Size: 0x108 (Inherited: 0xa0)
struct UEncounterManagerComponent : UGameFrameworkComponent {
	struct TWeakObjectPtr<struct AEncounterGameplayVolume> EncounterVolume; // 0xa0(0x08)
	struct TWeakObjectPtr<struct AActor> CenterActorOverride; // 0xa8(0x08)
	struct TSet<struct APlayerController*> ExplicitContributors; // 0xb0(0x50)
	struct TWeakObjectPtr<struct UEncounterItem> EncounterItem; // 0x100(0x08)

	void RemoveExplicitContributor(struct APlayerController* Contributor); // Function EncountersRuntime.EncounterManagerComponent.RemoveExplicitContributor // (Final|Native|Public|BlueprintCallable) // @ game+0xab9f4e0
	void OnStateTreeStatusChanged(enum class EStateTreeRunStatus Status); // Function EncountersRuntime.EncounterManagerComponent.OnStateTreeStatusChanged // (Final|Native|Private) // @ game+0xab9f0b0
	void HandleEncounterSuccess(int32_t RewardIndex); // Function EncountersRuntime.EncounterManagerComponent.HandleEncounterSuccess // (Final|Native|Public|BlueprintCallable) // @ game+0xab9f340
	void HandleEncounterFailure(int32_t RewardIndex); // Function EncountersRuntime.EncounterManagerComponent.HandleEncounterFailure // (Final|Native|Public|BlueprintCallable) // @ game+0xab9f1a0
	struct FGameplayTagQuery GetVariable_TagQuery(struct FGameplayTag& VarName); // Function EncountersRuntime.EncounterManagerComponent.GetVariable_TagQuery // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xab9f7b0
	struct UFortAthenaLivingWorldEncounter* GetVariable_LWMEncounter(struct FGameplayTag& VarName); // Function EncountersRuntime.EncounterManagerComponent.GetVariable_LWMEncounter // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xab9f900
	struct UFortWorldItemDefinition* GetVariable_ItemDefinition(struct FGameplayTag& VarName); // Function EncountersRuntime.EncounterManagerComponent.GetVariable_ItemDefinition // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xab9fa00
	int32_t GetVariable_Int(struct FGameplayTag& VarName); // Function EncountersRuntime.EncounterManagerComponent.GetVariable_Int // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xab9fc00
	struct FGameplayTag GetVariable_GameplayTag(struct FGameplayTag& VarName); // Function EncountersRuntime.EncounterManagerComponent.GetVariable_GameplayTag // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xab9f6c0
	float GetVariable_Float(struct FGameplayTag& VarName); // Function EncountersRuntime.EncounterManagerComponent.GetVariable_Float // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xab9fb00
	bool GetVariable_Bool(struct FGameplayTag& VarName); // Function EncountersRuntime.EncounterManagerComponent.GetVariable_Bool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xab9fd00
	void AddExplicitContributor(struct APlayerController* Contributor); // Function EncountersRuntime.EncounterManagerComponent.AddExplicitContributor // (Final|Native|Public|BlueprintCallable) // @ game+0xab9f5d0
};

// Class EncountersRuntime.EncounterStateTreeComponent
// Size: 0x148 (Inherited: 0x148)
struct UEncounterStateTreeComponent : UStateTreeComponent {
};

// Class EncountersRuntime.LivingWorldEncounterPrefab
// Size: 0x978 (Inherited: 0x918)
struct ALivingWorldEncounterPrefab : AFortAthenaLivingWorldPrefab {
	char pad_918[0x40]; // 0x918(0x40)
	struct TArray<struct FEncounterPrefabEntry> EncounterEntries; // 0x958(0x10)
	struct UEncounterItem* EncounterItem; // 0x968(0x08)
	struct TWeakObjectPtr<struct UEncounterItemDefinition> EncounterDefinition; // 0x970(0x08)

	void OnRep_EncounterDefinition(); // Function EncountersRuntime.LivingWorldEncounterPrefab.OnRep_EncounterDefinition // (Final|Native|Private) // @ game+0xaba53c0
};

