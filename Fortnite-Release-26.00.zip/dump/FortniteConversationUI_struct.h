// Enum FortniteConversationUI.ECannotBuyReason
enum class ECannotBuyReason : uint8 {
	CannotAfford = 0,
	OutOfStock = 1,
	ECannotBuyReason_MAX = 2
};

