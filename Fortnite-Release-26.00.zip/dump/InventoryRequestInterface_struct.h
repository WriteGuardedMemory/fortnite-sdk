// Enum InventoryRequestInterface.EInventoryPersistenceMode
enum class EInventoryPersistenceMode : uint8 {
	Normal = 0,
	Deferred = 1,
	Disabled = 2,
	ReadOnly = 3,
	EInventoryPersistenceMode_MAX = 4
};

