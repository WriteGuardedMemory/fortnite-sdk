// Enum LaserGameplayRuntime.ELaserConnectionState
enum class ELaserConnectionState : uint8 {
	Off = 0,
	TransitionOn = 1,
	On = 2,
	TransitionOff = 3,
	ELaserConnectionState_MAX = 4
};

// ScriptStruct LaserGameplayRuntime.LaserGridConnectionEntry
// Size: 0x18 (Inherited: 0x0c)
struct FLaserGridConnectionEntry : FFastArraySerializerItem {
	struct FLaserOutletConnection OutletConnection; // 0x0c(0x02)
	enum class ELaserConnectionState State; // 0x0e(0x01)
	char pad_F[0x1]; // 0x0f(0x01)
	struct ULaserCapsuleComponent* LaserCapsuleComponent; // 0x10(0x08)
};

// ScriptStruct LaserGameplayRuntime.LaserOutletConnection
// Size: 0x02 (Inherited: 0x00)
struct FLaserOutletConnection {
	char PrimaryOutletIndex; // 0x00(0x01)
	char SecondaryOutletIndex; // 0x01(0x01)
};

// ScriptStruct LaserGameplayRuntime.LaserGridConnectionArray
// Size: 0x118 (Inherited: 0x108)
struct FLaserGridConnectionArray : FFastArraySerializer {
	struct TArray<struct FLaserGridConnectionEntry> Entries; // 0x108(0x10)
};

// ScriptStruct LaserGameplayRuntime.LaserGridOutletEntry
// Size: 0x10 (Inherited: 0x0c)
struct FLaserGridOutletEntry : FFastArraySerializerItem {
	char InstanceIndex; // 0x0c(0x01)
	enum class ELaserConnectionState State; // 0x0d(0x01)
	char pad_E[0x2]; // 0x0e(0x02)
};

// ScriptStruct LaserGameplayRuntime.LaserGridOutletArray
// Size: 0x120 (Inherited: 0x108)
struct FLaserGridOutletArray : FFastArraySerializer {
	struct TArray<struct FLaserGridOutletEntry> Entries; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// ScriptStruct LaserGameplayRuntime.LaserGridPattern
// Size: 0x18 (Inherited: 0x00)
struct FLaserGridPattern {
	struct TArray<struct FLaserOutletConnection> OutletConnections; // 0x00(0x10)
	float Duration; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

