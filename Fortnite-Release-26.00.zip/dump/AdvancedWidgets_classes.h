// Class AdvancedWidgets.RadialSlider
// Size: 0x7a0 (Inherited: 0x178)
struct URadialSlider : UWidget {
	float Value; // 0x178(0x04)
	struct FDelegate ValueDelegate; // 0x17c(0x0c)
	bool bUseCustomDefaultValue; // 0x188(0x01)
	char pad_189[0x3]; // 0x189(0x03)
	float CustomDefaultValue; // 0x18c(0x04)
	struct FRuntimeFloatCurve SliderRange; // 0x190(0x88)
	struct TArray<float> ValueTags; // 0x218(0x10)
	float SliderHandleStartAngle; // 0x228(0x04)
	float SliderHandleEndAngle; // 0x22c(0x04)
	float AngularOffset; // 0x230(0x04)
	char pad_234[0x4]; // 0x234(0x04)
	struct FVector2D HandStartEndRatio; // 0x238(0x10)
	char pad_248[0x8]; // 0x248(0x08)
	struct FSliderStyle WidgetStyle; // 0x250(0x4a0)
	struct FLinearColor SliderBarColor; // 0x6f0(0x10)
	struct FLinearColor SliderProgressColor; // 0x700(0x10)
	struct FLinearColor SliderHandleColor; // 0x710(0x10)
	struct FLinearColor CenterBackgroundColor; // 0x720(0x10)
	bool Locked; // 0x730(0x01)
	bool MouseUsesStep; // 0x731(0x01)
	bool RequiresControllerLock; // 0x732(0x01)
	char pad_733[0x1]; // 0x733(0x01)
	float StepSize; // 0x734(0x04)
	bool IsFocusable; // 0x738(0x01)
	bool UseVerticalDrag; // 0x739(0x01)
	bool ShowSliderHandle; // 0x73a(0x01)
	bool ShowSliderHand; // 0x73b(0x01)
	char pad_73C[0x4]; // 0x73c(0x04)
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // 0x740(0x10)
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // 0x750(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // 0x760(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // 0x770(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x780(0x10)
	char pad_790[0x10]; // 0x790(0x10)

	void SetValueTags(struct TArray<float>& InValueTags); // Function AdvancedWidgets.RadialSlider.SetValueTags // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa97ee00
	void SetValue(float InValue); // Function AdvancedWidgets.RadialSlider.SetValue // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97f380
	void SetUseVerticalDrag(bool InUseVerticalDrag); // Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97e100
	void SetStepSize(float InValue); // Function AdvancedWidgets.RadialSlider.SetStepSize // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97e640
	void SetSliderRange(struct FRuntimeFloatCurve& InSliderRange); // Function AdvancedWidgets.RadialSlider.SetSliderRange // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa97ef40
	void SetSliderProgressColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderProgressColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa97e420
	void SetSliderHandleStartAngle(float InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97ece0
	void SetSliderHandleEndAngle(float InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97ebc0
	void SetSliderHandleColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa97e310
	void SetSliderBarColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderBarColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa97e530
	void SetShowSliderHandle(bool InShowSliderHandle); // Function AdvancedWidgets.RadialSlider.SetShowSliderHandle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97e000
	void SetShowSliderHand(bool InShowSliderHand); // Function AdvancedWidgets.RadialSlider.SetShowSliderHand // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97df00
	void SetLocked(bool InValue); // Function AdvancedWidgets.RadialSlider.SetLocked // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97e770
	void SetHandStartEndRatio(struct FVector2D InValue); // Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa97e970
	void SetCustomDefaultValue(float InValue); // Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97f200
	void SetCenterBackgroundColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa97e200
	void SetAngularOffset(float InValue); // Function AdvancedWidgets.RadialSlider.SetAngularOffset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xa97eac0
	float GetValue(); // Function AdvancedWidgets.RadialSlider.GetValue // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa97f600
	float GetNormalizedSliderHandlePosition(); // Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa97f500
	float GetCustomDefaultValue(); // Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa97f550
};

