// Class AnnualRefundTokenUI.FortPurchaseHistoryEntryBase
// Size: 0x1550 (Inherited: 0x1510)
struct UFortPurchaseHistoryEntryBase : UFortHoldableButton {
	struct UFortCosmeticItemCard* ItemCardClass; // 0x1510(0x08)
	float CardWidthOverride; // 0x1518(0x04)
	char pad_151C[0x4]; // 0x151c(0x04)
	struct UCommonTextBlock* Text_Name; // 0x1520(0x08)
	struct TArray<struct FString> LootEntryItemTypesToExclude; // 0x1528(0x10)
	struct TArray<struct FString> LootEntryItemTypesToCombine; // 0x1538(0x10)
	char pad_1548[0x8]; // 0x1548(0x08)

	void UpdateItemList(struct TArray<struct UFortCosmeticItemCard*>& ItemCards); // Function AnnualRefundTokenUI.FortPurchaseHistoryEntryBase.UpdateItemList // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class AnnualRefundTokenUI.FortPurchaseHistoryEntry
// Size: 0x1550 (Inherited: 0x1550)
struct UFortPurchaseHistoryEntry : UFortPurchaseHistoryEntryBase {

	void SetupItemCard(struct UFortCosmeticItemCard* ItemCard, struct UFortItem* Item); // Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetupItemCard // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetPurchaseText(struct FText& PurchaseDateText, struct FText& RefundDateText, bool bHasBeenRefunded, enum class EFortPurchaseHistoryRefundType RefundType); // Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.SetPurchaseText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnSetHistory(bool bHasBeenRefunded, bool bIsTokenlessRefund, bool bPlayerHasTokens, bool bNonRefundable, bool IsPartOfABundle, bool IsNextRefundable, int32_t IndexInBundle, int32_t NumPurchasesInBundle); // Function AnnualRefundTokenUI.FortPurchaseHistoryEntry.OnSetHistory // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class AnnualRefundTokenUI.FortPurchaseHistoryBundleEntry
// Size: 0x1550 (Inherited: 0x1550)
struct UFortPurchaseHistoryBundleEntry : UFortPurchaseHistoryEntryBase {

	void SetExpandButtonText(int32_t NumPurchases); // Function AnnualRefundTokenUI.FortPurchaseHistoryBundleEntry.SetExpandButtonText // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class AnnualRefundTokenUI.FortPurchaseHistoryListView
// Size: 0x3b0 (Inherited: 0x290)
struct UFortPurchaseHistoryListView : UListViewBase {
	char pad_290[0x120]; // 0x290(0x120)
};

// Class AnnualRefundTokenUI.FortPurchaseHistoryTreeView
// Size: 0x3e8 (Inherited: 0x3b0)
struct UFortPurchaseHistoryTreeView : UFortPurchaseHistoryListView {
	char pad_3B0[0x10]; // 0x3b0(0x10)
	struct UFortPurchaseHistoryBundleEntry* HeaderEntryWidgetClass; // 0x3c0(0x08)
	char pad_3C8[0x20]; // 0x3c8(0x20)
};

// Class AnnualRefundTokenUI.FortAnnualRefundTicket
// Size: 0x2b0 (Inherited: 0x2a8)
struct UFortAnnualRefundTicket : UUserWidget {
	struct UCommonTextBlock* Text_AvailableDate; // 0x2a8(0x08)

	void OnUpdatePendingState(bool bIsPending); // Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdatePendingState // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnUpdateAvailableState(bool bIsAvailable); // Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnUpdateAvailableState // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayLockingAnimation(); // Function AnnualRefundTokenUI.FortAnnualRefundTicket.OnPlayLockingAnimation // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class AnnualRefundTokenUI.FortAnnualRefundTokenData
// Size: 0x4b8 (Inherited: 0x498)
struct UFortAnnualRefundTokenData : UFortGameFeatureData {
	struct TSoftClassPtr<UObject> PurchaseHistoryScreenClass; // 0x498(0x20)
};

// Class AnnualRefundTokenUI.FortPurchaseHistoryScreen
// Size: 0x650 (Inherited: 0x558)
struct UFortPurchaseHistoryScreen : UFortActivatablePanel {
	struct FDataTableRowHandle BackAction; // 0x558(0x10)
	char pad_568[0x18]; // 0x568(0x18)
	struct TSoftClassPtr<UObject> RefundConfirmationClass; // 0x580(0x20)
	struct TSoftClassPtr<UObject> DirectPurchaseInfoModalClass; // 0x5a0(0x20)
	struct UCommonAnimatedSwitcher* Switcher_MainContent; // 0x5c0(0x08)
	struct UFortPurchaseHistoryTreeView* TreeView_Purchases; // 0x5c8(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x5d0(0x08)
	struct UCommonButtonBase* Button_PostApproval; // 0x5d8(0x08)
	struct UCommonTextBlock* Text_Desc; // 0x5e0(0x08)
	struct UCommonTextBlock* Text_RefundCount; // 0x5e8(0x08)
	struct UCommonTextBlock* Text_ResultHeader; // 0x5f0(0x08)
	struct UCommonTextBlock* Text_ResultTitle; // 0x5f8(0x08)
	struct UCommonTextBlock* Text_ResultDesc; // 0x600(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Left; // 0x608(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Center; // 0x610(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Right; // 0x618(0x08)
	struct UWidget* Widget_CancelPurchaseInfo; // 0x620(0x08)
	struct UWidget* Widget_ReturnTicketInfo; // 0x628(0x08)
	struct UWidget* Widget_TokenlessRefundInfo; // 0x630(0x08)
	struct UWidget* Widget_NonRefundableInfo; // 0x638(0x08)
	struct UWidget* Widget_BundledPurchaseInfo; // 0x640(0x08)
	struct UWidget* Widget_BundledPurchaseTokenlessRefundInfo; // 0x648(0x08)

	void OnPopulateView(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnPopulateView // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnNoPurchasesAvailable(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnNoPurchasesAvailable // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEndRefundSubmission(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnEndRefundSubmission // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnBeginRefundSubmission(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.OnBeginRefundSubmission // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool BP_IsShowingPurchases(); // Function AnnualRefundTokenUI.FortPurchaseHistoryScreen.BP_IsShowingPurchases // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class AnnualRefundTokenUI.FortRefundConfirmation
// Size: 0x5b0 (Inherited: 0x558)
struct UFortRefundConfirmation : UFortActivatablePanel {
	char pad_558[0x10]; // 0x558(0x10)
	struct UCommonTextBlock* Text_RefundsRemaining; // 0x568(0x08)
	struct UCommonTextBlock* Text_RefundCount; // 0x570(0x08)
	struct UCommonTextBlock* Text_AreYouSure; // 0x578(0x08)
	struct UCommonButtonBase* Button_Yes; // 0x580(0x08)
	struct UCommonButtonBase* Button_No; // 0x588(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x590(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Left; // 0x598(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Center; // 0x5a0(0x08)
	struct UFortAnnualRefundTicket* RefundTicket_Right; // 0x5a8(0x08)

	void BP_UpdateRefundType(enum class EFortPurchaseHistoryRefundType RefundType, bool bBundledRefund); // Function AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateRefundType // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_UpdateItemsList(struct TArray<struct UFortItemDefinition*>& SelectedItemDefs, int32_t TotalMtxPaid); // Function AnnualRefundTokenUI.FortRefundConfirmation.BP_UpdateItemsList // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

