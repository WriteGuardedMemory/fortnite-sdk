// Class DaySequence.DaySequenceModifierComponent
// Size: 0x6f0 (Inherited: 0x5b0)
struct UDaySequenceModifierComponent : UBoxComponent {
	struct ADaySequenceActor* TargetActor; // 0x5b0(0x08)
	struct FComponentReference VolumeShapeComponent; // 0x5b8(0x28)
	struct TWeakObjectPtr<struct AActor> ExternalVolumeBlendTarget; // 0x5e0(0x08)
	struct UDaySequence* UserDaySequence; // 0x5e8(0x08)
	struct UDaySequence* ProceduralDaySequence; // 0x5f0(0x08)
	struct TMap<struct FName, struct FDaySequenceModifierNamedSequence> AdditionalNamedDaySequences; // 0x5f8(0x50)
	char pad_648[0x8]; // 0x648(0x08)
	int32_t Bias; // 0x650(0x04)
	float DayNightCycleTime; // 0x654(0x04)
	float BlendAmount; // 0x658(0x04)
	char pad_65C[0x4]; // 0x65c(0x04)
	float CustomVolumeBlendWeight; // 0x660(0x04)
	enum class EDayNightCycleMode DayNightCycle; // 0x664(0x01)
	enum class EDaySequenceModifierBlendMode BlendMode; // 0x665(0x01)
	char pad_666[0x2]; // 0x666(0x02)
	struct FMulticastInlineDelegate OnPostReinitializeSubSequences; // 0x668(0x10)
	struct FMulticastInlineDelegate OnPostEnableModifier; // 0x678(0x10)
	char bIgnoreBias : 1; // 0x688(0x01)
	char bUseVolume : 1; // 0x688(0x01)
	char bIsComponentEnabled : 1; // 0x688(0x01)
	char bIsEnabled : 1; // 0x688(0x01)
	char bPreview : 1; // 0x688(0x01)
	char pad_688_5 : 3; // 0x688(0x01)
	char pad_689[0x67]; // 0x689(0x67)

	void UnbindFromDaySequenceActor(); // Function DaySequence.DaySequenceModifierComponent.UnbindFromDaySequenceActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f20e70
	void SetUserDaySequence(struct UDaySequence* InDaySequence); // Function DaySequence.DaySequenceModifierComponent.SetUserDaySequence // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f1f730
	void SetCustomVolumeBlendWeight(float Weight); // Function DaySequence.DaySequenceModifierComponent.SetCustomVolumeBlendWeight // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f1f510
	void ResetOverrides(); // Function DaySequence.DaySequenceModifierComponent.ResetOverrides // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f20d80
	void MuteNamedSequence(struct FName SequenceKey, bool bState); // Function DaySequence.DaySequenceModifierComponent.MuteNamedSequence // (Final|Native|Public|BlueprintCallable) // @ game+0x6f1f350
	struct UShapeComponent* GetShapeVolumeComponent(); // Function DaySequence.DaySequenceModifierComponent.GetShapeVolumeComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x6f1f4e0
	void EnableModifier(); // Function DaySequence.DaySequenceModifierComponent.EnableModifier // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f20dc0
	void EnableDistanceVolumeBlends(struct AActor* InActor); // Function DaySequence.DaySequenceModifierComponent.EnableDistanceVolumeBlends // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f1f610
	void EnableComponent(); // Function DaySequence.DaySequenceModifierComponent.EnableComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f20e30
	void DisableModifier(); // Function DaySequence.DaySequenceModifierComponent.DisableModifier // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f20da0
	void DisableComponent(); // Function DaySequence.DaySequenceModifierComponent.DisableComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f20de0
	void BindToDaySequenceActor(struct ADaySequenceActor* DaySequenceActor); // Function DaySequence.DaySequenceModifierComponent.BindToDaySequenceActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f20ed0
	void AddVisibilityOverride(struct UObject* Object, bool bValue); // Function DaySequence.DaySequenceModifierComponent.AddVisibilityOverride // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f1f820
	void AddVectorOverride(struct UObject* Object, struct FName PropertyName, struct FVector Value); // Function DaySequence.DaySequenceModifierComponent.AddVectorOverride // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6f20580
	void AddTransformOverride(struct UObject* Object, struct FTransform Value); // Function DaySequence.DaySequenceModifierComponent.AddTransformOverride // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6f20150
	void AddStaticTimeOfDayOverride(struct ADaySequenceActor* Actor, float Hours); // Function DaySequence.DaySequenceModifierComponent.AddStaticTimeOfDayOverride // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f20c00
	void AddScalarOverride(struct UObject* Object, struct FName PropertyName, double Value); // Function DaySequence.DaySequenceModifierComponent.AddScalarOverride // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f207c0
	void AddScalarMaterialParameterOverride(struct UObject* Object, int32_t MaterialIndex, struct FName ParameterName, float Value); // Function DaySequence.DaySequenceModifierComponent.AddScalarMaterialParameterOverride // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f1fc80
	void AddMaterialOverride(struct UObject* Object, int32_t MaterialIndex, struct UMaterialInterface* Value); // Function DaySequence.DaySequenceModifierComponent.AddMaterialOverride // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f1ff30
	void AddColorOverride(struct UObject* Object, struct FName PropertyName, struct FLinearColor Value); // Function DaySequence.DaySequenceModifierComponent.AddColorOverride // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6f20360
	void AddColorMaterialParameterOverride(struct UObject* Object, int32_t MaterialIndex, struct FName ParameterName, struct FLinearColor Value); // Function DaySequence.DaySequenceModifierComponent.AddColorMaterialParameterOverride // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6f1f9b0
	void AddBoolOverride(struct UObject* Object, struct FName PropertyName, bool bValue); // Function DaySequence.DaySequenceModifierComponent.AddBoolOverride // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f209e0
};

// Class DaySequence.DaySequence
// Size: 0x130 (Inherited: 0x68)
struct UDaySequence : UMovieSceneSequence {
	char pad_68[0x8]; // 0x68(0x08)
	struct UMovieScene* MovieScene; // 0x70(0x08)
	struct FDaySequenceBindingReferences BindingReferences; // 0x78(0xa0)
	ClassPtrProperty DirectorClass; // 0x118(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x120(0x10)
};

// Class DaySequence.DaySequenceActor
// Size: 0x3d0 (Inherited: 0x290)
struct ADaySequenceActor : AInfo {
	char pad_290[0x10]; // 0x290(0x10)
	struct UDaySequencePlayer* SequencePlayer; // 0x2a0(0x08)
	struct UCurveFloat* DayInterpCurve; // 0x2a8(0x08)
	struct TMap<struct FName, struct FDaySequenceAssetData> DaySequences; // 0x2b0(0x50)
	struct UMovieSceneBindingOverrides* BindingOverrides; // 0x300(0x08)
	char bReplicatePlayback : 1; // 0x308(0x01)
	char pad_308_1 : 7; // 0x308(0x01)
	char pad_309[0x7]; // 0x309(0x07)
	struct UDaySequence* RootSequence; // 0x310(0x08)
	bool bRunDayCycle; // 0x318(0x01)
	bool bUseInterpCurve; // 0x319(0x01)
	char pad_31A[0x2]; // 0x31a(0x02)
	struct FTimecode DayLength; // 0x31c(0x14)
	struct FTimecode TimePerCycle; // 0x330(0x14)
	struct FTimecode InitialTimeOfDay; // 0x344(0x14)
	char pad_358[0x78]; // 0x358(0x78)

	bool SetTimeOfDay(float InHours); // Function DaySequence.DaySequenceActor.SetTimeOfDay // (Final|Native|Public|BlueprintCallable) // @ game+0x6f23510
	void SetStaticTimeOfDay(float InHours); // Function DaySequence.DaySequenceActor.SetStaticTimeOfDay // (Final|Native|Public|BlueprintCallable) // @ game+0x6f22d80
	void SetReplicatePlayback(bool ReplicatePlayback); // Function DaySequence.DaySequenceActor.SetReplicatePlayback // (Final|Native|Public|BlueprintCallable) // @ game+0x6f236d0
	void SetDaySequence(struct FName SequenceName, struct UDaySequence* InDaySequence); // Function DaySequence.DaySequenceActor.SetDaySequence // (Final|Native|Public|BlueprintCallable) // @ game+0x6f237d0
	void SetBias(struct FName SequenceKey, int32_t Bias); // Function DaySequence.DaySequenceActor.SetBias // (Final|Native|Public|BlueprintCallable) // @ game+0x6f23050
	void RemoveStaticTimeOfDay(bool bResumeFromStaticTime); // Function DaySequence.DaySequenceActor.RemoveStaticTimeOfDay // (Final|Native|Public|BlueprintCallable) // @ game+0x6f22c90
	void Play(); // Function DaySequence.DaySequenceActor.Play // (Final|Native|Public|BlueprintCallable) // @ game+0x6f234f0
	void Pause(); // Function DaySequence.DaySequenceActor.Pause // (Final|Native|Public|BlueprintCallable) // @ game+0x6f234d0
	void MuteSequence(struct FName SequenceKey, bool bState); // Function DaySequence.DaySequenceActor.MuteSequence // (Final|Native|Public|BlueprintCallable) // @ game+0x6f232c0
	void Multicast_SetTimePerCycle(float InHours); // Function DaySequence.DaySequenceActor.Multicast_SetTimePerCycle // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x34e0af0
	bool IsPlaying(); // Function DaySequence.DaySequenceActor.IsPlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f23490
	bool IsPaused(); // Function DaySequence.DaySequenceActor.IsPaused // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f23450
	bool IsMuteSequence(struct FName SequenceKey); // Function DaySequence.DaySequenceActor.IsMuteSequence // (Final|Native|Public|BlueprintCallable) // @ game+0x6f231d0
	bool HasStaticTimeOfDay(); // Function DaySequence.DaySequenceActor.HasStaticTimeOfDay // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f22ea0
	float GetTimePerCycle(); // Function DaySequence.DaySequenceActor.GetTimePerCycle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f23670
	float GetTimeOfDay(); // Function DaySequence.DaySequenceActor.GetTimeOfDay // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f23610
	float GetStaticTimeOfDay(); // Function DaySequence.DaySequenceActor.GetStaticTimeOfDay // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f22e70
	struct UDaySequencePlayer* GetSequencePlayer(); // Function DaySequence.DaySequenceActor.GetSequencePlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f23dc0
	float GetInitialTimeOfDay(); // Function DaySequence.DaySequenceActor.GetInitialTimeOfDay // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f23640
	struct UDaySequence* GetFirstDaySequence(); // Function DaySequence.DaySequenceActor.GetFirstDaySequence // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f23d90
	struct UDaySequence* GetDaySequence(struct FName SequenceName); // Function DaySequence.DaySequenceActor.GetDaySequence // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f23c10
	float GetDayLength(); // Function DaySequence.DaySequenceActor.GetDayLength // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f236a0
	int32_t GetBias(struct FName SequenceKey); // Function DaySequence.DaySequenceActor.GetBias // (Final|Native|Public|BlueprintCallable) // @ game+0x6f22f60
	bool ContainsDaySequence(struct UDaySequence* InDaySequence); // Function DaySequence.DaySequenceActor.ContainsDaySequence // (Final|Native|Public|BlueprintCallable) // @ game+0x6f23950
};

// Class DaySequence.DaySequenceDirector
// Size: 0x38 (Inherited: 0x28)
struct UDaySequenceDirector : UObject {
	struct UDaySequencePlayer* Player; // 0x28(0x08)
	int32_t SubSequenceID; // 0x30(0x04)
	int32_t MovieScenePlayerIndex; // 0x34(0x04)

	void OnCreated(); // Function DaySequence.DaySequenceDirector.OnCreated // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	struct UMovieSceneSequence* GetSequence(); // Function DaySequence.DaySequenceDirector.GetSequence // (Final|Native|Public|BlueprintCallable) // @ game+0x3b20ec0
	struct FQualifiedFrameTime GetRootSequenceTime(); // Function DaySequence.DaySequenceDirector.GetRootSequenceTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f2a100
	struct FQualifiedFrameTime GetMasterSequenceTime(); // Function DaySequence.DaySequenceDirector.GetMasterSequenceTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f2a0c0
	struct FQualifiedFrameTime GetCurrentTime(); // Function DaySequence.DaySequenceDirector.GetCurrentTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3b21570
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding); // Function DaySequence.DaySequenceDirector.GetBoundObjects // (Final|Native|Public|BlueprintCallable) // @ game+0x3b21410
	struct UObject* GetBoundObject(struct FMovieSceneObjectBindingID ObjectBinding); // Function DaySequence.DaySequenceDirector.GetBoundObject // (Final|Native|Public|BlueprintCallable) // @ game+0x3b211f0
	struct TArray<struct AActor*> GetBoundActors(struct FMovieSceneObjectBindingID ObjectBinding); // Function DaySequence.DaySequenceDirector.GetBoundActors // (Final|Native|Public|BlueprintCallable) // @ game+0x3b21090
	struct AActor* GetBoundActor(struct FMovieSceneObjectBindingID ObjectBinding); // Function DaySequence.DaySequenceDirector.GetBoundActor // (Final|Native|Public|BlueprintCallable) // @ game+0x3b20f70
};

// Class DaySequence.DaySequencePlayer
// Size: 0x4d0 (Inherited: 0x4c8)
struct UDaySequencePlayer : UMovieSceneSequencePlayer {
	char pad_4C8[0x8]; // 0x4c8(0x08)
};

// Class DaySequence.DaySequenceProjectSettings
// Size: 0x60 (Inherited: 0x30)
struct UDaySequenceProjectSettings : UDeveloperSettings {
	bool bDefaultLockEngineToDisplayRate; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FString DefaultDisplayRate; // 0x38(0x10)
	struct FString DefaultTickResolution; // 0x48(0x10)
	enum class EUpdateClockSource DefaultClockSource; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class DaySequence.DaySequenceProvider
// Size: 0x2a0 (Inherited: 0x290)
struct ADaySequenceProvider : AActor {
	struct TArray<struct UDaySequence*> DaySequenceAssets; // 0x290(0x10)
};

// Class DaySequence.DaySequenceSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UDaySequenceSubsystem : UWorldSubsystem {

	struct ADaySequenceActor* GetDaySequenceActor(); // Function DaySequence.DaySequenceSubsystem.GetDaySequenceActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6f2f7a0
};

// Class DaySequence.DaySequenceTrack
// Size: 0xa8 (Inherited: 0xa8)
struct UDaySequenceTrack : UMovieSceneSubTrack {
};

// Class DaySequence.EnvironmentLightingActor
// Size: 0x2d0 (Inherited: 0x2a0)
struct AEnvironmentLightingActor : ADaySequenceProvider {
	struct USkyAtmosphereComponent* SkyAtmosphereComponent; // 0x2a0(0x08)
	struct USkyLightComponent* SkyLightComponent; // 0x2a8(0x08)
	struct USceneComponent* SunRootComponent; // 0x2b0(0x08)
	struct UDirectionalLightComponent* SunComponent; // 0x2b8(0x08)
	struct UExponentialHeightFogComponent* ExponentialHeightFogComponent; // 0x2c0(0x08)
	struct UVolumetricCloudComponent* VolumetricCloudComponent; // 0x2c8(0x08)
};

