// Enum DaySequence.EDayNightCycleMode
enum class EDayNightCycleMode : uint8 {
	Default = 0,
	FixedTime = 1,
	StartAtSpecifiedTime = 2,
	RandomFixedTime = 3,
	RandomStartTime = 4,
	EDayNightCycleMode_MAX = 5
};

// Enum DaySequence.EDaySequenceModifierBlendMode
enum class EDaySequenceModifierBlendMode : uint8 {
	None = 0,
	Distance = 1,
	EDaySequenceModifierBlendMode_MAX = 2
};

// ScriptStruct DaySequence.DaySequenceModifierNamedSequence
// Size: 0x10 (Inherited: 0x00)
struct FDaySequenceModifierNamedSequence {
	struct UDaySequence* Sequence; // 0x00(0x08)
	int32_t BiasOffset; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct DaySequence.DaySequenceAssetData
// Size: 0x10 (Inherited: 0x00)
struct FDaySequenceAssetData {
	struct UDaySequence* Sequence; // 0x00(0x08)
	int32_t Bias; // 0x08(0x04)
	bool bMuted; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
};

// ScriptStruct DaySequence.DaySequenceBindingReference
// Size: 0x30 (Inherited: 0x00)
struct FDaySequenceBindingReference {
	struct TSoftObjectPtr<UObject> ExternalObjectPath; // 0x00(0x20)
	struct FString ObjectPath; // 0x20(0x10)
};

// ScriptStruct DaySequence.DaySequenceBindingReferenceArray
// Size: 0x10 (Inherited: 0x00)
struct FDaySequenceBindingReferenceArray {
	struct TArray<struct FDaySequenceBindingReference> References; // 0x00(0x10)
};

// ScriptStruct DaySequence.DaySequenceBindingReferences
// Size: 0xa0 (Inherited: 0x00)
struct FDaySequenceBindingReferences {
	struct TMap<struct FGuid, struct FDaySequenceBindingReferenceArray> BindingIdToReferences; // 0x00(0x50)
	struct TSet<struct FGuid> AnimSequenceInstances; // 0x50(0x50)
};

