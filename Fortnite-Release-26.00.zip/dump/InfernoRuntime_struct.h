// ScriptStruct InfernoRuntime.FortCurieVoxelPropagationProperties
// Size: 0x18 (Inherited: 0x08)
struct FFortCurieVoxelPropagationProperties : FTableRowBase {
	float PropagationZDirectionDownMultiplier; // 0x08(0x04)
	float PropagationZDirectionUpMultiplier; // 0x0c(0x04)
	float PropagationBaseDelay; // 0x10(0x04)
	float PropagationBaseSpeed; // 0x14(0x04)
};

// ScriptStruct InfernoRuntime.FortCurieVoxelFirePropagationManagerTickFunction
// Size: 0x30 (Inherited: 0x28)
struct FFortCurieVoxelFirePropagationManagerTickFunction : FTickFunction {
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct InfernoRuntime.FortCurieVoxelFireParticleGrassData
// Size: 0x58 (Inherited: 0x00)
struct FFortCurieVoxelFireParticleGrassData {
	char pad_0[0x58]; // 0x00(0x58)
};

