// ScriptStruct DynamicCapsuleCodeRuntime.DynamicCapsuleState
// Size: 0x10 (Inherited: 0x00)
struct FDynamicCapsuleState {
	float CapsuleRadius; // 0x00(0x04)
	float CapsuleHalfHeight; // 0x04(0x04)
	double RelativeMeshHeight; // 0x08(0x08)
};

// ScriptStruct DynamicCapsuleCodeRuntime.DynamicCapsuleEntry
// Size: 0x18 (Inherited: 0x00)
struct FDynamicCapsuleEntry {
	struct FGameplayTag tag; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FDynamicCapsuleState State; // 0x08(0x10)
};

