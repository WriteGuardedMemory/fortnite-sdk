// Class InterchangePipelines.InterchangeGenericCommonMeshesProperties
// Size: 0xf8 (Inherited: 0xe8)
struct UInterchangeGenericCommonMeshesProperties : UInterchangePipelineBase {
	enum class EInterchangeForceMeshType ForceAllMeshAsType; // 0xe8(0x01)
	bool bImportLods; // 0xe9(0x01)
	bool bBakeMeshes; // 0xea(0x01)
	enum class EInterchangeVertexColorImportOption VertexColorImportOption; // 0xeb(0x01)
	struct FColor VertexOverrideColor; // 0xec(0x04)
	bool bRecomputeNormals; // 0xf0(0x01)
	bool bRecomputeTangents; // 0xf1(0x01)
	bool bUseMikkTSpace; // 0xf2(0x01)
	bool bComputeWeightedNormals; // 0xf3(0x01)
	bool bUseHighPrecisionTangentBasis; // 0xf4(0x01)
	bool bUseFullPrecisionUVs; // 0xf5(0x01)
	bool bUseBackwardsCompatibleF16TruncUVs; // 0xf6(0x01)
	bool bRemoveDegenerates; // 0xf7(0x01)
};

// Class InterchangePipelines.InterchangeGenericCommonSkeletalMeshesAndAnimationsProperties
// Size: 0xf8 (Inherited: 0xe8)
struct UInterchangeGenericCommonSkeletalMeshesAndAnimationsProperties : UInterchangePipelineBase {
	bool bImportOnlyAnimations; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	struct TWeakObjectPtr<struct USkeleton> Skeleton; // 0xec(0x08)
	bool bImportMeshesInBoneHierarchy; // 0xf4(0x01)
	bool bUseT0AsRefPose; // 0xf5(0x01)
	bool bConvertStaticsWithMorphTargetsToSkeletals; // 0xf6(0x01)
	char pad_F7[0x1]; // 0xf7(0x01)
};

// Class InterchangePipelines.GLTFPipelineSettings
// Size: 0x88 (Inherited: 0x30)
struct UGLTFPipelineSettings : UDeveloperSettings {
	struct TMap<struct FString, struct FSoftObjectPath> MaterialParents; // 0x30(0x50)
	char pad_80[0x8]; // 0x80(0x08)
};

// Class InterchangePipelines.InterchangeGLTFPipeline
// Size: 0xf8 (Inherited: 0xe8)
struct UInterchangeGLTFPipeline : UInterchangePipelineBase {
	char pad_E8[0x8]; // 0xe8(0x08)
	bool bUseGLTFMaterialInstanceLibrary; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
};

// Class InterchangePipelines.MaterialXPipelineSettings
// Size: 0x80 (Inherited: 0x30)
struct UMaterialXPipelineSettings : UDeveloperSettings {
	struct TMap<enum class EInterchangeMaterialXShaders, struct FSoftObjectPath> PredefinedSurfaceShaders; // 0x30(0x50)
};

// Class InterchangePipelines.InterchangeMaterialXPipeline
// Size: 0xf0 (Inherited: 0xe8)
struct UInterchangeMaterialXPipeline : UInterchangePipelineBase {
	char pad_E8[0x8]; // 0xe8(0x08)
};

// Class InterchangePipelines.InterchangeGenericAnimationPipeline
// Size: 0x158 (Inherited: 0xe8)
struct UInterchangeGenericAnimationPipeline : UInterchangePipelineBase {
	struct TWeakObjectPtr<struct UInterchangeGenericCommonSkeletalMeshesAndAnimationsProperties> CommonSkeletalMeshesAndAnimationsProperties; // 0xe8(0x08)
	struct TWeakObjectPtr<struct UInterchangeGenericCommonMeshesProperties> CommonMeshesProperties; // 0xf0(0x08)
	bool bImportAnimations; // 0xf8(0x01)
	bool bImportBoneTracks; // 0xf9(0x01)
	enum class EInterchangeAnimationRange AnimationRange; // 0xfa(0x01)
	char pad_FB[0x1]; // 0xfb(0x01)
	struct FInt32Interval FrameImportRange; // 0xfc(0x08)
	bool bUse30HzToBakeBoneAnimation; // 0x104(0x01)
	char pad_105[0x3]; // 0x105(0x03)
	int32_t CustomBoneAnimationSampleRate; // 0x108(0x04)
	bool bSnapToClosestFrameBoundary; // 0x10c(0x01)
	bool bImportCustomAttribute; // 0x10d(0x01)
	bool bAddCurveMetadataToSkeleton; // 0x10e(0x01)
	bool bSetMaterialDriveParameterOnCustomAttribute; // 0x10f(0x01)
	struct TArray<struct FString> MaterialCurveSuffixes; // 0x110(0x10)
	bool bRemoveCurveRedundantKeys; // 0x120(0x01)
	bool bDoNotImportCurveWithZero; // 0x121(0x01)
	bool bDeleteExistingNonCurveCustomAttributes; // 0x122(0x01)
	bool bDeleteExistingCustomAttributeCurves; // 0x123(0x01)
	bool bDeleteExistingMorphTargetCurves; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
	struct FString SourceAnimationName; // 0x128(0x10)
	bool bSceneImport; // 0x138(0x01)
	char pad_139[0x1f]; // 0x139(0x1f)
};

// Class InterchangePipelines.InterchangeGenericAssetsPipeline
// Size: 0x178 (Inherited: 0xe8)
struct UInterchangeGenericAssetsPipeline : UInterchangePipelineBase {
	enum class EReimportStrategyFlags ReimportStrategy; // 0xe8(0x01)
	bool bUseSourceNameForAsset; // 0xe9(0x01)
	char pad_EA[0x6]; // 0xea(0x06)
	struct FString AssetName; // 0xf0(0x10)
	struct FVector ImportOffsetTranslation; // 0x100(0x18)
	struct FRotator ImportOffsetRotation; // 0x118(0x18)
	float ImportOffsetUniformScale; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct UInterchangeGenericCommonMeshesProperties* CommonMeshesProperties; // 0x138(0x08)
	struct UInterchangeGenericCommonSkeletalMeshesAndAnimationsProperties* CommonSkeletalMeshesAndAnimationsProperties; // 0x140(0x08)
	struct UInterchangeGenericMeshPipeline* MeshPipeline; // 0x148(0x08)
	struct UInterchangeGenericAnimationPipeline* AnimationPipeline; // 0x150(0x08)
	struct UInterchangeGenericMaterialPipeline* MaterialPipeline; // 0x158(0x08)
	char pad_160[0x18]; // 0x160(0x18)
};

// Class InterchangePipelines.InterchangeGenericMaterialPipeline
// Size: 0x178 (Inherited: 0xe8)
struct UInterchangeGenericMaterialPipeline : UInterchangePipelineBase {
	bool bImportMaterials; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
	struct FString AssetName; // 0xf0(0x10)
	enum class EInterchangeMaterialImportOption MaterialImport; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FSoftObjectPath ParentMaterial; // 0x108(0x18)
	struct UInterchangeGenericTexturePipeline* TexturePipeline; // 0x120(0x08)
	struct UInterchangeBaseNodeContainer* BaseNodeContainer; // 0x128(0x08)
	char pad_130[0x48]; // 0x130(0x48)
};

// Class InterchangePipelines.InterchangeGenericMeshPipeline
// Size: 0x1b8 (Inherited: 0xe8)
struct UInterchangeGenericMeshPipeline : UInterchangePipelineBase {
	struct TWeakObjectPtr<struct UInterchangeGenericCommonMeshesProperties> CommonMeshesProperties; // 0xe8(0x08)
	struct TWeakObjectPtr<struct UInterchangeGenericCommonSkeletalMeshesAndAnimationsProperties> CommonSkeletalMeshesAndAnimationsProperties; // 0xf0(0x08)
	bool bImportStaticMeshes; // 0xf8(0x01)
	bool bCombineStaticMeshes; // 0xf9(0x01)
	char pad_FA[0x2]; // 0xfa(0x02)
	struct FName LODGroup; // 0xfc(0x04)
	bool bImportCollision; // 0x100(0x01)
	bool bImportCollisionAccordingToMeshName; // 0x101(0x01)
	bool bOneConvexHullPerUCX; // 0x102(0x01)
	bool bBuildNanite; // 0x103(0x01)
	bool bBuildReversedIndexBuffer; // 0x104(0x01)
	bool bGenerateLightmapUVs; // 0x105(0x01)
	bool bGenerateDistanceFieldAsIfTwoSided; // 0x106(0x01)
	bool bSupportFaceRemap; // 0x107(0x01)
	int32_t MinLightmapResolution; // 0x108(0x04)
	int32_t SrcLightmapIndex; // 0x10c(0x04)
	int32_t DstLightmapIndex; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
	struct FVector BuildScale3D; // 0x118(0x18)
	float DistanceFieldResolutionScale; // 0x130(0x04)
	struct TWeakObjectPtr<struct UStaticMesh> DistanceFieldReplacementMesh; // 0x134(0x08)
	int32_t MaxLumenMeshCards; // 0x13c(0x04)
	bool bImportSkeletalMeshes; // 0x140(0x01)
	enum class EInterchangeSkeletalMeshContentType SkeletalMeshImportContentType; // 0x141(0x01)
	enum class EInterchangeSkeletalMeshContentType LastSkeletalMeshImportContentType; // 0x142(0x01)
	bool bCombineSkeletalMeshes; // 0x143(0x01)
	bool bImportMorphTargets; // 0x144(0x01)
	bool bUpdateSkeletonReferencePose; // 0x145(0x01)
	bool bCreatePhysicsAsset; // 0x146(0x01)
	char pad_147[0x1]; // 0x147(0x01)
	struct TWeakObjectPtr<struct UPhysicsAsset> PhysicsAsset; // 0x148(0x08)
	bool bUseHighPrecisionSkinWeights; // 0x150(0x01)
	char pad_151[0x3]; // 0x151(0x03)
	float ThresholdPosition; // 0x154(0x04)
	float ThresholdTangentNormal; // 0x158(0x04)
	float ThresholdUV; // 0x15c(0x04)
	float MorphThresholdPosition; // 0x160(0x04)
	int32_t BoneInfluenceLimit; // 0x164(0x04)
	char pad_168[0x50]; // 0x168(0x50)
};

// Class InterchangePipelines.InterchangeGenericLevelPipeline
// Size: 0xf8 (Inherited: 0xe8)
struct UInterchangeGenericLevelPipeline : UInterchangePipelineBase {
	enum class EReimportStrategyFlags ReimportPropertyStrategy; // 0xe8(0x01)
	bool bDeleteMissingActors; // 0xe9(0x01)
	bool bForceReimportDeletedActors; // 0xea(0x01)
	bool bForceReimportDeletedAssets; // 0xeb(0x01)
	bool bDeleteMissingAssets; // 0xec(0x01)
	bool bUsePhysicalInsteadOfStandardPerspectiveCamera; // 0xed(0x01)
	char pad_EE[0xa]; // 0xee(0x0a)
};

// Class InterchangePipelines.InterchangeGenericTexturePipeline
// Size: 0x140 (Inherited: 0xe8)
struct UInterchangeGenericTexturePipeline : UInterchangePipelineBase {
	bool bImportTextures; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
	struct FString AssetName; // 0xf0(0x10)
	bool bAllowNonPowerOfTwo; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct UInterchangeBaseNodeContainer* BaseNodeContainer; // 0x108(0x08)
	char pad_110[0x30]; // 0x110(0x30)
};

// Class InterchangePipelines.InterchangePipelineMeshesUtilities
// Size: 0x128 (Inherited: 0x28)
struct UInterchangePipelineMeshesUtilities : UObject {
	char pad_28[0x100]; // 0x28(0x100)

	void SetContext(struct FInterchangePipelineMeshesUtilitiesContext& Context); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.SetContext // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0b620
	bool IsValidMeshInstanceUid(struct FString MeshInstanceUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.IsValidMeshInstanceUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0c180
	bool IsValidMeshGeometryUid(struct FString MeshGeometryUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.IsValidMeshGeometryUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0bdf0
	struct FString GetMeshInstanceSkeletonRootUid(struct FString MeshInstanceUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetMeshInstanceSkeletonRootUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0b880
	struct FInterchangeMeshInstance GetMeshInstanceByUid(struct FString MeshInstanceUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetMeshInstanceByUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0bf40
	struct FString GetMeshGeometrySkeletonRootUid(struct FString MeshGeometryUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetMeshGeometrySkeletonRootUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0b720
	struct FInterchangeMeshGeometry GetMeshGeometryByUid(struct FString MeshGeometryUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetMeshGeometryByUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0bc60
	void GetAllStaticMeshInstance(struct TArray<struct FString>& MeshInstanceUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllStaticMeshInstance // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0c850
	void GetAllStaticMeshGeometry(struct TArray<struct FString>& MeshGeometryUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllStaticMeshGeometry // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0c430
	void GetAllSkinnedMeshInstance(struct TArray<struct FString>& MeshInstanceUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllSkinnedMeshInstance // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0c9b0
	void GetAllSkinnedMeshGeometry(struct TArray<struct FString>& MeshGeometryUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllSkinnedMeshGeometry // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0c590
	void GetAllMeshInstanceUidsUsingMeshGeometryUid(struct FString MeshGeometryUid, struct TArray<struct FString>& MeshInstanceUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllMeshInstanceUidsUsingMeshGeometryUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0b9e0
	void GetAllMeshInstanceUids(struct TArray<struct FString>& MeshInstanceUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllMeshInstanceUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0cb10
	void GetAllMeshGeometryNotInstanced(struct TArray<struct FString>& MeshGeometryUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllMeshGeometryNotInstanced // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0c2d0
	void GetAllMeshGeometry(struct TArray<struct FString>& MeshGeometryUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllMeshGeometry // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbb0c6f0
	struct UInterchangePipelineMeshesUtilities* CreateInterchangePipelineMeshesUtilities(struct UInterchangeBaseNodeContainer* BaseNodeContainer); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.CreateInterchangePipelineMeshesUtilities // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbb0cc70
};

