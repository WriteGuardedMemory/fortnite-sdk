// Enum InterchangeFactoryNodes.EInterchangeSkeletalMeshContentType
enum class EInterchangeSkeletalMeshContentType : uint8 {
	All = 0,
	Geometry = 1,
	SkinningWeights = 2,
	MAX = 3
};

