// Class CableComponent.CableActor
// Size: 0x298 (Inherited: 0x290)
struct ACableActor : AActor {
	struct UCableComponent* CableComponent; // 0x290(0x08)
};

// Class CableComponent.CableComponent
// Size: 0x650 (Inherited: 0x5a0)
struct UCableComponent : UMeshComponent {
	bool bAttachStart; // 0x5a0(0x01)
	bool bAttachEnd; // 0x5a1(0x01)
	char pad_5A2[0x6]; // 0x5a2(0x06)
	struct FComponentReference AttachEndTo; // 0x5a8(0x28)
	struct FName AttachEndToSocketName; // 0x5d0(0x04)
	char pad_5D4[0x4]; // 0x5d4(0x04)
	struct FVector EndLocation; // 0x5d8(0x18)
	float CableLength; // 0x5f0(0x04)
	int32_t NumSegments; // 0x5f4(0x04)
	float SubstepTime; // 0x5f8(0x04)
	int32_t SolverIterations; // 0x5fc(0x04)
	bool bEnableStiffness; // 0x600(0x01)
	bool bUseSubstepping; // 0x601(0x01)
	bool bSkipCableUpdateWhenNotVisible; // 0x602(0x01)
	bool bSkipCableUpdateWhenNotOwnerRecentlyRendered; // 0x603(0x01)
	bool bEnableCollision; // 0x604(0x01)
	char pad_605[0x3]; // 0x605(0x03)
	float CollisionFriction; // 0x608(0x04)
	char pad_60C[0x4]; // 0x60c(0x04)
	struct FVector CableForce; // 0x610(0x18)
	float CableGravityScale; // 0x628(0x04)
	float CableWidth; // 0x62c(0x04)
	int32_t NumSides; // 0x630(0x04)
	float TileMaterial; // 0x634(0x04)
	char pad_638[0x18]; // 0x638(0x18)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x6c46690
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo // (Final|Native|Public|BlueprintCallable) // @ game+0x6c46450
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c461a0
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c46340
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c463d0
};

