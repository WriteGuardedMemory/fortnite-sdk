// Class MidMatchAssignedGameplayRuntime.FortGameStateComponent_AssignedObjective
// Size: 0x1d0 (Inherited: 0xa8)
struct UFortGameStateComponent_AssignedObjective : UFortGameStateComponent_MidMatchObjectiveParent {
	struct FScalableFloat IdealNumSquadsPerObjective; // 0xa8(0x28)
	struct FScalableFloat bAllowUnopposedSquads; // 0xd0(0x28)
	struct FScalableFloat MinPairedSquadDistForUnopposed; // 0xf8(0x28)
	struct FScalableFloat UnopposedSquad_FakeSquadMaxSafeZonePct; // 0x120(0x28)
	struct FScalableFloat UnopposedSquad_FakeSquadMinDistToSquad; // 0x148(0x28)
	struct FScalableFloat SpawnObjectivesInsideSafeZonePct; // 0x170(0x28)
	struct TSoftObjectPtr<UEnvQuery> AssignedObjectiveLocationEnvQuery; // 0x198(0x20)
	struct TArray<struct FFortAssignedObjectiveData> AssignedObjectives; // 0x1b8(0x10)
	char pad_1C8[0x8]; // 0x1c8(0x08)

	void StartAssignedObjectives(); // Function MidMatchAssignedGameplayRuntime.FortGameStateComponent_AssignedObjective.StartAssignedObjectives // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3982d70
	void OnAssignedObjectiveReady(struct FFortAssignedObjectiveData& ObjectiveData); // Function MidMatchAssignedGameplayRuntime.FortGameStateComponent_AssignedObjective.OnAssignedObjectiveReady // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	struct FVector CalculateSquadAvgLocation(char SquadId, struct UObject* WorldContextObject); // Function MidMatchAssignedGameplayRuntime.FortGameStateComponent_AssignedObjective.CalculateSquadAvgLocation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0xacb0ec0
};

// Class MidMatchAssignedGameplayRuntime.FortQueryContext_SpawnedObjectiveLocations
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_SpawnedObjectiveLocations : UEnvQueryContext {
};

// Class MidMatchAssignedGameplayRuntime.FortQueryContext_SquadAvgLocationsForObjective
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_SquadAvgLocationsForObjective : UEnvQueryContext {
};

// Class MidMatchAssignedGameplayRuntime.FortQueryTest_ClosestPlayersToObjectiveDeltaDistance
// Size: 0x200 (Inherited: 0x1f8)
struct UFortQueryTest_ClosestPlayersToObjectiveDeltaDistance : UEnvQueryTest {
	bool bUseDistance2D; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
};

