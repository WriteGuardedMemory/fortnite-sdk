// Class ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance
// Size: 0x1690 (Inherited: 0x15d0)
struct UFortArmoredBattleBusPassengerAnimInstance : UFortPlayerAnimInstanceProxy {
	struct FRotator PreviousVehicleRotator; // 0x15c8(0x18)
	float SmoothedVehicleYawRate; // 0x15e0(0x04)
	int32_t PawnSeat; // 0x15e4(0x04)
	bool bIsFrontTurretPassenger; // 0x15e8(0x01)
	bool bIsRearTurretPassenger; // 0x15e9(0x01)
	float Speed; // 0x15ec(0x04)
	float YawDelta; // 0x15f0(0x04)
	float TurretYaw; // 0x15f4(0x04)
	float TurretPitch; // 0x15f8(0x04)
	struct FRotator TurretYawRotator; // 0x1600(0x18)
	float SlopeRollDegreeAngle; // 0x1618(0x04)
	float SlopePitchDegreeAngle; // 0x161c(0x04)
	struct FVector HandAttachL; // 0x1620(0x18)
	struct FVector HandAttachR; // 0x1638(0x18)
	enum class ERelativeTransformSpace TransformSpace; // 0x1650(0x01)
	char pad_1653[0x1]; // 0x1653(0x01)
	float UpdateYawDeltaSmoothedLerpRate; // 0x1654(0x04)
	int32_t TurretPassengerFront; // 0x1658(0x04)
	int32_t TurretPassengerRear; // 0x165c(0x04)
	struct FName FrontFootBoneName; // 0x1660(0x04)
	struct FName RearFootBoneName; // 0x1664(0x04)
	struct FName GunHandAttachBoneName_FrontLeft; // 0x1668(0x04)
	struct FName GunHandAttachBoneName_RearLeft; // 0x166c(0x04)
	struct FName GunHandAttachBoneName_FrontRight; // 0x1670(0x04)
	struct FName GunHandAttachBoneName_RearRight; // 0x1674(0x04)
	struct FName PassengerBoneName_Front; // 0x1678(0x04)
	struct FName PassengerBoneName_Rear; // 0x167c(0x04)
	float TurretPitchDegMin; // 0x1680(0x04)
	float TurretPitchDegMax; // 0x1684(0x04)
	float LocalPlayerTurretPitchEaseRate; // 0x1688(0x04)
	char pad_168C[0x4]; // 0x168c(0x04)

	void UpdateYawDeltaSmoothed(struct AFortAthenaVehicle* VehicleActor, struct FName SocketName, struct FRotator& NewRotation, float& SmoothedYawValue); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateYawDeltaSmoothed // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa701410
	void UpdateSmoothedVehicleYawRate(struct AFortAthenaVehicle* VehicleActor); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateSmoothedVehicleYawRate // (Final|Native|Public|BlueprintCallable) // @ game+0xa7016e0
	void UpdateHandPositionsSlopeValues(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateHandPositionsSlopeValues // (Final|Native|Public|BlueprintCallable) // @ game+0xa701320
	struct FVector UnrotateHandAttachLocation(struct FVector& HandLocation, struct FVector& FootLocation, struct FRotator& FootRotation); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UnrotateHandAttachLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa700c70
	struct FTransform GetPassengerTransform(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetPassengerTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa700ad0
	struct FVector GetHandAttachLocation(struct USkeletalMeshComponent* BusMeshComponent, struct FName FrontHandAttachBoneName, struct FName RearHandAttachBoneName); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetHandAttachLocation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa701070
	struct FTransform GetFootAttachTransform(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetFootAttachTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa700ed0
	void GenerateCharacterPitchAndYawForSlopedTerrain(struct AFortAthenaVehicle* VehicleActor, float& TurretYaw, float& TurretPitch, struct FRotator& PawnYawRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GenerateCharacterPitchAndYawForSlopedTerrain // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa7007e0
};

// Class ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance
// Size: 0x690 (Inherited: 0x600)
struct UFortArmoredBattleBusVehicleAnimInstance : UFortVehicleAnimInstance {
	float FrontTurretAimPitch; // 0x5f8(0x04)
	float RearTurretAimPitch; // 0x5fc(0x04)
	float FrontYawDeltaSmoothed; // 0x600(0x04)
	float RearYawDeltaSmoothed; // 0x604(0x04)
	float SmoothedVehicleYawRate; // 0x608(0x04)
	float FrontYawDeltaSmoothedAlpha; // 0x60c(0x04)
	float RearYawDeltaSmoothedAlpha; // 0x610(0x04)
	struct FRotator FrontWeaponYaw; // 0x618(0x18)
	struct FRotator RearWeaponYaw; // 0x630(0x18)
	struct FRotator PreviousVehicleRotator; // 0x648(0x18)
	bool bHasFrontTurretPassenger; // 0x660(0x01)
	bool bHasRearTurretPassenger; // 0x661(0x01)
	float NetworkEaseRate; // 0x664(0x04)
	float UpdateYawDeltaSmoothedLerpRate; // 0x668(0x04)
	int32_t FrontPassengerSeatIndex; // 0x66c(0x04)
	int32_t RearPassengerSeatIndex; // 0x670(0x04)
	float FrontPassengerYawOffset; // 0x674(0x04)
	float RearPassengerYawOffset; // 0x678(0x04)
	struct FName FrontPassengerBoneName; // 0x67c(0x04)
	struct FName RearPassengerBoneName; // 0x680(0x04)
	char pad_686[0xa]; // 0x686(0x0a)

	float UpdateYawDeltaSmoothed(struct AFortAthenaVehicle* VehicleActor, struct FName SocketName, struct FRotator NewRotation, float SmoothedYawValue); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateYawDeltaSmoothed // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa703ea0
	void UpdateTurretAimPitchWeaponYaw(struct AFortAthenaVehicle* OwnerVehicle, struct AFortPlayerPawn* GunnerActor, struct FName SocketName, float YawOffset, float& TurretAimPitch, float& YawDeltaSmoothed, struct FRotator& WeaponYaw); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateTurretAimPitchWeaponYaw // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa703840
	float UpdateSmoothedVehicleYawRate(struct AFortAthenaVehicle* VehicleActor, struct FRotator PreviousRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateSmoothedVehicleYawRate // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa704180
	void GetPitchAndYaw(struct AFortAthenaVehicle* VehicleActor, struct AFortPlayerPawn* GunnerActor, float& AdjustedPitch, float& AdjustedYaw, bool& bIsLocalPlayerControlled, struct FRotator& YawRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.GetPitchAndYaw // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa704450
};

