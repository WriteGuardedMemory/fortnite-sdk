// Class CharacterCollectionMapScreen.AthenaCollectionScreenMapCharacter
// Size: 0x6c0 (Inherited: 0x6b8)
struct UAthenaCollectionScreenMapCharacter : UAthenaCollectionScreenMapBase {
	struct UCollectionScreenServiceVisualData* SharedServiceVisualData; // 0x6b8(0x08)
};

// Class CharacterCollectionMapScreen.CollectionNPCServiceInfoOverlay
// Size: 0x4c8 (Inherited: 0x4b0)
struct UCollectionNPCServiceInfoOverlay : UAthenaCollectionScreenInfoOverlay {
	struct UCollectionNPCServiceContainer* Services; // 0x4b0(0x08)
	struct UImage* Image_ServiceIcon; // 0x4b8(0x08)
	struct UCollectionScreenServiceVisualData* SharedServiceVisualData; // 0x4c0(0x08)
};

