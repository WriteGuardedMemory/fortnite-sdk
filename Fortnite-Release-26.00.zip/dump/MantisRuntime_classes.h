// Class MantisRuntime.FortMantisLayerAnimInstance
// Size: 0x15e0 (Inherited: 0x15d0)
struct UFortMantisLayerAnimInstance : UFortPlayerAnimInstanceProxy {
	struct FFortMantisReplicatedAnimInstanceInfo MantisAnimInstanceInfo; // 0x15c8(0x10)

	void OnMantisTechniqueStarted(int32_t TechniqueIndex, struct FName TechniqueName); // Function MantisRuntime.FortMantisLayerAnimInstance.OnMantisTechniqueStarted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnMantisTechniqueEnded(int32_t TechniqueIndex, struct FName TechniqueName); // Function MantisRuntime.FortMantisLayerAnimInstance.OnMantisTechniqueEnded // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class MantisRuntime.FortItemLayerAnimInstance_UncleBrolly
// Size: 0x760 (Inherited: 0x6d0)
struct UFortItemLayerAnimInstance_UncleBrolly : UFortItemLayerAnimInstance {
	struct FCachedAnimStateArray UmbrellaGliderOpenStateDataArray; // 0x6c8(0x18)
	struct FVector WrapTranslation; // 0x6e0(0x18)
	struct FRotator WrapRotation; // 0x6f8(0x18)
	struct FRotator RootRotationOffset; // 0x710(0x18)
	float LandingPredictedTimer; // 0x728(0x04)
	bool bShouldUpdateYawCorrection; // 0x72c(0x01)
	bool bWasAcceleratingBeforeDodge; // 0x72d(0x01)
	float UncleBrollyDeployCurveValue; // 0x730(0x04)
	float DashChargeTier; // 0x734(0x04)
	float DashChargeAdditivePlayrate; // 0x738(0x04)
	bool bIsUmbrellaFailing; // 0x73c(0x01)
	bool bIsMeleeGuarding; // 0x73d(0x01)
	bool bIsSprinting; // 0x73e(0x01)
	bool bIsInAir; // 0x73f(0x01)
	bool bIsLandingPredicted; // 0x740(0x01)
	bool bIsJumping; // 0x741(0x01)
	bool bIsDodging; // 0x742(0x01)
	bool bIsDodgingEast; // 0x743(0x01)
	bool bIsDodgingSouth; // 0x744(0x01)
	bool bIsDodgingWest; // 0x745(0x01)
	bool bIsDashing; // 0x746(0x01)
	bool bIsDashCharging; // 0x747(0x01)
	bool bIsDashPredictingEnd; // 0x748(0x01)
	bool bIsChargeTier1; // 0x749(0x01)
	bool bIsChargeTier2; // 0x74a(0x01)
	bool bIsChargeTier3; // 0x74b(0x01)
	bool bMeleeGuardingOrUmbrellaFailing; // 0x74c(0x01)
	bool bTransition_Default_to_GuardLoop; // 0x74d(0x01)
	bool bTransition_Default_to_GuardIntro; // 0x74e(0x01)
	bool bTransition_GuardIntro_to_Default; // 0x74f(0x01)
	bool bUpperBodyShouldPassThrough; // 0x750(0x01)
	bool bUmbrellaGliderIsOpen; // 0x751(0x01)
	char pad_758[0x8]; // 0x758(0x08)
};

// Class MantisRuntime.UncleBrollyWeaponAnimInstance
// Size: 0x390 (Inherited: 0x350)
struct UUncleBrollyWeaponAnimInstance : UAnimInstance {
	struct UAnimInstance* UncleBrollyItemLayer; // 0x348(0x08)
	struct FRotator UmbrellaRotation; // 0x350(0x18)
	float UmbrellaSpinSpeed; // 0x368(0x04)
	float BlockDeployEndPlayrate; // 0x36c(0x04)
	float BlockDeployEndStartPosition; // 0x370(0x04)
	bool bIsDodging; // 0x374(0x01)
	bool bIsPlayingMeleeAnim; // 0x375(0x01)
	bool bIsUmbrellaFailing; // 0x376(0x01)
	bool bIsMeleeGuarding; // 0x377(0x01)
	bool bIsInAir; // 0x378(0x01)
	bool bIsDashing; // 0x379(0x01)
	bool bIsSprinting; // 0x37a(0x01)
	bool bIsPredictingEnd; // 0x37b(0x01)
	bool bIsDashCharging; // 0x37c(0x01)
	bool bIsDashPredictingEnd; // 0x37d(0x01)
	bool bInAirAndMeleeGuarding; // 0x37e(0x01)
	bool bTransition_Default_to_DeployStart; // 0x37f(0x01)
	bool bTransition_DeployStart_to_Default; // 0x380(0x01)
	bool bTransition_Fail_to_FailToDeploy; // 0x381(0x01)
	bool bTransition_FailLoop_to_DeployEnd; // 0x382(0x01)
	char pad_38B[0x5]; // 0x38b(0x05)
};

// Class MantisRuntime.FortAbilityTask_ApplyRootMotionMantisForce
// Size: 0x100 (Inherited: 0xb8)
struct UFortAbilityTask_ApplyRootMotionMantisForce : UAbilityTask_ApplyRootMotion_Base {
	struct FMulticastInlineDelegate OnFinish; // 0xb8(0x10)
	float Duration; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct UAnimMontage* TechniqueMontage; // 0xd0(0x08)
	struct FFortMantisRootMotionWarpInfo WarpInfo; // 0xd8(0x28)
};

// Class MantisRuntime.FortAnimNotify_Mantis
// Size: 0x40 (Inherited: 0x38)
struct UFortAnimNotify_Mantis : UAnimNotify {
	enum class EFortMantisNotifyEvent MantisNotifyEvent; // 0x38(0x01)
	enum class EFortMantisBranchRule MantisBranchRule; // 0x39(0x01)
	enum class EFortMantisBranchPath MantisBranchPath; // 0x3a(0x01)
	char pad_3B[0x5]; // 0x3b(0x05)
};

// Class MantisRuntime.FortAnimNotifyState_Mantis
// Size: 0x40 (Inherited: 0x30)
struct UFortAnimNotifyState_Mantis : UAnimNotifyState {
	enum class EFortMantisNotifyWindow MantisNotifyWindow; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FGameplayTag MantisNotifyTag; // 0x34(0x04)
	enum class EFortMantisNotifyRotationWarpRateRule RotationRateWarpRule; // 0x38(0x01)
	char bWarpRotation : 1; // 0x39(0x01)
	char bWarpTranslation : 1; // 0x39(0x01)
	char pad_39_2 : 6; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
};

// Class MantisRuntime.FortGameplayAbility_Mantis
// Size: 0xb70 (Inherited: 0xb28)
struct UFortGameplayAbility_Mantis : UFortGameplayAbility {
	bool bAllowRootMotionWarping; // 0xb28(0x01)
	bool bApplyEffectContainerOnTechniqueDamage; // 0xb29(0x01)
	bool bApplyEffectContainerOnTechniqueStart; // 0xb2a(0x01)
	char pad_B2B[0x5]; // 0xb2b(0x05)
	struct UFortMantisPawnComponent* MantisPawnComponent; // 0xb30(0x08)
	struct UAbilityTask_PlayMontageAndWait* MontageTask; // 0xb38(0x08)
	struct UAbilityTask_ApplyRootMotion_Base* RootMotionTask; // 0xb40(0x08)
	char pad_B48[0x28]; // 0xb48(0x28)

	void OnMontageFinished(); // Function MantisRuntime.FortGameplayAbility_Mantis.OnMontageFinished // (Final|Native|Protected) // @ game+0xa878a60
	void OnMontageCancelled(); // Function MantisRuntime.FortGameplayAbility_Mantis.OnMontageCancelled // (Final|Native|Protected) // @ game+0xa878a00
	int32_t GetLevelForGameplayEffectContainer(struct FGameplayTag ApplicationTag); // Function MantisRuntime.FortGameplayAbility_Mantis.GetLevelForGameplayEffectContainer // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0xa879030
	struct FName GetDynamicMontageNameForTechnique(struct FName TechniqueName); // Function MantisRuntime.FortGameplayAbility_Mantis.GetDynamicMontageNameForTechnique // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0xa878f30
	void FillMetadataForTechnique(struct FName TechniqueName, struct FFortMantisTechniqueMetadata& OutTechniqueMetadata); // Function MantisRuntime.FortGameplayAbility_Mantis.FillMetadataForTechnique // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void ConfigureRootMotionWarping(struct FName TechniqueName, bool& bOutAllowTranslationWarp, bool& bOutAllowRotationWarp, struct AActor*& OutTargetActor, bool& bOutSnapshotTargetActorLocation, bool& bOutWarpTranslationToLocation, struct FVector& outTargetLocation); // Function MantisRuntime.FortGameplayAbility_Mantis.ConfigureRootMotionWarping // (Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0xa878a80
	void BP_OnTechniqueNotifyWindowStarted(enum class EFortMantisNotifyWindow NotifyWindow, struct UFortAnimNotifyState_Mantis* Notify); // Function MantisRuntime.FortGameplayAbility_Mantis.BP_OnTechniqueNotifyWindowStarted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_OnTechniqueNotifyWindowEnded(enum class EFortMantisNotifyWindow NotifyWindow, struct UFortAnimNotifyState_Mantis* Notify); // Function MantisRuntime.FortGameplayAbility_Mantis.BP_OnTechniqueNotifyWindowEnded // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_OnTechniqueNotifyEvent(enum class EFortMantisNotifyEvent NotifyEvent, struct UFortAnimNotify_Mantis* Notify); // Function MantisRuntime.FortGameplayAbility_Mantis.BP_OnTechniqueNotifyEvent // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_OnMantisTechniqueHit(struct FGameplayAbilityTargetDataHandle& TargetDataHandle, struct FGameplayTag ApplicationTag); // Function MantisRuntime.FortGameplayAbility_Mantis.BP_OnMantisTechniqueHit // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void BP_OnMantisInputEvent(enum class EFortMantisTechniqueActivationInputType InputType, enum class EFortMantisTechniqueActivationTimingType InputTiming, bool bDidInputStartTechnique, bool bDidInputQueueTechnique, float InputHeldDuration); // Function MantisRuntime.FortGameplayAbility_Mantis.BP_OnMantisInputEvent // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_MantisAbilityTechniqueStarted(struct FGameplayTagContainer OwningTags, struct FName SequenceName, bool StartsSequence, bool EndsSequence); // Function MantisRuntime.FortGameplayAbility_Mantis.BP_MantisAbilityTechniqueStarted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class MantisRuntime.FortMantisData
// Size: 0x70 (Inherited: 0x30)
struct UFortMantisData : UDataAsset {
	bool bShowTargetHealthBar; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct UFortGameplayAbility_Mantis* TechniqueAbility; // 0x38(0x08)
	struct TArray<struct FFortGameplayEffectContainer> TechniqueAdditionEffectContainers; // 0x40(0x10)
	struct TArray<struct FFortMantisTechniqueData> Techniques; // 0x50(0x10)
	struct TArray<struct FFortMantisTechniqueBranch> Branches; // 0x60(0x10)
};

// Class MantisRuntime.FortMantisPawnComponent
// Size: 0x448 (Inherited: 0xa0)
struct UFortMantisPawnComponent : UPawnComponent {
	struct FMulticastInlineDelegate OnTechniqueMetadataReady; // 0xa0(0x10)
	char pad_B0[0xc8]; // 0xb0(0xc8)
	struct TMap<struct UAnimMontage*, struct FFortMantisMontageData> MontageDataMap; // 0x178(0x50)
	struct UFortMantisData* MantisData; // 0x1c8(0x08)
	struct AFortWeapon* Weapon; // 0x1d0(0x08)
	char pad_1D8[0x270]; // 0x1d8(0x270)

	bool TryManuallyStartTechnique(int32_t TechniqueDataIndex); // Function MantisRuntime.FortMantisPawnComponent.TryManuallyStartTechnique // (Final|Native|Public|BlueprintCallable) // @ game+0xa87e840
	bool TryManuallyEndCurrentTechnique(); // Function MantisRuntime.FortMantisPawnComponent.TryManuallyEndCurrentTechnique // (Final|Native|Public|BlueprintCallable) // @ game+0xa87e7d0
	void SimulateInputEvent(enum class EFortMantisTechniqueActivationInputType InputType, enum class EFortMantisTechniqueActivationTimingType InputTiming, bool bForceProcessEvent); // Function MantisRuntime.FortMantisPawnComponent.SimulateInputEvent // (Final|Native|Public|BlueprintCallable) // @ game+0xa87ec20
	void SetLockOnState(bool bEnabled, struct AActor* TargetActor); // Function MantisRuntime.FortMantisPawnComponent.SetLockOnState // (Final|Native|Public|BlueprintCallable) // @ game+0xa87ea10
	void SetBranchRule(enum class EFortMantisBranchRule InBranchRule, enum class EFortMantisBranchPath InBranchPath); // Function MantisRuntime.FortMantisPawnComponent.SetBranchRule // (Final|Native|Protected|BlueprintCallable) // @ game+0xa87e3c0
	void OnPostPhysicsRotation(struct UCharacterMovementComponent* CharMoveComp, float DeltaSeconds); // Function MantisRuntime.FortMantisPawnComponent.OnPostPhysicsRotation // (Final|Native|Protected) // @ game+0xa87e070
	void OnOwnerWeaponHolstered(); // Function MantisRuntime.FortMantisPawnComponent.OnOwnerWeaponHolstered // (Final|Native|Protected) // @ game+0xa87e370
	void OnCharacterMovementPreUpdate(struct UCharacterMovementComponent* CharMoveComp, float DeltaSeconds); // Function MantisRuntime.FortMantisPawnComponent.OnCharacterMovementPreUpdate // (Final|Native|Protected) // @ game+0xa87e1f0
	bool IsSpecificInputPressed(enum class EFortMantisTechniqueActivationInputType InputType); // Function MantisRuntime.FortMantisPawnComponent.IsSpecificInputPressed // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa87e6c0
	bool IsPerformingLockOn(); // Function MantisRuntime.FortMantisPawnComponent.IsPerformingLockOn // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa87e9e0
	bool HasLockOnTarget(); // Function MantisRuntime.FortMantisPawnComponent.HasLockOnTarget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa87e960
	bool HasCurrentTechniqueMetadataBeenSet(); // Function MantisRuntime.FortMantisPawnComponent.HasCurrentTechniqueMetadataBeenSet // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a17cb0
	struct AActor* GetLockOnTarget(); // Function MantisRuntime.FortMantisPawnComponent.GetLockOnTarget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa87e930
	struct FFortMantisTechniqueMetadata GetCurrentTechniqueMetadata(); // Function MantisRuntime.FortMantisPawnComponent.GetCurrentTechniqueMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa87ebf0
};

// Class MantisRuntime.FortMantisWeaponComponent
// Size: 0xe0 (Inherited: 0xa0)
struct UFortMantisWeaponComponent : UFortWeaponComponent {
	struct UFortMantisData* MantisData; // 0xa0(0x08)
	bool bAllowPrimaryFireInputsWhileHolstered; // 0xa8(0x01)
	bool bAllowSecondaryFireInputsWhileHolstered; // 0xa9(0x01)
	char pad_AA[0x2]; // 0xaa(0x02)
	struct TWeakObjectPtr<struct UFortMantisPawnComponent> MantisPawnComponent; // 0xac(0x08)
	char pad_B4[0xc]; // 0xb4(0x0c)
	struct FFortMantisReplicatedAnimInstanceInfo AnimInstanceInfo; // 0xc0(0x10)
	struct FFortMantisReplicatedAnimInstanceInfo ReplayAnimInstanceInfo; // 0xd0(0x10)

	void OnWeaponAbilitiesRemoved(struct AFortWeapon* Weapon, enum class EFortWeaponAbilityRemovalReason RemovalReason); // Function MantisRuntime.FortMantisWeaponComponent.OnWeaponAbilitiesRemoved // (Final|Native|Protected) // @ game+0xa885600
	void OnUnEquip(struct AFortWeapon* Weapon); // Function MantisRuntime.FortMantisWeaponComponent.OnUnEquip // (Final|Native|Protected) // @ game+0xa885d90
	void OnRep_ReplayAnimInstanceInfo(); // Function MantisRuntime.FortMantisWeaponComponent.OnRep_ReplayAnimInstanceInfo // (Final|Native|Protected) // @ game+0xa885580
	void OnReleaseTrigger(struct AFortWeapon* Weapon); // Function MantisRuntime.FortMantisWeaponComponent.OnReleaseTrigger // (Final|Native|Protected) // @ game+0xa885b90
	void OnReleaseSecondaryFire(struct AFortWeapon* Weapon); // Function MantisRuntime.FortMantisWeaponComponent.OnReleaseSecondaryFire // (Final|Native|Protected) // @ game+0xa8859b0
	void OnPressTrigger(struct AFortWeapon* Weapon); // Function MantisRuntime.FortMantisWeaponComponent.OnPressTrigger // (Final|Native|Protected) // @ game+0xa885c80
	void OnPressSecondaryFire(struct AFortWeapon* Weapon); // Function MantisRuntime.FortMantisWeaponComponent.OnPressSecondaryFire // (Final|Native|Protected) // @ game+0xa885aa0
	void OnEquip(struct AFortWeapon* Weapon); // Function MantisRuntime.FortMantisWeaponComponent.OnEquip // (Final|Native|Protected) // @ game+0xa885ed0
	struct FFortMantisReplicatedAnimInstanceInfo GetAnimInstanceInfo(); // Function MantisRuntime.FortMantisWeaponComponent.GetAnimInstanceInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa885fc0
};

