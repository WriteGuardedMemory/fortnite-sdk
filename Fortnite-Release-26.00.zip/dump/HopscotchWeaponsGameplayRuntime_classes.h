// Class HopscotchWeaponsGameplayRuntime.FortGameplayAbility_AppleSunSmall_Passive
// Size: 0xbf0 (Inherited: 0xb28)
struct UFortGameplayAbility_AppleSunSmall_Passive : UFortGameplayAbility {
	struct TWeakObjectPtr<struct AFortPlayerPawn> PlayerPawn; // 0xb28(0x08)
	struct TWeakObjectPtr<struct UCharacterMovementComponent> CharacterMovementComponent; // 0xb30(0x08)
	struct FScalableFloat UpdateIntervalRow; // 0xb38(0x28)
	struct UGameplayEffect* CanCrashpadGameplayEffectClass; // 0xb60(0x08)
	struct FGameplayTagContainer CanCrashpadGameplayTags; // 0xb68(0x20)
	struct FGameplayTagContainer GliderRedeployTags; // 0xb88(0x20)
	float UpdateInterval; // 0xba8(0x04)
	float MaxFallVelocity; // 0xbac(0x04)
	float CloseToGroundThreshold; // 0xbb0(0x04)
	float GroundTraceMaxDistance; // 0xbb4(0x04)
	float MaxVelocityJumpPromt; // 0xbb8(0x04)
	float DefaultMinVelocityJumpPromt; // 0xbbc(0x04)
	float SwimmingMinVelocityJumpPromt; // 0xbc0(0x04)
	float CurrentMinVelocityJumpPrompt; // 0xbc4(0x04)
	float DefaultMinTimeSinceGroundedForJumpPrompt; // 0xbc8(0x04)
	float SwimmingMinTimeSinceGroundedForJumpPrompt; // 0xbcc(0x04)
	float CurrentMinTimeSinceGroundedForJumpPrompt; // 0xbd0(0x04)
	float TraceDistanceToGround; // 0xbd4(0x04)
	float TimeSinceGrounded; // 0xbd8(0x04)
	bool bCanCrashpadByJumping; // 0xbdc(0x01)
	bool bPreviousCanCrashpad; // 0xbdd(0x01)
	bool bIsCloseToGround; // 0xbde(0x01)
	bool bIsClambering; // 0xbdf(0x01)
	bool bBlockedTag; // 0xbe0(0x01)
	bool bGliderTag; // 0xbe1(0x01)
	char pad_BE2[0xe]; // 0xbe2(0x0e)

	void UpdateIsCloseToGround(); // Function HopscotchWeaponsGameplayRuntime.FortGameplayAbility_AppleSunSmall_Passive.UpdateIsCloseToGround // (Final|Native|Protected|BlueprintCallable) // @ game+0xa97be10
	void UpdateCanCrashpad(); // Function HopscotchWeaponsGameplayRuntime.FortGameplayAbility_AppleSunSmall_Passive.UpdateCanCrashpad // (Final|Native|Protected|BlueprintCallable) // @ game+0xa97be30
	void OnPlayerMovementModeChanged(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function HopscotchWeaponsGameplayRuntime.FortGameplayAbility_AppleSunSmall_Passive.OnPlayerMovementModeChanged // (Final|Native|Private) // @ game+0xa97b6b0
};

