// Class MemoryUsageQueries.MemoryUsageQueriesConfig
// Size: 0x88 (Inherited: 0x28)
struct UMemoryUsageQueriesConfig : UObject {
	struct TArray<struct FCollectionInfo> Collections; // 0x28(0x10)
	struct TMap<struct FString, struct FString> SavingsPresets; // 0x38(0x50)
};

