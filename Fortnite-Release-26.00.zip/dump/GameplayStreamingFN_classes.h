// Class GameplayStreamingFN.FortLocalPlayerAccountHelper
// Size: 0x50 (Inherited: 0x28)
struct UFortLocalPlayerAccountHelper : UObject {
	char pad_28[0x28]; // 0x28(0x28)
};

// Class GameplayStreamingFN.FortGFNGameplayStreamingHandler
// Size: 0xb0 (Inherited: 0x78)
struct UFortGFNGameplayStreamingHandler : UGFNGameplayStreamingHandler {
	char pad_78[0x8]; // 0x78(0x08)
	struct UFortLocalPlayerAccountHelper* FortLocalPlayerAccountHelper; // 0x80(0x08)
	struct UFortOnlineAccount* FortOnlineAccount; // 0x88(0x08)
	char pad_90[0x20]; // 0x90(0x20)
};

// Class GameplayStreamingFN.FortLunaGameplayStreamingHandler
// Size: 0xa8 (Inherited: 0x78)
struct UFortLunaGameplayStreamingHandler : ULunaGameplayStreamingHandler {
	char pad_78[0x30]; // 0x78(0x30)
};

// Class GameplayStreamingFN.FortGameplayStreamingHandler
// Size: 0x28 (Inherited: 0x28)
struct UFortGameplayStreamingHandler : UInterface {
};

// Class GameplayStreamingFN.FortGameplayStreamingService
// Size: 0x38 (Inherited: 0x30)
struct UFortGameplayStreamingService : UGameplayStreamingService {
	char pad_30[0x8]; // 0x30(0x08)
};

