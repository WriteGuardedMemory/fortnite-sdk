// Enum MassEntity.EMassCommandOperationType
enum class EMassCommandOperationType : uint8 {
	None = 0,
	Create = 1,
	Add = 2,
	Remove = 3,
	ChangeComposition = 4,
	Set = 5,
	Destroy = 6,
	MAX = 7
};

// Enum MassEntity.EMassObservedOperation
enum class EMassObservedOperation : uint8 {
	Add = 0,
	Remove = 1,
	MAX = 2
};

// Enum MassEntity.EProcessorExecutionFlags
enum class EProcessorExecutionFlags : uint8 {
	None = 0,
	Standalone = 1,
	Server = 2,
	Client = 4,
	Editor = 8,
	AllNetModes = 7,
	All = 15,
	EProcessorExecutionFlags_MAX = 16
};

// Enum MassEntity.EMassProcessingPhase
enum class EMassProcessingPhase : uint8 {
	PrePhysics = 0,
	StartPhysics = 1,
	DuringPhysics = 2,
	EndPhysics = 3,
	PostPhysics = 4,
	FrameEnd = 5,
	MAX = 6
};

// Enum MassEntity.EMassFragmentAccess
enum class EMassFragmentAccess : uint8 {
	None = 0,
	ReadOnly = 1,
	ReadWrite = 2,
	MAX = 3
};

// Enum MassEntity.EMassFragmentPresence
enum class EMassFragmentPresence : uint8 {
	All = 0,
	Any = 1,
	None = 2,
	Optional = 3,
	MAX = 4
};

// ScriptStruct MassEntity.MassFragmentRequirements
// Size: 0x1e8 (Inherited: 0x00)
struct FMassFragmentRequirements {
	char pad_0[0x1e8]; // 0x00(0x1e8)
};

// ScriptStruct MassEntity.MassEntityQuery
// Size: 0x2a0 (Inherited: 0x1e8)
struct FMassEntityQuery : FMassFragmentRequirements {
	char pad_1E8[0xb8]; // 0x1e8(0xb8)
};

// ScriptStruct MassEntity.MassFragment
// Size: 0x01 (Inherited: 0x00)
struct FMassFragment {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct MassEntity.MassTag
// Size: 0x01 (Inherited: 0x00)
struct FMassTag {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct MassEntity.MassChunkFragment
// Size: 0x01 (Inherited: 0x00)
struct FMassChunkFragment {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct MassEntity.MassSharedFragment
// Size: 0x01 (Inherited: 0x00)
struct FMassSharedFragment {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct MassEntity.MassEntityHandle
// Size: 0x08 (Inherited: 0x00)
struct FMassEntityHandle {
	int32_t Index; // 0x00(0x04)
	int32_t SerialNumber; // 0x04(0x04)
};

// ScriptStruct MassEntity.MassEntityView
// Size: 0x20 (Inherited: 0x00)
struct FMassEntityView {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct MassEntity.MassObserversMap
// Size: 0x50 (Inherited: 0x00)
struct FMassObserversMap {
	struct TMap<struct UScriptStruct*, struct FMassRuntimePipeline> Container; // 0x00(0x50)
};

// ScriptStruct MassEntity.MassRuntimePipeline
// Size: 0x10 (Inherited: 0x00)
struct FMassRuntimePipeline {
	struct TArray<struct UMassProcessor*> Processors; // 0x00(0x10)
};

// ScriptStruct MassEntity.MassObserverManager
// Size: 0x1c8 (Inherited: 0x00)
struct FMassObserverManager {
	char pad_0[0x80]; // 0x00(0x80)
	struct FMassObserversMap FragmentObservers[0x2]; // 0x80(0xa0)
	struct FMassObserversMap TagObservers[0x2]; // 0x120(0xa0)
	char pad_1C0[0x8]; // 0x1c0(0x08)
};

// ScriptStruct MassEntity.MassProcessorClassCollection
// Size: 0x10 (Inherited: 0x00)
struct FMassProcessorClassCollection {
	struct TArray<struct UMassProcessor*> ClassCollection; // 0x00(0x10)
};

// ScriptStruct MassEntity.MassEntityObserverClassesMap
// Size: 0x50 (Inherited: 0x00)
struct FMassEntityObserverClassesMap {
	struct TMap<struct UScriptStruct*, struct FMassProcessorClassCollection> Container; // 0x00(0x50)
};

// ScriptStruct MassEntity.MassProcessingPhaseConfig
// Size: 0x20 (Inherited: 0x00)
struct FMassProcessingPhaseConfig {
	struct FName PhaseName; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UMassCompositeProcessor* PhaseGroupClass; // 0x08(0x08)
	struct TArray<struct UMassProcessor*> ProcessorCDOs; // 0x10(0x10)
};

// ScriptStruct MassEntity.ProcessorAuxDataBase
// Size: 0x01 (Inherited: 0x00)
struct FProcessorAuxDataBase {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct MassEntity.MassProcessingContext
// Size: 0x40 (Inherited: 0x00)
struct FMassProcessingContext {
	char pad_0[0x10]; // 0x00(0x10)
	float DeltaSeconds; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FInstancedStruct AuxData; // 0x18(0x10)
	bool bFlushCommandBuffer; // 0x28(0x01)
	char pad_29[0x17]; // 0x29(0x17)
};

// ScriptStruct MassEntity.MassProcessorExecutionOrder
// Size: 0x28 (Inherited: 0x00)
struct FMassProcessorExecutionOrder {
	struct FName ExecuteInGroup; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FName> ExecuteBefore; // 0x08(0x10)
	struct TArray<struct FName> ExecuteAfter; // 0x18(0x10)
};

// ScriptStruct MassEntity.MassSubsystemRequirements
// Size: 0x48 (Inherited: 0x00)
struct FMassSubsystemRequirements {
	char pad_0[0x48]; // 0x00(0x48)
};

