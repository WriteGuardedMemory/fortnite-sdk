// Class HoagieRuntime.FortHoagieDriverAnimInstance
// Size: 0x890 (Inherited: 0x810)
struct UFortHoagieDriverAnimInstance : UFortVehicleOccupantAnimInstance {
	struct FVector LeftHandIKPositionOffset; // 0x810(0x18)
	struct FVector RightHandIKPositionOffset; // 0x828(0x18)
	struct FRotator LeftHandIKRotationOffset; // 0x840(0x18)
	struct FRotator RightHandIKRotationOffset; // 0x858(0x18)
	enum class EFortCardinalDirection BoostCardinalDirection; // 0x870(0x01)
	char pad_871[0x3]; // 0x871(0x03)
	float NormalizedAcceleration; // 0x874(0x04)
	float VehicleRoll; // 0x878(0x04)
	float VehicleYaw; // 0x87c(0x04)
	float ForwardSpeed; // 0x880(0x04)
	bool bIsMovingAnyDirection; // 0x884(0x01)
	bool bIsMovingFastAnyDirection; // 0x885(0x01)
	bool bShouldReverse; // 0x886(0x01)
	bool bShouldGoBackToIdle; // 0x887(0x01)
	bool bTransition_Default_ReverseStart; // 0x888(0x01)
	bool bTransition_BoostLoop_Reverse; // 0x889(0x01)
	char pad_88A[0x6]; // 0x88a(0x06)
};

// Class HoagieRuntime.FortHoagieVehicleAnimInstance
// Size: 0x7f0 (Inherited: 0x600)
struct UFortHoagieVehicleAnimInstance : UFortVehicleAnimInstance {
	char pad_600[0x128]; // 0x600(0x128)
	struct FRotator EngineRotation; // 0x728(0x18)
	struct FRotator MainRotorRotation; // 0x740(0x18)
	struct FRotator TailRotorRotaton; // 0x758(0x18)
	struct FRotator BoosterFanRotation; // 0x770(0x18)
	enum class EFortCardinalDirection BoostCardinalDirection; // 0x788(0x01)
	char pad_789[0x1b]; // 0x789(0x1b)
	float EngineRotationInterpSpeed; // 0x7a4(0x04)
	float EngineRotationDuringBoostInterpSpeed; // 0x7a8(0x04)
	float EngineFlipSpeedThreshold; // 0x7ac(0x04)
	float BoostDirectionDeadzone; // 0x7b0(0x04)
	float EngineFlipDeadzone; // 0x7b4(0x04)
	float DriverRoll; // 0x7b8(0x04)
	float DriverYaw; // 0x7bc(0x04)
	float VerticalSpeed; // 0x7c0(0x04)
	float FwdSpeed; // 0x7c4(0x04)
	float LocalBoostDirection; // 0x7c8(0x04)
	float YawBlendSpaceInput; // 0x7cc(0x04)
	float NormalizedAcceleration; // 0x7d0(0x04)
	char pad_7D4[0x1]; // 0x7d4(0x01)
	bool bShouldHideBlades; // 0x7d5(0x01)
	bool bIsBoostOnCD; // 0x7d6(0x01)
	bool bIsBoostReady; // 0x7d7(0x01)
	bool bIsMovingForward; // 0x7d8(0x01)
	bool bIsReversing; // 0x7d9(0x01)
	bool bIsMovingAnyDirection; // 0x7da(0x01)
	bool bIsBoosting; // 0x7db(0x01)
	bool bShouldReverse; // 0x7dc(0x01)
	bool bShouldGoBackToIdle; // 0x7dd(0x01)
	bool bShouldApplyBoostAdditive; // 0x7de(0x01)
	bool bIsEngineShuttingOff; // 0x7df(0x01)
	bool bTransition_Default_ReverseStart; // 0x7e0(0x01)
	bool bTransition_BoostLoop_Reverse; // 0x7e1(0x01)
	char pad_7E2[0xe]; // 0x7e2(0x0e)
};

// Class HoagieRuntime.FortCameraMode_Hoagie
// Size: 0x1bc0 (Inherited: 0x1b50)
struct UFortCameraMode_Hoagie : UFortCameraMode_AthenaVehicle {
	float CurrentRollMultiplier; // 0x1b50(0x04)
	float CurrentPitchMultiplier; // 0x1b54(0x04)
	struct FVector LastOrigin; // 0x1b58(0x18)
	struct FVector CurrentInterpSpeed; // 0x1b70(0x18)
	struct FVector BoostInterpSpeed; // 0x1b88(0x18)
	float BaseRollMultiplier; // 0x1ba0(0x04)
	float BasePitchMultiplier; // 0x1ba4(0x04)
	float BoostRollMultiplier; // 0x1ba8(0x04)
	float BoostPitchMultiplier; // 0x1bac(0x04)
	float BoostRollDampFactor; // 0x1bb0(0x04)
	float BoostRollRecoveryDampFactor; // 0x1bb4(0x04)
	float BoostRecoveryInterpSpeed; // 0x1bb8(0x04)
	char pad_1BBC[0x4]; // 0x1bbc(0x04)
};

// Class HoagieRuntime.FortHoagieAudioController
// Size: 0x2f8 (Inherited: 0x290)
struct AFortHoagieAudioController : AActor {
	bool bHighQualityOverride; // 0x290(0x01)
	bool bLocalPlayerInHoagie; // 0x291(0x01)
	bool bCriticalDamageNative; // 0x292(0x01)
	bool bRotorHitNative; // 0x293(0x01)
	bool bIsRotorWashActiveNative; // 0x294(0x01)
	char pad_295[0x3]; // 0x295(0x03)
	float RotorWashRelativeZOffset; // 0x298(0x04)
	struct TWeakObjectPtr<struct AFortHoagieVehicle> Vehicle; // 0x29c(0x08)
	char pad_2A4[0x4]; // 0x2a4(0x04)
	struct UFortLayeredAudioComponent* EngineAudio; // 0x2a8(0x08)
	struct UFortLayeredAudioComponent* RotorAudio; // 0x2b0(0x08)
	char pad_2B8[0x40]; // 0x2b8(0x40)

	void Update(); // Function HoagieRuntime.FortHoagieAudioController.Update // (Final|Native|Public|BlueprintCallable) // @ game+0xa82a100
	void CacheHoagieVehicle(struct AFortHoagieVehicle* InVehicle); // Function HoagieRuntime.FortHoagieAudioController.CacheHoagieVehicle // (Final|Native|Public|BlueprintCallable) // @ game+0xa829fe0
	void CacheAudioComponents(struct UFortLayeredAudioComponent* InEngine, struct UFortLayeredAudioComponent* InRotor); // Function HoagieRuntime.FortHoagieAudioController.CacheAudioComponents // (Final|Native|Public|BlueprintCallable) // @ game+0xa829e50
};

// Class HoagieRuntime.FortHoagieVehicle
// Size: 0x2120 (Inherited: 0x1b00)
struct AFortHoagieVehicle : AFortAthenaSKVehicle {
	struct FName PassengerCollision; // 0x1b00(0x04)
	float CameraBoomDistance; // 0x1b04(0x04)
	float CameraBoomHeight; // 0x1b08(0x04)
	char pad_1B0C[0x4]; // 0x1b0c(0x04)
	struct FMulticastInlineDelegate OnBoostStateChanged; // 0x1b10(0x10)
	struct FMulticastInlineDelegate OnAltimeterTraceUpdated; // 0x1b20(0x10)
	struct FMulticastInlineDelegate OnCrashingStateEntered; // 0x1b30(0x10)
	bool bEngineAudioDisabled; // 0x1b40(0x01)
	char pad_1B41[0x3]; // 0x1b41(0x03)
	float LiftRumbleTimer; // 0x1b44(0x04)
	bool bLiftUp; // 0x1b48(0x01)
	char pad_1B49[0x7]; // 0x1b49(0x07)
	uint64_t LiftForceFeedbackHandle; // 0x1b50(0x08)
	uint64_t PassiveForceFeedbackHandle; // 0x1b58(0x08)
	float Theta_Native; // 0x1b60(0x04)
	float WashAltAlpha_Native; // 0x1b64(0x04)
	float RotorWashTickTimer; // 0x1b68(0x04)
	char pad_1B6C[0x4]; // 0x1b6c(0x04)
	struct TArray<struct FVector> RotorTraceArray; // 0x1b70(0x10)
	struct TArray<enum class EObjectTypeQuery> RotorWashObjectsTypes; // 0x1b80(0x10)
	struct UFortHoagieVehicleConfigs* FortHoagieVehicleConfigs; // 0x1b90(0x08)
	struct UCurveFloat* RumbleIntensity; // 0x1b98(0x08)
	struct FFortHeliFlightModel FlightModel; // 0x1ba0(0x1e8)
	bool bClearPitchInput; // 0x1d88(0x01)
	char pad_1D89[0x3]; // 0x1d89(0x03)
	float BoostTimeLeft; // 0x1d8c(0x04)
	float BoostBrakingTimeLeft; // 0x1d90(0x04)
	float BoostCooldown; // 0x1d94(0x04)
	float ShutdownTimer; // 0x1d98(0x04)
	float FoliageDestructionTimer; // 0x1d9c(0x04)
	float CrashingScrapingTimer; // 0x1da0(0x04)
	float CrashingNotMovingTimer; // 0x1da4(0x04)
	bool bCanSleep; // 0x1da8(0x01)
	bool bHasAppliedCrashDamage; // 0x1da9(0x01)
	bool bOrientedForLanding; // 0x1daa(0x01)
	bool bForceNegativeLift; // 0x1dab(0x01)
	float AltimeterTraceTimer; // 0x1dac(0x04)
	float LastRotorImpulseTime; // 0x1db0(0x04)
	float CriticalExplodeTimer; // 0x1db4(0x04)
	bool bCriticalExplosionPlayed; // 0x1db8(0x01)
	char pad_1DB9[0x3]; // 0x1db9(0x03)
	float TimeWhileCritical; // 0x1dbc(0x04)
	float TimeWhileLanding; // 0x1dc0(0x04)
	float LiftFromOverrideButton; // 0x1dc4(0x04)
	struct FVector BoostDirection; // 0x1dc8(0x18)
	struct FVector LastRotorSweepDirection; // 0x1de0(0x18)
	struct FHitResult AltimeterTraceResult; // 0x1df8(0xe0)
	int32_t HoagieStateRep; // 0x1ed8(0x04)
	enum class EHoagieState CurrentHoagieState; // 0x1edc(0x04)
	float CurrentRotorSpeed; // 0x1ee0(0x04)
	float CurrentRotorAngle; // 0x1ee4(0x04)
	float RotorImpactTraceAngle; // 0x1ee8(0x04)
	struct FVehicleGamepadLiftInputs LiftInputs; // 0x1eec(0x08)
	char pad_1EF4[0x4]; // 0x1ef4(0x04)
	struct TArray<struct FRotorHit> RotorHits; // 0x1ef8(0x10)
	struct TArray<struct FCachedSeatCollision> CachedSeatCollision; // 0x1f08(0x10)
	struct FVector RotorHitLinearImpulse; // 0x1f18(0x18)
	struct FVector RotorHitAngularImpulse; // 0x1f30(0x18)
	struct UNiagaraComponent* HoagieIdleFX_Native; // 0x1f48(0x08)
	struct UNiagaraComponent* DamageFX_Native; // 0x1f50(0x08)
	struct UNiagaraComponent* RotorWashFX_Native; // 0x1f58(0x08)
	struct UFortHoagieVehicleAnimInstance* HoagieAnimBP_Native; // 0x1f60(0x08)
	struct FName AltimeterTraceSocketName; // 0x1f68(0x04)
	struct FName RotorDamageTraceSocketName; // 0x1f6c(0x04)
	struct FName MainRotorCritSocketName; // 0x1f70(0x04)
	struct FName TailRotorCritSocketName; // 0x1f74(0x04)
	struct UAnimMontage* SeatTransition_ToDriver; // 0x1f78(0x08)
	struct UAnimMontage* SeatTransition_ToPassenger; // 0x1f80(0x08)
	struct FName RotorTraceProfile; // 0x1f88(0x04)
	struct FName FoliageOverlapsBoxTag; // 0x1f8c(0x04)
	struct FReplicatedHeliControlState ControlState; // 0x1f90(0x30)
	float CurrentViewDistanceScale; // 0x1fc0(0x04)
	float CurrentHLODDistanceOverrideScale; // 0x1fc4(0x04)
	float CurrentHLODMaxDrawDistanceScale; // 0x1fc8(0x04)
	char pad_1FCC[0xc]; // 0x1fcc(0x0c)
	struct FHoagieDeathEffectInfo CachedDeathEffectInfo; // 0x1fd8(0x148)

	void UpdateHoagieAnimBP(); // Function HoagieRuntime.FortHoagieVehicle.UpdateHoagieAnimBP // (Native|Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x74aa620
	void UpdateDamageStateNative(float Damage); // Function HoagieRuntime.FortHoagieVehicle.UpdateDamageStateNative // (Final|Native|Protected|BlueprintCallable) // @ game+0xa82d410
	void ShowCooldownCue(struct AFortPlayerPawn* Pawn, float Duration); // Function HoagieRuntime.FortHoagieVehicle.ShowCooldownCue // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetTailRotorRotation(float Degrees); // Function HoagieRuntime.FortHoagieVehicle.SetTailRotorRotation // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetRotorWashActive(bool bActive); // Function HoagieRuntime.FortHoagieVehicle.SetRotorWashActive // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetMainRotorRotation(float Degrees); // Function HoagieRuntime.FortHoagieVehicle.SetMainRotorRotation // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void ServerUpdateControlState(struct FReplicatedHeliControlState InControlState); // Function HoagieRuntime.FortHoagieVehicle.ServerUpdateControlState // (Final|Net|Native|Event|Private|NetServer) // @ game+0xa82cf90
	void OnTickRotors(float RotorAngleDegrees); // Function HoagieRuntime.FortHoagieVehicle.OnTickRotors // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnStartupEnd(); // Function HoagieRuntime.FortHoagieVehicle.OnStartupEnd // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnStartupBegin(); // Function HoagieRuntime.FortHoagieVehicle.OnStartupBegin // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRotorsStop(); // Function HoagieRuntime.FortHoagieVehicle.OnRotorsStop // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRotorDamagePlayer(struct FHitResult& Impact); // Function HoagieRuntime.FortHoagieVehicle.OnRotorDamagePlayer // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnRotorDamageDealtOuter(struct FHitResult& Impact); // Function HoagieRuntime.FortHoagieVehicle.OnRotorDamageDealtOuter // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnRotorDamageDealtInner(struct FHitResult& Impact); // Function HoagieRuntime.FortHoagieVehicle.OnRotorDamageDealtInner // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnRotorDamageDealt(struct FHitResult& Impact, bool bInner); // Function HoagieRuntime.FortHoagieVehicle.OnRotorDamageDealt // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnRep_HoagieState(); // Function HoagieRuntime.FortHoagieVehicle.OnRep_HoagieState // (Final|Native|Protected) // @ game+0xa82d230
	void OnRep_ControlState(); // Function HoagieRuntime.FortHoagieVehicle.OnRep_ControlState // (Final|Native|Private) // @ game+0x3982d70
	void OnRefueledFromEmpty(); // Function HoagieRuntime.FortHoagieVehicle.OnRefueledFromEmpty // (Final|Native|Protected) // @ game+0xa82d1c0
	void OnImpactWhileCritical(); // Function HoagieRuntime.FortHoagieVehicle.OnImpactWhileCritical // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnImpactOtherHoagie(struct FVector& HitLocation, struct FVector& NormalImpulse); // Function HoagieRuntime.FortHoagieVehicle.OnImpactOtherHoagie // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnCritRotor(float Damage, struct FVector& ImpactLocation, struct AController* DamageInstigator, struct AActor* DamageCauser, bool bMainRotor); // Function HoagieRuntime.FortHoagieVehicle.OnCritRotor // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnBoostStarted(); // Function HoagieRuntime.FortHoagieVehicle.OnBoostStarted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnBoostReady(); // Function HoagieRuntime.FortHoagieVehicle.OnBoostReady // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnBoostFinished(); // Function HoagieRuntime.FortHoagieVehicle.OnBoostFinished // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnBoostFailed(); // Function HoagieRuntime.FortHoagieVehicle.OnBoostFailed // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void MulticastRotorImpulse(struct FHitResult RotorHit); // Function HoagieRuntime.FortHoagieVehicle.MulticastRotorImpulse // (Net|NetReliableNative|Event|NetMulticast|Protected|BlueprintCallable) // @ game+0xa82d2e0
	bool IsStartingUp(); // Function HoagieRuntime.FortHoagieVehicle.IsStartingUp // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d840
	bool IsShuttingDown(); // Function HoagieRuntime.FortHoagieVehicle.IsShuttingDown // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d810
	bool IsScrapingBottom(); // Function HoagieRuntime.FortHoagieVehicle.IsScrapingBottom // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d500
	void HoagieOnDisabledChanged(bool bDisabled); // Function HoagieRuntime.FortHoagieVehicle.HoagieOnDisabledChanged // (Final|Native|Protected) // @ game+0xa82d0a0
	float GetVerticalSpeedKmh(); // Function HoagieRuntime.FortHoagieVehicle.GetVerticalSpeedKmh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d750
	struct FVector GetThrustDirection(bool bWorldSpace); // Function HoagieRuntime.FortHoagieVehicle.GetThrustDirection // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d5d0
	float GetStrafeAlpha(); // Function HoagieRuntime.FortHoagieVehicle.GetStrafeAlpha // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d950
	float GetSteerAlpha(); // Function HoagieRuntime.FortHoagieVehicle.GetSteerAlpha // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d910
	float GetShutdownTimeLeft(); // Function HoagieRuntime.FortHoagieVehicle.GetShutdownTimeLeft // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d7f0
	float GetRotorSpeedPercent(); // Function HoagieRuntime.FortHoagieVehicle.GetRotorSpeedPercent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d550
	float GetRotorSpeed(); // Function HoagieRuntime.FortHoagieVehicle.GetRotorSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d5b0
	struct FVector GetRotorCenterPosition(); // Function HoagieRuntime.FortHoagieVehicle.GetRotorCenterPosition // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d6e0
	float GetRotorAngleDegrees(); // Function HoagieRuntime.FortHoagieVehicle.GetRotorAngleDegrees // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d530
	float GetMaxBoostCooldown(); // Function HoagieRuntime.FortHoagieVehicle.GetMaxBoostCooldown // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d890
	float GetMaxAltitude(); // Function HoagieRuntime.FortHoagieVehicle.GetMaxAltitude // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82da00
	float GetLiftAlpha(); // Function HoagieRuntime.FortHoagieVehicle.GetLiftAlpha // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d990
	bool GetIsEngineOn(); // Function HoagieRuntime.FortHoagieVehicle.GetIsEngineOn // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d720
	float GetForwardAlpha(); // Function HoagieRuntime.FortHoagieVehicle.GetForwardAlpha // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d950
	float GetDistanceToGround(); // Function HoagieRuntime.FortHoagieVehicle.GetDistanceToGround // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d7d0
	float GetBoostTimeLeft(); // Function HoagieRuntime.FortHoagieVehicle.GetBoostTimeLeft // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d8f0
	float GetBoostDuration(); // Function HoagieRuntime.FortHoagieVehicle.GetBoostDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d8c0
	struct FVector GetBoostDirection(); // Function HoagieRuntime.FortHoagieVehicle.GetBoostDirection // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d9d0
	float GetBoostCooldown(); // Function HoagieRuntime.FortHoagieVehicle.GetBoostCooldown // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d870
	float GetAltitude(); // Function HoagieRuntime.FortHoagieVehicle.GetAltitude // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa82d7a0
};

// Class HoagieRuntime.FortHoagieVehicleConfigs
// Size: 0xae8 (Inherited: 0x8b0)
struct UFortHoagieVehicleConfigs : UFortPhysicsVehicleConfigs {
	float StrafeForce; // 0x8b0(0x04)
	float StrafeForceMin; // 0x8b4(0x04)
	float MaxStrafeSpeedKmh; // 0x8b8(0x04)
	float StrafeTooFastBrakeForce; // 0x8bc(0x04)
	float LandedBrakeForce; // 0x8c0(0x04)
	float LiftForce; // 0x8c4(0x04)
	float MaxLiftSpeedKmh; // 0x8c8(0x04)
	float LiftTooFastBrakeForce; // 0x8cc(0x04)
	float LateralDragCoefficient; // 0x8d0(0x04)
	float LateralDragCoefficient2; // 0x8d4(0x04)
	float LiftDragCoefficient; // 0x8d8(0x04)
	float LiftDragCoefficient2; // 0x8dc(0x04)
	float MaxPitchForCameraYaw; // 0x8e0(0x04)
	float MaxCameraYawAngle; // 0x8e4(0x04)
	float CameraYawStiff; // 0x8e8(0x04)
	float CameraYawDamp; // 0x8ec(0x04)
	float CameraYawStrength; // 0x8f0(0x04)
	float UprightStiff; // 0x8f4(0x04)
	float UprightDamp; // 0x8f8(0x04)
	bool bUseVehiclePivotForCameraPitch; // 0x8fc(0x01)
	char pad_8FD[0x3]; // 0x8fd(0x03)
	float ThrustTorqueAnglePercent; // 0x900(0x04)
	float BoostThrustTorqueAnglePercent; // 0x904(0x04)
	float ThrustTorqueStiff; // 0x908(0x04)
	float ThrustTorqueDamp; // 0x90c(0x04)
	float ThrustTorqueMaxAccel; // 0x910(0x04)
	float ThrustTorque; // 0x914(0x04)
	float YawTorque; // 0x918(0x04)
	float YawTorqueDampingSpeed; // 0x91c(0x04)
	float BoostForce; // 0x920(0x04)
	float BoostMaxSpeedKmh; // 0x924(0x04)
	float BoostDuration; // 0x928(0x04)
	float BoostCooldown; // 0x92c(0x04)
	float BoostTorqueStiff; // 0x930(0x04)
	float BoostTorqueDamp; // 0x934(0x04)
	float AfterBoostBrakingForce; // 0x938(0x04)
	float AfterBoostBrakingDuration; // 0x93c(0x04)
	float AfterBoostBrakingMinSpeed; // 0x940(0x04)
	float PitchAngleRequiredForFullThrust; // 0x944(0x04)
	float DistanceToGroundForLanding; // 0x948(0x04)
	float StartupDelay; // 0x94c(0x04)
	float LandingSequenceDelay; // 0x950(0x04)
	float RotorsRadius; // 0x954(0x04)
	float RotorsRadiusInner; // 0x958(0x04)
	float NoDriverBrakeForce; // 0x95c(0x04)
	float TimeBetweenRotorDamageTicks; // 0x960(0x04)
	float AutoLandingForce; // 0x964(0x04)
	float RotorDamageBoxSweepLength; // 0x968(0x04)
	float CriticalStateLiftForce; // 0x96c(0x04)
	float IdleRotationMultiplier; // 0x970(0x04)
	float LiftPitchDegrees; // 0x974(0x04)
	float MinAltitudeForIdleNoise; // 0x978(0x04)
	float DefaultLinearDamp; // 0x97c(0x04)
	float DefaultAngularDamp; // 0x980(0x04)
	float LandingLinearDamp; // 0x984(0x04)
	float LandingAngularDamp; // 0x988(0x04)
	float LandingLiftAlpha; // 0x98c(0x04)
	float CriticalStateThrustMultiplier; // 0x990(0x04)
	float BodyUpDotThresholdForLanding; // 0x994(0x04)
	int32_t CriticalHealthThreshold; // 0x998(0x04)
	float DamagePerImpulseWhileCritical; // 0x99c(0x04)
	float RotorImpulseLinear; // 0x9a0(0x04)
	float RotorImpulseAngular; // 0x9a4(0x04)
	float RotorImpulseCooldown; // 0x9a8(0x04)
	float StartupLift; // 0x9ac(0x04)
	float StartupLiftTime; // 0x9b0(0x04)
	float MaxAltitude; // 0x9b4(0x04)
	float AltitudeForSpinning; // 0x9b8(0x04)
	float RotorMaxSpeed; // 0x9bc(0x04)
	float RotorAccel; // 0x9c0(0x04)
	float RotorDecel; // 0x9c4(0x04)
	float ExplodeRotorDecel; // 0x9c8(0x04)
	float MinRotorSpeedForSkippingStartup; // 0x9cc(0x04)
	float RotorSpeedForStartupLift; // 0x9d0(0x04)
	float CriticalLiftForceDecay; // 0x9d4(0x04)
	float CriticalYawTorqueMin; // 0x9d8(0x04)
	float CriticalYawTorqueMax; // 0x9dc(0x04)
	float CriticalYawTorqueRampDuration; // 0x9e0(0x04)
	float RotorTraceRotationSpeed; // 0x9e4(0x04)
	float RotorTraceBoxSize; // 0x9e8(0x04)
	float RotorTraceBoxHeight; // 0x9ec(0x04)
	float MaxCriticalFallForce; // 0x9f0(0x04)
	float BoostFOV; // 0x9f4(0x04)
	float GentleCrashTimeToExplode; // 0x9f8(0x04)
	float CriticalTimeForGentleCrash; // 0x9fc(0x04)
	float AutoLandingYawTorque; // 0xa00(0x04)
	float MinHeightForAutoLandingYawTorque; // 0xa04(0x04)
	float MinSpeedForScrapingBottom; // 0xa08(0x04)
	float FallDamageHeightBuffer; // 0xa0c(0x04)
	float TimeBetweenRotorPlayerDamage; // 0xa10(0x04)
	float RotorMoveSpeedRequiredToUpdateTraceDirSqr; // 0xa14(0x04)
	float FoliageTraceRate; // 0xa18(0x04)
	float RotorWashTicksPerFrame; // 0xa1c(0x04)
	float CriticalHitRadius; // 0xa20(0x04)
	float AngleNormalUpForLockMovement; // 0xa24(0x04)
	float MaxAutoLandingTime; // 0xa28(0x04)
	float SpeedThresholdForCrashed; // 0xa2c(0x04)
	float CritMultiplier; // 0xa30(0x04)
	float AltitudeForSprings; // 0xa34(0x04)
	float MaxCrashingTime; // 0xa38(0x04)
	float MaxCrashingScrapingTime; // 0xa3c(0x04)
	float MaxCrashingTimeSpentNotMoving; // 0xa40(0x04)
	float LandscapeRotorImpulseMag; // 0xa44(0x04)
	float HealthThresholdForLandscapeRotorImpulse; // 0xa48(0x04)
	float MaxHeightBuffer; // 0xa4c(0x04)
	bool bImpulseOnOuterRotorHitLandscape; // 0xa50(0x01)
	bool bSkipRotorImpulses; // 0xa51(0x01)
	bool bEnableCVarScaling; // 0xa52(0x01)
	char pad_A53[0x1]; // 0xa53(0x01)
	float CVarScalingInterp; // 0xa54(0x04)
	struct FVector FoliageTraceBoxSize; // 0xa58(0x18)
	struct FVector WaterBoxSize; // 0xa70(0x18)
	struct FVector WaterBoxOffset; // 0xa88(0x18)
	struct FVector RotorOffsetFromActorLocationOnServer; // 0xaa0(0x18)
	bool bSkipContactRotations; // 0xab8(0x01)
	char pad_AB9[0x7]; // 0xab9(0x07)
	struct FScalableFloat MaxAutoLandHeightWhenOutOfFuel; // 0xac0(0x28)
};

