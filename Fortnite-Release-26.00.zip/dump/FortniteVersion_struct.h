// ScriptStruct FortniteVersion.FortReleaseVersion
// Size: 0x04 (Inherited: 0x00)
struct FFortReleaseVersion {
	struct FName VersionName; // 0x00(0x04)
};

