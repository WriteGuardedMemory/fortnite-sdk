// ScriptStruct HeistBasesGameplayRuntime.FortHeistDisplayCaseItemDataTableRow
// Size: 0x10 (Inherited: 0x08)
struct FFortHeistDisplayCaseItemDataTableRow : FTableRowBase {
	struct UFortWorldItemDefinition* WorldItemDefinition; // 0x08(0x08)
};

