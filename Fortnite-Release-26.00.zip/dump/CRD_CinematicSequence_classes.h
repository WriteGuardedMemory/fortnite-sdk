// Class CRD_CinematicSequence.CinematicSequenceDeviceBase
// Size: 0xc00 (Inherited: 0xbb8)
struct ACinematicSequenceDeviceBase : ABuildingProp {
	char pad_BB8[0x20]; // 0xbb8(0x20)
	struct ULevelSequence* Sequence; // 0xbd8(0x08)
	struct ALevelSequenceActor* LevelSequenceActor; // 0xbe0(0x08)
	struct AFortPlayerController* InstigatingController; // 0xbe8(0x08)
	char InstigatingTeam; // 0xbf0(0x01)
	char pad_BF1[0x3]; // 0xbf1(0x03)
	char bLoopPlayback : 1; // 0xbf4(0x01)
	char bRestoreState : 1; // 0xbf4(0x01)
	char bAutoPlay : 1; // 0xbf4(0x01)
	char pad_BF4_3 : 5; // 0xbf4(0x01)
	char pad_BF5[0x3]; // 0xbf5(0x03)
	enum class EFortMinigameState AutoPlayMinigameState; // 0xbf8(0x01)
	enum class ECinematicSequenceVisibility Visibility; // 0xbf9(0x01)
	bool bLevelSequenceActorAlwaysRelevant; // 0xbfa(0x01)
	char pad_BFB[0x1]; // 0xbfb(0x01)
	float PlayRate; // 0xbfc(0x04)

	void Stop(); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Stop // (Final|Native|Public|BlueprintCallable) // @ game+0xaa91c60
	void SetSequence(struct ULevelSequence* Sequence); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.SetSequence // (Final|Native|Public|BlueprintCallable) // @ game+0xaa90e20
	void SetPlayRate(float PlayRate); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.SetPlayRate // (Final|Native|Public|BlueprintCallable) // @ game+0xaa91220
	void SetPlaybackTime(float Time); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.SetPlaybackTime // (Final|Native|Public|BlueprintCallable) // @ game+0xaa91490
	void SetPlaybackFrame(int32_t Frame); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.SetPlaybackFrame // (Final|Native|Public|BlueprintCallable) // @ game+0xaa91880
	void Play(); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Play // (Final|Native|Public|BlueprintCallable) // @ game+0xaa91f80
	void Pause(); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.Pause // (Final|Native|Public|BlueprintCallable) // @ game+0xaa91df0
	void HandleSequencePlayerCreated(struct ULevelSequencePlayer* Player); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.HandleSequencePlayerCreated // (Native|Event|Protected|BlueprintEvent) // @ game+0x74c9f30
	void GoToEndAndStop(); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.GoToEndAndStop // (Final|Native|Public|BlueprintCallable) // @ game+0xaa91ad0
	struct UMovieSceneSequencePlayer* GetSequencePlayer(); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.GetSequencePlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa90dd0
	float GetPlayRate(); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.GetPlayRate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa91080
	float GetPlaybackTime(); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.GetPlaybackTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa91460
	int32_t GetPlaybackFrame(); // Function CRD_CinematicSequence.CinematicSequenceDeviceBase.GetPlaybackFrame // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa916f0
};

