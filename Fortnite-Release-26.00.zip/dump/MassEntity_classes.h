// Class MassEntity.MassModuleSettings
// Size: 0x28 (Inherited: 0x28)
struct UMassModuleSettings : UObject {
};

// Class MassEntity.MassEntitySettings
// Size: 0x110 (Inherited: 0x28)
struct UMassEntitySettings : UMassModuleSettings {
	struct FString DumpDependencyGraphFileName; // 0x28(0x10)
	struct FMassProcessingPhaseConfig ProcessingPhasesConfig[0x6]; // 0x38(0xc0)
	struct TArray<struct UMassProcessor*> ProcessorCDOs; // 0xf8(0x10)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class MassEntity.MassEntitySubsystem
// Size: 0x40 (Inherited: 0x30)
struct UMassEntitySubsystem : UWorldSubsystem {
	char pad_30[0x10]; // 0x30(0x10)
};

// Class MassEntity.MassProcessor
// Size: 0xb8 (Inherited: 0x28)
struct UMassProcessor : UObject {
	int32_t ExecutionFlags; // 0x28(0x04)
	enum class EMassProcessingPhase ProcessingPhase; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	struct FMassProcessorExecutionOrder ExecutionOrder; // 0x30(0x28)
	bool bAutoRegisterWithProcessingPhases; // 0x58(0x01)
	char pad_59[0x2]; // 0x59(0x02)
	bool bRequiresGameThreadExecution; // 0x5b(0x01)
	char pad_5C[0x5c]; // 0x5c(0x5c)
};

// Class MassEntity.MassObserverProcessor
// Size: 0xd0 (Inherited: 0xb8)
struct UMassObserverProcessor : UMassProcessor {
	bool bAutoRegisterWithObserverRegistry; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
	struct UScriptStruct* ObservedType; // 0xc0(0x08)
	char pad_C8[0x8]; // 0xc8(0x08)
};

// Class MassEntity.MassObserverRegistry
// Size: 0x168 (Inherited: 0x28)
struct UMassObserverRegistry : UObject {
	struct FMassEntityObserverClassesMap FragmentObservers[0x2]; // 0x28(0xa0)
	struct FMassEntityObserverClassesMap TagObservers[0x2]; // 0xc8(0xa0)
};

// Class MassEntity.MassCompositeProcessor
// Size: 0xf0 (Inherited: 0xb8)
struct UMassCompositeProcessor : UMassProcessor {
	struct FMassRuntimePipeline ChildPipeline; // 0xb8(0x10)
	struct FName GroupName; // 0xc8(0x04)
	char pad_CC[0x24]; // 0xcc(0x24)
};

// Class MassEntity.MassSettings
// Size: 0x80 (Inherited: 0x30)
struct UMassSettings : UDeveloperSettings {
	struct TMap<struct FName, struct UMassModuleSettings*> ModuleSettings; // 0x30(0x50)
};

