// Class CRD_ClassSelectorUI.ClassSelectorLoadoutContainer
// Size: 0x318 (Inherited: 0x2d0)
struct UClassSelectorLoadoutContainer : UCommonUserWidget {
	struct UWrapBox* WrapBox; // 0x2d0(0x08)
	struct UAthenaItemElementWidgetBase* EntryWidgetClass; // 0x2d8(0x08)
	struct TArray<struct UAthenaItemElementWidgetBase*> EntryWidgets; // 0x2e0(0x10)
	struct UFortItemDefinition* PreviewItemDef; // 0x2f0(0x08)
	int32_t NumPreviewEntries; // 0x2f8(0x04)
	char pad_2FC[0x1c]; // 0x2fc(0x1c)
};

// Class CRD_ClassSelectorUI.ClassSelectorTabButtons
// Size: 0x388 (Inherited: 0x2d0)
struct UClassSelectorTabButtons : UCommonUserWidget {
	struct UCommonActionWidget* LeftActionWidget; // 0x2d0(0x08)
	struct UCommonActionWidget* RightActionWidget; // 0x2d8(0x08)
	struct UScrollBox* TabButtonsScrollBox; // 0x2e0(0x08)
	struct UCommonButtonBase* LeftButton; // 0x2e8(0x08)
	struct UCommonButtonBase* RightButton; // 0x2f0(0x08)
	struct FDataTableRowHandle LeftInputAction; // 0x2f8(0x10)
	char pad_308[0x8]; // 0x308(0x08)
	struct FDataTableRowHandle RightInputAction; // 0x310(0x10)
	char pad_320[0x8]; // 0x320(0x08)
	struct TArray<struct UClassSelectorTeamTile*> TabButtons; // 0x328(0x10)
	struct UClassSelectorTeamTile* TabButtonClass; // 0x338(0x08)
	struct FMargin TabButtonPadding; // 0x340(0x10)
	char pad_350[0x8]; // 0x350(0x08)
	struct TArray<struct FText> DesignerPreviewTabNames; // 0x358(0x10)
	float ButtonScrollAmount; // 0x368(0x04)
	char pad_36C[0x1c]; // 0x36c(0x1c)
};

// Class CRD_ClassSelectorUI.ClassSelectorTeamInfoWidget
// Size: 0x2c0 (Inherited: 0x2a8)
struct UClassSelectorTeamInfoWidget : UUserWidget {
	struct UCommonTextBlock* TeamName; // 0x2a8(0x08)
	struct UCommonTextBlock* TeamCountText; // 0x2b0(0x08)
	struct UCommonTextBlock* TeamDescription; // 0x2b8(0x08)
};

// Class CRD_ClassSelectorUI.CreativeClassSelectorButton
// Size: 0x14b0 (Inherited: 0x1470)
struct UCreativeClassSelectorButton : UCommonButtonBase {
	struct UCommonTextBlock* ButtonTextBlock; // 0x1470(0x08)
	struct UCommonActionWidget* ActionWidget; // 0x1478(0x08)
	struct FText ButtonText; // 0x1480(0x18)
	struct FDataTableRowHandle buttonInputAction; // 0x1498(0x10)
	bool bAutoCapitalize; // 0x14a8(0x01)
	char pad_14A9[0x7]; // 0x14a9(0x07)

	void SetButtonText(struct FText& InText); // Function CRD_ClassSelectorUI.CreativeClassSelectorButton.SetButtonText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaa9a530
};

// Class CRD_ClassSelectorUI.ClassSelectorTeamTile
// Size: 0x1560 (Inherited: 0x14b0)
struct UClassSelectorTeamTile : UCreativeClassSelectorButton {
	char pad_14B0[0x90]; // 0x14b0(0x90)
	struct UTextBlock* PlayerCount; // 0x1540(0x08)
	struct UCommonLazyImage* TeamIconImage; // 0x1548(0x08)
	char pad_1550[0x10]; // 0x1550(0x10)

	void OnTeamSet(struct FMinigameTeam& NewTeamData); // Function CRD_ClassSelectorUI.ClassSelectorTeamTile.OnTeamSet // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnTeamIconSet(struct FCreativeIconOption& NewTeamIcon); // Function CRD_ClassSelectorUI.ClassSelectorTeamTile.OnTeamIconSet // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnTeamColorIndexSet(int32_t TeamColorIndex); // Function CRD_ClassSelectorUI.ClassSelectorTeamTile.OnTeamColorIndexSet // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayerCountSet(int32_t NewPlayerCount); // Function CRD_ClassSelectorUI.ClassSelectorTeamTile.OnPlayerCountSet // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class CRD_ClassSelectorUI.ClassSelectorTeamTiles
// Size: 0x318 (Inherited: 0x2d0)
struct UClassSelectorTeamTiles : UCommonUserWidget {
	char pad_2D0[0x8]; // 0x2d0(0x08)
	struct TArray<struct UClassSelectorTeamTile*> TeamTiles; // 0x2d8(0x10)
	struct UUniformGridPanel* RootPanel; // 0x2e8(0x08)
	struct UClassSelectorTeamTile* EntryClass; // 0x2f0(0x08)
	int32_t DesignerPreviewEntries; // 0x2f8(0x04)
	char pad_2FC[0x1c]; // 0x2fc(0x1c)
};

// Class CRD_ClassSelectorUI.CreativeClassItemInfo
// Size: 0x80 (Inherited: 0x28)
struct UCreativeClassItemInfo : UObject {
	struct FMinigameClassSlot ClassSlot; // 0x28(0x50)
	char pad_78[0x8]; // 0x78(0x08)
};

// Class CRD_ClassSelectorUI.CreativeClassEntry
// Size: 0x14c0 (Inherited: 0x14b0)
struct UCreativeClassEntry : UCreativeClassSelectorButton {
	char pad_14B0[0x8]; // 0x14b0(0x08)
	struct UCreativeClassItemInfo* ItemInfo; // 0x14b8(0x08)

	void OnClassEntryDataSet(bool bIsCurrentClass, bool bIsPendingClass); // Function CRD_ClassSelectorUI.CreativeClassEntry.OnClassEntryDataSet // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnBrowsingLoadout(bool bBrowsingLoadout); // Function CRD_ClassSelectorUI.CreativeClassEntry.OnBrowsingLoadout // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class CRD_ClassSelectorUI.CreativeClassSelector
// Size: 0x520 (Inherited: 0x3e8)
struct UCreativeClassSelector : UCommonActivatableWidget {
	char pad_3E8[0x10]; // 0x3e8(0x10)
	struct UClassSelectorTabButtons* TabButtons_TeamSelection; // 0x3f8(0x08)
	struct UCommonListView* ListView_Classes; // 0x400(0x08)
	struct TArray<struct UCreativeClassItemInfo*> ClassItemInfos; // 0x408(0x10)
	struct UScrollBox* LoadoutScrollBox; // 0x418(0x08)
	struct UClassSelectorLoadoutContainer* LoadoutContainer_Inventory; // 0x420(0x08)
	struct UClassSelectorLoadoutContainer* LoadoutContainer_Resources; // 0x428(0x08)
	struct UCommonButtonBase* Button_SelectLoadout; // 0x430(0x08)
	struct UCommonButtonBase* Button_RandomClass; // 0x438(0x08)
	struct UWidgetSwitcher* Switcher_Descriptions; // 0x440(0x08)
	struct UPanelWidget* ClassAndTeamDescriptionContainer; // 0x448(0x08)
	struct UPanelWidget* ItemDescriptionContainer; // 0x450(0x08)
	struct UPanelWidget* InventoryPanel; // 0x458(0x08)
	struct UPanelWidget* ResourcesPanel; // 0x460(0x08)
	struct UCommonTextBlock* ItemRarity; // 0x468(0x08)
	struct UCommonTextBlock* ItemName; // 0x470(0x08)
	struct UCommonTextBlock* ItemDescription; // 0x478(0x08)
	struct UPanelWidget* TeamDescriptionContainer; // 0x480(0x08)
	struct UClassSelectorTeamInfoWidget* TeamInfoWidget_FullView; // 0x488(0x08)
	struct UClassSelectorTeamInfoWidget* TeamInfoWidget_TeamsOnly; // 0x490(0x08)
	struct UWidgetSwitcher* DisplaySwitcher; // 0x498(0x08)
	struct UPanelWidget* ClassAndTeamSelectionContainer; // 0x4a0(0x08)
	struct UPanelWidget* OnlyTeamSelectionContainer; // 0x4a8(0x08)
	struct UPanelWidget* InvalidDataContainer; // 0x4b0(0x08)
	struct UClassSelectorTeamTiles* TeamTiles; // 0x4b8(0x08)
	struct UCreativeClassSelectorButton* TeamSelectionTabClass; // 0x4c0(0x08)
	bool bIsModalVersion; // 0x4c8(0x01)
	bool bEnableModalTimeLimit; // 0x4c9(0x01)
	char pad_4CA[0x2]; // 0x4ca(0x02)
	int32_t ModalTimeLimitInSeconds; // 0x4cc(0x04)
	char pad_4D0[0x10]; // 0x4d0(0x10)
	enum class EClassSelectorDisplayMode DisplayMode; // 0x4e0(0x01)
	bool bDeferRespawn; // 0x4e1(0x01)
	char pad_4E2[0x6]; // 0x4e2(0x06)
	struct FDataTableRowHandle ReturnToClassSelectionInputAction; // 0x4e8(0x10)
	float LoadoutScrollPadding; // 0x4f8(0x04)
	char pad_4FC[0x1c]; // 0x4fc(0x1c)
	struct UCreativeClassItemInfo* SelectedClassItemInfo; // 0x518(0x08)

	void OnTimerCountdown(int32_t RemainingTime); // Function CRD_ClassSelectorUI.CreativeClassSelector.OnTimerCountdown // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnLoadoutCommitted(struct FText& NewClassName, struct FText& NewTeamName, bool bNewLoadout); // Function CRD_ClassSelectorUI.CreativeClassSelector.OnLoadoutCommitted // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnClassSelectorUIPopulated(bool bHasValidData); // Function CRD_ClassSelectorUI.CreativeClassSelector.OnClassSelectorUIPopulated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnClassSelectionChanged(struct FText& NewClassName, struct FText& NewClassDescription); // Function CRD_ClassSelectorUI.CreativeClassSelector.OnClassSelectionChanged // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void HandleMinigameStateChanged(struct AFortMinigame* Minigame, enum class EFortMinigameState MinigameState); // Function CRD_ClassSelectorUI.CreativeClassSelector.HandleMinigameStateChanged // (Final|Native|Protected) // @ game+0xaa97a80
	struct UWidget* GetFirstLoadoutItem(); // Function CRD_ClassSelectorUI.CreativeClassSelector.GetFirstLoadoutItem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xaa97c20
};

// Class CRD_ClassSelectorUI.CreativeClassSelectorMapTab
// Size: 0x448 (Inherited: 0x3e8)
struct UCreativeClassSelectorMapTab : UCommonActivatableWidget {
	char pad_3E8[0x10]; // 0x3e8(0x10)
	struct FAthenaMapScreenContainerTabInfo MapTabInfo; // 0x3f8(0x48)
	struct UCreativeClassSelector* CreativeClassSelector; // 0x440(0x08)

	void SetTabName(struct FText& TabName); // Function CRD_ClassSelectorUI.CreativeClassSelectorMapTab.SetTabName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaa9af50
};

// Class CRD_ClassSelectorUI.Mutator_ClassSelectorUI
// Size: 0x338 (Inherited: 0x338)
struct AMutator_ClassSelectorUI : AFortAthenaMutator {
};

