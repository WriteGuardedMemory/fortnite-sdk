// Class EventScreenBase.FortEventScreenData
// Size: 0x670 (Inherited: 0x30)
struct UFortEventScreenData : UDataAsset {
	struct FString EventCMSId; // 0x30(0x10)
	struct FString AccountResourceName; // 0x40(0x10)
	struct FString LevelOfferId; // 0x50(0x10)
	struct FString PremiumTrackOfferId; // 0x60(0x10)
	struct UFortTokenType* PremiumTrackPurchasedToken; // 0x70(0x08)
	struct FGameplayTag VaultWorldTag; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FVaultWorldBackgroundData PreviewScreenBackgroundData; // 0x80(0x58)
	struct TSoftObjectPtr<UFortChallengeBundleItemDefinition> QuestBundle; // 0xd8(0x20)
	struct TSoftObjectPtr<UFortItemDefinition> SpecialRewardItem; // 0xf8(0x20)
	struct TSoftObjectPtr<UFortItemDefinition> SpecialPremiumRewardItem; // 0x118(0x20)
	struct TArray<struct FEventItemOverride> ItemOverrides; // 0x138(0x10)
	struct FEventScreenTrackData FreeTrackData; // 0x148(0x20)
	struct FEventScreenTrackData PremiumTrackData; // 0x168(0x20)
	struct FGameplayTag QuestCategoryTag; // 0x188(0x04)
	char pad_18C[0x4]; // 0x18c(0x04)
	struct TArray<struct URichTextBlockDecorator*> RichTextDecorators; // 0x190(0x10)
	struct UMaterialInterface* EventBackgroundMaterial; // 0x1a0(0x08)
	struct UMaterialInterface* ProgressBarMaterial; // 0x1a8(0x08)
	struct FSlateBrush CurrencyBrush; // 0x1b0(0xc0)
	struct FSlateBrush CompletionBannerBrush; // 0x270(0xc0)
	struct FSlateBrush GlowForeground; // 0x330(0xc0)
	struct FSlateBrush GlowBackground; // 0x3f0(0xc0)
	struct FLinearColor EventBackgroundColor1; // 0x4b0(0x10)
	struct FLinearColor EventBackgroundColor2; // 0x4c0(0x10)
	struct FLinearColor RewardBackgroundColor1; // 0x4d0(0x10)
	struct FLinearColor RewardBackgroundColor2; // 0x4e0(0x10)
	struct FLinearColor RewardBackgroundColor3; // 0x4f0(0x10)
	struct FLinearColor AccentColor; // 0x500(0x10)
	struct TMap<struct FName, struct FLinearColor> RewardTileBackgroundColors; // 0x510(0x50)
	struct FText TimeRemainingFormat; // 0x560(0x18)
	struct FText CurrencyFormat; // 0x578(0x18)
	struct USoundBase* DefaultHoveredSound; // 0x590(0x08)
	struct USoundBase* DefaultPressedSound; // 0x598(0x08)
	struct USoundBase* BuyPressedSound; // 0x5a0(0x08)
	struct USoundBase* BuyHoldStartedSound; // 0x5a8(0x08)
	struct USoundBase* BuyHoldCompletedSound; // 0x5b0(0x08)
	struct USoundBase* BuyHoldAbortedSound; // 0x5b8(0x08)
	struct USoundBase* BackPressedSound; // 0x5c0(0x08)
	struct USoundBase* AddPressedSound; // 0x5c8(0x08)
	struct USoundBase* SubtractPressedSound; // 0x5d0(0x08)
	struct USoundBase* ProgressStartedSound; // 0x5d8(0x08)
	struct USoundBase* ProgressEndedSound; // 0x5e0(0x08)
	struct USoundBase* ProgressInterruptedSound; // 0x5e8(0x08)
	float RewardPreviewZoomLevel; // 0x5f0(0x04)
	bool bUseWidgetCameraFraming; // 0x5f4(0x01)
	char pad_5F5[0x3]; // 0x5f5(0x03)
	struct TSoftClassPtr<UObject> MoreInfoModalClass; // 0x5f8(0x20)
	struct TSoftClassPtr<UObject> PurchaseLevelsModalClass; // 0x618(0x20)
	struct TSoftClassPtr<UObject> PurchasePremiumTrackModalClass; // 0x638(0x20)
	struct TArray<struct FString> CalendarEvents; // 0x658(0x10)
	char pad_668[0x8]; // 0x668(0x08)
};

// Class EventScreenBase.FortEventModalBase
// Size: 0x3f0 (Inherited: 0x3e8)
struct UFortEventModalBase : UCommonActivatableWidget {
	char pad_3E8[0x8]; // 0x3e8(0x08)

	void CloseModal(); // Function EventScreenBase.FortEventModalBase.CloseModal // (Final|Native|Public|BlueprintCallable) // @ game+0x5306810
};

// Class EventScreenBase.FortEventMoreInfoGroup
// Size: 0x2a8 (Inherited: 0x2a8)
struct UFortEventMoreInfoGroup : UUserWidget {

	void OnSetGroupText(struct FText& Header, struct FText& Body); // Function EventScreenBase.FortEventMoreInfoGroup.OnSetGroupText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnIconLoaded(struct UTexture2D* Icon); // Function EventScreenBase.FortEventMoreInfoGroup.OnIconLoaded // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEventScreenDataSet(struct UFortEventScreenData* InEventScreenData); // Function EventScreenBase.FortEventMoreInfoGroup.OnEventScreenDataSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventMoreInfoModal
// Size: 0x418 (Inherited: 0x3f0)
struct UFortEventMoreInfoModal : UFortEventModalBase {
	struct UDynamicEntryBox* DynamicEntryBox_Groups; // 0x3f0(0x08)
	struct UCommonButtonBase* Button_Back; // 0x3f8(0x08)
	struct UCommonButtonBase* Button_CloseMobile; // 0x400(0x08)
	char pad_408[0x8]; // 0x408(0x08)
	struct UScrollBox* SB_Vertical; // 0x410(0x08)

	void SetModalText(struct FText& Header, struct FText& SubHeader, struct FText& Legal); // Function EventScreenBase.FortEventMoreInfoModal.SetModalText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnModalBackout(); // Function EventScreenBase.FortEventMoreInfoModal.OnModalBackout // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEventScreenDataSet(struct UFortEventScreenData* InEventScreenData); // Function EventScreenBase.FortEventMoreInfoModal.OnEventScreenDataSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	struct UFortEventScreenData* GetEventScreenData(); // Function EventScreenBase.FortEventMoreInfoModal.GetEventScreenData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb26a0
};

// Class EventScreenBase.FortEventPurchaseLevelsModal
// Size: 0x460 (Inherited: 0x3f0)
struct UFortEventPurchaseLevelsModal : UFortEventModalBase {
	struct UCommonButtonBase* Button_Addition; // 0x3f0(0x08)
	struct UCommonButtonBase* Button_Subtraction; // 0x3f8(0x08)
	struct UCommonButtonBase* Button_Purchase; // 0x400(0x08)
	struct UCommonButtonBase* Button_GetVBucks; // 0x408(0x08)
	struct UCommonButtonBase* Button_Back; // 0x410(0x08)
	struct UCommonButtonBase* Button_CloseMobile; // 0x418(0x08)
	struct UEventScreenListView* ListView_RewardPreview; // 0x420(0x08)
	int32_t CurrentResourceValue; // 0x428(0x04)
	int32_t MaxResourceValue; // 0x42c(0x04)
	int32_t CurrentVBucks; // 0x430(0x04)
	int32_t OfferResourceQuantity; // 0x434(0x04)
	bool bAnimateListViewFromEmpty; // 0x438(0x01)
	char pad_439[0x27]; // 0x439(0x27)

	void OnPurchaseAmountChanged(int32_t TotalPrice, int32_t LevelQuantity, int32_t PurchaseQuantity, int32_t ResourceQuantity); // Function EventScreenBase.FortEventPurchaseLevelsModal.OnPurchaseAmountChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEventScreenDataSet(struct UFortEventScreenData* InEventScreenData); // Function EventScreenBase.FortEventPurchaseLevelsModal.OnEventScreenDataSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnCMSTextApplied(struct FText& LegalText); // Function EventScreenBase.FortEventPurchaseLevelsModal.OnCMSTextApplied // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnAmountChangeButtonClicked(); // Function EventScreenBase.FortEventPurchaseLevelsModal.OnAmountChangeButtonClicked // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandlePurchaseComplete(bool bSuccess, struct TArray<struct FPurchasedItemInfo>& PurchasedItems, struct FString InOfferId); // Function EventScreenBase.FortEventPurchaseLevelsModal.HandlePurchaseComplete // (Final|Native|Private|HasOutParms) // @ game+0xabb3270
	struct UFortEventScreenData* GetEventScreenData(); // Function EventScreenBase.FortEventPurchaseLevelsModal.GetEventScreenData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb3510
};

// Class EventScreenBase.FortPurchasePremiumTrackBody
// Size: 0x2a8 (Inherited: 0x2a8)
struct UFortPurchasePremiumTrackBody : UUserWidget {

	void OnPopulate(int32_t BodyIndex, struct FText& BodyText); // Function EventScreenBase.FortPurchasePremiumTrackBody.OnPopulate // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventPurchasePremiumTrackModal
// Size: 0x460 (Inherited: 0x3f0)
struct UFortEventPurchasePremiumTrackModal : UFortEventModalBase {
	struct UDynamicEntryBox* DynamicEntryBox_Body; // 0x3f0(0x08)
	struct UScrollBox* ScrollBox_Body; // 0x3f8(0x08)
	struct UFortCTAButton* Button_Purchase; // 0x400(0x08)
	struct UCommonButtonBase* Button_GetVBucks; // 0x408(0x08)
	struct UCommonButtonBase* Button_Back; // 0x410(0x08)
	struct UCommonButtonBase* Button_CloseMobile; // 0x418(0x08)
	struct UCommonButtonBase* Button_PreviewReward; // 0x420(0x08)
	int32_t CurrentVBucks; // 0x428(0x04)
	char pad_42C[0x34]; // 0x42c(0x34)

	void OnPriceSet(int32_t Price); // Function EventScreenBase.FortEventPurchasePremiumTrackModal.OnPriceSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEventScreenDataSet(struct UFortEventScreenData* InEventScreenData); // Function EventScreenBase.FortEventPurchasePremiumTrackModal.OnEventScreenDataSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnCMSTextApplied(struct FText& HeaderText, struct FText& LegalText); // Function EventScreenBase.FortEventPurchasePremiumTrackModal.OnCMSTextApplied // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void HandlePurchaseComplete(bool bSuccess, struct TArray<struct FPurchasedItemInfo>& PurchasedItems, struct FString InOfferId); // Function EventScreenBase.FortEventPurchasePremiumTrackModal.HandlePurchaseComplete // (Final|Native|Private|HasOutParms) // @ game+0xabb3270
	struct UFortEventScreenData* GetEventScreenData(); // Function EventScreenBase.FortEventPurchasePremiumTrackModal.GetEventScreenData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb4740
};

// Class EventScreenBase.FortEventListViewWidgetBase
// Size: 0x2b0 (Inherited: 0x2a8)
struct UFortEventListViewWidgetBase : UUserWidget {
	char pad_2A8[0x8]; // 0x2a8(0x08)
};

// Class EventScreenBase.FortEventRewardTracksWidget
// Size: 0x300 (Inherited: 0x2b0)
struct UFortEventRewardTracksWidget : UFortEventListViewWidgetBase {
	struct UDynamicEntryBox* DynamicEntryBox_RewardTracks; // 0x2b0(0x08)
	bool bPreviewMode; // 0x2b8(0x01)
	char pad_2B9[0x47]; // 0x2b9(0x47)

	void BPSetProgressPercent(float Percent); // Function EventScreenBase.FortEventRewardTracksWidget.BPSetProgressPercent // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BPSetAllRewardsCollected(bool bAllCollected); // Function EventScreenBase.FortEventRewardTracksWidget.BPSetAllRewardsCollected // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BPOnSetRewardItem(int32_t RequiredProgress, int32_t RemainingProgress, float RewardProgressPercent, float PreviewProgressPercent, float OverallProgressPercent, bool bInPreviewMode); // Function EventScreenBase.FortEventRewardTracksWidget.BPOnSetRewardItem // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BPOnEventScreenDataSet(struct UFortEventScreenData* InEventScreenData); // Function EventScreenBase.FortEventRewardTracksWidget.BPOnEventScreenDataSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventSpacerWidget
// Size: 0x2b0 (Inherited: 0x2b0)
struct UFortEventSpacerWidget : UFortEventListViewWidgetBase {
};

// Class EventScreenBase.FortEventRewardWidget
// Size: 0x338 (Inherited: 0x2a8)
struct UFortEventRewardWidget : UUserWidget {
	char pad_2A8[0x8]; // 0x2a8(0x08)
	struct UCommonButtonBase* Button_RewardPreview; // 0x2b0(0x08)
	struct UFortCosmeticItemCard* UserWidget_ItemCard; // 0x2b8(0x08)
	bool bIsTrackOwned; // 0x2c0(0x01)
	bool bPreviewMode; // 0x2c1(0x01)
	bool bInPreviewSelectedState; // 0x2c2(0x01)
	bool bInPremiumUpgradeState; // 0x2c3(0x01)
	char pad_2C4[0x74]; // 0x2c4(0x74)

	void SetTrackData(struct FEventScreenTrackData& TrackData, bool bIsOwned); // Function EventScreenBase.FortEventRewardWidget.SetTrackData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void SetProgressPercent(float Percent); // Function EventScreenBase.FortEventRewardWidget.SetProgressPercent // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void SetIsBannerItem(bool bIsBanner); // Function EventScreenBase.FortEventRewardWidget.SetIsBannerItem // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetInSelectedState(bool bSelected); // Function EventScreenBase.FortEventRewardWidget.SetInSelectedState // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void SetInPreviewSelectedState(bool bSelected); // Function EventScreenBase.FortEventRewardWidget.SetInPreviewSelectedState // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetInPreviewedState(bool bPreviewed); // Function EventScreenBase.FortEventRewardWidget.SetInPreviewedState // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void SetInPremiumUpgradeState(bool bHighlighted); // Function EventScreenBase.FortEventRewardWidget.SetInPremiumUpgradeState // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetDoubleWidth(bool bDoubleWidth); // Function EventScreenBase.FortEventRewardWidget.SetDoubleWidth // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void SetCustomItemIcon(struct UTexture2D* CustomItemIcon); // Function EventScreenBase.FortEventRewardWidget.SetCustomItemIcon // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetAllRewardsCollected(bool bAllCollected); // Function EventScreenBase.FortEventRewardWidget.SetAllRewardsCollected // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnSetRewardItem(int32_t RequiredProgress, int32_t RemainingProgress, float RewardProgressPercent, float PreviewProgressPercent, float OverallProgressPercent, bool bInPreviewMode); // Function EventScreenBase.FortEventRewardWidget.OnSetRewardItem // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRewardWidgetReset(); // Function EventScreenBase.FortEventRewardWidget.OnRewardWidgetReset // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnInputMethodChanged(enum class ECommonInputType NewInputType); // Function EventScreenBase.FortEventRewardWidget.OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnEventScreenDataSet(struct UFortEventScreenData* InEventScreenData); // Function EventScreenBase.FortEventRewardWidget.OnEventScreenDataSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	struct UFortEventScreenData* GetEventScreenData(); // Function EventScreenBase.FortEventRewardWidget.GetEventScreenData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb74f0
};

// Class EventScreenBase.FortEventScreenBase
// Size: 0xb48 (Inherited: 0x708)
struct UFortEventScreenBase : UFortItemPreviewScreen {
	char pad_708[0x8]; // 0x708(0x08)
	struct TArray<struct UNamedSlot*> LayoutTemplateSlots; // 0x710(0x10)
	struct UFortLazyImage* LazyImage_KeyArt; // 0x720(0x08)
	struct UCommonButtonBase* Button_ViewQuests; // 0x728(0x08)
	struct UCommonButtonBase* Button_MoreInfo; // 0x730(0x08)
	struct UCommonButtonBase* Button_PurchaseLevels; // 0x738(0x08)
	struct UCommonButtonBase* Button_Preview; // 0x740(0x08)
	struct UCommonButtonBase* Button_ShowInItemShop; // 0x748(0x08)
	struct UCommonButtonBase* Button_Previous; // 0x750(0x08)
	struct UCommonButtonBase* Button_Next; // 0x758(0x08)
	struct UFortEventTrackerModule_CustomText* CustomText_InspectItem; // 0x760(0x08)
	struct UPanelWidget* Panel_LoadError; // 0x768(0x08)
	struct UCommonButtonBase* Button_Close; // 0x770(0x08)
	struct UCommonButtonBase* Button_MobileClose; // 0x778(0x08)
	struct UCommonTextBlock* Text_ItemDescription; // 0x780(0x08)
	struct UCommonTextBlock* Text_ItemName; // 0x788(0x08)
	struct UCommonTextBlock* Text_SetDetails; // 0x790(0x08)
	struct UAthenaRewardItemTypeRarityTag* ItemRewardTag; // 0x798(0x08)
	struct UFortEventScreenData* EventScreenData; // 0x7a0(0x08)
	enum class EEventScreenRewardPreviewType ActiveRewardPreviewType; // 0x7a8(0x01)
	char pad_7A9[0x7]; // 0x7a9(0x07)
	struct UFortChallengeBundleItemDefinition* LoadedQuestBundle; // 0x7b0(0x08)
	struct AFortItemPreviewWorld* CachedVaultWorld; // 0x7b8(0x08)
	char pad_7C0[0x10]; // 0x7c0(0x10)
	float TimeBetweenVariantsRestart; // 0x7d0(0x04)
	float TimeBetweenVariants; // 0x7d4(0x04)
	struct TArray<struct FFortCosmeticVariantPreview> CachedVariantPreviews; // 0x7d8(0x10)
	char pad_7E8[0x360]; // 0x7e8(0x360)

	void UpdateVariantCounter(int32_t CurrentVariantIndex, int32_t TotalNumVariants); // Function EventScreenBase.FortEventScreenBase.UpdateVariantCounter // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetRewardTrackLegal(struct FText& LegalText); // Function EventScreenBase.FortEventScreenBase.SetRewardTrackLegal // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void SetItemShopOfferInfoVisibility(bool bIsVisible); // Function EventScreenBase.FortEventScreenBase.SetItemShopOfferInfoVisibility // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetItemShopCallout(struct FText& ItemShopCalloutText); // Function EventScreenBase.FortEventScreenBase.SetItemShopCallout // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void RegisterLayoutSlots(); // Function EventScreenBase.FortEventScreenBase.RegisterLayoutSlots // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnScreenViewChanged(enum class EEventScreenView PrevScreenView, enum class EEventScreenView NewScreenView); // Function EventScreenBase.FortEventScreenBase.OnScreenViewChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRewardTrackReady(); // Function EventScreenBase.FortEventScreenBase.OnRewardTrackReady // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnRewardPreviewItemChanged(struct UFortAccountItemDefinition* Item, bool bFreeTrack); // Function EventScreenBase.FortEventScreenBase.OnRewardPreviewItemChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnFirstViewAfterCompletion(); // Function EventScreenBase.FortEventScreenBase.OnFirstViewAfterCompletion // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnCalendarEventStarted(struct FString EventName); // Function EventScreenBase.FortEventScreenBase.OnCalendarEventStarted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnCalendarEventEnded(struct FString EventName); // Function EventScreenBase.FortEventScreenBase.OnCalendarEventEnded // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool IsCalendarEventActive(struct FString EventName); // Function EventScreenBase.FortEventScreenBase.IsCalendarEventActive // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb94f0
	bool HasPurchasedPremiumTrack(); // Function EventScreenBase.FortEventScreenBase.HasPurchasedPremiumTrack // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb9620
	bool HasAllRewardsCollected(); // Function EventScreenBase.FortEventScreenBase.HasAllRewardsCollected // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb9650
	struct UWidget* HandleUpsellPromptNavigateUpEvent(enum class EUINavigation InNavigation); // Function EventScreenBase.FortEventScreenBase.HandleUpsellPromptNavigateUpEvent // (Final|Native|Private) // @ game+0xabb8cb0
	void HandleToggleFullscreenMap(bool bVisible); // Function EventScreenBase.FortEventScreenBase.HandleToggleFullscreenMap // (Final|Native|Private) // @ game+0xabb9300
	struct UWidget* HandleRewardListNavigateUpEvent(enum class EUINavigation InNavigation); // Function EventScreenBase.FortEventScreenBase.HandleRewardListNavigateUpEvent // (Final|Native|Private) // @ game+0xabb8ec0
	struct UWidget* HandleRewardListNavigateRightEvent(enum class EUINavigation InNavigation); // Function EventScreenBase.FortEventScreenBase.HandleRewardListNavigateRightEvent // (Final|Native|Private) // @ game+0xabb8da0
	void HandleItemShown(struct UFortAccountItemDefinition* AccountItemDef); // Function EventScreenBase.FortEventScreenBase.HandleItemShown // (Final|Native|Private) // @ game+0xabb8fb0
	void HandleGiftBoxClosed(); // Function EventScreenBase.FortEventScreenBase.HandleGiftBoxClosed // (Final|Native|Private) // @ game+0xabb92e0
	void HandleActiveSeasonDataChanged(struct TArray<struct FString>& ActiveEventFlags); // Function EventScreenBase.FortEventScreenBase.HandleActiveSeasonDataChanged // (Final|Native|Private|HasOutParms) // @ game+0xabb9180
	struct UMaterialInstanceDynamic* GetVaultWorldFloorMID(); // Function EventScreenBase.FortEventScreenBase.GetVaultWorldFloorMID // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb9470
	struct UMaterialInstanceDynamic* GetVaultWorldBackgroundMID(); // Function EventScreenBase.FortEventScreenBase.GetVaultWorldBackgroundMID // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb94b0
	struct UFortEventModalBase* GetActiveModal(); // Function EventScreenBase.FortEventScreenBase.GetActiveModal // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabb93f0
};

// Class EventScreenBase.EventScreenListView
// Size: 0x470 (Inherited: 0x290)
struct UEventScreenListView : UListViewBase {
	char pad_290[0xe8]; // 0x290(0xe8)
	struct FMulticastInlineDelegate OnProgressBarAnimationStartedEvent; // 0x378(0x10)
	struct FMulticastInlineDelegate OnProgressBarAnimationCompletedEvent; // 0x388(0x10)
	struct FMulticastInlineDelegate OnProgressBarAnimationInterruptedEvent; // 0x398(0x10)
	struct FMulticastInlineDelegate OnResourcePreviewOffsetAnimationEvent; // 0x3a8(0x10)
	char pad_3B8[0x20]; // 0x3b8(0x20)
	struct UFortEventRewardTracksWidget* RewardTrackWidgetClass; // 0x3d8(0x08)
	struct UFortEventSpacerWidget* SpacerWidgetClass; // 0x3e0(0x08)
	float EntrySpacing; // 0x3e8(0x04)
	bool bCenterSelection; // 0x3ec(0x01)
	char pad_3ED[0x3]; // 0x3ed(0x03)
	float MaxItemsInView; // 0x3f0(0x04)
	bool bPreviewMode; // 0x3f4(0x01)
	char pad_3F5[0x3]; // 0x3f5(0x03)
	struct UCurveFloat* ProgressAnimationCurve; // 0x3f8(0x08)
	bool bCanAnimateOnceComplete; // 0x400(0x01)
	char pad_401[0x6f]; // 0x401(0x6f)

	void SetNativeTickAllowed(bool bAllowed); // Function EventScreenBase.EventScreenListView.SetNativeTickAllowed // (Final|Native|Public|BlueprintCallable) // @ game+0xabc7fa0
	struct UFortEventScreenData* GetEventScreenData(); // Function EventScreenBase.EventScreenListView.GetEventScreenData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabc7f70
};

// Class EventScreenBase.FortEventTokenCollectionWidget
// Size: 0x308 (Inherited: 0x2a8)
struct UFortEventTokenCollectionWidget : UUserWidget {
	struct UCommonLazyImage* LazyImage_GhostIcon; // 0x2a8(0x08)
	struct UCommonLazyImage* LazyImage_CompletedIcon; // 0x2b0(0x08)
	struct UImage* Image_Glow; // 0x2b8(0x08)
	struct TSoftObjectPtr<UTexture2D> FallbackBrush; // 0x2c0(0x20)
	struct TSoftObjectPtr<UFortTokenType> TokenDefinition; // 0x2e0(0x20)
	char pad_300[0x8]; // 0x300(0x08)

	void OnRefreshIcon(bool IsCollected, bool bIsFirstViewAfterCollection); // Function EventScreenBase.FortEventTokenCollectionWidget.OnRefreshIcon // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventTrackerModule
// Size: 0x2b0 (Inherited: 0x2a8)
struct UFortEventTrackerModule : UUserWidget {
	char pad_2A8[0x8]; // 0x2a8(0x08)

	void OnModuleInitialized(struct UFortEventScreenData* InEventScreenData); // Function EventScreenBase.FortEventTrackerModule.OnModuleInitialized // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	struct UFortEventScreenData* GetEventScreenData(); // Function EventScreenBase.FortEventTrackerModule.GetEventScreenData // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabcb500
};

// Class EventScreenBase.FortEventTrackerModule_EventDetails
// Size: 0x2b0 (Inherited: 0x2b0)
struct UFortEventTrackerModule_EventDetails : UFortEventTrackerModule {

	void UpdateEventTimeRemaining(struct FText& OutEventTimeRemaining); // Function EventScreenBase.FortEventTrackerModule_EventDetails.UpdateEventTimeRemaining // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnPopulateEventDetailsText(struct FText& OutEventName, struct FText& OutEventDescription); // Function EventScreenBase.FortEventTrackerModule_EventDetails.OnPopulateEventDetailsText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventTrackerModule_Header
// Size: 0x2b0 (Inherited: 0x2b0)
struct UFortEventTrackerModule_Header : UFortEventTrackerModule {

	void OnPopulateEventResourceStarterHeader(struct FText& Header); // Function EventScreenBase.FortEventTrackerModule_Header.OnPopulateEventResourceStarterHeader // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnPopulateEventResourceHeader(struct FText& Header, int32_t ResourceValue); // Function EventScreenBase.FortEventTrackerModule_Header.OnPopulateEventResourceHeader // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventTrackerModule_RewardDetails
// Size: 0x2b8 (Inherited: 0x2b0)
struct UFortEventTrackerModule_RewardDetails : UFortEventTrackerModule {
	char pad_2B0[0x8]; // 0x2b0(0x08)

	void OnPopulateNextRewardDetails(struct TArray<struct FText>& RewardNames, int32_t ResourceNeeded); // Function EventScreenBase.FortEventTrackerModule_RewardDetails.OnPopulateNextRewardDetails // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnPopulateCompletedReward(struct TArray<struct FText>& RewardNames); // Function EventScreenBase.FortEventTrackerModule_RewardDetails.OnPopulateCompletedReward // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	bool IsPremiumTrackOwned(); // Function EventScreenBase.FortEventTrackerModule_RewardDetails.IsPremiumTrackOwned // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x9cec130
};

// Class EventScreenBase.FortEventTrackerModule_RewardRemaining
// Size: 0x2d0 (Inherited: 0x2b0)
struct UFortEventTrackerModule_RewardRemaining : UFortEventTrackerModule {
	struct UCommonButtonBase* Button_PurchasePremium; // 0x2b0(0x08)
	char pad_2B8[0x18]; // 0x2b8(0x18)

	void OnPopulateRemaining(int32_t ResourceNeeded, int32_t TotalResourceRequired, bool bRequiresPremiumTrackPurchase); // Function EventScreenBase.FortEventTrackerModule_RewardRemaining.OnPopulateRemaining // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventTrackerModule_ProgressiveRewards
// Size: 0x2b8 (Inherited: 0x2b0)
struct UFortEventTrackerModule_ProgressiveRewards : UFortEventTrackerModule {
	struct UEventScreenListView* ListView_Rewards; // 0x2b0(0x08)

	void OnPopulateCompletionMessage(bool bIsComplete, struct FText& CompletionText); // Function EventScreenBase.FortEventTrackerModule_ProgressiveRewards.OnPopulateCompletionMessage // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventTrackerModule_Collection
// Size: 0x2b0 (Inherited: 0x2b0)
struct UFortEventTrackerModule_Collection : UFortEventTrackerModule {

	void OnGatherTokenCollectionWidgets(struct TArray<struct UFortEventTokenCollectionWidget*>& OutCollectionWidgets); // Function EventScreenBase.FortEventTrackerModule_Collection.OnGatherTokenCollectionWidgets // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventTrackerModule_Banner
// Size: 0x2b8 (Inherited: 0x2b0)
struct UFortEventTrackerModule_Banner : UFortEventTrackerModule {
	struct UFortLazyImage* LazyImage_BannerArt; // 0x2b0(0x08)

	void OnPopulateHeaderCTAText(struct FText& HeaderCTAText); // Function EventScreenBase.FortEventTrackerModule_Banner.OnPopulateHeaderCTAText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnPopulateBannerText(struct FText& BannerText); // Function EventScreenBase.FortEventTrackerModule_Banner.OnPopulateBannerText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnCTACompleted(bool bIsComplete); // Function EventScreenBase.FortEventTrackerModule_Banner.OnCTACompleted // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class EventScreenBase.FortEventTrackerModule_PremiumUpsell
// Size: 0x320 (Inherited: 0x2b0)
struct UFortEventTrackerModule_PremiumUpsell : UFortEventTrackerModule {
	struct UFortCTAButton* Button_Prompt; // 0x2b0(0x08)
	struct FText PromptTextUnowned; // 0x2b8(0x18)
	struct FText PromptTextOwned; // 0x2d0(0x18)
	char pad_2E8[0x38]; // 0x2e8(0x38)

	void OnPopulateText(struct FText& HeaderText, struct FText& BodyText); // Function EventScreenBase.FortEventTrackerModule_PremiumUpsell.OnPopulateText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnIconLoaded(struct UTexture* LoadedTexture); // Function EventScreenBase.FortEventTrackerModule_PremiumUpsell.OnIconLoaded // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool IsPremiumTrackOwned(); // Function EventScreenBase.FortEventTrackerModule_PremiumUpsell.IsPremiumTrackOwned // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xabcc010
};

// Class EventScreenBase.FortEventTrackerModule_CustomText
// Size: 0x2b0 (Inherited: 0x2b0)
struct UFortEventTrackerModule_CustomText : UFortEventTrackerModule {

	void OnPopulateText(struct FText& CustomText); // Function EventScreenBase.FortEventTrackerModule_CustomText.OnPopulateText // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

