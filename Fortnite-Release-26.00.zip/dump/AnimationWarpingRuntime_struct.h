// Enum AnimationWarpingRuntime.EFootPlacementLockType
enum class EFootPlacementLockType : uint8 {
	Unlocked = 0,
	PivotAroundBall = 1,
	PivotAroundAnkle = 2,
	LockRotation = 3,
	EFootPlacementLockType_MAX = 4
};

// Enum AnimationWarpingRuntime.EPelvisHeightMode
enum class EPelvisHeightMode : uint8 {
	AllLegs = 0,
	AllPlantedFeet = 1,
	FrontPlantedFeetUphill_FrontFeetDownhill = 2,
	EPelvisHeightMode_MAX = 3
};

// Enum AnimationWarpingRuntime.EActorMovementCompensationMode
enum class EActorMovementCompensationMode : uint8 {
	ComponentSpace = 0,
	WorldSpace = 1,
	SuddenMotionOnly = 2,
	EActorMovementCompensationMode_MAX = 3
};

// Enum AnimationWarpingRuntime.EOffsetRootBoneMode
enum class EOffsetRootBoneMode : uint8 {
	Accumulate = 0,
	Interpolate = 1,
	Hold = 2,
	Release = 3,
	EOffsetRootBoneMode_MAX = 4
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementInterpolationSettings
// Size: 0x24 (Inherited: 0x00)
struct FFootPlacementInterpolationSettings {
	float UnplantLinearStiffness; // 0x00(0x04)
	float UnplantLinearDamping; // 0x04(0x04)
	float UnplantAngularStiffness; // 0x08(0x04)
	float UnplantAngularDamping; // 0x0c(0x04)
	float FloorLinearStiffness; // 0x10(0x04)
	float FloorLinearDamping; // 0x14(0x04)
	float FloorAngularStiffness; // 0x18(0x04)
	float FloorAngularDamping; // 0x1c(0x04)
	bool bEnableFloorInterpolation; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementTraceSettings
// Size: 0x1c (Inherited: 0x00)
struct FFootPlacementTraceSettings {
	float StartOffset; // 0x00(0x04)
	float EndOffset; // 0x04(0x04)
	float SweepRadius; // 0x08(0x04)
	enum class ETraceTypeQuery ComplexTraceChannel; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	float MaxGroundPenetration; // 0x10(0x04)
	float SimpleCollisionInfluence; // 0x14(0x04)
	enum class ETraceTypeQuery SimpleTraceChannel; // 0x18(0x01)
	bool bEnabled; // 0x19(0x01)
	char pad_1A[0x2]; // 0x1a(0x02)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementRootDefinition
// Size: 0x18 (Inherited: 0x00)
struct FFootPlacementRootDefinition {
	struct FBoneReference PelvisBone; // 0x00(0x0c)
	struct FBoneReference IKRootBone; // 0x0c(0x0c)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementPelvisSettings
// Size: 0x1c (Inherited: 0x00)
struct FFootPlacementPelvisSettings {
	float MaxOffset; // 0x00(0x04)
	float LinearStiffness; // 0x04(0x04)
	float LinearDamping; // 0x08(0x04)
	float HorizontalRebalancingWeight; // 0x0c(0x04)
	float MaxOffsetHorizontal; // 0x10(0x04)
	float HeelLiftRatio; // 0x14(0x04)
	enum class EPelvisHeightMode PelvisHeightMode; // 0x18(0x01)
	enum class EActorMovementCompensationMode ActorMovementCompensationMode; // 0x19(0x01)
	bool bEnableInterpolation; // 0x1a(0x01)
	char pad_1B[0x1]; // 0x1b(0x01)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacemenLegDefinition
// Size: 0x30 (Inherited: 0x00)
struct FFootPlacemenLegDefinition {
	struct FBoneReference FKFootBone; // 0x00(0x0c)
	struct FBoneReference IKFootBone; // 0x0c(0x0c)
	struct FBoneReference BallBone; // 0x18(0x0c)
	int32_t NumBonesInLimb; // 0x24(0x04)
	struct FName SpeedCurveName; // 0x28(0x04)
	struct FName DisableLockCurveName; // 0x2c(0x04)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementPlantSettings
// Size: 0x34 (Inherited: 0x00)
struct FFootPlacementPlantSettings {
	float SpeedThreshold; // 0x00(0x04)
	float DistanceToGround; // 0x04(0x04)
	enum class EFootPlacementLockType LockType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float UnplantRadius; // 0x0c(0x04)
	float ReplantRadiusRatio; // 0x10(0x04)
	float UnplantAngle; // 0x14(0x04)
	float ReplantAngleRatio; // 0x18(0x04)
	float MaxExtensionRatio; // 0x1c(0x04)
	float MinExtensionRatio; // 0x20(0x04)
	float SeparatingDistance; // 0x24(0x04)
	float UnalignmentSpeedThreshold; // 0x28(0x04)
	float AnkleTwistReduction; // 0x2c(0x04)
	bool bAdjustHeelBeforePlanting; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_FootPlacement
// Size: 0x400 (Inherited: 0xc8)
struct FAnimNode_FootPlacement : FAnimNode_SkeletalControlBase {
	enum class EWarpingEvaluationMode PlantSpeedMode; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	struct FBoneReference IKFootRootBone; // 0xcc(0x0c)
	struct FBoneReference PelvisBone; // 0xd8(0x0c)
	struct FFootPlacementPelvisSettings PelvisSettings; // 0xe4(0x1c)
	struct TArray<struct FFootPlacemenLegDefinition> LegDefinitions; // 0x100(0x10)
	struct FFootPlacementPlantSettings PlantSettings; // 0x110(0x34)
	struct FFootPlacementInterpolationSettings InterpolationSettings; // 0x144(0x24)
	struct FFootPlacementTraceSettings TraceSettings; // 0x168(0x1c)
	char pad_184[0x27c]; // 0x184(0x27c)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_OffsetRootBone
// Size: 0x190 (Inherited: 0xc8)
struct FAnimNode_OffsetRootBone : FAnimNode_SkeletalControlBase {
	char pad_C8[0xc8]; // 0xc8(0xc8)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_OrientationWarping
// Size: 0x198 (Inherited: 0xc8)
struct FAnimNode_OrientationWarping : FAnimNode_SkeletalControlBase {
	enum class EWarpingEvaluationMode Mode; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	float OrientationAngle; // 0xcc(0x04)
	float LocomotionAngle; // 0xd0(0x04)
	float MinRootMotionSpeedThreshold; // 0xd4(0x04)
	float LocomotionAngleDeltaThreshold; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct TArray<struct FBoneReference> SpineBones; // 0xe0(0x10)
	struct FBoneReference IKFootRootBone; // 0xf0(0x0c)
	char pad_FC[0x4]; // 0xfc(0x04)
	struct TArray<struct FBoneReference> IKFootBones; // 0x100(0x10)
	enum class EAxis RotationAxis; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	float DistributedBoneOrientationAlpha; // 0x114(0x04)
	float RotationInterpSpeed; // 0x118(0x04)
	float WarpingAlpha; // 0x11c(0x04)
	float OffsetAlpha; // 0x120(0x04)
	float MaxOffsetAngle; // 0x124(0x04)
	char pad_128[0x70]; // 0x128(0x70)
};

// ScriptStruct AnimationWarpingRuntime.SlopeWarpingFootDefinition
// Size: 0x20 (Inherited: 0x00)
struct FSlopeWarpingFootDefinition {
	struct FBoneReference IKFootBone; // 0x00(0x0c)
	struct FBoneReference FKFootBone; // 0x0c(0x0c)
	int32_t NumBonesInLimb; // 0x18(0x04)
	float FootSize; // 0x1c(0x04)
};

// ScriptStruct AnimationWarpingRuntime.SlopeWarpingFootData
// Size: 0xb0 (Inherited: 0x00)
struct FSlopeWarpingFootData {
	char pad_0[0xb0]; // 0x00(0xb0)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_SlopeWarping
// Size: 0x2d8 (Inherited: 0xc8)
struct FAnimNode_SlopeWarping : FAnimNode_SkeletalControlBase {
	char pad_C8[0x18]; // 0xc8(0x18)
	struct FBoneReference IKFootRootBone; // 0xe0(0x0c)
	struct FBoneReference PelvisBone; // 0xec(0x0c)
	struct TArray<struct FSlopeWarpingFootDefinition> FeetDefinitions; // 0xf8(0x10)
	struct TArray<struct FSlopeWarpingFootData> FeetData; // 0x108(0x10)
	struct FVectorRK4SpringInterpolator PelvisOffsetInterpolator; // 0x118(0x08)
	char pad_120[0x58]; // 0x120(0x58)
	struct FVector GravityDir; // 0x178(0x18)
	struct FVector CustomFloorOffset; // 0x190(0x18)
	float CachedDeltaTime; // 0x1a8(0x04)
	char pad_1AC[0x4]; // 0x1ac(0x04)
	struct FVector TargetFloorNormalWorldSpace; // 0x1b0(0x18)
	struct FVectorRK4SpringInterpolator FloorNormalInterpolator; // 0x1c8(0x08)
	char pad_1D0[0x58]; // 0x1d0(0x58)
	struct FVector TargetFloorOffsetLocalSpace; // 0x228(0x18)
	struct FVectorRK4SpringInterpolator FloorOffsetInterpolator; // 0x240(0x08)
	char pad_248[0x58]; // 0x248(0x58)
	float MaxStepHeight; // 0x2a0(0x04)
	char bKeepMeshInsideOfCapsule : 1; // 0x2a4(0x01)
	char bPullPelvisDown : 1; // 0x2a4(0x01)
	char bUseCustomFloorOffset : 1; // 0x2a4(0x01)
	char bWasOnGround : 1; // 0x2a4(0x01)
	char bShowDebug : 1; // 0x2a4(0x01)
	char bFloorSmoothingInitialized : 1; // 0x2a4(0x01)
	char pad_2A4_6 : 2; // 0x2a4(0x01)
	char pad_2A5[0x3]; // 0x2a5(0x03)
	struct FVector ActorLocation; // 0x2a8(0x18)
	struct FVector GravityDirCompSpace; // 0x2c0(0x18)
};

// ScriptStruct AnimationWarpingRuntime.StrideWarpingFootDefinition
// Size: 0x24 (Inherited: 0x00)
struct FStrideWarpingFootDefinition {
	struct FBoneReference IKFootBone; // 0x00(0x0c)
	struct FBoneReference FKFootBone; // 0x0c(0x0c)
	struct FBoneReference ThighBone; // 0x18(0x0c)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_StrideWarping
// Size: 0x240 (Inherited: 0xc8)
struct FAnimNode_StrideWarping : FAnimNode_SkeletalControlBase {
	enum class EWarpingEvaluationMode Mode; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
	struct FVector StrideDirection; // 0xd0(0x18)
	float StrideScale; // 0xe8(0x04)
	float LocomotionSpeed; // 0xec(0x04)
	float MinRootMotionSpeedThreshold; // 0xf0(0x04)
	struct FBoneReference PelvisBone; // 0xf4(0x0c)
	struct FBoneReference IKFootRootBone; // 0x100(0x0c)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct TArray<struct FStrideWarpingFootDefinition> FootDefinitions; // 0x110(0x10)
	struct FInputClampConstants StrideScaleModifier; // 0x120(0x14)
	char pad_134[0x4]; // 0x134(0x04)
	struct FWarpingVectorValue FloorNormalDirection; // 0x138(0x20)
	struct FWarpingVectorValue GravityDirection; // 0x158(0x20)
	struct FIKFootPelvisPullDownSolver PelvisIKFootSolver; // 0x178(0x80)
	bool bOrientStrideDirectionUsingFloorNormal; // 0x1f8(0x01)
	bool bCompensateIKUsingFKThighRotation; // 0x1f9(0x01)
	bool bClampIKUsingFKLimits; // 0x1fa(0x01)
	char pad_1FB[0x45]; // 0x1fb(0x45)
};

