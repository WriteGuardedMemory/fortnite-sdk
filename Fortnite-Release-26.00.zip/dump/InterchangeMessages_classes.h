// Class InterchangeMessages.InterchangeResultMeshWarning
// Size: 0x70 (Inherited: 0x60)
struct UInterchangeResultMeshWarning : UInterchangeResultWarning {
	struct FString MeshName; // 0x60(0x10)
};

// Class InterchangeMessages.InterchangeResultTextureWarning
// Size: 0x70 (Inherited: 0x60)
struct UInterchangeResultTextureWarning : UInterchangeResultWarning {
	struct FString TextureName; // 0x60(0x10)
};

// Class InterchangeMessages.InterchangeResultMeshError
// Size: 0x70 (Inherited: 0x60)
struct UInterchangeResultMeshError : UInterchangeResultError {
	struct FString MeshName; // 0x60(0x10)
};

// Class InterchangeMessages.InterchangeResultMeshWarning_Generic
// Size: 0x88 (Inherited: 0x70)
struct UInterchangeResultMeshWarning_Generic : UInterchangeResultMeshWarning {
	struct FText Text; // 0x70(0x18)
};

// Class InterchangeMessages.InterchangeResultMeshError_Generic
// Size: 0x88 (Inherited: 0x70)
struct UInterchangeResultMeshError_Generic : UInterchangeResultMeshError {
	struct FText Text; // 0x70(0x18)
};

// Class InterchangeMessages.InterchangeResultMeshWarning_TooManyUVs
// Size: 0x78 (Inherited: 0x70)
struct UInterchangeResultMeshWarning_TooManyUVs : UInterchangeResultMeshWarning {
	int32_t ExcessUVs; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class InterchangeMessages.InterchangeResultTextureWarning_TextureFileDoNotExist
// Size: 0x98 (Inherited: 0x70)
struct UInterchangeResultTextureWarning_TextureFileDoNotExist : UInterchangeResultTextureWarning {
	struct FText Text; // 0x70(0x18)
	struct FString MaterialName; // 0x88(0x10)
};

