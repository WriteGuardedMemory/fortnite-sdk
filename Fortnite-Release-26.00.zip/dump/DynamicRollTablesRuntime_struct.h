// Enum DynamicRollTablesRuntime.ERollModifierOperation
enum class ERollModifierOperation : uint8 {
	Add = 0,
	Multiply = 1,
	Zero = 2,
	ERollModifierOperation_MAX = 3
};

// ScriptStruct DynamicRollTablesRuntime.FortDynamicRollResult
// Size: 0x08 (Inherited: 0x00)
struct FFortDynamicRollResult {
	struct UFortItemDefinition* Item; // 0x00(0x08)
};

// ScriptStruct DynamicRollTablesRuntime.FortDynamicRollBaseWeightTableRow
// Size: 0x38 (Inherited: 0x08)
struct FFortDynamicRollBaseWeightTableRow : FTableRowBase {
	struct UFortItemDefinition* ItemDefinition; // 0x08(0x08)
	float BaseWeight; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TArray<struct FGameplayTag> ModTags; // 0x18(0x10)
	bool bOwningItemZerosWeight; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float MaxModifiedWeight; // 0x2c(0x04)
	float MinModifiedWeight; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DynamicRollTablesRuntime.FortDynamicRollWeightModifierTableRow
// Size: 0x18 (Inherited: 0x08)
struct FFortDynamicRollWeightModifierTableRow : FTableRowBase {
	struct FGameplayTag ActivatingPlayerTag; // 0x08(0x04)
	struct FGameplayTag TargetModTag; // 0x0c(0x04)
	enum class ERollModifierOperation WeightModifierOperation; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float WeightModificationValue; // 0x14(0x04)
};

// ScriptStruct DynamicRollTablesRuntime.DynamicRollModifiersActivatedByPlayerTagContainer
// Size: 0x10 (Inherited: 0x00)
struct FDynamicRollModifiersActivatedByPlayerTagContainer {
	char pad_0[0x10]; // 0x00(0x10)
};

