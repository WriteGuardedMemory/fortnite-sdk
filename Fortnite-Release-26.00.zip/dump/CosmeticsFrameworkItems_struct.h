// ScriptStruct CosmeticsFrameworkItems.CosmeticPropertyBase
// Size: 0x04 (Inherited: 0x00)
struct FCosmeticPropertyBase {
	struct FGameplayTag PropertyTag; // 0x00(0x04)
};

// ScriptStruct CosmeticsFrameworkItems.CosmeticProperty_Vector
// Size: 0x20 (Inherited: 0x04)
struct FCosmeticProperty_Vector : FCosmeticPropertyBase {
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector Value; // 0x08(0x18)
};

