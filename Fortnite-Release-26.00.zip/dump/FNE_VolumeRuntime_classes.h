// Class FNE_VolumeRuntime.FNE_Volume
// Size: 0x350 (Inherited: 0x330)
struct AFNE_Volume : AGameplayVolume {
	struct TSoftClassPtr<UObject> NewPlayspaceClassTemplate; // 0x330(0x20)
};

// Class FNE_VolumeRuntime.FNE_VolumeComponent
// Size: 0x118 (Inherited: 0xa0)
struct UFNE_VolumeComponent : UActorComponent {
	struct FMulticastInlineDelegate OnPlayspaceUserAdded; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnPlayspaceUserRemoved; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnPlayerStateBeginOverlap; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnPlayerStateEndOverlap; // 0xd0(0x10)
	struct AActor* VolumeClassTemplate; // 0xe0(0x08)
	struct TSoftClassPtr<UObject> PlayspaceClassTemplate; // 0xe8(0x20)
	struct AFNE_Volume* SpawnedVolume; // 0x108(0x08)
	bool bEnableOverlap; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)

	void SetEnableOverlap(bool bEnable); // Function FNE_VolumeRuntime.FNE_VolumeComponent.SetEnableOverlap // (Final|Native|Public|BlueprintCallable) // @ game+0xabdb170
	void HandlePlayspaceUserRemoved(struct FPlayspaceUser& RemovedUser); // Function FNE_VolumeRuntime.FNE_VolumeComponent.HandlePlayspaceUserRemoved // (Final|Native|Protected|HasOutParms) // @ game+0xabdadb0
	void HandlePlayspaceUserAdded(struct FPlayspaceUser& AddedUser); // Function FNE_VolumeRuntime.FNE_VolumeComponent.HandlePlayspaceUserAdded // (Final|Native|Protected|HasOutParms) // @ game+0xabdaf90
	void HandleNotifyPlayerStateEndOverlap(struct APlayerState* TouchingPlayerState, struct AGameplayVolume* Volume); // Function FNE_VolumeRuntime.FNE_VolumeComponent.HandleNotifyPlayerStateEndOverlap // (Final|Native|Protected) // @ game+0xabdaab0
	void HandleNotifyPlayerStateBeginOverlap(struct APlayerState* TouchingPlayerState, struct AGameplayVolume* Volume); // Function FNE_VolumeRuntime.FNE_VolumeComponent.HandleNotifyPlayerStateBeginOverlap // (Final|Native|Protected) // @ game+0xabdac30
	struct AFNE_Volume* GetSpawnedVolume(); // Function FNE_VolumeRuntime.FNE_VolumeComponent.GetSpawnedVolume // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdb280
	bool GetEnableOverlap(); // Function FNE_VolumeRuntime.FNE_VolumeComponent.GetEnableOverlap // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdb260
	struct TArray<struct APlayerState*> GetAllPlayerStates(); // Function FNE_VolumeRuntime.FNE_VolumeComponent.GetAllPlayerStates // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xabdb2a0
};

