// Enum EventScreenBase.EEventScreenView
enum class EEventScreenView : uint8 {
	None = 0,
	LandingPage = 1,
	RewardPreview = 2,
	MoreInfo = 3,
	PurchaseLevels = 4,
	PurchasePremiumTrack = 5,
	LoadError = 6,
	EEventScreenView_MAX = 7
};

// Enum EventScreenBase.EEventScreenRewardPreviewType
enum class EEventScreenRewardPreviewType : uint8 {
	None = 0,
	RewardTrack = 1,
	SpecialItem = 2,
	SpecialPremiumItem = 3,
	EEventScreenRewardPreviewType_MAX = 4
};

// ScriptStruct EventScreenBase.EventItemOverride
// Size: 0x68 (Inherited: 0x00)
struct FEventItemOverride {
	struct TSoftObjectPtr<UFortItemDefinition> ItemDefinition; // 0x00(0x20)
	struct TSoftObjectPtr<UTexture2D> CustomItemTexture; // 0x20(0x20)
	struct TSoftObjectPtr<UTexture2D> CustomItemTextureMobile; // 0x40(0x20)
	bool bIsDoubleWidth; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct EventScreenBase.EventScreenTrackData
// Size: 0x20 (Inherited: 0x00)
struct FEventScreenTrackData {
	struct FLinearColor TrackColorPrimary; // 0x00(0x10)
	struct FLinearColor TrackColorSecondary; // 0x10(0x10)
};

// ScriptStruct EventScreenBase.EventScreenMoreInfoGroup
// Size: 0x40 (Inherited: 0x00)
struct FEventScreenMoreInfoGroup {
	struct FText Header; // 0x00(0x18)
	struct FText Body; // 0x18(0x18)
	struct FString IconURL; // 0x30(0x10)
};

// ScriptStruct EventScreenBase.EventScreenCMSResourceGroupOverride
// Size: 0x18 (Inherited: 0x00)
struct FEventScreenCMSResourceGroupOverride {
	int32_t ResourceValue; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString KeyArtOverrideURL; // 0x08(0x10)
};

// ScriptStruct EventScreenBase.EventScreenCMSData
// Size: 0x2a8 (Inherited: 0x00)
struct FEventScreenCMSData {
	struct FString EventCMSId; // 0x00(0x10)
	struct FText EventName; // 0x10(0x18)
	struct FText EventDescription; // 0x28(0x18)
	struct FText ResourceHeader; // 0x40(0x18)
	struct FText StarterHeader; // 0x58(0x18)
	struct FText CompletionHeader; // 0x70(0x18)
	struct FText EventCTA; // 0x88(0x18)
	struct FText EventCTACompleted; // 0xa0(0x18)
	struct FText HeaderCTA; // 0xb8(0x18)
	struct FText ItemShopCallout; // 0xd0(0x18)
	struct FString CTAIconURL; // 0xe8(0x10)
	struct FString KeyArtURL; // 0xf8(0x10)
	struct FText MoreInfoHeader; // 0x108(0x18)
	struct FText MoreInfoSubHeader; // 0x120(0x18)
	struct FText MoreInfoLegal; // 0x138(0x18)
	struct TArray<struct FEventScreenMoreInfoGroup> MoreInfoGroups; // 0x150(0x10)
	struct FText PurchaseLegal; // 0x160(0x18)
	struct FText RewardTrackLegal; // 0x178(0x18)
	struct FString ItemShopOfferId; // 0x190(0x10)
	struct FText PremiumUpsellUnownedHeader; // 0x1a0(0x18)
	struct FText PremiumUpsellUnownedBody; // 0x1b8(0x18)
	struct FText PremiumUpsellOwnedHeader; // 0x1d0(0x18)
	struct FText PremiumUpsellOwnedBody; // 0x1e8(0x18)
	struct FString PremiumUpsellIconURL; // 0x200(0x10)
	struct FText PurchasePremiumTrackHeader; // 0x210(0x18)
	struct TArray<struct FText> PurchasePremiumTrackBodyList; // 0x228(0x10)
	struct FText InspectSpecialItemUnowned; // 0x238(0x18)
	struct FText InspectSpecialItemOwned; // 0x250(0x18)
	struct FText InspectSpecialPremiumItemUnowned; // 0x268(0x18)
	struct FText InspectSpecialPremiumItemOwned; // 0x280(0x18)
	struct TArray<struct FEventScreenCMSResourceGroupOverride> ResourceGroupOverrides; // 0x298(0x10)
};

// ScriptStruct EventScreenBase.EventScreenCMSGroup
// Size: 0x10 (Inherited: 0x00)
struct FEventScreenCMSGroup {
	struct TArray<struct FEventScreenCMSData> EventScreens; // 0x00(0x10)
};

