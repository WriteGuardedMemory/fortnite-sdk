// Class AudioWidgets.AudioMeter
// Size: 0x6b0 (Inherited: 0x178)
struct UAudioMeter : UWidget {
	struct TArray<struct FMeterChannelInfo> MeterChannelInfo; // 0x178(0x10)
	struct FDelegate MeterChannelInfoDelegate; // 0x188(0x0c)
	char pad_194[0xc]; // 0x194(0x0c)
	struct FAudioMeterStyle WidgetStyle; // 0x1a0(0x480)
	enum class EOrientation Orientation; // 0x620(0x01)
	char pad_621[0x3]; // 0x621(0x03)
	struct FLinearColor BackgroundColor; // 0x624(0x10)
	struct FLinearColor MeterBackgroundColor; // 0x634(0x10)
	struct FLinearColor MeterValueColor; // 0x644(0x10)
	struct FLinearColor MeterPeakColor; // 0x654(0x10)
	struct FLinearColor MeterClippingColor; // 0x664(0x10)
	struct FLinearColor MeterScaleColor; // 0x674(0x10)
	struct FLinearColor MeterScaleLabelColor; // 0x684(0x10)
	char pad_694[0x1c]; // 0x694(0x1c)

	void SetMeterValueColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterValueColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a3390
	void SetMeterScaleLabelColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a2f50
	void SetMeterScaleColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterScaleColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a3060
	void SetMeterPeakColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterPeakColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a3280
	void SetMeterClippingColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterClippingColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a3170
	void SetMeterChannelInfo(struct TArray<struct FMeterChannelInfo>& InMeterChannelInfo); // Function AudioWidgets.AudioMeter.SetMeterChannelInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa9a36c0
	void SetMeterBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a34a0
	void SetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a35b0
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo__DelegateSignature(); // DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature // (Public|Delegate) // @ game+0x1b027f0
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo(); // Function AudioWidgets.AudioMeter.GetMeterChannelInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9a37e0
};

// Class AudioWidgets.AudioRadialSlider
// Size: 0x380 (Inherited: 0x178)
struct UAudioRadialSlider : UWidget {
	float Value; // 0x178(0x04)
	struct FDelegate ValueDelegate; // 0x17c(0x0c)
	enum class EAudioRadialSliderLayout WidgetLayout; // 0x188(0x01)
	char pad_189[0x3]; // 0x189(0x03)
	struct FLinearColor CenterBackgroundColor; // 0x18c(0x10)
	struct FLinearColor SliderProgressColor; // 0x19c(0x10)
	struct FLinearColor SliderBarColor; // 0x1ac(0x10)
	char pad_1BC[0x4]; // 0x1bc(0x04)
	struct FVector2D HandStartEndRatio; // 0x1c0(0x10)
	struct FText UnitsText; // 0x1d0(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x1e8(0x10)
	bool ShowLabelOnlyOnHover; // 0x1f8(0x01)
	bool ShowUnitsText; // 0x1f9(0x01)
	bool IsUnitsTextReadOnly; // 0x1fa(0x01)
	bool IsValueTextReadOnly; // 0x1fb(0x01)
	float SliderThickness; // 0x1fc(0x04)
	struct FVector2D OutputRange; // 0x200(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x210(0x10)
	char pad_220[0x160]; // 0x220(0x160)

	void SetWidgetLayout(enum class EAudioRadialSliderLayout InLayout); // Function AudioWidgets.AudioRadialSlider.SetWidgetLayout // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a5ad0
	void SetValueTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioRadialSlider.SetValueTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a5190
	void SetUnitsTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a52d0
	void SetUnitsText(struct FText Units); // Function AudioWidgets.AudioRadialSlider.SetUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a53d0
	void SetTextLabelBackgroundColor(struct FSlateColor InColor); // Function AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a5530
	void SetSliderThickness(float InThickness); // Function AudioWidgets.AudioRadialSlider.SetSliderThickness // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a4e90
	void SetSliderProgressColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a58b0
	void SetSliderBarColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetSliderBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a57a0
	void SetShowUnitsText(bool bShowUnitsText); // Function AudioWidgets.AudioRadialSlider.SetShowUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a4f90
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // Function AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a5090
	void SetOutputRange(struct FVector2D InOutputRange); // Function AudioWidgets.AudioRadialSlider.SetOutputRange // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a4d90
	void SetHandStartEndRatio(struct FVector2D InHandStartEndRatio); // Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a56a0
	void SetCenterBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a59c0
	float GetSliderValue(float OutputValue); // Function AudioWidgets.AudioRadialSlider.GetSliderValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a5bd0
	float GetOutputValue(float InSliderValue); // Function AudioWidgets.AudioRadialSlider.GetOutputValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a5cd0
};

// Class AudioWidgets.AudioVolumeRadialSlider
// Size: 0x380 (Inherited: 0x380)
struct UAudioVolumeRadialSlider : UAudioRadialSlider {
};

// Class AudioWidgets.AudioFrequencyRadialSlider
// Size: 0x380 (Inherited: 0x380)
struct UAudioFrequencyRadialSlider : UAudioRadialSlider {
};

// Class AudioWidgets.AudioSliderBase
// Size: 0x930 (Inherited: 0x178)
struct UAudioSliderBase : UWidget {
	float Value; // 0x178(0x04)
	char pad_17C[0x4]; // 0x17c(0x04)
	struct FText UnitsText; // 0x180(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x198(0x10)
	struct FDelegate TextLabelBackgroundColorDelegate; // 0x1a8(0x0c)
	bool ShowLabelOnlyOnHover; // 0x1b4(0x01)
	bool ShowUnitsText; // 0x1b5(0x01)
	bool IsUnitsTextReadOnly; // 0x1b6(0x01)
	bool IsValueTextReadOnly; // 0x1b7(0x01)
	struct FDelegate ValueDelegate; // 0x1b8(0x0c)
	struct FLinearColor SliderBackgroundColor; // 0x1c4(0x10)
	struct FDelegate SliderBackgroundColorDelegate; // 0x1d4(0x0c)
	struct FLinearColor SliderBarColor; // 0x1e0(0x10)
	struct FDelegate SliderBarColorDelegate; // 0x1f0(0x0c)
	struct FLinearColor SliderThumbColor; // 0x1fc(0x10)
	struct FDelegate SliderThumbColorDelegate; // 0x20c(0x0c)
	struct FLinearColor WidgetBackgroundColor; // 0x218(0x10)
	struct FDelegate WidgetBackgroundColorDelegate; // 0x228(0x0c)
	enum class EOrientation Orientation; // 0x234(0x01)
	char pad_235[0x3]; // 0x235(0x03)
	struct FMulticastInlineDelegate OnValueChanged; // 0x238(0x10)
	char pad_248[0x6e8]; // 0x248(0x6e8)

	void SetWidgetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a80f0
	void SetValueTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8730
	void SetUnitsTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8870
	void SetUnitsText(struct FText Units); // Function AudioWidgets.AudioSliderBase.SetUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8970
	void SetTextLabelBackgroundColor(struct FSlateColor InColor); // Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8ad0
	void SetSliderThumbColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderThumbColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a8200
	void SetSliderBarColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a8310
	void SetSliderBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9a8420
	void SetShowUnitsText(bool bShowUnitsText); // Function AudioWidgets.AudioSliderBase.SetShowUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8530
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8630
	float GetSliderValue(float OutputValue); // Function AudioWidgets.AudioSliderBase.GetSliderValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8c40
	float GetOutputValue(float InSliderValue); // Function AudioWidgets.AudioSliderBase.GetOutputValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8d40
	float GetLinValue(float OutputValue); // Function AudioWidgets.AudioSliderBase.GetLinValue // (Final|Native|Public|BlueprintCallable) // @ game+0xa9a8c40
};

// Class AudioWidgets.AudioSlider
// Size: 0x940 (Inherited: 0x930)
struct UAudioSlider : UAudioSliderBase {
	struct TWeakObjectPtr<struct UCurveFloat> LinToOutputCurve; // 0x930(0x08)
	struct TWeakObjectPtr<struct UCurveFloat> OutputToLinCurve; // 0x938(0x08)
};

// Class AudioWidgets.AudioVolumeSlider
// Size: 0x940 (Inherited: 0x940)
struct UAudioVolumeSlider : UAudioSlider {
};

// Class AudioWidgets.AudioFrequencySlider
// Size: 0x940 (Inherited: 0x930)
struct UAudioFrequencySlider : UAudioSliderBase {
	struct FVector2D OutputRange; // 0x930(0x10)
};

