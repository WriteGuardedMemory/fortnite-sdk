// Class AirJellyfishRuntime.FortAirJellyfishAnimInstance
// Size: 0x560 (Inherited: 0x540)
struct UFortAirJellyfishAnimInstance : UFortAnimInstance {
	float RotatorLerpRate; // 0x538(0x04)
	float VelocityDirectionScalar; // 0x53c(0x04)
	struct FRotator RootRotation; // 0x540(0x18)
};

