// ScriptStruct CosmeticsFrameworkFlowgraph.CosmeticFlowData
// Size: 0x50 (Inherited: 0x00)
struct FCosmeticFlowData {
	struct TMap<struct FName, struct FInstancedStruct> NamedData; // 0x00(0x50)
};

// ScriptStruct CosmeticsFrameworkFlowgraph.OperationSequenceHandle
// Size: 0x10 (Inherited: 0x00)
struct FOperationSequenceHandle {
	char pad_0[0x10]; // 0x00(0x10)
};

