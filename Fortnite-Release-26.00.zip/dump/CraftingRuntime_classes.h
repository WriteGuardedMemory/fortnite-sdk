// Class CraftingRuntime.CraftingGlobals
// Size: 0x28 (Inherited: 0x28)
struct UCraftingGlobals : UObject {
};

// Class CraftingRuntime.CraftingObjectBGA
// Size: 0x9e0 (Inherited: 0x978)
struct ACraftingObjectBGA : ABuildingGameplayActor {
	char pad_978[0x8]; // 0x978(0x08)
	struct AFortInventory* Inventory; // 0x980(0x08)
	char pad_988[0x18]; // 0x988(0x18)
	struct USphereComponent* SphereComponent_InteractionRange; // 0x9a0(0x08)
	struct TSoftClassPtr<UObject> MenuWidget; // 0x9a8(0x20)
	struct UWidgetComponent* WidgetComponent_PotContents; // 0x9c8(0x08)
	bool bShowCraftingUI; // 0x9d0(0x01)
	bool bSendEventMessageOnLocalInteract; // 0x9d1(0x01)
	char pad_9D2[0x6]; // 0x9d2(0x06)
	struct UStaticMeshComponent* CraftingObjectMesh; // 0x9d8(0x08)

	void HandleInteractionRangeEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function CraftingRuntime.CraftingObjectBGA.HandleInteractionRangeEndOverlap // (Final|Native|Private) // @ game+0xa8edc30
	void HandleInteractionRangeBeginOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function CraftingRuntime.CraftingObjectBGA.HandleInteractionRangeBeginOverlap // (Final|Native|Private|HasOutParms) // @ game+0xa8edf00
};

// Class CraftingRuntime.CraftingCheatManager
// Size: 0x28 (Inherited: 0x28)
struct UCraftingCheatManager : UChildCheatManager {

	void ToggleFreeCrafting(); // Function CraftingRuntime.CraftingCheatManager.ToggleFreeCrafting // (Final|Exec|Native|Public) // @ game+0x3982d70
	void StartSelfCrafting(struct FName FormulaName); // Function CraftingRuntime.CraftingCheatManager.StartSelfCrafting // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x78a3430
};

// Class CraftingRuntime.CraftingObjectComponent
// Size: 0x440 (Inherited: 0xa0)
struct UCraftingObjectComponent : UGameFrameworkComponent {
	struct FMulticastInlineDelegate CraftingObjectStateChanged; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFormulaCraftableChanged; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnCraftingSuccess; // 0xc0(0x10)
	struct TArray<struct FCraftingObjectRepStateData> CraftingObjectRepStateData; // 0xd0(0x10)
	struct TMap<struct FCraftingMultiKey, struct FCraftingObjectServerStateData> CraftingObjectServerStateData; // 0xe0(0x50)
	struct FName LastCraftedItemFormulaRow; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct FString LastIngredientStringForAnalytics; // 0x138(0x10)
	struct FString LastFormulaStringForAnalytics; // 0x148(0x10)
	struct FString LastResultsStringForAnalytics; // 0x158(0x10)
	struct FGameplayAbilitySpecHandle WhileCraftingAbilitySpecHandle; // 0x168(0x04)
	struct FGameplayAbilitySpecHandle OwnerCraftingAbilitySpecHandle; // 0x16c(0x04)
	struct FGameplayTag CraftingObjectTag; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
	struct FGameplayTagContainer CraftingObjectTags; // 0x178(0x20)
	struct FScalableFloat CraftingTimeLength; // 0x198(0x28)
	struct FScalableFloat ReadyTimeLength; // 0x1c0(0x28)
	struct FScalableFloat OverCraftingTimeLength; // 0x1e8(0x28)
	struct FScalableFloat ResettingTimeLength; // 0x210(0x28)
	struct FName OverCraftingLootTierKey; // 0x238(0x04)
	char bTakeItemsAtCraftingStart : 1; // 0x23c(0x01)
	char pad_23C_1 : 7; // 0x23c(0x01)
	char pad_23D[0x3]; // 0x23d(0x03)
	float DecayRate; // 0x240(0x04)
	char bGiveIngredientsToCraftingObject : 1; // 0x244(0x01)
	char bGiveIngredientsToInstigator : 1; // 0x244(0x01)
	char pad_244_2 : 6; // 0x244(0x01)
	char pad_245[0x3]; // 0x245(0x03)
	struct FVector IngredientSpawnOffset; // 0x248(0x18)
	char bGiveToCraftingObject : 1; // 0x260(0x01)
	char bGiveResultToInstigator : 1; // 0x260(0x01)
	char pad_260_2 : 6; // 0x260(0x01)
	char pad_261[0x7]; // 0x261(0x07)
	struct TSoftClassPtr<UObject> OwnerCraftingAbility; // 0x268(0x20)
	struct TSoftClassPtr<UObject> WhileCraftingAbility; // 0x288(0x20)
	struct TSoftClassPtr<UObject> InstigatorWhileCraftingAbility; // 0x2a8(0x20)
	bool bScaleMultiCraftingTime; // 0x2c8(0x01)
	char pad_2C9[0x7]; // 0x2c9(0x07)
	struct FGameplayTagContainer CraftingFailedTags; // 0x2d0(0x20)
	char pad_2F0[0x148]; // 0x2f0(0x148)
	bool FreeCraftingEnabled; // 0x438(0x01)
	char pad_439[0x7]; // 0x439(0x07)

	void OnRep_CraftingObjectRepStateData(struct TArray<struct FCraftingObjectRepStateData>& OldValue); // Function CraftingRuntime.CraftingObjectComponent.OnRep_CraftingObjectRepStateData // (Final|Native|Private|HasOutParms) // @ game+0xa8f0690
	void HandlePickupCraftingItemPickedUp(struct AFortPickup* Pickup, struct AFortPawn* InteractingPawn, struct UFortWorldItemDefinition* WorldItemDefinition, struct FVector PickupLocation); // Function CraftingRuntime.CraftingObjectComponent.HandlePickupCraftingItemPickedUp // (Final|Native|Private|HasDefaults) // @ game+0xa8f03f0
	void CraftingObjectOnFormulaCraftableChanged__DelegateSignature(struct FName& FormulaRowName, bool bIsCraftable); // DelegateFunction CraftingRuntime.CraftingObjectComponent.CraftingObjectOnFormulaCraftableChanged__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x1b027f0
};

// Class CraftingRuntime.FortControllerComponent_CraftingNetworkEvents
// Size: 0xb8 (Inherited: 0xa8)
struct UFortControllerComponent_CraftingNetworkEvents : UFortControllerComponent {
	struct FMulticastInlineDelegate OnCraftingSuccess; // 0xa8(0x10)

	void ServerStartCrafting(struct AActor* CraftingObject, struct FName CraftingFormulaName, int32_t NumberToCraft, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerStartCrafting // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0xa8f83c0
	void ServerResumeCrafting(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerResumeCrafting // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0xa8f7a90
	void ServerReportCraftingSuccess(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerReportCraftingSuccess // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0xa8f75d0
	void ServerPickupItemAndStartCrafting(struct AActor* CraftingObject, struct AFortPickup* Pickup, struct FName CraftingFormulaName, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerPickupItemAndStartCrafting // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0xa8f80a0
	void ServerPauseCrafting(struct AActor* CraftingObject, bool bDecayPausedTime, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerPauseCrafting // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0xa8f7c60
	void ServerEjectItems(struct AActor* CraftingObject); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerEjectItems // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0xa8f77a0
	void ServerClaimCraftingResults(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerClaimCraftingResults // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0xa8f78c0
	void ServerCancelCrafting(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ServerCancelCrafting // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable|NetValidate) // @ game+0xa8f7ed0
	void NotifyCraftingSuccess(struct AActor* CraftingObject, struct FName& FormulaRowName, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.NotifyCraftingSuccess // (Final|Native|Public|HasOutParms) // @ game+0xa8f70c0
	void ClientNotifyCraftingSuccess(struct AActor* CraftingObject, struct FName FormulaRowName, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ClientNotifyCraftingSuccess // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xa8f6eb0
	void ClientNotifyCraftingFailed(struct AActor* CraftingObject, struct FGameplayTagContainer FailedReason, struct FCraftingMultiKey Key); // Function CraftingRuntime.FortControllerComponent_CraftingNetworkEvents.ClientNotifyCraftingFailed // (Net|Native|Event|Public|NetClient) // @ game+0xa8f7330
};

// Class CraftingRuntime.FortGameStateComponent_Crafting
// Size: 0x248 (Inherited: 0xa0)
struct UFortGameStateComponent_Crafting : UFortGameStateComponent {
	struct FDataRegistryType CraftingFormulaRegistryType; // 0xa0(0x04)
	struct FDataRegistryType CraftingIngredientsUIDataRegistryType; // 0xa4(0x04)
	char pad_A8[0x140]; // 0xa8(0x140)
	struct TArray<struct FCraftingResult> CraftingResultsList; // 0x1e8(0x10)
	char pad_1F8[0x50]; // 0x1f8(0x50)

	void OnRep_CraftingResultsList(); // Function CraftingRuntime.FortGameStateComponent_Crafting.OnRep_CraftingResultsList // (Final|Native|Protected) // @ game+0xa8f9460
	void OnPlaylistDataReady(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function CraftingRuntime.FortGameStateComponent_Crafting.OnPlaylistDataReady // (Final|Native|Protected|HasOutParms) // @ game+0xa8f91e0
};

// Class CraftingRuntime.FortPickupInteractOverrideComponent_Crafting
// Size: 0xe0 (Inherited: 0xc0)
struct UFortPickupInteractOverrideComponent_Crafting : UFortPickupInteractOverrideComponent {
	struct UFortItemDefinition* LastPickupItemDef; // 0xc0(0x08)
	struct UFortItemDefinition* LastFocusedItemDef; // 0xc8(0x08)
	struct FName LastTargetFormulaName; // 0xd0(0x04)
	float ContextualCraftingInteractDuration; // 0xd4(0x04)
	enum class TInteractionType CachedInteractionType; // 0xd8(0x01)
	enum class EInteractionBeingAttempted CachedInteractionBeingAttempted; // 0xd9(0x01)
	char pad_DA[0x6]; // 0xda(0x06)
};

// Class CraftingRuntime.FortContextualTutorial_CraftingComplete
// Size: 0xf8 (Inherited: 0xf8)
struct UFortContextualTutorial_CraftingComplete : UFortContextualTutorial {

	void OnCraftingSuccess(struct FCraftingObjectSuccessEvent& Event); // Function CraftingRuntime.FortContextualTutorial_CraftingComplete.OnCraftingSuccess // (Final|Native|Private|HasOutParms) // @ game+0xa8fbe50
};

// Class CraftingRuntime.FortContextualTutorial_CraftingReady
// Size: 0xf8 (Inherited: 0xf8)
struct UFortContextualTutorial_CraftingReady : UFortContextualTutorial {

	void HandleFormulaCraftableChanged(struct FName& FormulaRowName, bool bIsCraftable); // Function CraftingRuntime.FortContextualTutorial_CraftingReady.HandleFormulaCraftableChanged // (Final|Native|Private|HasOutParms) // @ game+0xa8fc410
};

// Class CraftingRuntime.FortContextualTutorial_CraftingTabOpen
// Size: 0x100 (Inherited: 0xf8)
struct UFortContextualTutorial_CraftingTabOpen : UFortContextualTutorial {
	char pad_F8[0x8]; // 0xf8(0x08)

	void HandleInventoryTabChanged(struct FName InventoryTabNameId); // Function CraftingRuntime.FortContextualTutorial_CraftingTabOpen.HandleInventoryTabChanged // (Final|Native|Private) // @ game+0xa8fce20
	void HandleFormulaCraftableChanged(struct FName& FormulaRowName, bool bIsCraftable); // Function CraftingRuntime.FortContextualTutorial_CraftingTabOpen.HandleFormulaCraftableChanged // (Final|Native|Private|HasOutParms) // @ game+0xa8fccb0
};

// Class CraftingRuntime.CraftingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCraftingLibrary : UBlueprintFunctionLibrary {

	void StartCrafting(struct AFortPlayerController* Instigator, struct AActor* CraftingObject, struct FName& CraftingFormulaName, int32_t NumberToCraft, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.StartCrafting // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa8fe680
	void ResumeCrafting(struct AFortPlayerController* Instigator, struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.ResumeCrafting // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8fdae0
	void ReportCraftingSuccess(struct AFortPlayerController* Instigator, struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.ReportCraftingSuccess // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8fd460
	void PickupItemAndStartCrafting(struct AFortPlayerController* Instigator, struct AActor* CraftingObject, struct AFortPickup* Pickup, struct FName& CraftingFormulaName, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.PickupItemAndStartCrafting // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa8fe2c0
	void PauseCrafting(struct AFortPlayerController* Instigator, struct AActor* CraftingObject, bool bDecayPausedTime, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.PauseCrafting // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8fdd40
	bool IsValidIngredient(struct AFortPlayerController* FortPC, struct AActor* CraftingObject, struct UFortItemDefinition* ItemDef); // Function CraftingRuntime.CraftingLibrary.IsValidIngredient // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa901610
	void GiveItemToCraftingObject(struct AFortPlayerController* Instigator, struct AActor* CraftingObject, struct FFortItemEntry& ItemEntryToGrant); // Function CraftingRuntime.CraftingLibrary.GiveItemToCraftingObject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa902c40
	void GetValidIngredientsInInventory(struct AFortPlayerController* FortPC, struct AActor* CraftingObject, struct TArray<struct UFortWorldItem*>& OutIngredients); // Function CraftingRuntime.CraftingLibrary.GetValidIngredientsInInventory // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa900890
	void GetUIDataForCraftingIngredientTags(struct UObject* WorldContextObject, struct FGameplayTagContainer& IngredientTags, struct TArray<struct TSoftObjectPtr<UFortItemDefinition>>& OutItemDefs, struct TArray<struct TSoftObjectPtr<UObject>>& OutIcons); // Function CraftingRuntime.CraftingLibrary.GetUIDataForCraftingIngredientTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa8ff650
	float GetTimeToCraftRecipe(struct AActor* CraftingObject, struct FName& CraftingFormulaName); // Function CraftingRuntime.CraftingLibrary.GetTimeToCraftRecipe // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa8fea10
	struct FName GetLastCraftedItemFormulaName(struct AActor* CraftingObject); // Function CraftingRuntime.CraftingLibrary.GetLastCraftedItemFormulaName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9025d0
	void GetKnownCraftingFormulas(struct AFortPlayerController* FortPC, struct AActor* CraftingObject, struct TArray<struct FName>& OutFormulas); // Function CraftingRuntime.CraftingLibrary.GetKnownCraftingFormulas // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa902090
	struct TArray<struct UFortWorldItem*> GetIngredientsInCraftingObject(struct AActor* CraftingObject); // Function CraftingRuntime.CraftingLibrary.GetIngredientsInCraftingObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa903020
	void GetCraftingResultsForRowName(struct UObject* WorldContextObject, struct FName& CraftingFormulaRow, struct TArray<struct FItemAndCount>& OutResults, int32_t NumToCraft); // Function CraftingRuntime.CraftingLibrary.GetCraftingResultsForRowName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9039c0
	struct FGameplayTagContainer GetCraftingObjectTags(struct AActor* CraftingObject); // Function CraftingRuntime.CraftingLibrary.GetCraftingObjectTags // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9036f0
	float GetCraftingObjectPausedTime(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.GetCraftingObjectPausedTime // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8febd0
	float GetCraftingObjectCurrentCraftingStateTimeLeft(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateTimeLeft // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8fee20
	float GetCraftingObjectCurrentCraftingStateStartTime(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateStartTime // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8ff1e0
	float GetCraftingObjectCurrentCraftingStateEndTime(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCurrentCraftingStateEndTime // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8ff020
	enum class ECraftingObjectState GetCraftingObjectCraftingState(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.GetCraftingObjectCraftingState // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa903510
	struct UCraftingObjectComponent* GetCraftingObjectComponent(struct AActor* CraftingObject); // Function CraftingRuntime.CraftingLibrary.GetCraftingObjectComponent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9038a0
	struct TArray<struct UFortWorldItem*> GetCraftingIngredients_TempItems(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.GetCraftingIngredients_TempItems // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9031c0
	struct FName GetCraftingFormulaNameBeingCrafted(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.GetCraftingFormulaNameBeingCrafted // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa902700
	bool GetCraftingFormulaIngredientRequirements(struct UObject* WorldContextObject, struct FName& CraftingFormulaRow, struct TArray<struct FCraftingIngredientRequirement>& OutIngredientRequirements); // Function CraftingRuntime.CraftingLibrary.GetCraftingFormulaIngredientRequirements // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa8ff3c0
	struct TArray<struct UFortWorldItem*> GetCraftedResults_TempItems(struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.GetCraftedResults_TempItems // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9028d0
	void GetAllValidIngredients(struct AFortPlayerController* FortPC, struct AActor* CraftingObject, struct TArray<struct FGameplayTagContainer>& OutIngredients); // Function CraftingRuntime.CraftingLibrary.GetAllValidIngredients // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa901060
	void GetAllCraftingFormulas(struct AFortPlayerController* FortPC, struct AActor* CraftingObject, struct TArray<struct FName>& OutFormulas); // Function CraftingRuntime.CraftingLibrary.GetAllCraftingFormulas // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa901bf0
	void GetAllCraftableFormulas(struct AFortPlayerController* FortPC, struct AActor* CraftingObject, struct TArray<struct FName>& OutFormulas); // Function CraftingRuntime.CraftingLibrary.GetAllCraftableFormulas // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa8ffa50
	void EjectItems(struct AFortPlayerController* Instigator, struct AActor* CraftingObject); // Function CraftingRuntime.CraftingLibrary.EjectItems // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8fd6c0
	void ClaimCraftingResults(struct AFortPlayerController* Instigator, struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.ClaimCraftingResults // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8fd880
	bool CanCraftFormulaWithAdditionalItems(struct AFortPlayerController* FortPC, struct AActor* CraftingObject, struct FName CraftingFormulaRow, struct TArray<struct FItemAndCount>& AdditionalItems, struct TArray<struct FCraftingIngredientQueryState>& OutIngredientStates, int32_t NumberToCraft); // Function CraftingRuntime.CraftingLibrary.CanCraftFormulaWithAdditionalItems // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9000a0
	bool CanCraftFormula(struct AFortPlayerController* FortPC, struct AActor* CraftingObject, struct FName CraftingFormulaRow, struct TArray<struct FCraftingIngredientQueryState>& OutIngredientStates, int32_t NumberToCraft); // Function CraftingRuntime.CraftingLibrary.CanCraftFormula // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa900510
	void CancelCrafting(struct AFortPlayerController* Instigator, struct AActor* CraftingObject, struct FCraftingMultiKey Key); // Function CraftingRuntime.CraftingLibrary.CancelCrafting // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa8fe060
};

