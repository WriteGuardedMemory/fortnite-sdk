// ScriptStruct AudioMotorSimStandardComponents.MotorSimGearCurve
// Size: 0x90 (Inherited: 0x00)
struct FMotorSimGearCurve {
	struct FRuntimeFloatCurve RpmCurve; // 0x00(0x88)
	float SpeedTopThreshold; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

