// ScriptStruct HealthShieldRegenRuntime.FortHealthShieldRegen_ShieldDelegateContainer
// Size: 0x30 (Inherited: 0x00)
struct FFortHealthShieldRegen_ShieldDelegateContainer {
	struct FDelegate OnShieldChanged; // 0x00(0x0c)
	struct FDelegate OnShieldedDamage; // 0x0c(0x0c)
	struct FDelegate OnShieldDestroyed; // 0x18(0x0c)
	struct FDelegate OnDamageReceived; // 0x24(0x0c)
};

// ScriptStruct HealthShieldRegenRuntime.FortHealthShieldRegen_HealthDelegateContainer
// Size: 0x18 (Inherited: 0x00)
struct FFortHealthShieldRegen_HealthDelegateContainer {
	struct FDelegate OnHealthChanged; // 0x00(0x0c)
	struct FDelegate OnDamageReceived; // 0x0c(0x0c)
};

