// Class FortniteAI.FortAITask_Move
// Size: 0x160 (Inherited: 0x118)
struct UFortAITask_Move : UAITask_MoveTo {
	struct FFortMoveConfig MoveConfig; // 0x118(0x38)
	char pad_150[0x10]; // 0x150(0x10)
};

// Class FortniteAI.FortNavModifierComponent
// Size: 0x230 (Inherited: 0x190)
struct UFortNavModifierComponent : UNavModifierComponent {
	float LowSpeedSquareThreshold; // 0x190(0x04)
	float LowSpeedSquareDistanceThreshold; // 0x194(0x04)
	float LowSpeedRotationThreshold; // 0x198(0x04)
	float LowSpeedScaleThreshold; // 0x19c(0x04)
	char bAutomaticNavBoundComputation : 1; // 0x1a0(0x01)
	char bForceFailSafeExtent : 1; // 0x1a0(0x01)
	char pad_1A0_2 : 6; // 0x1a0(0x01)
	char pad_1A1[0x3]; // 0x1a1(0x03)
	float ExtrapolationMultiplierForFailsafeExtent; // 0x1a4(0x04)
	struct TArray<struct ANavigationData*> DisableForNavmeshClasses; // 0x1a8(0x10)
	struct UPrimitiveComponent* PrimCompAffectingNavMesh; // 0x1b8(0x08)
	char pad_1C0[0x70]; // 0x1c0(0x70)

	void SetComponentAffectingNavMesh(struct UPrimitiveComponent* InComponentAffectingNavMesh); // Function FortniteAI.FortNavModifierComponent.SetComponentAffectingNavMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x962ef30
};

// Class FortniteAI.FortPhysicsObjectNavigationComponent
// Size: 0x240 (Inherited: 0x230)
struct UFortPhysicsObjectNavigationComponent : UFortNavModifierComponent {
	struct UFortPhysicsObjectComponent* PhysicsObjectComponent; // 0x230(0x08)
	char pad_238[0x8]; // 0x238(0x08)

	void OnSleepStateChanged(struct UPrimitiveComponent* SimulatingComponent, bool bIsAwake); // Function FortniteAI.FortPhysicsObjectNavigationComponent.OnSleepStateChanged // (Final|RequiredAPI|Native|Protected) // @ game+0x9632bf0
};

// Class FortniteAI.FortAIAimingInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAIAimingInterface : UInterface {

	void GetAimingRotation(struct FRotator& OutRotation); // Function FortniteAI.FortAIAimingInterface.GetAimingRotation // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x94c20b0
};

// Class FortniteAI.FortAIAimingManagerInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAIAimingManagerInterface : UInterface {

	void ComputeAimingRotations(); // Function FortniteAI.FortAIAimingManagerInterface.ComputeAimingRotations // (Native|Event|Public|BlueprintEvent) // @ game+0x5329050
};

// Class FortniteAI.FortAIEnvironmentalDangerSourceInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAIEnvironmentalDangerSourceInterface : UInterface {

	struct FBox GetDangerSourceBounds(); // Function FortniteAI.FortAIEnvironmentalDangerSourceInterface.GetDangerSourceBounds // (Native|Event|Public|HasDefaults|BlueprintEvent|Const) // @ game+0x94c2430
	bool GetDangerSourceActive(); // Function FortniteAI.FortAIEnvironmentalDangerSourceInterface.GetDangerSourceActive // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6f9c3e0
	float GetDangerAtLocation(struct FVector& Location); // Function FortniteAI.FortAIEnvironmentalDangerSourceInterface.GetDangerAtLocation // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const) // @ game+0x94c2480
};

// Class FortniteAI.FortAIInjectedBehaviorComponent
// Size: 0xf0 (Inherited: 0xa0)
struct UFortAIInjectedBehaviorComponent : UActorComponent {
	char pad_A0[0x50]; // 0xa0(0x50)
};

// Class FortniteAI.FortAIPerceptionSystem
// Size: 0x130 (Inherited: 0x130)
struct UFortAIPerceptionSystem : UAIPerceptionSystem {
};

// Class FortniteAI.FortAthenaAIBotCharacterCustomization
// Size: 0x288 (Inherited: 0x28)
struct UFortAthenaAIBotCharacterCustomization : UObject {
	struct FFortAthenaLoadout CustomizationLoadout; // 0x28(0x260)
};

// Class FortniteAI.FortAthenaAIBotInventoryItems
// Size: 0x38 (Inherited: 0x28)
struct UFortAthenaAIBotInventoryItems : UObject {
	struct TArray<struct FItemAndCount> Items; // 0x28(0x10)
};

// Class FortniteAI.FortAthenaAIControllerInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaAIControllerInterface : UInterface {
};

// Class FortniteAI.FortAthenaAILODSettings
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaAILODSettings : UInterface {
};

// Class FortniteAI.FortAthenaAILODSettings_AIEvaluator
// Size: 0x2b0 (Inherited: 0x28)
struct UFortAthenaAILODSettings_AIEvaluator : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct UFortAthenaAIEvaluator*> SystemClasses; // 0x30(0x10)
	struct FFortAILODSetting_AIEvaluator BelowLowerLODSettings; // 0x40(0x68)
	struct FFortAILODSetting_AIEvaluator LowerLODSettings; // 0xa8(0x68)
	struct FFortAILODSetting_AIEvaluator AboveLowerLODSettings; // 0x110(0x68)
	struct FFortAILODSetting_AIEvaluator BelowNormalLODSettings; // 0x178(0x68)
	struct FFortAILODSetting_AIEvaluator NormalLODSettings; // 0x1e0(0x68)
	struct FFortAILODSetting_AIEvaluator AboveNormalLODSettings; // 0x248(0x68)
};

// Class FortniteAI.FortAthenaAILODSettings_CharacterMovement
// Size: 0x970 (Inherited: 0x28)
struct UFortAthenaAILODSettings_CharacterMovement : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct UFortMovementComp_Character*> SystemClasses; // 0x30(0x10)
	struct FFortAILODSetting_CharacterMovement BelowLowerLODSettings; // 0x40(0x188)
	struct FFortAILODSetting_CharacterMovement LowerLODSettings; // 0x1c8(0x188)
	struct FFortAILODSetting_CharacterMovement AboveLowerLODSettings; // 0x350(0x188)
	struct FFortAILODSetting_CharacterMovement BelowNormalLODSettings; // 0x4d8(0x188)
	struct FFortAILODSetting_CharacterMovement NormalLODSettings; // 0x660(0x188)
	struct FFortAILODSetting_CharacterMovement AboveNormalLODSettings; // 0x7e8(0x188)
};

// Class FortniteAI.FortAthenaAILODSettings_FortWeaponRanged
// Size: 0x2b0 (Inherited: 0x28)
struct UFortAthenaAILODSettings_FortWeaponRanged : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct AFortWeaponRanged*> SystemClasses; // 0x30(0x10)
	struct FFortAILODSetting_FortWeaponRanged BelowLowerLODSettings; // 0x40(0x68)
	struct FFortAILODSetting_FortWeaponRanged LowerLODSettings; // 0xa8(0x68)
	struct FFortAILODSetting_FortWeaponRanged AboveLowerLODSettings; // 0x110(0x68)
	struct FFortAILODSetting_FortWeaponRanged BelowNormalLODSettings; // 0x178(0x68)
	struct FFortAILODSetting_FortWeaponRanged NormalLODSettings; // 0x1e0(0x68)
	struct FFortAILODSetting_FortWeaponRanged AboveNormalLODSettings; // 0x248(0x68)
};

// Class FortniteAI.FortAthenaAILODSettings_GenericTickingObject
// Size: 0x190 (Inherited: 0x28)
struct UFortAthenaAILODSettings_GenericTickingObject : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct UObject*> SystemClasses; // 0x30(0x10)
	struct FFortAILODSetting_GenericTickingObject BelowLowerLODSettings; // 0x40(0x38)
	struct FFortAILODSetting_GenericTickingObject LowerLODSettings; // 0x78(0x38)
	struct FFortAILODSetting_GenericTickingObject AboveLowerLODSettings; // 0xb0(0x38)
	struct FFortAILODSetting_GenericTickingObject BelowNormalLODSettings; // 0xe8(0x38)
	struct FFortAILODSetting_GenericTickingObject NormalLODSettings; // 0x120(0x38)
	struct FFortAILODSetting_GenericTickingObject AboveNormalLODSettings; // 0x158(0x38)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent
// Size: 0x30 (Inherited: 0x28)
struct UFortAthenaAISpawnerDataComponent : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_ConstructionBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_ConstructionBase : UFortAthenaAISpawnerDataComponent {

	bool GetConstructionBuildingInfo(struct FConstructionBuildingList& OutConstructionInfoList); // Function FortniteAI.FortAthenaAISpawnerDataComponent_ConstructionBase.GetConstructionBuildingInfo // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x96be5a0
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotConstruction
// Size: 0xc0 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIBotConstruction : UFortAthenaAISpawnerDataComponent_ConstructionBase {
	struct FConstructionBuildingList ConstructionBuildingInfoList; // 0x30(0x90)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_BehaviorBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_BehaviorBase : UFortAthenaAISpawnerDataComponent {

	struct UBehaviorTree* GetBehaviorTree(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_BehaviorBase.GetBehaviorTree // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x96bd220
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_Behavior
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_Behavior : UFortAthenaAISpawnerDataComponent_BehaviorBase {
	struct UBehaviorTree* BehaviorTree; // 0x30(0x08)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_ChanceEncounterBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_ChanceEncounterBase : UFortAthenaAISpawnerDataComponent {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_ConversationBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_ConversationBase : UFortAthenaAISpawnerDataComponent {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_DebugBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_DebugBase : UFortAthenaAISpawnerDataComponent {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_LODBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_LODBase : UFortAthenaAISpawnerDataComponent {

	struct FClientAILODSettings GetClientAILODSettings(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_LODBase.GetClientAILODSettings // (RequiredAPI|Native|Event|Public|BlueprintEvent|Const) // @ game+0x96c3690
	struct UFortAthenaAILODSettingsContainer* GetAILODSettingsContainer(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_LODBase.GetAILODSettingsContainer // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x39ba580
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_LOD
// Size: 0x328 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_LOD : UFortAthenaAISpawnerDataComponent_LODBase {
	struct UFortAthenaAILODSettingsContainer* LODSettings; // 0x30(0x08)
	struct FClientAILODSettings ClientLODSettings; // 0x38(0x2f0)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_VehicleBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_VehicleBase : UFortAthenaAISpawnerDataComponent {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_VoiceBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_VoiceBase : UFortAthenaAISpawnerDataComponent {
};

// Class FortniteAI.FortAthenaEntitySubsystemInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaEntitySubsystemInterface : UInterface {
};

// Class FortniteAI.FortAthenaAISpawnerData
// Size: 0x118 (Inherited: 0x48)
struct UFortAthenaAISpawnerData : UFortAthenaSpawnerDataBase {
	struct TArray<struct UFortAthenaAISpawnerDataComponent*> ClassComponentList; // 0x48(0x10)
	struct UFortAthenaAISpawnerDataComponent_InventoryBase* InventoryComponent; // 0x58(0x08)
	struct UFortAthenaAISpawnerDataComponent_SpawnParamsBase* SpawnParamsComponent; // 0x60(0x08)
	struct UFortAthenaAISpawnerDataComponent_BehaviorBase* BehaviorComponent; // 0x68(0x08)
	struct UFortAthenaAISpawnerDataComponent_AffiliationBase* AffiliationComponent; // 0x70(0x08)
	struct UFortAthenaAISpawnerDataComponent_LODBase* LODComponent; // 0x78(0x08)
	struct UFortAthenaAISpawnerDataComponent_DebugBase* DebugComponent; // 0x80(0x08)
	struct UFortAthenaAISpawnerDataComponent_AnalyticBase* AnalyticComponent; // 0x88(0x08)
	struct UFortAthenaAISpawnerDataComponent_GameplayBase* GameplayComponent; // 0x90(0x08)
	struct UFortAthenaAISpawnerDataComponent_ConversationBase* ConversationComponent; // 0x98(0x08)
	struct UFortAthenaAISpawnerDataComponent_VoiceBase* VoiceComponent; // 0xa0(0x08)
	struct UFortAthenaAISpawnerDataComponent_CosmeticBase* CosmeticComponent; // 0xa8(0x08)
	struct UFortAthenaAISpawnerDataComponent_ChanceEncounterBase* ChanceEncounterComponent; // 0xb0(0x08)
	struct UFortAthenaAISpawnerDataComponent_OptimBase* OptimizationComponent; // 0xb8(0x08)
	struct UFortAthenaAISpawnerDataComponent_GameplayAbilityBase* GameplayAbilityComponent; // 0xc0(0x08)
	struct UFortAthenaAISpawnerDataComponent_PerceptionBase* PerceptionComponent; // 0xc8(0x08)
	struct UFortAthenaAISpawnerDataComponent_SmartObjectBase* SmartObjectComponent; // 0xd0(0x08)
	struct UFortAthenaAISpawnerDataComponent_GroupBase* GroupComponent; // 0xd8(0x08)
	struct UFortAthenaAISpawnerDataComponent_ScriptBase* ScriptComponent; // 0xe0(0x08)
	struct UFortAthenaAISpawnerDataComponent_TokenBase* TokenComponent; // 0xe8(0x08)
	struct FScalableFloat SpawnIntervalOverride; // 0xf0(0x28)

	struct UFortAthenaAISpawnerDataComponent_VoiceBase* GetVoiceComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetVoiceComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d460
	struct UFortAthenaAISpawnerDataComponent_TokenBase* GetTokenComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetTokenComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d070
	struct UFortAthenaAISpawnerDataComponent_SpawnParamsBase* GetSpawnParamsComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetSpawnParamsComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d770
	struct UFortAthenaAISpawnerDataComponent_SmartObjectBase* GetSmartObjectComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetSmartObjectComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d1c0
	struct UFortAthenaAISpawnerDataComponent_ScriptBase* GetScriptComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetScriptComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d0e0
	struct UFortAthenaAISpawnerDataComponent_PerceptionBase* GetPerceptionComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetPerceptionComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d230
	struct UFortAthenaAISpawnerDataComponent_OptimBase* GetOptimizationComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetOptimizationComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d310
	struct UFortAthenaAISpawnerDataComponent_InventoryBase* GetInventoryComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetInventoryComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d7e0
	struct UFortAthenaAISpawnerDataComponent_GroupBase* GetGroupComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetGroupComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d150
	struct UFortAthenaAISpawnerDataComponent_GameplayBase* GetGameplayComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetGameplayComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d540
	struct UFortAthenaAISpawnerDataComponent_GameplayAbilityBase* GetGameplayAbilityComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetGameplayAbilityComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d2a0
	struct UFortAthenaAISpawnerDataComponent_DebugBase* GetDebugComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetDebugComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d5b0
	struct UFortAthenaAISpawnerDataComponent_CosmeticBase* GetCosmeticComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetCosmeticComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d3f0
	struct UFortAthenaAISpawnerDataComponent_ConversationBase* GetConversationComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetConversationComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d4d0
	struct UFortAthenaAISpawnerDataComponent_ChanceEncounterBase* GetChanceEncounterComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetChanceEncounterComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d380
	struct UFortAthenaAISpawnerDataComponent_BehaviorBase* GetBehaviorComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetBehaviorComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d700
	struct UFortAthenaAISpawnerDataComponent_AnalyticBase* GetAnalyticComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetAnalyticComponent // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3bf2270
	struct UFortAthenaAISpawnerDataComponent_LODBase* GetAILODComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetAILODComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d620
	struct UFortAthenaAISpawnerDataComponent_AffiliationBase* GetAffiliationComponent(); // Function FortniteAI.FortAthenaAISpawnerData.GetAffiliationComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969d690
	struct UFortAthenaAISpawnerDataComponentList* CreateComponentListFromClass(struct UFortAthenaAISpawnerData* AISpawnerDataClass, struct UObject* OuterObject); // Function FortniteAI.FortAthenaAISpawnerData.CreateComponentListFromClass // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x969cdd0
	struct UFortAthenaAISpawnerDataComponentList* CreateComponentList(struct UObject* OuterObject); // Function FortniteAI.FortAthenaAISpawnerData.CreateComponentList // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969cf80
};

// Class FortniteAI.FortAthenaAIBotSpawnerData
// Size: 0x140 (Inherited: 0x118)
struct UFortAthenaAIBotSpawnerData : UFortAthenaAISpawnerData {
	struct UFortAthenaAISpawnerDataComponent_SkillsetBase* SkillSetComponent; // 0x118(0x08)
	struct UFortAthenaAISpawnerDataComponent_ConstructionBase* ConstructionComponent; // 0x120(0x08)
	struct UFortAthenaAISpawnerDataComponent_VehicleBase* VehicleComponent; // 0x128(0x08)
	struct UFortAthenaAISpawnerDataComponent_CoverBase* CoverComponent; // 0x130(0x08)
	struct UFortAthenaAISpawnerDataComponent_PerksBase* PerksComponent; // 0x138(0x08)

	struct UFortAthenaAISpawnerDataComponent_VehicleBase* GetVehicleComponent(); // Function FortniteAI.FortAthenaAIBotSpawnerData.GetVehicleComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9690570
	struct UFortAthenaAISpawnerDataComponent_SkillsetBase* GetSkillSetComponent(); // Function FortniteAI.FortAthenaAIBotSpawnerData.GetSkillSetComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9690650
	struct UFortAthenaAISpawnerDataComponent_PerksBase* GetPerksComponent(); // Function FortniteAI.FortAthenaAIBotSpawnerData.GetPerksComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9690490
	struct UFortAthenaAISpawnerDataComponent_CoverBase* GetCoverComponent(); // Function FortniteAI.FortAthenaAIBotSpawnerData.GetCoverComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9690500
	struct UFortAthenaAISpawnerDataComponent_ConstructionBase* GetConstructionComponent(); // Function FortniteAI.FortAthenaAIBotSpawnerData.GetConstructionComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96905e0
};

// Class FortniteAI.FortAthenaNPCSpawnerData
// Size: 0x140 (Inherited: 0x140)
struct UFortAthenaNPCSpawnerData : UFortAthenaAIBotSpawnerData {
};

// Class FortniteAI.FortAthenaPlayerBotSpawnerData
// Size: 0x140 (Inherited: 0x140)
struct UFortAthenaPlayerBotSpawnerData : UFortAthenaAIBotSpawnerData {
};

// Class FortniteAI.FortBotNameSettings
// Size: 0x50 (Inherited: 0x28)
struct UFortBotNameSettings : UObject {
	enum class EBotNamingMode NamingMode; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FText OverrideName; // 0x30(0x18)
	bool bAddPlayerIDSuffix; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class FortniteAI.FortDoorLinkOpenerInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortDoorLinkOpenerInterface : UInterface {
};

// Class FortniteAI.FortInjectedBehavior
// Size: 0x48 (Inherited: 0x28)
struct UFortInjectedBehavior : UObject {
	struct UFortAthenaAIEvaluator* AIEvaluator; // 0x28(0x08)
	float Interval; // 0x30(0x04)
	float RandomDeviation; // 0x34(0x04)
	struct UBehaviorTree* InjectedBehaviorTree; // 0x38(0x08)
	uint32_t Priority; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class FortniteAI.FortMetaNavArea
// Size: 0x58 (Inherited: 0x48)
struct UFortMetaNavArea : UNavAreaMeta {
	struct TArray<struct FNavAgentData> AgentData; // 0x48(0x10)
};

// Class FortniteAI.FortMetaNavArea_Wall
// Size: 0x58 (Inherited: 0x58)
struct UFortMetaNavArea_Wall : UFortMetaNavArea {
};

// Class FortniteAI.FortNavArea
// Size: 0x50 (Inherited: 0x48)
struct UFortNavArea : UNavArea {
	char bObstacle : 1; // 0x48(0x01)
	char bSmashable : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class FortniteAI.FortNavArea_DefaultSmashable
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_DefaultSmashable : UFortNavArea {
};

// Class FortniteAI.FortNavArea_PlayerBuiltSmashable
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_PlayerBuiltSmashable : UFortNavArea_DefaultSmashable {
};

// Class FortniteAI.FortNavArea_WoodenWall
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_WoodenWall : UFortNavArea {
};

// Class FortniteAI.FortQueryContext_ConverterPawn
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_ConverterPawn : UEnvQueryContext {
};

// Class FortniteAI.FortQueryContext_ConverterController
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_ConverterController : UEnvQueryContext {
};

// Class FortniteAI.FortQueryContext_ConverterViewLocation
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_ConverterViewLocation : UEnvQueryContext {
};

// Class FortniteAI.FortQueryContext_ConverterViewRotation
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_ConverterViewRotation : UEnvQueryContext {
};

// Class FortniteAI.FortSpawnPointsPercentageCurveSequence
// Size: 0x48 (Inherited: 0x30)
struct UFortSpawnPointsPercentageCurveSequence : UDataAsset {
	struct TArray<struct FDataTableRowHandle> SpawnPointsPercentageCurves; // 0x30(0x10)
	enum class EFortIntensityCurveSequenceType SequenceType; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class FortniteAI.AIHotSpot
// Size: 0x440 (Inherited: 0x290)
struct AAIHotSpot : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct TArray<struct UAIHotSpotSlot*> UserSlots; // 0x298(0x10)
	struct UAIHotSpotSlotGenerator* SlotGenerator; // 0x2a8(0x08)
	struct TArray<struct UAIHotSpotSlot*> Slots; // 0x2b0(0x10)
	struct AActor* FocusActor; // 0x2c0(0x08)
	struct UNavigationQueryFilter* FilterClass; // 0x2c8(0x08)
	struct FVector CustomNavmeshSearchExtent; // 0x2d0(0x18)
	char bStartEnabled : 1; // 0x2e8(0x01)
	char bAllowSlotlessAssignment : 1; // 0x2e8(0x01)
	char bAllowClaimingMultipleSlots : 1; // 0x2e8(0x01)
	char bTrackOverlappingSlots : 1; // 0x2e8(0x01)
	char bProjectSlotsOnNavmesh : 1; // 0x2e8(0x01)
	char bCustomNavmeshSearchExtent : 1; // 0x2e8(0x01)
	char bIsEnabled : 1; // 0x2e8(0x01)
	char pad_2E8_7 : 1; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct TArray<struct AAIController*> NoSlotAssignees; // 0x2f0(0x10)
	char pad_300[0x128]; // 0x300(0x128)
	struct UPrimitiveComponent* RenderingComponent; // 0x428(0x08)
	struct UBillboardComponent* SpriteComponent; // 0x430(0x08)
	char pad_438[0x8]; // 0x438(0x08)

	void SetEnabled(bool bEnabled); // Function FortniteAI.AIHotSpot.SetEnabled // (Native|Public|BlueprintCallable) // @ game+0x850fed0
	int32_t RemoveGroupFromHotspot(struct TArray<struct AAIController*> GroupOfAI); // Function FortniteAI.AIHotSpot.RemoveGroupFromHotspot // (Native|Public|BlueprintCallable) // @ game+0x94cd330
	bool RemoveFromHotspot(struct AAIController* AI, bool bAssignFromWaitingList); // Function FortniteAI.AIHotSpot.RemoveFromHotspot // (Native|Public|BlueprintCallable) // @ game+0x94cd4b0
	void OnSlotOccupied(struct AAIController* AI, int32_t Index, int32_t UserId); // Function FortniteAI.AIHotSpot.OnSlotOccupied // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cbd30
	void OnSlotFreed(struct AAIController* AI, int32_t Index, int32_t UserId); // Function FortniteAI.AIHotSpot.OnSlotFreed // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cbb20
	void OnSlotEnabled(int32_t Index, int32_t UserId); // Function FortniteAI.AIHotSpot.OnSlotEnabled // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cb5f0
	void OnSlotDisabled(int32_t Index, int32_t UserId); // Function FortniteAI.AIHotSpot.OnSlotDisabled // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cb780
	void OnSlotClaimed(struct AAIController* AI, int32_t Index, int32_t UserId); // Function FortniteAI.AIHotSpot.OnSlotClaimed // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cbf40
	void OnSlotBlocked(struct AAIController* AI, int32_t Index, int32_t UserId); // Function FortniteAI.AIHotSpot.OnSlotBlocked // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cb910
	void OnRemovedSlotlessBehavior(struct AAIController* AI, bool bIsClamingSlot); // Function FortniteAI.AIHotSpot.OnRemovedSlotlessBehavior // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cc4a0
	void OnRemovedBehavior(struct AAIController* AI, int32_t Index, int32_t UserId, enum class EAIHotSpotSlot PrevState, bool bWasOnWaitingList); // Function FortniteAI.AIHotSpot.OnRemovedBehavior // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cc150
	void OnMoveToSlotFinished(struct AAIController* AI, int32_t Index, int32_t UserId, bool bResult); // Function FortniteAI.AIHotSpot.OnMoveToSlotFinished // (BlueprintAuthorityOnly|Native|Event|Protected|BlueprintEvent) // @ game+0x94ca400
	void OnHotSpotEnabled(); // Function FortniteAI.AIHotSpot.OnHotSpotEnabled // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x3c1aed0
	void OnHotSpotDisabled(); // Function FortniteAI.AIHotSpot.OnHotSpotDisabled // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x3c1aef0
	bool OnAssignedSlotlessBehavior(struct AAIController* AI); // Function FortniteAI.AIHotSpot.OnAssignedSlotlessBehavior // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cc630
	bool OnAssignedOccupiedBehavior(struct AAIController* AI, int32_t Index, int32_t UserId); // Function FortniteAI.AIHotSpot.OnAssignedOccupiedBehavior // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cc730
	bool OnAssignedClaimedBehavior(struct AAIController* AI, int32_t Index, int32_t UserId, bool bWasOnWaitingList); // Function FortniteAI.AIHotSpot.OnAssignedClaimedBehavior // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent) // @ game+0x94cc950
	bool OccupySlotByIndex(int32_t Index); // Function FortniteAI.AIHotSpot.OccupySlotByIndex // (Native|Public|BlueprintCallable) // @ game+0x94ca6b0
	bool IsSlotlessAssignmentAllowed(); // Function FortniteAI.AIHotSpot.IsSlotlessAssignmentAllowed // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94ca7b0
	bool IsEnabled(); // Function FortniteAI.AIHotSpot.IsEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cdc60
	bool IsAIAllowed(struct AAIController* AI); // Function FortniteAI.AIHotSpot.IsAIAllowed // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent|Const) // @ game+0x94cdb60
	bool HasEnabledSlots(); // Function FortniteAI.AIHotSpot.HasEnabledSlots // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94ca7e0
	bool HasAssignedAI(struct AAIController* AI, enum class EAIHotSpotAssignmentFilter Filter); // Function FortniteAI.AIHotSpot.HasAssignedAI // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94ccd80
	int32_t GetSlotUserIdByIndex(int32_t Index); // Function FortniteAI.AIHotSpot.GetSlotUserIdByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cb0c0
	enum class EAIHotSpotSlot GetSlotStateByOwner(struct AAIController* AIOwner); // Function FortniteAI.AIHotSpot.GetSlotStateByOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cacf0
	enum class EAIHotSpotSlot GetSlotStateByIndex(int32_t Index); // Function FortniteAI.AIHotSpot.GetSlotStateByIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cae70
	struct FRotator GetSlotRotationByIndex(int32_t Index); // Function FortniteAI.AIHotSpot.GetSlotRotationByIndex // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x94caa20
	struct AAIController* GetSlotOwnerByIndex(int32_t Index); // Function FortniteAI.AIHotSpot.GetSlotOwnerByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94caf90
	struct FVector GetSlotLocationByIndex(int32_t Index); // Function FortniteAI.AIHotSpot.GetSlotLocationByIndex // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cab90
	int32_t GetSlotIndexByOwner(struct AAIController* AIOwner); // Function FortniteAI.AIHotSpot.GetSlotIndexByOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cb1e0
	int32_t GetSlotCount(enum class EAIHotSpotSlotFilter Filter); // Function FortniteAI.AIHotSpot.GetSlotCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94ca840
	struct UAIHotSpotSlot* GetSlotByOwner(struct AAIController* AIOwner); // Function FortniteAI.AIHotSpot.GetSlotByOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cb350
	struct UAIHotSpotSlot* GetSlotByIndex(int32_t Index); // Function FortniteAI.AIHotSpot.GetSlotByIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cb4d0
	int32_t GetAssignedAICount(enum class EAIHotSpotAssignmentFilter Filter); // Function FortniteAI.AIHotSpot.GetAssignedAICount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94ccc10
	struct TArray<struct AAIController*> GetAssignedAI(enum class EAIHotSpotAssignmentFilter Filter); // Function FortniteAI.AIHotSpot.GetAssignedAI // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94ccf10
	struct TArray<int32_t> FindBestSlotIndices(struct TArray<struct AAIController*> AI); // Function FortniteAI.AIHotSpot.FindBestSlotIndices // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cd080
	int32_t FindBestSlotIndex(struct AAIController* AI); // Function FortniteAI.AIHotSpot.FindBestSlotIndex // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cd230
	bool CanUseSlotByIndex(struct AAIController* AI, int32_t Index); // Function FortniteAI.AIHotSpot.CanUseSlotByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94cd970
	bool AssignToSlotByIndex(struct AAIController* AI, int32_t Index); // Function FortniteAI.AIHotSpot.AssignToSlotByIndex // (Native|Public|BlueprintCallable) // @ game+0x94cd660
	bool AssignToHotspot(struct AAIController* AI); // Function FortniteAI.AIHotSpot.AssignToHotspot // (Native|Public|BlueprintCallable) // @ game+0x3c1aba0
	int32_t AssignGroupToHotspot(struct TArray<struct AAIController*> GroupOfAI); // Function FortniteAI.AIHotSpot.AssignGroupToHotspot // (Native|Public|BlueprintCallable) // @ game+0x94cd7f0
	void AssignFromWaitingList(); // Function FortniteAI.AIHotSpot.AssignFromWaitingList // (Final|Native|Public|BlueprintCallable) // @ game+0x94cd640
};

// Class FortniteAI.AIHotSpotManagerProxy
// Size: 0x80 (Inherited: 0x28)
struct UAIHotSpotManagerProxy : UAIHotSpotManager {
	char pad_28[0x58]; // 0x28(0x58)
};

// Class FortniteAI.AIHotSpotRenderingComponent
// Size: 0x5c0 (Inherited: 0x5c0)
struct UAIHotSpotRenderingComponent : UDebugDrawComponent {
};

// Class FortniteAI.AIHotSpotSlot
// Size: 0x120 (Inherited: 0x28)
struct UAIHotSpotSlot : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FTransform LocalTransform; // 0x30(0x60)
	float Height; // 0x90(0x04)
	float Radius; // 0x94(0x04)
	float DistanceToFocusActor; // 0x98(0x04)
	int32_t UserId; // 0x9c(0x04)
	char bStartEnabled : 1; // 0xa0(0x01)
	char bHasCachedAgentData : 1; // 0xa0(0x01)
	char bHasOverlappingSlots : 1; // 0xa0(0x01)
	char bHasDistanceToFocusActor : 1; // 0xa0(0x01)
	char bIsBlockingOthers : 1; // 0xa0(0x01)
	char bIsEnabled : 1; // 0xa0(0x01)
	char pad_A0_6 : 2; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct AAIController* Owner; // 0xa8(0x08)
	int32_t SlotIndex; // 0xb0(0x04)
	enum class EAIHotSpotSlot SlotState; // 0xb4(0x01)
	char pad_B5[0x6b]; // 0xb5(0x6b)

	void SetSlotState(enum class EAIHotSpotSlot NewState); // Function FortniteAI.AIHotSpotSlot.SetSlotState // (Native|Public|BlueprintCallable) // @ game+0x94d3930
	void SetSlotOwnerAndState(struct AAIController* NewOwner, enum class EAIHotSpotSlot NewState); // Function FortniteAI.AIHotSpotSlot.SetSlotOwnerAndState // (Native|Public|BlueprintCallable) // @ game+0x94d3a20
	void SetSlotEnabled(bool bNewEnabled); // Function FortniteAI.AIHotSpotSlot.SetSlotEnabled // (Native|Public|BlueprintCallable) // @ game+0x94d3840
	void OnStateChanged(struct AAIController* SlotOwner, enum class EAIHotSpotSlot NewState); // Function FortniteAI.AIHotSpotSlot.OnStateChanged // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool IsEnabled(); // Function FortniteAI.AIHotSpotSlot.IsEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3bb0
	bool IsAIAllowed(struct AAIController* AI); // Function FortniteAI.AIHotSpotSlot.IsAIAllowed // (BlueprintAuthorityOnly|Native|Event|Public|BlueprintEvent|Const) // @ game+0x94d3740
	bool HasUserId(); // Function FortniteAI.AIHotSpotSlot.HasUserId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3da0
	int32_t GetSlotUserId(); // Function FortniteAI.AIHotSpotSlot.GetSlotUserId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3dd0
	enum class EAIHotSpotSlot GetSlotState(); // Function FortniteAI.AIHotSpotSlot.GetSlotState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3d80
	struct FRotator GetSlotRotation(); // Function FortniteAI.AIHotSpotSlot.GetSlotRotation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3cf0
	float GetSlotRadius(); // Function FortniteAI.AIHotSpotSlot.GetSlotRadius // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52fbda0
	struct AAIController* GetSlotOwner(); // Function FortniteAI.AIHotSpotSlot.GetSlotOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aedd60
	struct FVector GetSlotLocation(); // Function FortniteAI.AIHotSpotSlot.GetSlotLocation // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3d50
	int32_t GetSlotIndex(); // Function FortniteAI.AIHotSpotSlot.GetSlotIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x35c96f0
	float GetSlotHeight(); // Function FortniteAI.AIHotSpotSlot.GetSlotHeight // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3cd0
	struct FBox GetSlotBounds(); // Function FortniteAI.AIHotSpotSlot.GetSlotBounds // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3be0
	struct AAIHotSpot* GetHotSpot(); // Function FortniteAI.AIHotSpotSlot.GetHotSpot // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3df0
	void ClearSlot(); // Function FortniteAI.AIHotSpotSlot.ClearSlot // (Native|Public|BlueprintCallable) // @ game+0x3e76cb0
};

// Class FortniteAI.AthenaAIBudgetManager
// Size: 0x278 (Inherited: 0x30)
struct UAthenaAIBudgetManager : UWorldSubsystem {
	char pad_30[0x30]; // 0x30(0x30)
	struct TMap<struct TWeakObjectPtr<struct UObject>, struct FAthenaMemoryBudgetInterfaces> StaticallyRegisteredPawns; // 0x60(0x50)
	char pad_B0[0x1c8]; // 0xb0(0x1c8)
};

// Class FortniteAI.FortAIController
// Size: 0x560 (Inherited: 0x3b8)
struct AFortAIController : AAIController {
	char pad_3B8[0x30]; // 0x3b8(0x30)
	char bUsingNavMesh : 1; // 0x3e8(0x01)
	char bAlwaysNotifyBumpWall : 1; // 0x3e8(0x01)
	char bInstantRotation : 1; // 0x3e8(0x01)
	char bTurnTransitionsEnabled : 1; // 0x3e8(0x01)
	char pad_3E8_4 : 4; // 0x3e8(0x01)
	char pad_3E9_0 : 7; // 0x3e9(0x01)
	char bIgnoreAllActorsThatAreNotPawnsOrBuildings : 1; // 0x3e9(0x01)
	char bAllowHotspotAbilityLooping : 1; // 0x3ea(0x01)
	char pad_3EA_1 : 7; // 0x3ea(0x01)
	char pad_3EB[0x5]; // 0x3eb(0x05)
	struct UFortPathFollowingComponent* FortPathFollowingComp; // 0x3f0(0x08)
	struct FAIHotSpotUseInfo CurrentHotSpot; // 0x3f8(0x18)
	struct UFortAthenaAIRuntimeParametersComponent* CachedAIRuntimeParametersComponent; // 0x410(0x08)
	struct UFortAthenaAIRuntimeParameters_AffiliationBase* CachedAffiliationRuntimeParameters; // 0x418(0x08)
	float GoalInfoUpdateRate; // 0x420(0x04)
	char pad_424[0x4]; // 0x424(0x04)
	struct AActor* GoalActor; // 0x428(0x08)
	float GoalVisibilityPersistanceTime; // 0x430(0x04)
	char pad_434[0xcc]; // 0x434(0xcc)
	struct AFortAIPawn* MyFortPawn; // 0x500(0x08)
	struct FMulticastInlineDelegate OnTeamSetDelegate; // 0x508(0x10)
	struct FMulticastInlineDelegate OnControllerComponentAttachedEvent; // 0x518(0x10)
	struct UAIGoalComponent* AIGoalComponent; // 0x528(0x08)
	struct FMulticastInlineDelegate OnControllerNewGoalActorEvent; // 0x530(0x10)
	struct FMulticastInlineDelegate OnPawnKilledEvent; // 0x540(0x10)
	struct UBehaviorTree* BTAssetToRunOnPawnAISpawned; // 0x550(0x08)
	struct UFortGameStateComponent_AffiliationManager* CachedAffiliationManager; // 0x558(0x08)

	void WakeUp(); // Function FortniteAI.FortAIController.WakeUp // (Final|Native|Public|BlueprintCallable) // @ game+0x94fd410
	void UnlockMovementResource(); // Function FortniteAI.FortAIController.UnlockMovementResource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94fdbf0
	void UnlockBehaviorResource(); // Function FortniteAI.FortAIController.UnlockBehaviorResource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94fdbb0
	void SetupCustomVIM(struct UObject* VIM); // Function FortniteAI.FortAIController.SetupCustomVIM // (Final|Native|Public|BlueprintCallable) // @ game+0x94fd450
	void SetTeamInt(char InTeam); // Function FortniteAI.FortAIController.SetTeamInt // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94fd610
	void SetTeam(enum class EFortTeam InTeam); // Function FortniteAI.FortAIController.SetTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x94fd610
	void SetPawnAIType(enum class EFortressAIType NewAIType, struct AActor* SpawnSpot); // Function FortniteAI.FortAIController.SetPawnAIType // (Final|Native|Public|BlueprintCallable) // @ game+0x94fd270
	void SetIsSleeping(bool bNewSleepStatus); // Function FortniteAI.FortAIController.SetIsSleeping // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94fd710
	void SetGoalActor(struct AActor* InActor, bool bLocationAlwaysKnown); // Function FortniteAI.FortAIController.SetGoalActor // (Final|Native|Public|BlueprintCallable) // @ game+0x94fddc0
	void SetFullPeripheralVision(bool bNewFullPeripheralVision); // Function FortniteAI.FortAIController.SetFullPeripheralVision // (Final|Native|Public|BlueprintCallable) // @ game+0x94fd940
	void SetAlwaysGameplayRelevant(bool bInAlwaysGameplayRelevant); // Function FortniteAI.FortAIController.SetAlwaysGameplayRelevant // (Final|Native|Public|BlueprintCallable) // @ game+0x94fda40
	void OnBuildingActorGoalDestroyed(); // Function FortniteAI.FortAIController.OnBuildingActorGoalDestroyed // (Final|Native|Public) // @ game+0x94fdda0
	void OnActorGoalDestroyed(struct AActor* DestroyedActor); // Function FortniteAI.FortAIController.OnActorGoalDestroyed // (Final|Native|Public) // @ game+0x94fdcb0
	void LockMovementResource(); // Function FortniteAI.FortAIController.LockMovementResource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94fdc70
	void LockBehaviorResource(); // Function FortniteAI.FortAIController.LockBehaviorResource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94fdc30
	bool IsIgnoringProximity(struct AFortAIController* FortAIController); // Function FortniteAI.FortAIController.IsIgnoringProximity // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x7bc8c80
	bool IsAllowedToSleep(); // Function FortniteAI.FortAIController.IsAllowedToSleep // (Final|Native|Public|BlueprintCallable) // @ game+0x94fd8f0
	void IgnoreProximityForDuration(float DurationToIgnore); // Function FortniteAI.FortAIController.IgnoreProximityForDuration // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94fd800
	struct AActor* GetGoalActor(); // Function FortniteAI.FortAIController.GetGoalActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94fdf50
	struct UFortAIEncounterInfo* GetEncounterInfo(); // Function FortniteAI.FortAIController.GetEncounterInfo // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94fe270
	bool CreateBuildingActor(struct ABuildingSMActor* BuildingClass, struct FVector BuildLoc, struct FRotator BuildRot, bool bMirrored); // Function FortniteAI.FortAIController.CreateBuildingActor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x94fdf70
	void ClearAllFocalPoints(); // Function FortniteAI.FortAIController.ClearAllFocalPoints // (Final|Native|Public|BlueprintCallable) // @ game+0x94fdb40
};

// Class FortniteAI.AthenaAIController
// Size: 0x5f0 (Inherited: 0x560)
struct AAthenaAIController : AFortAIController {
	char pad_560[0x20]; // 0x560(0x20)
	struct UFortGameplayAbility* PrimaryMeleeAttackAbilityInstance; // 0x580(0x08)
	struct UFortGameplayAbility* PrimaryRangedAttackAbilityInstance; // 0x588(0x08)
	struct FVector NavWalkingSearchExtentScale; // 0x590(0x18)
	float CheapFlyingNavPointHorizontalGridRatio; // 0x5a8(0x04)
	float CheapFlyingNavNavPointVerticalGridRatio; // 0x5ac(0x04)
	struct FGameplayTagContainer CheapFlyingNavSmashableAbilityTag; // 0x5b0(0x20)
	char bEnableCheapFlyingNavigation : 1; // 0x5d0(0x01)
	char bAllowBacktrackPathfinding : 1; // 0x5d0(0x01)
	char bIsGoalRequiredForBehavior : 1; // 0x5d0(0x01)
	char bAutomaticallyChooseClosestTargetAsGoal : 1; // 0x5d0(0x01)
	char bAutoGenerateHotspotOnPlayerBuildings : 1; // 0x5d0(0x01)
	char bAutoAttackOnMovedHit : 1; // 0x5d0(0x01)
	char pad_5D0_6 : 2; // 0x5d0(0x01)
	char pad_5D1_0 : 1; // 0x5d1(0x01)
	char bRegisterToAthenaAIDropper : 1; // 0x5d1(0x01)
	char pad_5D1_2 : 6; // 0x5d1(0x01)
	char pad_5D2[0x6]; // 0x5d2(0x06)
	struct AActor* SecondaryGoalActor; // 0x5d8(0x08)
	char pad_5E0[0x8]; // 0x5e0(0x08)
	struct UAthenaPathFollowingComponent* AthenaPFC; // 0x5e8(0x08)
};

// Class FortniteAI.FortAIPerceptionComponent
// Size: 0x190 (Inherited: 0x188)
struct UFortAIPerceptionComponent : UAIPerceptionComponent {
	float LosingSightRadiusBump; // 0x188(0x04)
	char pad_18C[0x4]; // 0x18c(0x04)
};

// Class FortniteAI.AthenaAIPerceptionComponent
// Size: 0x198 (Inherited: 0x190)
struct UAthenaAIPerceptionComponent : UFortAIPerceptionComponent {
	struct TWeakObjectPtr<struct UFortAthenaAIRuntimeParametersComponent> CachedAIRuntimeParametersComponent; // 0x190(0x08)
};

// Class FortniteAI.FortBehaviorTreeComponent
// Size: 0x298 (Inherited: 0x298)
struct UFortBehaviorTreeComponent : UBehaviorTreeComponent {
};

// Class FortniteAI.AthenaBehaviorTreeComponent
// Size: 0x298 (Inherited: 0x298)
struct UAthenaBehaviorTreeComponent : UFortBehaviorTreeComponent {
};

// Class FortniteAI.FortAIDirector
// Size: 0x1008 (Inherited: 0x290)
struct AFortAIDirector : AActor {
	char pad_290[0x10]; // 0x290(0x10)
	struct FCurveTableRowHandle MaxAliveCurve; // 0x2a0(0x10)
	struct FCurveTableRowHandle MinAliveCurve; // 0x2b0(0x10)
	struct FIntensityData IntensityInfo; // 0x2c0(0x30)
	struct FFortAIEncounterPIDController AIDirectorPIDController; // 0x2f0(0x68)
	struct FFortAIEncounterPIDControllerSettings PIDControllerSettings; // 0x358(0x30)
	struct FUtilityData UtilityContributionData[0x10]; // 0x388(0x400)
	float UnreachableLocationPathCost; // 0x788(0x04)
	char pad_78C[0x4]; // 0x78c(0x04)
	struct FFortPlayerPerformanceEstimateSettings PlayerPerformanceEstimateSettings; // 0x790(0x40)
	char bUsePrototypeEnemies : 1; // 0x7d0(0x01)
	char pad_7D0_1 : 7; // 0x7d0(0x01)
	char pad_7D1[0x3]; // 0x7d1(0x03)
	bool bForceByPassNavMeshForAISpawning; // 0x7d4(0x01)
	char pad_7D5[0x3]; // 0x7d5(0x03)
	struct TArray<enum class EFortEncounterDirection> DebugEncounterDirections; // 0x7d8(0x10)
	enum class EDespawnAIType DespawnAIType; // 0x7e8(0x01)
	char pad_7E9[0x3]; // 0x7e9(0x03)
	float DespawnDistance; // 0x7ec(0x04)
	float DespawnInterval; // 0x7f0(0x04)
	char pad_7F4[0x4]; // 0x7f4(0x04)
	struct FGameplayTagContainer DebugSpawnAIGroupTags; // 0x7f8(0x20)
	struct FGameplayTagContainer DebugEncounterTags; // 0x818(0x20)
	float BurstSpawnThreatVisualsEndDelay; // 0x838(0x04)
	char pad_83C[0x4]; // 0x83c(0x04)
	struct TArray<struct FFortAIEncounterSpawnGroupCapsProfile> EncounterSpawnGroupCapSettings; // 0x840(0x10)
	struct TArray<struct FFortAIEncounterSpawnPointsProfile> EncounterSpawnPointsSettings; // 0x850(0x10)
	struct TArray<struct FFortAIEncounterPawnDifficultyLevelModifier> EncounterPawnDifficultyLevelModifiers; // 0x860(0x10)
	struct TArray<struct FFortAISpawnGroupUpgradeData> SpawnGroupUpgrades; // 0x870(0x10)
	float GuaranteedUpgradeGroupUtilityBonus; // 0x880(0x04)
	float DiscreteEncounterUtilityDesireMappings[0x4]; // 0x884(0x10)
	enum class EFortAIUtility InitialDynamicUtilities[0x4]; // 0x894(0x04)
	struct FEncounterEnvironmentQueryInfo SpawnLocationPlacementQueries[0x4]; // 0x898(0xa0)
	struct FEncounterEnvironmentQueryInfo SpawnLocationActorSearchQueries[0x4]; // 0x938(0xa0)
	struct UFortAIDirectorDataTrackingSettings* DataTrackingSettings; // 0x9d8(0x08)
	struct TArray<struct FDataTableRowHandle> BaseLootDropData; // 0x9e0(0x10)
	struct TArray<struct FFortAILootDropModifiers> LootDropModifiers; // 0x9f0(0x10)
	struct FGameplayTagQuery LootDropDenialQuery; // 0xa00(0x48)
	char bDebugEncounterQueries : 1; // 0xa48(0x01)
	char pad_A48_1 : 7; // 0xa48(0x01)
	char pad_A49[0x17]; // 0xa49(0x17)
	struct TArray<struct AFortPlayerControllerZone*> PlayerControllersForBVTree; // 0xa60(0x10)
	struct TArray<struct AFortPlayerPawn*> PlayerPawnsForBVTree; // 0xa70(0x10)
	char pad_A80[0x30]; // 0xa80(0x30)
	struct TArray<struct AFortAIController*> AIControllersForBVTree; // 0xab0(0x10)
	struct TArray<struct AFortAIPawn*> AIPawnsForBVTree; // 0xac0(0x10)
	char pad_AD0[0x30]; // 0xad0(0x30)
	struct TArray<struct AFortAthenaAIBotController*> AIPlayerBotControllersForBVTree; // 0xb00(0x10)
	struct TArray<struct AFortPlayerPawn*> AIPlayerBotPawnsForBVTree; // 0xb10(0x10)
	char pad_B20[0x30]; // 0xb20(0x30)
	struct TArray<struct AFortAthenaAIBotController*> AINonPlayerBotControllersForBVTree; // 0xb50(0x10)
	struct TArray<struct AFortPlayerPawn*> AINonPlayerBotPawnsForBVTree; // 0xb60(0x10)
	char pad_B70[0x30]; // 0xb70(0x30)
	struct TArray<struct AFortPlayerPawn*> NonPlayerBotPawns; // 0xba0(0x10)
	struct TArray<struct AFortPlayerPawn*> PlayerBotPawns; // 0xbb0(0x10)
	struct TArray<struct AFortPlayerPawn*> PlayerPawns; // 0xbc0(0x10)
	struct TArray<struct AFortAIPawn*> FortAIPawns; // 0xbd0(0x10)
	char pad_BE0[0x100]; // 0xbe0(0x100)
	bool bUseLODSettings; // 0xce0(0x01)
	char pad_CE1[0x6f]; // 0xce1(0x6f)
	struct TScriptInterface<IFortAthenaAILODSettings> CachedLODSettingsManager; // 0xd50(0x10)
	bool bAsyncProcessUpdateAliveAIs; // 0xd60(0x01)
	bool bAllowProcessPlayerTargeting; // 0xd61(0x01)
	char pad_D62[0x2]; // 0xd62(0x02)
	int32_t MaxNumLODAIProcessPerFrame; // 0xd64(0x04)
	struct FFortEncounterPawnNumberCaps DefaultEncounterPawnCaps; // 0xd68(0x18)
	char pad_D80[0x8]; // 0xd80(0x08)
	struct UReporterGraph* IntensityGraph; // 0xd88(0x08)
	struct UReporterGraph* UtilitiesGraph; // 0xd90(0x08)
	struct UReporterGraph* PIDValuesGraph; // 0xd98(0x08)
	struct UReporterGraph* PIDContributionsGraph; // 0xda0(0x08)
	char bNightActive : 1; // 0xda8(0x01)
	char bAIDisabled : 1; // 0xda8(0x01)
	char bRegisteredForDayPhaseChange : 1; // 0xda8(0x01)
	char bUseSpawnCap : 1; // 0xda8(0x01)
	char pad_DA8_4 : 4; // 0xda8(0x01)
	char pad_DA9[0x3]; // 0xda9(0x03)
	int32_t NightCount; // 0xdac(0x04)
	float NightEncounterFailureBreatherTime; // 0xdb0(0x04)
	float EncounterPawnSpawnInterval; // 0xdb4(0x04)
	struct UFortAIEncounterInfo* DefaultNightEncounter; // 0xdb8(0x08)
	struct UFortAIEncounterInfo* DummyDebugEncounter; // 0xdc0(0x08)
	struct UFortAIEncounterInfo* BaseEncounterClass; // 0xdc8(0x08)
	int32_t MaxActiveAlive; // 0xdd0(0x04)
	int32_t NumActiveAlive; // 0xdd4(0x04)
	int32_t NumPendingCapRelevantAI; // 0xdd8(0x04)
	char pad_DDC[0x54]; // 0xddc(0x54)
	struct TArray<struct FPendingSpawnInfo> PendingSpawns; // 0xe30(0x10)
	int32_t MaxAISpawnedPerFrame; // 0xe40(0x04)
	int32_t MaxAIDespawnedPerFrame; // 0xe44(0x04)
	int32_t DespawnAllAIMaxAIDespawnedPerFrame; // 0xe48(0x04)
	char pad_E4C[0x4]; // 0xe4c(0x04)
	struct TArray<struct TWeakObjectPtr<struct AFortAIPawn>> PendingDespawns; // 0xe50(0x10)
	char pad_E60[0x8]; // 0xe60(0x08)
	int32_t NumWorldSubdivides; // 0xe68(0x04)
	float MinAISpawnDistanceFromPlayers; // 0xe6c(0x04)
	struct FGameplayTagContainer AmbientThreatPreferredPlacementActorTags; // 0xe70(0x20)
	struct FGameplayTagContainer AmbientThreatRequiredPlacementActorTags; // 0xe90(0x20)
	struct TArray<struct UFortAIEncounterInfo*> ActiveEncounters; // 0xeb0(0x10)
	struct TArray<struct UFortAIEncounterInfo*> InactiveEncounters; // 0xec0(0x10)
	struct TArray<struct FFortPendingStoppedEncounterData> PendingStoppedEncounters; // 0xed0(0x10)
	struct UFortAIEncounterInfo* ActiveDefaultEncounter; // 0xee0(0x08)
	struct UFortAIEncounterInfo* ActiveDummyDebugEncounter; // 0xee8(0x08)
	struct TArray<struct UFortAIEncounterSequence*> EncounterSequences; // 0xef0(0x10)
	struct UEQSRenderingComponent* EQSRenderingComp; // 0xf00(0x08)
	int32_t DebugGraphUpdateFrequency; // 0xf08(0x04)
	float MaxNormalLODDistanceToPlayer; // 0xf0c(0x04)
	float AIRelevantDistanceToPlayer; // 0xf10(0x04)
	float EncounterRelevantDistanceToPlayer; // 0xf14(0x04)
	float EncounterRelevantDistanceToDefender; // 0xf18(0x04)
	char pad_F1C[0x4]; // 0xf1c(0x04)
	struct TArray<struct TScriptInterface<IFortPatrolWardInterface>> PatrolWards; // 0xf20(0x10)
	char pad_F30[0x4]; // 0xf30(0x04)
	int32_t MaxTotalActiveAliveAI; // 0xf34(0x04)
	int32_t MaxEncounterActiveAliveAI; // 0xf38(0x04)
	int32_t MaxSPUsed; // 0xf3c(0x04)
	char pad_F40[0x8]; // 0xf40(0x08)
	struct TArray<struct FUtilityTypeFloatPair> DebugEncounterTopUtilityPercentages; // 0xf48(0x10)
	struct TArray<struct UCurveFloat*> DebugEncounterSpawnPointsCurves; // 0xf58(0x10)
	char bDebugAllowEncounterModifierTags : 1; // 0xf68(0x01)
	char pad_F68_1 : 7; // 0xf68(0x01)
	char pad_F69[0x3]; // 0xf69(0x03)
	int32_t SimulatedNumberOfPlayersForAIEncounters; // 0xf6c(0x04)
	char pad_F70[0x78]; // 0xf70(0x78)
	int32_t MaxNumberOfEncounterGroups; // 0xfe8(0x04)
	char pad_FEC[0x4]; // 0xfec(0x04)
	struct TArray<struct ABuildingProp_AISpawner*> RegisteredAISpawners; // 0xff0(0x10)
	char pad_1000[0x8]; // 0x1000(0x08)

	void UnregisterPatrolWard(struct TScriptInterface<IFortPatrolWardInterface> PatrolWard); // Function FortniteAI.FortAIDirector.UnregisterPatrolWard // (Final|Native|Public|BlueprintCallable) // @ game+0x9509db0
	struct UFortAIEncounterInfo* StartEncounter(struct FString& EncounterInstigator, struct UFortDifficultyEncounterSettings* DifficultyEncounterSettings, struct FFortAIEncounterQueryData OptionalQueryData); // Function FortniteAI.FortAIDirector.StartEncounter // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x95093c0
	void RegisterPatrolWard(struct TScriptInterface<IFortPatrolWardInterface> PatrolWard); // Function FortniteAI.FortAIDirector.RegisterPatrolWard // (Final|Native|Public|BlueprintCallable) // @ game+0x9509eb0
	void ReceivePawnSpawned(struct AFortPawn* SpawnedPawn); // Function FortniteAI.FortAIDirector.ReceivePawnSpawned // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void PostDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function FortniteAI.FortAIDirector.PostDayPhaseChanged // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnRestStarted(); // Function FortniteAI.FortAIDirector.OnRestStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnRampStarted(); // Function FortniteAI.FortAIDirector.OnRampStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayerSpawn(struct AFortPlayerPawn* PlayerPawn); // Function FortniteAI.FortAIDirector.OnPlayerSpawn // (RequiredAPI|BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPlayerDied(struct AFortPlayerPawn* PlayerPawn); // Function FortniteAI.FortAIDirector.OnPlayerDied // (RequiredAPI|BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPeakStarted(); // Function FortniteAI.FortAIDirector.OnPeakStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPawnDied(struct AFortAIPawn* KilledPawn); // Function FortniteAI.FortAIDirector.OnPawnDied // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnFadeStarted(); // Function FortniteAI.FortAIDirector.OnFadeStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnDirectorDeactivated(); // Function FortniteAI.FortAIDirector.OnDirectorDeactivated // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function FortniteAI.FortAIDirector.OnDayPhaseChanged // (Native|Public) // @ game+0x950ab10
	bool IsPointTooCloseToPatrolWards(struct FVector& Point, enum class EWardAffectType WardEffectTypeFilter); // Function FortniteAI.FortAIDirector.IsPointTooCloseToPatrolWards // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9509c20
	bool IsLineTooCloseToPatrolWards(struct FVector& LineStart, struct FVector& LineEnd); // Function FortniteAI.FortAIDirector.IsLineTooCloseToPatrolWards // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9509a70
	bool IsAnyEncounterGoalWithinDistanceOfPoint(struct FVector& Point, float Distance, bool bOnlyActiveEncounters); // Function FortniteAI.FortAIDirector.IsAnyEncounterGoalWithinDistanceOfPoint // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x950a590
	bool IsAnyAIRelevantToPlayer(struct AFortPlayerPawn* Player); // Function FortniteAI.FortAIDirector.IsAnyAIRelevantToPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x950a7e0
	bool IsAnyActiveEncounterRelevantToPlayer(struct AFortPlayerPawn* Player); // Function FortniteAI.FortAIDirector.IsAnyActiveEncounterRelevantToPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x950a440
	bool IsAnyActiveEncounterRelevantToDefender(struct AFortAIPawn* Defender); // Function FortniteAI.FortAIDirector.IsAnyActiveEncounterRelevantToDefender // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x950a2f0
	struct FVector GetVectorFromEncounterDirection(enum class EFortEncounterDirection Direction); // Function FortniteAI.FortAIDirector.GetVectorFromEncounterDirection // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x950b2f0
	struct TArray<struct ABuildingRift*> GetRiftsFromClosestActiveEncounterTo(struct AActor* Target); // Function FortniteAI.FortAIDirector.GetRiftsFromClosestActiveEncounterTo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x950a0a0
	int32_t GetNumPlayers(); // Function FortniteAI.FortAIDirector.GetNumPlayers // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x87dfc00
	int32_t GetNumActiveEncounters(); // Function FortniteAI.FortAIDirector.GetNumActiveEncounters // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x950aaf0
	enum class EFortEncounterDirection GetEncounterDirectionFromVector(struct FVector DirectionVector); // Function FortniteAI.FortAIDirector.GetEncounterDirectionFromVector // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x950b130
	void GetAmbientThreatEncounterSpawnLocations(struct TArray<struct FVector>& AmbientThreatEncounterSpawnLocations); // Function FortniteAI.FortAIDirector.GetAmbientThreatEncounterSpawnLocations // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x950ad30
	void Deactivate(); // Function FortniteAI.FortAIDirector.Deactivate // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3c1aed0
	struct TArray<enum class EFortEncounterDirection> ConvertInvalidDirectionsToValidDirections(struct TArray<enum class EFortEncounterDirection> InvalidDirections); // Function FortniteAI.FortAIDirector.ConvertInvalidDirectionsToValidDirections // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x950aea0
	void Activate(); // Function FortniteAI.FortAIDirector.Activate // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3bacdc0
};

// Class FortniteAI.AthenaAIDirector
// Size: 0x1010 (Inherited: 0x1008)
struct AAthenaAIDirector : AFortAIDirector {
	char pad_1008[0x8]; // 0x1008(0x08)

	void AggroOnActor(struct AAthenaAIController* AIController, struct AActor* Target); // Function FortniteAI.AthenaAIDirector.AggroOnActor // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x94deb10
};

// Class FortniteAI.AthenaAIDropper
// Size: 0x38 (Inherited: 0x28)
struct UAthenaAIDropper : UObject {
	struct TArray<struct FDroppingAgentData> InactiveAgents; // 0x28(0x10)
};

// Class FortniteAI.AthenaAIPerceptionManager
// Size: 0x48 (Inherited: 0x38)
struct UAthenaAIPerceptionManager : UAISubsystem {
	char pad_38[0x10]; // 0x38(0x10)
};

// Class FortniteAI.AthenaNavSystemConfigOverride
// Size: 0x2a0 (Inherited: 0x2a0)
struct AAthenaNavSystemConfigOverride : ANavSystemConfigOverride {
};

// Class FortniteAI.AthenaAISettingsAIDIrectorLOD
// Size: 0x118 (Inherited: 0x30)
struct UAthenaAISettingsAIDIrectorLOD : UDataAsset {
	struct TArray<struct FPlayerLODViewConeConfig> PlayerLODViewConeConfigs; // 0x30(0x10)
	struct FPlayerLODViewConeHysteresisConfig PlayerLODViewConeHysteresisConfig; // 0x40(0x50)
	struct FScalableFloat CouldBeVisibleViewConeAngleDegrees; // 0x90(0x28)
	struct FScalableFloat CouldBeVisibleMaxDistance; // 0xb8(0x28)
	struct FScalableFloat LODSortHysteresisDistance; // 0xe0(0x28)
	struct TArray<struct FFortAIDirectorPerLODConfig> FortAIDirectorLODConfigs; // 0x108(0x10)
};

// Class FortniteAI.AthenaAISettings
// Size: 0x98 (Inherited: 0x30)
struct UAthenaAISettings : UDataAsset {
	char bAllowAIDirector : 1; // 0x30(0x01)
	char bAllowAIGoalManager : 1; // 0x30(0x01)
	char bForceRVOUse : 1; // 0x30(0x01)
	char pad_30_3 : 5; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float MaxPlayerSpeedScaleFootstepSounds; // 0x34(0x04)
	float MinFootstepHearingRange; // 0x38(0x04)
	float MaxFootstepHearingRange; // 0x3c(0x04)
	float DamagedHearingRange; // 0x40(0x04)
	float CrouchHearingModifier; // 0x44(0x04)
	float MaxNPCHearingRange; // 0x48(0x04)
	float MaxPerceptualStimuliAge; // 0x4c(0x04)
	float DeAggroRange; // 0x50(0x04)
	float ReducedDeAggroRange; // 0x54(0x04)
	float DurationReduceAggroLimits; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct AAthenaNavSystemConfigOverride* NavigationSystemConfig; // 0x60(0x08)
	struct TSoftObjectPtr<UAthenaAISettingsAIDIrectorLOD> AIDIrectorLOD; // 0x68(0x20)
	struct TArray<struct UAthenaAIService*> AIServices; // 0x88(0x10)
};

// Class FortniteAI.FortAISystem
// Size: 0x218 (Inherited: 0x178)
struct UFortAISystem : UAISystem {
	struct TArray<struct UFortQueryTwoPointSolver*> TwoPointSolvers; // 0x178(0x10)
	struct UFortInfluenceMap* InfluenceMap; // 0x188(0x08)
	struct UFortBotMissionManager* BotManager; // 0x190(0x08)
	char pad_198[0x10]; // 0x198(0x10)
	struct TArray<struct UFortRiftBlockerComponent*> ActiveRiftBlockers; // 0x1a8(0x10)
	char pad_1B8[0x50]; // 0x1b8(0x50)
	struct UAthenaAISpawner* AISpawner; // 0x208(0x08)
	struct UAthenaAIServiceManager* AIServiceManager; // 0x210(0x08)

	bool IsInCone2D(struct FVector ConeOrigin, struct FVector ConeDirection, float HalfAngle, struct FVector LocationToCheck); // Function FortniteAI.FortAISystem.IsInCone2D // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x955abe0
};

// Class FortniteAI.AthenaAISystem
// Size: 0x270 (Inherited: 0x218)
struct UAthenaAISystem : UFortAISystem {
	struct UAthenaAIPerceptionManager* PerceptionManager; // 0x218(0x08)
	struct UAthenaAIDropper* AIDropper; // 0x220(0x08)
	struct UAthenaAIPopulationTracker* AIPopulationTracker; // 0x228(0x08)
	struct UAthenaAIVehicleAvoidanceManager* AIVehicleAvoidanceManager; // 0x230(0x08)
	struct TArray<struct AAthenaAIController*> AIControllers; // 0x238(0x10)
	struct TArray<struct UAthenaPathFollowingComponent*> PathFollowingComponents; // 0x248(0x10)
	struct TArray<struct AActor*> RegisteredAISpawners; // 0x258(0x10)
	char bUnlimitedAIHealth : 1; // 0x268(0x01)
	char bNavigationReady : 1; // 0x268(0x01)
	char pad_268_2 : 6; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)

	void OnAIPawnSpawned(struct AController* SpawnedController, bool bIsABot, struct AFortPawn* FortAIPawn, struct AFortPlayerPawn* PlayerPawn); // Function FortniteAI.AthenaAISystem.OnAIPawnSpawned // (Final|Native|Protected) // @ game+0x94e1400
	void OnAIPawnDied(struct AController* KilledController, bool bIsABot, struct AFortPawn* KilledAIPawn, struct AFortPlayerPawn* KilledPlayerPawn, struct AController* KillerController); // Function FortniteAI.AthenaAISystem.OnAIPawnDied // (Final|Native|Protected) // @ game+0x94e10a0
	void OnAIPawnDestroyed(struct AFortPawn* DestroyedPawn); // Function FortniteAI.AthenaAISystem.OnAIPawnDestroyed // (Final|Native|Protected) // @ game+0x34e0930
	void HandlePlayerExitAircraft(struct AController* ExitingController); // Function FortniteAI.AthenaAISystem.HandlePlayerExitAircraft // (Final|Native|Protected) // @ game+0x94e0c70
	void HandleGamePhaseStepChanged(struct TScriptInterface<IFortSafeZoneInterface>& SafeZoneInterface, enum class EAthenaGamePhaseStep GamePhaseStep); // Function FortniteAI.AthenaAISystem.HandleGamePhaseStepChanged // (Final|Native|Protected|HasOutParms) // @ game+0x94e0da0
	void AIProfiling_OnSafeZoneUpdated(struct FFortSafeZonePhaseUpdatedEvent& Event); // Function FortniteAI.AthenaAISystem.AIProfiling_OnSafeZoneUpdated // (Final|Native|Public|HasOutParms) // @ game+0x94e16d0
	void AIProfiling_OnGamePhaseChanged(struct FFortGamePhaseUpdatedEvent& Event); // Function FortniteAI.AthenaAISystem.AIProfiling_OnGamePhaseChanged // (Final|Native|Public|HasOutParms) // @ game+0x78744d0
};

// Class FortniteAI.AthenaCreativeRift
// Size: 0xc20 (Inherited: 0xb30)
struct AAthenaCreativeRift : ABuildingRift {
	struct USphereComponent* DespawnSphereComponent; // 0xb28(0x08)
	struct ABuildingProp_AISpawner* ParentTrap; // 0xb30(0x08)
	struct FFortEncounterSettings OverrideEncounterSettings; // 0xb38(0xc0)
	bool bHasLoadedSettings; // 0xbf8(0x01)
	struct TArray<struct AFortPlayerPawn*> DespawnPlayerOverlaps; // 0xc00(0x10)
	char pad_C11[0x7]; // 0xc11(0x07)
	struct UFortAIManagerMinigameComponent* CachedAIMinigamecomponent; // 0xc18(0x08)

	void NotifyActorDespawnEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function FortniteAI.AthenaCreativeRift.NotifyActorDespawnEndOverlap // (Final|Native|Public) // @ game+0x94e3dc0
	void BlueprintShowRift(); // Function FortniteAI.AthenaCreativeRift.BlueprintShowRift // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class FortniteAI.FortPathFollowingComponentBase
// Size: 0x338 (Inherited: 0x318)
struct UFortPathFollowingComponentBase : UCrowdFollowingComponent {
	struct AAIController* AIController; // 0x318(0x08)
	char pad_320[0x18]; // 0x320(0x18)
};

// Class FortniteAI.FortPathFollowingComponent
// Size: 0x428 (Inherited: 0x338)
struct UFortPathFollowingComponent : UFortPathFollowingComponentBase {
	struct AFortAIController* MyAI; // 0x338(0x08)
	char pad_340[0x20]; // 0x340(0x20)
	float MovementBlockFrustrationCooldownSpeed; // 0x360(0x04)
	char pad_364[0xc4]; // 0x364(0xc4)
};

// Class FortniteAI.AthenaPathFollowingComponent
// Size: 0x468 (Inherited: 0x428)
struct UAthenaPathFollowingComponent : UFortPathFollowingComponent {
	enum class EAthenaPathFollowingFocus FocusDirectionMethod; // 0x428(0x01)
	char pad_429[0x1f]; // 0x429(0x1f)
	struct AAthenaAIController* AthenaAIController; // 0x448(0x08)
	char pad_450[0x18]; // 0x450(0x18)
};

// Class FortniteAI.FortAthenaAITelemetryFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaAITelemetryFunctionLibrary : UBlueprintFunctionLibrary {

	struct UFortAthenaAITelemetryData* GetOrCreateAITelemetryData(struct AActor* Owner, struct UFortAthenaAITelemetryData* TelemetryDataClass); // Function FortniteAI.FortAthenaAITelemetryFunctionLibrary.GetOrCreateAITelemetryData // (Final|BlueprintAuthorityOnly|Native|Static|Private|BlueprintCallable) // @ game+0x94e98b0
};

// Class FortniteAI.FortAthenaAITelemetryData
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaAITelemetryData : UObject {
};

// Class FortniteAI.FortAIComponent_Telemetry
// Size: 0x108 (Inherited: 0xa0)
struct UFortAIComponent_Telemetry : UActorComponent {
	struct AFortAIPawn* PossessedPawn; // 0xa0(0x08)
	struct AAthenaAIController* CachedAIController; // 0xa8(0x08)
	struct AController* DeathInstigator; // 0xb0(0x08)
	struct TArray<struct UFortItemDefinition*> GrabbedPickups; // 0xb8(0x10)
	struct TArray<struct UFortItemDefinition*> DroppedPickups; // 0xc8(0x10)
	struct UFortAthenaAIRuntimeParameters_AIAnalytic* AnalyticRuntimeParameters; // 0xd8(0x08)
	struct TArray<struct UFortAthenaAITelemetryData*> TelemetryData; // 0xe0(0x10)
	char pad_F0[0x18]; // 0xf0(0x18)

	void OnTetheredFollowerChanged(struct AFortPawn* NewFollower, struct AFortPawn* OldFollower); // Function FortniteAI.FortAIComponent_Telemetry.OnTetheredFollowerChanged // (Final|Native|Private) // @ game+0x94ea240
	void OnPawnDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAIComponent_Telemetry.OnPawnDied // (Final|Native|Private|HasDefaults) // @ game+0x94e9d00
	void OnDidDamage(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAIComponent_Telemetry.OnDidDamage // (Final|Native|Private|HasDefaults) // @ game+0x94ea580
	struct UFortAthenaAITelemetryData* GetOrCreateTelemetryData(struct UFortAthenaAITelemetryData* TelemetryDataClass); // Function FortniteAI.FortAIComponent_Telemetry.GetOrCreateTelemetryData // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x94eabc0
};

// Class FortniteAI.FortAIComponent_Voice
// Size: 0xa8 (Inherited: 0xa0)
struct UFortAIComponent_Voice : UActorComponent {
	struct UFortTaggedSoundBank* VoiceSoundBank; // 0xa0(0x08)

	void SetVoiceSoundBank(struct UFortTaggedSoundBank* InSoundBank); // Function FortniteAI.FortAIComponent_Voice.SetVoiceSoundBank // (Final|Native|Public|BlueprintCallable) // @ game+0x94f3160
	struct UFortTaggedSoundBank* GetVoiceSoundBank(); // Function FortniteAI.FortAIComponent_Voice.GetVoiceSoundBank // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3aedd40
};

// Class FortniteAI.FortAIManagerMinigameComponent
// Size: 0x110 (Inherited: 0xa0)
struct UFortAIManagerMinigameComponent : UActorComponent {
	char pad_A0[0x60]; // 0xa0(0x60)
	struct TArray<struct FGameplayTag> SpawnableAITypeTags; // 0x100(0x10)

	void OnPawnSpawned(struct APawn* Pawn, int32_t RequestID); // Function FortniteAI.FortAIManagerMinigameComponent.OnPawnSpawned // (Final|Native|Public) // @ game+0x94f4230
	void OnPawnDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAIManagerMinigameComponent.OnPawnDied // (Final|Native|Public|HasDefaults) // @ game+0x94f3b90
	void HandleMinigameStarted(); // Function FortniteAI.FortAIManagerMinigameComponent.HandleMinigameStarted // (Final|Native|Public) // @ game+0x94f43b0
	struct FGameplayTag GetSpawnTagFromPawnObject(struct UObject* PawnObject); // Function FortniteAI.FortAIManagerMinigameComponent.GetSpawnTagFromPawnObject // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x94f3aa0
};

// Class FortniteAI.FortAISpawnerUtilityComponent
// Size: 0x130 (Inherited: 0xa0)
struct UFortAISpawnerUtilityComponent : UActorComponent {
	struct FGameplayTag AIPawnSpawnTypeTag; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct UEnvQuery* EnvironmentQuery; // 0xa8(0x08)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0xb0(0x10)
	float QueryRadius; // 0xc0(0x04)
	float QueryMinDistance; // 0xc4(0x04)
	struct FMulticastInlineDelegate OnEnvironmentQueryFinishedDelegate; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnUnownedPawnDiedDelegate; // 0xd8(0x10)
	char pad_E8[0x10]; // 0xe8(0x10)
	struct TArray<struct FVector> FreeSpawnSlots; // 0xf8(0x10)
	char pad_108[0x18]; // 0x108(0x18)
	struct TScriptInterface<IFortSpatialGameplayInterface> CachedFortSpatialGameplay; // 0x120(0x10)

	void StartEnvironmentQuery(); // Function FortniteAI.FortAISpawnerUtilityComponent.StartEnvironmentQuery // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94f6bc0
	void SetQueryRadius(float Radius); // Function FortniteAI.FortAISpawnerUtilityComponent.SetQueryRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x94f6be0
	void SetMinigame(struct AFortMinigame* Minigame); // Function FortniteAI.FortAISpawnerUtilityComponent.SetMinigame // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94f6e50
	void SetEQSQuery(struct TSoftObjectPtr<UEnvQuery> SelectedEQSQuery); // Function FortniteAI.FortAISpawnerUtilityComponent.SetEQSQuery // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94f6cd0
	int32_t RequestSpawn(struct UFortAthenaAISpawnerDataComponentList* AISpawnerComponentList, struct FTransform& SpawnTransform); // Function FortniteAI.FortAISpawnerUtilityComponent.RequestSpawn // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x94f6760
	void OnUnownedPawnDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAISpawnerUtilityComponent.OnUnownedPawnDied // (Final|Native|Private|HasDefaults) // @ game+0x94f5d50
	bool IsSpawnCountCapped(); // Function FortniteAI.FortAISpawnerUtilityComponent.IsSpawnCountCapped // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x42ab9f0
	void HandleUnownedPawnSpawned(struct AFortPawn* FortPawn); // Function FortniteAI.FortAISpawnerUtilityComponent.HandleUnownedPawnSpawned // (Final|Native|Public|BlueprintCallable) // @ game+0x94f6310
};

// Class FortniteAI.FortPawnComponent_AIInventoryManagement
// Size: 0xc8 (Inherited: 0xa8)
struct UFortPawnComponent_AIInventoryManagement : UFortPawnComponent {
	struct FGameplayTagContainer CanEquipItemTags; // 0xa8(0x20)
};

// Class FortniteAI.FortAIDataProvider_Ability
// Size: 0x70 (Inherited: 0x28)
struct UFortAIDataProvider_Ability : UAIDataProvider {
	struct FGameplayTagContainer AbilityTag; // 0x28(0x20)
	struct FGameplayTagContainer AbilityBehaviorDistanceTag; // 0x48(0x20)
	float BehaviorDistance; // 0x68(0x04)
	float MaxTargetSelectionRange; // 0x6c(0x04)
};

// Class FortniteAI.FortAIDataProvider_AIDirector
// Size: 0x30 (Inherited: 0x28)
struct UFortAIDataProvider_AIDirector : UAIDataProvider {
	float AIRelevantDistanceToPlayer; // 0x28(0x04)
	float EncounterRelevantDistanceToPlayer; // 0x2c(0x04)
};

// Class FortniteAI.FortAIDataProvider_FloatCurveOverGameDifficulty
// Size: 0x58 (Inherited: 0x28)
struct UFortAIDataProvider_FloatCurveOverGameDifficulty : UAIDataProvider {
	struct FScalableFloat ScalableFloat; // 0x28(0x28)
	float FloatValue; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class FortniteAI.FortAIDataProvider_GoalProviderAbility
// Size: 0x70 (Inherited: 0x70)
struct UFortAIDataProvider_GoalProviderAbility : UFortAIDataProvider_Ability {
};

// Class FortniteAI.FortAIDataProvider_Pawn
// Size: 0x60 (Inherited: 0x28)
struct UFortAIDataProvider_Pawn : UAIDataProvider {
	float SightRadius; // 0x28(0x04)
	float HearingRadius; // 0x2c(0x04)
	float ViewLocationOffsetFromGround; // 0x30(0x04)
	float MaxStepHeight; // 0x34(0x04)
	struct FVector TetheredBoxCenterLocation; // 0x38(0x18)
	float TetheredBoxWidth; // 0x50(0x04)
	float TetheredBoxHeight; // 0x54(0x04)
	float TetheredBoxEQSGridSize; // 0x58(0x04)
	float TetheredBoxEQSSpaceBetween; // 0x5c(0x04)
};

// Class FortniteAI.FortAIDataProvider_ScalableFloat
// Size: 0x60 (Inherited: 0x28)
struct UFortAIDataProvider_ScalableFloat : UAIDataProvider {
	struct FScalableFloat ScalableFloat; // 0x28(0x28)
	float FloatValue; // 0x50(0x04)
	int32_t IntValue; // 0x54(0x04)
	bool BoolValue; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class FortniteAI.FortAIAssetLoader
// Size: 0x50 (Inherited: 0x28)
struct UFortAIAssetLoader : UObject {
	struct TArray<struct FPendingRequestManager> PendingRequests; // 0x28(0x10)
	struct TArray<struct UObject*> AssetsLoaded; // 0x38(0x10)
	char pad_48[0x8]; // 0x48(0x08)
};

// Class FortniteAI.FortAIAssignment
// Size: 0xd8 (Inherited: 0x28)
struct UFortAIAssignment : UObject {
	struct FFortAIAssignmentIdentifier AssignmentIdentifier; // 0x28(0x30)
	struct UFortAIAssignmentSettings* AssignmentSettings; // 0x58(0x08)
	struct UFortAIGoalProvider* GoalProvider; // 0x60(0x08)
	struct TArray<struct TWeakObjectPtr<struct UAIGoalComponent>> GoalComponentsOnAssignment; // 0x68(0x10)
	char pad_78[0x50]; // 0x78(0x50)
	struct TArray<struct FFortAIGoal> Goals; // 0xc8(0x10)
};

// Class FortniteAI.FortAIAssignmentSettings
// Size: 0x90 (Inherited: 0x30)
struct UFortAIAssignmentSettings : UDataAsset {
	struct TArray<struct FGoalSelectionQueryInfo> GoalSelectionQueryInfos; // 0x30(0x10)
	bool bGoalLocationsAlwaysKnown; // 0x40(0x01)
	bool bIsEnemyAssignment; // 0x41(0x01)
	char pad_42[0x6]; // 0x42(0x06)
	struct FGameplayTagContainer RequiredTags; // 0x48(0x20)
	struct FGameplayTagContainer ProhibitedTags; // 0x68(0x20)
	float MaxAIAllowedForAssignment; // 0x88(0x04)
	float MaxAIAllowedPerGoal; // 0x8c(0x04)
};

// Class FortniteAI.FortAIBotDebugActor
// Size: 0x298 (Inherited: 0x290)
struct AFortAIBotDebugActor : AActor {
	struct UAthenaAIBotDebugMiniMapIndicator* BotDebugMiniMapIndicator; // 0x290(0x08)

	void OnRep_BotDebugMiniMapIndicator(struct UAthenaAIBotDebugMiniMapIndicator* OldBotDebugMiniMap); // Function FortniteAI.FortAIBotDebugActor.OnRep_BotDebugMiniMapIndicator // (Final|Native|Private) // @ game+0x34e0930
};

// Class FortniteAI.FortAIBotPOIDebugActor
// Size: 0x298 (Inherited: 0x290)
struct AFortAIBotPOIDebugActor : AActor {
	struct UAthenaAIBotPOIDebugMiniMapIndicator* BotPOIDebugMiniMapIndicator; // 0x290(0x08)

	void OnRep_PlayerBotsDebugMiniMap(struct UAthenaAIBotPOIDebugMiniMapIndicator* OldPlayerBotsDebugMiniMap); // Function FortniteAI.FortAIBotPOIDebugActor.OnRep_PlayerBotsDebugMiniMap // (Final|Native|Private) // @ game+0x34e0930
};

// Class FortniteAI.FortAICustomTargetingComponent
// Size: 0x100 (Inherited: 0xa0)
struct UFortAICustomTargetingComponent : UActorComponent {
	struct TArray<struct FAICustomTargetConfiguration> Configurations; // 0xa0(0x10)
	char pad_B0[0x50]; // 0xb0(0x50)
};

// Class FortniteAI.FortAIDirectorLODAIConfig
// Size: 0x78 (Inherited: 0x28)
struct UFortAIDirectorLODAIConfig : UObject {
	struct FScalableFloat SingleAIUnitCost; // 0x28(0x28)
	struct FScalableFloat Priority; // 0x50(0x28)
};

// Class FortniteAI.FortAIDirectorDataManager
// Size: 0x370 (Inherited: 0x290)
struct AFortAIDirectorDataManager : AActor {
	struct UObject* OwnerObject; // 0x290(0x08)
	struct TArray<struct FAIDirectorEventData> EventsToTrack; // 0x298(0x10)
	struct TArray<struct FFortAIDirectorFactorData> FactorsToTrack; // 0x2a8(0x10)
	char pad_2B8[0xa0]; // 0x2b8(0xa0)
	struct TArray<enum class EFortAIDirectorFactor> FactorsBeingTracked; // 0x358(0x10)
	char pad_368[0x8]; // 0x368(0x08)

	void TriggerEvent(struct FFortAIDirectorEvent& TriggeredEvent); // Function FortniteAI.FortAIDirectorDataManager.TriggerEvent // (Native|Public|HasOutParms) // @ game+0x95193b0
	float GetAIDirectorFactorValue(enum class EFortAIDirectorFactor AIDirectorFactor); // Function FortniteAI.FortAIDirectorDataManager.GetAIDirectorFactorValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9519240
};

// Class FortniteAI.FortAIDirectorDataTrackingSettings
// Size: 0x40 (Inherited: 0x30)
struct UFortAIDirectorDataTrackingSettings : UDataAsset {
	struct AFortAIDirectorDataManager* PlayerDataManager; // 0x30(0x08)
	struct AFortAIDirectorDataManager* EncounterDataManager; // 0x38(0x08)
};

// Class FortniteAI.FortAIDirectorEventManager
// Size: 0x2e0 (Inherited: 0x290)
struct AFortAIDirectorEventManager : AActor {
	char pad_290[0x50]; // 0x290(0x50)
};

// Class FortniteAI.FortAIEncounterInfo
// Size: 0xd98 (Inherited: 0x28)
struct UFortAIEncounterInfo : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct UFortAISpawnGroupProgressionInfo* SpawnGroupProgressionInfo; // 0x38(0x08)
	struct FFortSpawnPointsPercentageCurveSequenceInstanceInfo SpawnPointsPercentageCurveSequence; // 0x40(0x10)
	struct FFortIntensityCurveSequenceInstanceInfo IntensityCurveSequence; // 0x50(0x10)
	float BurstSpawnPointsPercentage; // 0x60(0x04)
	float SpawnPointsMultiplier; // 0x64(0x04)
	bool bUseBreathers; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FCurveTableRowHandle LowPlayerPerformanceBreatherTimeSecondsCurve; // 0x70(0x10)
	struct FCurveTableRowHandle NormalPlayerPerformanceBreatherTimeSecondsCurve; // 0x80(0x10)
	struct FCurveTableRowHandle HighPlayerPerformanceBreatherTimeSecondsCurve; // 0x90(0x10)
	float EncounterTimeSeconds; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct TArray<struct FUtilityTypeFloatPair> LockedUtilityValues; // 0xa8(0x10)
	int32_t NumFreeUtilities; // 0xb8(0x04)
	float UtilityAdjustmentPeriodSeconds; // 0xbc(0x04)
	float MinSpawnDistance; // 0xc0(0x04)
	float MaxSpawnDistance; // 0xc4(0x04)
	int32_t NumDirections; // 0xc8(0x04)
	bool bChangeDirectionsOnRest; // 0xcc(0x01)
	char pad_CD[0x3]; // 0xcd(0x03)
	float SpawnPointsPercentageLimit; // 0xd0(0x04)
	int32_t PawnNumberLimit; // 0xd4(0x04)
	struct FFortEncounterPawnNumberCaps PawnNumberCaps; // 0xd8(0x18)
	float SpawningIntervalSeconds; // 0xf0(0x04)
	float PreSpawnRequeryTime; // 0xf4(0x04)
	struct FFortEncounterSettingsFixedPace EncounterSettingsFixed; // 0xf8(0x14)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct FMulticastInlineDelegate OnEncounterSpawnDirectionsChosen; // 0x110(0x10)
	float NextRiftReplacementTime; // 0x120(0x04)
	float NextSpawningTime; // 0x124(0x04)
	struct FFortAIEncounterSpawnGroupCapsProfile EncounterSpawnGroupCapsProfile; // 0x128(0x30)
	struct TArray<struct FFortAIEncounterSpawnGroupCapsCategory> AdditionalSpawnGroupCapsCategories; // 0x158(0x10)
	struct FFortAIEncounterSpawnPointsProfile EncounterSpawnPointsProfile; // 0x168(0x40)
	struct TArray<struct FFortAISpawnGroupUpgradeData> AvailableUpgrades; // 0x1a8(0x10)
	struct TArray<struct FCurveTableRowHandle> PawnDifficultyLevelModifiers; // 0x1b8(0x10)
	struct TArray<struct FFortAIBaseLootDropRow> BaseLootDropRows; // 0x1c8(0x10)
	struct TArray<struct FFortAILootDropModifierRow> LootDropModifierRows; // 0x1d8(0x10)
	bool bRequiresReinitializationFromProfile; // 0x1e8(0x01)
	char pad_1E9[0x7]; // 0x1e9(0x07)
	struct FCurveTableRowHandle DesiredHostilityCurve; // 0x1f0(0x10)
	struct UFortIntensityCurveSequenceProgression* IntensitySequenceProgression; // 0x200(0x08)
	char pad_208[0x70]; // 0x208(0x70)
	float AliveMultiplier; // 0x278(0x04)
	enum class EFortEncounterSpawnLimitType SpawnLimitType; // 0x27c(0x01)
	char pad_27D[0x3]; // 0x27d(0x03)
	int32_t SpawnLimit; // 0x280(0x04)
	int32_t PawnNumberLimitProgress; // 0x284(0x04)
	int32_t SpawnPointsLimitProgress; // 0x288(0x04)
	bool bSpawnLimitReached; // 0x28c(0x01)
	bool bHasSpawnedAllBurstSpawnAI; // 0x28d(0x01)
	bool bOverrideAliveCounts; // 0x28e(0x01)
	char pad_28F[0x1]; // 0x28f(0x01)
	int32_t MinAliveOverride; // 0x290(0x04)
	int32_t MaxAliveOverride; // 0x294(0x04)
	float HostilityThreshold; // 0x298(0x04)
	float PeakTimeSeconds; // 0x29c(0x04)
	float BreatherTimeSeconds; // 0x2a0(0x04)
	float MaxRampTimeSeconds; // 0x2a4(0x04)
	float MinTimeBetweenBreathesSeconds; // 0x2a8(0x04)
	float MaxFadeTimeSeconds; // 0x2ac(0x04)
	float FadeEndIntensity; // 0x2b0(0x04)
	float FadeEndRemainingSpawnPointsPercentage; // 0x2b4(0x04)
	float CompletionPercentageToDisableBreathers; // 0x2b8(0x04)
	char pad_2BC[0x4]; // 0x2bc(0x04)
	struct FMulticastInlineDelegate OnEncounterAllEnemiesKilled; // 0x2c0(0x10)
	struct FMulticastInlineDelegate OnEncounterEnemySpawned; // 0x2d0(0x10)
	struct FMulticastInlineDelegate OnEncounterEnemySpawnFailed; // 0x2e0(0x10)
	struct FMulticastInlineDelegate OnEncounterAllBurstEnemiesSpawned; // 0x2f0(0x10)
	struct FMulticastInlineDelegate OnEncounterCompleted; // 0x300(0x10)
	struct FMulticastInlineDelegate OnEncounterPawnDied; // 0x310(0x10)
	struct FMulticastInlineDelegate OnEncounterSpawnedFinalEnemy; // 0x320(0x10)
	struct FMulticastInlineDelegate OnEncounterRiftSpawned; // 0x330(0x10)
	struct FMulticastInlineDelegate OnBuildingRiftBlockedShouldDie; // 0x340(0x10)
	char pad_350[0x3]; // 0x350(0x03)
	bool bDisplayThreatVisuals; // 0x353(0x01)
	float BaseDesiredUtilities[0x10]; // 0x354(0x40)
	char pad_394[0x4]; // 0x394(0x04)
	struct FGameplayTagContainer UtilitiesRequiredTags[0x10]; // 0x398(0x200)
	struct FGameplayTagContainer InjectedTagForUtilityCheck; // 0x598(0x20)
	char pad_5B8[0x4]; // 0x5b8(0x04)
	float MaxLargeSpawnGroupDiscountInterval; // 0x5bc(0x04)
	float MaxSelectionToSpawningDelay; // 0x5c0(0x04)
	char pad_5C4[0x54]; // 0x5c4(0x54)
	struct TArray<struct FUtilityTypeFloatPair> CurrentDesiredUtilities; // 0x618(0x10)
	float UtilityRecentSelectionPenalties[0x10]; // 0x628(0x40)
	float UtilityEffectivenessMeasurements[0x10]; // 0x668(0x40)
	struct FCurveTableRowHandle UtilityEffectivenessMultiplierCurve; // 0x6a8(0x10)
	float UtilityEffectivenessInfluenceCap; // 0x6b8(0x04)
	char pad_6BC[0x4]; // 0x6bc(0x04)
	struct TArray<struct FUtilityTypeFloatPair> CurrentTopUtilityPercentages; // 0x6c0(0x10)
	struct TArray<enum class EFortAIUtility> UsedTopUtilities; // 0x6d0(0x10)
	struct TArray<enum class EFortAIUtility> CurrentlySelectedFreeUtilities; // 0x6e0(0x10)
	int32_t NumUtilitiesConsidered; // 0x6f0(0x04)
	float ReactivityPercentage; // 0x6f4(0x04)
	bool bAdjustUtilitiesDuringRest; // 0x6f8(0x01)
	bool bDespawnAIsDuringRest; // 0x6f9(0x01)
	char pad_6FA[0x2]; // 0x6fa(0x02)
	float LastPlayerCombatFactorUpdateTime; // 0x6fc(0x04)
	float LastUtilityAdjustTime; // 0x700(0x04)
	float LastSpawnPointAdjustmentTime; // 0x704(0x04)
	float LastLargeGroupSpawnTime; // 0x708(0x04)
	char pad_70C[0x4]; // 0x70c(0x04)
	struct TArray<struct FAIEncounterSpawnGroupWeights> EnemySpawnData; // 0x710(0x10)
	struct FFortAIEncounterPIDController EncounterPIDController; // 0x720(0x68)
	int32_t CurrentSpawnPointsCap; // 0x788(0x04)
	int32_t CurrentSpawnPointsUsed; // 0x78c(0x04)
	char pad_790[0x8]; // 0x790(0x08)
	int32_t FailSafeMinSpawnPoints; // 0x798(0x04)
	char pad_79C[0x4]; // 0x79c(0x04)
	struct TArray<struct FSpawnGroupInstanceInfo> ActiveSpawnGroups; // 0x7a0(0x10)
	float EncounterEngagementDistance; // 0x7b0(0x04)
	float MinRelevantBuildingDamagedDistance; // 0x7b4(0x04)
	float MaxRelevantBuildingDamagedDistance; // 0x7b8(0x04)
	char pad_7BC[0x14]; // 0x7bc(0x14)
	struct AActor* CurrentGroupSpawnPoint; // 0x7d0(0x08)
	enum class EFortEncounterState EncounterState; // 0x7d8(0x01)
	enum class EFortEncounterPacingState PacingState; // 0x7d9(0x01)
	char pad_7DA[0x2]; // 0x7da(0x02)
	float LastPacingStateTransitionTime; // 0x7dc(0x04)
	struct FFortAIEncounterWaveProgressEstimation WaveProgressEstimate; // 0x7e0(0x1c)
	float DesiredDifficultyLevel; // 0x7fc(0x04)
	float DifficultyLevelOverride; // 0x800(0x04)
	char pad_804[0x4]; // 0x804(0x04)
	struct AFortAIDirector* MyAIDirector; // 0x808(0x08)
	struct TArray<struct FFortGoalActorEncounterDataManagerPair> DataManagers; // 0x810(0x10)
	struct AActor* TargetObjective; // 0x820(0x08)
	bool bOnlyActiveAtNight; // 0x828(0x01)
	char pad_829[0x3]; // 0x829(0x03)
	int32_t NumRiftsToUse; // 0x82c(0x04)
	int32_t MinRiftsToUse; // 0x830(0x04)
	int32_t NumRiftsUsed; // 0x834(0x04)
	struct FFortEncounterSettings EncounterSettings; // 0x838(0xc0)
	float EncounterStartTime; // 0x8f8(0x04)
	float HostilityCurveStartTime; // 0x8fc(0x04)
	struct FEncounterEnvironmentQueryInfo DefaultEnvironmentQueryInfo; // 0x900(0x28)
	struct FEncounterEnvironmentQueryInfo FallbackEnvironmentQueryInfo; // 0x928(0x28)
	struct FEncounterEnvironmentQueryInfo OverrideEnvironmentQueryInfo; // 0x950(0x28)
	struct FEncounterEnvironmentQueryInfo CurrentEnvironmentQueryInfo; // 0x978(0x28)
	bool bNukeWavesAtDaybreak; // 0x9a0(0x01)
	bool bNukeWavesAtEncounterEnd; // 0x9a1(0x01)
	bool bNukeWavesAtEncounterDeactivation; // 0x9a2(0x01)
	char pad_9A3[0x1]; // 0x9a3(0x01)
	int32_t ActiveEnemyCap; // 0x9a4(0x04)
	char pad_9A8[0x8]; // 0x9a8(0x08)
	float CurrentHostilityLevel; // 0x9b0(0x04)
	char pad_9B4[0x4]; // 0x9b4(0x04)
	struct FMulticastInlineDelegate OnEncounterRampStarted; // 0x9b8(0x10)
	struct FMulticastInlineDelegate OnEncounterPeakStarted; // 0x9c8(0x10)
	struct FMulticastInlineDelegate OnEncounterFadeStarted; // 0x9d8(0x10)
	struct FMulticastInlineDelegate OnEncounterRestStarted; // 0x9e8(0x10)
	struct FMulticastInlineDelegate OnEncounterCombatParticipation; // 0x9f8(0x10)
	struct FMulticastInlineDelegate OnEncounterOptionsChanged; // 0xa08(0x10)
	struct ABuildingRift* RiftClassTemplate; // 0xa18(0x08)
	char pad_A20[0x20]; // 0xa20(0x20)
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct FFortAISpawnerData> ExternalAISpawners; // 0xa40(0x50)
	struct FFortAIEncounterQueryData EncounterQueryData; // 0xa90(0x20)
	struct UFortAIEncounterRiftManager* RiftManager; // 0xab0(0x08)
	struct FString AssociatedMissionName; // 0xab8(0x10)
	enum class EFortMissionType AssociatedMissionType; // 0xac8(0x01)
	char pad_AC9[0x3]; // 0xac9(0x03)
	char bCanBeActive : 1; // 0xacc(0x01)
	char pad_ACC_1 : 7; // 0xacc(0x01)
	char pad_ACD[0x3]; // 0xacd(0x03)
	struct TArray<struct UFortAIAssignment*> EncounterAssignments; // 0xad0(0x10)
	struct UFortAIAssignmentSettings* DefaultEncounterAssignmentSettings; // 0xae0(0x08)
	char pad_AE8[0x30]; // 0xae8(0x30)
	int32_t MaxActiveAlive; // 0xb18(0x04)
	int32_t MaxSpawnPointsUsed; // 0xb1c(0x04)
	struct UCurveFloat* OverrideSpawnPointsCurve; // 0xb20(0x08)
	char pad_B28[0x1f8]; // 0xb28(0x1f8)
	bool bSendFullAnalyticsReport; // 0xd20(0x01)
	bool bUseAILifespans; // 0xd21(0x01)
	bool bTrackCombatParticipation; // 0xd22(0x01)
	char pad_D23[0x5]; // 0xd23(0x05)
	struct FGameplayTagContainer ModifierTags; // 0xd28(0x20)
	struct TArray<struct FFortAIEncounterTimedModifierTags> TimedModifierTags; // 0xd48(0x10)
	struct FGameplayTagContainer GameContextTags; // 0xd58(0x20)
	struct AFortGameplayMutator_AILevelVariance* AILevelMutator; // 0xd78(0x08)
	struct TArray<struct AFortGameplayMutator_AIEncounterModifierTags*> EncounterModifierTagsMutators; // 0xd80(0x10)
	char pad_D90[0x8]; // 0xd90(0x08)

	void UnRegisterAISpawner(struct AActor* InAISpawner); // Function FortniteAI.FortAIEncounterInfo.UnRegisterAISpawner // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x951ecc0
	void SpawnTestAIGroup(struct UFortAISpawnGroup* SpawnGroupToSpawn, struct FVector SpawnLocation, struct FRotator SpawnRotation, struct AActor* SpawnSource, struct TArray<struct UFortAbilitySet*> AbilitySetsToGrantOnSpawn, struct FFortAISpawnGroupUpgradeData UpgradeData, bool bAllowAssigningToExternalSpawners, float SecondsBetweenSpawns); // Function FortniteAI.FortAIEncounterInfo.SpawnTestAIGroup // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x951e110
	struct AFortAIPawn* SpawnAIPawnReservedForEnemySpawner(struct AActor* EnemySpawner, struct FVector SpawnLocation, struct FRotator SpawnRotation); // Function FortniteAI.FortAIEncounterInfo.SpawnAIPawnReservedForEnemySpawner // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x951e760
	void SetPawnNumberLimit(int32_t InPawnNumberLimit); // Function FortniteAI.FortAIEncounterInfo.SetPawnNumberLimit // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x951f880
	void SetNukeWavesAtEncounterEnd(bool bNuke); // Function FortniteAI.FortAIEncounterInfo.SetNukeWavesAtEncounterEnd // (Final|Native|Public|BlueprintCallable) // @ game+0x951f170
	void SetEncounterActivationState(bool bEncounterActivityState); // Function FortniteAI.FortAIEncounterInfo.SetEncounterActivationState // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x951e020
	void RequestActivation(int32_t ActivationDelay); // Function FortniteAI.FortAIEncounterInfo.RequestActivation // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x951df30
	void RegisterAISpawner(struct AActor* InAISpawner); // Function FortniteAI.FortAIEncounterInfo.RegisterAISpawner // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x951ef50
	void OnRestStarted(); // Function FortniteAI.FortAIEncounterInfo.OnRestStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnRampStarted(); // Function FortniteAI.FortAIEncounterInfo.OnRampStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnPeakStarted(); // Function FortniteAI.FortAIEncounterInfo.OnPeakStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnGoalTakeDamage(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAIEncounterInfo.OnGoalTakeDamage // (Final|Native|Public|HasDefaults) // @ game+0x951d360
	void OnGameDifficultyChanged(); // Function FortniteAI.FortAIEncounterInfo.OnGameDifficultyChanged // (Final|Native|Private) // @ game+0x951d300
	void OnFadeStarted(); // Function FortniteAI.FortAIEncounterInfo.OnFadeStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnEncounterPawnDamaged(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAIEncounterInfo.OnEncounterPawnDamaged // (Final|Native|Protected|HasDefaults) // @ game+0x951cc70
	void NotifyRiftDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAIEncounterInfo.NotifyRiftDied // (Final|Native|Public|HasDefaults) // @ game+0x951da30
	bool GroupHasAIRemainingToSpawn(struct FFortAISpawnerData& FortAISpawnerData); // Function FortniteAI.FortAIEncounterInfo.GroupHasAIRemainingToSpawn // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x951eb20
	int32_t GetPawnNumberLimit(); // Function FortniteAI.FortAIEncounterInfo.GetPawnNumberLimit // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x951f820
	float GetEncounterTimeSeconds(); // Function FortniteAI.FortAIEncounterInfo.GetEncounterTimeSeconds // (Final|Native|Public|BlueprintCallable) // @ game+0x86c42d0
	void GetEncounterRifts(struct TArray<struct ABuildingRift*>& OutRifts); // Function FortniteAI.FortAIEncounterInfo.GetEncounterRifts // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x951f5d0
	struct AActor* GetEncounterQueryActor(); // Function FortniteAI.FortAIEncounterInfo.GetEncounterQueryActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x951f540
	void GetEncounterGameplayTags(struct FGameplayTagContainer& OutEncounterTags); // Function FortniteAI.FortAIEncounterInfo.GetEncounterGameplayTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x951cb20
	struct AFortAIDirectorDataManager* GetEncounterDataManager(); // Function FortniteAI.FortAIEncounterInfo.GetEncounterDataManager // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x951d2c0
	void GetEncounterAssignmentGoalActors(struct TArray<struct AActor*>& OutGoalActors); // Function FortniteAI.FortAIEncounterInfo.GetEncounterAssignmentGoalActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x951d1a0
	bool GetCurrentSpawnAreaDirections(struct TArray<enum class EFortEncounterDirection>& OutDirections); // Function FortniteAI.FortAIEncounterInfo.GetCurrentSpawnAreaDirections // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x951f6f0
	bool EncounterHasReservedSpawnRequestForEnemySpawner(struct AActor* EnemySpawner); // Function FortniteAI.FortAIEncounterInfo.EncounterHasReservedSpawnRequestForEnemySpawner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x951e9c0
	void DespawnPendingAndCurrentAI(); // Function FortniteAI.FortAIEncounterInfo.DespawnPendingAndCurrentAI // (Final|Native|Public|BlueprintCallable) // @ game+0x951d320
	struct UFortAIAssignment* CreateEncounterAssignment(struct UFortAIAssignmentSettings* AssignmentSettings, struct AActor* GoalActor); // Function FortniteAI.FortAIEncounterInfo.CreateEncounterAssignment // (Final|Native|Public|BlueprintCallable) // @ game+0x951f260
};

// Class FortniteAI.FortAIEncounterInfoOwnerInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAIEncounterInfoOwnerInterface : UInterface {

	struct UFortAIEncounterInfo* GetEncounterInfo(); // Function FortniteAI.FortAIEncounterInfoOwnerInterface.GetEncounterInfo // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50583f0
};

// Class FortniteAI.FortAIEncounterRiftManager
// Size: 0x2b0 (Inherited: 0x28)
struct UFortAIEncounterRiftManager : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct UFortAIEncounterInfo* MyEncounter; // 0x38(0x08)
	struct AFortAIDirector* AIDirector; // 0x40(0x08)
	struct FFortAIEncounterSpawnArea CurrentSpawnArea; // 0x48(0x58)
	struct FFortAIEncounterSpawnArea FutureSpawnArea; // 0xa0(0x58)
	float UpdateIntervalTimeSeconds; // 0xf8(0x04)
	int32_t NumRiftsToUse; // 0xfc(0x04)
	int32_t MinRiftsToUse; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	struct FFortEncounterSettings EncounterSettings; // 0x108(0xc0)
	float ExtraSpawnLocationPercentage; // 0x1c8(0x04)
	char pad_1CC[0x4]; // 0x1cc(0x04)
	struct FEncounterEnvironmentQueryInfo CurrentEnvironmentQueryInfo; // 0x1d0(0x28)
	struct FEncounterEnvironmentQueryInfo FallbackEnvironmentQueryInfo; // 0x1f8(0x28)
	struct FFortAIEncounterQueryDirectionTracker EncounterQueryDirectionTracker; // 0x220(0x48)
	struct ABuildingRift* RiftClassTemplate; // 0x268(0x08)
	float LastObjectiveBatchPathCostUpdateTime; // 0x270(0x04)
	float LastPlayerBatchPathCostUpdateTime; // 0x274(0x04)
	char pad_278[0x38]; // 0x278(0x38)

	void OnRiftDestroyed(struct AActor* Rift); // Function FortniteAI.FortAIEncounterRiftManager.OnRiftDestroyed // (Final|Native|Public) // @ game+0x9540f40
	struct AFortMission* GetAssociatedMission(); // Function FortniteAI.FortAIEncounterRiftManager.GetAssociatedMission // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9540e60
};

// Class FortniteAI.FortAIEncounterSequence
// Size: 0x1a0 (Inherited: 0x28)
struct UFortAIEncounterSequence : UObject {
	struct FFortGeneratedEncounterSequence GeneratedEncounterSequence; // 0x28(0x30)
	int32_t CurrentEncounterIndexInSequence; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct UFortAIEncounterInfo* CurrentEncounter; // 0x60(0x08)
	struct AFortAIDirector* AssociatedAIDirector; // 0x68(0x08)
	struct AFortMission* AssociatedMission; // 0x70(0x08)
	struct TArray<struct AActor*> TargetActors; // 0x78(0x10)
	struct UFortAIAssignmentSettings* AssignmentSettings; // 0x88(0x08)
	struct FEncounterEnvironmentQueryInfo OverrideEnvironmentQueryInfo; // 0x90(0x28)
	struct AActor* OptionalQueryActor; // 0xb8(0x08)
	struct FGameplayTagContainer InjectedTags; // 0xc0(0x20)
	struct FFortEncounterSettings EncounterSettings; // 0xe0(0xc0)

	void StopCurrentEncounter(); // Function FortniteAI.FortAIEncounterSequence.StopCurrentEncounter // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9549eb0
	struct UFortAIEncounterInfo* StartCurrentEncounterWithSavedData(enum class EFortEncounterSequenceResult& OutRequestResult, int32_t ActivationDelay); // Function FortniteAI.FortAIEncounterSequence.StartCurrentEncounterWithSavedData // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9549ef0
	struct UFortAIEncounterInfo* StartCurrentEncounter(enum class EFortEncounterSequenceResult& OutRequestResult, struct TArray<struct AActor*>& InTargetActors, struct UFortAIAssignmentSettings* InAssignmentSettings, struct FEncounterEnvironmentQueryInfo InOverrideEnvironmentQueryInfo, struct AActor* InOptionalQueryActor, struct FGameplayTagContainer InInjectedTags, struct FFortEncounterSettings InEncounterSettings, int32_t ActivationDelay); // Function FortniteAI.FortAIEncounterSequence.StartCurrentEncounter // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x954a090
	void SetEncounterStartingData(struct TArray<struct AActor*>& InTargetActors, struct UFortAIAssignmentSettings* InAssignmentSettings, struct FEncounterEnvironmentQueryInfo InOverrideEnvironmentQueryInfo, struct AActor* InOptionalQueryActor, struct FGameplayTagContainer InInjectedTags, struct FFortEncounterSettings InEncounterSettings); // Function FortniteAI.FortAIEncounterSequence.SetEncounterStartingData // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x954a980
	enum class EFortEncounterSequenceResult Previous(); // Function FortniteAI.FortAIEncounterSequence.Previous // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9549e20
	enum class EFortEncounterSequenceResult Next(); // Function FortniteAI.FortAIEncounterSequence.Next // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9549e70
	enum class EFortEncounterSequenceResult Last(); // Function FortniteAI.FortAIEncounterSequence.Last // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9549df0
	bool IsOnFinalIndexInSequence(); // Function FortniteAI.FortAIEncounterSequence.IsOnFinalIndexInSequence // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9549cd0
	bool HasEncounter(); // Function FortniteAI.FortAIEncounterSequence.HasEncounter // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9549ca0
	int32_t GetNumEncountersInSequence(); // Function FortniteAI.FortAIEncounterSequence.GetNumEncountersInSequence // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3afc220
	int32_t GetEncounterIndexInSequence(); // Function FortniteAI.FortAIEncounterSequence.GetEncounterIndexInSequence // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4157610
	struct UFortAIEncounterInfo* GetCurrentEncounter(); // Function FortniteAI.FortAIEncounterSequence.GetCurrentEncounter // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9549c80
	bool EncounterBelongsToSequence(struct UFortAIEncounterInfo* InEncounter); // Function FortniteAI.FortAIEncounterSequence.EncounterBelongsToSequence // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9549d00
};

// Class FortniteAI.FortAIEncounterTargetInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAIEncounterTargetInterface : UInterface {

	bool IsFloatingTarget(); // Function FortniteAI.FortAIEncounterTargetInterface.IsFloatingTarget // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	float GetObjectiveCompletionPercentage(); // Function FortniteAI.FortAIEncounterTargetInterface.GetObjectiveCompletionPercentage // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class FortniteAI.FortAIFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UFortAIFunctionLibrary : UBlueprintFunctionLibrary {

	bool TeleportAIPawn(struct AFortAIPawn* AIPawn, struct FVector DestLocation, struct FRotator DestRotation, bool bIgnoreCollision); // Function FortniteAI.FortAIFunctionLibrary.TeleportAIPawn // (Final|BlueprintAuthorityOnly|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x954c000
	void SetHearingRange(struct AActor* AIAgent, float Range); // Function FortniteAI.FortAIFunctionLibrary.SetHearingRange // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x875f090
	void RequestNavUpdateForBuilding(struct ABuildingActor* BuildingActor); // Function FortniteAI.FortAIFunctionLibrary.RequestNavUpdateForBuilding // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x954c790
	void MakeNoiseEventAtLocation(struct AActor* NoiseMaker, float MaxRange, struct FVector& NoiseLocation, struct FName NoiseTag); // Function FortniteAI.FortAIFunctionLibrary.MakeNoiseEventAtLocation // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x954c9c0
	void MakeNoiseEvent(struct AActor* NoiseMaker, float MaxRange, struct FName NoiseTag); // Function FortniteAI.FortAIFunctionLibrary.MakeNoiseEvent // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x954cfe0
	bool IsConcealedByPerceptionModifiers(struct UObject* WorldContextObject, struct FVector ObserverLocation, struct FVector TargetLocation, float& OutConcealment); // Function FortniteAI.FortAIFunctionLibrary.IsConcealedByPerceptionModifiers // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x954c290
	struct UFortAthenaAIRuntimeParameters* GetOrCreateAIRuntimeParameters(struct AAIController* AIController, struct UFortAthenaAIRuntimeParameters* ParametersClass); // Function FortniteAI.FortAIFunctionLibrary.GetOrCreateAIRuntimeParameters // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x954c580
	struct UAthenaAISpawner* GetAISpawner(struct UObject* WorldContextObject); // Function FortniteAI.FortAIFunctionLibrary.GetAISpawner // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x954c880
};

// Class FortniteAI.FortAIGoalManager
// Size: 0x400 (Inherited: 0x290)
struct AFortAIGoalManager : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct TArray<struct UFortAIAssignment*> WorldAssignments; // 0x298(0x10)
	struct TArray<struct UFortAIAssignment*> WorldEnemyAssignments; // 0x2a8(0x10)
	struct UFortAIAssignment* DefaultAttackPlayersAssignment; // 0x2b8(0x08)
	char pad_2C0[0x60]; // 0x2c0(0x60)
	struct TArray<struct UEnvQuery*> CombinedQueries; // 0x320(0x10)
	char pad_330[0x50]; // 0x330(0x50)
	struct UFortAIAssignmentSettings* DefaultEncounterAssignmentSettings; // 0x380(0x08)
	struct UFortAIAssignmentSettings* DefaultEnemyAssignmentSettings; // 0x388(0x08)
	struct TArray<struct FPawnGoalSelectionTableEntry> PawnGoalSelectionTable; // 0x390(0x10)
	char pad_3A0[0x60]; // 0x3a0(0x60)

	void SetCurrentGoalDiscouragement(struct UObject* WorldContext, struct AFortAIController* AI); // Function FortniteAI.FortAIGoalManager.SetCurrentGoalDiscouragement // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x954ec10
	void RemoveWorldAssignment(struct UObject* WorldContextObject, struct FFortAIAssignmentIdentifier AssignmentIdentifier); // Function FortniteAI.FortAIGoalManager.RemoveWorldAssignment // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9551210
	void RemoveGoalsFromWorldAssignment(struct UObject* WorldContextObject, struct FFortAIAssignmentIdentifier& AssignmentIdentifier, struct TArray<struct FFortAIGoalInfo>& GoalInfos); // Function FortniteAI.FortAIGoalManager.RemoveGoalsFromWorldAssignment // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9550360
	void RemoveGoalFromWorldAssignment(struct UObject* WorldContextObject, struct FFortAIAssignmentIdentifier& AssignmentIdentifier, struct FFortAIGoalInfo& GoalInfo); // Function FortniteAI.FortAIGoalManager.RemoveGoalFromWorldAssignment // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9550720
	void MakeGoalsFromLocationsAndActor(struct TArray<struct FFortAIGoalInfo>& Goals, struct UObject* WorldContextObject, struct TArray<struct FVector>& GoalLocations, struct AActor* GoalActor); // Function FortniteAI.FortAIGoalManager.MakeGoalsFromLocationsAndActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x954f4d0
	void MakeGoalsFromLocations(struct TArray<struct FFortAIGoalInfo>& Goals, struct UObject* WorldContextObject, struct TArray<struct FVector>& GoalLocations); // Function FortniteAI.FortAIGoalManager.MakeGoalsFromLocations // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x954f7c0
	void MakeGoalsFromActors(struct TArray<struct FFortAIGoalInfo>& Goals, struct UObject* WorldContextObject, struct TArray<struct AActor*>& GoalActors, bool bActorsAlwaysPerceived, bool bGoalActorsAllowUndermining); // Function FortniteAI.FortAIGoalManager.MakeGoalsFromActors // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x954fc50
	void MakeGoalFromLocation(struct FFortAIGoalInfo& Goal, struct UObject* WorldContextObject, struct FVector& GoalLocation); // Function FortniteAI.FortAIGoalManager.MakeGoalFromLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x954fa10
	void MakeGoalFromActor(struct FFortAIGoalInfo& Goal, struct UObject* WorldContextObject, struct AActor* GoalActor, bool bActorAlwaysPerceived, bool bGoalActorAllowsUndermining); // Function FortniteAI.FortAIGoalManager.MakeGoalFromActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x954ffc0
	void CreateWorldAssignment(struct UObject* WorldContextObject, struct FFortAIAssignmentIdentifier WorldAssignmentIdentifier, struct UFortAIAssignmentSettings* AssignmentSettings, struct UFortAIGoalProvider* GoalProvider, struct FFortAIAssignmentIdentifier& AssignmentIdentifier, enum class EAssignmentCreationResult& CreationResult); // Function FortniteAI.FortAIGoalManager.CreateWorldAssignment // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9551650
	struct UFortAIAssignment* AddWorldAssignment(struct UFortAIAssignmentSettings* AssignmentSettings, struct AActor* GoalActor); // Function FortniteAI.FortAIGoalManager.AddWorldAssignment // (Final|Native|Public|BlueprintCallable) // @ game+0x954f040
	void AddGoalToWorldAssignment(struct UObject* WorldContextObject, struct FFortAIAssignmentIdentifier& AssignmentIdentifier, struct FFortAIGoalInfo& GoalInfo); // Function FortniteAI.FortAIGoalManager.AddGoalToWorldAssignment // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9550e70
	void AddGoalsToWorldAssignment(struct UObject* WorldContextObject, struct FFortAIAssignmentIdentifier& AssignmentIdentifier, struct TArray<struct FFortAIGoalInfo>& GoalInfos); // Function FortniteAI.FortAIGoalManager.AddGoalsToWorldAssignment // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9550ad0
	void AddGoalActorToAssignment(struct UFortAIAssignment* Assignment, struct AActor* GoalActor); // Function FortniteAI.FortAIGoalManager.AddGoalActorToAssignment // (Final|Native|Public|BlueprintCallable) // @ game+0x954ed80
	void AddGoal(struct AActor* GoalActor, struct UFortAIAssignmentSettings* GoalSettings); // Function FortniteAI.FortAIGoalManager.AddGoal // (Final|Native|Public|BlueprintCallable) // @ game+0x954f2a0
};

// Class FortniteAI.FortAINearbyActorsPerceptionComponent
// Size: 0xe0 (Inherited: 0xc8)
struct UFortAINearbyActorsPerceptionComponent : UFortNearbyActorsPerceptionComponent {
	char pad_C8[0x8]; // 0xc8(0x08)
	struct TScriptInterface<IFortAthenaAILODSettings> CachedLODSettingsManager; // 0xd0(0x10)
};

// Class FortniteAI.FortAIObjectiveInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAIObjectiveInterface : UInterface {
};

// Class FortniteAI.FortAIPawnCustomizationDefinition
// Size: 0x98 (Inherited: 0x30)
struct UFortAIPawnCustomizationDefinition : UPrimaryDataAsset {
	char pad_30[0x8]; // 0x30(0x08)
	struct TSoftObjectPtr<USkeletalMesh> SkeletalMesh; // 0x38(0x20)
	struct TArray<struct FFortAIPawnMaterialDefinition> OverrideMaterials; // 0x58(0x10)
	struct TSoftClassPtr<UObject> AnimationBP; // 0x68(0x20)
	struct TArray<struct UCustomCharacterPart*> CharacterParts; // 0x88(0x10)
};

// Class FortniteAI.FortAIPawnVariant
// Size: 0x70 (Inherited: 0x28)
struct UFortAIPawnVariant : UObject {
	struct TArray<struct AFortAIPawn*> PawnClasses; // 0x28(0x10)
	struct TArray<struct FFortAIPawnVariantDefinition> PawnVariantDefinitions; // 0x38(0x10)
	int32_t MinPlayersToSpawnVariant; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FDataTableRowHandle SpawnPointValueHandle; // 0x50(0x10)
	int32_t CachedSpawnPointValue; // 0x60(0x04)
	float EncounterExpectedLifespan; // 0x64(0x04)
	int32_t VersionNum; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class FortniteAI.FortAIRootAssignmentProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAIRootAssignmentProviderInterface : UInterface {

	struct FFortAIAssignmentIdentifier GetRootAssignmentIdentifier(); // Function FortniteAI.FortAIRootAssignmentProviderInterface.GetRootAssignmentIdentifier // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9558480
};

// Class FortniteAI.FortAISpawnerActorBase
// Size: 0x290 (Inherited: 0x290)
struct AFortAISpawnerActorBase : AActor {
};

// Class FortniteAI.FortAISpawnerInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAISpawnerInterface : UInterface {

	bool OnReceiveSpawnGroup(); // Function FortniteAI.FortAISpawnerInterface.OnReceiveSpawnGroup // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool IsReadyToReceiveNewSpawnGroup(); // Function FortniteAI.FortAISpawnerInterface.IsReadyToReceiveNewSpawnGroup // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class FortniteAI.FortAISpawnGroup
// Size: 0x190 (Inherited: 0x30)
struct UFortAISpawnGroup : UPrimaryDataAsset {
	float EnemyUtilities[0x10]; // 0x30(0x40)
	struct TArray<struct FSpawnGroupEnemy> EnemiesToSpawn; // 0x70(0x10)
	bool bIsPrototype; // 0x80(0x01)
	bool bIsValidForEnemySpawners; // 0x81(0x01)
	bool bIsLargeSpawnGroup; // 0x82(0x01)
	char pad_83[0x1]; // 0x83(0x01)
	float MaxDiscountRatio; // 0x84(0x04)
	bool bUseWeightSystem; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct FScalableFloat Weight; // 0x90(0x28)
	struct FScalableFloat MinNumber; // 0xb8(0x28)
	struct FScalableFloat MaxNumber; // 0xe0(0x28)
	struct FCurveTableRowHandle MaxGroupCategoryPopulationDensityCurve; // 0x108(0x10)
	struct TArray<struct FFortSpawnGroupEncounterTypeData> EncounterTypeData; // 0x118(0x10)
	struct FGameplayTagContainer SpawnGroupGameplayTags; // 0x128(0x20)
	struct FGameplayTagQuery RequiredTagQuery; // 0x148(0x48)

	bool IsValidForEnemySpawners(); // Function FortniteAI.FortAISpawnGroup.IsValidForEnemySpawners // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9558a60
	bool IsPrototype(); // Function FortniteAI.FortAISpawnGroup.IsPrototype // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9558a20
	bool IsLargeSpawnGroup(); // Function FortniteAI.FortAISpawnGroup.IsLargeSpawnGroup // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9558a40
	int32_t GetNumberOfEnemies(); // Function FortniteAI.FortAISpawnGroup.GetNumberOfEnemies // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2740a60
	struct UFortAIPawnVariant* GetEnemy(int32_t EnemyIndex); // Function FortniteAI.FortAISpawnGroup.GetEnemy // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9558a80
};

// Class FortniteAI.FortAISpawnGroupCapsCategorySet
// Size: 0x38 (Inherited: 0x28)
struct UFortAISpawnGroupCapsCategorySet : UObject {
	struct TArray<struct FFortAIEncounterSpawnGroupCapsCategory> SpawnGroupCapsCategories; // 0x28(0x10)
};

// Class FortniteAI.FortAISpawnGroupProgressionInfo
// Size: 0x40 (Inherited: 0x30)
struct UFortAISpawnGroupProgressionInfo : UDataAsset {
	struct TArray<struct FSpawnGroupProgression> SpawnGroups; // 0x30(0x10)
};

// Class FortniteAI.FortAISpawnGroupUpgrade
// Size: 0x118 (Inherited: 0x28)
struct UFortAISpawnGroupUpgrade : UObject {
	struct FGameplayTagContainer UpgradeTags; // 0x28(0x20)
	struct FGameplayTagQuery GroupRequiredTagQuery; // 0x48(0x48)
	struct TArray<struct FFortAIPawnUpgrade> BasePawnUpgrades; // 0x90(0x10)
	struct FName AdditionalModifiersLootTierGroup; // 0xa0(0x04)
	bool bInvalidForEnemySpawners; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
	float SpawnGroupDiscountPercentage; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FFortAISpawnGroupUpgradeUIData UIData; // 0xb0(0x68)
};

// Class FortniteAI.FortAISpawnGroupUpgradeProbabilities
// Size: 0x40 (Inherited: 0x28)
struct UFortAISpawnGroupUpgradeProbabilities : UObject {
	bool bIsGuaranteedUpgrade; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TArray<struct FFortAIPawnUpgradeProbability> UpgradeProbabilities; // 0x30(0x10)
};

// Class FortniteAI.FortAITetheringBoxBoundsInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAITetheringBoxBoundsInterface : UInterface {

	float GetTetheredBoxBoundsWidth(); // Function FortniteAI.FortAITetheringBoxBoundsInterface.GetTetheredBoxBoundsWidth // (RequiredAPI|BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	float GetTetheredBoxBoundsHeight(); // Function FortniteAI.FortAITetheringBoxBoundsInterface.GetTetheredBoxBoundsHeight // (RequiredAPI|BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	float GetTetheredBoxBoundsEQSSpaceBetween(); // Function FortniteAI.FortAITetheringBoxBoundsInterface.GetTetheredBoxBoundsEQSSpaceBetween // (RequiredAPI|BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	float GetTetheredBoxBoundsEQSGridSize(); // Function FortniteAI.FortAITetheringBoxBoundsInterface.GetTetheredBoxBoundsEQSGridSize // (RequiredAPI|BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	struct FVector GetTetheredBoxBoundsCenter(); // Function FortniteAI.FortAITetheringBoxBoundsInterface.GetTetheredBoxBoundsCenter // (RequiredAPI|BlueprintAuthorityOnly|Event|Public|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
};

// Class FortniteAI.FortAsyncAction_MakeTieredWaveEncounterSettings
// Size: 0x288 (Inherited: 0x30)
struct UFortAsyncAction_MakeTieredWaveEncounterSettings : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnComplete; // 0x30(0x10)
	struct FTieredWaveSetData WaveData; // 0x40(0x178)
	struct FFortEncounterSettings EncounterSettings; // 0x1b8(0xc0)
	char pad_278[0x10]; // 0x278(0x10)

	struct UFortAsyncAction_MakeTieredWaveEncounterSettings* CreateAsyncAction_MakeTieredWaveEncounterSettings(struct FTieredWaveSetData& WaveData, struct FFortEncounterSettings& InEncounterSettings); // Function FortniteAI.FortAsyncAction_MakeTieredWaveEncounterSettings.CreateAsyncAction_MakeTieredWaveEncounterSettings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x955f3a0
};

// Class FortniteAI.FortAthenaAIBotController
// Size: 0x1720 (Inherited: 0x3b8)
struct AFortAthenaAIBotController : AAIController {
	char pad_3B8[0x70]; // 0x3b8(0x70)
	struct AActor* PreviousVehicle; // 0x428(0x08)
	struct FMulticastInlineDelegate OnPickupCreated; // 0x430(0x10)
	char pad_440[0x10]; // 0x440(0x10)
	struct TMap<struct FGuid, struct FFortAbilitySetHandle> AppliedInGameModifierAbilitySetHandles; // 0x450(0x50)
	struct TSet<struct FGuid> GadgetTrackedAttributeItemInstanceIds; // 0x4a0(0x50)
	char pad_4F0[0x50]; // 0x4f0(0x50)
	struct FFortBotTargetHandler TargetHandler; // 0x540(0x40)
	char pad_580[0x1]; // 0x580(0x01)
	char pad_581_0 : 1; // 0x581(0x01)
	char bIsAnAthenaGameParticipant : 1; // 0x581(0x01)
	char pad_581_2 : 6; // 0x581(0x01)
	char pad_582[0x6]; // 0x582(0x06)
	enum class EReachLocationValidationMode ReachLocationValidationMode; // 0x588(0x01)
	char pad_589[0x7]; // 0x589(0x07)
	struct UBehaviorTree* BehaviorTree; // 0x590(0x08)
	struct FFortBotInventoryInfo SlotItems[0x6]; // 0x598(0x270)
	char pad_808[0x48]; // 0x808(0x48)
	struct UFortAthenaAIBotInventoryDigestedSkillSet* CacheInventoryDigestedSkillSet; // 0x850(0x08)
	char pad_858[0x8]; // 0x858(0x08)
	struct AFortPlayerPawnAthena* PlayerBotPawn; // 0x860(0x08)
	struct UAthenaAIServicePlayerBots* CachedAIServicePlayerBots; // 0x868(0x08)
	struct AFortGameModeAthena* CachedGameMode; // 0x870(0x08)
	struct UFortAthenaAIRuntimeParametersComponent* CachedAIRuntimeParametersComponent; // 0x878(0x08)
	struct UFortAthenaAIRuntimeParameters_Leash* CachedLeashRuntimeParameters; // 0x880(0x08)
	struct UFortAthenaAIRuntimeParameters_AffiliationBase* CachedAffiliationRuntimeParameters; // 0x888(0x08)
	struct UFortAthenaNpcPatrollingComponent* CachedPatrollingComponent; // 0x890(0x08)
	struct UFortAIControllerPerksComponent* CachedAIPerksComponent; // 0x898(0x08)
	struct UFortAICombatTokenConsumerComponent* CachedTokenConsumerComponent; // 0x8a0(0x08)
	struct TScriptInterface<IFortAIAimingInterface> CachedAIAimingInterface; // 0x8a8(0x10)
	char pad_8B8[0x8]; // 0x8b8(0x08)
	struct TArray<struct FBotDelayedStimulus> DelayedStimulus; // 0x8c0(0x10)
	char pad_8D0[0x18]; // 0x8d0(0x18)
	struct TArray<struct FFortBotThreatActorInfo> ObjectsThreatList; // 0x8e8(0x10)
	struct TArray<struct FFortBotThreatActorInfo> TrapsThreatList; // 0x8f8(0x10)
	enum class EAlertLevel CurrentAlertLevel; // 0x908(0x01)
	char pad_909[0x7]; // 0x909(0x07)
	struct FAlertLevelInfo DefaultAlertLevelInfo; // 0x910(0x10)
	struct FMulticastInlineDelegate OnAlertLevelChangedEventDelegate; // 0x920(0x10)
	struct FMulticastInlineDelegate OnStealthMeterChangedEventDelegate; // 0x930(0x10)
	char pad_940[0x8]; // 0x940(0x08)
	struct FMulticastInlineDelegate OnAgentDBNOStatusChangedEventDelegate; // 0x948(0x10)
	struct FMulticastInlineDelegate OnAgentDiedEventDelegate; // 0x958(0x10)
	struct FMulticastInlineDelegate OnAgentGameOver; // 0x968(0x10)
	char pad_978[0x48]; // 0x978(0x48)
	struct FMulticastInlineDelegate OnPlayerPawnKilledByBot; // 0x9c0(0x10)
	struct FMulticastInlineDelegate OnAIPawnKilledByBot; // 0x9d0(0x10)
	struct FMulticastInlineDelegate OnCurrentTargetChangedDelegate; // 0x9e0(0x10)
	char pad_9F0[0x30]; // 0x9f0(0x30)
	struct AFortInventory* Inventory; // 0xa20(0x08)
	float Skill; // 0xa28(0x04)
	char bAllowUnsupportedItemsInDefaultInventory : 1; // 0xa2c(0x01)
	char pad_A2C_1 : 7; // 0xa2c(0x01)
	char pad_A2D[0x3]; // 0xa2d(0x03)
	struct TArray<struct UFortAthenaAIBotSkillSet*> BotSkillSetClasses; // 0xa30(0x10)
	char pad_A40[0x20]; // 0xa40(0x20)
	struct UFortAthenaAIBotInventoryItems* StartupInventory; // 0xa60(0x08)
	struct FFortAthenaLoadout CosmeticLoadoutBC; // 0xa68(0x260)
	struct TArray<struct UCustomCharacterPart*> CustomCharacterPartOverridesBC; // 0xcc8(0x10)
	struct UFortBotNameSettings* NameSettingsBC; // 0xcd8(0x08)
	struct FScalableFloat SpectateOnDeathMinTime; // 0xce0(0x28)
	struct FScalableFloat SpectateOnDeathMaxTime; // 0xd08(0x28)
	struct FScalableFloat EmotesMaxCount; // 0xd30(0x28)
	struct FVector LeashGameplayVolumeProjectExtent; // 0xd58(0x18)
	struct UFortAthenaAIBotPerceptionDigestedSkillSet* CachePerceptionDigestedSkillSet; // 0xd70(0x08)
	struct UFortAthenaAIBotHarvestDigestedSkillSet* CacheHarvestDigestedSkillSet; // 0xd78(0x08)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CacheMovementSkillSet; // 0xd80(0x08)
	struct UFortAthenaAIBotLootingDigestedSkillSet* CacheLootingSkillSet; // 0xd88(0x08)
	struct UFortAthenaAIBotAttackingDigestedSkillSet* CacheAttackingSkillSet; // 0xd90(0x08)
	struct UFortAthenaAIBotPlayStyleDigestedSkillSet* CachePlayStyleSkillSet; // 0xd98(0x08)
	struct UFortAthenaAIBotUnstuckDigestedSkillSet* CacheUnstuckSkillSet; // 0xda0(0x08)
	struct UFortAthenaAIBotRangeAttackDigestedSkillSet* CacheRangeAttackSkillSet; // 0xda8(0x08)
	struct UFortAthenaAIBotVehicleDigestedSkillSet* CacheVehicleSkillSet; // 0xdb0(0x08)
	char pad_DB8[0x60]; // 0xdb8(0x60)
	struct UFortInteractContextInfo* InteractContextInfo; // 0xe18(0x08)
	char pad_E20[0x78]; // 0xe20(0x78)
	struct UFortAthenaAIBotAimingDigestedSkillSet* CacheAimingDigestedSkillSet; // 0xe98(0x08)
	char pad_EA0[0x4]; // 0xea0(0x04)
	char pad_EA4_0 : 1; // 0xea4(0x01)
	char bCanBeDestroyedOnDeath : 1; // 0xea4(0x01)
	char pad_EA4_2 : 6; // 0xea4(0x01)
	char pad_EA5[0xb]; // 0xea5(0x0b)
	struct FVector LastDeathLocation; // 0xeb0(0x18)
	struct FRotator LastDeathRotation; // 0xec8(0x18)
	struct UFortWorldItem* CachedWorldItem; // 0xee0(0x08)
	char pad_EE8[0x8]; // 0xee8(0x08)
	struct AFortWeapon* CacheWeaponUsedToCalculateType; // 0xef0(0x08)
	bool bCachedIsUsingArcedProjectileWeapon; // 0xef8(0x01)
	char pad_EF9[0x3]; // 0xef9(0x03)
	float CachedProjectileGravityScale; // 0xefc(0x04)
	struct AFortWeapon* CachedWeaponUsedToCalculateProjectileData; // 0xf00(0x08)
	struct UStatManager* StatManager; // 0xf08(0x08)
	struct TArray<struct FBuildingWeakSpotData> ActiveWeakSpots; // 0xf10(0x10)
	char pad_F20[0x28]; // 0xf20(0x28)
	struct AFortPawn* CacheBotPawnClass; // 0xf48(0x08)
	char pad_F50[0x8]; // 0xf50(0x08)
	struct AActor* CurrentLootActor; // 0xf58(0x08)
	struct UAthenaMarkerComponent* MarkerComponent; // 0xf60(0x08)
	struct FString BotPlayerName; // 0xf68(0x10)
	struct FGameplayTag DescriptorTag; // 0xf78(0x04)
	char pad_F7C[0x4]; // 0xf7c(0x04)
	struct FString BotIDSuffix; // 0xf80(0x10)
	struct FString BotPlayerNameWithSkillRating; // 0xf90(0x10)
	char pad_FA0[0x10]; // 0xfa0(0x10)
	struct UFortAthenaMutator_SpawningPolicyData* PolicyDataSpawner; // 0xfb0(0x08)
	char pad_FB8[0x128]; // 0xfb8(0x128)
	struct UFortControllerComponent_Telemetry* FortControllerComponent_Telemetry; // 0x10e0(0x08)
	bool bForceUsingBuildingTool; // 0x10e8(0x01)
	bool bForceHolsterWeapon; // 0x10e9(0x01)
	char pad_10EA[0x6]; // 0x10ea(0x06)
	struct UFortWorldItem* PendingEquipWeapon; // 0x10f0(0x08)
	char pad_10F8[0x50]; // 0x10f8(0x50)
	struct APawn* PlayerToSpectateOnDeath; // 0x1148(0x08)
	struct FMulticastInlineDelegate OnPlayerPawnAISpawnedDelegate; // 0x1150(0x10)
	char pad_1160[0x120]; // 0x1160(0x120)
	struct UAISenseConfig_Sight* AISenseConfig_SightOverride; // 0x1280(0x08)
	struct UAISenseConfig_Hearing* AISenseConfig_HearingOverride; // 0x1288(0x08)
	char pad_1290[0x10]; // 0x1290(0x10)
	struct AActor* BotOwner; // 0x12a0(0x08)
	int32_t BotControllerUID; // 0x12a8(0x04)
	char pad_12AC[0x4]; // 0x12ac(0x04)
	struct AFortPlayerPawnAthena* ReviveTarget; // 0x12b0(0x08)
	char pad_12B8[0x90]; // 0x12b8(0x90)
	struct UFortAthenaAIBotCustomizationData* BotData; // 0x1348(0x08)
	struct FDebugMinimapData DebugMinimapData; // 0x1350(0x1b0)
	struct AFortPlayerPawnAthena* RevivePlayerPawnToken; // 0x1500(0x08)
	char pad_1508[0x18]; // 0x1508(0x18)
	struct AActor* LeashActorToFollow; // 0x1520(0x08)
	struct FVector LeashActorToFollowLocalOffset; // 0x1528(0x18)
	struct AFortAthenaAILeashVolume* LeashVolume; // 0x1540(0x08)
	struct TWeakObjectPtr<struct AGameplayVolume> LeashGameplayVolume; // 0x1548(0x08)
	struct UFortGameStateComponent_AffiliationManager* CachedAffiliationManager; // 0x1550(0x08)
	struct UFortActorComponent_Affiliation* CachedAffiliationComponent; // 0x1558(0x08)
	bool bIsAffectedByMutatorHealthAndShieldModifiers; // 0x1560(0x01)
	char pad_1561[0x7]; // 0x1561(0x07)
	bool bHasChangedPawnCullDistanceToAggroMode; // 0x1568(0x01)
	char pad_1569[0x7]; // 0x1569(0x07)
	struct UFortAthenaAIRuntimeParameters_AIBotRespawn* RespawnRuntimeParameters; // 0x1570(0x08)
	struct TWeakObjectPtr<struct AActor> CurrentBlockingObstacle; // 0x1578(0x08)
	char pad_1580[0x10]; // 0x1580(0x10)
	struct TArray<struct TWeakObjectPtr<struct AActor>> NoSmashActors; // 0x1590(0x10)
	char pad_15A0[0x8]; // 0x15a0(0x08)
	struct APawn* FinisherPawn; // 0x15a8(0x08)
	char pad_15B0[0x54]; // 0x15b0(0x54)
	enum class EFortPawnStasisMode PreviousStasisMode; // 0x1604(0x01)
	bool bPostponeGiveWeaponCheat; // 0x1605(0x01)
	bool bPostponeGiveMaterialsCheat; // 0x1606(0x01)
	char pad_1607[0x1]; // 0x1607(0x01)
	float StartSpectatingTime; // 0x1608(0x04)
	char pad_160C[0xb4]; // 0x160c(0xb4)
	struct UAthenaDanceItemDefinition* RequestedEmoteAsset; // 0x16c0(0x08)
	char pad_16C8[0x8]; // 0x16c8(0x08)
	struct UBehaviorTree* BTAssetToRunOnPawnAISpawned; // 0x16d0(0x08)
	char pad_16D8[0x48]; // 0x16d8(0x48)

	void UpdateLeashActorToFollowLocation(); // Function FortniteAI.FortAthenaAIBotController.UpdateLeashActorToFollowLocation // (Final|Native|Protected) // @ game+0x9563b40
	void ThankBusDriver(); // Function FortniteAI.FortAthenaAIBotController.ThankBusDriver // (Final|Native|Protected) // @ game+0x9563b60
	void SwitchTeam(char TeamIndex); // Function FortniteAI.FortAthenaAIBotController.SwitchTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x95641c0
	void StopSecondaryFire(bool bFireWhenStopping); // Function FortniteAI.FortAthenaAIBotController.StopSecondaryFire // (Final|Native|Public|BlueprintCallable) // @ game+0x9566d60
	void StopFire(); // Function FortniteAI.FortAthenaAIBotController.StopFire // (Final|Native|Public|BlueprintCallable) // @ game+0x9566e70
	void StopEmote(); // Function FortniteAI.FortAthenaAIBotController.StopEmote // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x95635c0
	void StartSecondaryFire(); // Function FortniteAI.FortAthenaAIBotController.StartSecondaryFire // (Final|Native|Public|BlueprintCallable) // @ game+0x9566e50
	void StartFire(); // Function FortniteAI.FortAthenaAIBotController.StartFire // (Final|Native|Public|BlueprintCallable) // @ game+0x9566ed0
	void SetSkillSet(struct UFortAthenaAIBotSkillSet* SkillSetClass); // Function FortniteAI.FortAthenaAIBotController.SetSkillSet // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x95678a0
	void SetRadialLeashOuterRadius(float OuterRadius); // Function FortniteAI.FortAthenaAIBotController.SetRadialLeashOuterRadius // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9562cb0
	void SetRadialLeashLocation(struct FVector& Location); // Function FortniteAI.FortAthenaAIBotController.SetRadialLeashLocation // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9562eb0
	void SetRadialLeashInnerRadius(float InnerRadius); // Function FortniteAI.FortAthenaAIBotController.SetRadialLeashInnerRadius // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9562db0
	void SetRadialLeashAlertLevelOverride(struct FLeashInfoOverride& LeashInfoOverride, enum class EAlertLevel AlertLevel); // Function FortniteAI.FortAthenaAIBotController.SetRadialLeashAlertLevelOverride // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9562940
	void SetPatrollingEnable(bool bEnable); // Function FortniteAI.FortAthenaAIBotController.SetPatrollingEnable // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9562600
	void SetLeashVolume(struct AFortAthenaAILeashVolume* InLeashVolume); // Function FortniteAI.FortAthenaAIBotController.SetLeashVolume // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9562830
	void SetLeashReturnLocationMode(enum class ELeashReturnLocationMode ReturnMode); // Function FortniteAI.FortAthenaAIBotController.SetLeashReturnLocationMode // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9562bc0
	void SetLeashGameplayVolume(struct AGameplayVolume* InLeashGameplayVolume); // Function FortniteAI.FortAthenaAIBotController.SetLeashGameplayVolume // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9562700
	void SetLeashActorToFollow(struct AActor* ActorToFollow, float LeashLocationUpdateRate, struct FVector LocalOffset); // Function FortniteAI.FortAthenaAIBotController.SetLeashActorToFollow // (Final|BlueprintAuthorityOnly|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x95623c0
	void SetBotOwner(struct AActor* InBotOwner); // Function FortniteAI.FortAthenaAIBotController.SetBotOwner // (Final|Native|Public|BlueprintCallable) // @ game+0x95640d0
	void RequestEmote(struct FPrimaryAssetId& EmotePrimaryAssetId, float InfiniteEmoteMaxDuration); // Function FortniteAI.FortAthenaAIBotController.RequestEmote // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x95636f0
	void RemoveSkillSet(struct UFortAthenaAIBotSkillSet* SkillSetClass); // Function FortniteAI.FortAthenaAIBotController.RemoveSkillSet // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x95676d0
	void RemoveEmoteRequest(); // Function FortniteAI.FortAthenaAIBotController.RemoveEmoteRequest // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x95636d0
	void ReleaseBuildTool(); // Function FortniteAI.FortAthenaAIBotController.ReleaseBuildTool // (Final|Native|Protected) // @ game+0x9563b80
	void QueueStim(struct AActor* SourceActor, struct FVector& SourceLocation, struct FVector& SourceDirection, enum class EStimType NewStimType, float StimStrength, struct FName StimTag); // Function FortniteAI.FortAthenaAIBotController.QueueStim // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9567a10
	void PlayEmote(struct FPrimaryAssetId& EmotePrimaryAssetId); // Function FortniteAI.FortAthenaAIBotController.PlayEmote // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x95635e0
	void OverrideSkill(float NewSkill); // Function FortniteAI.FortAthenaAIBotController.OverrideSkill // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x95673b0
	void OverrideAggressivenessPlayStyle(bool bInIsAggressive); // Function FortniteAI.FortAthenaAIBotController.OverrideAggressivenessPlayStyle // (Final|Native|Public|BlueprintCallable) // @ game+0x9564a70
	void OnTargetPawnDestroyed(); // Function FortniteAI.FortAthenaAIBotController.OnTargetPawnDestroyed // (Final|Native|Public) // @ game+0x9566740
	void OnTargetPawnDead(struct AFortPawn* FortPawn); // Function FortniteAI.FortAthenaAIBotController.OnTargetPawnDead // (Final|Native|Public) // @ game+0x9566780
	void OnTargetPawnDamaged(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAthenaAIBotController.OnTargetPawnDamaged // (Final|Native|Public|HasDefaults) // @ game+0x9566870
	void OnTargetBuildingDestroyed(struct ABuildingActor* Building, struct AAthenaAIController* AIController); // Function FortniteAI.FortAthenaAIBotController.OnTargetBuildingDestroyed // (Final|Native|Public) // @ game+0x95662f0
	void OnTargetActorDestroyed(struct AActor* DestroyedActor); // Function FortniteAI.FortAthenaAIBotController.OnTargetActorDestroyed // (Final|Native|Public) // @ game+0x9566200
	void OnServerMarkerAdded(struct FFortWorldMarkerData& MarkerData); // Function FortniteAI.FortAthenaAIBotController.OnServerMarkerAdded // (Final|Native|Public|HasOutParms) // @ game+0x9567220
	void OnPossessedPawnReceiveDamage(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAthenaAIBotController.OnPossessedPawnReceiveDamage // (Final|Native|Public|HasDefaults) // @ game+0x9562fb0
	void OnPossesedPawnDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAthenaAIBotController.OnPossesedPawnDied // (Final|Native|Public|HasDefaults) // @ game+0x95656b0
	void OnPerceptionSensed(struct AActor* SourceActor, struct FAIStimulus Stim); // Function FortniteAI.FortAthenaAIBotController.OnPerceptionSensed // (Native|Public) // @ game+0x9567e20
	void OnPawnWeaponChanged(struct AFortWeapon* NewWeapon, struct AFortWeapon* OldWeapon); // Function FortniteAI.FortAthenaAIBotController.OnPawnWeaponChanged // (Final|Native|Public) // @ game+0x9565b70
	void OnPawnDidDamage(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAthenaAIBotController.OnPawnDidDamage // (Final|Native|Public|HasDefaults) // @ game+0x95651b0
	void OnMovementModeChange(struct ACharacter* InCharacter, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function FortniteAI.FortAthenaAIBotController.OnMovementModeChange // (Final|Native|Public) // @ game+0x9565d10
	void OnLaunched(struct FVector LaunchVelocity, bool bXYOverride, bool bZOverride); // Function FortniteAI.FortAthenaAIBotController.OnLaunched // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9564c60
	void OnKnockbacked(struct FGameplayTag KnockbackTypeTag); // Function FortniteAI.FortAthenaAIBotController.OnKnockbacked // (Final|Native|Public|BlueprintCallable) // @ game+0x9564b70
	void OnEndSpectating(struct AFortPlayerStateZone* Spectator); // Function FortniteAI.FortAthenaAIBotController.OnEndSpectating // (Final|Native|Public) // @ game+0x34e0930
	void OnCurrentHarvestableDestroyed(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAthenaAIBotController.OnCurrentHarvestableDestroyed // (Final|Native|Protected|HasDefaults) // @ game+0x9563bd0
	void OnBeginSpectating(struct AFortPlayerStateZone* Spectator); // Function FortniteAI.FortAthenaAIBotController.OnBeginSpectating // (Final|Native|Public) // @ game+0x34e0930
	void OnAlertLevelChanged(enum class EAlertLevel OldAlertLevel, enum class EAlertLevel NewAlertLevel); // Function FortniteAI.FortAthenaAIBotController.OnAlertLevelChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnAgentDBNO(struct AFortPawn* InPlayer, bool bInIsDBNO); // Function FortniteAI.FortAthenaAIBotController.OnAgentDBNO // (Final|Native|Public) // @ game+0x9565fe0
	void NotifyPickupsSpawnedOnDeath(struct TArray<struct AFortPickup*>& SpawnedPickups, int32_t SpawnRequestId); // Function FortniteAI.FortAthenaAIBotController.NotifyPickupsSpawnedOnDeath // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x95621f0
	bool IsAnAthenaGameParticipant(); // Function FortniteAI.FortAthenaAIBotController.IsAnAthenaGameParticipant // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95643a0
	struct UFortWorldItem* GetSlotItemByTag(struct FGameplayTag& TagToCheck); // Function FortniteAI.FortAthenaAIBotController.GetSlotItemByTag // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x95650b0
	struct UFortWorldItem* GetSlotItemByItemDefinition(struct UFortItemDefinition* ItemDefinition); // Function FortniteAI.FortAthenaAIBotController.GetSlotItemByItemDefinition // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9564f80
	struct UAthenaMarkerComponent* GetMarkerComponent(); // Function FortniteAI.FortAthenaAIBotController.GetMarkerComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9564f60
	struct AActor* GetCurrentThreat(); // Function FortniteAI.FortAthenaAIBotController.GetCurrentThreat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9567350
	struct AActor* GetBotOwner(); // Function FortniteAI.FortAthenaAIBotController.GetBotOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95640b0
	struct AFortWeapon* EquipWeaponByTag(struct FGameplayTag& WeaponTag); // Function FortniteAI.FortAthenaAIBotController.EquipWeaponByTag // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9566ef0
	struct AFortWeapon* EquipWeapon(struct UFortWorldItem* Weapon); // Function FortniteAI.FortAthenaAIBotController.EquipWeapon // (Final|Native|Public|BlueprintCallable) // @ game+0x9566ff0
	struct AFortWeapon* EquipMeleeWeapon(); // Function FortniteAI.FortAthenaAIBotController.EquipMeleeWeapon // (Final|Native|Public|BlueprintCallable) // @ game+0x95670e0
	struct AFortWeapon* EquipBestWeapon(); // Function FortniteAI.FortAthenaAIBotController.EquipBestWeapon // (Final|Native|Public|BlueprintCallable) // @ game+0x95671a0
	void Cheat_ForceAthenaCosmeticItemInSlot(struct UAthenaCosmeticItemDefinition* CosmeticItem, enum class EAthenaCustomizationCategory Slot, int32_t Index); // Function FortniteAI.FortAthenaAIBotController.Cheat_ForceAthenaCosmeticItemInSlot // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x95638d0
	void Cheat_ClearForcedCosmeticItems(); // Function FortniteAI.FortAthenaAIBotController.Cheat_ClearForcedCosmeticItems // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x9563870
	void ChangeActiveVariantForCosmeticItem(struct FName ItemTemplateToChange, struct FGameplayTag VariantChannelToChange, struct FGameplayTag DesiredActiveVariant); // Function FortniteAI.FortAthenaAIBotController.ChangeActiveVariantForCosmeticItem // (BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x95674c0
	void BlueprintOnBehaviorTreeStarted(); // Function FortniteAI.FortAthenaAIBotController.BlueprintOnBehaviorTreeStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void AddTargetInfos(struct TArray<struct AActor*>& Targets, enum class EPerceptionState PerceptionState, float ForgetTime, float ForgetDistance); // Function FortniteAI.FortAthenaAIBotController.AddTargetInfos // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x95643d0
	void AddTargetInfo(struct AActor* Target, bool bForceTarget, enum class EPerceptionState PerceptionState, float ForgetTime, float ForgetDistance); // Function FortniteAI.FortAthenaAIBotController.AddTargetInfo // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9564710
};

// Class FortniteAI.FortAthenaAIBotNameDataAsset
// Size: 0x80 (Inherited: 0x30)
struct UFortAthenaAIBotNameDataAsset : UDataAsset {
	struct TSoftObjectPtr<UDataTable> DefaultNameDataTable; // 0x30(0x20)
	struct TSoftObjectPtr<UDataTable> ChinaNameDataTable; // 0x50(0x20)
	struct TArray<struct FFortAthenaAIBotNameRegionData> RegionData; // 0x70(0x10)
};

// Class FortniteAI.FortAthenaTrackableAIObjectComponent
// Size: 0xe0 (Inherited: 0xa0)
struct UFortAthenaTrackableAIObjectComponent : UActorComponent {
	char pad_A0[0x10]; // 0xa0(0x10)
	struct FGameplayTagContainer GameplayTags; // 0xb0(0x20)
	char pad_D0[0x8]; // 0xd0(0x08)
	ClassPtrProperty CustomRegistrationClass; // 0xd8(0x08)
};

// Class FortniteAI.FortAthenaTrackableAIObjectVehicleComponent
// Size: 0xe0 (Inherited: 0xe0)
struct UFortAthenaTrackableAIObjectVehicleComponent : UFortAthenaTrackableAIObjectComponent {

	void HandleSleepStateChanged(bool bIsAwake); // Function FortniteAI.FortAthenaTrackableAIObjectVehicleComponent.HandleSleepStateChanged // (Final|Native|Private) // @ game+0x959fda0
};

// Class FortniteAI.FortBlackboardComponent
// Size: 0x1a8 (Inherited: 0x1a8)
struct UFortBlackboardComponent : UBlackboardComponent {
};

// Class FortniteAI.FortBTDecorator_QueryGameplayAbility
// Size: 0x100 (Inherited: 0x68)
struct UFortBTDecorator_QueryGameplayAbility : UBTDecorator {
	struct FGameplayTagContainer GameplayAbilityTag; // 0x68(0x20)
	struct FBlackboardKeySelector GameplayAbilityTagBlackboardKey; // 0x88(0x28)
	struct FBlackboardKeySelector Target; // 0xb0(0x28)
	struct FGameplayTagContainer ActiveAbilityTagsToSkipTesting; // 0xd8(0x20)
	bool bUseTarget; // 0xf8(0x01)
	bool bUseBlackboardTag; // 0xf9(0x01)
	char pad_FA[0x6]; // 0xfa(0x06)
};

// Class FortniteAI.FortBTTask_TriggerVOEvent
// Size: 0xa0 (Inherited: 0x70)
struct UFortBTTask_TriggerVOEvent : UBTTaskNode {
	char bUseFeedbackBank : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FString CustomEventName; // 0x78(0x10)
	struct FString SelectedEvent; // 0x88(0x10)
	struct UFortFeedbackBank* FeedbackBank; // 0x98(0x08)
};

// Class FortniteAI.FortCreativeCreatureManagerInfoComponent
// Size: 0x208 (Inherited: 0x158)
struct UFortCreativeCreatureManagerInfoComponent : UFortMinigameLogicComponent {
	char pad_158[0x18]; // 0x158(0x18)
	struct TSoftClassPtr<UObject> CreatureBlueprintClass; // 0x170(0x20)
	int32_t MaxHealth; // 0x190(0x04)
	float HearingAggroRange; // 0x194(0x04)
	int32_t ScorePoints; // 0x198(0x04)
	float DamageCaused; // 0x19c(0x04)
	float EnvironmentalDamageOverride; // 0x1a0(0x04)
	float MovementSpeedMultiplier; // 0x1a4(0x04)
	bool bImmuneToWeaponKnockback; // 0x1a8(0x01)
	char pad_1A9[0x7]; // 0x1a9(0x07)
	struct UFortCreativeCreatureManagerComponent* CreatureManagerComponent; // 0x1b0(0x08)
	struct UGameplayEffect* DamageOverrideEffect; // 0x1b8(0x08)
	struct UGameplayEffect* EnvironmentalDamageOverrideEffect; // 0x1c0(0x08)
	struct UGameplayEffect* MovementSpeedOverrideEffect; // 0x1c8(0x08)
	struct UGameplayEffect* WeaponKnockbackImmunityEffect; // 0x1d0(0x08)
	struct UGameplayEffect* MaxHealthOverrideEffect; // 0x1d8(0x08)
	enum class EScoreDistributionType ScoreDistribution; // 0x1e0(0x01)
	enum class ECreatureManagerAffectedTargets AffectedTargetsType; // 0x1e1(0x01)
	char pad_1E2[0x26]; // 0x1e2(0x26)

	void SetWeaponKnockbackImmunityEffect(struct UGameplayEffect* Effect); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetWeaponKnockbackImmunityEffect // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2850
	void SetWeaponKnockbackImmunity(bool InImmuneToWeaponKnockback); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetWeaponKnockbackImmunity // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2d20
	void SetScorePoints(int32_t InScorePoints); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetScorePoints // (Final|Native|Public|BlueprintCallable) // @ game+0x95a3400
	void SetScoreDistribution(enum class EScoreDistributionType InScoreDistribution); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetScoreDistribution // (Final|Native|Public|BlueprintCallable) // @ game+0x95a32d0
	void SetOverrideDamage(float InOverrideDamage); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetOverrideDamage // (Final|Native|Public|BlueprintCallable) // @ game+0x95a3070
	void SetMovementSpeedOverrideEffect(struct UGameplayEffect* Effect); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetMovementSpeedOverrideEffect // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2940
	void SetMovementSpeedMultiplier(float InOverrideMovementSpeedMultiplier); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetMovementSpeedMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2f60
	void SetMovementOverrideTag(struct FGameplayTag tag); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetMovementOverrideTag // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2580
	void SetMaxHealthOverrideTag(struct FGameplayTag tag); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetMaxHealthOverrideTag // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2490
	void SetMaxHealthOverrideEffect(struct UGameplayEffect* Effect); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetMaxHealthOverrideEffect // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2760
	void SetMaxHealth(int32_t InMaxHealth); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetMaxHealth // (Final|Native|Public|BlueprintCallable) // @ game+0x95a3530
	void SetHearingAggroRange(float InHearingAggroRange); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetHearingAggroRange // (Final|Native|Public|BlueprintCallable) // @ game+0x5335370
	void SetEnvironmentalDamageOverrideEffect(struct UGameplayEffect* Effect); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetEnvironmentalDamageOverrideEffect // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2a30
	void SetEnvironmentalDamageOverride(float InOverrideDamage); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetEnvironmentalDamageOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x95a31a0
	void SetDamageOverrideTag(struct FGameplayTag tag); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetDamageOverrideTag // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2670
	void SetDamageOverrideEffect(struct UGameplayEffect* Effect); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetDamageOverrideEffect // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2b20
	void SetCreatureManagerComponent(struct UFortCreativeCreatureManagerComponent* InCreatureManagerComponent); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetCreatureManagerComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2c10
	void SetCreatureBlueprintClass(struct TSoftClassPtr<UObject> InCreatureBlueprintClass); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetCreatureBlueprintClass // (Final|Native|Public|BlueprintCallable) // @ game+0x95a3620
	void SetAffectedTargetsType(enum class ECreatureManagerAffectedTargets InAffectedTargetsType); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.SetAffectedTargetsType // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2e30
	void ResetWeaponKnockbackImmunity(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.ResetWeaponKnockbackImmunity // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2d00
	void ResetScorePoints(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.ResetScorePoints // (Final|Native|Public|BlueprintCallable) // @ game+0x95a33e0
	void ResetScoreDistribution(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.ResetScoreDistribution // (Final|Native|Public|BlueprintCallable) // @ game+0x95a32b0
	void ResetOverrideDamage(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.ResetOverrideDamage // (Final|Native|Public|BlueprintCallable) // @ game+0x95a3050
	void ResetMovementSpeedMultiplier(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.ResetMovementSpeedMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x95a2f40
	void ResetMaxHealth(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.ResetMaxHealth // (Final|Native|Public|BlueprintCallable) // @ game+0x95a3510
	void ResetHearingAggroRange(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.ResetHearingAggroRange // (Final|Native|Public|BlueprintCallable) // @ game+0x95a34f0
	void ResetEnvironmentalDamageOverride(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.ResetEnvironmentalDamageOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x95a3180
	bool GetWeaponKnockbackImmunity(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetWeaponKnockbackImmunity // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95a2e10
	int32_t GetScorePoints(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetScorePoints // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ec3ad0
	enum class EScoreDistributionType GetScoreDistribution(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetScoreDistribution // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95a33c0
	float GetOverrideDamage(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetOverrideDamage // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95a3160
	float GetMovementSpeedMultiplier(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetMovementSpeedMultiplier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x533e0d0
	int32_t GetMaxHealth(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetMaxHealth // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5334880
	int32_t GetInvalidInt32(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetInvalidInt32 // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x41e8360
	float GetInvalidFloat(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetInvalidFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x95a2470
	float GetHearingAggroRange(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetHearingAggroRange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ec3c10
	float GetEnvironmentalDamageOverride(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetEnvironmentalDamageOverride // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95a3290
	struct UFortCreativeCreatureManagerComponent* GetCreatureManagerComponent(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetCreatureManagerComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x39961b0
	struct TSoftClassPtr<UObject> GetCreatureBlueprintClass(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetCreatureBlueprintClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95a37e0
	enum class ECreatureManagerAffectedTargets GetAffectedTargetsType(); // Function FortniteAI.FortCreativeCreatureManagerInfoComponent.GetAffectedTargetsType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95a2f20
};

// Class FortniteAI.FortCreativeCreatureManagerComponent
// Size: 0x160 (Inherited: 0xa0)
struct UFortCreativeCreatureManagerComponent : UActorComponent {
	struct TArray<struct UFortCreativeCreatureManagerInfoComponent*> CreatureManagerInfos; // 0xa0(0x10)
	struct TMap<struct TSoftClassPtr<UObject>, struct UFortCreativeCreatureManagerInfoComponent*> EnabledCreatureManagerInfos; // 0xb0(0x50)
	char pad_100[0x60]; // 0x100(0x60)

	void OnInfoComponentRemoved(struct UFortCreativeCreatureManagerInfoComponent* CreatureManagerInfoComponent); // Function FortniteAI.FortCreativeCreatureManagerComponent.OnInfoComponentRemoved // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x95a4320
	void OnInfoComponentAdded(struct UFortCreativeCreatureManagerInfoComponent* CreatureManagerInfoComponent); // Function FortniteAI.FortCreativeCreatureManagerComponent.OnInfoComponentAdded // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x95a44f0
	void OnAIPawnDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortCreativeCreatureManagerComponent.OnAIPawnDied // (Final|Native|Public|HasDefaults) // @ game+0x95a4620
};

// Class FortniteAI.FortCrowdManager
// Size: 0xf8 (Inherited: 0xf0)
struct UFortCrowdManager : UCrowdManager {
	char pad_F0[0x8]; // 0xf0(0x08)
};

// Class FortniteAI.FortEnemySpawn
// Size: 0x718 (Inherited: 0x710)
struct AFortEnemySpawn : ABuildingActor {
	float ClusterRadius; // 0x710(0x04)
	char pad_714[0x4]; // 0x714(0x04)
};

// Class FortniteAI.FortEnvQueryManager
// Size: 0x1b8 (Inherited: 0x158)
struct UFortEnvQueryManager : UEnvQueryManager {
	struct TArray<struct FEnvQueryManagerConfig> EnvManagerConfigPerGamePhase; // 0x158(0x10)
	struct FEnvQueryManagerConfig EnvManagerConfigSTW; // 0x168(0x30)
	char pad_198[0x20]; // 0x198(0x20)
};

// Class FortniteAI.FortQueryContext_WorldLocationParam
// Size: 0x28 (Inherited: 0x28)
struct UFortQueryContext_WorldLocationParam : UEnvQueryContext {
};

// Class FortniteAI.FortQueryItemType_Goal
// Size: 0x30 (Inherited: 0x30)
struct UFortQueryItemType_Goal : UEnvQueryItemType_ActorBase {
};

// Class FortniteAI.FortQueryTwoPointSolver
// Size: 0x140 (Inherited: 0x28)
struct UFortQueryTwoPointSolver : UObject {
	struct UEnvQuery* QueryPointA; // 0x28(0x08)
	struct UEnvQuery* QueryPointB; // 0x30(0x08)
	struct TArray<struct FEnvNamedValue> QueryParamsA; // 0x38(0x10)
	struct TArray<struct FEnvNamedValue> QueryParamsB; // 0x48(0x10)
	struct FMulticastInlineDelegate OnFinished; // 0x58(0x10)
	struct FMulticastInlineDelegate OnFailed; // 0x68(0x10)
	enum class ETwoPointSolverRotationA RotationMode; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct FRotator MinRotationOffset; // 0x80(0x18)
	struct FRotator MaxRotationOffset; // 0x98(0x18)
	char bUseNegativeAngleOffsets : 1; // 0xb0(0x01)
	char bUsePositiveAngleOffsets : 1; // 0xb0(0x01)
	char pad_B0_2 : 6; // 0xb0(0x01)
	char pad_B1[0x7f]; // 0xb1(0x7f)
	struct UFortAISystem* AISys; // 0x130(0x08)
	struct UObject* CachedQuerier; // 0x138(0x08)

	void Start(struct UObject* Querier); // Function FortniteAI.FortQueryTwoPointSolver.Start // (Final|Native|Public|BlueprintCallable) // @ game+0x95aacb0
	void SkipToNextPointA(); // Function FortniteAI.FortQueryTwoPointSolver.SkipToNextPointA // (Final|Native|Public|BlueprintCallable) // @ game+0x95aaba0
	void SetCustomRotationA(struct FRotator& Rotation); // Function FortniteAI.FortQueryTwoPointSolver.SetCustomRotationA // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x95aabc0
	void OnCustomRotationMode(struct FVector& InPointA, struct FVector Querier); // Function FortniteAI.FortQueryTwoPointSolver.OnCustomRotationMode // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	struct FRotator GetRandomRotationOffset(); // Function FortniteAI.FortQueryTwoPointSolver.GetRandomRotationOffset // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x95aa7e0
	void AddNamedFloatParamB(struct FName ParamName, float Value); // Function FortniteAI.FortQueryTwoPointSolver.AddNamedFloatParamB // (Final|Native|Public|BlueprintCallable) // @ game+0x95aa820
	void AddNamedFloatParamA(struct FName ParamName, float Value); // Function FortniteAI.FortQueryTwoPointSolver.AddNamedFloatParamA // (Final|Native|Public|BlueprintCallable) // @ game+0x95aa9e0
};

// Class FortniteAI.FortForcedLODZone
// Size: 0x298 (Inherited: 0x290)
struct AFortForcedLODZone : AActor {
	enum class EFortAILODLevel ForcedLODLevel; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
};

// Class FortniteAI.FortGameplayAbility_TeleportToActor
// Size: 0xb60 (Inherited: 0xb28)
struct UFortGameplayAbility_TeleportToActor : UFortGameplayAbility {
	char pad_B28[0x4]; // 0xb28(0x04)
	bool bCheckPlayerLOSWhenTeleporting; // 0xb2c(0x01)
	char pad_B2D[0x3]; // 0xb2d(0x03)
	float MaxDistanceToConsiderLOS; // 0xb30(0x04)
	float PlayerFOV; // 0xb34(0x04)
	float TeleportDelay; // 0xb38(0x04)
	int32_t TeleportRetries; // 0xb3c(0x04)
	float RetryDelay; // 0xb40(0x04)
	char pad_B44[0xc]; // 0xb44(0x0c)
	struct UEnvQuery* FindTeleportSpotEQSQuery; // 0xb50(0x08)
	char pad_B58[0x8]; // 0xb58(0x08)

	void PreTeleportPawn(struct AFortPawn* TeleportedPawn); // Function FortniteAI.FortGameplayAbility_TeleportToActor.PreTeleportPawn // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void PostTeleportedPawn(struct AFortPawn* TeleportedPawn); // Function FortniteAI.FortGameplayAbility_TeleportToActor.PostTeleportedPawn // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class FortniteAI.FortIntensityCurveSequence
// Size: 0x48 (Inherited: 0x30)
struct UFortIntensityCurveSequence : UDataAsset {
	struct TArray<struct FDataTableRowHandle> IntensityCurves; // 0x30(0x10)
	enum class EFortIntensityCurveSequenceType SequenceType; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class FortniteAI.FortIntensityCurveSequenceProgression
// Size: 0x40 (Inherited: 0x30)
struct UFortIntensityCurveSequenceProgression : UDataAsset {
	struct TArray<struct FFortInstensityCurveSequenceProgression> IntensityCurveSequences; // 0x30(0x10)
};

// Class FortniteAI.FortJumpDownLink
// Size: 0x2e0 (Inherited: 0x2e0)
struct AFortJumpDownLink : ANavLinkProxy {
};

// Class FortniteAI.FortNavGraphGoal
// Size: 0x2a0 (Inherited: 0x290)
struct AFortNavGraphGoal : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	float GraphRadius; // 0x298(0x04)
	char pad_29C[0x4]; // 0x29c(0x04)
};

// Class FortniteAI.FortNavLinkBlockerComponent
// Size: 0x5b0 (Inherited: 0x5b0)
struct UFortNavLinkBlockerComponent : UBoxComponent {
};

// Class FortniteAI.FortNavLinkContainer
// Size: 0x290 (Inherited: 0x290)
struct AFortNavLinkContainer : AActor {
};

// Class FortniteAI.FortNavLinkDefinition
// Size: 0x80 (Inherited: 0x50)
struct UFortNavLinkDefinition : UNavLinkDefinition {
	struct FFortNavLinkPattern Pattern; // 0x50(0x08)
	struct TArray<struct FFortNavLinkPattern> AdditionalPatterns; // 0x58(0x10)
	struct TArray<enum class EBuildingStairsRailing> StairsRailing; // 0x68(0x10)
	enum class EBuildingFloorRailing FloorRailing; // 0x78(0x01)
	enum class EFortNavLinkPattern PatternType; // 0x79(0x01)
	char pad_7A[0x6]; // 0x7a(0x06)
};

// Class FortniteAI.FortNavMesh
// Size: 0x5b0 (Inherited: 0x5a8)
struct AFortNavMesh : ARecastNavMesh {
	struct UFortAIHotSpotManager* HotSpotManager; // 0x5a8(0x08)
};

// Class FortniteAI.FortNavObstacleComponent
// Size: 0xf8 (Inherited: 0xf0)
struct UFortNavObstacleComponent : UNavRelevantComponent {
	struct UNavArea* ObstacleAreaClass; // 0xf0(0x08)
};

// Class FortniteAI.FortNavSystem
// Size: 0x17c8 (Inherited: 0x1588)
struct UFortNavSystem : UNavigationSystemV1 {
	char pad_1588[0x10]; // 0x1588(0x10)
	struct TSoftClassPtr<UObject> DefaultSmashableArea; // 0x1598(0x20)
	struct TSoftClassPtr<UObject> JumpDownArea; // 0x15b8(0x20)
	char pad_15D8[0x20]; // 0x15d8(0x20)
	struct TSoftClassPtr<UObject> JumpDownSmashableArea2; // 0x15f8(0x20)
	struct TSoftClassPtr<UObject> JumpDownSmashableArea3; // 0x1618(0x20)
	struct TArray<struct UFortCustomNavLinkGlobalProxy*> LinkGlobalProxies; // 0x1638(0x10)
	struct TArray<struct ARecastNavMesh*> NamedNavmeshes; // 0x1648(0x10)
	struct TArray<struct UFortNavLinkBlockerComponent*> NavLinkBlockers; // 0x1658(0x10)
	char pad_1668[0x10]; // 0x1668(0x10)
	struct TArray<struct UFortPathCostEstimator*> PathEstimators; // 0x1678(0x10)
	struct TArray<struct UFortInescapableZoneTracker*> InescapableZones; // 0x1688(0x10)
	char bAllowAutoRebuild : 1; // 0x1698(0x01)
	char bRebuildOnInitialUnlock : 1; // 0x1698(0x01)
	char bUsesStreamedInNavLevel : 1; // 0x1698(0x01)
	char bUseStaticMeshLinks : 1; // 0x1698(0x01)
	char bUseStaticWorldLinksDown : 1; // 0x1698(0x01)
	char bUseStaticWorldLinksUp : 1; // 0x1698(0x01)
	char bUseJumpLinkActors : 1; // 0x1698(0x01)
	char bGenerateWallClimbLinks : 1; // 0x1698(0x01)
	char bGenerateClamberLinks : 1; // 0x1699(0x01)
	char pad_1699_1 : 7; // 0x1699(0x01)
	char pad_169A[0x2]; // 0x169a(0x02)
	int32_t UndermineHorizontalTileLimit; // 0x169c(0x04)
	int32_t UndermineVerticalTileLimit; // 0x16a0(0x04)
	float DirtyAreasUpdateFreqInactive; // 0x16a4(0x04)
	char pad_16A8[0xd8]; // 0x16a8(0xd8)
	struct AFortNavigationGraph* NavGraphData; // 0x1780(0x08)
	struct TArray<struct TWeakObjectPtr<struct AActor>> CompositePathGoals; // 0x1788(0x10)
	struct TArray<struct FBox> AtlasCells; // 0x1798(0x10)
	char pad_17A8[0x10]; // 0x17a8(0x10)
	struct TArray<struct FMetaNavCachedEntry> MetaNavCachedAreas; // 0x17b8(0x10)

	void OnNavDataRegistered(struct ANavigationData* NavData); // Function FortniteAI.FortNavSystem.OnNavDataRegistered // (Final|Native|Protected) // @ game+0x95b10b0
	bool IsNavmeshInRadiusInitialized(struct UObject* WorldContext, struct FVector& TestLocation, float TestRadius); // Function FortniteAI.FortNavSystem.IsNavmeshInRadiusInitialized // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x95b1230
};

// Class FortniteAI.FortNavSystemConfig
// Size: 0x60 (Inherited: 0x58)
struct UFortNavSystemConfig : UNavigationSystemModuleConfig {
	char bAllowAutoRebuild : 1; // 0x58(0x01)
	char bRebuildOnInitialUnlock : 1; // 0x58(0x01)
	char bUsesStreamedInNavLevel : 1; // 0x58(0x01)
	char pad_58_3 : 5; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class FortniteAI.FortPatrolWardInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortPatrolWardInterface : UInterface {

	enum class EWardAffectType GetAffectingType(); // Function FortniteAI.FortPatrolWardInterface.GetAffectingType // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent|Const) // @ game+0x1b027f0
	float GetAffectingDistance(); // Function FortniteAI.FortPatrolWardInterface.GetAffectingDistance // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent|Const) // @ game+0x1b027f0
};

// Class FortniteAI.FortPlacedPawnMarker
// Size: 0x2b8 (Inherited: 0x2b8)
struct AFortPlacedPawnMarker : ANavigationObjectBase {
};

// Class FortniteAI.FortRiftBlockerComponent
// Size: 0x5b0 (Inherited: 0x5b0)
struct UFortRiftBlockerComponent : UBoxComponent {
	char bStartActive : 1; // 0x5a8(0x01)
};

// Class FortniteAI.FortStaticMeshLinkComponent
// Size: 0x138 (Inherited: 0xf0)
struct UFortStaticMeshLinkComponent : UNavRelevantComponent {
	char pad_F0[0x48]; // 0xf0(0x48)
};

// Class FortniteAI.FortThreatVisualsManager
// Size: 0x548 (Inherited: 0x290)
struct AFortThreatVisualsManager : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct AThreatCloud* CloudBlueprint; // 0x298(0x08)
	float CloudRadius; // 0x2a0(0x04)
	float ThreatBoxVolumeTopPadding; // 0x2a4(0x04)
	float ThreatBoxVolumeBottomPadding; // 0x2a8(0x04)
	bool bUseLocalPlayersOnlyForCloudMinimumHeight; // 0x2ac(0x01)
	bool bHideClouds; // 0x2ad(0x01)
	char pad_2AE[0x2]; // 0x2ae(0x02)
	float CloudMinimumHeightAbovePlayers; // 0x2b0(0x04)
	float CloudMinimumHeightAboveGround; // 0x2b4(0x04)
	float CloudMinimumAltitude; // 0x2b8(0x04)
	float CloudMaxVerticalDelta; // 0x2bc(0x04)
	float CloudMinSpeed; // 0x2c0(0x04)
	float CloudMaxSpeed; // 0x2c4(0x04)
	float StormWindCloudRadius; // 0x2c8(0x04)
	float StormWindGoalRadius; // 0x2cc(0x04)
	float StormWindFalloffRadius; // 0x2d0(0x04)
	float StormWindInactiveMagnitude; // 0x2d4(0x04)
	float StormWindActiveMagnitude; // 0x2d8(0x04)
	float StormWindDesiredDeltaBlendTime; // 0x2dc(0x04)
	float StormWindDirectionAdditionalAngle; // 0x2e0(0x04)
	char pad_2E4[0x4]; // 0x2e4(0x04)
	struct FThreatLocationArray ThreatLocations; // 0x2e8(0x118)
	struct FStormWindArray StormWindArray; // 0x400(0x118)
	struct TArray<struct FVector> GoalActorLocations; // 0x518(0x10)
	char pad_528[0x20]; // 0x528(0x20)

	bool StormsExist(); // Function FortniteAI.FortThreatVisualsManager.StormsExist // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95c82d0
	void SetMinimumCloudAltitude(float NewMinimumAltitude); // Function FortniteAI.FortThreatVisualsManager.SetMinimumCloudAltitude // (Final|Native|Public|BlueprintCallable) // @ game+0x95c7eb0
	void SetCloudsAreHidden(bool bHide); // Function FortniteAI.FortThreatVisualsManager.SetCloudsAreHidden // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x95c7d80
	void ResetMinimumCloudAltitude(); // Function FortniteAI.FortThreatVisualsManager.ResetMinimumCloudAltitude // (Final|Native|Public|BlueprintCallable) // @ game+0x95c7e90
	void OnWorldReady(); // Function FortniteAI.FortThreatVisualsManager.OnWorldReady // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnThreatCloudsChanged(struct TArray<struct FThreatLocationInfo>& ThreatLocationInfo); // Function FortniteAI.FortThreatVisualsManager.OnThreatCloudsChanged // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnRep_ThreatLocations(); // Function FortniteAI.FortThreatVisualsManager.OnRep_ThreatLocations // (Final|Native|Private) // @ game+0x3c1aef0
	void OnRep_StormWinds(); // Function FortniteAI.FortThreatVisualsManager.OnRep_StormWinds // (Final|Native|Private) // @ game+0x3c1af10
	void OnRep_HideClouds(); // Function FortniteAI.FortThreatVisualsManager.OnRep_HideClouds // (Final|Native|Private) // @ game+0x3c1aed0
	void OnRep_GoalActorLocations(); // Function FortniteAI.FortThreatVisualsManager.OnRep_GoalActorLocations // (Final|Native|Private) // @ game+0x45d4560
	void OnBeginThreatVisualsPrecursor(struct AActor* SourceActor, struct FVector& EndLocation); // Function FortniteAI.FortThreatVisualsManager.OnBeginThreatVisualsPrecursor // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	struct TArray<struct FThreatLocationInfo> GetThreatClouds(); // Function FortniteAI.FortThreatVisualsManager.GetThreatClouds // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95c7fa0
	struct AThreatCloud* GetThreatCloud(struct FThreatLocationInfo& ThreatLocInfo); // Function FortniteAI.FortThreatVisualsManager.GetThreatCloud // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x95c8100
	bool GetCloudsAreHidden(); // Function FortniteAI.FortThreatVisualsManager.GetCloudsAreHidden // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x82f1d00
	void BeginThreatVisualsPrecursor(struct AActor* SourceActor, struct FVector ThreatLocation); // Function FortniteAI.FortThreatVisualsManager.BeginThreatVisualsPrecursor // (Net|NetReliableNative|Event|NetMulticast|Public|HasDefaults) // @ game+0x95c7be0
};

// Class FortniteAI.AIGoalComponent
// Size: 0x108 (Inherited: 0xa0)
struct UAIGoalComponent : UGameFrameworkComponent {
	char pad_A0[0x68]; // 0xa0(0x68)
};

// Class FortniteAI.FortAIGoalComponent
// Size: 0x158 (Inherited: 0x108)
struct UFortAIGoalComponent : UAIGoalComponent {
	struct TMap<enum class EFortAILODLevel, struct FScalableFloat> AssignmentUpdatePeriods; // 0x108(0x50)
};

// Class FortniteAI.FortAIGoalProvider
// Size: 0x48 (Inherited: 0x28)
struct UFortAIGoalProvider : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UWorld* World; // 0x30(0x08)
	struct UFortAIAssignment* AssignmentOwner; // 0x38(0x08)
	struct UFortAIEncounterInfo* EncounterInfo; // 0x40(0x08)

	void UpdateGoals(); // Function FortniteAI.FortAIGoalProvider.UpdateGoals // (Native|Public|BlueprintCallable) // @ game+0x3b35ce0
	bool InitializeGoalProvider(struct UWorld* ContextWorld, struct UFortAIAssignment* Assignment); // Function FortniteAI.FortAIGoalProvider.InitializeGoalProvider // (Native|Public|BlueprintCallable) // @ game+0x95cf880
	struct UFortAIEncounterInfo* GetEncounterInfo(); // Function FortniteAI.FortAIGoalProvider.GetEncounterInfo // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x95cf840
};

// Class FortniteAI.FortAIGoalProvider_EnvQuery
// Size: 0xd0 (Inherited: 0x48)
struct UFortAIGoalProvider_EnvQuery : UFortAIGoalProvider {
	char pad_48[0x8]; // 0x48(0x08)
	struct UEnvQuery* GoalQuery; // 0x50(0x08)
	float AutomaticUpdatePeriodInSeconds; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FFortAIAssignmentIdentifier SpecificAssignmentContext; // 0x60(0x30)
	struct TSoftClassPtr<UObject> AIPawnContext; // 0x90(0x20)
	char pad_B0[0x20]; // 0xb0(0x20)
};

// Class FortniteAI.FortAIEncounterGoalSelectionTable
// Size: 0x40 (Inherited: 0x30)
struct UFortAIEncounterGoalSelectionTable : UDataAsset {
	struct TArray<struct FEncounterGoalSelectionTableEntry> EncounterGoalSelectionCriteria; // 0x30(0x10)
};

// Class FortniteAI.AIHotSpotConfig
// Size: 0x50 (Inherited: 0x30)
struct UAIHotSpotConfig : UDataAsset {
	struct TArray<struct FAIHotSpotSlotConfig> Slots; // 0x30(0x10)
	char bDetectUnreachableSlots : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct UAIHotSpotSlotGenerator* SlotGenerator; // 0x48(0x08)
};

// Class FortniteAI.AIHotSpotSlotGenerator
// Size: 0x28 (Inherited: 0x28)
struct UAIHotSpotSlotGenerator : UObject {

	struct AAIHotSpot* GetHotSpot(); // Function FortniteAI.AIHotSpotSlotGenerator.GetHotSpot // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94d3df0
	void GenerateSlots(); // Function FortniteAI.AIHotSpotSlotGenerator.GenerateSlots // (Native|Event|Public|BlueprintEvent) // @ game+0x3b35d00
	struct UAIHotSpotSlot* AddSlot(struct FVector& RelativeLocation, struct FRotator& RelativeRotation, struct UAIHotSpotSlot* CustomSlotClass, bool bEnabled); // Function FortniteAI.AIHotSpotSlotGenerator.AddSlot // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x95e2ea0
};

// Class FortniteAI.AIHotSpotSlotGenerator_OnBoundingBox
// Size: 0x98 (Inherited: 0x28)
struct UAIHotSpotSlotGenerator_OnBoundingBox : UAIHotSpotSlotGenerator {
	struct UAIHotSpotSlot* SlotClass; // 0x28(0x08)
	struct FVector MaxExtent; // 0x30(0x18)
	float ExpandBy; // 0x48(0x04)
	float OffsetFromEdge; // 0x4c(0x04)
	float Spacing; // 0x50(0x04)
	char bLimitMaxExtent : 1; // 0x54(0x01)
	char bMustHitFocusActor : 1; // 0x54(0x01)
	char pad_54_2 : 6; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	enum class EBoundingBoxSlotDirectionCalculation SlotDirectionCalculation; // 0x58(0x01)
	char pad_59[0x3f]; // 0x59(0x3f)
};

// Class FortniteAI.BuildingActorHotSpotConfig
// Size: 0x158 (Inherited: 0x30)
struct UBuildingActorHotSpotConfig : UDataAsset {
	struct FBuildingActorHotSpotDirection DirectionSetup[0x6]; // 0x30(0xf0)
	struct FBuildingActorHotSpotDirection DefaultSetup; // 0x120(0x28)
	struct UAIHotSpotConfig* ExtraTypeConfig; // 0x148(0x08)
	char bHasDirectionalSetup : 1; // 0x150(0x01)
	char pad_150_1 : 7; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
};

// Class FortniteAI.BuildingActorHotSpotRenderingComponent
// Size: 0x5c0 (Inherited: 0x5c0)
struct UBuildingActorHotSpotRenderingComponent : UDebugDrawComponent {
};

// Class FortniteAI.FortAIHotSpot
// Size: 0x468 (Inherited: 0x440)
struct AFortAIHotSpot : AAIHotSpot {
	char pad_440[0x28]; // 0x440(0x28)
};

// Class FortniteAI.FortAIHotSpotManager
// Size: 0x1c0 (Inherited: 0x80)
struct UFortAIHotSpotManager : UAIHotSpotManagerProxy {
	struct TSoftObjectPtr<UBuildingActorHotSpotConfig> FallbackHotspotConfig; // 0x80(0x20)
	char pad_A0[0xf0]; // 0xa0(0xf0)
	struct TArray<struct FAutoAcquireSlot> AutoAcquireSlots; // 0x190(0x10)
	char pad_1A0[0x20]; // 0x1a0(0x20)
};

// Class FortniteAI.FortAIHotSpotSlot
// Size: 0x130 (Inherited: 0x120)
struct UFortAIHotSpotSlot : UAIHotSpotSlot {
	enum class EFortHotSpotSlot SlotType; // 0x120(0x01)
	char pad_121[0x3]; // 0x121(0x03)
	char bHasProjectedLocation : 1; // 0x124(0x01)
	char bProjectedOnLowArea : 1; // 0x124(0x01)
	char bIsAutoGenerated : 1; // 0x124(0x01)
	char bCanDuplicateOnProjection : 1; // 0x124(0x01)
	char bCanProjectUp : 1; // 0x124(0x01)
	char pad_124_5 : 3; // 0x124(0x01)
	char pad_125[0xb]; // 0x125(0x0b)
};

// Class FortniteAI.FortAIHotSpotSlotGenerator_FromConfig
// Size: 0x50 (Inherited: 0x28)
struct UFortAIHotSpotSlotGenerator_FromConfig : UAIHotSpotSlotGenerator {
	struct UAIHotSpotConfig* BuildingConfig; // 0x28(0x08)
	struct FVector Offset; // 0x30(0x18)
	char bMirrorX : 1; // 0x48(0x01)
	char bMirrorY : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class FortniteAI.FortAIHotSpotSlotGenerator_OnBoundingBox
// Size: 0xa0 (Inherited: 0x98)
struct UFortAIHotSpotSlotGenerator_OnBoundingBox : UAIHotSpotSlotGenerator_OnBoundingBox {
	float DistanceForRangedSlots; // 0x98(0x04)
	float DistanceForHugeSlots; // 0x9c(0x04)
};

// Class FortniteAI.FortAIHotSpotSlotGenerator_RampTrace
// Size: 0x58 (Inherited: 0x28)
struct UFortAIHotSpotSlotGenerator_RampTrace : UAIHotSpotSlotGenerator {
	char pad_28[0x30]; // 0x28(0x30)
};

// Class FortniteAI.FortAIHotSpot_Building
// Size: 0x550 (Inherited: 0x468)
struct AFortAIHotSpot_Building : AFortAIHotSpot {
	struct UAIHotSpotConfig* ExtraTypeConfig; // 0x468(0x08)
	char pad_470[0xe0]; // 0x470(0xe0)
};

// Class FortniteAI.FortAIHotSpot_FakeBuilding
// Size: 0x468 (Inherited: 0x468)
struct AFortAIHotSpot_FakeBuilding : AFortAIHotSpot {
};

// Class FortniteAI.FortAIHotSpot_Shooting
// Size: 0x468 (Inherited: 0x468)
struct AFortAIHotSpot_Shooting : AFortAIHotSpot {
};

// Class FortniteAI.FortInfluenceMap
// Size: 0xf8 (Inherited: 0x28)
struct UFortInfluenceMap : UObject {
	char pad_28[0xb8]; // 0x28(0xb8)
	struct AFortNavigationGraph* GraphData; // 0xe0(0x08)
	char pad_E8[0x10]; // 0xe8(0x10)

	void K2_GetInfluenceSourcePositions(struct UObject* WorldContext, struct TArray<struct FVector>& InfluenceSourcePositions); // Function FortniteAI.FortInfluenceMap.K2_GetInfluenceSourcePositions // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x95fc5f0
	void K2_AddInfluenceSource(struct UObject* WorldContext, struct FVector& Position, struct FString SourceName, float Strength); // Function FortniteAI.FortInfluenceMap.K2_AddInfluenceSource // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x95fc8c0
};

// Class FortniteAI.IrwinAIController
// Size: 0x5f0 (Inherited: 0x5f0)
struct AIrwinAIController : AAthenaAIController {
};

// Class FortniteAI.LevelTestingActorBase
// Size: 0x290 (Inherited: 0x290)
struct ALevelTestingActorBase : AActor {
};

// Class FortniteAI.FortBotController
// Size: 0x568 (Inherited: 0x560)
struct AFortBotController : AFortAIController {
	struct UFortBotMissionLogic* CurrentMissionLogic; // 0x560(0x08)
};

// Class FortniteAI.FortBotMissionLogic
// Size: 0x78 (Inherited: 0x28)
struct UFortBotMissionLogic : UObject {
	struct AFortMission* Mission; // 0x28(0x08)
	struct TArray<struct AActor*> Goals; // 0x30(0x10)
	struct TArray<struct AFortBotStructureBuilder*> Builders; // 0x40(0x10)
	struct UBehaviorTree* CurrentBehaviorAsset; // 0x50(0x08)
	struct TArray<struct AFortBotController*> AssignedAI; // 0x58(0x10)
	struct TArray<char> GoalHasLocator; // 0x68(0x10)

	struct AFortBotStructureBuilder* SpawnStructureBuilder(struct AActor* MissionGoal, struct UFortBuildingInstructions* BuildingInstructions); // Function FortniteAI.FortBotMissionLogic.SpawnStructureBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x95fe4c0
	void SetGoalsInvulnerable(bool bGodMode); // Function FortniteAI.FortBotMissionLogic.SetGoalsInvulnerable // (Final|Native|Public|BlueprintCallable) // @ game+0x95fe940
	void SetCurrentBehavior(struct UBehaviorTree* Behavior); // Function FortniteAI.FortBotMissionLogic.SetCurrentBehavior // (Final|Native|Public|BlueprintCallable) // @ game+0x95feef0
	void ResetBehavior(); // Function FortniteAI.FortBotMissionLogic.ResetBehavior // (Final|Native|Public|BlueprintCallable) // @ game+0x95fee60
	void OnMissionStarted(); // Function FortniteAI.FortBotMissionLogic.OnMissionStarted // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnMissionFinished(); // Function FortniteAI.FortBotMissionLogic.OnMissionFinished // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnMissionActivated(); // Function FortniteAI.FortBotMissionLogic.OnMissionActivated // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool OnInteractWithMissionGoal(struct AFortAIController* BotAI, struct AActor* MissionGoal); // Function FortniteAI.FortBotMissionLogic.OnInteractWithMissionGoal // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool OnCanStartOtherMission(struct AFortAIController* BotAI, struct AFortMission* OtherMission); // Function FortniteAI.FortBotMissionLogic.OnCanStartOtherMission // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnAssignedBehavior(struct AFortAIController* BotAI); // Function FortniteAI.FortBotMissionLogic.OnAssignedBehavior // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void MarkSingleLocator(struct AActor* LocatorActor); // Function FortniteAI.FortBotMissionLogic.MarkSingleLocator // (Final|Native|Public|BlueprintCallable) // @ game+0x95febb0
	void MarkAllLocated(); // Function FortniteAI.FortBotMissionLogic.MarkAllLocated // (Final|Native|Public|BlueprintCallable) // @ game+0x95feb00
	void ClearAllLocated(); // Function FortniteAI.FortBotMissionLogic.ClearAllLocated // (Final|Native|Public|BlueprintCallable) // @ game+0x95fead0
};

// Class FortniteAI.FortBotMissionManager
// Size: 0xc8 (Inherited: 0x28)
struct UFortBotMissionManager : UObject {
	struct TSoftClassPtr<UObject> BotPawnClass; // 0x28(0x20)
	struct TArray<struct AFortPawn*> BotPawns; // 0x48(0x10)
	struct TArray<struct UFortBotMissionLogic*> ActiveMissionsLogicData; // 0x58(0x10)
	struct UFortBotMissionLogic* PrimaryMissionLogicData; // 0x68(0x08)
	char pad_70[0x58]; // 0x70(0x58)
};

// Class FortniteAI.FortBotStructureBuilder
// Size: 0x2c8 (Inherited: 0x290)
struct AFortBotStructureBuilder : AActor {
	struct UFortBuildingInstructions* BuildingInstructions; // 0x290(0x08)
	struct TArray<struct ABuildingActor*> BuiltActors; // 0x298(0x10)
	struct AActor* CachedGoal; // 0x2a8(0x08)
	char pad_2B0[0x18]; // 0x2b0(0x18)

	void RunDeconstructor(); // Function FortniteAI.FortBotStructureBuilder.RunDeconstructor // (Final|Native|Public|BlueprintCallable) // @ game+0x95ffc60
	void OnBuildingDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortBotStructureBuilder.OnBuildingDied // (Final|Native|Protected|HasDefaults) // @ game+0x95ff760
	void BuildAll(); // Function FortniteAI.FortBotStructureBuilder.BuildAll // (Final|Native|Public|BlueprintCallable) // @ game+0x95ffcf0
};

// Class FortniteAI.FortMetaNavArea_Obstacles
// Size: 0x50 (Inherited: 0x48)
struct UFortMetaNavArea_Obstacles : UNavAreaMeta {
	int32_t HealthThreshold; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class FortniteAI.FortNavAgentCostData
// Size: 0x48 (Inherited: 0x30)
struct UFortNavAgentCostData : UPrimaryDataAsset {
	struct FName NavAgentName; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TArray<struct UNavArea*> NavAreaStrengthBuckets; // 0x38(0x10)
};

// Class FortniteAI.FortNavAreaAutomatic
// Size: 0x68 (Inherited: 0x50)
struct UFortNavAreaAutomatic : UFortNavArea {
	struct FCurveTableRowHandle NavCostCurveHandle; // 0x50(0x10)
	int32_t NavAreaStrength; // 0x60(0x04)
	float AutomaticNavCost; // 0x64(0x04)
};

// Class FortniteAI.FortNavArea_BigMovingPawn
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_BigMovingPawn : UFortNavArea {
};

// Class FortniteAI.FortNavArea_CheapObstacle
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_CheapObstacle : UFortNavArea {
};

// Class FortniteAI.FortNavArea_Clamber
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_Clamber : UFortNavArea {
};

// Class FortniteAI.FortNavArea_ClosedDoors
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_ClosedDoors : UFortNavArea {
};

// Class FortniteAI.FortNavArea_Danger
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_Danger : UFortNavArea {
};

// Class FortniteAI.FortNavArea_DefenderNull
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_DefenderNull : UFortNavArea {
};

// Class FortniteAI.FortNavArea_HuskNull
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_HuskNull : UFortNavArea {
};

// Class FortniteAI.FortNavArea_LowJump
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_LowJump : UFortNavArea {
};

// Class FortniteAI.FortNavArea_LowSmashable
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_LowSmashable : UFortNavArea_DefaultSmashable {
};

// Class FortniteAI.FortNavArea_Obstacle
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_Obstacle : UFortNavArea {
};

// Class FortniteAI.FortNavArea_PortalOrSmash
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_PortalOrSmash : UFortNavArea {
};

// Class FortniteAI.FortNavArea_SmashableJump
// Size: 0x58 (Inherited: 0x50)
struct UFortNavArea_SmashableJump : UFortNavArea {
	int32_t Strength; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class FortniteAI.FortNavArea_Stairs
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_Stairs : UFortNavArea {
};

// Class FortniteAI.FortNavArea_StarlightCheapObstacle
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_StarlightCheapObstacle : UFortNavArea_CheapObstacle {
};

// Class FortniteAI.FortNavArea_StarlightObstacle
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_StarlightObstacle : UFortNavArea_Obstacle {
};

// Class FortniteAI.FortNavArea_StoneWall
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_StoneWall : UFortNavArea {
};

// Class FortniteAI.FortNavArea_TakerOnly
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_TakerOnly : UFortNavArea {
};

// Class FortniteAI.FortNavArea_TraceSmashable
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_TraceSmashable : UFortNavArea_DefaultSmashable {
};

// Class FortniteAI.FortNavArea_Unwalkable
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_Unwalkable : UFortNavArea {
};

// Class FortniteAI.FortNavArea_WalkOverWall
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_WalkOverWall : UFortNavArea {
};

// Class FortniteAI.FortNavArea_WallCorner
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_WallCorner : UFortNavArea {
};

// Class FortniteAI.FortNavArea_Zipline
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_Zipline : UFortNavArea {
};

// Class FortniteAI.AthenaAvoidanceManager
// Size: 0xe0 (Inherited: 0xe0)
struct UAthenaAvoidanceManager : UAvoidanceManager {
};

// Class FortniteAI.AthenaNavInvokerBox
// Size: 0x2a0 (Inherited: 0x290)
struct AAthenaNavInvokerBox : AActor {
	float GenerationRange; // 0x290(0x04)
	char pad_294[0x4]; // 0x294(0x04)
	struct UNavigationInvokerComponent* InvokerComp; // 0x298(0x08)

	void SetInvokerEnabled(bool bEnable); // Function FortniteAI.AthenaNavInvokerBox.SetInvokerEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96064c0
};

// Class FortniteAI.AthenaNavMesh
// Size: 0x6b0 (Inherited: 0x5b0)
struct AAthenaNavMesh : AFortNavMesh {
	int32_t HotSpotPathfindingMaxSearchNodes; // 0x5b0(0x04)
	float ShallowWaterTraceStartOffsetZ; // 0x5b4(0x04)
	float ShallowWaterTraceEndOffsetZ; // 0x5b8(0x04)
	int32_t MaximumTilesToProcessForWaterPerFrame; // 0x5bc(0x04)
	bool bSuspendNavmeshWhenNoAIUsersAlive; // 0x5c0(0x01)
	char pad_5C1[0x7]; // 0x5c1(0x07)
	struct TArray<struct FBox> SerializedDirtyAreas; // 0x5c8(0x10)
	char pad_5D8[0xd8]; // 0x5d8(0xd8)

	void MoveTiles(struct FBox& SourceBox, struct FIntPoint& TileOffset, float RotationDeg, struct FVector2D& FillerTilePosition); // Function FortniteAI.AthenaNavMesh.MoveTiles // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9606dd0
	void ComputeOffsetForMoveTiles(struct FVector& StartPosition, struct FVector& DesiredPosition, struct FVector& OutEndPosition, struct FIntPoint& OutTileOffset); // Function FortniteAI.AthenaNavMesh.ComputeOffsetForMoveTiles // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9607080
};

// Class FortniteAI.AthenaNavMeshRenderingComponent
// Size: 0x5d0 (Inherited: 0x5d0)
struct UAthenaNavMeshRenderingComponent : UNavMeshRenderingComponent {
};

// Class FortniteAI.AthenaNavMesh_Big
// Size: 0x6b8 (Inherited: 0x6b0)
struct AAthenaNavMesh_Big : AAthenaNavMesh {
	float MaximumDistanceToWaterForShallow; // 0x6b0(0x04)
	char pad_6B4[0x4]; // 0x6b4(0x04)
};

// Class FortniteAI.AthenaNavOctTreeInclusionBounds
// Size: 0x2c8 (Inherited: 0x2c8)
struct AAthenaNavOctTreeInclusionBounds : AVolume {
};

// Class FortniteAI.AthenaNavPresenceDetectorComponent
// Size: 0xe8 (Inherited: 0xa0)
struct UAthenaNavPresenceDetectorComponent : UActorComponent {
	bool bDisableUponNavMeshPresence; // 0xa0(0x01)
	bool bHasValidNavMesh; // 0xa1(0x01)
	char pad_A2[0x2]; // 0xa2(0x02)
	struct FName NavMeshNameToUse; // 0xa4(0x04)
	struct TArray<struct FNavMeshDetectedInfo> NavMeshesInfo; // 0xa8(0x10)
	struct FMulticastInlineDelegate NavMeshPresenceDetected; // 0xb8(0x10)
	struct FMulticastInlineDelegate NavMeshPresenceUndetected; // 0xc8(0x10)
	char pad_D8[0x10]; // 0xd8(0x10)

	void OnNavMeshTilesUpdated(struct FUpdatedNavMeshTiles& UpdatedNavMeshTiles); // Function FortniteAI.AthenaNavPresenceDetectorComponent.OnNavMeshTilesUpdated // (Final|Native|Protected|HasOutParms) // @ game+0x960d170
	bool HasValidNavMeshLocation(); // Function FortniteAI.AthenaNavPresenceDetectorComponent.HasValidNavMeshLocation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x960d290
};

// Class FortniteAI.AthenaNavRelevantActorInterface
// Size: 0x28 (Inherited: 0x28)
struct UAthenaNavRelevantActorInterface : UInterface {
};

// Class FortniteAI.AthenaNavSystem
// Size: 0x1978 (Inherited: 0x17c8)
struct UAthenaNavSystem : UFortNavSystem {
	char pad_17C8[0x8]; // 0x17c8(0x08)
	struct TArray<struct FNavDataSetVariantSettings> NavDataSetVariants; // 0x17d0(0x10)
	char bUseNavDataSetVariants : 1; // 0x17e0(0x01)
	char bMarkBuildingFoundationDirty : 1; // 0x17e0(0x01)
	char bSupportRuntimeNavmeshDisabling : 1; // 0x17e0(0x01)
	char pad_17E0_3 : 5; // 0x17e0(0x01)
	char pad_17E1[0x3]; // 0x17e1(0x03)
	float NavGenerationObserverCheckInterval; // 0x17e4(0x04)
	char pad_17E8[0x20]; // 0x17e8(0x20)
	char bAllowStaticNavigationInvokerBoxes : 1; // 0x1808(0x01)
	char pad_1808_1 : 7; // 0x1808(0x01)
	char pad_1809[0x7]; // 0x1809(0x07)
	struct TArray<struct FBoxNavInvoker> BoxInvokers; // 0x1810(0x10)
	char pad_1820[0x138]; // 0x1820(0x138)
	struct TArray<struct FBox> NavOctTreeInclusionBounds; // 0x1958(0x10)
	char pad_1968[0x10]; // 0x1968(0x10)

	void UnregisterNavGenerationObserver(struct USceneComponent* Component); // Function FortniteAI.AthenaNavSystem.UnregisterNavGenerationObserver // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x960e730
	void RegisterNavGenerationObserver(struct USceneComponent* Component, struct FDelegate Event); // Function FortniteAI.AthenaNavSystem.RegisterNavGenerationObserver // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x960e8b0
	bool IsInitialNavigationLockActive(struct UObject* WorldContextObject); // Function FortniteAI.AthenaNavSystem.IsInitialNavigationLockActive // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x960e5f0
};

// Class FortniteAI.AthenaNavSystemConfig
// Size: 0xa8 (Inherited: 0x60)
struct UAthenaNavSystemConfig : UFortNavSystemConfig {
	struct TArray<struct FNavDataSetVariantSettings> NavDataSetVariants; // 0x60(0x10)
	char bUseNavDataSetVariants : 1; // 0x70(0x01)
	char bDiscardNavDataFromSublevels : 1; // 0x70(0x01)
	char bUseNavigationInvokers : 1; // 0x70(0x01)
	char bAllowStaticNavigationInvokerBoxes : 1; // 0x70(0x01)
	char bLazyOctree : 1; // 0x70(0x01)
	char bUseNavOctTreeInclusionBounds : 1; // 0x70(0x01)
	char bPrioritizeNavigationAroundSpawners : 1; // 0x70(0x01)
	char bResetDirtyAreasOnInitialBuildingRelease : 1; // 0x70(0x01)
	char bSupportRuntimeNavmeshDisabling : 1; // 0x71(0x01)
	char bNavOctreeUnlockedByDefaultWhenNotPreloadingNavData : 1; // 0x71(0x01)
	char bConfigureDirtyAreaWarningSizeThreshold : 1; // 0x71(0x01)
	char pad_71_3 : 5; // 0x71(0x01)
	char pad_72[0x2]; // 0x72(0x02)
	float DirtyAreaWarningSizeThreshold; // 0x74(0x04)
	struct TArray<struct FOverriddenSupportedAgentsByReleaseVersion> OverriddenSupportedAgentsByReleaseVersion; // 0x78(0x10)
	bool bSuspendNavmeshWhenNoPossibleUsers; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct TArray<struct FName> AllowedNavBoundsUniqueActorTags; // 0x90(0x10)
	struct FNavAgentSelector EnableAutoNavConfigForAgent; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
};

// Class FortniteAI.FortNavArea_MetaReplacement
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_MetaReplacement : UFortNavArea {
};

// Class FortniteAI.FortNavArea_WallCornerReplacement
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_WallCornerReplacement : UFortNavArea {
};

// Class FortniteAI.FortNavArea_ObstacleReplacement
// Size: 0x50 (Inherited: 0x50)
struct UFortNavArea_ObstacleReplacement : UFortNavArea {
};

// Class FortniteAI.FortNavArea_TempWallReplacement
// Size: 0x68 (Inherited: 0x68)
struct UFortNavArea_TempWallReplacement : UFortNavAreaAutomatic {
};

// Class FortniteAI.EdgeNavLinks
// Size: 0x330 (Inherited: 0x2e0)
struct AEdgeNavLinks : ANavLinkProxy {
	float DistanceBetweenLinks; // 0x2e0(0x04)
	char pad_2E4[0x4]; // 0x2e4(0x04)
	struct FVector Start; // 0x2e8(0x18)
	struct FVector End; // 0x300(0x18)
	float SnapRadius; // 0x318(0x04)
	float SnapHeight; // 0x31c(0x04)
	float LinkProjectionHeight; // 0x320(0x04)
	float RightLinkForwardOffset; // 0x324(0x04)
	enum class ECollisionChannel CollisionChannel; // 0x328(0x01)
	char pad_329[0x3]; // 0x329(0x03)
	char bManualAdjustment : 1; // 0x32c(0x01)
	char pad_32C_1 : 7; // 0x32c(0x01)
	char pad_32D[0x3]; // 0x32d(0x03)
};

// Class FortniteAI.EdgeNavLinksRenderingComponent
// Size: 0x570 (Inherited: 0x570)
struct UEdgeNavLinksRenderingComponent : UNavLinkRenderingComponent {
};

// Class FortniteAI.FortCustomNavLinkGlobalProxy
// Size: 0x40 (Inherited: 0x28)
struct UFortCustomNavLinkGlobalProxy : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FNavLinkId LinkId; // 0x30(0x08)
	struct UObject* Owner; // 0x38(0x08)
};

// Class FortniteAI.FortClamberLinkGlobalProxy
// Size: 0x40 (Inherited: 0x40)
struct UFortClamberLinkGlobalProxy : UFortCustomNavLinkGlobalProxy {
};

// Class FortniteAI.FortDoorLinkComponent
// Size: 0x1e0 (Inherited: 0x1e0)
struct UFortDoorLinkComponent : UNavLinkCustomComponent {
};

// Class FortniteAI.FortNavigationMetaFilter
// Size: 0x48 (Inherited: 0x48)
struct UFortNavigationMetaFilter : UNavigationQueryFilter {
};

// Class FortniteAI.FortNavigationFilter_Hunting
// Size: 0x48 (Inherited: 0x48)
struct UFortNavigationFilter_Hunting : UFortNavigationMetaFilter {
};

// Class FortniteAI.FortNavigationFilter_IgnoreSmashingCost
// Size: 0x48 (Inherited: 0x48)
struct UFortNavigationFilter_IgnoreSmashingCost : UNavigationQueryFilter {
};

// Class FortniteAI.FortNavigationFilter_Leash
// Size: 0x48 (Inherited: 0x48)
struct UFortNavigationFilter_Leash : UNavigationQueryFilter {
};

// Class FortniteAI.FortNavigationFilter_NoSmashing
// Size: 0x48 (Inherited: 0x48)
struct UFortNavigationFilter_NoSmashing : UNavigationQueryFilter {
};

// Class FortniteAI.FortNavigationFilter_NoSmashingIncludeLow
// Size: 0x48 (Inherited: 0x48)
struct UFortNavigationFilter_NoSmashingIncludeLow : UNavigationQueryFilter {
};

// Class FortniteAI.FortNavigationFilter_TetherZone
// Size: 0x48 (Inherited: 0x48)
struct UFortNavigationFilter_TetherZone : UNavigationQueryFilter {
};

// Class FortniteAI.FortNavigationGraph
// Size: 0x5e8 (Inherited: 0x490)
struct AFortNavigationGraph : ANavigationData {
	char pad_490[0x158]; // 0x490(0x158)
};

// Class FortniteAI.FortNavModifierVolume
// Size: 0x2f0 (Inherited: 0x2e0)
struct AFortNavModifierVolume : ANavModifierVolume {
	struct TArray<struct ANavigationData*> EnableOnlyForNavmeshClasses; // 0x2e0(0x10)
};

// Class FortniteAI.FortNavPathRendererInfoInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortNavPathRendererInfoInterface : UInterface {
};

// Class FortniteAI.FortNavPathRendererComponent
// Size: 0x120 (Inherited: 0xa0)
struct UFortNavPathRendererComponent : UActorComponent {
	struct UNiagaraSystem* PathVFX; // 0xa0(0x08)
	struct FVector PathVFXOffset; // 0xa8(0x18)
	struct TArray<struct FColor> PathColors; // 0xc0(0x10)
	struct UNiagaraComponent* PathVFXComponent; // 0xd0(0x08)
	struct TArray<struct FPathRendererInfo> PathRendererList; // 0xd8(0x10)
	struct TArray<struct FVector4f> AllPathsPoints; // 0xe8(0x10)
	struct TArray<struct FVector> NavPathPoints; // 0xf8(0x10)
	struct TArray<int32_t> NavPathPointsStatus; // 0x108(0x10)
	enum class EPatrollingMode PathMode; // 0x118(0x01)
	char pad_119[0x3]; // 0x119(0x03)
	int32_t CurrentPathColorIndex; // 0x11c(0x04)

	void UpdatePathsVisualOnClient(); // Function FortniteAI.FortNavPathRendererComponent.UpdatePathsVisualOnClient // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96311d0
	void OnRep_PathPointsUpdated(); // Function FortniteAI.FortNavPathRendererComponent.OnRep_PathPointsUpdated // (Final|Native|Private) // @ game+0x9631190
	void OnRep_PathModeUpdated(); // Function FortniteAI.FortNavPathRendererComponent.OnRep_PathModeUpdated // (Final|Native|Private) // @ game+0x9631170
	void OnRep_ColorIndexUpdated(); // Function FortniteAI.FortNavPathRendererComponent.OnRep_ColorIndexUpdated // (Final|Native|Private) // @ game+0x9631170
	void DeactivateFX(); // Function FortniteAI.FortNavPathRendererComponent.DeactivateFX // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96311b0
};

// Class FortniteAI.FortZiplineLinkComponent
// Size: 0x220 (Inherited: 0x1e0)
struct UFortZiplineLinkComponent : UNavLinkCustomComponent {
	struct FVector LinkOffsetFromSplineStart; // 0x1e0(0x18)
	struct FVector LinkOffsetFromSplineEnd; // 0x1f8(0x18)
	bool bOverrideSnapRadius; // 0x210(0x01)
	char pad_211[0x3]; // 0x211(0x03)
	float SnapRadiusOverride; // 0x214(0x04)
	bool bOverrideSnapHeight; // 0x218(0x01)
	char pad_219[0x3]; // 0x219(0x03)
	float SnapHeightOverride; // 0x21c(0x04)

	void OnZiplineStateChanged(bool bIsZiplining, struct AFortPlayerPawn* FortPlayerPawn); // Function FortniteAI.FortZiplineLinkComponent.OnZiplineStateChanged // (Final|Native|Protected) // @ game+0x9633730
};

// Class FortniteAI.JLargeNavMesh
// Size: 0x6b0 (Inherited: 0x6b0)
struct AJLargeNavMesh : AAthenaNavMesh {
};

// Class FortniteAI.JMediumNavMesh
// Size: 0x6b0 (Inherited: 0x6b0)
struct AJMediumNavMesh : AAthenaNavMesh {
};

// Class FortniteAI.JSmallNavMesh
// Size: 0x6b0 (Inherited: 0x6b0)
struct AJSmallNavMesh : AAthenaNavMesh {
};

// Class FortniteAI.FortInescapableZoneTracker
// Size: 0x90 (Inherited: 0x28)
struct UFortInescapableZoneTracker : UObject {
	struct AFortNavigationGraph* NavGraph; // 0x28(0x08)
	char pad_30[0x60]; // 0x30(0x60)
};

// Class FortniteAI.FortPathCostEstimator
// Size: 0xa8 (Inherited: 0x28)
struct UFortPathCostEstimator : UObject {
	struct TWeakObjectPtr<struct AActor> GoalActorWeak; // 0x28(0x08)
	struct AFortNavigationGraph* NavGraph; // 0x30(0x08)
	char pad_38[0x70]; // 0x38(0x70)
};

// Class FortniteAI.NavGraphDebugActor
// Size: 0x290 (Inherited: 0x290)
struct ANavGraphDebugActor : AActor {
};

// Class FortniteAI.AthenaAISense_Hearing
// Size: 0xe0 (Inherited: 0xe0)
struct UAthenaAISense_Hearing : UAISense_Hearing {
};

// Class FortniteAI.FortAIControllerPerksComponent
// Size: 0xc0 (Inherited: 0xa8)
struct UFortAIControllerPerksComponent : UFortControllerComponent {
	char pad_A8[0x18]; // 0xa8(0x18)
};

// Class FortniteAI.FortAIPerkBase
// Size: 0x168 (Inherited: 0x28)
struct UFortAIPerkBase : UObject {
	struct FScalableFloat CooldownDuration; // 0x28(0x28)
	struct FScalableFloat CooldownDurationRandomDeviation; // 0x50(0x28)
	struct FScalableFloat ActivationCountBeforeCooldown; // 0x78(0x28)
	struct FScalableFloat ActivationDuration; // 0xa0(0x28)
	struct FScalableFloat ActivationDurationRandomDeviation; // 0xc8(0x28)
	struct FScalableFloat OddsToActivate; // 0xf0(0x28)
	struct FScalableFloat FailedActivationCooldownDuration; // 0x118(0x28)
	struct FScalableFloat FailedActivationCooldownDurationRandomDeviation; // 0x140(0x28)
};

// Class FortniteAI.AITask_ExecuteAbility
// Size: 0x90 (Inherited: 0x68)
struct UAITask_ExecuteAbility : UAITask {
	char pad_68[0x28]; // 0x68(0x28)
};

// Class FortniteAI.FortAITask_AdjustToSlot
// Size: 0xc0 (Inherited: 0x68)
struct UFortAITask_AdjustToSlot : UAITask {
	struct FVector SlotLocation; // 0x68(0x18)
	struct FVector SlotDirection; // 0x80(0x18)
	char pad_98[0x28]; // 0x98(0x28)
};

// Class FortniteAI.FortAITask_ExecuteAbility
// Size: 0xb8 (Inherited: 0x90)
struct UFortAITask_ExecuteAbility : UAITask_ExecuteAbility {
	char pad_90[0x28]; // 0x90(0x28)

	void OnInjectedHitResultDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAITask_ExecuteAbility.OnInjectedHitResultDied // (Final|Native|Protected|HasDefaults) // @ game+0x9648a80
};

// Class FortniteAI.FortAITask_FuzzyQueue
// Size: 0x138 (Inherited: 0x118)
struct UFortAITask_FuzzyQueue : UAITask_MoveTo {
	char pad_118[0x20]; // 0x118(0x20)
};

// Class FortniteAI.FortAITask_MoveTo
// Size: 0x118 (Inherited: 0x118)
struct UFortAITask_MoveTo : UAITask_MoveTo {
};

// Class FortniteAI.FortAITask_NavmeshWait
// Size: 0x78 (Inherited: 0x68)
struct UFortAITask_NavmeshWait : UAITask {
	char pad_68[0x10]; // 0x68(0x10)
};

// Class FortniteAI.FortAITask_RotateToFace
// Size: 0x90 (Inherited: 0x68)
struct UFortAITask_RotateToFace : UAITask {
	struct AActor* FocusTarget; // 0x68(0x08)
	struct FVector FocalPoint; // 0x70(0x18)
	char pad_88[0x8]; // 0x88(0x08)
};

// Class FortniteAI.FortAITask_StepAside
// Size: 0x1a8 (Inherited: 0x160)
struct UFortAITask_StepAside : UFortAITask_Move {
	char pad_160[0x18]; // 0x160(0x18)
	struct AActor* GoalActor; // 0x178(0x08)
	char pad_180[0x28]; // 0x180(0x28)
};

// Class FortniteAI.FortAICloudVortex
// Size: 0x328 (Inherited: 0x290)
struct AFortAICloudVortex : AActor {
	struct TArray<struct USplineMeshComponent*> SplineMeshesBody; // 0x290(0x10)
	struct UParticleSystemComponent* VortexBase; // 0x2a0(0x08)
	struct UParticleSystemComponent* VortexRing; // 0x2a8(0x08)
	struct TArray<struct FVector> SplinePointsA; // 0x2b0(0x10)
	struct TArray<struct FVector> SplinePointsB; // 0x2c0(0x10)
	struct TArray<struct FVector> SplineTangentsA; // 0x2d0(0x10)
	struct TArray<struct FVector> SplineTangentsB; // 0x2e0(0x10)
	struct TArray<double> TimeRandomArray; // 0x2f0(0x10)
	float TwistOverTime; // 0x300(0x04)
	int32_t NumberOfSplinePoints; // 0x304(0x04)
	bool bEnableVortexBaseParticleSystem; // 0x308(0x01)
	bool bEnableVortexRingParticleSystem; // 0x309(0x01)
	char pad_30A[0x6]; // 0x30a(0x06)
	struct FVector BasePSOffset; // 0x310(0x18)

	void CalculateTwisterWiggle(double TickDelta); // Function FortniteAI.FortAICloudVortex.CalculateTwisterWiggle // (Final|Native|Public|BlueprintCallable) // @ game+0x9653290
};

// Class FortniteAI.ThreatCloud
// Size: 0x4d0 (Inherited: 0x290)
struct AThreatCloud : AActor {
	struct TArray<struct UBoxComponent*> LightningSourceAreas; // 0x290(0x10)
	struct FSlateBrush MiniMapIconBrush; // 0x2a0(0xc0)
	float MiniMapIconPercent; // 0x360(0x04)
	char pad_364[0xc]; // 0x364(0x0c)
	struct FSlateBrush MiniMapFarOffIconBrush; // 0x370(0xc0)
	struct FLinearColor ActiveTint; // 0x430(0x10)
	struct FLinearColor InActiveTint; // 0x440(0x10)
	float ActiveTransitionTime; // 0x450(0x04)
	float DeathTimerDuration; // 0x454(0x04)
	float CloudMiniMapTickInterval; // 0x458(0x04)
	char pad_45C[0x14]; // 0x45c(0x14)
	float MiniMapFarOffIconDegreesOfArc; // 0x470(0x04)
	char pad_474[0xc]; // 0x474(0x0c)
	struct FBox ThreatBoxVolume; // 0x480(0x38)
	float GroundLevelUnderCloud; // 0x4b8(0x04)
	char pad_4BC[0x4]; // 0x4bc(0x04)
	struct TArray<struct FVector> GoalActorLocations; // 0x4c0(0x10)

	void OnThreatVolumeChanged(); // Function FortniteAI.ThreatCloud.OnThreatVolumeChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnLightningStrike(struct FVector& StartLocation, struct FVector& EndLocation, struct ABuildingRift* Rift, bool bLightningStruckRift); // Function FortniteAI.ThreatCloud.OnLightningStrike // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnCloudStart(); // Function FortniteAI.ThreatCloud.OnCloudStart // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnCloudHiddenChange(bool bCloudsAreHidden); // Function FortniteAI.ThreatCloud.OnCloudHiddenChange // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnCloudDeactivated(enum class EFortThreatDeactivationType DeactivationType); // Function FortniteAI.ThreatCloud.OnCloudDeactivated // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnCloudActivated(); // Function FortniteAI.ThreatCloud.OnCloudActivated // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnBeginDeath(); // Function FortniteAI.ThreatCloud.OnBeginDeath // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void ManualLightningFlash(); // Function FortniteAI.ThreatCloud.ManualLightningFlash // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x1b027f0
	struct FBox GetThreatVolume(); // Function FortniteAI.ThreatCloud.GetThreatVolume // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9654150
};

// Class FortniteAI.AthenaAIBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAthenaAIBlueprintLibrary : UBlueprintFunctionLibrary {

	void MakeBotGroupsTakeEachOtherAsTargets(struct TArray<struct AActor*>& GroupA, struct TArray<struct AActor*>& GroupB, enum class EPerceptionState PerceptionState, float ForgetTime, float ForgetDistance); // Function FortniteAI.AthenaAIBlueprintLibrary.MakeBotGroupsTakeEachOtherAsTargets // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9656320
	void KillBots(struct UObject* WorldContextObject, bool bKillPlayers, bool bKillNoneParticipants, char TeamIndex, struct AActor* BotOwner); // Function FortniteAI.AthenaAIBlueprintLibrary.KillBots // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x96569d0
	void JoinTeam(struct UObject* WorldContextObject, struct AController* SourceTeamController, struct AController* DestinationTeamController); // Function FortniteAI.AthenaAIBlueprintLibrary.JoinTeam // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x9657810
	bool IsWeaponSupported(struct UObject* WorldContextObject, struct AFortWeapon* FortWeapon); // Function FortniteAI.AthenaAIBlueprintLibrary.IsWeaponSupported // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x96572d0
	bool IsItemDefinitionSupported(struct UObject* WorldContextObject, struct UFortItemDefinition* FortItemDef); // Function FortniteAI.AthenaAIBlueprintLibrary.IsItemDefinitionSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x9656d50
	struct UAthenaAIServicePlayerBots* GetAIServicePlayerBots(struct UObject* WorldContextObject); // Function FortniteAI.AthenaAIBlueprintLibrary.GetAIServicePlayerBots // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x9657cf0
	struct UAthenaAIServiceLoot* GetAIServiceLoot(struct UObject* WorldContextObject); // Function FortniteAI.AthenaAIBlueprintLibrary.GetAIServiceLoot // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x9657bf0
	struct UAthenaAIServiceCreativePlayerBots* GetAIServiceCreativePlayerBots(struct UObject* WorldContextObject); // Function FortniteAI.AthenaAIBlueprintLibrary.GetAIServiceCreativePlayerBots // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x9657af0
	struct UAthenaAIPopulationTracker* GetAIPopulationTracker(struct UObject* WorldContextObject); // Function FortniteAI.AthenaAIBlueprintLibrary.GetAIPopulationTracker // (Final|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x96582f0
	struct APawn* AthenaSpawnAIFromClass(struct UObject* WorldContextObject, struct APawn* PawnClass, struct UBehaviorTree* BehaviorTree, struct FVector Location, struct FRotator Rotation, bool bNoCollisionFail, struct AActor* Owner); // Function FortniteAI.AthenaAIBlueprintLibrary.AthenaSpawnAIFromClass // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x9657df0
	bool AIPawnFromGAHasLuringPickupAsGoal(struct FGameplayAbilityActorInfo& ActorInfo, struct FGameplayTag GameplayTag, float MaxLifetime, enum class EFortPickupSpawnSource RequiredPickupSpawnSource); // Function FortniteAI.AthenaAIBlueprintLibrary.AIPawnFromGAHasLuringPickupAsGoal // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x96566e0
};

// Class FortniteAI.FortAICombatTokenConsumerComponent
// Size: 0xd8 (Inherited: 0xa8)
struct UFortAICombatTokenConsumerComponent : UFortPawnComponent {
	float TokenHoldMinDuration; // 0xa8(0x04)
	float TokenHoldMaxDuration; // 0xac(0x04)
	struct AFortAthenaAIBotController* CachedOwnerBotController; // 0xb0(0x08)
	struct TWeakObjectPtr<struct UFortAICombatTokenProviderComponent> CurrentTargetTokenProvider; // 0xb8(0x08)
	bool bHasToken; // 0xc0(0x01)
	char pad_C1[0x17]; // 0xc1(0x17)
};

// Class FortniteAI.FortAICombatTokenProviderComponent
// Size: 0xf8 (Inherited: 0xa0)
struct UFortAICombatTokenProviderComponent : UActorComponent {
	struct FScalableFloat TokenMaxCount; // 0xa0(0x28)
	int32_t TokenMaxCountRuntime; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct TArray<struct TWeakObjectPtr<struct UFortAICombatTokenConsumerComponent>> Tokens; // 0xd0(0x10)
	char pad_E0[0x18]; // 0xe0(0x18)
};

// Class FortniteAI.FortAthenaAIBotBuildingComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UFortAthenaAIBotBuildingComponent : UActorComponent {
	char pad_A0[0x38]; // 0xa0(0x38)
};

// Class FortniteAI.FortAthenaAlertStateComponent
// Size: 0xa8 (Inherited: 0xa0)
struct UFortAthenaAlertStateComponent : UActorComponent {
	float StealthMeterTarget; // 0xa0(0x04)
	float StealthMeterTargetTime; // 0xa4(0x04)

	void SetStealthMeterTargetTime(float InStealthMeterTargetTime); // Function FortniteAI.FortAthenaAlertStateComponent.SetStealthMeterTargetTime // (Final|Native|Public|BlueprintCallable) // @ game+0x965b950
	void SetStealthMeterTarget(float InStealthMeterTarget); // Function FortniteAI.FortAthenaAlertStateComponent.SetStealthMeterTarget // (Final|Native|Public|BlueprintCallable) // @ game+0x965ba60
	void OnStealthMeterChanged(struct AFortAthenaAIBotController* BotController, float StealthMeterTarget, float StealthMeterTargetTime); // Function FortniteAI.FortAthenaAlertStateComponent.OnStealthMeterChanged // (Final|Native|Public) // @ game+0x965bb50
	float GetStealthMeterTargetTime(); // Function FortniteAI.FortAthenaAlertStateComponent.GetStealthMeterTargetTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x965ba40
	float GetStealthMeterTarget(); // Function FortniteAI.FortAthenaAlertStateComponent.GetStealthMeterTarget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x86c42d0
};

// Class FortniteAI.FortAthenaNPCLoopStateComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UFortAthenaNPCLoopStateComponent : UActorComponent {
	char bSpawnOutsideTheLoop : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct UFortAthenaAIRuntimeParameters_AIBotLoopSettings* RuntimeLoopSettings; // 0xa8(0x08)

	void OnOwnerPawnDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAthenaNPCLoopStateComponent.OnOwnerPawnDied // (Final|Native|Protected|HasDefaults) // @ game+0x965cce0
	void InitLoopState(struct AFortPawn* PawnOwner); // Function FortniteAI.FortAthenaNPCLoopStateComponent.InitLoopState // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class FortniteAI.FortPawnComponent_PingCommand
// Size: 0x248 (Inherited: 0xa8)
struct UFortPawnComponent_PingCommand : UFortPawnComponent {
	struct FFortPingInfo PingInfo; // 0xa8(0x188)
	char pad_230[0x18]; // 0x230(0x18)
};

// Class FortniteAI.FortPawnComponent_AIBotPingCommand
// Size: 0x250 (Inherited: 0x248)
struct UFortPawnComponent_AIBotPingCommand : UFortPawnComponent_PingCommand {
	struct AAIController* CachedOwnerController; // 0x248(0x08)

	void OnServerMarkerRemoved(struct FMarkerID MarkerID); // Function FortniteAI.FortPawnComponent_AIBotPingCommand.OnServerMarkerRemoved // (Final|Native|Public) // @ game+0x965e400
	void OnServerMarkerAdded(struct FFortWorldMarkerData& MarkerData); // Function FortniteAI.FortPawnComponent_AIBotPingCommand.OnServerMarkerAdded // (Final|Native|Public|HasOutParms) // @ game+0x965e2d0
	void OnAIPingCommand(struct AFortPlayerPawn* PlayerPawn, enum class PingCommandType CommandType); // Function FortniteAI.FortPawnComponent_AIBotPingCommand.OnAIPingCommand // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void HandleOnNPCUnconvertEvent(struct AFortPawn* UnconvertedFortPawn, enum class EUnconvertReason UnconvertReason); // Function FortniteAI.FortPawnComponent_AIBotPingCommand.HandleOnNPCUnconvertEvent // (Final|Native|Public) // @ game+0x965df70
	void HandleOnNPCConvertEvent(struct AFortPawn* InstigatorPawn, struct AFortPawn* ConvertedPawn); // Function FortniteAI.FortPawnComponent_AIBotPingCommand.HandleOnNPCConvertEvent // (Final|Native|Public) // @ game+0x965e120
};

// Class FortniteAI.FortPawnComponent_AIFormation
// Size: 0xd8 (Inherited: 0xa8)
struct UFortPawnComponent_AIFormation : UFortPawnComponent {
	struct TArray<struct FVector> Slots; // 0xa8(0x10)
	float MaxDistanceFromSlotToSprint; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
	struct TArray<struct FFortAthenaAIFormationSlotRuntime> RuntimeSlots; // 0xc0(0x10)
	float MaxDistanceFromSlotToSprintSqr; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)

	void OnUserDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortPawnComponent_AIFormation.OnUserDied // (Final|Native|Private|HasDefaults) // @ game+0x965fc40
};

// Class FortniteAI.FortPawnComponent_AIGroup
// Size: 0xb0 (Inherited: 0xa8)
struct UFortPawnComponent_AIGroup : UFortPawnComponent {
	bool bCanBeGroupLeader; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	int32_t GroupId; // 0xac(0x04)

	void RemoveFromCurrentGroup(); // Function FortniteAI.FortPawnComponent_AIGroup.RemoveFromCurrentGroup // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x9660f60
	void OnGroupMemberDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortPawnComponent_AIGroup.OnGroupMemberDied // (Final|Native|Private|HasDefaults) // @ game+0x9660aa0
};

// Class FortniteAI.FortAthenaPatrolPath
// Size: 0x458 (Inherited: 0x290)
struct AFortAthenaPatrolPath : AActor {
	char pad_290[0x18]; // 0x290(0x18)
	enum class EPatrollingMode Mode; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)
	struct TArray<struct AFortAthenaPatrolPoint*> PatrolPoints; // 0x2b0(0x10)
	bool bUseRandomStartupPatrolPoint; // 0x2c0(0x01)
	bool bUseRandomStartupDirection; // 0x2c1(0x01)
	char pad_2C2[0x6]; // 0x2c2(0x06)
	struct FGameplayTagContainer GameplayTags; // 0x2c8(0x20)
	struct AActor* RadialLeashLocationActorOverride; // 0x2e8(0x08)
	float RadialLeashInnerRadiusOverride; // 0x2f0(0x04)
	float RadialLeashOuterRadiusOverride; // 0x2f4(0x04)
	struct TArray<struct FPatrolPathLeash> PathLeashArray; // 0x2f8(0x10)
	struct FScalableFloat WaterLevelIndexMax; // 0x308(0x28)
	struct FScalableFloat WaterLevelIndexMin; // 0x330(0x28)
	struct FMulticastInlineDelegate OnPatrolPointFailedToReach; // 0x358(0x10)
	struct FMulticastInlineDelegate OnPatrolPointReached; // 0x368(0x10)
	struct FMulticastInlineDelegate OnPatrolPathStarted; // 0x378(0x10)
	struct FMulticastInlineDelegate OnPatrolPathStopped; // 0x388(0x10)
	struct FMulticastInlineDelegate OnPatrolPathActivationStatusChanged; // 0x398(0x10)
	struct FScalableFloat MaxConcurrentUsage; // 0x3a8(0x28)
	int32_t CurrentConcurrentUsage; // 0x3d0(0x04)
	char pad_3D4[0x4]; // 0x3d4(0x04)
	struct FScalableFloat MaxLifetimeUsage; // 0x3d8(0x28)
	float DebugLinkWidthSelected; // 0x400(0x04)
	float DebugLinkWidthNotSelected; // 0x404(0x04)
	struct FLinearColor DebugNotSelectedColor; // 0x408(0x10)
	char pad_418_0 : 1; // 0x418(0x01)
	char bIsPatrolPathEnabled : 1; // 0x418(0x01)
	char pad_418_2 : 6; // 0x418(0x01)
	char pad_419[0x3f]; // 0x419(0x3f)

	void SetPatrolPathEnabled(bool bIsEnabled); // Function FortniteAI.FortAthenaPatrolPath.SetPatrolPathEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96d0fc0
	void PatrolPointReached(struct AFortAthenaPatrolPoint* PathPoint, struct AAIController* AIInstigator); // Function FortniteAI.FortAthenaPatrolPath.PatrolPointReached // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x96d14b0
	void PatrolPointFailedToReach(struct AFortAthenaPatrolPoint* PathPoint, struct AAIController* AIInstigator); // Function FortniteAI.FortAthenaPatrolPath.PatrolPointFailedToReach // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x96d1310
	void PatrolPathStopped(struct AAIController* AIInstigator); // Function FortniteAI.FortAthenaPatrolPath.PatrolPathStopped // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x96d1110
	void PatrolPathStarted(struct AAIController* AIInstigator); // Function FortniteAI.FortAthenaPatrolPath.PatrolPathStarted // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x96d1210
	void OnCurrentPlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function FortniteAI.FortAthenaPatrolPath.OnCurrentPlaylistLoaded // (Final|Native|Protected|HasOutParms) // @ game+0x96d0d70
	void GetPatrolPoints(struct TArray<struct AFortAthenaPatrolPoint*>& OutPatrolPoints); // Function FortniteAI.FortAthenaPatrolPath.GetPatrolPoints // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x96d1650
	bool CanBeUsed(); // Function FortniteAI.FortAthenaPatrolPath.CanBeUsed // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96d10d0
};

// Class FortniteAI.FortCreativePatrolPath
// Size: 0x480 (Inherited: 0x458)
struct AFortCreativePatrolPath : AFortAthenaPatrolPath {
	struct TArray<struct AFortCreativeDeviceProp*> CreativePatrolPoints; // 0x458(0x10)
	enum class EFortCreativePatrolPathGroup PatrolPathGroup; // 0x468(0x01)
	char pad_469[0x7]; // 0x469(0x07)
	struct ABuildingActor* CreativePathRenderer; // 0x470(0x08)
	char pad_478[0x8]; // 0x478(0x08)

	void SetPatrolHasValidNavMesh(bool bValidNavMesh); // Function FortniteAI.FortCreativePatrolPath.SetPatrolHasValidNavMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9661d10
	bool HasPatrolValidNavMesh(); // Function FortniteAI.FortCreativePatrolPath.HasPatrolValidNavMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9661cf0
};

// Class FortniteAI.FortAthenaAIRuntimeParameters
// Size: 0x30 (Inherited: 0x28)
struct UFortAthenaAIRuntimeParameters : UObject {
	int32_t ExtractedLevel; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// Class FortniteAI.FortAthenaAIBotDigestedSkillSet
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAIBotDigestedSkillSet : UFortAthenaAIRuntimeParameters {
};

// Class FortniteAI.FortAthenaAIBotAimingDigestedSkillSet
// Size: 0x780 (Inherited: 0x30)
struct UFortAthenaAIBotAimingDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	struct FDigestedFocusSetting DefaultFocusSetting; // 0x30(0x68)
	struct TArray<struct FDigestedFocusSetting> FocusSettings; // 0x98(0x10)
	struct FLookAtDigestedSetting LookAtSettings[0x4]; // 0xa8(0x40)
	bool bAllowScanAroundWhileSwimming; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	float TrackingReactionTime; // 0xec(0x04)
	float InAirTrackingReactionTimeMultiplier; // 0xf0(0x04)
	float TrackingInterpTime; // 0xf4(0x04)
	float TrackingInterpTimeMultForGroundVehicles; // 0xf8(0x04)
	float TrackingInterpTimeMultForFlyingVehicles; // 0xfc(0x04)
	float MaxTrackingPredictionError; // 0x100(0x04)
	float MaxTrackingOffsetErrorMultiplier; // 0x104(0x04)
	float AdjustedTrackingOffsetErrorMultiplierAgainstAIs; // 0x108(0x04)
	float TrackingErrorUpdateInterval; // 0x10c(0x04)
	float TrackingInAirVelocityThreshold; // 0x110(0x04)
	float TrackingInAirHeightDeltaThreshold; // 0x114(0x04)
	float TargetAcquisitionRate; // 0x118(0x04)
	float TimeToHitMultiplier; // 0x11c(0x04)
	float MaxTimeToHitAddedCausedByTargetSpeed; // 0x120(0x04)
	float MaxTimeToHitAddedCausedByTargetInAir; // 0x124(0x04)
	float TimeToHitDelayMultiplierWhenTargetInAir; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
	struct FScalableFloat TimeToHitDelayMultiplierCurveBasedOnSpeed; // 0x130(0x28)
	bool bAimingCircleEnabled; // 0x158(0x01)
	bool bTargetIdleDetectionEnabled; // 0x159(0x01)
	bool bTargetIdleUseAgainstNPC; // 0x15a(0x01)
	char pad_15B[0x1]; // 0x15b(0x01)
	float TargetIdleLookBackTime; // 0x15c(0x04)
	float TargetIdleUnsuspectingCosAngle; // 0x160(0x04)
	float TargetIdleUnsuspectingDistance; // 0x164(0x04)
	float TargetIdleUnsuspectingDamageDuration; // 0x168(0x04)
	float TargetIdleUnsuspectingTimeMultiplier; // 0x16c(0x04)
	float TargetIdleVerticalSpeedThreshold; // 0x170(0x04)
	float TargetIdleLateralSpeedThreshold; // 0x174(0x04)
	float TargetIdleFrontalSpeedThreshold; // 0x178(0x04)
	float TargetIdleRevivedGracePeriodDuration; // 0x17c(0x04)
	float MaxDistanceEvaluationErrorRatio; // 0x180(0x04)
	float TargetingUpdateInterval; // 0x184(0x04)
	float TargetingUpdateIntervalMaxDeviation; // 0x188(0x04)
	float ReachLeashLimitToleranceDistance; // 0x18c(0x04)
	bool bShootFloorTrapOnlyWhenHigherThanTrap; // 0x190(0x01)
	char pad_191[0x3]; // 0x191(0x03)
	float TargetingRotationSpeedLimit; // 0x194(0x04)
	float TargetingRotationSnapThreshold; // 0x198(0x04)
	float BaseClampingDistance; // 0x19c(0x04)
	struct FDigestedWeaponAccuracy NoWeaponAccuracy; // 0x1a0(0x328)
	struct TArray<struct FDigestedWeaponAccuracyCategory> WeaponAccuracies; // 0x4c8(0x10)
	struct TArray<struct FDigestedTargetBasedAccuracyCategory> DigestedTargetBasedAccuracies; // 0x4d8(0x10)
	struct FDigestedTrackingOffsetModifiers TrackingOffsetModifiers; // 0x4e8(0x120)
	struct FDigestedAimingCircleSettings DefaultAimingCircleSettings; // 0x608(0x168)
	struct TWeakObjectPtr<struct AFortWeapon> CachedWeaponUsedToCalculateAccuracy; // 0x770(0x08)
	char pad_778[0x8]; // 0x778(0x08)
};

// Class FortniteAI.FortAthenaAIBotSkillSet
// Size: 0x30 (Inherited: 0x28)
struct UFortAthenaAIBotSkillSet : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class FortniteAI.FortAthenaAIBotAimingSkillSet
// Size: 0x1598 (Inherited: 0x30)
struct UFortAthenaAIBotAimingSkillSet : UFortAthenaAIBotSkillSet {
	struct FFocusSetting DefaultFocusSetting; // 0x30(0x140)
	struct TArray<struct FFocusSetting> FocusSettings; // 0x170(0x10)
	struct FLookAtSetting LookAtSettings[0x4]; // 0x180(0x280)
	struct FScalableFloat AllowScanAroundWhileSwimming; // 0x400(0x28)
	struct FScalableFloat TrackingReactionTime; // 0x428(0x28)
	struct FScalableFloat InAirTrackingReactionTimeMultiplier; // 0x450(0x28)
	struct FScalableFloat TrackingInterpTime; // 0x478(0x28)
	struct FScalableFloat TrackingInterpTimeMultForGroundVehicles; // 0x4a0(0x28)
	struct FScalableFloat TrackingInterpTimeMultForFlyingVehicles; // 0x4c8(0x28)
	struct FScalableFloat MaxTrackingPredictionError; // 0x4f0(0x28)
	struct FScalableFloat MaxTrackingOffsetErrorMultiplier; // 0x518(0x28)
	struct FScalableFloat AdjustedTrackingOffsetErrorMultiplierAgainstAIs; // 0x540(0x28)
	struct FScalableFloat TrackingErrorUpdateInterval; // 0x568(0x28)
	struct FScalableFloat TrackingInAirVelocityThreshold; // 0x590(0x28)
	struct FScalableFloat TrackingInAirHeightDeltaThreshold; // 0x5b8(0x28)
	struct FScalableFloat TargetAcquisitionRate; // 0x5e0(0x28)
	struct FScalableFloat TimeToHitMultiplier; // 0x608(0x28)
	struct FScalableFloat MaxTimeToHitAddedCausedByTargetSpeed; // 0x630(0x28)
	struct FScalableFloat MaxTimeToHitAddedCausedByTargetInAir; // 0x658(0x28)
	struct FScalableFloat TimeToHitDelayMultiplierWhenTargetInAir; // 0x680(0x28)
	struct FScalableFloat TimeToHitDelayMultiplierCurveBasedOnSpeed; // 0x6a8(0x28)
	struct FScalableFloat AimingCircleEnabled; // 0x6d0(0x28)
	struct FScalableFloat TargetIdleDetectionEnabled; // 0x6f8(0x28)
	struct FScalableFloat TargetIdleUseAgainstNPC; // 0x720(0x28)
	struct FScalableFloat TargetIdleLookBackTime; // 0x748(0x28)
	struct FScalableFloat TargetIdleUnsuspectingAngle; // 0x770(0x28)
	struct FScalableFloat TargetIdleUnsuspectingDistance; // 0x798(0x28)
	struct FScalableFloat TargetIdleUnsuspectingDamageDuration; // 0x7c0(0x28)
	struct FScalableFloat TargetIdleUnsuspectingTimeMultiplier; // 0x7e8(0x28)
	struct FScalableFloat TargetIdleVerticalSpeedThreshold; // 0x810(0x28)
	struct FScalableFloat TargetIdleLateralSpeedThreshold; // 0x838(0x28)
	struct FScalableFloat TargetIdleFrontalSpeedThreshold; // 0x860(0x28)
	struct FScalableFloat TargetIdleRevivedGracePeriodDuration; // 0x888(0x28)
	struct FScalableFloat MaxDistanceEvaluationErrorRatio; // 0x8b0(0x28)
	struct FScalableFloat TargetingUpdateInterval; // 0x8d8(0x28)
	struct FScalableFloat TargetingUpdateIntervalMaxDeviation; // 0x900(0x28)
	struct FScalableFloat ReachLeashLimitToleranceDistance; // 0x928(0x28)
	struct FScalableFloat ShootFloorTrapOnlyWhenHigherThanTrap; // 0x950(0x28)
	struct FScalableFloat TargetingRotationSpeedLimit; // 0x978(0x28)
	struct FScalableFloat TargetingRotationSnapThreshold; // 0x9a0(0x28)
	struct FScalableFloat BaseClampingDistance; // 0x9c8(0x28)
	struct FWeaponAccuracy NoWeaponAccuracy; // 0x9f0(0x760)
	struct TArray<struct FWeaponAccuracyCategory> WeaponAccuracies; // 0x1150(0x10)
	struct TArray<struct FTargetBasedAccuracyCategory> TargetBasedAccuracies; // 0x1160(0x10)
	char bDigestTrackingOffsetModifiersWithAvgMatchMMR : 1; // 0x1170(0x01)
	char pad_1170_1 : 7; // 0x1170(0x01)
	char pad_1171[0x7]; // 0x1171(0x07)
	struct TArray<struct FTrackingOffsetModifierInfo> TrackingOffsetModifiers; // 0x1178(0x10)
	struct FAimingCircleSettings DefaultAimingCircleSettings; // 0x1188(0x410)
};

// Class FortniteAI.AISenseScalableConfig
// Size: 0x28 (Inherited: 0x28)
struct UAISenseScalableConfig : UObject {
};

// Class FortniteAI.AISenseScalableConfig_Sight
// Size: 0xf0 (Inherited: 0x28)
struct UAISenseScalableConfig_Sight : UAISenseScalableConfig {
	struct FScalableFloat SightRadius; // 0x28(0x28)
	struct FScalableFloat LoseSightRadius; // 0x50(0x28)
	struct FScalableFloat PeripheralVisionAngleDegrees; // 0x78(0x28)
	struct FScalableFloat PointOfViewBackwardOffset; // 0xa0(0x28)
	struct FScalableFloat NearClippingRadius; // 0xc8(0x28)
};

// Class FortniteAI.AISenseScalableConfig_Hearing
// Size: 0x50 (Inherited: 0x28)
struct UAISenseScalableConfig_Hearing : UAISenseScalableConfig {
	struct FScalableFloat HearingRange; // 0x28(0x28)
};

// Class FortniteAI.FortAthenaAIBotAlertLevelConfig
// Size: 0x38 (Inherited: 0x28)
struct UFortAthenaAIBotAlertLevelConfig : UObject {
	int32_t AlertLevels; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct UAISenseScalableConfig* ScalableSenseConfig; // 0x30(0x08)
};

// Class FortniteAI.FortAthenaAIBotAttackingDigestedSkillSet
// Size: 0x140 (Inherited: 0x30)
struct UFortAthenaAIBotAttackingDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float MaxDistanceToEngageMeleeSq; // 0x30(0x04)
	float MinDistanceToGiveUpMeleeSq; // 0x34(0x04)
	float MaxDistanceToThrowMeleeAttackSq; // 0x38(0x04)
	float ExcludeReachingTargetInMeleeTime; // 0x3c(0x04)
	float ExcludeReachingTargetMoveDistanceSquared; // 0x40(0x04)
	bool bUseContinuousMeleeAttack; // 0x44(0x01)
	bool bOnlyEngageMeleeAgainstThreatThatHasNoRangeWeapon; // 0x45(0x01)
	bool bOnlyUsePickaxeAgainstGameParticipants; // 0x46(0x01)
	char pad_47[0x1]; // 0x47(0x01)
	float MaxDistanceToConsiderAsAnAlternateTargetSq; // 0x48(0x04)
	bool bEnableAlternateTargetRequiredTags; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	struct FGameplayTagContainer AlternateTargetRequiredTags; // 0x50(0x20)
	bool bEnableWTFBehavior; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	float MinCooldownDelayBetweenMeleeAttackAttempts; // 0x74(0x04)
	float MaxCooldownDelayBetweenMeleeAttackAttempts; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FGameplayTagContainer ThrowableGameplayTags; // 0x80(0x20)
	struct FGameplayTagQuery CombatMeleeTagQuery; // 0xa0(0x48)
	int32_t MinThrowableCount; // 0xe8(0x04)
	int32_t MaxThrowableCount; // 0xec(0x04)
	float ThrowableCooldownMin; // 0xf0(0x04)
	float ThrowableCooldownMax; // 0xf4(0x04)
	float ThrowableMinimumRangeSquared; // 0xf8(0x04)
	bool bThrowableEvaluatorActive; // 0xfc(0x01)
	char pad_FD[0x3]; // 0xfd(0x03)
	float RetreatMinHealthRange; // 0x100(0x04)
	float RetreatMaxHealthRange; // 0x104(0x04)
	float RetreatProbability; // 0x108(0x04)
	float RetreatRangeMinSquared; // 0x10c(0x04)
	float RetreatRangeMaxSquared; // 0x110(0x04)
	float RetreatMaxDuration; // 0x114(0x04)
	struct FVector RetreatPositionBoxExtent; // 0x118(0x18)
	bool CautiousInvestigationEnabled; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	float TimeSinceLastStimToBeCautious; // 0x134(0x04)
	float CautiousInvestigationTimeMax; // 0x138(0x04)
	char pad_13C[0x4]; // 0x13c(0x04)
};

// Class FortniteAI.FortAthenaAIBotAttackingSkillSet
// Size: 0x530 (Inherited: 0x30)
struct UFortAthenaAIBotAttackingSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat MaxDistanceToEngageMelee; // 0x30(0x28)
	struct FScalableFloat MinDistanceToGiveUpMelee; // 0x58(0x28)
	struct FScalableFloat MaxDistanceToThrowMeleeAttack; // 0x80(0x28)
	struct FScalableFloat UseContinuousMeleeAttack; // 0xa8(0x28)
	struct FScalableFloat OnlyEngageMeleeAgainstThreatThatHasNoRangeWeapon; // 0xd0(0x28)
	struct FScalableFloat OnlyUsePickaxeAgainstGameParticipants; // 0xf8(0x28)
	struct FScalableFloat EnableWTFBehavior; // 0x120(0x28)
	struct FScalableFloat MinCooldownDelayBetweenMeleeAttackAttempts; // 0x148(0x28)
	struct FScalableFloat MaxCooldownDelayBetweenMeleeAttackAttempts; // 0x170(0x28)
	struct FGameplayTagQuery CombatMeleeTagQuery; // 0x198(0x48)
	struct FScalableFloat ExcludeReachingTargetInMeleeTime; // 0x1e0(0x28)
	struct FScalableFloat ExcludeReachingTargetMoveDistance; // 0x208(0x28)
	struct FScalableFloat MaxDistanceToConsiderAsAnAlternateTarget; // 0x230(0x28)
	struct FScalableFloat EnableAlternateTargetRequiredTags; // 0x258(0x28)
	struct FGameplayTagContainer AlternateTargetRequiredTags; // 0x280(0x20)
	struct FGameplayTagContainer ThrowableGameplayTags; // 0x2a0(0x20)
	struct FScalableFloat MinThrowableCount; // 0x2c0(0x28)
	struct FScalableFloat MaxThrowableCount; // 0x2e8(0x28)
	struct FScalableFloat ThrowableCooldownMin; // 0x310(0x28)
	struct FScalableFloat ThrowableCooldownMax; // 0x338(0x28)
	struct FScalableFloat ThrowableMinimumRange; // 0x360(0x28)
	struct FScalableFloat ThrowableEvaluatorActive; // 0x388(0x28)
	struct FScalableFloat RetreatMinHealthRange; // 0x3b0(0x28)
	struct FScalableFloat RetreatMaxHealthRange; // 0x3d8(0x28)
	struct FScalableFloat RetreatProbability; // 0x400(0x28)
	struct FScalableFloat RetreatRangeMin; // 0x428(0x28)
	struct FScalableFloat RetreatRangeMax; // 0x450(0x28)
	struct FScalableFloat RetreatMaxDuration; // 0x478(0x28)
	struct FVector RetreatPositionBoxExtent; // 0x4a0(0x18)
	struct FScalableFloat CautiousInvestigationEnabled; // 0x4b8(0x28)
	struct FScalableFloat TimeSinceLastStimToBeCautious; // 0x4e0(0x28)
	struct FScalableFloat CautiousInvestigationTimeMax; // 0x508(0x28)
};

// Class FortniteAI.FortAthenaAIBotBuildingDigestedSkillSet
// Size: 0x70 (Inherited: 0x30)
struct UFortAthenaAIBotBuildingDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float DefensiveBuildingDelayBetweenBuilds; // 0x30(0x04)
	float DefensiveBuildingDelayDeviationBetweenBuilds; // 0x34(0x04)
	float DelayBetweenBuildPieces; // 0x38(0x04)
	float ForceEquipBuildToolDuration; // 0x3c(0x04)
	float StealWallTurboBuildDetectionTime; // 0x40(0x04)
	int32_t StealWallAfterNumberOfTurboBuiltWall; // 0x44(0x04)
	float StealWallEfficiency; // 0x48(0x04)
	float StealWallBuildingTemplateWeights[0x5]; // 0x4c(0x14)
	struct TArray<struct FAthenaFortAIBotDigestedWeightedBuildingList> WeightedBuildingLists; // 0x60(0x10)
};

// Class FortniteAI.FortAthenaAIBotBuildingSkillSet
// Size: 0x220 (Inherited: 0x30)
struct UFortAthenaAIBotBuildingSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat DefensiveBuildingDelayBetweenBuilds; // 0x30(0x28)
	struct FScalableFloat DefensiveBuildingDelayDeviationBetweenBuilds; // 0x58(0x28)
	struct FScalableFloat DelayBetweenBuildPieces; // 0x80(0x28)
	struct FScalableFloat ForceEquipBuildToolDuration; // 0xa8(0x28)
	struct TArray<struct FAthenaFortAIBotWeightedBuildingList> WeightedBuildingLists; // 0xd0(0x10)
	struct FScalableFloat StealWallTurboBuildDetectionTime; // 0xe0(0x28)
	struct FScalableFloat StealWallAfterNumberOfTurboBuiltWall; // 0x108(0x28)
	struct FScalableFloat StealWallEfficiency; // 0x130(0x28)
	struct FScalableFloat StealWallBuildingTemplateWeights[0x5]; // 0x158(0xc8)
};

// Class FortniteAI.FortAthenaAIBotCosmeticData
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAIBotCosmeticData : UDataAsset {
	struct TArray<struct TSoftObjectPtr<UFortAthenaAIBotCosmeticLibraryData>> CosmeticLibraries; // 0x30(0x10)

	struct TSoftObjectPtr<UFortAthenaAIBotCosmeticLibraryData> FindLibraryDataFromName(struct FString PartialName); // Function FortniteAI.FortAthenaAIBotCosmeticData.FindLibraryDataFromName // (Final|Native|Public|BlueprintCallable) // @ game+0x966a3b0
};

// Class FortniteAI.FortAthenaAIBotCosmeticLibraryData
// Size: 0x1c0 (Inherited: 0x30)
struct UFortAthenaAIBotCosmeticLibraryData : UPrimaryDataAsset {
	struct TSoftObjectPtr<UDataTable> PredefineSetsDataTable; // 0x30(0x20)
	struct TSoftObjectPtr<UDataTable> CharactersDataTable; // 0x50(0x20)
	struct TSoftObjectPtr<UDataTable> GlidersDataTable; // 0x70(0x20)
	struct TSoftObjectPtr<UDataTable> SkyDiveContrailsDataTable; // 0x90(0x20)
	struct TSoftObjectPtr<UDataTable> BackpacksDataTable; // 0xb0(0x20)
	struct TSoftObjectPtr<UDataTable> PickaxesDataTable; // 0xd0(0x20)
	struct TSoftObjectPtr<UDataTable> FallbackCharactersDataTable; // 0xf0(0x20)
	struct TSoftObjectPtr<UDataTable> EmotesDataTable; // 0x110(0x20)
	struct TSoftObjectPtr<UDataTable> BannerIconDataTable; // 0x130(0x20)
	struct TSoftObjectPtr<UDataTable> BannerColorDataTable; // 0x150(0x20)
	struct FScalableFloat OddsToUseSameSetCosmeticItems; // 0x170(0x28)
	struct FScalableFloat OddsToUseRandomItemWhenNoneFromSetAvailable; // 0x198(0x28)

	struct TArray<struct UDataTable*> RetrieveDataTables(); // Function FortniteAI.FortAthenaAIBotCosmeticLibraryData.RetrieveDataTables // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x966a810
	struct UDataTable* FindDataTableFromAssetType(struct FString AssetType); // Function FortniteAI.FortAthenaAIBotCosmeticLibraryData.FindDataTableFromAssetType // (Final|Native|Public|BlueprintCallable) // @ game+0x966aad0
	bool FillDataTableValuesFromSourceLibrary(struct UFortAthenaAIBotCosmeticLibraryData* SourceLibrary); // Function FortniteAI.FortAthenaAIBotCosmeticLibraryData.FillDataTableValuesFromSourceLibrary // (Final|Native|Public|BlueprintCallable) // @ game+0x966a8d0
};

// Class FortniteAI.BotCosmeticBlueprintHelperLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBotCosmeticBlueprintHelperLibrary : UBlueprintFunctionLibrary {

	bool SplitDataArrayByType(struct TArray<struct FString>& InAssetNames, struct TArray<struct FString>& InAssetTypes, struct TArray<int32_t>& InAssetUsageCounts, struct TArray<int32_t>& InAssetTypeSplitIndices, int32_t CurrentSplitIndex, struct FString& OutAssetType, struct TArray<struct FString>& OutAssetNames, struct TArray<int32_t>& OutAssetUsageCounts); // Function FortniteAI.BotCosmeticBlueprintHelperLibrary.SplitDataArrayByType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x966b740
	struct TArray<struct FString> OpenCSVFileDialog(struct FString TitleDetails, bool bAllowMultipleFiles); // Function FortniteAI.BotCosmeticBlueprintHelperLibrary.OpenCSVFileDialog // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x966c3d0
	bool LoadDataFromCSV(struct FString FilePath, struct TArray<struct FString>& ForbiddenAssetNames, struct TArray<struct FString>& ForbiddenAssetPrefix, struct TArray<struct FString>& AssetNames, struct TArray<struct FString>& AssetTypes, struct TArray<int32_t>& AssetUsageCounts, struct TArray<int32_t>& AssetTypeSplitIndices); // Function FortniteAI.BotCosmeticBlueprintHelperLibrary.LoadDataFromCSV // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x966bd20
	bool GenerateWeightedCSV(struct FString AssetTypeName, struct TArray<struct FString>& AssetNames, struct TArray<int32_t>& AssetWeight, struct FString& CSV); // Function FortniteAI.BotCosmeticBlueprintHelperLibrary.GenerateWeightedCSV // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x966b390
	bool ExportDataTableToSourceCSV(struct UDataTable* DataTable, bool bCanCheckOutFile); // Function FortniteAI.BotCosmeticBlueprintHelperLibrary.ExportDataTableToSourceCSV // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x966b210
};

// Class FortniteAI.FortAthenaAIBotCustomizationData
// Size: 0x180 (Inherited: 0x30)
struct UFortAthenaAIBotCustomizationData : UPrimaryDataAsset {
	struct AFortPlayerPawnAthena* PawnClass; // 0x30(0x08)
	char bRequiresUniqueNetId : 1; // 0x38(0x01)
	char bHasCustomSquadId : 1; // 0x38(0x01)
	char pad_38_2 : 6; // 0x38(0x01)
	char CustomSquadId; // 0x39(0x01)
	char bOverrideCanRespawnOnDeath : 1; // 0x3a(0x01)
	char bCanRespawnOnDeath : 1; // 0x3a(0x01)
	char bOverrideBehaviorTree : 1; // 0x3a(0x01)
	char bOverrideCharacterCustomization : 1; // 0x3a(0x01)
	char bOverrideDBNOPlayStyle : 1; // 0x3a(0x01)
	char bOverrideSkillLevel : 1; // 0x3a(0x01)
	char bUseMatchMMRToOverrideSkillLevel : 1; // 0x3a(0x01)
	char bOverrideSkillSets : 1; // 0x3a(0x01)
	char bOverrideStartupInventory : 1; // 0x3b(0x01)
	char bOverrideBotNameSettings : 1; // 0x3b(0x01)
	char bOverrideBotIDAnalyticsSuffix : 1; // 0x3b(0x01)
	char bOverrideConstructionBuildingInfo : 1; // 0x3b(0x01)
	char pad_3B_4 : 4; // 0x3b(0x01)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct TSoftObjectPtr<UDataTable> OverrideSkillLevelMMRTable; // 0x40(0x20)
	struct UBehaviorTree* BehaviorTree; // 0x60(0x08)
	enum class BotDataOverrideCosmeticMode OverrideCosmeticMode; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct UFortAthenaAIBotCharacterCustomization* CharacterCustomization; // 0x70(0x08)
	struct TSoftObjectPtr<UFortAthenaAIBotCosmeticLibraryData> CosmeticCustomizationLibrary; // 0x78(0x20)
	enum class EDBNOPlayStyle DBNOPlayStyle; // 0x98(0x01)
	char pad_99[0x3]; // 0x99(0x03)
	float SkillLevel; // 0x9c(0x04)
	char pad_A0[0x8]; // 0xa0(0x08)
	struct TArray<struct UFortAthenaAIBotSkillSet*> SkillSetOverrideClasses; // 0xa8(0x10)
	struct UFortAthenaAIBotInventoryItems* StartupInventory; // 0xb8(0x08)
	struct UFortBotNameSettings* BotNameSettings; // 0xc0(0x08)
	struct FString BotAnalyticsSuffix; // 0xc8(0x10)
	float SpawnTracePadding; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct FConstructionBuildingInfo OverrideConstructionBuildingInfo[0x6]; // 0xe0(0x90)
	struct UFortAthenaAILODSettingsContainer* AILODSettingsContainer; // 0x170(0x08)
	struct UFortAthenaAILODSettingsContainer* AILODSettingsContainerLoaded; // 0x178(0x08)

	void SetCharacterCustomizationFromPlayerPawn(struct AFortPlayerPawn* InFortPawn); // Function FortniteAI.FortAthenaAIBotCustomizationData.SetCharacterCustomizationFromPlayerPawn // (Final|Native|Public|BlueprintCallable) // @ game+0x966d290
};

// Class FortniteAI.FortAthenaAIBotDBNODigestedSkillSet
// Size: 0x50 (Inherited: 0x30)
struct UFortAthenaAIBotDBNODigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float MaxDBNOCrawlingResponseTime; // 0x30(0x04)
	float MaxDBNOCrawlingResponseTimeDeviation; // 0x34(0x04)
	float AllyEvaluationTime; // 0x38(0x04)
	float AllyEvaluationTimeDeviation; // 0x3c(0x04)
	float AllyEvaluationMaxDistance; // 0x40(0x04)
	float OddsToLookForCover; // 0x44(0x04)
	float CoverEvaluationTime; // 0x48(0x04)
	float CoverEvaluationTimeDeviation; // 0x4c(0x04)
};

// Class FortniteAI.FortAthenaAIBotDBNOSkillSet
// Size: 0x170 (Inherited: 0x30)
struct UFortAthenaAIBotDBNOSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat MaxDBNOCrawlingResponseTime; // 0x30(0x28)
	struct FScalableFloat MaxDBNOCrawlingResponseTimeDeviation; // 0x58(0x28)
	struct FScalableFloat AllyEvaluationTime; // 0x80(0x28)
	struct FScalableFloat AllyEvaluationTimeDeviation; // 0xa8(0x28)
	struct FScalableFloat AllyEvaluationMaxDistance; // 0xd0(0x28)
	struct FScalableFloat OddsToLookForCover; // 0xf8(0x28)
	struct FScalableFloat CoverEvaluationTime; // 0x120(0x28)
	struct FScalableFloat CoverEvaluationTimeDeviation; // 0x148(0x28)
};

// Class FortniteAI.FortAthenaAIBotEmoteDigestedSkillSet
// Size: 0x50 (Inherited: 0x30)
struct UFortAthenaAIBotEmoteDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float InfiniteEmoteMinDuration; // 0x30(0x04)
	float InfiniteEmoteMaxDuration; // 0x34(0x04)
	int32_t EmotesMaxCount; // 0x38(0x04)
	float DanceOnKillMaxDistanceFromKillSqr; // 0x3c(0x04)
	float DanceOnKillMaxTimeFromKill; // 0x40(0x04)
	float DanceOnKillMinTimeFromLastTry; // 0x44(0x04)
	float DanceOnKillChanceToDanceOnBots; // 0x48(0x04)
	float DanceOnKillChanceToDanceOnPlayers; // 0x4c(0x04)
};

// Class FortniteAI.FortAthenaAIBotEmoteSkillSet
// Size: 0x148 (Inherited: 0x30)
struct UFortAthenaAIBotEmoteSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat InfiniteEmoteMinDuration; // 0x30(0x28)
	struct FScalableFloat InfiniteEmoteMaxDuration; // 0x58(0x28)
	struct FScalableFloat DanceOnKillMaxDistanceFromKill; // 0x80(0x28)
	struct FScalableFloat DanceOnKillMaxTimeFromKill; // 0xa8(0x28)
	struct FScalableFloat DanceOnKillMinTimeFromLastTry; // 0xd0(0x28)
	struct FScalableFloat DanceOnKillChanceToDanceOnBots; // 0xf8(0x28)
	struct FScalableFloat DanceOnKillChanceToDanceOnPlayers; // 0x120(0x28)
};

// Class FortniteAI.FortAthenaAIEvaluator
// Size: 0xa0 (Inherited: 0x28)
struct UFortAthenaAIEvaluator : UObject {
	struct UBehaviorTreeComponent* CachedOwnerComp; // 0x28(0x08)
	struct AAIController* CachedAIController; // 0x30(0x08)
	struct UNavigationQueryFilter* OverrideNavigationFilterClass; // 0x38(0x08)
	char pad_40[0x18]; // 0x40(0x18)
	struct FName ExecutionStatusName; // 0x58(0x04)
	char pad_5C[0xc]; // 0x5c(0x0c)
	struct TScriptInterface<IFortAthenaAILODSettings> CachedLODSettingsInterface; // 0x68(0x10)
	struct UBlackboardKeyAccessValidator* KeyAccessValidator; // 0x78(0x08)
	char pad_80[0x20]; // 0x80(0x20)
};

// Class FortniteAI.FortAthenaAIBotEvaluator
// Size: 0xa8 (Inherited: 0xa0)
struct UFortAthenaAIBotEvaluator : UFortAthenaAIEvaluator {
	struct AFortAthenaAIBotController* CachedBotController; // 0xa0(0x08)
};

// Class FortniteAI.FortAthenaAIBotEvaluator_Movement
// Size: 0x1a8 (Inherited: 0xa8)
struct UFortAthenaAIBotEvaluator_Movement : UFortAthenaAIBotEvaluator {
	struct FName MovementStateKeyName; // 0xa8(0x04)
	struct FName MovementDestinationKeyName; // 0xac(0x04)
	struct FName LastPartialPathTimeKeyName; // 0xb0(0x04)
	struct FName LastPartialPathCountKeyName; // 0xb4(0x04)
	struct FName LastBlockedPathCountKeyName; // 0xb8(0x04)
	struct FName UnstuckInWaterExecutionStatusName; // 0xbc(0x04)
	struct FName UnstuckLastBlockedByActorKeyName; // 0xc0(0x04)
	struct FName UnstuckExecutionStatusKeyName; // 0xc4(0x04)
	struct FName TeleportExecutionStatusKeyName; // 0xc8(0x04)
	struct FName UndermineExecutionStatusKeyName; // 0xcc(0x04)
	struct FName UndermineTargetKeyName; // 0xd0(0x04)
	struct FName UndermineLocationImpactName; // 0xd4(0x04)
	struct FName UnstuckSteerExecutionStatusKeyName; // 0xd8(0x04)
	struct FName UnstuckSteerDirectionKeyName; // 0xdc(0x04)
	struct UAthenaAIServicePlayerBots* CachedAIServicePlayerBots; // 0xe0(0x08)
	char pad_E8[0x10]; // 0xe8(0x10)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CachedMovementDigestedSkillSet; // 0xf8(0x08)
	struct UFortAthenaAIBotUnstuckDigestedSkillSet* UnstuckSkillSet; // 0x100(0x08)
	char pad_108[0xa0]; // 0x108(0xa0)

	void OnCurrentUnstuckSteeringAttemptFinished(enum class EBotUnstuckSteeringReason UnstuckSteeringReason); // Function FortniteAI.FortAthenaAIBotEvaluator_Movement.OnCurrentUnstuckSteeringAttemptFinished // (Final|Native|Private) // @ game+0x96786e0
	void EvaluateIsolatedIslandSteering(); // Function FortniteAI.FortAthenaAIBotEvaluator_Movement.EvaluateIsolatedIslandSteering // (Final|Native|Private) // @ game+0x96786c0
};

// Class FortniteAI.FortAthenaAIBotEvaluator_Loot
// Size: 0x368 (Inherited: 0x1a8)
struct UFortAthenaAIBotEvaluator_Loot : UFortAthenaAIBotEvaluator_Movement {
	struct UAthenaAIServiceLoot* CachedAIServiceLoot; // 0x1a8(0x08)
	struct UFortAthenaAIBotLootingDigestedSkillSet* LootingSkillSet; // 0x1b0(0x08)
	char pad_1B8[0x10]; // 0x1b8(0x10)
	struct FName LootDestinationKeyName; // 0x1c8(0x04)
	struct FName LootObjectKeyName; // 0x1cc(0x04)
	struct FName LootTypeKeyName; // 0x1d0(0x04)
	struct FName POINavigationExecutionStatusKeyName; // 0x1d4(0x04)
	char pad_1D8[0x8]; // 0x1d8(0x08)
	enum class EExecutionStatus POINavigationExecutionStatus; // 0x1e0(0x01)
	char pad_1E1[0x177]; // 0x1e1(0x177)
	uint32_t CurrentLootOctreeElementId; // 0x358(0x04)
	char pad_35C[0x4]; // 0x35c(0x04)
	struct AFortTeamInfoAthena* CachedTeamInfo; // 0x360(0x08)
};

// Class FortniteAI.FortAthenaAIBotEvasiveManeuversDigestedSkillSet
// Size: 0x148 (Inherited: 0x30)
struct UFortAthenaAIBotEvasiveManeuversDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	char pad_30[0x8]; // 0x30(0x08)
	struct FDigestedEvasiveManeuverSkillSettings DefaultEvasiveManeuverSkillSettings; // 0x38(0x58)
	struct TArray<struct FDigestedEvasiveManeuverSkillSettingsSpecialization> EvasiveManeuverSkillSettingsSpecializations; // 0x90(0x10)
	float JetpackStrafeDelay; // 0xa0(0x04)
	float JetpackStrafeRandomDeviationDelay; // 0xa4(0x04)
	float JetpackStrafeOverlayWeight; // 0xa8(0x04)
	float JetpackStrafeDistanceMax; // 0xac(0x04)
	float JetpackStrafeDistanceMin; // 0xb0(0x04)
	float JetpackStrafeActivationTime; // 0xb4(0x04)
	float JetpackStrafeActivationTimeRandomDeviation; // 0xb8(0x04)
	float JetpackStrafeTime; // 0xbc(0x04)
	float JetpackStrafeTimeRandomDeviation; // 0xc0(0x04)
	float DodgeMaxDistanceSquared; // 0xc4(0x04)
	float CrouchMaxDistanceSquared; // 0xc8(0x04)
	float JumpMaxDistanceSquared; // 0xcc(0x04)
	float JetpackStrafeMaxDistanceSquared; // 0xd0(0x04)
	float AvoidProjectilesReactionDistanceSqr; // 0xd4(0x04)
	float AvoidProjectilesReactionTimeMin; // 0xd8(0x04)
	float AvoidProjectilesReactionTimeMax; // 0xdc(0x04)
	float AvoidProjectilesEvasiveDistanceMin; // 0xe0(0x04)
	float AvoidProjectilesEvasiveDistanceMax; // 0xe4(0x04)
	float AvoidPhysicsObjectsReactionDistanceMin; // 0xe8(0x04)
	float AvoidPhysicsObjectsReactionDistanceMax; // 0xec(0x04)
	float AvoidPhysicsObjectsSpeedMin; // 0xf0(0x04)
	float AvoidPhysicsObjectsSpeedMax; // 0xf4(0x04)
	struct FGameplayTagQuery CanUseEvasiveManeuversTagQuery; // 0xf8(0x48)
	bool bCanCrouchInUrgentMovement; // 0x140(0x01)
	bool bCanDodgeInUrgentMovement; // 0x141(0x01)
	bool bCanJumpInUrgentMovement; // 0x142(0x01)
	char pad_143[0x5]; // 0x143(0x05)
};

// Class FortniteAI.FortAthenaAIBotEvasiveManeuversSkillSet
// Size: 0x6c8 (Inherited: 0x30)
struct UFortAthenaAIBotEvasiveManeuversSkillSet : UFortAthenaAIBotSkillSet {
	struct FEvasiveManeuverSkillSettings DefaultEvasiveManeuverSkillSettings; // 0x30(0x258)
	struct TArray<struct FEvasiveManeuverSkillSettingsSpecialization> EvasiveManeuverSkillSettingsSpecializations; // 0x288(0x10)
	struct FScalableFloat JetpackStrafeOverlayWeight; // 0x298(0x28)
	struct FScalableFloat JetpackStrafeDelay; // 0x2c0(0x28)
	struct FScalableFloat JetpackStrafeRandomDeviationDelay; // 0x2e8(0x28)
	struct FScalableFloat JetpackStrafeDistanceMax; // 0x310(0x28)
	struct FScalableFloat JetpackStrafeDistanceMin; // 0x338(0x28)
	struct FScalableFloat JetpackStrafeActivationTime; // 0x360(0x28)
	struct FScalableFloat JetpackStrafeActivationTimeRandomDeviation; // 0x388(0x28)
	struct FScalableFloat JetpackStrafeTime; // 0x3b0(0x28)
	struct FScalableFloat JetpackStrafeTimeRandomDeviation; // 0x3d8(0x28)
	struct FScalableFloat DodgeMaxDistance; // 0x400(0x28)
	struct FScalableFloat CanDodgeInUrgentMovement; // 0x428(0x28)
	struct FScalableFloat CrouchMaxDistance; // 0x450(0x28)
	struct FScalableFloat CanCrouchInUrgentMovement; // 0x478(0x28)
	struct FScalableFloat JumpMaxDistance; // 0x4a0(0x28)
	struct FScalableFloat CanJumpInUrgentMovement; // 0x4c8(0x28)
	struct FScalableFloat JetpackStrafeMaxDistance; // 0x4f0(0x28)
	struct FScalableFloat AvoidProjectilesReactionDistanceMax; // 0x518(0x28)
	struct FScalableFloat AvoidProjectilesReactionTimeMin; // 0x540(0x28)
	struct FScalableFloat AvoidProjectilesReactionTimeMax; // 0x568(0x28)
	struct FScalableFloat AvoidProjectilesEvasiveDistanceMin; // 0x590(0x28)
	struct FScalableFloat AvoidProjectilesEvasiveDistanceMax; // 0x5b8(0x28)
	struct FScalableFloat AvoidPhysicsObjectsReactionDistanceMin; // 0x5e0(0x28)
	struct FScalableFloat AvoidPhysicsObjectsReactionDistanceMax; // 0x608(0x28)
	struct FScalableFloat AvoidPhysicsObjectsSpeedMin; // 0x630(0x28)
	struct FScalableFloat AvoidPhysicsObjectsSpeedMax; // 0x658(0x28)
	struct FGameplayTagQuery CanUseEvasiveManeuversTagQuery; // 0x680(0x48)
};

// Class FortniteAI.FortAthenaAIBotHarvestDigestedSkillSet
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAIBotHarvestDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float DelayBetweenHarvest; // 0x30(0x04)
	float DeviationTimeBetweenHarvest; // 0x34(0x04)
	float HarvestingMaxDistanceSquared; // 0x38(0x04)
	float WeakSpotHitProbability; // 0x3c(0x04)
};

// Class FortniteAI.FortAthenaAIBotHarvestSkillSet
// Size: 0xd0 (Inherited: 0x30)
struct UFortAthenaAIBotHarvestSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat DelayBetweenHarvest; // 0x30(0x28)
	struct FScalableFloat DeviationTimeBetweenHarvest; // 0x58(0x28)
	struct FScalableFloat HarvestingMaxDistance; // 0x80(0x28)
	struct FScalableFloat WeakSpotHitProbability; // 0xa8(0x28)
};

// Class FortniteAI.FortAthenaAIBotHealingDigestedSkillSet
// Size: 0x70 (Inherited: 0x30)
struct UFortAthenaAIBotHealingDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	struct FFortBotDigestedHealingItemsList HealthItemsList; // 0x30(0x10)
	struct TArray<struct FFortBotDigestedHealingItemsSpec> HealthItemsSpecializations; // 0x40(0x10)
	struct FFortBotDigestedHealingItemsList ShieldItemsList; // 0x50(0x10)
	struct TArray<struct FFortBotDigestedHealingItemsSpec> ShieldItemsSpecializations; // 0x60(0x10)
};

// Class FortniteAI.FortAthenaAIBotHealingSkillSet
// Size: 0x70 (Inherited: 0x30)
struct UFortAthenaAIBotHealingSkillSet : UFortAthenaAIBotSkillSet {
	struct FFortBotHealingItemsList HealthItemsList; // 0x30(0x10)
	struct TArray<struct FFortBotHealingItemsSpec> HealthItemsSpecializations; // 0x40(0x10)
	struct FFortBotHealingItemsList ShieldItemsList; // 0x50(0x10)
	struct TArray<struct FFortBotHealingItemsSpec> ShieldItemsSpecializations; // 0x60(0x10)
};

// Class FortniteAI.FortAthenaAIBotInventoryDigestedSkillSet
// Size: 0x1a0 (Inherited: 0x30)
struct UFortAthenaAIBotInventoryDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float DefaultWeaponSelectionDistance; // 0x30(0x04)
	float DefaultWeaponSelectionDistanceDeviation; // 0x34(0x04)
	bool bHasInfiniteResources; // 0x38(0x01)
	bool bHasInfiniteAmmoForAllWeapons; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
	struct FGameplayTagContainer InventorySlotPreference[0x6]; // 0x40(0xc0)
	struct TArray<struct FDigestedBotEquipWeaponInfo> EquipWeaponInfo; // 0x100(0x10)
	bool bShouldPrioritizeRangedWeaponWithoutTarget; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	struct FGameplayTagContainer InfiniteAmmoCheats; // 0x118(0x20)
	struct TArray<struct FItemAndCount> MaterialItems; // 0x138(0x10)
	float GiveMaterialsToBotFrequency; // 0x148(0x04)
	char pad_14C[0x4]; // 0x14c(0x04)
	struct FGameplayTagContainer CheckLoadedAmmoForInfiniteAmmoCheats; // 0x150(0x20)
	float NoWeaponGiveWeaponAfterTime; // 0x170(0x04)
	float NoWeaponNoPlayerConeDistance; // 0x174(0x04)
	float NoWeaponNoPlayerConeFOV; // 0x178(0x04)
	struct FName NoWeaponLootTierGroup; // 0x17c(0x04)
	struct FGameplayTagContainer IgnoredAsWeaponTags; // 0x180(0x20)
};

// Class FortniteAI.FortAthenaAIBotInventorySkillSet
// Size: 0x2b0 (Inherited: 0x30)
struct UFortAthenaAIBotInventorySkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat DefaultWeaponSelectionDistance; // 0x30(0x28)
	struct FScalableFloat DefaultWeaponSelectionDistanceDeviation; // 0x58(0x28)
	struct FScalableFloat HasInfiniteResources; // 0x80(0x28)
	struct FGameplayTagContainer InventorySlotPreference[0x6]; // 0xa8(0xc0)
	struct TArray<struct FBotEquipWeaponInfo> EquipWeaponInfo; // 0x168(0x10)
	struct FScalableFloat ShouldPrioritizeRangedWeaponWithoutTarget; // 0x178(0x28)
	struct FScalableFloat HasInfiniteAmmoForAllWeapons; // 0x1a0(0x28)
	struct TArray<struct FWeaponAmmoCheat> AmmoCheats; // 0x1c8(0x10)
	struct TArray<struct FItemAndCount> MaterialItems; // 0x1d8(0x10)
	struct FScalableFloat GiveMaterialsToBotFrequency; // 0x1e8(0x28)
	struct FScalableFloat NoWeaponGiveWeaponAfterTime; // 0x210(0x28)
	struct FScalableFloat NoWeaponNoPlayerConeDistance; // 0x238(0x28)
	struct FScalableFloat NoWeaponNoPlayerConeFOV; // 0x260(0x28)
	struct FName NoWeaponLootTierGroup; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
	struct FGameplayTagContainer IgnoredAsWeaponTags; // 0x290(0x20)
};

// Class FortniteAI.FortAthenaAIBotLootingDigestedSkillSet
// Size: 0xb0 (Inherited: 0x30)
struct UFortAthenaAIBotLootingDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float ThresholdDistanceToSwitchLootItem; // 0x30(0x04)
	float ThresholdDistanceSquaredToRescanForBetterLoot; // 0x34(0x04)
	float ThresholdTimeToRescanForBetterLoot; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FVector OctreeBoxHalfExtent; // 0x40(0x18)
	float LootStateEvaluationRadiusSq; // 0x58(0x04)
	float MinLootDurationPerPOI; // 0x5c(0x04)
	float MaxLootDurationPerPOI; // 0x60(0x04)
	float LootPickupInteractionTime; // 0x64(0x04)
	float LootPickupInteractionDeviationTime; // 0x68(0x04)
	float Distance2DScore; // 0x6c(0x04)
	float HeightScore; // 0x70(0x04)
	float ThreatMaxScore; // 0x74(0x04)
	struct FScalableFloat ThreatProximityScoreTable; // 0x78(0x28)
	float PrioritizeWeaponScore; // 0xa0(0x04)
	float PoiSelectionDistanceScore; // 0xa4(0x04)
	float PoiSelectionBotPresenceScore; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class FortniteAI.FortAthenaAIBotLootingSkillSet
// Size: 0x2a0 (Inherited: 0x30)
struct UFortAthenaAIBotLootingSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat ThresholdDistanceToSwitchLootItem; // 0x30(0x28)
	struct FScalableFloat ThresholdDistanceToRescanForBetterLoot; // 0x58(0x28)
	struct FScalableFloat ThresholdTimeToRescanForBetterLoot; // 0x80(0x28)
	struct FVector OctreeBoxExtent; // 0xa8(0x18)
	struct FScalableFloat LootStateEvaluationRadius; // 0xc0(0x28)
	struct FScalableFloat MinLootDurationPerPOI; // 0xe8(0x28)
	struct FScalableFloat MaxLootDurationPerPOI; // 0x110(0x28)
	struct FScalableFloat LootPickupInteractionTime; // 0x138(0x28)
	struct FScalableFloat LootPickupInteractionDeviationTime; // 0x160(0x28)
	struct FScalableFloat Distance2DScore; // 0x188(0x28)
	struct FScalableFloat HeightScore; // 0x1b0(0x28)
	struct FScalableFloat ThreatMaxScore; // 0x1d8(0x28)
	struct FScalableFloat ThreatProximityScoreTable; // 0x200(0x28)
	struct FScalableFloat PrioritizeWeaponScore; // 0x228(0x28)
	struct FScalableFloat PoiSelectionDistanceScore; // 0x250(0x28)
	struct FScalableFloat PoiSelectionBotPresenceScore; // 0x278(0x28)
};

// Class FortniteAI.FortAthenaAIBotMovementDigestedSkillSet
// Size: 0x2b8 (Inherited: 0x30)
struct UFortAthenaAIBotMovementDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float SlowDownDistanceSquared; // 0x30(0x04)
	float TraversalSpeedEstimation; // 0x34(0x04)
	float TraversalSpeedEstimationWithThreat; // 0x38(0x04)
	bool bOffPathDetectionEnabled; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	float OffPathDistanceThresholdSquared; // 0x40(0x04)
	float GliderDeployMinAngle; // 0x44(0x04)
	float GliderDeployMaxAngle; // 0x48(0x04)
	float GliderNoiseMinDistance; // 0x4c(0x04)
	float GliderNoiseMaxDistance; // 0x50(0x04)
	float GliderNoiseMinDelay; // 0x54(0x04)
	float GliderNoiseMaxDelay; // 0x58(0x04)
	float GliderNoiseDistanceTreshold; // 0x5c(0x04)
	float GliderStopRotationDistance; // 0x60(0x04)
	float GliderLandingDistance; // 0x64(0x04)
	float GliderRotationLerpDuration; // 0x68(0x04)
	bool GliderBehaviorEnableFlag; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	float GliderBehaviorMinInterval; // 0x70(0x04)
	float GliderBehaviorMaxInterval; // 0x74(0x04)
	float GliderBehaviorMinRadius; // 0x78(0x04)
	float GliderBehaviorMaxRadius; // 0x7c(0x04)
	float GliderBehaviorSurveyProbability; // 0x80(0x04)
	bool GliderMovementTypeEnableFlag; // 0x84(0x01)
	char pad_85[0x3]; // 0x85(0x03)
	float GliderLinearProbability; // 0x88(0x04)
	float GliderSpiralMinRadius; // 0x8c(0x04)
	float GliderSpiralMaxRadius; // 0x90(0x04)
	float GliderSpiralMinAngle; // 0x94(0x04)
	float GliderSpiralMaxAngle; // 0x98(0x04)
	float GliderSpiralMinInterval; // 0x9c(0x04)
	float GliderSpiralMaxInterval; // 0xa0(0x04)
	float GliderSpiralProbability; // 0xa4(0x04)
	float GliderSerpentineMinAngle; // 0xa8(0x04)
	float GliderSerpentineMaxAngle; // 0xac(0x04)
	float GliderSerpentineMinRadius; // 0xb0(0x04)
	float GliderSerpentineMaxRadius; // 0xb4(0x04)
	float GliderSerpentineMinInterval; // 0xb8(0x04)
	float GliderSerpentineMaxInterval; // 0xbc(0x04)
	float GliderSerpentineMinPeriod; // 0xc0(0x04)
	float GliderSerpentineMaxPeriod; // 0xc4(0x04)
	float GliderSerpentineProbability; // 0xc8(0x04)
	float JumpOffMinAngle; // 0xcc(0x04)
	float JumpOffMaxAngle; // 0xd0(0x04)
	float MinPatrolDistance; // 0xd4(0x04)
	float MaxPatrolDistance; // 0xd8(0x04)
	float MaxPatrolDistanceRandomDeviation; // 0xdc(0x04)
	float WobbleProbability; // 0xe0(0x04)
	float MaxDelayBetweenWobblingMovement; // 0xe4(0x04)
	float MaxDelayBetweenWobblingMovementRandomDeviation; // 0xe8(0x04)
	bool bAllowSwimWobble; // 0xec(0x01)
	char pad_ED[0x3]; // 0xed(0x03)
	float MaxWobblingDuration; // 0xf0(0x04)
	float MaxWobblingDurationRandomDeviation; // 0xf4(0x04)
	float MaxWobblingIntensity; // 0xf8(0x04)
	float WobblingIntensityDeviation; // 0xfc(0x04)
	float MaxWobblingFrequency; // 0x100(0x04)
	float WobblingFrequencyDeviation; // 0x104(0x04)
	float WobblingStickToPathCorridorStrength; // 0x108(0x04)
	float MaxAfterLaunchedPauseTime; // 0x10c(0x04)
	float MaxAfterLaunchedFromVortexPauseTime; // 0x110(0x04)
	float AfterLaunchedPauseTimeDeviation; // 0x114(0x04)
	bool bSteerMovementWhenLaunched; // 0x118(0x01)
	char pad_119[0x3]; // 0x119(0x03)
	float SteerMovementWhenLaunchedDirectionUpdateTime; // 0x11c(0x04)
	float MaxReactionTimeToDangerZone; // 0x120(0x04)
	float MaxReactionTimeToDangerZoneDeviation; // 0x124(0x04)
	bool bLimitBlockingObstacleAngle; // 0x128(0x01)
	bool bEnableSwimSprintJump; // 0x129(0x01)
	char pad_12A[0x2]; // 0x12a(0x02)
	float SwimSprintJumpDelay; // 0x12c(0x04)
	float SwimSprintJumpDelayDeviation; // 0x130(0x04)
	float SwimUnblockJumpHeightThreshold; // 0x134(0x04)
	bool bSwimSprintJumpNav2D; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	float TacticalSprintEvaluationMinTime; // 0x13c(0x04)
	float TacticalSprintEvaluationMaxTime; // 0x140(0x04)
	float TacticalSprintMinTriggerChance; // 0x144(0x04)
	float TacticalSprintMaxTriggerChance; // 0x148(0x04)
	float TacticalSprintMinTriggerChanceInUrgentMovement; // 0x14c(0x04)
	float TacticalSprintMaxTriggerChanceInUrgentMovement; // 0x150(0x04)
	float TacticalSprintMaxSlopeAngle; // 0x154(0x04)
	float TacticalSprintMinPathTargetDistance; // 0x158(0x04)
	float TacticalSprintMaxPathAlignmentAngle; // 0x15c(0x04)
	float TacticalSprintMaxPathConeAngle; // 0x160(0x04)
	float TacticalSprintPathConeRearOffset; // 0x164(0x04)
	bool TacticalSprintUsageEnabled; // 0x168(0x01)
	char pad_169[0x3]; // 0x169(0x03)
	float TacticalSprintJumpTriggerChance; // 0x16c(0x04)
	float TacticalSprintJumpDelay; // 0x170(0x04)
	float TacticalSprintJumpDelayDeviation; // 0x174(0x04)
	float TacticalSprintJumpDelayInitialRatio; // 0x178(0x04)
	char pad_17C[0x4]; // 0x17c(0x04)
	struct FVector SlidingBoxExtent; // 0x180(0x18)
	float SlidingEnabled[0x4]; // 0x198(0x10)
	float SlidingEvaluationMinTime; // 0x1a8(0x04)
	float SlidingEvaluationMaxTime; // 0x1ac(0x04)
	float SlidingTriggerChanceStyleMalus; // 0x1b0(0x04)
	float SlidingTriggerChanceStyleMalusRandomDeviation; // 0x1b4(0x04)
	float SlidingTriggerChanceFlat; // 0x1b8(0x04)
	float SlidingTriggerChanceLittleSlope; // 0x1bc(0x04)
	float SlidingTriggerChanceSteepSlope; // 0x1c0(0x04)
	float SlidingDuringUrgentMovementTriggerChanceFlat; // 0x1c4(0x04)
	float SlidingDuringUrgentMovementTriggerChanceLittleSlope; // 0x1c8(0x04)
	float SlidingDuringUrgentMovementTriggerChanceSteepSlope; // 0x1cc(0x04)
	float MinSlidingDuration; // 0x1d0(0x04)
	float SlidingCooldownMinTime; // 0x1d4(0x04)
	float SlidingCooldownMaxTime; // 0x1d8(0x04)
	float SlidingStopMinDelay; // 0x1dc(0x04)
	float SlidingStopMaxDelay; // 0x1e0(0x04)
	float SlidingMaxPathConeAngle; // 0x1e4(0x04)
	float SlidingMinPathTargetDistance; // 0x1e8(0x04)
	float SlidingAllowResumeFocusOnTargetTriggerChance; // 0x1ec(0x04)
	float MoveToRangeAttackMinOffset; // 0x1f0(0x04)
	float MoveToRangeAttackMaxOffset; // 0x1f4(0x04)
	float LKPMinOffset; // 0x1f8(0x04)
	float LKPMaxOffset; // 0x1fc(0x04)
	bool bInvestigateAllowSearch; // 0x200(0x01)
	char pad_201[0x3]; // 0x201(0x03)
	float InvestigateWaitMinTime; // 0x204(0x04)
	float InvestigateWaitMaxTime; // 0x208(0x04)
	float InvestigateSearchMinDistance; // 0x20c(0x04)
	float InvestigateSearchMaxDistance; // 0x210(0x04)
	float SandTunnelJumpMinTime; // 0x214(0x04)
	float SandTunnelJumpMaxTime; // 0x218(0x04)
	float SandTunnelBurrowedAndHiddenChance; // 0x21c(0x04)
	float SandTunnelBurrowedAndHiddenMinTime; // 0x220(0x04)
	float SandTunnelBurrowedAndHiddenMaxTime; // 0x224(0x04)
	struct FVector ZiplineOctreeBoxExtent; // 0x228(0x18)
	float ThresholdDistanceToRescanForZiplines; // 0x240(0x04)
	float CooldownBetweenZiplineUsages; // 0x244(0x04)
	float DistanceToAddToZiplineStartPosition; // 0x248(0x04)
	float RadiusFromZiplineEnterPointToLookAtExit; // 0x24c(0x04)
	bool ZiplineUsageEnabled; // 0x250(0x01)
	char pad_251[0x7]; // 0x251(0x07)
	struct FDigestedBotKnockbackSettings DefaultKnockbackSettings; // 0x258(0x50)
	struct TArray<struct FDigestedBotKnockbackSettings> KnockbackSettingsSpecializations; // 0x2a8(0x10)
};

// Class FortniteAI.FortAthenaAIBotMovementSkillSet
// Size: 0x13f8 (Inherited: 0x30)
struct UFortAthenaAIBotMovementSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat SlowDownDistance; // 0x30(0x28)
	struct FScalableFloat TraversalSpeedEstimation; // 0x58(0x28)
	struct FScalableFloat TraversalSpeedEstimationWithThreat; // 0x80(0x28)
	struct FScalableFloat OffPathDetectionEnabled; // 0xa8(0x28)
	struct FScalableFloat OffPathDistanceThreshold; // 0xd0(0x28)
	struct FScalableFloat GliderDeployMinAngle; // 0xf8(0x28)
	struct FScalableFloat GliderDeployMaxAngle; // 0x120(0x28)
	struct FScalableFloat GliderNoiseMinDistance; // 0x148(0x28)
	struct FScalableFloat GliderNoiseMaxDistance; // 0x170(0x28)
	struct FScalableFloat GliderNoiseMinDelay; // 0x198(0x28)
	struct FScalableFloat GliderNoiseMaxDelay; // 0x1c0(0x28)
	struct FScalableFloat GliderNoiseDistanceTreshold; // 0x1e8(0x28)
	struct FScalableFloat GliderStopRotationDistance; // 0x210(0x28)
	struct FScalableFloat GliderLandingDistance; // 0x238(0x28)
	struct FScalableFloat GliderRotationLerpDuration; // 0x260(0x28)
	struct FScalableFloat GliderBehaviorEnableFlag; // 0x288(0x28)
	struct FScalableFloat GliderBehaviorMinInterval; // 0x2b0(0x28)
	struct FScalableFloat GliderBehaviorMaxInterval; // 0x2d8(0x28)
	struct FScalableFloat GliderBehaviorMinRadius; // 0x300(0x28)
	struct FScalableFloat GliderBehaviorMaxRadius; // 0x328(0x28)
	struct FScalableFloat GliderBehaviorSurveyProbability; // 0x350(0x28)
	struct FScalableFloat GliderMovementTypeEnableFlag; // 0x378(0x28)
	struct FScalableFloat GliderLinearProbability; // 0x3a0(0x28)
	struct FScalableFloat GliderSpiralMinRadius; // 0x3c8(0x28)
	struct FScalableFloat GliderSpiralMaxRadius; // 0x3f0(0x28)
	struct FScalableFloat GliderSpiralMinAngle; // 0x418(0x28)
	struct FScalableFloat GliderSpiralMaxAngle; // 0x440(0x28)
	struct FScalableFloat GliderSpiralMinInterval; // 0x468(0x28)
	struct FScalableFloat GliderSpiralMaxInterval; // 0x490(0x28)
	struct FScalableFloat GliderSpiralProbability; // 0x4b8(0x28)
	struct FScalableFloat GliderSerpentineMinAngle; // 0x4e0(0x28)
	struct FScalableFloat GliderSerpentineMaxAngle; // 0x508(0x28)
	struct FScalableFloat GliderSerpentineMinRadius; // 0x530(0x28)
	struct FScalableFloat GliderSerpentineMaxRadius; // 0x558(0x28)
	struct FScalableFloat GliderSerpentineMinInterval; // 0x580(0x28)
	struct FScalableFloat GliderSerpentineMaxInterval; // 0x5a8(0x28)
	struct FScalableFloat GliderSerpentineMinPeriod; // 0x5d0(0x28)
	struct FScalableFloat GliderSerpentineMaxPeriod; // 0x5f8(0x28)
	struct FScalableFloat GliderSerpentineProbability; // 0x620(0x28)
	struct FScalableFloat JumpOffMinAngle; // 0x648(0x28)
	struct FScalableFloat JumpOffMaxAngle; // 0x670(0x28)
	struct FScalableFloat MinPatrolDistance; // 0x698(0x28)
	struct FScalableFloat MaxPatrolDistance; // 0x6c0(0x28)
	struct FScalableFloat MaxPatrolDistanceRandomDeviation; // 0x6e8(0x28)
	struct FScalableFloat MoveToRangeAttackMinOffset; // 0x710(0x28)
	struct FScalableFloat MoveToRangeAttackMaxOffset; // 0x738(0x28)
	struct FScalableFloat LKPMinOffset; // 0x760(0x28)
	struct FScalableFloat LKPMaxOffset; // 0x788(0x28)
	struct FScalableFloat bInvestigateAllowSearch; // 0x7b0(0x28)
	struct FScalableFloat InvestigateWaitMinTime; // 0x7d8(0x28)
	struct FScalableFloat InvestigateWaitMaxTime; // 0x800(0x28)
	struct FScalableFloat InvestigateSearchMinDistance; // 0x828(0x28)
	struct FScalableFloat InvestigateSearchMaxDistance; // 0x850(0x28)
	struct FScalableFloat SandTunnelJumpMinTime; // 0x878(0x28)
	struct FScalableFloat SandTunnelJumpMaxTime; // 0x8a0(0x28)
	struct FScalableFloat SandTunnelBurrowedAndHiddenChance; // 0x8c8(0x28)
	struct FScalableFloat SandTunnelBurrowedAndHiddenMinTime; // 0x8f0(0x28)
	struct FScalableFloat SandTunnelBurrowedAndHiddenMaxTime; // 0x918(0x28)
	struct FScalableFloat WobblingProbability; // 0x940(0x28)
	struct FScalableFloat MaxDelayBetweenWobblingMovement; // 0x968(0x28)
	struct FScalableFloat MaxDelayBetweenWobblingMovementRandomDeviation; // 0x990(0x28)
	struct FScalableFloat MaxWobblingDuration; // 0x9b8(0x28)
	struct FScalableFloat MaxWobblingDurationRandomDeviation; // 0x9e0(0x28)
	struct FScalableFloat MaxWobblingIntensity; // 0xa08(0x28)
	struct FScalableFloat WobblingIntensityDeviation; // 0xa30(0x28)
	struct FScalableFloat MaxWobblingFrequency; // 0xa58(0x28)
	struct FScalableFloat WobblingFrequencyDeviation; // 0xa80(0x28)
	struct FScalableFloat WobblingStickToPathCorridorStrength; // 0xaa8(0x28)
	struct FScalableFloat LimitBlockingObstacleAngle; // 0xad0(0x28)
	struct FScalableFloat MaxAfterLaunchedPauseTime; // 0xaf8(0x28)
	struct FScalableFloat MaxAfterLaunchedFromVortexPauseTime; // 0xb20(0x28)
	struct FScalableFloat AfterLaunchedPauseTimeDeviation; // 0xb48(0x28)
	struct FScalableFloat SteerMovementWhenLaunched; // 0xb70(0x28)
	struct FScalableFloat SteerMovementWhenLaunchedDirectionUpdateTime; // 0xb98(0x28)
	struct FScalableFloat MaxReactionTimeToDangerZone; // 0xbc0(0x28)
	struct FScalableFloat MaxReactionTimeToDangerZoneDeviation; // 0xbe8(0x28)
	struct FScalableFloat AllowSwimWobble; // 0xc10(0x28)
	struct FScalableFloat EnableSwimSprintJump; // 0xc38(0x28)
	struct FScalableFloat SwimSprintJumpDelay; // 0xc60(0x28)
	struct FScalableFloat SwimSprintJumpDelayDeviation; // 0xc88(0x28)
	struct FScalableFloat SwimUnblockJumpHeightThreshold; // 0xcb0(0x28)
	struct FScalableFloat SwimSprintJumpNav2D; // 0xcd8(0x28)
	struct FScalableFloat TacticalSprintEvaluationMinTime; // 0xd00(0x28)
	struct FScalableFloat TacticalSprintEvaluationMaxTime; // 0xd28(0x28)
	struct FScalableFloat TacticalSprintMinTriggerChance; // 0xd50(0x28)
	struct FScalableFloat TacticalSprintMaxTriggerChance; // 0xd78(0x28)
	struct FScalableFloat TacticalSprintMinTriggerChanceInUrgentMovement; // 0xda0(0x28)
	struct FScalableFloat TacticalSprintMaxTriggerChanceInUrgentMovement; // 0xdc8(0x28)
	struct FScalableFloat TacticalSprintMaxSlopeAngle; // 0xdf0(0x28)
	struct FScalableFloat TacticalSprintMinPathTargetDistance; // 0xe18(0x28)
	struct FScalableFloat TacticalSprintMaxPathAlignmentAngle; // 0xe40(0x28)
	struct FScalableFloat TacticalSprintMaxPathConeAngle; // 0xe68(0x28)
	struct FScalableFloat TacticalSprintPathConeRearOffset; // 0xe90(0x28)
	struct FScalableFloat TacticalSprintUsageEnabled; // 0xeb8(0x28)
	struct FScalableFloat TacticalSprintJumpTriggerChance; // 0xee0(0x28)
	struct FScalableFloat TacticalSprintJumpDelay; // 0xf08(0x28)
	struct FScalableFloat TacticalSprintJumpDelayDeviation; // 0xf30(0x28)
	struct FScalableFloat TacticalSprintJumpDelayInitialRatio; // 0xf58(0x28)
	struct FVector SlidingBoxExtent; // 0xf80(0x18)
	struct FScalableFloat SlidingEnabled[0x4]; // 0xf98(0xa0)
	struct FScalableFloat SlidingEvaluationMinTime; // 0x1038(0x28)
	struct FScalableFloat SlidingEvaluationMaxTime; // 0x1060(0x28)
	struct FScalableFloat SlidingTriggerChanceStyleMalus; // 0x1088(0x28)
	struct FScalableFloat SlidingTriggerChanceStyleMalusRandomDeviation; // 0x10b0(0x28)
	struct FScalableFloat SlidingTriggerChanceFlat; // 0x10d8(0x28)
	struct FScalableFloat SlidingTriggerChanceLittleSlope; // 0x1100(0x28)
	struct FScalableFloat SlidingTriggerChanceSteepSlope; // 0x1128(0x28)
	struct FScalableFloat SlidingDuringUrgentMovementTriggerChanceFlat; // 0x1150(0x28)
	struct FScalableFloat SlidingDuringUrgentMovementTriggerChanceLittleSlope; // 0x1178(0x28)
	struct FScalableFloat SlidingDuringUrgentMovementTriggerChanceSteepSlope; // 0x11a0(0x28)
	struct FScalableFloat MinSlidingDuration; // 0x11c8(0x28)
	struct FScalableFloat SlidingCooldownMinTime; // 0x11f0(0x28)
	struct FScalableFloat SlidingCooldownMaxTime; // 0x1218(0x28)
	struct FScalableFloat SlidingStopMinDelay; // 0x1240(0x28)
	struct FScalableFloat SlidingStopMaxDelay; // 0x1268(0x28)
	struct FScalableFloat SlidingMaxPathConeAngle; // 0x1290(0x28)
	struct FScalableFloat SlidingMinPathTargetDistance; // 0x12b8(0x28)
	struct FScalableFloat SlidingAllowResumeFocusOnTargetTriggerChance; // 0x12e0(0x28)
	struct FVector ZiplineOctreeBoxExtent; // 0x1308(0x18)
	struct FScalableFloat ThresholdDistanceToRescanForZiplines; // 0x1320(0x28)
	struct FScalableFloat CooldownBetweenZiplineUsages; // 0x1348(0x28)
	struct FScalableFloat DistanceToAddToZiplineStartPosition; // 0x1370(0x28)
	struct FScalableFloat RadiusFromZiplineEnterPointToLookAtExit; // 0x1398(0x28)
	struct FScalableFloat ZiplineUsageEnabled; // 0x13c0(0x28)
	struct TArray<struct FBotKnockbackSettings> KnockbackSettings; // 0x13e8(0x10)
};

// Class FortniteAI.FortAthenaAIBotPathFollowingComponent
// Size: 0x570 (Inherited: 0x338)
struct UFortAthenaAIBotPathFollowingComponent : UFortPathFollowingComponentBase {
	struct AFortAthenaAIBotController* BotController; // 0x338(0x08)
	struct ABuildingActor* HitBuilding; // 0x340(0x08)
	struct UFortAthenaAIBotUnstuckDigestedSkillSet* CachedUnstuckSkillSet; // 0x348(0x08)
	struct UFortAthenaAIBotMovementDigestedSkillSet* CachedMovementSkillSet; // 0x350(0x08)
	struct UFortAthenaAIBotVehicleDigestedSkillSet* CachedVehicleSkillSet; // 0x358(0x08)
	char pad_360[0x210]; // 0x360(0x210)

	void HandlePawnTeleported(struct AFortPawn* TeleportedPawn); // Function FortniteAI.FortAthenaAIBotPathFollowingComponent.HandlePawnTeleported // (Final|Native|Public) // @ game+0x9683af0
};

// Class FortniteAI.FortAthenaAIBotPerceptionDigestedSkillSet
// Size: 0x350 (Inherited: 0x30)
struct UFortAthenaAIBotPerceptionDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float SightReactionTime; // 0x30(0x04)
	float SightRandomDeviation; // 0x34(0x04)
	char pad_38[0x28]; // 0x38(0x28)
	struct TArray<struct FDigestedSightReactionSpecialization> SightReactionSpecializations; // 0x60(0x10)
	float LoseSightTime; // 0x70(0x04)
	float LoseSightRandomDeviation; // 0x74(0x04)
	float SightSuspicionTime; // 0x78(0x04)
	float SightSuspicionRandomDeviation; // 0x7c(0x04)
	float EnemyMarkedReactionTime; // 0x80(0x04)
	float EnemyMarkedReactionRandomDeviation; // 0x84(0x04)
	float ChancesToHelpOnMarkedEnemy; // 0x88(0x04)
	float DamageReactionTime; // 0x8c(0x04)
	float DamageRandomDeviation; // 0x90(0x04)
	float HearingReactionTime; // 0x94(0x04)
	float HearingRandomDeviation; // 0x98(0x04)
	float MaxHearingLocationError; // 0x9c(0x04)
	float ObstacleDistanceOverrideTargetingSq; // 0xa0(0x04)
	float ObstacleForgetDistanceSq; // 0xa4(0x04)
	float ObstacleMinimumBlockingTime; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FFortAthenaAIBotDigestedTargetHeuristicSettings DefaultTargetHeuristicSettings; // 0xb0(0x190)
	struct TArray<struct FFortAthenaAIBotDigestedTargetHeuristicSettingsSpecialization> TargetHeuristicsSettingsSpecializations; // 0x240(0x10)
	struct FSoundPerceptionDigestedSetting SoundSettings[0x7]; // 0x250(0x54)
	float AlertedAccumulatedLoudnessLimit; // 0x2a4(0x04)
	float AlertedAccumulatedDamageLimit; // 0x2a8(0x04)
	float LKPAccumulatedLoudnessLimit; // 0x2ac(0x04)
	float EnemyMarkingDelay; // 0x2b0(0x04)
	float EnemyMarkingDelayRandomDeviation; // 0x2b4(0x04)
	float AdditionalMarkedEnemyLKPForgetTime; // 0x2b8(0x04)
	float AdditionalMarkedEnemyLKPForgetDistance; // 0x2bc(0x04)
	struct FAlertLevelInfo AlertLevelInfos[0x4]; // 0x2c0(0x40)
	float ProjectileThreatForgetTime; // 0x300(0x04)
	struct FTrapPerceptionSettings TrapPerceptionSettings; // 0x304(0x14)
	bool bStealthMeterEnable; // 0x318(0x01)
	char pad_319[0x3]; // 0x319(0x03)
	float StealthMeterThreshold; // 0x31c(0x04)
	struct FScalableFloat StealthMeterIncreaseSpeed; // 0x320(0x28)
	float StealthMeterDecreaseSpeed; // 0x348(0x04)
	bool bStealthMeterAllowSharedTarget; // 0x34c(0x01)
	bool bStealthMeterForceLKPWhenDamagedAndThreatened; // 0x34d(0x01)
	char pad_34E[0x2]; // 0x34e(0x02)
};

// Class FortniteAI.FortAthenaAIBotPerceptionSkillSet
// Size: 0xce0 (Inherited: 0x30)
struct UFortAthenaAIBotPerceptionSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat SightReactionTime; // 0x30(0x28)
	struct FScalableFloat SightRandomDeviation; // 0x58(0x28)
	struct FScalableFloat SightRandomAddition; // 0x80(0x28)
	struct TArray<struct FSightReactionSpecialization> SightReactionSpecializations; // 0xa8(0x10)
	struct FScalableFloat LoseSightTime; // 0xb8(0x28)
	struct FScalableFloat LoseSightRandomDeviation; // 0xe0(0x28)
	struct FScalableFloat SightSuspicionTime; // 0x108(0x28)
	struct FScalableFloat SightSuspicionRandomDeviation; // 0x130(0x28)
	struct FScalableFloat EnemyMarkedReactionTime; // 0x158(0x28)
	struct FScalableFloat EnemyMarkedReactionRandomDeviation; // 0x180(0x28)
	struct FScalableFloat ChancesToHelpOnMarkedEnemy; // 0x1a8(0x28)
	struct FScalableFloat DamageReactionTime; // 0x1d0(0x28)
	struct FScalableFloat DamageRandomDeviation; // 0x1f8(0x28)
	struct FScalableFloat HearingReactionTime; // 0x220(0x28)
	struct FScalableFloat HearingRandomDeviation; // 0x248(0x28)
	struct FScalableFloat MaxHearingLocationError; // 0x270(0x28)
	struct FFortAthenaAIBotTargetHeuristicSettings DefaultTargetHeuristicSettings; // 0x298(0x348)
	struct TArray<struct FFortAthenaAIBotTargetHeuristicSettingsSpecialization> TargetHeuristicSettingsSpecializations; // 0x5e0(0x10)
	struct FScalableFloat ObstacleDistanceOverrideTargeting; // 0x5f0(0x28)
	struct FScalableFloat ObstacleForgetDistance; // 0x618(0x28)
	struct FScalableFloat ObstacleMinimumBlockingTime; // 0x640(0x28)
	struct FSoundPerceptionSetting SoundSettings[0x7]; // 0x668(0x348)
	struct FScalableFloat AlertedAccumulatedLoudnessLimit; // 0x9b0(0x28)
	struct FScalableFloat AlertedAccumulatedDamageLimit; // 0x9d8(0x28)
	struct FScalableFloat LKPAccumulatedLoudnessLimit; // 0xa00(0x28)
	struct FScalableFloat EnemyMarkingDelay; // 0xa28(0x28)
	struct FScalableFloat EnemyMarkingDelayRandomDeviation; // 0xa50(0x28)
	struct FScalableFloat AdditionalMarkedEnemyLKPForgetTime; // 0xa78(0x28)
	struct FScalableFloat AdditionalMarkedEnemyLKPForgetDistance; // 0xaa0(0x28)
	struct TArray<struct UFortAthenaAIBotAlertLevelConfig*> AlertLevelConfigs; // 0xac8(0x10)
	struct FScalableFloat ProjectileThreatForgetTime; // 0xad8(0x28)
	struct FScalableFloat TrapDetectionDistanceMax; // 0xb00(0x28)
	struct FScalableFloat TrapDetectionDistanceMaxDeviation; // 0xb28(0x28)
	struct FScalableFloat TrapDetectionChanceWhenPerpendicular; // 0xb50(0x28)
	struct FScalableFloat TrapDetectionChanceWhenParallel; // 0xb78(0x28)
	struct FScalableFloat TrapDetectionEvaluationAngleThreshold; // 0xba0(0x28)
	struct FScalableFloat TrapDetectionAutomaticIfWithinCreationTime; // 0xbc8(0x28)
	struct FScalableFloat StealthMeterEnable; // 0xbf0(0x28)
	struct FScalableFloat StealthMeterThreshold; // 0xc18(0x28)
	struct FScalableFloat StealthMeterIncreaseSpeed; // 0xc40(0x28)
	struct FScalableFloat StealthMeterDecreaseSpeed; // 0xc68(0x28)
	struct FScalableFloat StealthMeterAllowSharedTarget; // 0xc90(0x28)
	struct FScalableFloat bStealthMeterForceLKPWhenDamagedAndThreatened; // 0xcb8(0x28)
};

// Class FortniteAI.FortAthenaAIBotPlayStyleDigestedSkillSet
// Size: 0x98 (Inherited: 0x30)
struct UFortAthenaAIBotPlayStyleDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	struct FScalableFloat AggressiveTowardsThreatWeight; // 0x30(0x28)
	struct FScalableFloat DefensiveTowardsThreatWeight; // 0x58(0x28)
	enum class EDBNOPlayStyle DBNOPlayStyle; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct TArray<struct FPlaystyleSwitchToAggressiveDataDigested> ChangeToAggressiveData; // 0x88(0x10)
};

// Class FortniteAI.FortAthenaAIBotPlayStyleSkillSet
// Size: 0x108 (Inherited: 0x30)
struct UFortAthenaAIBotPlayStyleSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat AggressiveTowardsThreatWeight; // 0x30(0x28)
	struct FScalableFloat DefensiveTowardsThreatWeight; // 0x58(0x28)
	struct FScalableFloat PassiveDBNOPlayStyle; // 0x80(0x28)
	struct FScalableFloat ThirstyDBNOPlayStyle; // 0xa8(0x28)
	struct FScalableFloat PassiveOnHumansDBNOPlayStyle; // 0xd0(0x28)
	struct TArray<struct FPlaystyleSwitchToAggressiveData> ChangeToAggressiveData; // 0xf8(0x10)
};

// Class FortniteAI.FortAthenaAIBotPropagateAwarenessDigestedSkillSet
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAIBotPropagateAwarenessDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float PropagationMaxDistanceSQ; // 0x30(0x04)
	float CosineFOV; // 0x34(0x04)
};

// Class FortniteAI.FortAthenaAIBotPropagateAwarenessSkillSet
// Size: 0x80 (Inherited: 0x30)
struct UFortAthenaAIBotPropagateAwarenessSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat PropagationMaxDistance; // 0x30(0x28)
	struct FScalableFloat FOV; // 0x58(0x28)
};

// Class FortniteAI.FortAthenaAIBotRangeAttackDigestedSkillSet
// Size: 0x150 (Inherited: 0x30)
struct UFortAthenaAIBotRangeAttackDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	struct TWeakObjectPtr<struct AFortWeapon> CachedWeaponUsedToCalculateSkillSet; // 0x30(0x08)
	char pad_38[0x8]; // 0x38(0x08)
	struct TArray<struct FDigestedRangedWeaponSkillCategory> RangedWeaponCategorySkills; // 0x40(0x10)
	float ChangeWeaponDelay; // 0x50(0x04)
	float ChangeWeaponDelayDeviation; // 0x54(0x04)
	float SwapInsteadOfReloadOdds; // 0x58(0x04)
	float SwapInsteadOfReloadRangeMax; // 0x5c(0x04)
	struct FGameplayTagContainer SwapInsteadOfReloadIgnoredWeaponTags; // 0x60(0x20)
	float InterruptReloadToShootOdds; // 0x80(0x04)
	float ReloadPartiallyEmptyWeaponsOdds; // 0x84(0x04)
	float UseCoverOdds; // 0x88(0x04)
	float CoverDistanceMin; // 0x8c(0x04)
	struct FScalableFloat CoverDistanceMaxCurve; // 0x90(0x28)
	float CoverDistanceToTargetMin; // 0xb8(0x04)
	float MinimumDistanceToTargetWhileMovingToCover; // 0xbc(0x04)
	float CoverSearchCooldown; // 0xc0(0x04)
	float MaximumPathDetourFactor; // 0xc4(0x04)
	float PostCoverCooldownMin; // 0xc8(0x04)
	float PostCoverCooldownMax; // 0xcc(0x04)
	bool bCanFindShootingPositionAround; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	float PositioningMaxSearchRadius; // 0xd4(0x04)
	float PositioningQueryCooldown; // 0xd8(0x04)
	float PositioningQueryCooldownDeviation; // 0xdc(0x04)
	int32_t CoverPeekCountMin; // 0xe0(0x04)
	int32_t CoverPeekCountMax; // 0xe4(0x04)
	float ShotDelayAfterTargetRevived; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct TArray<struct FDigestedFiringPattern> DefaultTargetInAirFiringPatterns; // 0xf0(0x10)
	bool bStepBackEnabled; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	float StepBackCooldown; // 0x104(0x04)
	float StepBackPercentageChance; // 0x108(0x04)
	float StepBackDistanceBetweenAIPawnAndTargetMin; // 0x10c(0x04)
	float StepBackDistanceBetweenAIPawnAndTargetMax; // 0x110(0x04)
	float StepBackDistanceBetweenCoverAndTargetMin; // 0x114(0x04)
	float StepBackDistanceBetweenCoverAndTargetMax; // 0x118(0x04)
	float StepBackDistanceBetweenAIPawnAndCoverMin; // 0x11c(0x04)
	float StepBackDistanceBetweenAIPawnAndCoverMax; // 0x120(0x04)
	bool bFlankingEnabled; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
	float FlankingCooldown; // 0x128(0x04)
	float FlankingPercentageChance; // 0x12c(0x04)
	float FlankingInnerRadius; // 0x130(0x04)
	float FlankingOuterRadius; // 0x134(0x04)
	int32_t FlankingLayersCount; // 0x138(0x04)
	int32_t FlankingPointsPerLayerCount; // 0x13c(0x04)
	float FlankingMaxAngleRad; // 0x140(0x04)
	float FlankingScorePawnDetectionRadius; // 0x144(0x04)
	float LoFMaxDistanceToTest; // 0x148(0x04)
	float LoFForceCrouchVehicleSeatZOffset; // 0x14c(0x04)
};

// Class FortniteAI.FortAthenaAIBotRangeAttackSkillSet
// Size: 0x700 (Inherited: 0x30)
struct UFortAthenaAIBotRangeAttackSkillSet : UFortAthenaAIBotSkillSet {
	struct TArray<struct FRangedWeaponSkillCategory> RangedWeaponSkills; // 0x30(0x10)
	struct FScalableFloat ChangeWeaponDelay; // 0x40(0x28)
	struct FScalableFloat ChangeWeaponDelayDeviation; // 0x68(0x28)
	struct FScalableFloat SwapInsteadOfReloadOdds; // 0x90(0x28)
	struct FScalableFloat SwapInsteadOfReloadRangeMax; // 0xb8(0x28)
	struct FGameplayTagContainer SwapInsteadOfReloadIgnoredWeaponTags; // 0xe0(0x20)
	struct FScalableFloat InterruptReloadToShootOdds; // 0x100(0x28)
	struct FScalableFloat ReloadPartiallyEmptyWeaponsOdds; // 0x128(0x28)
	struct FScalableFloat UseCoverOdds; // 0x150(0x28)
	struct FScalableFloat CoverDistanceMin; // 0x178(0x28)
	struct FScalableFloat CoverDistanceMaxCurve; // 0x1a0(0x28)
	struct FScalableFloat CoverDistanceToTargetMin; // 0x1c8(0x28)
	struct FScalableFloat MinimumDistanceToTargetWhileMovingToCover; // 0x1f0(0x28)
	struct FScalableFloat CoverSearchCooldown; // 0x218(0x28)
	struct FScalableFloat MaximumPathDetourFactor; // 0x240(0x28)
	struct FScalableFloat PostCoverCooldownMin; // 0x268(0x28)
	struct FScalableFloat PostCoverCooldownMax; // 0x290(0x28)
	struct FScalableFloat CanFindShootingPositionAround; // 0x2b8(0x28)
	struct FScalableFloat PositioningMaxSearchRadius; // 0x2e0(0x28)
	struct FScalableFloat PositioningQueryCooldown; // 0x308(0x28)
	struct FScalableFloat PositioningQueryCooldownDeviation; // 0x330(0x28)
	struct FScalableFloat CoverPeekCountMin; // 0x358(0x28)
	struct FScalableFloat CoverPeekCountMax; // 0x380(0x28)
	struct FScalableFloat ShotDelayAfterTargetRevived; // 0x3a8(0x28)
	struct TArray<struct FFiringPattern> DefaultTargetInAirFiringPatterns; // 0x3d0(0x10)
	struct FScalableFloat StepBackEnabled; // 0x3e0(0x28)
	struct FScalableFloat StepBackCooldown; // 0x408(0x28)
	struct FScalableFloat StepBackPercentageChance; // 0x430(0x28)
	struct FScalableFloat StepBackDistanceBetweenAIPawnAndTargetMin; // 0x458(0x28)
	struct FScalableFloat StepBackDistanceBetweenAIPawnAndTargetMax; // 0x480(0x28)
	struct FScalableFloat StepBackDistanceBetweenCoverAndTargetMin; // 0x4a8(0x28)
	struct FScalableFloat StepBackDistanceBetweenCoverAndTargetMax; // 0x4d0(0x28)
	struct FScalableFloat StepBackDistanceBetweenAIPawnAndCoverMin; // 0x4f8(0x28)
	struct FScalableFloat StepBackDistanceBetweenAIPawnAndCoverMax; // 0x520(0x28)
	struct FScalableFloat FlankingEnabled; // 0x548(0x28)
	struct FScalableFloat FlankingCooldown; // 0x570(0x28)
	struct FScalableFloat FlankingPercentageChance; // 0x598(0x28)
	struct FScalableFloat FlankingInnerRadius; // 0x5c0(0x28)
	struct FScalableFloat FlankingOuterRadius; // 0x5e8(0x28)
	struct FScalableFloat FlankingLayersCount; // 0x610(0x28)
	struct FScalableFloat FlankingPointsPerLayerCount; // 0x638(0x28)
	struct FScalableFloat FlankingMaxAngle; // 0x660(0x28)
	struct FScalableFloat FlankingScorePawnDetectionRadius; // 0x688(0x28)
	struct FScalableFloat LoFMaxDistanceToTest; // 0x6b0(0x28)
	struct FScalableFloat LoFForceCrouchVehicleSeatZOffset; // 0x6d8(0x28)
};

// Class FortniteAI.FortAthenaAIBotReviveDigestedSkillSet
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAIBotReviveDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float AllyEvaluationTime; // 0x30(0x04)
	float AllyEvaluationTimeDeviation; // 0x34(0x04)
	float CooldownOnCancel; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class FortniteAI.FortAthenaAIBotReviveSkillSet
// Size: 0xa8 (Inherited: 0x30)
struct UFortAthenaAIBotReviveSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat AllyEvaluationTime; // 0x30(0x28)
	struct FScalableFloat AllyEvaluationTimeDeviation; // 0x58(0x28)
	struct FScalableFloat CooldownOnCancel; // 0x80(0x28)
};

// Class FortniteAI.FortAthenaAIBotUnstuckDigestedSkillSet
// Size: 0x90 (Inherited: 0x30)
struct UFortAthenaAIBotUnstuckDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	bool bCanUndermineWhenStuck; // 0x30(0x01)
	bool bCanTeleportWhenStuck; // 0x31(0x01)
	bool bAvoidsTeleportLocationsUnderTheLandscape; // 0x32(0x01)
	bool bCanTeleportWhenStuckWithPlayerAround; // 0x33(0x01)
	float MaxDistanceSqToPlayerToTeleport; // 0x34(0x04)
	float PlayerToPhoebeAngleVisibilityConeToTeleport; // 0x38(0x04)
	float TimeBetweenPartialPathToConsiderPathStuck; // 0x3c(0x04)
	int32_t ConsecutivePartialPathCountToConsiderPathStuck; // 0x40(0x04)
	float DistanceSqBetweenBlockedPathToConsiderPathStuck; // 0x44(0x04)
	float DistanceBetweenSampleToConsiderPathStuckInWater; // 0x48(0x04)
	float TimeBetweenSampleToConsiderPathStuckInWater; // 0x4c(0x04)
	float DistanceBetweenSampleToConsiderPathStuckOnGround; // 0x50(0x04)
	float TimeBetweenSampleToConsiderPathStuckOnGround; // 0x54(0x04)
	int32_t ConsecutiveBlockedPathCountToConsiderPathStuck; // 0x58(0x04)
	int32_t MaxSafeZoneIndexToAllowTeleport; // 0x5c(0x04)
	float TimeToBreakBlockingDoor; // 0x60(0x04)
	float TimeToCloseBlockingDoor; // 0x64(0x04)
	float RiverbedObstacleCollisionNormalThreshold; // 0x68(0x04)
	bool bCanUseSteeringWhenStuckOnIsolatedIsland; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	int32_t MaxSteeringDirectionAttempts; // 0x70(0x04)
	float SteeringAttemptDuration; // 0x74(0x04)
	float EvaluateIsolatedIslandSteeringTime; // 0x78(0x04)
	bool bCanSlideWhenBlocked; // 0x7c(0x01)
	char pad_7D[0x3]; // 0x7d(0x03)
	float SlidingDurationSeconds; // 0x80(0x04)
	float SlidingStartIntensity; // 0x84(0x04)
	float SlidingIntensityPerSeconds; // 0x88(0x04)
	float SlidingMaxIntensity; // 0x8c(0x04)
};

// Class FortniteAI.FortAthenaAIBotUnstuckSkillSet
// Size: 0x468 (Inherited: 0x30)
struct UFortAthenaAIBotUnstuckSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat CanUndermineWhenStuck; // 0x30(0x28)
	struct FScalableFloat CanTeleportWhenStuck; // 0x58(0x28)
	struct FScalableFloat AvoidsTeleportLocationsUnderTheLandscape; // 0x80(0x28)
	struct FScalableFloat CanTeleportWhenStuckWithPlayerAround; // 0xa8(0x28)
	struct FScalableFloat MaxDistanceToPlayerToTeleport; // 0xd0(0x28)
	struct FScalableFloat PlayerToPhoebeAngleVisibilityConeToTeleport; // 0xf8(0x28)
	struct FScalableFloat MaxSafeZoneIndexToAllowTeleport; // 0x120(0x28)
	struct FScalableFloat TimeToCloseBlockingDoor; // 0x148(0x28)
	struct FScalableFloat TimeToBreakBlockingDoor; // 0x170(0x28)
	struct FScalableFloat RiverbedObstacleCollisionNormalThreshold; // 0x198(0x28)
	struct FScalableFloat CanUseSteeringWhenStuckOnIsolatedIsland; // 0x1c0(0x28)
	struct FScalableFloat MaxSteeringDirectionAttempts; // 0x1e8(0x28)
	struct FScalableFloat SteeringAttemptDuration; // 0x210(0x28)
	struct FScalableFloat EvaluateIsolatedIslandSteeringTime; // 0x238(0x28)
	struct FScalableFloat TimeBetweenPartialPathToConsiderPathStuck; // 0x260(0x28)
	struct FScalableFloat ConsecutivePartialPathCountToConsiderPathStuck; // 0x288(0x28)
	struct FScalableFloat DistanceBetweenSampleToConsiderPathStuckInWater; // 0x2b0(0x28)
	struct FScalableFloat TimeBetweenSampleToConsiderPathStuckInWater; // 0x2d8(0x28)
	struct FScalableFloat DistanceBetweenSampleToConsiderPathStuckOnGround; // 0x300(0x28)
	struct FScalableFloat TimeBetweenSampleToConsiderPathStuckOnGround; // 0x328(0x28)
	struct FScalableFloat DistanceBetweenBlockedPathToConsiderPathStuck; // 0x350(0x28)
	struct FScalableFloat ConsecutiveBlockedPathCountToConsiderPathStuck; // 0x378(0x28)
	struct FScalableFloat bCanSlideWhenBlocked; // 0x3a0(0x28)
	struct FScalableFloat SlidingDurationSeconds; // 0x3c8(0x28)
	struct FScalableFloat SlidingStartIntensity; // 0x3f0(0x28)
	struct FScalableFloat SlidingIntensityPerSeconds; // 0x418(0x28)
	struct FScalableFloat SlidingMaxIntensity; // 0x440(0x28)
};

// Class FortniteAI.FortAthenaAIBotVehicleDigestedSkillSet
// Size: 0xf8 (Inherited: 0x30)
struct UFortAthenaAIBotVehicleDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	struct FDigestedVehicleDriving NoMatchingVehicleDriving; // 0x30(0xb8)
	struct TArray<struct FDigestedVehicleDrivingCategory> VehicleDrivingArray; // 0xe8(0x10)
};

// Class FortniteAI.FortAthenaAIBotVehicleSkillSet
// Size: 0x340 (Inherited: 0x30)
struct UFortAthenaAIBotVehicleSkillSet : UFortAthenaAIBotSkillSet {
	struct FVehicleDriving NoMatchingVehicleDriving; // 0x30(0x300)
	struct TArray<struct FVehicleDrivingCategory> VehicleDrivingArray; // 0x330(0x10)
};

// Class FortniteAI.FortAthenaAIBotWarmupDigestedSkillSet
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAIBotWarmupDigestedSkillSet : UFortAthenaAIBotDigestedSkillSet {
	float WarmupPlayEmoteBehaviorWeight; // 0x30(0x04)
	float WarmupLootAndShootBehaviorWeight; // 0x34(0x04)
	float WarmupIdleBehaviorWeight; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class FortniteAI.FortAthenaAIBotWarmupSkillSet
// Size: 0xa8 (Inherited: 0x30)
struct UFortAthenaAIBotWarmupSkillSet : UFortAthenaAIBotSkillSet {
	struct FScalableFloat WarmupPlayEmoteBehaviorWeight; // 0x30(0x28)
	struct FScalableFloat WarmupLootAndShootBehaviorWeight; // 0x58(0x28)
	struct FScalableFloat WarmupIdleBehaviorWeight; // 0x80(0x28)
};

// Class FortniteAI.FortAthenaAIBot_EQSQueryContext_CurrentTarget
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaAIBot_EQSQueryContext_CurrentTarget : UEnvQueryContext {
};

// Class FortniteAI.FortAthenaAICoverComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UFortAthenaAICoverComponent : UControllerComponent {
	struct UNavigationQueryFilter* CoverPositionFilterClass; // 0xa0(0x08)
	struct FVector CoverBoxExtent; // 0xa8(0x18)
	float CoverOffset; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct AAIController* CachedController; // 0xc8(0x08)
	struct TWeakObjectPtr<struct ABuildingActor> LastBuildingActorUsedForCover; // 0xd0(0x08)
};

// Class FortniteAI.BlackboardKeyAccessValidator
// Size: 0x28 (Inherited: 0x28)
struct UBlackboardKeyAccessValidator : UObject {
};

// Class FortniteAI.FortAthenaAIEvaluatorComponent
// Size: 0xc0 (Inherited: 0xa0)
struct UFortAthenaAIEvaluatorComponent : UActorComponent {
	struct TArray<struct FMovementEvaluatorInfo> MovementEvaluatorInfo; // 0xa0(0x10)
	struct TArray<struct UFortAthenaAIEvaluator*> AIEvaluators; // 0xb0(0x10)
};

// Class FortniteAI.FortAthenaAILeashVolume
// Size: 0x2e8 (Inherited: 0x2c8)
struct AFortAthenaAILeashVolume : AVolume {
	struct FVector ProjectExtent; // 0x2c8(0x18)
	float IsInsideTolerance; // 0x2e0(0x04)
	char pad_2E4[0x4]; // 0x2e4(0x04)
};

// Class FortniteAI.FortAthenaAILODSettingsContainer
// Size: 0xc8 (Inherited: 0x28)
struct UFortAthenaAILODSettingsContainer : UObject {
	struct TMap<ClassPtrProperty, struct TScriptInterface<IFortAthenaAILODSettings>> ClassToSettings; // 0x28(0x50)
	struct TArray<struct UFortAthenaAILODSettings_AIEvaluator*> LODSettings_AIEvaluators; // 0x78(0x10)
	struct TArray<struct UFortAthenaAILODSettings_CharacterMovement*> LODSettings_CharacterMovement; // 0x88(0x10)
	struct TArray<struct UFortAthenaAILODSettings_FortWeaponRanged*> LODSettings_FortWeaponRanged; // 0x98(0x10)
	struct TArray<struct UFortAthenaAILODSettings_GenericTickingObject*> LODSettings_GenericTickingObject; // 0xa8(0x10)
	struct UFortAIDirectorLODAIConfig* FortAIDirectorLODConfig; // 0xb8(0x08)
	struct UFortAIDirectorLODAIConfig* FortAIDirectorObjectLODConfig; // 0xc0(0x08)
};

// Class FortniteAI.FortAthenaAILODComponent
// Size: 0xe8 (Inherited: 0xa0)
struct UFortAthenaAILODComponent : UActorComponent {
	enum class EFortAILODLevel CurrentFortAILODLevel; // 0xa0(0x01)
	char pad_A1[0x2]; // 0xa1(0x02)
	char pad_A3_0 : 1; // 0xa3(0x01)
	char bCouldBeVisibleToPlayers : 1; // 0xa3(0x01)
	char pad_A3_2 : 6; // 0xa3(0x01)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct AFortPawn* CachedFortPawn; // 0xa8(0x08)
	struct UFortAthenaAILODSettingsContainer* AILODSettingsContainer; // 0xb0(0x08)
	char pad_B8[0x30]; // 0xb8(0x30)

	void OnRep_CurrentFortAILODLevel(); // Function FortniteAI.FortAthenaAILODComponent.OnRep_CurrentFortAILODLevel // (Final|Native|Private) // @ game+0x9696570
};

// Class FortniteAI.FortAthenaAIObjectTracker
// Size: 0xa8 (Inherited: 0x30)
struct UFortAthenaAIObjectTracker : UWorldSubsystem {
	char pad_30[0x28]; // 0x30(0x28)
	struct TMap<ClassPtrProperty, struct FAITrackedObjectsSet> TrackedObjects; // 0x58(0x50)

	struct FFortAthenaAIObjectTrackerQuery BP_MakeFullAthenaAIObjectTrackerQueryFromSimplified(struct FFortAthenaAIObjectTrackerQuerySimplified& SimplifiedQuery, struct AActor* OptionalQuerier); // Function FortniteAI.FortAthenaAIObjectTracker.BP_MakeFullAthenaAIObjectTrackerQueryFromSimplified // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x9698c20
};

// Class FortniteAI.FortAthenaAIRuntimeParametersProvider
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaAIRuntimeParametersProvider : UInterface {
};

// Class FortniteAI.FortAthenaAIRuntimeParametersComponent
// Size: 0x140 (Inherited: 0xa0)
struct UFortAthenaAIRuntimeParametersComponent : UActorComponent {
	struct TMap<struct UFortAthenaAIRuntimeParameters*, struct TScriptInterface<IFortAthenaAIRuntimeParametersProvider>> RegisteredParametersProviders; // 0xa0(0x50)
	struct TMap<ClassPtrProperty, struct UFortAthenaAIRuntimeParameters*> ExtractedRuntimeParameters; // 0xf0(0x50)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_SmartObjectBase
// Size: 0x100 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_SmartObjectBase : UFortAthenaAIRuntimeParameters {
	char bEnabled : 1; // 0x30(0x01)
	char bChooseClosestSmartObject : 1; // 0x30(0x01)
	char pad_30_2 : 6; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float UnreachableBanDuration; // 0x34(0x04)
	float SelectedSmartObjectExpirationDelay; // 0x38(0x04)
	float GlobalSmartObjectCooldownOnFinished; // 0x3c(0x04)
	float GlobalSmartObjectCooldownOnInterrupted; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct TArray<struct FAIRuntimeParametersSmartObjectActivity> SmartObjectActivities; // 0x48(0x10)
	struct TArray<struct FSmartObjectRecentlyUsed> SmartObjectsMostRecentlyUsed; // 0x58(0x10)
	struct TArray<struct FSmartObjectBanned> SmartObjectsBannedList; // 0x68(0x10)
	int32_t SelectedActivityID; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FSmartObjectRequestResult SelectedResult; // 0x80(0x18)
	struct FSmartObjectSlotEntranceHandle SelectedEntranceHandle; // 0x98(0x18)
	float LastSelectedSmartObjectTimestamp; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FSmartObjectClaimHandle ClaimedHandle; // 0xb8(0x20)
	struct UGameplayBehaviorConfig* BehaviorConfig; // 0xd8(0x08)
	struct UGameplayBehavior* GameplayBehavior; // 0xe0(0x08)
	struct UGameplayInteractionSmartObjectBehaviorDefinition* GameplayInteractionBehaviorDefinition; // 0xe8(0x08)
	float GlobalSmartObjectLastUseTimestamp; // 0xf0(0x04)
	float GlobalSmartObjectCooldown; // 0xf4(0x04)
	int32_t ActivitiesIDCount; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)

	void SetChooseClosestSmartObject(bool bInChooseClosestSmartObject); // Function FortniteAI.FortAthenaAIRuntimeParameters_SmartObjectBase.SetChooseClosestSmartObject // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x969c1c0
	bool GetChooseClosestSmartObject(); // Function FortniteAI.FortAthenaAIRuntimeParameters_SmartObjectBase.GetChooseClosestSmartObject // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969c190
};

// Class FortniteAI.FortAthenaAISmartObjectActivity
// Size: 0x158 (Inherited: 0x28)
struct UFortAthenaAISmartObjectActivity : UObject {
	struct FScalableFloat Enabled; // 0x28(0x28)
	struct FFortAthenaAISmartObjectActivityCondition SmartObjectActivityCondition; // 0x50(0x48)
	struct FFortAthenaAISmartObjectActivityConfig SmartObjectActivityConfig; // 0x98(0xc0)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponentList
// Size: 0x58 (Inherited: 0x28)
struct UFortAthenaAISpawnerDataComponentList : UObject {
	char pad_28[0x30]; // 0x28(0x30)

	struct UFortAthenaAISpawnerDataComponentList* OverrideComponentClass(struct UFortAthenaAISpawnerDataComponent* NewComponentSubClass); // Function FortniteAI.FortAthenaAISpawnerDataComponentList.OverrideComponentClass // (Final|Native|Public|BlueprintCallable) // @ game+0x969eb60
	struct UFortAthenaAISpawnerDataComponentList* OverrideComponent(struct UFortAthenaAISpawnerDataComponent* NewComponent); // Function FortniteAI.FortAthenaAISpawnerDataComponentList.OverrideComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x969eca0
	struct UFortAthenaAISpawnerDataComponent* GetOrCreateComponentClassForModification(struct UObject* ComponentOuter, struct UFortAthenaAISpawnerDataComponent* ClassToClone); // Function FortniteAI.FortAthenaAISpawnerDataComponentList.GetOrCreateComponentClassForModification // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969e9e0
	struct TArray<struct UFortAthenaAISpawnerDataComponent*> GetList(); // Function FortniteAI.FortAthenaAISpawnerDataComponentList.GetList // (Final|Native|Public|BlueprintCallable) // @ game+0x969f1e0
	struct APawn* GetDefaultPawn(); // Function FortniteAI.FortAthenaAISpawnerDataComponentList.GetDefaultPawn // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x969f2a0
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_AffiliationBase
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_AffiliationBase : UFortAthenaAIRuntimeParameters {
	char pad_30[0x4]; // 0x30(0x04)
	char bFullTeamAwarenessPropagation : 1; // 0x34(0x01)
	char bAwarenessPropagationIsBasedOnAlertLevel : 1; // 0x34(0x01)
	char bTurnHostileOnDamageIfNeutral : 1; // 0x34(0x01)
	char pad_34_3 : 5; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	float TurnHostileWhenBlockedTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase
// Size: 0xc0 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AffiliationBase : UFortAthenaAISpawnerDataComponent {
	struct FGameplayTagContainer FactionTags; // 0x30(0x20)
	struct FScalableFloat TurnHostileOnDamageIfNeutral; // 0x50(0x28)
	struct FScalableFloat TurnHostileWhenBlockedTime; // 0x78(0x28)
	struct TArray<struct FSpawnerDataComponentAffiliationSharedBBConfiguration> FactionSharedBBConfigurations; // 0xa0(0x10)
	char bFullTeamAwarenessPropagation : 1; // 0xb0(0x01)
	char bAwarenessPropagationIsBasedOnAlertLevel : 1; // 0xb0(0x01)
	char pad_B0_2 : 6; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	float FullTeamAwarenessMaxDistance; // 0xb4(0x04)
	bool bAddGameParticipantFactionAutomatically; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)

	void SetFullTeamAwarenessPropagationDistance(float InFullTeamAwarenessMaxDistance); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase.SetFullTeamAwarenessPropagationDistance // (Final|Native|Public|BlueprintCallable) // @ game+0x96a05f0
	void SetFullTeamAwarenessPropagation(bool bInFullTeamAwarenessPropagation); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase.SetFullTeamAwarenessPropagation // (Final|Native|Public|BlueprintCallable) // @ game+0x96a06e0
	void SetFactionTags(struct FGameplayTagContainer& NewTags); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase.SetFactionTags // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x96a0910
	void SetAwarenessPropagationIsBasedOnAlertLevel(bool bInAwarenessPropagationIsBasedOnAlertLevel); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase.SetAwarenessPropagationIsBasedOnAlertLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x96a07e0
	bool GetFullTeamAwarenessPropagation(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase.GetFullTeamAwarenessPropagation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7d8cd50
	float GetFullTeamAwarenessMaxDistance(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase.GetFullTeamAwarenessMaxDistance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x35c95e0
	struct FGameplayTagContainer GetFactionTag(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase.GetFactionTag // (Final|Native|Public|BlueprintCallable) // @ game+0x96a0a60
	bool GetAwarenessPropagationIsBasedOnAlertLevel(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AffiliationBase.GetAwarenessPropagationIsBasedOnAlertLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96a08e0
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Analytic
// Size: 0x50 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Analytic : UFortAthenaAIRuntimeParameters {
	struct FGameplayTagContainer OnDeathGameplayTags; // 0x30(0x20)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_AIAnalytic
// Size: 0x78 (Inherited: 0x50)
struct UFortAthenaAIRuntimeParameters_AIAnalytic : UFortAthenaAIRuntimeParameters_Analytic {
	struct FString AnalyticUniqueID; // 0x50(0x10)
	struct FString AIType; // 0x60(0x10)
	char bShouldSendSpawnEvents : 1; // 0x70(0x01)
	char bShouldRecordGrabbedPickups : 1; // 0x70(0x01)
	char bShouldRecordDroppedPickups : 1; // 0x70(0x01)
	char bShouldRecordDeathInstigator : 1; // 0x70(0x01)
	char bShouldRecordRegularDowns : 1; // 0x70(0x01)
	char bShouldRecordTetheredDowns : 1; // 0x70(0x01)
	char pad_70_6 : 2; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AnalyticBase
// Size: 0x60 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AnalyticBase : UFortAthenaAISpawnerDataComponent {
	struct FGameplayTagContainer OnDeathGameplayTags; // 0x30(0x20)
	char pad_50[0x10]; // 0x50(0x10)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIAnalytic
// Size: 0x160 (Inherited: 0x60)
struct UFortAthenaAISpawnerDataComponent_AIAnalytic : UFortAthenaAISpawnerDataComponent_AnalyticBase {
	struct FString AIType; // 0x60(0x10)
	struct FScalableFloat ShouldSendSpawnEvents; // 0x70(0x28)
	struct FScalableFloat ShouldRecordGrabbedPickups; // 0x98(0x28)
	struct FScalableFloat ShouldRecordDroppedPickups; // 0xc0(0x28)
	struct FScalableFloat ShouldRecordDeathInstigator; // 0xe8(0x28)
	struct FScalableFloat ShouldRecordRegularDowns; // 0x110(0x28)
	struct FScalableFloat ShouldRecordTetheredDowns; // 0x138(0x28)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Marker
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Marker : UFortAthenaAIRuntimeParameters {
	char bSupportsMarkerWithFaction : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float MarkerPropagationMaxDistanceSQ; // 0x34(0x04)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_AIBotDisguise
// Size: 0xd0 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_AIBotDisguise : UFortAthenaAIRuntimeParameters {
	bool bShouldApplyDisguise; // 0x30(0x01)
	bool bRevealDisguiseOnDamage; // 0x31(0x01)
	bool bRevealOnDamageExcludeAIPawnDamage; // 0x32(0x01)
	bool bRevealDisguiseOnPlayerProximity; // 0x33(0x01)
	float RevealPlayerProximityDistanceSqr; // 0x34(0x04)
	float RevealPlayerProximityMinDuration; // 0x38(0x04)
	float RevealPlayerProximityMaxDuration; // 0x3c(0x04)
	struct UFortBotNameSettings* NameSettingsAfterReveal; // 0x40(0x08)
	struct FGameplayTagContainer DisguisedFactionsBeforeReveal; // 0x48(0x20)
	struct FGameplayTagContainer DisguisedFactionsAfterReveal; // 0x68(0x20)
	struct TArray<struct UGameplayEffect*> DisguiseGameplayEffectBeforeReveal; // 0x88(0x10)
	struct TArray<struct UGameplayEffect*> DisguiseGameplayEffectAfterReveal; // 0x98(0x10)
	struct TArray<struct FItemAndCount> DisguiseInventory; // 0xa8(0x10)
	struct FDataTableRowHandle DisguiseLootInfo; // 0xb8(0x10)
	struct UFortNPCConversationParticipantComponent* DisguiseConversationComponentOverride; // 0xc8(0x08)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Collection
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Collection : UFortAthenaAIRuntimeParameters {
	bool bForceAddToCollectionOnDamage; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotAffiliation
// Size: 0x2c8 (Inherited: 0xc0)
struct UFortAthenaAISpawnerDataComponent_AIBotAffiliation : UFortAthenaAISpawnerDataComponent_AffiliationBase {
	bool bForceAddToCollectionOnDamage; // 0xc0(0x01)
	char bOverrideIsAnAthenaGameParticipant : 1; // 0xc1(0x01)
	char bIsAnAthenaGameParticipant : 1; // 0xc1(0x01)
	char pad_C1_2 : 6; // 0xc1(0x01)
	char pad_C2[0x6]; // 0xc2(0x06)
	struct FScalableFloat SupportsMarkerWithFaction; // 0xc8(0x28)
	struct FScalableFloat MarkerPropagationMaxDistance; // 0xf0(0x28)
	struct FScalableFloat DisguiseProbability; // 0x118(0x28)
	struct FScalableFloat RevealDisguiseOnDamage; // 0x140(0x28)
	struct FScalableFloat RevealOnDamageExcludeAIPawnDamage; // 0x168(0x28)
	struct FScalableFloat RevealDisguiseOnPlayerProximity; // 0x190(0x28)
	struct FScalableFloat RevealPlayerProximityDistance; // 0x1b8(0x28)
	struct FScalableFloat RevealPlayerProximityMinDuration; // 0x1e0(0x28)
	struct FScalableFloat RevealPlayerProximityMaxDuration; // 0x208(0x28)
	struct UFortBotNameSettings* NameSettingsAfterReveal; // 0x230(0x08)
	struct FGameplayTagContainer DisguisedFactionsBeforeReveal; // 0x238(0x20)
	struct FGameplayTagContainer DisguisedFactionsAfterReveal; // 0x258(0x20)
	struct TArray<struct UGameplayEffect*> DisguiseGameplayEffectBeforeReveal; // 0x278(0x10)
	struct TArray<struct UGameplayEffect*> DisguiseGameplayEffectAfterReveal; // 0x288(0x10)
	struct TArray<struct FItemAndCount> DisguiseInventory; // 0x298(0x10)
	struct FDataTableRowHandle DisguiseLootInfo; // 0x2a8(0x10)
	struct UFortNPCConversationParticipantComponent* DisguiseConversationComponent; // 0x2b8(0x08)
	int32_t OverrideTeamIndex; // 0x2c0(0x04)
	char pad_2C4[0x4]; // 0x2c4(0x04)

	void SetOverrideTeamIndex(int32_t InOverrideTeamIdx); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotAffiliation.SetOverrideTeamIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x96a2980
	bool GetTeamID(int32_t& OutTeamId); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotAffiliation.GetTeamID // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96a2a70
	bool GetSquadID(int32_t& OutSquadId); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotAffiliation.GetSquadID // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96a2b70
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotAnalytic
// Size: 0x98 (Inherited: 0x60)
struct UFortAthenaAISpawnerDataComponent_AIBotAnalytic : UFortAthenaAISpawnerDataComponent_AnalyticBase {
	char bUseDescriptorTagSuffix : 1; // 0x60(0x01)
	char pad_60_1 : 7; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct FString BotIDSuffix; // 0x68(0x10)
	struct TArray<struct FScalableFloat> IdleDetectionBucketsCutoffs; // 0x78(0x10)
	struct TArray<struct FScalableFloat> DamageDistanceBuckets; // 0x88(0x10)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_BehaviorTreeControl
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_BehaviorTreeControl : UFortAthenaAIRuntimeParameters {
	uint32_t BehaviorTreeControls; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)

	bool IsBehaviorTreeBranchActive(enum class EBehaviorTreeBranches Behavior); // Function FortniteAI.FortAthenaAIRuntimeParameters_BehaviorTreeControl.IsBehaviorTreeBranchActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96b4640
	void EnableBehaviorTreeBranch(enum class EBehaviorTreeBranches Behavior); // Function FortniteAI.FortAthenaAIRuntimeParameters_BehaviorTreeControl.EnableBehaviorTreeBranch // (Final|Native|Public|BlueprintCallable) // @ game+0x96b4550
	void DisableBehaviorTreeBranch(enum class EBehaviorTreeBranches Behavior); // Function FortniteAI.FortAthenaAIRuntimeParameters_BehaviorTreeControl.DisableBehaviorTreeBranch // (Final|Native|Public|BlueprintCallable) // @ game+0x96b4460
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_ReviveBehavior
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_ReviveBehavior : UFortAthenaAIRuntimeParameters {
	char bAllowReviveSquadmates : 1; // 0x30(0x01)
	char bAllowReviveSameFactionNPCs : 1; // 0x30(0x01)
	char bAllowReviveConverter : 1; // 0x30(0x01)
	char bAllowReviveConverterSquadmates : 1; // 0x30(0x01)
	char bUseReviveToken : 1; // 0x30(0x01)
	char pad_30_5 : 3; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float MaxDistanceToRevive; // 0x34(0x04)
	float MaxDistanceToReviveHumanPlayer; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_DBNOBehavior
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_DBNOBehavior : UFortAthenaAIRuntimeParameters {
	char bDieWhenAllAlliesAreDBNO : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float AliveAlliesMaxRangeSqr; // 0x34(0x04)
	float SecondsBeforeAutomaticReviveFromDBNOWhenOutOfCombat; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_NPCBehavior
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_NPCBehavior : UFortAthenaAIRuntimeParameters {
	char bSupportsHolsteredWeapon : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Behavior
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Behavior : UFortAthenaAIRuntimeParameters {
	char bSurfaceTypeCheckEnabled : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotBehavior
// Size: 0x278 (Inherited: 0x38)
struct UFortAthenaAISpawnerDataComponent_AIBotBehavior : UFortAthenaAISpawnerDataComponent_Behavior {
	uint32_t BehaviorTreeControls; // 0x38(0x04)
	char bCanUseFallbackPatrolAround : 1; // 0x3c(0x01)
	char bAllowReviveSquadmates : 1; // 0x3c(0x01)
	char bAllowReviveSameFactionNPCs : 1; // 0x3c(0x01)
	char pad_3C_3 : 5; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct FScalableFloat AllowReviveConverter; // 0x40(0x28)
	struct FScalableFloat AllowReviveConverterSquadmates; // 0x68(0x28)
	char bUseReviveToken : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FScalableFloat MaxDistanceToRevive; // 0x98(0x28)
	struct FScalableFloat MaxDistanceToReviveHumanPlayer; // 0xc0(0x28)
	struct FScalableFloat DieWhenAllAlliesAreDBNO; // 0xe8(0x28)
	struct FScalableFloat AliveAlliesMaxRange; // 0x110(0x28)
	struct FScalableFloat SecondsBeforeAutomaticReviveFromDBNOWhenOutOfCombat; // 0x138(0x28)
	struct FScalableFloat SupportsHolsteredWeapon; // 0x160(0x28)
	struct FScalableFloat SurfaceTypeCheckEnabled; // 0x188(0x28)
	struct FScalableFloat bShouldResetAggressivePlayStyleOnUnaware; // 0x1b0(0x28)
	struct FScalableFloat TimeToKeepTrackOfDamagingActorsForAggressivePlayStyle; // 0x1d8(0x28)
	struct FScalableFloat TimeToIgnoreDamagingActorsWhenBeingControlled; // 0x200(0x28)
	struct FScalableFloat PauseBehaviorOnSpawnDuration; // 0x228(0x28)
	struct FScalableFloat bShouldBeInvulnerableDuringPause; // 0x250(0x28)

	bool IsBehaviorTreeBranchActive(enum class EBehaviorTreeBranches Behavior); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotBehavior.IsBehaviorTreeBranchActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96b4b10
	void EnableBehaviorTreeBranch(enum class EBehaviorTreeBranches Behavior); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotBehavior.EnableBehaviorTreeBranch // (Final|Native|Public|BlueprintCallable) // @ game+0x96b4a20
	void DisableBehaviorTreeBranch(enum class EBehaviorTreeBranches Behavior); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotBehavior.DisableBehaviorTreeBranch // (Final|Native|Public|BlueprintCallable) // @ game+0x96b4930
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotChanceEncounter
// Size: 0x60 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIBotChanceEncounter : UFortAthenaAISpawnerDataComponent_ChanceEncounterBase {
	struct FScalableFloat PassiveHealerEnable; // 0x30(0x28)
	struct UFortPawnComponent_PassiveHealer* PassiveHealerComponentClass; // 0x58(0x08)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_AIBotLoopSettings
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_AIBotLoopSettings : UFortAthenaAIRuntimeParameters {
	char bSpawnOutsideTheLoop : 1; // 0x30(0x01)
	char bRespawnOustideTheLoop : 1; // 0x30(0x01)
	char bRemoveInvulnerabilityOutsideSafeZone : 1; // 0x30(0x01)
	char bDisableSpecialActorComponentUntilRespawn : 1; // 0x30(0x01)
	char pad_30_4 : 4; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Conversation
// Size: 0x60 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Conversation : UFortAthenaAIRuntimeParameters {
	char bEnterBTTaskConversationIfPlayerAround : 1; // 0x30(0x01)
	char bCanConverseWhenConverted : 1; // 0x30(0x01)
	char pad_30_2 : 6; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float EnterBTTaskConversationIfPlayerAroundDistSqr; // 0x34(0x04)
	float WaitTimeWhileNotInConversationState; // 0x38(0x04)
	float SecondsToDenyActorToWaitForConversation; // 0x3c(0x04)
	struct TArray<struct UAthenaDanceItemDefinition*> GreetingEmotes; // 0x40(0x10)
	float GreetingEmoteMaxDuration; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct UFortTandemCharacterData* CharacterData; // 0x58(0x08)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotConversation
// Size: 0x240 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIBotConversation : UFortAthenaAISpawnerDataComponent_ConversationBase {
	struct UFortNPCConversationParticipantComponent* ConversationComponentClass; // 0x30(0x08)
	struct FGameplayTag ConversationEntryTag; // 0x38(0x04)
	struct FGameplayTag InteractorParticipantTag; // 0x3c(0x04)
	struct FGameplayTag SelfParticipantTag; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FScalableFloat EnterBTTaskConversationIfPlayerAround; // 0x48(0x28)
	struct FScalableFloat EnterBTTaskConversationIfPlayerAroundDist; // 0x70(0x28)
	struct FScalableFloat WaitTimeWhileNotInConversationState; // 0x98(0x28)
	struct FScalableFloat SecondsToDenyActorToWaitForConversation; // 0xc0(0x28)
	struct TArray<struct UAthenaDanceItemDefinition*> GreetingEmotes; // 0xe8(0x10)
	struct FScalableFloat GreetingEmoteMaxDuration; // 0xf8(0x28)
	struct UFortTandemCharacterData* CharacterData; // 0x120(0x08)
	struct FName ConversationInteractionCollisionProfile; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
	struct FVector ConversationInteractionBoxExtent; // 0x130(0x18)
	struct FVector ConversationInteractionBoxOffset; // 0x148(0x18)
	struct FScalableFloat SpawnOutOfTheLoop; // 0x160(0x28)
	struct FScalableFloat RespawnOutsideTheLoop; // 0x188(0x28)
	struct FScalableFloat RemoveInvulnerabilityOutsideSafeZone; // 0x1b0(0x28)
	struct UFortAthenaNPCLoopStateComponent* NPCLoopStateComponentClass; // 0x1d8(0x08)
	struct FScalableFloat UseSpecialActorComponent; // 0x1e0(0x28)
	struct UAthenaSpecialActorComponent* SpecialActorComponentClass; // 0x208(0x08)
	struct FScalableFloat BlockSpecialActorUntilOutsideTheLoop; // 0x210(0x28)
	bool bCanConverseWhenConverted; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_CosmeticBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_CosmeticBase : UFortAthenaAISpawnerDataComponent {

	void GetFallbackTag(struct FGameplayTag& OutFallbackTag); // Function FortniteAI.FortAthenaAISpawnerDataComponent_CosmeticBase.GetFallbackTag // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x96bea70
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotCosmeticBase
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIBotCosmeticBase : UFortAthenaAISpawnerDataComponent_CosmeticBase {
	struct TArray<struct UAthenaCosmeticItemDefinition*> CosmeticOverrideList; // 0x30(0x10)

	void GetLoadout(struct FFortAthenaLoadout& OutLoadout); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotCosmeticBase.GetLoadout // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x96b6f40
	void GetDances(struct TArray<struct UAthenaDanceItemDefinition*>& Dances, struct AFortAthenaAIBotController* BotController); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotCosmeticBase.GetDances // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x96b6b10
	void GetCustomCharacterParts(struct TArray<struct UCustomCharacterPart*>& OutCustomCharacterParts); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotCosmeticBase.GetCustomCharacterParts // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x96b6ce0
	void GetAnimBPOverride(struct UAnimInstance*& OutAnimBPOverride, int32_t& OutPriority); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotCosmeticBase.GetAnimBPOverride // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x96b6980
	void GetAllLoadouts(struct TArray<struct FFortAthenaLoadout>& OutLoadouts); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotCosmeticBase.GetAllLoadouts // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x96b6e00
	void AddCosmeticOverrideItemDef(struct UAthenaCosmeticItemDefinition* InCosmeticItemToPreview); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotCosmeticBase.AddCosmeticOverrideItemDef // (Final|Native|Public|BlueprintCallable) // @ game+0x96b6840
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotDebug
// Size: 0x1f0 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIBotDebug : UFortAthenaAISpawnerDataComponent_DebugBase {
	struct FDebugMinimapData DebugMinimapData; // 0x30(0x1b0)
	struct TArray<struct FString> EditorConsoleCommands; // 0x1e0(0x10)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_AIConvert
// Size: 0x110 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_AIConvert : UFortAthenaAIRuntimeParameters {
	bool bCanBeConverted; // 0x30(0x01)
	bool bCanBeConvertedFromDBNO; // 0x31(0x01)
	bool bForceKillWhenUnconverted; // 0x32(0x01)
	bool bForceKillWhenConverterDies; // 0x33(0x01)
	bool bCopyConverterSpecificRelations; // 0x34(0x01)
	bool bRemoveFromAllFactions; // 0x35(0x01)
	bool bAddConverterFactions; // 0x36(0x01)
	char pad_37[0x1]; // 0x37(0x01)
	float ReleaseDistanceSq; // 0x38(0x04)
	float CheckReleaseConditionsTimeInterval; // 0x3c(0x04)
	struct FGameplayTagContainer AddToFactions; // 0x40(0x20)
	struct FGameplayTagContainer RemoveFromFactions; // 0x60(0x20)
	char PreConversionTeamIndex; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FGameplayTagContainer PreConversionFactions; // 0x88(0x20)
	struct TArray<struct UFortAbilitySet*> AbilitySetsForConverted; // 0xa8(0x10)
	struct FTeleportSettings TeleportSettings; // 0xb8(0x38)
	bool bEnableDBNO; // 0xf0(0x01)
	enum class TInteractionType DBNOInteractionType; // 0xf1(0x01)
	char pad_F2[0x2]; // 0xf2(0x02)
	float DBNOInteractionDuration; // 0xf4(0x04)
	struct TArray<struct FPickupTagConvertInfo> PickupTagConvertInfos; // 0xf8(0x10)
	struct FGameplayTag ConvertIdentifierTag; // 0x108(0x04)
	char pad_10C[0x4]; // 0x10c(0x04)

	void SetForceKillWhenUnconverted(bool bInForceKillWhenUnconverted); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.SetForceKillWhenUnconverted // (Final|Native|Public|BlueprintCallable) // @ game+0x96c1060
	void SetForceKillWhenConverterDies(bool bInForceKillWhenConverterDies); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.SetForceKillWhenConverterDies // (Final|Native|Public|BlueprintCallable) // @ game+0x96c0f50
	void SetCanBeConvertedFromDBNO(bool bInCanBeConvertedFromDBNO); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.SetCanBeConvertedFromDBNO // (Final|Native|Public|BlueprintCallable) // @ game+0x96c1170
	void SetCanBeConverted(bool bInCanBeConverted); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.SetCanBeConverted // (Final|Native|Public|BlueprintCallable) // @ game+0x84057d0
	struct TArray<struct FPickupTagConvertInfo> GetPickupTagConvertInfos(); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.GetPickupTagConvertInfos // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96c0f20
	bool GetForceKillWhenUnconverted(); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.GetForceKillWhenUnconverted // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96c1150
	bool GetForceKillWhenConverterDies(); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.GetForceKillWhenConverterDies // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96c1040
	bool GetCanBeConvertedFromDBNO(); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.GetCanBeConvertedFromDBNO // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96c1260
	bool GetCanBeConverted(); // Function FortniteAI.FortAthenaAIRuntimeParameters_AIConvert.GetCanBeConverted // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x84057b0
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_AIBotConvert
// Size: 0x1b8 (Inherited: 0x110)
struct UFortAthenaAIRuntimeParameters_AIBotConvert : UFortAthenaAIRuntimeParameters_AIConvert {
	char bShouldLeashFollowConverter : 1; // 0x110(0x01)
	char bShouldScanAroundWhenWaiting : 1; // 0x110(0x01)
	char bFollowingBehaviorEnabled : 1; // 0x110(0x01)
	char bFollowerCanUseDBNO : 1; // 0x110(0x01)
	char bMimicBehaviorEnabled : 1; // 0x110(0x01)
	char bShouldTeleportTowardsConverter : 1; // 0x110(0x01)
	char bCanDanceWithConverter : 1; // 0x110(0x01)
	char bTargetPawnConverterDamaged : 1; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	float SkillLevelOverride; // 0x114(0x04)
	float PreConversionSkillLevel; // 0x118(0x04)
	float InnerLeashRadius; // 0x11c(0x04)
	float OuterLeashRadius; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
	struct UFortAthenaAIRuntimeParameters_Leash* PreConversionLeashParams; // 0x128(0x08)
	float LeashFollowActorUpdateRate; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct FVector LeashFollowActorLocalOffset; // 0x138(0x18)
	float FollowingBehaviorRadiusSqr; // 0x150(0x04)
	float FollowingBehaviorRadius; // 0x154(0x04)
	float FollowingBehaviorUrgenceRadiusSqr; // 0x158(0x04)
	float FollowingBehaviorUrgenceRadius; // 0x15c(0x04)
	float FollowingBehaviorBlockedSightAngleRad; // 0x160(0x04)
	float FollowingBehaviorBlockedSightExitAngleRad; // 0x164(0x04)
	float FollowingBehaviorBlockedSightExitDistMin; // 0x168(0x04)
	float MimicBehaviorRadiusSqr; // 0x16c(0x04)
	float MimicBehaviorRadius; // 0x170(0x04)
	float TeleportTowardsConverterDistanceSq; // 0x174(0x04)
	float TeleportTowardsConverterInCombatDistanceSq; // 0x178(0x04)
	float MinDistanceFromConverterWhenTeleported; // 0x17c(0x04)
	float MaxDistanceFromConverterWhenTeleported; // 0x180(0x04)
	char pad_184[0x4]; // 0x184(0x04)
	struct TArray<struct UFortAthenaAIBotSkillSet*> ConvertedSkillSetClasses; // 0x188(0x10)
	struct TArray<struct UFortAthenaAIBotSkillSet*> PreConversionSkillSetClasses; // 0x198(0x10)
	char pad_1A8[0x10]; // 0x1a8(0x10)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Leash
// Size: 0xb0 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Leash : UFortAthenaAIRuntimeParameters {
	struct FVector LeashLocation; // 0x30(0x18)
	float LeashInnerRadius; // 0x48(0x04)
	float LeashOuterRadius; // 0x4c(0x04)
	float LeashTeleportRadius; // 0x50(0x04)
	bool bCheckForReachabilityOnRandomLocationGeneration; // 0x54(0x01)
	enum class ELeashReturnLocationMode LeashReturnLocationMode; // 0x55(0x01)
	char pad_56[0x2]; // 0x56(0x02)
	struct FLeashInfoOverride DefaultLeashInfo; // 0x58(0x08)
	struct TMap<enum class EAlertLevel, struct FLeashInfoOverride> AlertLevelLeashOverride; // 0x60(0x50)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_AIBotRespawn
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_AIBotRespawn : UFortAthenaAIRuntimeParameters {
	char bCanRespawnOnDeath : 1; // 0x30(0x01)
	char bRespawnOnDeathLocation : 1; // 0x30(0x01)
	char pad_30_2 : 6; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float RespawnTime; // 0x34(0x04)
	struct UFortAthenaAISpawnerDataComponentList* AISpawnerDataComponentList; // 0x38(0x08)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_GameplayBase
// Size: 0x2f0 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_GameplayBase : UFortAthenaAISpawnerDataComponent {
	bool bOverrideGlobalSpeedMultiplier; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FScalableFloat GlobalSpeedMultiplier; // 0x38(0x28)
	struct FScalableFloat CanBeConverted; // 0x60(0x28)
	struct FScalableFloat CanBeConvertedFromDBNO; // 0x88(0x28)
	struct FScalableFloat ForceKillWhenUnconverted; // 0xb0(0x28)
	struct FScalableFloat ForceKillWhenConverterDies; // 0xd8(0x28)
	struct FScalableFloat CopyConverterSpecificRelations; // 0x100(0x28)
	struct FScalableFloat RemoveFromAllFactions; // 0x128(0x28)
	struct FScalableFloat AddConverterFactions; // 0x150(0x28)
	struct FScalableFloat ReleaseDistance; // 0x178(0x28)
	struct FScalableFloat CheckReleaseConditionsTimeInterval; // 0x1a0(0x28)
	struct FGameplayTagContainer AddToFactions; // 0x1c8(0x20)
	struct FGameplayTagContainer RemoveFromFactions; // 0x1e8(0x20)
	struct FScalableFloat PawnCullDistance; // 0x208(0x28)
	struct TArray<struct UFortAbilitySet*> AbilitySetsForConverted; // 0x230(0x10)
	struct FTeleportSettings TeleportSettings; // 0x240(0x38)
	bool bApplyTaggedNavFilters; // 0x278(0x01)
	char pad_279[0x7]; // 0x279(0x07)
	struct FFortAITaggedNavFilterData NavFilterData; // 0x280(0x60)
	bool bEnableDBNO; // 0x2e0(0x01)
	enum class TInteractionType DBNOInteractionType; // 0x2e1(0x01)
	char pad_2E2[0x2]; // 0x2e2(0x02)
	float DBNOInteractionDuration; // 0x2e4(0x04)
	bool bOnlyLeaderInteraction; // 0x2e8(0x01)
	char pad_2E9[0x3]; // 0x2e9(0x03)
	struct FGameplayTag ConvertIdentifierTag; // 0x2ec(0x04)

	bool ShouldOverrideGlobalSpeedMultiplier(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayBase.ShouldOverrideGlobalSpeedMultiplier // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3c5c970
	void SetCopyConverterSpecificRelations(bool bInCopyConverterSpecificRelations); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayBase.SetCopyConverterSpecificRelations // (Final|Native|Public|BlueprintCallable) // @ game+0x96c1690
	void SetCanBeConverted(bool bInCanBeConverted); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayBase.SetCanBeConverted // (Final|Native|Public|BlueprintCallable) // @ game+0x96c17b0
	void PostOnSpawnedBP(struct APawn* PawnAI); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayBase.PostOnSpawnedBP // (Event|Public|BlueprintEvent|Const) // @ game+0x1b027f0
	float GetGlobalSpeedMultiplier(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayBase.GetGlobalSpeedMultiplier // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c18d0
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotGameplay
// Size: 0x7d8 (Inherited: 0x2f0)
struct UFortAthenaAISpawnerDataComponent_AIBotGameplay : UFortAthenaAISpawnerDataComponent_GameplayBase {
	struct UFortBotNameSettings* NameSettings; // 0x2f0(0x08)
	char bRequiresUniqueNetId : 1; // 0x2f8(0x01)
	char pad_2F8_1 : 7; // 0x2f8(0x01)
	char pad_2F9[0x7]; // 0x2f9(0x07)
	struct FScalableFloat CanRespawnOnDeath; // 0x300(0x28)
	struct FScalableFloat RespawnOnDeathLocation; // 0x328(0x28)
	struct FScalableFloat RespawnTime; // 0x350(0x28)
	float PawnCullDistanceAfterPlayerAggroMode; // 0x378(0x04)
	enum class EReachLocationValidationMode ReachLocationValidationMode; // 0x37c(0x01)
	char pad_37D[0x3]; // 0x37d(0x03)
	struct FVector LeashLocation; // 0x380(0x18)
	float LeashInnerRadius; // 0x398(0x04)
	float LeashOuterRadius; // 0x39c(0x04)
	struct FScalableFloat LeashTeleportRadius; // 0x3a0(0x28)
	bool bCheckForReachabilityOnRandomLocationGeneration; // 0x3c8(0x01)
	enum class ELeashReturnLocationMode LeashReturnLocationMode; // 0x3c9(0x01)
	char pad_3CA[0x6]; // 0x3ca(0x06)
	struct TMap<enum class EAlertLevel, struct FLeashInfoOverride> AlertLevelLeashOverride; // 0x3d0(0x50)
	struct AFortAthenaPatrolPath* AssociatedPatrolPath; // 0x420(0x08)
	bool bCanInvestigateWithMeleeWeapon; // 0x428(0x01)
	bool bApplyMutatorsHealthAndShieldModifiers; // 0x429(0x01)
	bool bSupportsTethering; // 0x42a(0x01)
	bool bEnableRenderCustomDepth; // 0x42b(0x01)
	bool bDisableGiveWeaponCheat; // 0x42c(0x01)
	bool bDisableGiveMaterialsCheat; // 0x42d(0x01)
	char pad_42E[0x2]; // 0x42e(0x02)
	struct FScalableFloat InnerLeashRadius; // 0x430(0x28)
	struct FScalableFloat OuterLeashRadius; // 0x458(0x28)
	struct FScalableFloat ShouldLeashFollowConverter; // 0x480(0x28)
	struct FScalableFloat LeashFollowActorUpdateRate; // 0x4a8(0x28)
	struct FVector LeashFollowActorLocalOffset; // 0x4d0(0x18)
	struct FScalableFloat SkillLevelOverride; // 0x4e8(0x28)
	struct FScalableFloat ShouldScanAroundWhenWaiting; // 0x510(0x28)
	struct FScalableFloat ShouldTeleportTowardsConverter; // 0x538(0x28)
	struct FScalableFloat FollowingBehaviorEnabled; // 0x560(0x28)
	struct FScalableFloat FollowerCanUseDBNO; // 0x588(0x28)
	struct FScalableFloat FollowingBehaviorRadius; // 0x5b0(0x28)
	struct FScalableFloat FollowingBehaviorUrgenceRadius; // 0x5d8(0x28)
	struct FScalableFloat FollowingBehaviorBlockedSightAngle; // 0x600(0x28)
	struct FScalableFloat FollowingBehaviorBlockedSightExitAngle; // 0x628(0x28)
	struct FScalableFloat FollowingBehaviorBlockedSightExitDistMin; // 0x650(0x28)
	struct FScalableFloat MimicBehaviorEnabled; // 0x678(0x28)
	struct FScalableFloat MimicBehaviorRadius; // 0x6a0(0x28)
	struct FScalableFloat CanDanceWithConverter; // 0x6c8(0x28)
	struct FScalableFloat TeleportTowardsConverterDistance; // 0x6f0(0x28)
	struct FScalableFloat TeleportTowardsConverterInCombatDistance; // 0x718(0x28)
	struct FScalableFloat MinDistanceFromConverterWhenTeleported; // 0x740(0x28)
	struct FScalableFloat MaxDistanceFromConverterWhenTeleported; // 0x768(0x28)
	struct TArray<struct UFortAthenaAIBotSkillSet*> ConvertedSkillSetClasses; // 0x790(0x10)
	struct UFortPawnComponent_AIBotPingCommand* PingCommandComponentClass; // 0x7a0(0x08)
	struct FScalableFloat TargetPawnConverterDamaged; // 0x7a8(0x28)
	char pad_7D0[0x8]; // 0x7d0(0x08)

	void SetNameSettings(enum class EBotNamingMode InNamingMode, struct FString InName, bool bInAddPlayerIDSuffix); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotGameplay.SetNameSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x96b8d10
	void SetLeashOuterRadius(float InLeashOuterRadius); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotGameplay.SetLeashOuterRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x96b8b30
	void SetLeashLocation(struct FVector InLeashLocation); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotGameplay.SetLeashLocation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x96b8c20
	void SetLeashInnerRadius(float InLeashInnerRadius); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotGameplay.SetLeashInnerRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x96b8a40
	void SetAssociatedPatrolPath(struct AFortAthenaPatrolPath* InAssociatedPatrolPath); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotGameplay.SetAssociatedPatrolPath // (Final|Native|Public|BlueprintCallable) // @ game+0x96b8950
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_GameplayAbilityBase
// Size: 0x70 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_GameplayAbilityBase : UFortAthenaAISpawnerDataComponent {
	struct TArray<struct FInitialGameplayEffectInfo> InitialGameplayEffect; // 0x30(0x10)
	struct TArray<struct UFortAbilitySet*> InitialGameplayAbilitiesSet; // 0x40(0x10)
	struct FGameplayTagContainer LooseTagsToApplyToPawn; // 0x50(0x20)

	void SetLooseTagsToApplyToPawn(struct FGameplayTagContainer& InGameplayTagContainer); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayAbilityBase.SetLooseTagsToApplyToPawn // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x96bfe80
	struct FGameplayTagContainer GetLooseTagsToApplyToPawn(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayAbilityBase.GetLooseTagsToApplyToPawn // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bffd0
	void GetInitialGameplayEffects(struct TArray<struct FInitialGameplayEffectInfo>& OutGEs); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayAbilityBase.GetInitialGameplayEffects // (Native|Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96bfd60
	void GetInitialGameplayAbilities(struct TArray<struct UFortAbilitySet*>& OutGASets); // Function FortniteAI.FortAthenaAISpawnerDataComponent_GameplayAbilityBase.GetInitialGameplayAbilities // (Native|Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96bfc40
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotGameplayAbilityBase
// Size: 0x70 (Inherited: 0x70)
struct UFortAthenaAISpawnerDataComponent_AIBotGameplayAbilityBase : UFortAthenaAISpawnerDataComponent_GameplayAbilityBase {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_InventoryBase
// Size: 0xb0 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_InventoryBase : UFortAthenaAISpawnerDataComponent {
	struct TArray<struct FItemAndCount> Items; // 0x30(0x10)
	struct FScalableFloat ShouldDropCurrencyOnDeath; // 0x40(0x28)
	struct FScalableFloat DefaultInventoryIgnoresRestrictions; // 0x68(0x28)
	struct FName CurrencyPayoutRowName; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FDataTableRowHandle LootInfo; // 0x98(0x10)
	bool bDeathTagsCanBlockLootDrop; // 0xa8(0x01)
	bool bUseDefenderInventoryManagement; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)

	void SetInventoryItems(struct TArray<struct FItemAndCount>& InItems); // Function FortniteAI.FortAthenaAISpawnerDataComponent_InventoryBase.SetInventoryItems // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x96bfd60
	void GetInventoryItems(struct TArray<struct FItemAndCount>& OutList); // Function FortniteAI.FortAthenaAISpawnerDataComponent_InventoryBase.GetInventoryItems // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x96bfc40
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotInventory
// Size: 0xc8 (Inherited: 0xb0)
struct UFortAthenaAISpawnerDataComponent_AIBotInventory : UFortAthenaAISpawnerDataComponent_InventoryBase {
	char bItemsToGiveInEditorWhenCustomizationIsEnabled : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct TArray<struct FItemAndCount> EditorOnlyItems; // 0xb8(0x10)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_PerceptionBase
// Size: 0x90 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_PerceptionBase : UFortAthenaAISpawnerDataComponent {
	bool bOverrideVisibilityRange; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FGameplayTagContainer OverrideVisibilityRangeConditionTag; // 0x38(0x20)
	float SightRadius; // 0x58(0x04)
	float LoseSightRadius; // 0x5c(0x04)
	bool bRestrictSightOverrideToUnaware; // 0x60(0x01)
	bool bOverrideHearingRange; // 0x61(0x01)
	char pad_62[0x6]; // 0x62(0x06)
	struct FGameplayTagContainer OverrideHearingRangeConditionTag; // 0x68(0x20)
	float HearingRadius; // 0x88(0x04)
	bool bRestrictHearingOverrideToUnaware; // 0x8c(0x01)
	char pad_8D[0x3]; // 0x8d(0x03)

	void SetVisibilityRange(float InSightRadius, float LoseSightRadius, bool bInRestrictOverrideToUnaware); // Function FortniteAI.FortAthenaAISpawnerDataComponent_PerceptionBase.SetVisibilityRange // (Final|Native|Public|BlueprintCallable) // @ game+0x96c3d80
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotPerception
// Size: 0x90 (Inherited: 0x90)
struct UFortAthenaAISpawnerDataComponent_AIBotPerception : UFortAthenaAISpawnerDataComponent_PerceptionBase {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_SkillsetBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_SkillsetBase : UFortAthenaAISpawnerDataComponent {

	bool ShouldUseMatchMMRToOverrideSkillLevel(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SkillsetBase.ShouldUseMatchMMRToOverrideSkillLevel // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3c5c970
	struct TArray<struct UFortAthenaAIBotSkillSet*> GetSkillSets(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SkillsetBase.GetSkillSets // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x96c4b90
	float GetSkill(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SkillsetBase.GetSkill // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x96c4c60
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIBotSkillset
// Size: 0x118 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIBotSkillset : UFortAthenaAISpawnerDataComponent_SkillsetBase {
	struct UFortAthenaAIBotAimingSkillSet* AimingSkillSet; // 0x30(0x08)
	struct UFortAthenaAIBotAttackingSkillSet* AttackingSkillSet; // 0x38(0x08)
	struct UFortAthenaAIBotBuildingSkillSet* BuildingSkillSet; // 0x40(0x08)
	struct UFortAthenaAIBotDBNOSkillSet* DBNOSkillSet; // 0x48(0x08)
	struct UFortAthenaAIBotEmoteSkillSet* EmoteSkillSet; // 0x50(0x08)
	struct UFortAthenaAIBotEvasiveManeuversSkillSet* EvasiveManeuversSkillSet; // 0x58(0x08)
	struct UFortAthenaAIBotHarvestSkillSet* HarvestSkillSet; // 0x60(0x08)
	struct UFortAthenaAIBotHealingSkillSet* HealingSkillSet; // 0x68(0x08)
	struct UFortAthenaAIBotInventorySkillSet* InventorySkillSet; // 0x70(0x08)
	struct UFortAthenaAIBotLootingSkillSet* LootingSkillSet; // 0x78(0x08)
	struct UFortAthenaAIBotMovementSkillSet* MovementSkillSet; // 0x80(0x08)
	struct UFortAthenaAIBotPerceptionSkillSet* PerceptionSkillSet; // 0x88(0x08)
	struct UFortAthenaAIBotPlayStyleSkillSet* PlayStyleSkillSet; // 0x90(0x08)
	struct UFortAthenaAIBotPropagateAwarenessSkillSet* PropagateAwarenessSkillSet; // 0x98(0x08)
	struct UFortAthenaAIBotRangeAttackSkillSet* RangeAttackSkillSet; // 0xa0(0x08)
	struct UFortAthenaAIBotReviveSkillSet* ReviveSkillSet; // 0xa8(0x08)
	struct UFortAthenaAIBotUnstuckSkillSet* UnstuckSkillSet; // 0xb0(0x08)
	struct UFortAthenaAIBotVehicleSkillSet* VehicleSkillSet; // 0xb8(0x08)
	char bUseMatchMMRToOverrideSkillLevel : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct TSoftObjectPtr<UDataTable> OverrideSkillLevelMMRTable; // 0xc8(0x20)
	struct FScalableFloat Skill; // 0xe8(0x28)
	float SkillOverride; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)

	void SetSkill(float InSKill); // Function FortniteAI.FortAthenaAISpawnerDataComponent_AIBotSkillset.SetSkill // (Final|Native|Public|BlueprintCallable) // @ game+0x96bb770
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_PlayerBotSkillset
// Size: 0x120 (Inherited: 0x118)
struct UFortAthenaAISpawnerDataComponent_PlayerBotSkillset : UFortAthenaAISpawnerDataComponent_AIBotSkillset {
	struct UFortAthenaAIBotWarmupSkillSet* WarmUpSkillSet; // 0x118(0x08)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIGameplay
// Size: 0x340 (Inherited: 0x2f0)
struct UFortAthenaAISpawnerDataComponent_AIGameplay : UFortAthenaAISpawnerDataComponent_GameplayBase {
	float MoveSoundStimulusBroadcastInterval; // 0x2f0(0x04)
	float MaxMoveSoundRange; // 0x2f4(0x04)
	char bGenerateSoundInAllMovementModes : 1; // 0x2f8(0x01)
	char pad_2F8_1 : 7; // 0x2f8(0x01)
	char pad_2F9[0x7]; // 0x2f9(0x07)
	struct FScalableFloat DefaultLifespanAfterDeath; // 0x300(0x28)
	enum class EFortAthenaAISpawnerDataComponentTriBool IsAlwaysGameplayRelevantOverride; // 0x328(0x01)
	char pad_329[0x7]; // 0x329(0x07)
	struct TArray<struct FPickupTagConvertInfo> PickupTagConvertInfos; // 0x330(0x10)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIPawnCosmeticBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIPawnCosmeticBase : UFortAthenaAISpawnerDataComponent_CosmeticBase {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIPawnCosmeticCustomization
// Size: 0x48 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIPawnCosmeticCustomization : UFortAthenaAISpawnerDataComponent_AIPawnCosmeticBase {
	struct FGameplayTag FallbackTag; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct UFortAIPawnCustomizationDefinition* CustomizationDefinition; // 0x38(0x08)
	bool bCanUnloadCustomization; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_OptimBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_OptimBase : UFortAthenaAISpawnerDataComponent {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AIPawnOptim
// Size: 0x38 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AIPawnOptim : UFortAthenaAISpawnerDataComponent_OptimBase {
	char bRegisterToAIDropper : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_AssembledMesh
// Size: 0x50 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_AssembledMesh : UFortAthenaAISpawnerDataComponent_CosmeticBase {
	struct TSoftObjectPtr<UAssembledMeshSchema> AssembledMeshSchema; // 0x30(0x20)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_CosmeticLibrary
// Size: 0xf8 (Inherited: 0x40)
struct UFortAthenaAISpawnerDataComponent_CosmeticLibrary : UFortAthenaAISpawnerDataComponent_AIBotCosmeticBase {
	struct TArray<struct TSoftObjectPtr<UFortAthenaAIBotCosmeticLibraryData>> CosmeticLibraries; // 0x40(0x10)
	struct FScalableFloat DefaultCosmeticLibraryWeight; // 0x50(0x28)
	struct FGameplayTag PredefinedCosmeticSetTag; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FScalableFloat EmotesMaxCount; // 0x80(0x28)
	struct FScalableFloat bUseFixedSeed; // 0xa8(0x28)
	struct FScalableFloat FixedSeed; // 0xd0(0x28)

	int32_t GetAICosmeticLibraryDataIndex(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_CosmeticLibrary.GetAICosmeticLibraryDataIndex // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x4109610
	struct UFortAthenaAIBotCosmeticLibraryData* GetAICosmeticLibraryData(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_CosmeticLibrary.GetAICosmeticLibraryData // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96bee40
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_CosmeticLoadout
// Size: 0x2d8 (Inherited: 0x40)
struct UFortAthenaAISpawnerDataComponent_CosmeticLoadout : UFortAthenaAISpawnerDataComponent_AIBotCosmeticBase {
	struct FFortAthenaLoadout CosmeticLoadout; // 0x40(0x260)
	struct TArray<struct FFortAthenaAIWeightedCosmeticLoadout> WeightedLoadouts; // 0x2a0(0x10)
	struct TArray<struct UCustomCharacterPart*> CustomCharacterParts; // 0x2b0(0x10)
	bool bCanShowDefaultSkin; // 0x2c0(0x01)
	char pad_2C1[0x3]; // 0x2c1(0x03)
	struct FGameplayTag FallbackTag; // 0x2c4(0x04)
	struct UAnimInstance* AnimBPOverride; // 0x2c8(0x08)
	int32_t AnimBPOverridePriority; // 0x2d0(0x04)
	char pad_2D4[0x4]; // 0x2d4(0x04)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_CoverBase
// Size: 0x58 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_CoverBase : UFortAthenaAISpawnerDataComponent {
	struct UNavigationQueryFilter* CoverPositionFilterClass; // 0x30(0x08)
	struct FVector CoverBoxExtent; // 0x38(0x18)
	float CoverOffset; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_GroupBase
// Size: 0xe0 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_GroupBase : UFortAthenaAISpawnerDataComponent {
	struct FScalableFloat EnableGroupComponent; // 0x30(0x28)
	struct FScalableFloat CanBeGroupLeader; // 0x58(0x28)
	struct FScalableFloat EnableFormationComponent; // 0x80(0x28)
	struct TArray<struct FVector> FormationSlots; // 0xa8(0x10)
	struct FScalableFloat MaxDistanceFromSlotToSprint; // 0xb8(0x28)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Inventory
// Size: 0x50 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Inventory : UFortAthenaAIRuntimeParameters {
	char bShouldDropCurrencyOnDeath : 1; // 0x30(0x01)
	char bDefaultInventoryIgnoresRestrictions : 1; // 0x30(0x01)
	char bSkipInventoryInitialization : 1; // 0x30(0x01)
	char pad_30_3 : 5; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FName CurrencyPayoutRowName; // 0x34(0x04)
	char bDeathTagsCanBlockLootDrop : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FDataTableRowHandle LootInfo; // 0x40(0x10)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Hearing
// Size: 0x60 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Hearing : UFortAthenaAIRuntimeParameters {
	bool bOverrideHearingRange; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FGameplayTagContainer OverrideHearingRangeConditionTag; // 0x38(0x20)
	float HearingRadius; // 0x58(0x04)
	bool bRestrictOverrideToUnaware; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
};

// Class FortniteAI.FortAthenaAIRuntimeParameters_Sight
// Size: 0x68 (Inherited: 0x30)
struct UFortAthenaAIRuntimeParameters_Sight : UFortAthenaAIRuntimeParameters {
	bool bOverrideVisibilityRange; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FGameplayTagContainer OverrideVisibilityRangeConditionTag; // 0x38(0x20)
	float SightRadius; // 0x58(0x04)
	float LoseSightRadius; // 0x5c(0x04)
	bool bRestrictOverrideToUnaware; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_PerksBase
// Size: 0x40 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_PerksBase : UFortAthenaAISpawnerDataComponent {
	struct TArray<struct FPerkAvailabilityContainer> PerksContainers; // 0x30(0x10)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_RandomInventory
// Size: 0xc0 (Inherited: 0xb0)
struct UFortAthenaAISpawnerDataComponent_RandomInventory : UFortAthenaAISpawnerDataComponent_InventoryBase {
	struct TArray<struct FWeightedAIInventoryLoadout> Loadouts; // 0xb0(0x10)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_ScriptBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_ScriptBase : UFortAthenaAISpawnerDataComponent {
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_SmartObjectBase
// Size: 0x150 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_SmartObjectBase : UFortAthenaAISpawnerDataComponent {
	struct FScalableFloat Enabled; // 0x30(0x28)
	struct FScalableFloat ChooseClosestSmartObject; // 0x58(0x28)
	struct FScalableFloat UnreachableBanDuration; // 0x80(0x28)
	struct FScalableFloat SelectedSmartObjectExpirationDelay; // 0xa8(0x28)
	struct FScalableFloat GlobalSmartObjectCooldownOnFinished; // 0xd0(0x28)
	struct FScalableFloat GlobalSmartObjectCooldownOnInterrupted; // 0xf8(0x28)
	struct TArray<struct UFortAthenaAISmartObjectActivity*> SmartObjectActivitiesCombined; // 0x120(0x10)
	struct TArray<struct UFortAthenaAISmartObjectActivity*> SmartObjectActivitiesToAdd; // 0x130(0x10)
	struct TArray<struct UFortAthenaAISmartObjectActivity*> SmartObjectActivitiesToRemove; // 0x140(0x10)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase
// Size: 0x30 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_SpawnParamsBase : UFortAthenaAISpawnerDataComponent {

	bool ShouldSpawnInAir(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.ShouldSpawnInAir // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x4318760
	bool ShouldCheckForOverlaps(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.ShouldCheckForOverlaps // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c5f70
	float GetSpawnTracePadding(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.GetSpawnTracePadding // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c5fa0
	struct TArray<struct UFortAthenaAISpawnerData*> GetSpawnerDataSpawnedAsChildren(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.GetSpawnerDataSpawnedAsChildren // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c5fe0
	struct FDataTableRowHandle GetPawnStatHandle(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.GetPawnStatHandle // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c60b0
	struct APawn* GetPawnClass(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.GetPawnClass // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c6130
	float GetInAirSpawnTraceStartHeight(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.GetInAirSpawnTraceStartHeight // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c4c60
	float GetInAirSpawnTraceSphereRadius(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.GetInAirSpawnTraceSphereRadius // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c18d0
	float GetInAirSpawnTraceEndHeight(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.GetInAirSpawnTraceEndHeight // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c5f30
	struct AAIController* GetAIControllerClass(); // Function FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParamsBase.GetAIControllerClass // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x96c60f0
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_SpawnParams
// Size: 0x80 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_SpawnParams : UFortAthenaAISpawnerDataComponent_SpawnParamsBase {
	struct APawn* PawnClass; // 0x30(0x08)
	struct AAIController* AIControllerClass; // 0x38(0x08)
	struct FDataTableRowHandle PawnStatHandle; // 0x40(0x10)
	struct TArray<struct UFortAthenaAISpawnerData*> SpawnerDataSpawnedAsChildren; // 0x50(0x10)
	char bSpawnInAir : 1; // 0x60(0x01)
	char bSetSkyDivingFromBus : 1; // 0x60(0x01)
	char pad_60_2 : 6; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	float InAirSpawnTraceStartHeight; // 0x64(0x04)
	float InAirSpawnTraceEndHeight; // 0x68(0x04)
	float InAirSpawnTraceSphereRadius; // 0x6c(0x04)
	float SpawnTracePadding; // 0x70(0x04)
	char bCheckForOverlaps : 1; // 0x74(0x01)
	char bAddPOILocationTagsOnSpawn : 1; // 0x74(0x01)
	char pad_74_2 : 6; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
	bool bSetPlayerPawnAttributesWithThisStatHandle; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_TokenBase
// Size: 0xf8 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_TokenBase : UFortAthenaAISpawnerDataComponent {
	struct FScalableFloat EnableTokenProviderComponent; // 0x30(0x28)
	struct FScalableFloat TokenMaxCount; // 0x58(0x28)
	struct FScalableFloat EnableTokenConsumerComponent; // 0x80(0x28)
	struct FScalableFloat TokenHoldMinDuration; // 0xa8(0x28)
	struct FScalableFloat TokenHoldMaxDuration; // 0xd0(0x28)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_Vehicle
// Size: 0x50 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_Vehicle : UFortAthenaAISpawnerDataComponent_VehicleBase {
	struct AFortAthenaVehicle* VehicleToSpawnAndEnter; // 0x30(0x08)
	char bSetInfiniteFuel : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct UFortAthenaAIBotSkillSet*> VehicleSkillSets; // 0x40(0x10)
};

// Class FortniteAI.FortAthenaAISpawnerDataComponent_Voice
// Size: 0x50 (Inherited: 0x30)
struct UFortAthenaAISpawnerDataComponent_Voice : UFortAthenaAISpawnerDataComponent_VoiceBase {
	struct UFortAIComponent_Voice* VoiceComponentClass; // 0x30(0x08)
	struct UFortTaggedSoundBank* SoundBank; // 0x38(0x08)
	struct UFortTaggedSoundBank* MaleSoundBankOverride; // 0x40(0x08)
	struct UFortTaggedSoundBank* FemaleSoundBankOverride; // 0x48(0x08)
};

// Class FortniteAI.FortAthenaBeaconComponent
// Size: 0xd0 (Inherited: 0xa0)
struct UFortAthenaBeaconComponent : UActorComponent {
	int32_t MaxAttractedBots; // 0xa0(0x04)
	float AttractionRadius; // 0xa4(0x04)
	struct TArray<struct AActor*> RegisteredActors; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnConsumeEvent; // 0xb8(0x10)
	bool bIsConsumed; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// Class FortniteAI.FortAthenaBTTask_DynamicBlueprint
// Size: 0x80 (Inherited: 0x70)
struct UFortAthenaBTTask_DynamicBlueprint : UBTTaskNode {
	struct FName DynamicBlueprintStatusKeyName; // 0x70(0x04)
	struct FName DynamicBlueprintActorKeyName; // 0x74(0x04)
	char pad_78[0x8]; // 0x78(0x08)
};

// Class FortniteAI.FortAthenaLeashComponent
// Size: 0xe8 (Inherited: 0xa0)
struct UFortAthenaLeashComponent : UActorComponent {
	struct FScalableFloat LeashRadius; // 0xa0(0x28)
	struct FVector LeashCenter; // 0xc8(0x18)
	float LeashRadiusSqr; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)

	void SetLeashRadius(float NewRadius); // Function FortniteAI.FortAthenaLeashComponent.SetLeashRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x96cc340
	bool IsInsideLeash(struct FVector& Location); // Function FortniteAI.FortAthenaLeashComponent.IsInsideLeash // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x96cc240
	float GetLeashRadius(); // Function FortniteAI.FortAthenaLeashComponent.GetLeashRadius // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96cc1d0
	struct FVector GetLeashCenter(); // Function FortniteAI.FortAthenaLeashComponent.GetLeashCenter // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x96cc210
};

// Class FortniteAI.FortAthenaLocalGameplayBehavior
// Size: 0x2a0 (Inherited: 0x290)
struct AFortAthenaLocalGameplayBehavior : AActor {
	bool bNeedToAwakeDuringExecution; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
	struct UFortAthenaBTTask_DynamicBlueprint* CachedTask; // 0x298(0x08)

	void OnExecute(struct AActor* Activator); // Function FortniteAI.FortAthenaLocalGameplayBehavior.OnExecute // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnAbort(); // Function FortniteAI.FortAthenaLocalGameplayBehavior.OnAbort // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void FinishExecute(); // Function FortniteAI.FortAthenaLocalGameplayBehavior.FinishExecute // (Final|Native|Public|BlueprintCallable) // @ game+0x96cc750
};

// Class FortniteAI.FortAthenaNavArea_ShallowWater
// Size: 0x50 (Inherited: 0x50)
struct UFortAthenaNavArea_ShallowWater : UFortNavArea {
};

// Class FortniteAI.FortAthenaNavArea_Water
// Size: 0x50 (Inherited: 0x50)
struct UFortAthenaNavArea_Water : UFortNavArea {
};

// Class FortniteAI.FortAthenaNpcGalileoComponent
// Size: 0x100 (Inherited: 0xa0)
struct UFortAthenaNpcGalileoComponent : UActorComponent {
	struct AFortAthenaAIBotController* CachedBotController; // 0xa0(0x08)
	struct AFortPawn* PossessedPawn; // 0xa8(0x08)
	struct TArray<struct FVector> PatrolPath; // 0xb0(0x10)
	struct TArray<struct AFortAthenaAIBotController*> CommunicationGroup; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnPatrollingStart; // 0xd0(0x10)
	struct FMulticastInlineDelegate OnPatrollingStop; // 0xe0(0x10)
	char pad_F0[0x10]; // 0xf0(0x10)

	void SetPatrolPath(struct TArray<struct FVector>& NewPatrolPath); // Function FortniteAI.FortAthenaNpcGalileoComponent.SetPatrolPath // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x96cd200
	void SetCommunicationGroup(struct TArray<struct AFortAthenaAIBotController*>& AIBotControllerList); // Function FortniteAI.FortAthenaNpcGalileoComponent.SetCommunicationGroup // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x96cd060
	void OnPawnDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.FortAthenaNpcGalileoComponent.OnPawnDied // (Final|Native|Public|HasDefaults) // @ game+0x96cca90
	struct TArray<struct FVector> GetPatrolPath(); // Function FortniteAI.FortAthenaNpcGalileoComponent.GetPatrolPath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96cd1d0
	struct TArray<struct AFortAthenaAIBotController*> GetCommunicationGroup(); // Function FortniteAI.FortAthenaNpcGalileoComponent.GetCommunicationGroup // (Final|Native|Public|BlueprintCallable) // @ game+0x96ccfd0
};

// Class FortniteAI.FortAthenaNpcPatrollingComponent
// Size: 0xf8 (Inherited: 0xa0)
struct UFortAthenaNpcPatrollingComponent : UActorComponent {
	struct AAIController* CachedAIController; // 0xa0(0x08)
	struct FMulticastInlineDelegate OnStartPatrollingEvent; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnStopPatrollingEvent; // 0xb8(0x10)
	struct AFortAthenaPatrolPath* PatrolPath; // 0xc8(0x08)
	char pad_D0[0x28]; // 0xd0(0x28)

	void UpdateCurrentDestinationToNearestNextPoint(); // Function FortniteAI.FortAthenaNpcPatrollingComponent.UpdateCurrentDestinationToNearestNextPoint // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96cdf40
	void SetPatrolPath(struct AFortAthenaPatrolPath* NewPatrolPath, bool bOrientationAlreadyRandomized); // Function FortniteAI.FortAthenaNpcPatrollingComponent.SetPatrolPath // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96ce440
	void SelectNextPatrolPoint(); // Function FortniteAI.FortAthenaNpcPatrollingComponent.SelectNextPatrolPoint // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96ce060
	void RemovePatrolPath(); // Function FortniteAI.FortAthenaNpcPatrollingComponent.RemovePatrolPath // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96ce080
	void OnPatrolPathStatusChanged(bool bEnableState); // Function FortniteAI.FortAthenaNpcPatrollingComponent.OnPatrolPathStatusChanged // (Final|Native|Private) // @ game+0x96cde50
	bool IsPatrollingEnable(); // Function FortniteAI.FortAthenaNpcPatrollingComponent.IsPatrollingEnable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96cdf60
	bool IsCurrentPatrolPointAnEndPoint(); // Function FortniteAI.FortAthenaNpcPatrollingComponent.IsCurrentPatrolPointAnEndPoint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96cdfc0
	int32_t GetPatrolPointsCount(); // Function FortniteAI.FortAthenaNpcPatrollingComponent.GetPatrolPointsCount // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96cdf80
	struct AFortAthenaPatrolPath* GetPatrolPath(); // Function FortniteAI.FortAthenaNpcPatrollingComponent.GetPatrolPath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x821ead0
	struct AFortAthenaPatrolPoint* GetCurrentPatrolPoint(); // Function FortniteAI.FortAthenaNpcPatrollingComponent.GetCurrentPatrolPoint // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96ce010
	bool FindAndSetDynamicPatrolPath(struct FFortAthenaAIObjectTrackerQuery& FindQuery, bool bOrientationAlreadyRandomized, bool bExcludeCurrentlyUsedPatrolPath); // Function FortniteAI.FortAthenaNpcPatrollingComponent.FindAndSetDynamicPatrolPath // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x96ce0a0
};

// Class FortniteAI.PatrolPathRenderingComponent
// Size: 0x570 (Inherited: 0x570)
struct UPatrolPathRenderingComponent : UPrimitiveComponent {
};

// Class FortniteAI.PatrolPointRenderingComponent
// Size: 0x570 (Inherited: 0x570)
struct UPatrolPointRenderingComponent : UPrimitiveComponent {
};

// Class FortniteAI.FortAthenaPatrolPoint
// Size: 0x298 (Inherited: 0x290)
struct AFortAthenaPatrolPoint : AActor {
	struct AFortAthenaLocalGameplayBehavior* LocalGameplayBehavior; // 0x290(0x08)
};

// Class FortniteAI.FortAthenaTrackableAIObjectInterface
// Size: 0x28 (Inherited: 0x28)
struct UFortAthenaTrackableAIObjectInterface : UInterface {
};

// Class FortniteAI.AthenaAIPerceptionStimuliSourceComponent
// Size: 0xc0 (Inherited: 0xb8)
struct UAthenaAIPerceptionStimuliSourceComponent : UAIPerceptionStimuliSourceComponent {
	bool bIsConsideredAsThreateningObjectForBots; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)

	void OnOwnerTeamIndexChanged(); // Function FortniteAI.AthenaAIPerceptionStimuliSourceComponent.OnOwnerTeamIndexChanged // (Final|Native|Private) // @ game+0x96d5ad0
};

// Class FortniteAI.AthenaPhysicsAIPerceptionStimuliSourceComponent
// Size: 0xc0 (Inherited: 0xc0)
struct UAthenaPhysicsAIPerceptionStimuliSourceComponent : UAthenaAIPerceptionStimuliSourceComponent {
};

// Class FortniteAI.AthenaTrapAIPerceptionStimuliSourceComponent
// Size: 0x110 (Inherited: 0xb8)
struct UAthenaTrapAIPerceptionStimuliSourceComponent : UAIPerceptionStimuliSourceComponent {
	struct TMap<struct AActor*, struct FTrapDetectionState> TrapDiscoverabilityMap; // 0xb8(0x50)
	char bEnablePerceptionSystemOnTrap : 1; // 0x108(0x01)
	char pad_108_1 : 7; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
};

// Class FortniteAI.FortCollisionResponseSwapperComponent
// Size: 0x120 (Inherited: 0xa0)
struct UFortCollisionResponseSwapperComponent : UActorComponent {
	struct UPrimitiveComponent* CollisionPrimitiveComponent; // 0xa0(0x08)
	struct UPrimitiveComponent* OverlapPrimitiveComponent; // 0xa8(0x08)
	char pad_B0[0x28]; // 0xb0(0x28)
	struct TArray<struct AFortPawn*> PawnsListenedTo; // 0xd8(0x10)
	char pad_E8[0x8]; // 0xe8(0x08)
	struct FScalableFloat VisibilityModifiedTime; // 0xf0(0x28)
	enum class ECollisionResponse NewCollisionResponse; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)

	void UnregisterCallbacksForOverlap(); // Function FortniteAI.FortCollisionResponseSwapperComponent.UnregisterCallbacksForOverlap // (Final|Native|Protected|BlueprintCallable) // @ game+0x96d7d90
	void RestoreCollisionResponses(); // Function FortniteAI.FortCollisionResponseSwapperComponent.RestoreCollisionResponses // (Final|Native|Protected) // @ game+0x96d7500
	void RegisterCallbacksForOverlap(struct UPrimitiveComponent* InCollisionPrimitiveComponent, struct UPrimitiveComponent* InOverlapPrimitiveComponent); // Function FortniteAI.FortCollisionResponseSwapperComponent.RegisterCallbacksForOverlap // (Final|Native|Protected|BlueprintCallable) // @ game+0x96d7db0
	void HandleEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function FortniteAI.FortCollisionResponseSwapperComponent.HandleEndOverlap // (Final|Native|Protected) // @ game+0x96d7560
	void HandleBeginOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function FortniteAI.FortCollisionResponseSwapperComponent.HandleBeginOverlap // (Final|Native|Protected|HasOutParms) // @ game+0x96d78d0
};

// Class FortniteAI.FortAthenaAIPerk_Ambush
// Size: 0x168 (Inherited: 0x168)
struct UFortAthenaAIPerk_Ambush : UFortAIPerkBase {
};

// Class FortniteAI.FortAthenaAIPerk_Bunker
// Size: 0x2d0 (Inherited: 0x168)
struct UFortAthenaAIPerk_Bunker : UFortAIPerkBase {
	struct FScalableFloat OddsToBeUsedAgainstUnknownThreat; // 0x168(0x28)
	struct FScalableFloat OddsToUseRoofBuilding; // 0x190(0x28)
	struct FScalableFloat OddsToBuildForwardRamp; // 0x1b8(0x28)
	struct FScalableFloat InitialBuildDelay; // 0x1e0(0x28)
	struct FScalableFloat SamePieceBuildDelay; // 0x208(0x28)
	struct FScalableFloat SamePieceBuildDelayRandomDeviation; // 0x230(0x28)
	struct FScalableFloat DifferentPieceBuildDelay; // 0x258(0x28)
	struct FScalableFloat DifferentPieceBuildDelayRandomDeviation; // 0x280(0x28)
	struct FScalableFloat OddsToSelectRandomMaterial; // 0x2a8(0x28)
};

// Class FortniteAI.FortAthenaAIPerk_EvasiveManeuvers
// Size: 0x458 (Inherited: 0x168)
struct UFortAthenaAIPerk_EvasiveManeuvers : UFortAIPerkBase {
	struct FEvasiveManeuverSkillSettings EvasiveManeuverSkillSettings; // 0x168(0x258)
	struct FScalableFloat DistanceMin; // 0x3c0(0x28)
	struct FScalableFloat DistanceMax; // 0x3e8(0x28)
	struct FGameplayTagQuery WeaponTagQuery; // 0x410(0x48)
};

// Class FortniteAI.AthenaAIBotDebugMiniMapIndicator
// Size: 0x270 (Inherited: 0x140)
struct UAthenaAIBotDebugMiniMapIndicator : UFortMiniMapIndicator {
	struct TArray<struct FBotDebugInfo> BotDebugInfoList; // 0x140(0x10)
	struct FSlateBrush DebugMinimapIconBrush; // 0x150(0xc0)
	char pad_210[0x60]; // 0x210(0x60)
};

// Class FortniteAI.AthenaAIBotPOIDebugMiniMapIndicator
// Size: 0x188 (Inherited: 0x140)
struct UAthenaAIBotPOIDebugMiniMapIndicator : UFortMiniMapIndicator {
	struct TArray<struct FBotPOIDebugInfo> BotPOIDebugInfoList; // 0x140(0x10)
	struct TArray<struct FBotPOIExcludedZonesDebugInfo> BotPOIExcludedZonesDebugInfoList; // 0x150(0x10)
	struct TArray<struct FVector> ClusteredLootLocationsDebug; // 0x160(0x10)
	struct TArray<struct FString> ClusteredLootNamesDebug; // 0x170(0x10)
	int32_t ClusteredLootDrawDebugLevel; // 0x180(0x04)
	int32_t DynamicPOIDrawDebugLevel; // 0x184(0x04)
};

// Class FortniteAI.AthenaAIPopulationTracker
// Size: 0x170 (Inherited: 0x38)
struct UAthenaAIPopulationTracker : UAISubsystem {
	struct FMulticastInlineDelegate OnAIPawnDied; // 0x38(0x10)
	struct FMulticastInlineDelegate OnAIPawnDestroyed; // 0x48(0x10)
	struct FMulticastInlineDelegate OnAIPawnSpawned; // 0x58(0x10)
	char pad_68[0x60]; // 0x68(0x60)
	struct TArray<struct AController*> AIList; // 0xc8(0x10)
	struct AFortGameModeAthena* CachedGameMode; // 0xd8(0x08)
	char pad_E0[0x90]; // 0xe0(0x90)

	void OnFortPawnDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function FortniteAI.AthenaAIPopulationTracker.OnFortPawnDied // (Final|Native|Public|HasDefaults) // @ game+0x96db140
	void OnFortPawnDestroyed(struct AActor* DestroyedActor); // Function FortniteAI.AthenaAIPopulationTracker.OnFortPawnDestroyed // (Final|Native|Public) // @ game+0x96db050
	void OnAISpawned(struct APawn* Pawn, int32_t RequestID); // Function FortniteAI.AthenaAIPopulationTracker.OnAISpawned // (Final|Native|Private) // @ game+0x96dae40
	void OnAgentGameOver(struct AFortAthenaAIBotController* AIBotController, struct AFortPawn* Pawn, struct AController* Instigator); // Function FortniteAI.AthenaAIPopulationTracker.OnAgentGameOver // (Final|Native|Private) // @ game+0x96dac00
	int32_t GetNumTotalBots(); // Function FortniteAI.AthenaAIPopulationTracker.GetNumTotalBots // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96db9f0
	int32_t GetNumPlayerBots(); // Function FortniteAI.AthenaAIPopulationTracker.GetNumPlayerBots // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96db9d0
	int32_t GetNumNonAthenaParticipantBots(); // Function FortniteAI.AthenaAIPopulationTracker.GetNumNonAthenaParticipantBots // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96db9b0
	int32_t GetNumAIPawn(); // Function FortniteAI.AthenaAIPopulationTracker.GetNumAIPawn // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96db990
	struct FAIPopulationCountSnapshot GetAIPopulationTrackerCount(); // Function FortniteAI.AthenaAIPopulationTracker.GetAIPopulationTrackerCount // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96db750
	struct TArray<struct AController*> GetAIMatchingQuery(struct FGameplayTagQuery& TagQuery); // Function FortniteAI.AthenaAIPopulationTracker.GetAIMatchingQuery // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x96db790
};

// Class FortniteAI.AthenaAIService
// Size: 0x78 (Inherited: 0x28)
struct UAthenaAIService : UObject {
	struct AFortGameModeAthena* CachedGameMode; // 0x28(0x08)
	struct AFortGameStateAthena* CachedGameState; // 0x30(0x08)
	char pad_38[0x30]; // 0x38(0x30)
	struct UAthenaAIServiceManager* AIServiceManager; // 0x68(0x08)
	char pad_70[0x8]; // 0x70(0x08)
};

// Class FortniteAI.AthenaAIServiceCover
// Size: 0xa8 (Inherited: 0x78)
struct UAthenaAIServiceCover : UAthenaAIService {
	struct UNavigationQueryFilter* CoverPositionFilterClass; // 0x78(0x08)
	char pad_80[0x28]; // 0x80(0x28)

	struct UAthenaAIServiceCover* GetAthenaAIServiceCover(struct UObject* WorldContextObject); // Function FortniteAI.AthenaAIServiceCover.GetAthenaAIServiceCover // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x96de490
};

// Class FortniteAI.AthenaAIServicePlayerBots
// Size: 0x1290 (Inherited: 0x78)
struct UAthenaAIServicePlayerBots : UAthenaAIService {
	char pad_78[0x8]; // 0x78(0x08)
	struct UFortAthenaAISpawnerDataComponentList* DefaultAISpawnerDataComponentList; // 0x80(0x08)
	struct UFortAthenaAISpawnerDataComponent_SpawnParamsBase* DefaultAISpawnComponent; // 0x88(0x08)
	struct TArray<struct FFortServerBotInfo> DeadBots; // 0x90(0x10)
	struct TArray<struct FFortServerBotInfo> PlayerBotsRestartLeft; // 0xa0(0x10)
	struct FVector ZiplineOctreeCenter; // 0xb0(0x18)
	struct FScalableFloat ZiplineOctreeRadius; // 0xc8(0x28)
	struct FScalableFloat UseZiplines; // 0xf0(0x28)
	char pad_118[0x138]; // 0x118(0x138)
	struct FDebugMinimapData DebugMinimapData; // 0x250(0x1b0)
	struct FName MarkPlayerBotsAggressiveStencilName; // 0x400(0x04)
	struct FName MarkPlayerBotsDefensiveStencilName; // 0x404(0x04)
	bool bBotHostileToHumanPlayersOnly; // 0x408(0x01)
	char pad_409[0x7]; // 0x409(0x07)
	struct FScalableFloat UseAllBattleBusPOIsSquadRatio; // 0x410(0x28)
	struct UCurveFloat* TagQueryWeightChance; // 0x438(0x08)
	struct TSoftObjectPtr<UEnvQuery> FindLocationsAroundPOIQuery; // 0x440(0x20)
	struct TArray<struct FBattleBusPOI> BattleBusTagQueryPOIList; // 0x460(0x10)
	struct TArray<struct FBattleBusPOI> SecondaryBattleBusTagQueryPOIList; // 0x470(0x10)
	char pad_480[0x8]; // 0x480(0x08)
	struct TArray<struct FNavigationPOI> OnGroundTagQueryPOIList; // 0x488(0x10)
	struct FConstructionBuildingInfo ConstructionBuildingInfo[0x6]; // 0x498(0x90)
	struct FScalableFloat UseCustomSupportedItemList; // 0x528(0x28)
	struct UDataTable* BotItemDataTable; // 0x550(0x08)
	struct FName AugmentsRegistryName; // 0x558(0x04)
	char pad_55C[0x4]; // 0x55c(0x04)
	struct UDataRegistry* ItemBehaviorsRegistry; // 0x560(0x08)
	struct TArray<struct UBehaviorTree*> InjectionSupportingBehaviors; // 0x568(0x10)
	struct FScalableFloat UseRegionalNameList; // 0x578(0x28)
	struct FScalableFloat MaxAnonymousBotCount; // 0x5a0(0x28)
	struct TSoftObjectPtr<UFortAthenaAIBotNameDataAsset> BotNameDataAsset; // 0x5c8(0x20)
	struct FScalableFloat CosmeticVariationCount; // 0x5e8(0x28)
	struct FScalableFloat ThankBusDriverProbability; // 0x610(0x28)
	struct FScalableFloat ThankBusDriverMinTime; // 0x638(0x28)
	struct FScalableFloat ThankBusDriverMaxTime; // 0x660(0x28)
	struct FScalableFloat TriggerEndGameBehaviorMinTime; // 0x688(0x28)
	struct FScalableFloat TriggerEndGameBehaviorMaxTime; // 0x6b0(0x28)
	struct FScalableFloat ShowSeasonLevelProbability; // 0x6d8(0x28)
	struct FScalableFloat SpectateOthersOnDeath; // 0x700(0x28)
	struct FScalableFloat MaxNumberOfBotsToSpawnAroundPlayer; // 0x728(0x28)
	float MaxAroundBotDistanceToSearchPOIToLand; // 0x750(0x04)
	char pad_754[0x4]; // 0x754(0x04)
	struct FScalableFloat BackfillEnabled; // 0x758(0x28)
	struct FScalableFloat UsePlayerCosmeticForBackfill; // 0x780(0x28)
	struct FScalableFloat UsePlayerInventoryForBackfill; // 0x7a8(0x28)
	struct FScalableFloat OnlyUseBackfillDuringSafezones; // 0x7d0(0x28)
	struct TSoftClassPtr<UObject> BackfillSpawnerData; // 0x7f8(0x20)
	struct FGameplayTagContainer SupportedItemTags; // 0x818(0x20)
	struct TArray<struct FCachedPOIVolumeLocations> CachedValidPOIVolumeLocations; // 0x838(0x10)
	struct TArray<struct ABuildingFoundation*> CachedBuildingFoundations; // 0x848(0x10)
	struct TArray<struct FFortBotAugmentsDataTableRow> CachedSupportedAugments; // 0x858(0x10)
	char pad_868[0x60]; // 0x868(0x60)
	struct TScriptInterface<IFortAIAimingManagerInterface> CachedAIAimingManager; // 0x8c8(0x10)
	char pad_8D8[0x160]; // 0x8d8(0x160)
	struct AFortPlayerStartWarmup* LastTeamPlayerStart; // 0xa38(0x08)
	char pad_A40[0x8]; // 0xa40(0x08)
	struct TMap<int32_t, struct UCacheSafeZoneLocation*> CacheSafeZoneLocationsMap; // 0xa48(0x50)
	bool bCleanupBotsRegardlessOfRemainingSquadMembers; // 0xa98(0x01)
	char pad_A99[0x3]; // 0xa99(0x03)
	float DeadBotCleanupMinDelay; // 0xa9c(0x04)
	char pad_AA0[0x8]; // 0xaa0(0x08)
	struct TSet<struct FString> ReservedPlayerNames; // 0xaa8(0x50)
	char pad_AF8[0x8]; // 0xaf8(0x08)
	struct TArray<int32_t> LocationsInSafeZoneFreeIndices; // 0xb00(0x10)
	char pad_B10[0x68]; // 0xb10(0x68)
	struct AFortTeamInfoAthena* CurrentFillingTeam; // 0xb78(0x08)
	char pad_B80[0x58]; // 0xb80(0x58)
	struct FScalableFloat BotsUniqueIDUseValidAccountID; // 0xbd8(0x28)
	int32_t CurrentBotControllerUID; // 0xc00(0x04)
	char pad_C04[0x4]; // 0xc04(0x04)
	struct TArray<struct UFortAthenaBeaconComponent*> BeaconList; // 0xc08(0x10)
	char pad_C18_0 : 6; // 0xc18(0x01)
	char bWaitForNavmeshToBeLoaded : 1; // 0xc18(0x01)
	char bDoSpawnBotFlow : 1; // 0xc18(0x01)
	char bDoMapSampling : 1; // 0xc19(0x01)
	char pad_C19_1 : 7; // 0xc19(0x01)
	enum class EAthenaGamePhase GamePhaseToStartSpawning; // 0xc1a(0x01)
	char pad_C1B[0x5]; // 0xc1b(0x05)
	struct UFortAthenaAISpawnerData* DefaultBotAISpawnerData; // 0xc20(0x08)
	char pad_C28[0x10]; // 0xc28(0x10)
	struct TSoftObjectPtr<UEnvQuery> EQSMapSampling; // 0xc38(0x20)
	char pad_C58[0x30]; // 0xc58(0x30)
	struct FScalableFloat CanReviveDownedSquad; // 0xc88(0x28)
	struct UAthenaAIPopulationTracker* CachedAIPopulationTracker; // 0xcb0(0x08)
	struct TArray<struct FFortServerBotInfo> PlayerBots; // 0xcb8(0x10)
	struct TArray<struct FFortServerBotInfo> NonAthenaParticipantBots; // 0xcc8(0x10)
	char pad_CD8[0x88]; // 0xcd8(0x88)
	struct TSoftObjectPtr<UDataTable> MMRSpawnTable; // 0xd60(0x20)
	struct TArray<struct TSoftObjectPtr<UDataTable>> MMRSpawnTableOverrides; // 0xd80(0x10)
	struct FMMRSpawningPlayerBotsRuntimeInfo CachedMMRSpawningInfo; // 0xd90(0x38)
	char pad_DC8[0x20]; // 0xdc8(0x20)
	struct FScalableFloat OverridePOISpreadingSquadCount; // 0xde8(0x28)
	char pad_E10[0x68]; // 0xe10(0x68)
	struct FScalableFloat OnlyPickPOIsInSafeZone; // 0xe78(0x28)
	struct FVector KillVolumeOverlapCheckHalfExtent; // 0xea0(0x18)
	struct FScalableFloat DynamicBotPOIEnabled; // 0xeb8(0x28)
	struct TSoftObjectPtr<UEnvQuery> BotPOIEQS; // 0xee0(0x20)
	struct FScalableFloat BotPOIMinimumWeightForSquadMembers; // 0xf00(0x28)
	struct FScalableFloat BotPOINextPOIDurationSecondByWeight; // 0xf28(0x28)
	struct FScalableFloat BotPOINextPOIMinDuration; // 0xf50(0x28)
	struct FScalableFloat BotPOINextPOIMaxDuration; // 0xf78(0x28)
	struct UDataRegistry* BotPOIExcludedZonesDataRegistry; // 0xfa0(0x08)
	struct FGameplayTagContainer DynamicPOIPointProviderTags; // 0xfa8(0x20)
	struct FScalableFloat JumpOffBusWithDynamicPOIEnabled; // 0xfc8(0x28)
	struct FScalableFloat BotPOIJumpMainPOICountMax; // 0xff0(0x28)
	struct FScalableFloat BotPOISquadJumpOnMainPOICountMax; // 0x1018(0x28)
	struct FScalableFloat DenyJumpBusBotPOIByProximityEnabled; // 0x1040(0x28)
	struct FScalableFloat DenyJumpBusBotPOIDistance; // 0x1068(0x28)
	struct FScalableFloat NavigationWithDynamicPOIEnabled; // 0x1090(0x28)
	struct FScalableFloat FailToReachBotPOICountMax; // 0x10b8(0x28)
	struct FScalableFloat BotPOIScoringWeightFactor; // 0x10e0(0x28)
	struct FScalableFloat BotPOIScoringDistanceFactor; // 0x1108(0x28)
	struct FScalableFloat BotPOIScoringOccupancyFactor; // 0x1130(0x28)
	struct FScalableFloat BotPOIScoringVisitedFactor; // 0x1158(0x28)
	struct FScalableFloat ChanceToUseNextSafeZone; // 0x1180(0x28)
	int32_t BotPOIIdCount; // 0x11a8(0x04)
	int32_t BotPOISquadJumpedOnMainPOICount; // 0x11ac(0x04)
	struct TArray<int32_t> StartupPOIPendingEQSRequestIDList; // 0x11b0(0x10)
	struct TArray<struct FBotPOI> BotPOIList; // 0x11c0(0x10)
	struct TArray<struct FBotPOI> CachedMainJumpBotPOIList; // 0x11d0(0x10)
	struct TArray<struct FBotPOI> CachedSecondaryJumpBotPOIList; // 0x11e0(0x10)
	struct TArray<struct FBotPOIExcludedZone> CachedBotPOIExcludedZonesList; // 0x11f0(0x10)
	bool bIsBotPOIJumpListSplit; // 0x1200(0x01)
	bool bIsExcludedZoneGenerated; // 0x1201(0x01)
	char pad_1202[0x6]; // 0x1202(0x06)
	struct AFortAIBotPOIDebugActor* BotPOIDebugDebugActor; // 0x1208(0x08)
	bool bCheatBotPOIDebugMiniMapEnabled; // 0x1210(0x01)
	char pad_1211[0x7]; // 0x1211(0x07)
	struct AFortAIBotDebugActor* BotDebugDebugActor; // 0x1218(0x08)
	bool bCheatBotDebugMiniMapEnabled; // 0x1220(0x01)
	char pad_1221[0x7]; // 0x1221(0x07)
	struct UFortGameStateComponent_BattleRoyaleGamePhaseLogic* CachedGamePhaseLogic; // 0x1228(0x08)
	char pad_1230[0x60]; // 0x1230(0x60)

	struct APawn* SpawnAI(struct FVector& InSpawnLocation, struct FRotator& InSpawnRotation, struct UFortAthenaAISpawnerDataComponentList* AISpawnerComponentList); // Function FortniteAI.AthenaAIServicePlayerBots.SpawnAI // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x96ebfc0
	void OnServerGameMemberRemoved(char InSquadId, char InTeamIndex, struct AFortPlayerStateAthena* ChangedPS); // Function FortniteAI.AthenaAIServicePlayerBots.OnServerGameMemberRemoved // (Final|Native|Private) // @ game+0x96ead90
	void OnSafeZoneUpdated(struct FFortSafeZonePhaseUpdatedEvent& Event); // Function FortniteAI.AthenaAIServicePlayerBots.OnSafeZoneUpdated // (Final|Native|Private|HasOutParms) // @ game+0x96eb1c0
	void OnPlaylistDataReady(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function FortniteAI.AthenaAIServicePlayerBots.OnPlaylistDataReady // (Final|Native|Protected|HasOutParms) // @ game+0x96eb2b0
	void OnGamePhaseLogicReady(struct FFortBattleRoyaleGamePhaseLogicComponentReadyEvent& Event); // Function FortniteAI.AthenaAIServicePlayerBots.OnGamePhaseLogicReady // (RequiredAPI|Native|Protected|HasOutParms) // @ game+0x96eb0d0
	void OnGamePhaseChanged(struct FFortGamePhaseUpdatedEvent& Event); // Function FortniteAI.AthenaAIServicePlayerBots.OnGamePhaseChanged // (RequiredAPI|Native|Protected|HasOutParms) // @ game+0x96eafe0
	void OnAIPawnSpawned(struct AController* SpawnedController, bool bIsABot, struct AFortPawn* FortAIPawn, struct AFortPlayerPawn* PlayerPawn); // Function FortniteAI.AthenaAIServicePlayerBots.OnAIPawnSpawned // (Final|Native|Private) // @ game+0x96ea420
	void OnAgentGameOver(struct AFortAthenaAIBotController* AIBotController, struct AFortPawn* Pawn, struct AController* Instigator); // Function FortniteAI.AthenaAIServicePlayerBots.OnAgentGameOver // (RequiredAPI|Native|Protected) // @ game+0x96eaa00
	void KillBots(bool bKillPlayers, bool bKillNPCs, char TeamIndex, struct AActor* BotOwner); // Function FortniteAI.AthenaAIServicePlayerBots.KillBots // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96eb680
	void JoinTeam(struct AController* SourceTeamController, struct AController* DestinationTeamController); // Function FortniteAI.AthenaAIServicePlayerBots.JoinTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x96eb950
	bool IsWeaponSupported(struct AFortWeapon* FortWeapon); // Function FortniteAI.AthenaAIServicePlayerBots.IsWeaponSupported // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x96ebb80
	int32_t FetchNextCustomBotCosmeticVariantID(struct AFortPlayerPawnAthena* BotPawn); // Function FortniteAI.AthenaAIServicePlayerBots.FetchNextCustomBotCosmeticVariantID // (Final|Native|Public|BlueprintCallable) // @ game+0x96eb550
	void AddPOIVolume(struct AFortPoiVolume* POIVolume, enum class EAthenaAIServicePOIList POIList); // Function FortniteAI.AthenaAIServicePlayerBots.AddPOIVolume // (Final|Native|Private|BlueprintCallable) // @ game+0x96eac10
};

// Class FortniteAI.AthenaAIServiceCreativePlayerBots
// Size: 0x1310 (Inherited: 0x1290)
struct UAthenaAIServiceCreativePlayerBots : UAthenaAIServicePlayerBots {
	struct FMulticastInlineDelegate OnMinigameBotsReady; // 0x1288(0x10)
	struct TWeakObjectPtr<struct AFortMinigame> CachedMinigame; // 0x1298(0x08)
	struct TMap<struct AActor*, struct APlayerController*> HiringHistory; // 0x12a8(0x50)
	char pad_12F8[0x18]; // 0x12f8(0x18)

	void OnMinigameStateChanged(struct AFortMinigame* Minigame, enum class EFortMinigameState MinigameState); // Function FortniteAI.AthenaAIServiceCreativePlayerBots.OnMinigameStateChanged // (RequiredAPI|Native|Public) // @ game+0x96e0cf0
	void OnFinishedAddingMinigamePlayer(struct FUniqueNetIdRepl UniqueNetId, bool bIsLocalPlayer); // Function FortniteAI.AthenaAIServiceCreativePlayerBots.OnFinishedAddingMinigamePlayer // (Final|Native|Protected) // @ game+0x96e0a40
	bool IsMinigameBotSpawningRequired(); // Function FortniteAI.AthenaAIServiceCreativePlayerBots.IsMinigameBotSpawningRequired // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x86718c0
	struct APlayerController* GetLastHiringPlayer(struct AActor* HiredOwner); // Function FortniteAI.AthenaAIServiceCreativePlayerBots.GetLastHiringPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96e0e80
	void ClearHiringHistory(struct AActor* HiredOwner); // Function FortniteAI.AthenaAIServiceCreativePlayerBots.ClearHiringHistory // (Final|Native|Public|BlueprintCallable) // @ game+0x96e1020
	void AddHiringHistory(struct AActor* HiredOwner, struct APlayerController* HiringPlayer); // Function FortniteAI.AthenaAIServiceCreativePlayerBots.AddHiringHistory // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x96e1110
};

// Class FortniteAI.AthenaAIServiceGroup
// Size: 0x90 (Inherited: 0x78)
struct UAthenaAIServiceGroup : UAthenaAIService {
	int32_t GroupIndexCount; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TArray<struct FAthenaAIServiceGroupInfo> GroupList; // 0x80(0x10)
};

// Class FortniteAI.AthenaAIServiceLoot
// Size: 0x5b0 (Inherited: 0x78)
struct UAthenaAIServiceLoot : UAthenaAIService {
	struct FVector LootOctreeCenter; // 0x78(0x18)
	struct FScalableFloat LootOctreeRadius; // 0x90(0x28)
	struct FScalableFloat SupplyDropStatusUpdateRate; // 0xb8(0x28)
	struct FScalableFloat RemoveInvalidChestFromOctreeProbability; // 0xe0(0x28)
	struct FScalableFloat MovingLootTrackingEnabled; // 0x108(0x28)
	struct FScalableFloat MovingLootUpdateRate; // 0x130(0x28)
	struct FScalableFloat MovingLootOctreeUpdateDistanceThreshold; // 0x158(0x28)
	struct TArray<struct ABuildingProp*> HarvestableActorClassList; // 0x180(0x10)
	struct FScalableFloat LootClusteringEnabled; // 0x190(0x28)
	struct FScalableFloat LootClusteringNeighborDistanceMax; // 0x1b8(0x28)
	struct FScalableFloat LootClusteringNeighborhoodCountMin; // 0x1e0(0x28)
	struct UDataRegistry* LootClusteringItemWeightDataRegistry; // 0x208(0x08)
	struct FScalableFloat LootClusteringDefaultWeight; // 0x210(0x28)
	struct FScalableFloat LootClusteringExpandByBoxX; // 0x238(0x28)
	struct FScalableFloat LootClusteringExpandByBoxY; // 0x260(0x28)
	struct FScalableFloat LootClusteringExpandByBoxZ; // 0x288(0x28)
	char pad_2B0[0x210]; // 0x2b0(0x210)
	struct TMap<struct TWeakObjectPtr<struct AFortPickup>, struct FMovingLootInfo> MovingLoots; // 0x4c0(0x50)
	char pad_510[0x8]; // 0x510(0x08)
	struct TArray<struct FCachedSupplyDrop> CachedSupplyDrops; // 0x518(0x10)
	struct UFortWorldItem* CachedWorldItem; // 0x528(0x08)
	struct UDataTable* BotBuildingContainerExcludeListDataTable; // 0x530(0x08)
	enum class EAthenaGamePhaseStep LootClusterCalculationGamePhase; // 0x538(0x01)
	char pad_539[0x5f]; // 0x539(0x5f)
	struct TArray<struct FFortBotClusterLootWeightDataTableRow> CachedLootClusteringItemWeightTable; // 0x598(0x10)
	char pad_5A8[0x8]; // 0x5a8(0x08)

	void UpdateSupplyDropStatus(); // Function FortniteAI.AthenaAIServiceLoot.UpdateSupplyDropStatus // (Final|Native|Private) // @ game+0x96e3570
	void UpdateMovingLoots(); // Function FortniteAI.AthenaAIServiceLoot.UpdateMovingLoots // (Final|Native|Private) // @ game+0x96e3550
	void OnGamePhaseStepChanged(struct TScriptInterface<IFortSafeZoneInterface>& SafeZoneInterface, enum class EAthenaGamePhaseStep GamePhaseStep); // Function FortniteAI.AthenaAIServiceLoot.OnGamePhaseStepChanged // (Final|Native|Public|HasOutParms) // @ game+0x96e38f0
	void K2_RemoveGameplayTagFromLoot(struct AActor* LootActor, struct FGameplayTag& GameplayTag); // Function FortniteAI.AthenaAIServiceLoot.K2_RemoveGameplayTagFromLoot // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x96e3590
	void K2_AddGameplayTagToLoot(struct AActor* LootActor, struct FGameplayTag& GameplayTag); // Function FortniteAI.AthenaAIServiceLoot.K2_AddGameplayTagToLoot // (Final|BlueprintAuthorityOnly|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x96e3740
};

// Class FortniteAI.AthenaAIServiceManager
// Size: 0x80 (Inherited: 0x38)
struct UAthenaAIServiceManager : UAISubsystem {
	char pad_38[0x18]; // 0x38(0x18)
	struct TArray<struct UAthenaAIService*> AIServices; // 0x50(0x10)
	char pad_60[0x20]; // 0x60(0x20)
};

// Class FortniteAI.CacheSafeZoneLocation
// Size: 0x60 (Inherited: 0x28)
struct UCacheSafeZoneLocation : UObject {
	char pad_28[0x38]; // 0x28(0x38)
};

// Class FortniteAI.AthenaAIServiceVehicle
// Size: 0xc8 (Inherited: 0x78)
struct UAthenaAIServiceVehicle : UAthenaAIService {
	char pad_78[0x48]; // 0x78(0x48)
	float TimeToRefreshTree; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// Class FortniteAI.AthenaAIServiceZoneManager
// Size: 0x88 (Inherited: 0x78)
struct UAthenaAIServiceZoneManager : UAthenaAIService {
	struct TArray<struct FAthenaAITrackedZone> TrackedZones; // 0x78(0x10)

	void UnregisterOccluder(struct AActor* OccluderActor); // Function FortniteAI.AthenaAIServiceZoneManager.UnregisterOccluder // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x970f650
	void UnregisterDangerZone(struct AActor* Actor); // Function FortniteAI.AthenaAIServiceZoneManager.UnregisterDangerZone // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x970eec0
	void RegisterOccluder(struct AActor* OccluderActor, float SphereRadius); // Function FortniteAI.AthenaAIServiceZoneManager.RegisterOccluder // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x970f860
	void RegisterDangerZone(struct AActor* Actor, float Radius); // Function FortniteAI.AthenaAIServiceZoneManager.RegisterDangerZone // (Final|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x970f0d0
	void OnZoneDestroyed(struct AActor* Actor); // Function FortniteAI.AthenaAIServiceZoneManager.OnZoneDestroyed // (Final|BlueprintAuthorityOnly|Native|Private|BlueprintCallable) // @ game+0x970ebb0
	bool IsLOFOccluded(struct FVector& StartLocation, struct FVector& EndLocation); // Function FortniteAI.AthenaAIServiceZoneManager.IsLOFOccluded // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x970f460
	bool IsInDangerZone(struct FVector& Location); // Function FortniteAI.AthenaAIServiceZoneManager.IsInDangerZone // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x970ed80
	struct UAthenaAIServiceZoneManager* GetAthenaAIServiceZoneManager(struct UObject* WorldContextObject); // Function FortniteAI.AthenaAIServiceZoneManager.GetAthenaAIServiceZoneManager // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x970fbf0
};

// Class FortniteAI.AthenaAISpawner
// Size: 0x108 (Inherited: 0x38)
struct UAthenaAISpawner : UAISubsystem {
	struct FMulticastInlineDelegate OnPawnPreFinishSpawningEvent; // 0x38(0x10)
	struct FMulticastInlineDelegate OnPawnSpawnedEvent; // 0x48(0x10)
	char pad_58[0xb0]; // 0x58(0xb0)

	int32_t RequestSpawn(struct UFortAthenaAISpawnerDataComponentList* AISpawnerComponentList, struct FTransform& SpawnTransform, bool bUrgentRequest); // Function FortniteAI.AthenaAISpawner.RequestSpawn // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9710bf0
	void QueueForDespawn(struct AActor* ActorToDespawn); // Function FortniteAI.AthenaAISpawner.QueueForDespawn // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9710670
	bool CancelRequest(int32_t RequestID); // Function FortniteAI.AthenaAISpawner.CancelRequest // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9710b00
};

// Class FortniteAI.AthenaAIVehicleAvoidanceManager
// Size: 0x88 (Inherited: 0x38)
struct UAthenaAIVehicleAvoidanceManager : UAISubsystem {
	char pad_38[0x4c]; // 0x38(0x4c)
	float TimeToRefreshTree; // 0x84(0x04)
};

// Class FortniteAI.DespawnExpiredPawnComponent
// Size: 0xa8 (Inherited: 0xa8)
struct UDespawnExpiredPawnComponent : UFortPawnComponent {

	struct TArray<struct ABuildingRift*> GetDespawnRifts(); // Function FortniteAI.DespawnExpiredPawnComponent.GetDespawnRifts // (Final|Native|Public|BlueprintCallable) // @ game+0x9716b80
	void DespawnExpired(); // Function FortniteAI.DespawnExpiredPawnComponent.DespawnExpired // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x48d7560
	void AddDespawnRift(struct ABuildingRift* NewRift); // Function FortniteAI.DespawnExpiredPawnComponent.AddDespawnRift // (Final|Native|Public|BlueprintCallable) // @ game+0x9716bf0
};

