// Class CurveExpression.CurveExpressionsDataAsset
// Size: 0x128 (Inherited: 0x30)
struct UCurveExpressionsDataAsset : UDataAsset {
	char pad_30[0x30]; // 0x30(0x30)
	struct TArray<struct FName> NamedConstants; // 0x60(0x10)
	char pad_70[0xb8]; // 0x70(0xb8)
};

