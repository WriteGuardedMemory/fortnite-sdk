// Enum CRD_ClassSelectorRuntime.EClassSelectorDisplayMode
enum class EClassSelectorDisplayMode : uint8 {
	ClassesOnly = 0,
	TeamsOnly = 1,
	TeamsAndClasses = 2,
	EClassSelectorDisplayMode_MAX = 3
};

