// Class DataflowEnginePlugin.DataflowActor
// Size: 0x298 (Inherited: 0x290)
struct ADataflowActor : AActor {
	struct UDataflowComponent* DataflowComponent; // 0x290(0x08)
};

// Class DataflowEnginePlugin.DataflowComponent
// Size: 0x6b0 (Inherited: 0x570)
struct UDataflowComponent : UPrimitiveComponent {
	char pad_570[0x140]; // 0x570(0x140)
};

