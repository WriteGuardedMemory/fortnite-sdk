// Class EpicMediaUtilities.EpicMediaServerTime
// Size: 0x2a8 (Inherited: 0x290)
struct AEpicMediaServerTime : AActor {
	char pad_290[0x18]; // 0x290(0x18)

	void ServerRequestServerTime(double requestUtcTime); // Function EpicMediaUtilities.EpicMediaServerTime.ServerRequestServerTime // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x5f73780
	bool GetTimeUtc(struct FDateTime& OutDateTime); // Function EpicMediaUtilities.EpicMediaServerTime.GetTimeUtc // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f73a10
	void ClientReportServerTime(double requestUtcTime, double serverUtcTime); // Function EpicMediaUtilities.EpicMediaServerTime.ClientReportServerTime // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x5f73870
};

