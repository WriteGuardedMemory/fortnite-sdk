// Class MLDeformerFramework.MLDeformerAsset
// Size: 0x30 (Inherited: 0x28)
struct UMLDeformerAsset : UObject {
	struct UMLDeformerModel* Model; // 0x28(0x08)
};

// Class MLDeformerFramework.MLDeformerVizSettings
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerVizSettings : UObject {
};

// Class MLDeformerFramework.MLDeformerGeomCacheVizSettings
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerGeomCacheVizSettings : UMLDeformerVizSettings {
};

// Class MLDeformerFramework.MLDeformerMorphModelVizSettings
// Size: 0x38 (Inherited: 0x28)
struct UMLDeformerMorphModelVizSettings : UMLDeformerGeomCacheVizSettings {
	float MorphTargetDeltaThreshold; // 0x28(0x04)
	int32_t MorphTargetNumber; // 0x2c(0x04)
	bool bDrawMorphTargets; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class MLDeformerFramework.MLDeformerComponent
// Size: 0xe8 (Inherited: 0xa0)
struct UMLDeformerComponent : UActorComponent {
	char pad_A0[0x30]; // 0xa0(0x30)
	struct UMLDeformerAsset* DeformerAsset; // 0xd0(0x08)
	float Weight; // 0xd8(0x04)
	int32_t QualityLevel; // 0xdc(0x04)
	struct UMLDeformerModelInstance* ModelInstance; // 0xe0(0x08)

	void UpdateSkeletalMeshComponent(); // Function MLDeformerFramework.MLDeformerComponent.UpdateSkeletalMeshComponent // (Final|Native|Public|BlueprintCallable) // @ game+0xad5f4c0
	void SetWeight(float NormalizedWeightValue); // Function MLDeformerFramework.MLDeformerComponent.SetWeight // (Final|Native|Public|BlueprintCallable) // @ game+0x50f8570
	void SetQualityLevel(int32_t InQualityLevel); // Function MLDeformerFramework.MLDeformerComponent.SetQualityLevel // (Final|Native|Public|BlueprintCallable) // @ game+0xad5f880
	void SetDeformerAsset(struct UMLDeformerAsset* InDeformerAsset); // Function MLDeformerFramework.MLDeformerComponent.SetDeformerAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x48d7580
	float GetWeight(); // Function MLDeformerFramework.MLDeformerComponent.GetWeight // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x48d7670
	struct USkeletalMeshComponent* GetSkeletalMeshComponent(); // Function MLDeformerFramework.MLDeformerComponent.GetSkeletalMeshComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3c39a90
	int32_t GetQualityLevel(); // Function MLDeformerFramework.MLDeformerComponent.GetQualityLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9096160
	struct UMLDeformerAsset* GetDeformerAsset(); // Function MLDeformerFramework.MLDeformerComponent.GetDeformerAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x86318d0
	struct USkeletalMeshComponent* FindSkeletalMeshComponent(struct UMLDeformerAsset* Asset); // Function MLDeformerFramework.MLDeformerComponent.FindSkeletalMeshComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xad5f510
};

// Class MLDeformerFramework.MLDeformerComponentSource
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerComponentSource : UOptimusComponentSource {
};

// Class MLDeformerFramework.MLDeformerModel
// Size: 0xf0 (Inherited: 0x28)
struct UMLDeformerModel : UObject {
	char pad_28[0xa0]; // 0x28(0xa0)
	int32_t NumBaseMeshVerts; // 0xc8(0x04)
	int32_t NumTargetMeshVerts; // 0xcc(0x04)
	struct UMLDeformerInputInfo* InputInfo; // 0xd0(0x08)
	struct TArray<int32_t> VertexMap; // 0xd8(0x10)
	struct USkeletalMesh* SkeletalMesh; // 0xe8(0x08)
};

// Class MLDeformerFramework.MLDeformerGeomCacheModel
// Size: 0xf0 (Inherited: 0xf0)
struct UMLDeformerGeomCacheModel : UMLDeformerModel {
};

// Class MLDeformerFramework.MLDeformerGraphDebugDataInterface
// Size: 0x28 (Inherited: 0x28)
struct UMLDeformerGraphDebugDataInterface : UOptimusComputeDataInterface {
};

// Class MLDeformerFramework.MLDeformerGraphDebugDataProvider
// Size: 0x38 (Inherited: 0x28)
struct UMLDeformerGraphDebugDataProvider : UComputeDataProvider {
	struct UMLDeformerComponent* DeformerComponent; // 0x28(0x08)
	struct UMLDeformerAsset* DeformerAsset; // 0x30(0x08)
};

// Class MLDeformerFramework.MLDeformerInputInfo
// Size: 0x68 (Inherited: 0x28)
struct UMLDeformerInputInfo : UObject {
	struct FSoftObjectPath SkeletalMesh; // 0x28(0x18)
	struct TArray<struct FName> BoneNames; // 0x40(0x10)
	struct TArray<struct FName> CurveNames; // 0x50(0x10)
	int32_t NumBaseMeshVertices; // 0x60(0x04)
	int32_t NumTargetMeshVertices; // 0x64(0x04)
};

// Class MLDeformerFramework.MLDeformerModelInstance
// Size: 0x90 (Inherited: 0x28)
struct UMLDeformerModelInstance : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct UMLDeformerModel* Model; // 0x38(0x08)
	char pad_40[0x50]; // 0x40(0x50)
};

// Class MLDeformerFramework.MLDeformerMorphModel
// Size: 0x188 (Inherited: 0xf0)
struct UMLDeformerMorphModel : UMLDeformerGeomCacheModel {
	char pad_F0[0x10]; // 0xf0(0x10)
	struct TArray<struct FVector3f> MorphTargetDeltas; // 0x100(0x10)
	int32_t NumMorphTargets; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
	uint64_t CompressedMorphDataSizeInBytes; // 0x118(0x08)
	uint64_t UncompressedMorphDataSizeInBytes; // 0x120(0x08)
	struct TArray<int32_t> MorphTargetErrorOrder; // 0x128(0x10)
	struct TArray<float> MorphTargetErrors; // 0x138(0x10)
	struct TArray<float> MaxMorphWeights; // 0x148(0x10)
	struct TArray<struct FMLDeformerMorphModelQualityLevel> QualityLevels; // 0x158(0x10)
	bool bIncludeNormals; // 0x168(0x01)
	char pad_169[0x3]; // 0x169(0x03)
	float MorphDeltaZeroThreshold; // 0x16c(0x04)
	float MorphCompressionLevel; // 0x170(0x04)
	enum class EMLDeformerMaskChannel MaskChannel; // 0x174(0x01)
	bool bInvertMaskChannel; // 0x175(0x01)
	char pad_176[0x12]; // 0x176(0x12)

	void SetMorphTargetsMaxWeights(struct TArray<float>& MaxWeights); // Function MLDeformerFramework.MLDeformerMorphModel.SetMorphTargetsMaxWeights // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xad65b90
	void SetMorphTargetsErrorOrder(struct TArray<int32_t>& MorphTargetOrder, struct TArray<float>& ErrorValues); // Function MLDeformerFramework.MLDeformerMorphModel.SetMorphTargetsErrorOrder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xad65cb0
	void SetMorphTargetDeltas(struct TArray<struct FVector3f>& Deltas); // Function MLDeformerFramework.MLDeformerMorphModel.SetMorphTargetDeltas // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xad65ed0
	void SetMorphTargetDeltaFloats(struct TArray<float>& Deltas); // Function MLDeformerFramework.MLDeformerMorphModel.SetMorphTargetDeltaFloats // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xad65ff0
};

// Class MLDeformerFramework.MLDeformerMorphModelInputInfo
// Size: 0x68 (Inherited: 0x68)
struct UMLDeformerMorphModelInputInfo : UMLDeformerInputInfo {
};

// Class MLDeformerFramework.MLDeformerMorphModelInstance
// Size: 0xb0 (Inherited: 0x90)
struct UMLDeformerMorphModelInstance : UMLDeformerModelInstance {
	char pad_90[0x20]; // 0x90(0x20)
};

