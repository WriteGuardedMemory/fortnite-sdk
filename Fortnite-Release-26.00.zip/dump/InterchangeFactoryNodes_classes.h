// Class InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode
// Size: 0x170 (Inherited: 0x140)
struct UInterchangeAnimationTrackSetFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x30]; // 0x140(0x30)

	bool SetCustomFrameRate(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode.SetCustomFrameRate // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba27450
	bool RemoveCustomAnimationTrackUid(struct FString AnimationTrackUid); // Function InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode.RemoveCustomAnimationTrackUid // (Final|Native|Public|BlueprintCallable) // @ game+0xb9df8c0
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	bool GetCustomFrameRate(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode.GetCustomFrameRate // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba27230
	void GetCustomAnimationTrackUids(struct TArray<struct FString>& OutAnimationTrackUids); // Function InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode.GetCustomAnimationTrackUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb9dfcf0
	int32_t GetCustomAnimationTrackUidCount(); // Function InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode.GetCustomAnimationTrackUidCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb9dfe50
	void GetCustomAnimationTrackUid(int32_t Index, struct FString& OutAnimationTrackUid); // Function InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode.GetCustomAnimationTrackUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb9dfb20
	bool AddCustomAnimationTrackUid(struct FString AnimationTrackUid); // Function InterchangeFactoryNodes.InterchangeAnimationTrackSetFactoryNode.AddCustomAnimationTrackUid // (Final|Native|Public|BlueprintCallable) // @ game+0xb9df9f0
};

// Class InterchangeFactoryNodes.InterchangeActorFactoryNode
// Size: 0x170 (Inherited: 0x140)
struct UInterchangeActorFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x30]; // 0x140(0x30)

	bool SetCustomMobility(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeActorFactoryNode.SetCustomMobility // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba53290
	bool SetCustomGlobalTransform(struct FTransform& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeActorFactoryNode.SetCustomGlobalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba53770
	bool SetCustomActorClassName(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeActorFactoryNode.SetCustomActorClassName // (Final|Native|Public|BlueprintCallable) // @ game+0xba53520
	bool GetCustomMobility(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeActorFactoryNode.GetCustomMobility // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba53420
	bool GetCustomGlobalTransform(struct FTransform& AttributeValue); // Function InterchangeFactoryNodes.InterchangeActorFactoryNode.GetCustomGlobalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba53970
	bool GetCustomActorClassName(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeActorFactoryNode.GetCustomActorClassName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba53640
};

// Class InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode
// Size: 0x1b0 (Inherited: 0x170)
struct UInterchangePhysicalCameraFactoryNode : UInterchangeActorFactoryNode {
	char pad_170[0x40]; // 0x170(0x40)

	bool SetCustomSensorWidth(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode.SetCustomSensorWidth // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2d510
	bool SetCustomSensorHeight(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode.SetCustomSensorHeight // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2d150
	bool SetCustomFocusMethod(enum class ECameraFocusMethod& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode.SetCustomFocusMethod // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2cd90
	bool SetCustomFocalLength(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode.SetCustomFocalLength // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2d8d0
	bool GetCustomSensorWidth(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode.GetCustomSensorWidth // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2d6b0
	bool GetCustomSensorHeight(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode.GetCustomSensorHeight // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2d2f0
	bool GetCustomFocusMethod(enum class ECameraFocusMethod& AttributeValue); // Function InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode.GetCustomFocusMethod // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2cf30
	bool GetCustomFocalLength(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangePhysicalCameraFactoryNode.GetCustomFocalLength // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2da70
};

// Class InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode
// Size: 0x1d0 (Inherited: 0x170)
struct UInterchangeStandardCameraFactoryNode : UInterchangeActorFactoryNode {
	char pad_170[0x60]; // 0x170(0x60)

	bool SetCustomWidth(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.SetCustomWidth // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2f0a0
	bool SetCustomProjectionMode(enum class ECameraProjectionMode& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.SetCustomProjectionMode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2f460
	bool SetCustomNearClipPlane(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.SetCustomNearClipPlane // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2ece0
	bool SetCustomFieldOfView(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.SetCustomFieldOfView // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2e1a0
	bool SetCustomFarClipPlane(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.SetCustomFarClipPlane // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2e920
	bool SetCustomAspectRatio(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.SetCustomAspectRatio // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba2e560
	bool GetCustomWidth(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.GetCustomWidth // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2f240
	bool GetCustomProjectionMode(enum class ECameraProjectionMode& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.GetCustomProjectionMode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2f600
	bool GetCustomNearClipPlane(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.GetCustomNearClipPlane // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2ee80
	bool GetCustomFieldOfView(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.GetCustomFieldOfView // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2e340
	bool GetCustomFarClipPlane(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.GetCustomFarClipPlane // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2eac0
	bool GetCustomAspectRatio(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStandardCameraFactoryNode.GetCustomAspectRatio // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba2e700
};

// Class InterchangeFactoryNodes.InterchangeBaseLightFactoryNode
// Size: 0x1b0 (Inherited: 0x170)
struct UInterchangeBaseLightFactoryNode : UInterchangeActorFactoryNode {
	char pad_170[0x40]; // 0x170(0x40)

	bool SetCustomUseTemperature(bool AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeBaseLightFactoryNode.SetCustomUseTemperature // (Final|Native|Public|BlueprintCallable) // @ game+0xba303a0
	bool SetCustomTemperature(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeBaseLightFactoryNode.SetCustomTemperature // (Final|Native|Public|BlueprintCallable) // @ game+0xba30750
	bool SetCustomLightColor(struct FColor& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeBaseLightFactoryNode.SetCustomLightColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba30eb0
	bool SetCustomIntensity(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeBaseLightFactoryNode.SetCustomIntensity // (Final|Native|Public|BlueprintCallable) // @ game+0xba30b00
	bool GetCustomUseTemperature(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeBaseLightFactoryNode.GetCustomUseTemperature // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba30530
	bool GetCustomTemperature(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeBaseLightFactoryNode.GetCustomTemperature // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba308e0
	bool GetCustomLightColor(struct FColor& AttributeValue); // Function InterchangeFactoryNodes.InterchangeBaseLightFactoryNode.GetCustomLightColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba31040
	bool GetCustomIntensity(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeBaseLightFactoryNode.GetCustomIntensity // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba30c90
};

// Class InterchangeFactoryNodes.InterchangeDirectionalLightFactoryNode
// Size: 0x1b0 (Inherited: 0x1b0)
struct UInterchangeDirectionalLightFactoryNode : UInterchangeBaseLightFactoryNode {
};

// Class InterchangeFactoryNodes.InterchangeLightFactoryNode
// Size: 0x1e0 (Inherited: 0x1b0)
struct UInterchangeLightFactoryNode : UInterchangeBaseLightFactoryNode {
	char pad_1B0[0x30]; // 0x1b0(0x30)

	bool SetCustomIntensityUnits(enum class ELightUnits AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeLightFactoryNode.SetCustomIntensityUnits // (Final|Native|Public|BlueprintCallable) // @ game+0xba31e30
	bool SetCustomIESTexture(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeLightFactoryNode.SetCustomIESTexture // (Final|Native|Public|BlueprintCallable) // @ game+0xba31830
	bool SetCustomAttenuationRadius(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeLightFactoryNode.SetCustomAttenuationRadius // (Final|Native|Public|BlueprintCallable) // @ game+0xba31a80
	bool GetCustomIntensityUnits(enum class ELightUnits& AttributeValue); // Function InterchangeFactoryNodes.InterchangeLightFactoryNode.GetCustomIntensityUnits // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba31fc0
	bool GetCustomIESTexture(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeLightFactoryNode.GetCustomIESTexture // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba31950
	bool GetCustomAttenuationRadius(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeLightFactoryNode.GetCustomAttenuationRadius // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba31c10
};

// Class InterchangeFactoryNodes.InterchangeRectLightFactoryNode
// Size: 0x200 (Inherited: 0x1e0)
struct UInterchangeRectLightFactoryNode : UInterchangeLightFactoryNode {
	char pad_1E0[0x20]; // 0x1e0(0x20)

	bool SetCustomSourceWidth(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeRectLightFactoryNode.SetCustomSourceWidth // (Final|Native|Public|BlueprintCallable) // @ game+0xba329d0
	bool SetCustomSourceHeight(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeRectLightFactoryNode.SetCustomSourceHeight // (Final|Native|Public|BlueprintCallable) // @ game+0xba32620
	bool GetCustomSourceWidth(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeRectLightFactoryNode.GetCustomSourceWidth // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba32b60
	bool GetCustomSourceHeight(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeRectLightFactoryNode.GetCustomSourceHeight // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba327b0
};

// Class InterchangeFactoryNodes.InterchangePointLightFactoryNode
// Size: 0x200 (Inherited: 0x1e0)
struct UInterchangePointLightFactoryNode : UInterchangeLightFactoryNode {
	char pad_1E0[0x20]; // 0x1e0(0x20)

	bool SetCustomUseInverseSquaredFalloff(bool AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangePointLightFactoryNode.SetCustomUseInverseSquaredFalloff // (Final|Native|Public|BlueprintCallable) // @ game+0xba33330
	bool SetCustomLightFalloffExponent(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangePointLightFactoryNode.SetCustomLightFalloffExponent // (Final|Native|Public|BlueprintCallable) // @ game+0xba32f80
	bool GetCustomUseInverseSquaredFalloff(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangePointLightFactoryNode.GetCustomUseInverseSquaredFalloff // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba334c0
	bool GetCustomLightFalloffExponent(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangePointLightFactoryNode.GetCustomLightFalloffExponent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba33110
};

// Class InterchangeFactoryNodes.InterchangeSpotLightFactoryNode
// Size: 0x220 (Inherited: 0x200)
struct UInterchangeSpotLightFactoryNode : UInterchangePointLightFactoryNode {
	char pad_200[0x20]; // 0x200(0x20)

	bool SetCustomOuterConeAngle(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeSpotLightFactoryNode.SetCustomOuterConeAngle // (Final|Native|Public|BlueprintCallable) // @ game+0xba33a30
	bool SetCustomInnerConeAngle(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeSpotLightFactoryNode.SetCustomInnerConeAngle // (Final|Native|Public|BlueprintCallable) // @ game+0xba33de0
	bool GetCustomOuterConeAngle(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSpotLightFactoryNode.GetCustomOuterConeAngle // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba33bc0
	bool GetCustomInnerConeAngle(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSpotLightFactoryNode.GetCustomInnerConeAngle // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba33f70
};

// Class InterchangeFactoryNodes.InterchangePhysicsAssetFactoryNode
// Size: 0x170 (Inherited: 0x140)
struct UInterchangePhysicsAssetFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x30]; // 0x140(0x30)

	bool SetCustomSkeletalMeshUid(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangePhysicsAssetFactoryNode.SetCustomSkeletalMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba34c70
	void InitializePhysicsAssetNode(struct FString UniqueID, struct FString DisplayLabel, struct FString InAssetClass); // Function InterchangeFactoryNodes.InterchangePhysicsAssetFactoryNode.InitializePhysicsAssetNode // (Final|Native|Public|BlueprintCallable) // @ game+0xba34ec0
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangePhysicsAssetFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	bool GetCustomSkeletalMeshUid(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangePhysicsAssetFactoryNode.GetCustomSkeletalMeshUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba34d90
};

// Class InterchangeFactoryNodes.InterchangeSceneVariantSetsFactoryNode
// Size: 0x160 (Inherited: 0x140)
struct UInterchangeSceneVariantSetsFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x20]; // 0x140(0x20)

	bool RemoveCustomVariantSetUid(struct FString VariantUid); // Function InterchangeFactoryNodes.InterchangeSceneVariantSetsFactoryNode.RemoveCustomVariantSetUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba354e0
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeSceneVariantSetsFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	void GetCustomVariantSetUids(struct TArray<struct FString>& OutVariantUids); // Function InterchangeFactoryNodes.InterchangeSceneVariantSetsFactoryNode.GetCustomVariantSetUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba35910
	int32_t GetCustomVariantSetUidCount(); // Function InterchangeFactoryNodes.InterchangeSceneVariantSetsFactoryNode.GetCustomVariantSetUidCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba35a70
	void GetCustomVariantSetUid(int32_t Index, struct FString& OutVariantUid); // Function InterchangeFactoryNodes.InterchangeSceneVariantSetsFactoryNode.GetCustomVariantSetUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba35740
	bool AddCustomVariantSetUid(struct FString VariantUid); // Function InterchangeFactoryNodes.InterchangeSceneVariantSetsFactoryNode.AddCustomVariantSetUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba35610
};

// Class InterchangeFactoryNodes.InterchangeSkeletonFactoryNode
// Size: 0x190 (Inherited: 0x140)
struct UInterchangeSkeletonFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x50]; // 0x140(0x50)

	bool SetCustomUseTimeZeroForBindPose(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletonFactoryNode.SetCustomUseTimeZeroForBindPose // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba394b0
	bool SetCustomSkeletalMeshFactoryNodeUid(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletonFactoryNode.SetCustomSkeletalMeshFactoryNodeUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba39260
	bool SetCustomRootJointUid(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletonFactoryNode.SetCustomRootJointUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba397d0
	void InitializeSkeletonNode(struct FString UniqueID, struct FString DisplayLabel, struct FString InAssetClass); // Function InterchangeFactoryNodes.InterchangeSkeletonFactoryNode.InitializeSkeletonNode // (Final|Native|Public|BlueprintCallable) // @ game+0xba39a20
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeSkeletonFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	bool GetCustomUseTimeZeroForBindPose(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletonFactoryNode.GetCustomUseTimeZeroForBindPose // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba395b0
	bool GetCustomSkeletalMeshFactoryNodeUid(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletonFactoryNode.GetCustomSkeletalMeshFactoryNodeUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba39380
	bool GetCustomRootJointUid(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletonFactoryNode.GetCustomRootJointUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba398f0
};

// Class InterchangeFactoryNodes.InterchangeTextureFactoryNode
// Size: 0x3d0 (Inherited: 0x140)
struct UInterchangeTextureFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x290]; // 0x140(0x290)

	bool SetCustomVirtualTextureStreaming(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomVirtualTextureStreaming // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba45500
	bool SetCustomTranslatedTextureNodeUid(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomTranslatedTextureNodeUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba4b880
	bool SetCustomSRGB(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomSRGB // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba45c70
	bool SetCustomPreferCompressedSourceData(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomPreferCompressedSourceData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba43450
	bool SetCustomPowerOfTwoMode(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomPowerOfTwoMode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba46b60
	bool SetCustomPaddingColor(struct FColor& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomPaddingColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba467b0
	bool SetCustomMipLoadOptions(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomMipLoadOptions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba46030
	bool SetCustomMipGenSettings(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomMipGenSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba44da0
	bool SetCustomMaxTextureSize(int32_t& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomMaxTextureSize // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba480a0
	bool SetCustomLossyCompressionAmount(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomLossyCompressionAmount // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba48450
	bool SetCustomLODGroup(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomLODGroup // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba44620
	bool SetCustomLODBias(int32_t& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomLODBias // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba449e0
	bool SetCustomFilter(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomFilter // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba463f0
	bool SetCustomDownscaleOptions(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomDownscaleOptions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba43fc0
	bool SetCustomDownscale(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomDownscale // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba44380
	bool SetCustomDeferCompression(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomDeferCompression // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba48800
	bool SetCustomCompressionSettings(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomCompressionSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba47930
	bool SetCustomCompressionQuality(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomCompressionQuality // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba47cf0
	bool SetCustomCompressionNoAlpha(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomCompressionNoAlpha // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba48bb0
	bool SetCustomCompositeTextureMode(char& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomCompositeTextureMode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba43c10
	bool SetCustomCompositePower(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomCompositePower // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba43850
	bool SetCustomChromaKeyThreshold(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomChromaKeyThreshold // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba49310
	bool SetCustomChromaKeyColor(struct FColor& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomChromaKeyColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba48f60
	bool SetCustombUseLegacyGamma(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustombUseLegacyGamma // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba458c0
	bool SetCustombPreserveBorder(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustombPreserveBorder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba45150
	bool SetCustombFlipGreenChannel(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustombFlipGreenChannel // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba46f10
	bool SetCustombDoScaleMipsForAlphaCoverage(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustombDoScaleMipsForAlphaCoverage // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba471a0
	bool SetCustombChromaKeyTexture(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustombChromaKeyTexture // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba496d0
	bool SetCustomAlphaCoverageThresholds(struct FVector4& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAlphaCoverageThresholds // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba47550
	bool SetCustomAllowNonPowerOfTwo(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAllowNonPowerOfTwo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba43650
	bool SetCustomAdjustVibrance(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAdjustVibrance // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba4ad40
	bool SetCustomAdjustSaturation(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAdjustSaturation // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba4a980
	bool SetCustomAdjustRGBCurve(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAdjustRGBCurve // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba4a5c0
	bool SetCustomAdjustMinAlpha(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAdjustMinAlpha // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba49e40
	bool SetCustomAdjustMaxAlpha(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAdjustMaxAlpha // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba49a80
	bool SetCustomAdjustHue(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAdjustHue // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba4a200
	bool SetCustomAdjustBrightnessCurve(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAdjustBrightnessCurve // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba4b100
	bool SetCustomAdjustBrightness(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.SetCustomAdjustBrightness // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba4b4c0
	void InitializeTextureNode(struct FString UniqueID, struct FString DisplayLabel, struct FString InAssetName); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.InitializeTextureNode // (Final|Native|Public|BlueprintCallable) // @ game+0xba4bad0
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	bool GetCustomVirtualTextureStreaming(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomVirtualTextureStreaming // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba456a0
	bool GetCustomTranslatedTextureNodeUid(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomTranslatedTextureNodeUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba4b9a0
	bool GetCustomSRGB(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomSRGB // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba45e10
	bool GetCustomPreferCompressedSourceData(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomPreferCompressedSourceData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba43550
	bool GetCustomPowerOfTwoMode(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomPowerOfTwoMode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba46cf0
	bool GetCustomPaddingColor(struct FColor& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomPaddingColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba46940
	bool GetCustomMipLoadOptions(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomMipLoadOptions // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba461d0
	bool GetCustomMipGenSettings(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomMipGenSettings // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba44f30
	bool GetCustomMaxTextureSize(int32_t& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomMaxTextureSize // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba48230
	bool GetCustomLossyCompressionAmount(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomLossyCompressionAmount // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba485e0
	bool GetCustomLODGroup(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomLODGroup // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba447c0
	bool GetCustomLODBias(int32_t& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomLODBias // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba44b80
	bool GetCustomFilter(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomFilter // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba46590
	bool GetCustomDownscaleOptions(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomDownscaleOptions // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba44160
	bool GetCustomDownscale(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomDownscale // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba44520
	bool GetCustomDeferCompression(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomDeferCompression // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba48990
	bool GetCustomCompressionSettings(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomCompressionSettings // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba47ad0
	bool GetCustomCompressionQuality(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomCompressionQuality // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba47e80
	bool GetCustomCompressionNoAlpha(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomCompressionNoAlpha // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba48d40
	bool GetCustomCompositeTextureMode(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomCompositeTextureMode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba43da0
	bool GetCustomCompositePower(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomCompositePower // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba439f0
	bool GetCustomChromaKeyThreshold(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomChromaKeyThreshold // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba494b0
	bool GetCustomChromaKeyColor(struct FColor& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomChromaKeyColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba490f0
	bool GetCustombUseLegacyGamma(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustombUseLegacyGamma // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba45a50
	bool GetCustombPreserveBorder(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustombPreserveBorder // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba452e0
	bool GetCustombFlipGreenChannel(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustombFlipGreenChannel // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba470a0
	bool GetCustombDoScaleMipsForAlphaCoverage(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustombDoScaleMipsForAlphaCoverage // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba47330
	bool GetCustombChromaKeyTexture(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustombChromaKeyTexture // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba49860
	bool GetCustomAlphaCoverageThresholds(struct FVector4& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAlphaCoverageThresholds // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba47700
	bool GetCustomAllowNonPowerOfTwo(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAllowNonPowerOfTwo // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba43750
	bool GetCustomAdjustVibrance(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAdjustVibrance // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba4aee0
	bool GetCustomAdjustSaturation(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAdjustSaturation // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba4ab20
	bool GetCustomAdjustRGBCurve(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAdjustRGBCurve // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba4a760
	bool GetCustomAdjustMinAlpha(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAdjustMinAlpha // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba49fe0
	bool GetCustomAdjustMaxAlpha(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAdjustMaxAlpha // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba49c20
	bool GetCustomAdjustHue(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAdjustHue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba4a3a0
	bool GetCustomAdjustBrightnessCurve(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAdjustBrightnessCurve // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba4b2a0
	bool GetCustomAdjustBrightness(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureFactoryNode.GetCustomAdjustBrightness // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba4b660
};

// Class InterchangeFactoryNodes.InterchangeTexture2DArrayFactoryNode
// Size: 0x400 (Inherited: 0x3d0)
struct UInterchangeTexture2DArrayFactoryNode : UInterchangeTextureFactoryNode {
	char pad_3D0[0x30]; // 0x3d0(0x30)

	bool SetCustomAddressZ(char AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTexture2DArrayFactoryNode.SetCustomAddressZ // (Final|Native|Public|BlueprintCallable) // @ game+0xba402e0
	bool GetCustomAddressZ(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTexture2DArrayFactoryNode.GetCustomAddressZ // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba40460
	bool GetCustomAddressY(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTexture2DArrayFactoryNode.GetCustomAddressY // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba40680
	bool GetCustomAddressX(char& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTexture2DArrayFactoryNode.GetCustomAddressX // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba408a0
};

// Class InterchangeFactoryNodes.InterchangeTexture2DFactoryNode
// Size: 0x468 (Inherited: 0x3d0)
struct UInterchangeTexture2DFactoryNode : UInterchangeTextureFactoryNode {
	char pad_3D0[0x98]; // 0x3d0(0x98)

	void SetSourceBlocks(struct TMap<int32_t, struct FString>& InSourceBlocks); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.SetSourceBlocks // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba42250
	void SetSourceBlockByCoordinates(int32_t X, int32_t Y, struct FString InSourceFile); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.SetSourceBlockByCoordinates // (Final|Native|Public|BlueprintCallable) // @ game+0xba41b90
	void SetSourceBlock(int32_t BlockIndex, struct FString InSourceFile); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.SetSourceBlock // (Final|Native|Public|BlueprintCallable) // @ game+0xba419c0
	bool SetCustomAddressY(enum class TextureAddress AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.SetCustomAddressY // (Final|Native|Public|BlueprintCallable) // @ game+0xba42530
	bool SetCustomAddressX(enum class TextureAddress AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.SetCustomAddressX // (Final|Native|Public|BlueprintCallable) // @ game+0xba428e0
	struct TMap<int32_t, struct FString> GetSourceBlocks(); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.GetSourceBlocks // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba42420
	bool GetSourceBlockByCoordinates(int32_t X, int32_t Y, struct FString& OutSourceFile); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.GetSourceBlockByCoordinates // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba41fd0
	bool GetSourceBlock(int32_t BlockIndex, struct FString& OutSourceFile); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.GetSourceBlock // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba41df0
	bool GetCustomAddressY(enum class TextureAddress& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.GetCustomAddressY // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba426c0
	bool GetCustomAddressX(enum class TextureAddress& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTexture2DFactoryNode.GetCustomAddressX // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba42a70
};

// Class InterchangeFactoryNodes.InterchangeTextureCubeArrayFactoryNode
// Size: 0x3d0 (Inherited: 0x3d0)
struct UInterchangeTextureCubeArrayFactoryNode : UInterchangeTextureFactoryNode {
};

// Class InterchangeFactoryNodes.InterchangeTextureCubeFactoryNode
// Size: 0x3d0 (Inherited: 0x3d0)
struct UInterchangeTextureCubeFactoryNode : UInterchangeTextureFactoryNode {
};

// Class InterchangeFactoryNodes.InterchangeTextureLightProfileFactoryNode
// Size: 0x488 (Inherited: 0x468)
struct UInterchangeTextureLightProfileFactoryNode : UInterchangeTexture2DFactoryNode {
	char pad_468[0x20]; // 0x468(0x20)

	bool SetCustomTextureMultiplier(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureLightProfileFactoryNode.SetCustomTextureMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0xba521d0
	bool SetCustomBrightness(float AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeTextureLightProfileFactoryNode.SetCustomBrightness // (Final|Native|Public|BlueprintCallable) // @ game+0xba52570
	bool GetCustomTextureMultiplier(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureLightProfileFactoryNode.GetCustomTextureMultiplier // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba52350
	bool GetCustomBrightness(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeTextureLightProfileFactoryNode.GetCustomBrightness // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba526f0
};

// Class InterchangeFactoryNodes.InterchangeVolumeTextureFactoryNode
// Size: 0x3d0 (Inherited: 0x3d0)
struct UInterchangeVolumeTextureFactoryNode : UInterchangeTextureFactoryNode {
};

// Class InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode
// Size: 0x480 (Inherited: 0x140)
struct UInterchangeAnimSequenceFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x340]; // 0x140(0x340)

	bool SetCustomSkeletonSoftObjectPath(struct FSoftObjectPath& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomSkeletonSoftObjectPath // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba55c10
	bool SetCustomSkeletonFactoryNodeUid(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomSkeletonFactoryNodeUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba59200
	bool SetCustomRemoveCurveRedundantKeys(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomRemoveCurveRedundantKeys // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba57d80
	bool SetCustomMaterialDriveParameterOnCustomAttribute(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomMaterialDriveParameterOnCustomAttribute // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba57170
	bool SetCustomImportBoneTracksSampleRate(double& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomImportBoneTracksSampleRate // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba58e00
	bool SetCustomImportBoneTracksRangeStop(double& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomImportBoneTracksRangeStop // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba58a00
	bool SetCustomImportBoneTracksRangeStart(double& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomImportBoneTracksRangeStart // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba58c00
	bool SetCustomImportBoneTracks(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomImportBoneTracks // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba59000
	bool SetCustomImportAttributeCurves(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomImportAttributeCurves // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba586e0
	bool SetCustomDoNotImportCurveWithZero(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomDoNotImportCurveWithZero // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba583c0
	bool SetCustomDeleteExistingNonCurveCustomAttributes(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomDeleteExistingNonCurveCustomAttributes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba55f90
	bool SetCustomDeleteExistingMorphTargetCurves(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomDeleteExistingMorphTargetCurves // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba57a60
	bool SetCustomDeleteExistingCustomAttributeCurves(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomDeleteExistingCustomAttributeCurves // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba562b0
	bool SetCustomAddCurveMetadataToSkeleton(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetCustomAddCurveMetadataToSkeleton // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba580a0
	void SetAnimationPayloadKeysForSceneNodeUids(struct TMap<struct FString, struct FString>& SceneNodeAnimationPayloadKeyUids, struct TMap<struct FString, char>& SceneNodeAnimationPayloadKeyTypes); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetAnimationPayloadKeysForSceneNodeUids // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba556b0
	void SetAnimationPayloadKeysForMorphTargetNodeUids(struct TMap<struct FString, struct FString>& MorphTargetAnimationPayloadKeyUids, struct TMap<struct FString, char>& MorphTargetAnimationPayloadKeyTypes); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetAnimationPayloadKeysForMorphTargetNodeUids // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba55150
	bool SetAnimatedMaterialCurveSuffixe(struct FString MaterialCurveSuffixe); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetAnimatedMaterialCurveSuffixe // (Final|Native|Public|BlueprintCallable) // @ game+0xba56cd0
	bool SetAnimatedAttributeStepCurveName(struct FString AttributeStepCurveName); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetAnimatedAttributeStepCurveName // (Final|Native|Public|BlueprintCallable) // @ game+0xba56700
	bool SetAnimatedAttributeCurveName(struct FString AttributeCurveName); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.SetAnimatedAttributeCurveName // (Final|Native|Public|BlueprintCallable) // @ game+0xba575c0
	bool RemoveAnimatedMaterialCurveSuffixe(struct FString MaterialCurveSuffixe); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.RemoveAnimatedMaterialCurveSuffixe // (Final|Native|Public|BlueprintCallable) // @ game+0xba56ba0
	bool RemoveAnimatedAttributeStepCurveName(struct FString AttributeStepCurveName); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.RemoveAnimatedAttributeStepCurveName // (Final|Native|Public|BlueprintCallable) // @ game+0xba565d0
	bool RemoveAnimatedAttributeCurveName(struct FString AttributeCurveName); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.RemoveAnimatedAttributeCurveName // (Final|Native|Public|BlueprintCallable) // @ game+0xba57490
	void InitializeAnimSequenceNode(struct FString UniqueID, struct FString DisplayLabel); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.InitializeAnimSequenceNode // (Final|Native|Public|BlueprintCallable) // @ game+0xba59570
	void GetSceneNodeAnimationPayloadKeys(struct TMap<struct FString, struct FInterchangeAnimationPayLoadKey>& OutSceneNodeAnimationPayloadKeys); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetSceneNodeAnimationPayloadKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba55aa0
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	void GetMorphTargetNodeAnimationPayloadKeys(struct TMap<struct FString, struct FInterchangeAnimationPayLoadKey>& OutMorphTargetNodeAnimationPayloads); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetMorphTargetNodeAnimationPayloadKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba55540
	bool GetCustomSkeletonSoftObjectPath(struct FSoftObjectPath& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomSkeletonSoftObjectPath // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba55d40
	bool GetCustomSkeletonFactoryNodeUid(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomSkeletonFactoryNodeUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba59320
	bool GetCustomRemoveCurveRedundantKeys(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomRemoveCurveRedundantKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba57e80
	bool GetCustomMaterialDriveParameterOnCustomAttribute(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomMaterialDriveParameterOnCustomAttribute // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba57270
	bool GetCustomImportBoneTracksSampleRate(double& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomImportBoneTracksSampleRate // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba58f00
	bool GetCustomImportBoneTracksRangeStop(double& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomImportBoneTracksRangeStop // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba58b00
	bool GetCustomImportBoneTracksRangeStart(double& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomImportBoneTracksRangeStart // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba58d00
	bool GetCustomImportBoneTracks(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomImportBoneTracks // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba59100
	bool GetCustomImportAttributeCurves(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomImportAttributeCurves // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba587e0
	bool GetCustomDoNotImportCurveWithZero(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomDoNotImportCurveWithZero // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba584c0
	bool GetCustomDeleteExistingNonCurveCustomAttributes(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomDeleteExistingNonCurveCustomAttributes // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba56090
	bool GetCustomDeleteExistingMorphTargetCurves(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomDeleteExistingMorphTargetCurves // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba57b60
	bool GetCustomDeleteExistingCustomAttributeCurves(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomDeleteExistingCustomAttributeCurves // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba563b0
	bool GetCustomAddCurveMetadataToSkeleton(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetCustomAddCurveMetadataToSkeleton // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba581a0
	int32_t GetAnimatedMaterialCurveSuffixesCount(); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedMaterialCurveSuffixesCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba57130
	void GetAnimatedMaterialCurveSuffixes(struct TArray<struct FString>& OutMaterialCurveSuffixes); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedMaterialCurveSuffixes // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba56fd0
	void GetAnimatedMaterialCurveSuffixe(int32_t Index, struct FString& OutMaterialCurveSuffixe); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedMaterialCurveSuffixe // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba56e00
	int32_t GetAnimatedAttributeStepCurveNamesCount(); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedAttributeStepCurveNamesCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba56b60
	void GetAnimatedAttributeStepCurveNames(struct TArray<struct FString>& OutAttributeStepCurveNames); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedAttributeStepCurveNames // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba56a00
	void GetAnimatedAttributeStepCurveName(int32_t Index, struct FString& OutAttributeStepCurveName); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedAttributeStepCurveName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba56830
	int32_t GetAnimatedAttributeCurveNamesCount(); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedAttributeCurveNamesCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba57a20
	void GetAnimatedAttributeCurveNames(struct TArray<struct FString>& OutAttributeCurveNames); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedAttributeCurveNames // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba578c0
	void GetAnimatedAttributeCurveName(int32_t Index, struct FString& OutAttributeCurveName); // Function InterchangeFactoryNodes.InterchangeAnimSequenceFactoryNode.GetAnimatedAttributeCurveName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba576f0
};

// Class InterchangeFactoryNodes.InterchangeCommonPipelineDataFactoryNode
// Size: 0x160 (Inherited: 0x140)
struct UInterchangeCommonPipelineDataFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x20]; // 0x140(0x20)

	bool SetCustomGlobalOffsetTransform(struct UInterchangeBaseNodeContainer* NodeContainer, struct FTransform& AttributeValue); // Function InterchangeFactoryNodes.InterchangeCommonPipelineDataFactoryNode.SetCustomGlobalOffsetTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba5ee50
	bool SetBakeMeshes(struct UInterchangeBaseNodeContainer* NodeContainer, bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeCommonPipelineDataFactoryNode.SetBakeMeshes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba5ebc0
	bool GetCustomGlobalOffsetTransform(struct FTransform& AttributeValue); // Function InterchangeFactoryNodes.InterchangeCommonPipelineDataFactoryNode.GetCustomGlobalOffsetTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba5f050
	bool GetBakeMeshes(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeCommonPipelineDataFactoryNode.GetBakeMeshes // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba5ed50
};

// Class InterchangeFactoryNodes.InterchangeBaseMaterialFactoryNode
// Size: 0x140 (Inherited: 0x140)
struct UInterchangeBaseMaterialFactoryNode : UInterchangeFactoryBaseNode {
};

// Class InterchangeFactoryNodes.InterchangeMaterialFactoryNode
// Size: 0x1b0 (Inherited: 0x140)
struct UInterchangeMaterialFactoryNode : UInterchangeBaseMaterialFactoryNode {
	char pad_140[0x70]; // 0x140(0x70)

	bool SetCustomTwoSided(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.SetCustomTwoSided // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba63e80
	bool SetCustomTranslucencyLightingMode(enum class ETranslucencyLightingMode& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.SetCustomTranslucencyLightingMode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba644e0
	bool SetCustomShadingModel(enum class EMaterialShadingModel& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.SetCustomShadingModel // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba64780
	bool SetCustomScreenSpaceReflections(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.SetCustomScreenSpaceReflections // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba63500
	bool SetCustomRefractionMethod(enum class ERefractionMode& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.SetCustomRefractionMethod // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba63820
	bool SetCustomOpacityMaskClipValue(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.SetCustomOpacityMaskClipValue // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba63ac0
	bool SetCustomBlendMode(enum class EBlendMode& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.SetCustomBlendMode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba64240
	bool GetTransmissionColorConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetTransmissionColorConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba657a0
	bool GetTangentConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetTangentConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba68120
	bool GetSubsurfaceConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetSubsurfaceConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba67bf0
	bool GetSpecularConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetSpecularConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba69b10
	bool GetRoughnessConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetRoughnessConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba695e0
	bool GetRefractionConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetRefractionConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba66c60
	bool GetOpacityConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetOpacityConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba676c0
	bool GetOcclusionConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetOcclusionConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba67190
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	bool GetNormalConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetNormalConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba68650
	bool GetMetallicConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetMetallicConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba6a040
	bool GetFuzzColorConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetFuzzColorConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba65270
	bool GetEmissiveColorConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetEmissiveColorConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba68b80
	bool GetCustomTwoSided(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetCustomTwoSided // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba64020
	bool GetCustomTranslucencyLightingMode(enum class ETranslucencyLightingMode& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetCustomTranslucencyLightingMode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba64680
	bool GetCustomShadingModel(enum class EMaterialShadingModel& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetCustomShadingModel // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba64920
	bool GetCustomScreenSpaceReflections(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetCustomScreenSpaceReflections // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba63600
	bool GetCustomRefractionMethod(enum class ERefractionMode& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetCustomRefractionMethod // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba639c0
	bool GetCustomOpacityMaskClipValue(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetCustomOpacityMaskClipValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba63c60
	bool GetCustomBlendMode(enum class EBlendMode& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetCustomBlendMode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba643e0
	bool GetClothConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetClothConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba64d40
	bool GetClearCoatRoughnessConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetClearCoatRoughnessConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba66200
	bool GetClearCoatNormalConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetClearCoatNormalConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba65cd0
	bool GetClearCoatConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetClearCoatConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba66730
	bool GetBaseColorConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetBaseColorConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba6a570
	bool GetAnisotropyConnection(struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.GetAnisotropyConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba690b0
	bool ConnectToTransmissionColor(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToTransmissionColor // (Final|Native|Public|BlueprintCallable) // @ game+0xba65680
	bool ConnectToTangent(struct FString ExpressionNodeUid); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToTangent // (Final|Native|Public|BlueprintCallable) // @ game+0xba68000
	bool ConnectToSubsurface(struct FString ExpressionNodeUid); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToSubsurface // (Final|Native|Public|BlueprintCallable) // @ game+0xba67ad0
	bool ConnectToSpecular(struct FString ExpressionNodeUid); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToSpecular // (Final|Native|Public|BlueprintCallable) // @ game+0xba699f0
	bool ConnectToRoughness(struct FString ExpressionNodeUid); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToRoughness // (Final|Native|Public|BlueprintCallable) // @ game+0xba694c0
	bool ConnectToRefraction(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToRefraction // (Final|Native|Public|BlueprintCallable) // @ game+0xba66b40
	bool ConnectToOpacity(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToOpacity // (Final|Native|Public|BlueprintCallable) // @ game+0xba675a0
	bool ConnectToOcclusion(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToOcclusion // (Final|Native|Public|BlueprintCallable) // @ game+0xba67070
	bool ConnectToNormal(struct FString ExpressionNodeUid); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToNormal // (Final|Native|Public|BlueprintCallable) // @ game+0xba68530
	bool ConnectToMetallic(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToMetallic // (Final|Native|Public|BlueprintCallable) // @ game+0xba69f20
	bool ConnectToFuzzColor(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToFuzzColor // (Final|Native|Public|BlueprintCallable) // @ game+0xba65150
	bool ConnectToEmissiveColor(struct FString ExpressionNodeUid); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToEmissiveColor // (Final|Native|Public|BlueprintCallable) // @ game+0xba68a60
	bool ConnectToCloth(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToCloth // (Final|Native|Public|BlueprintCallable) // @ game+0xba64c20
	bool ConnectToClearCoatRoughness(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToClearCoatRoughness // (Final|Native|Public|BlueprintCallable) // @ game+0xba660e0
	bool ConnectToClearCoatNormal(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToClearCoatNormal // (Final|Native|Public|BlueprintCallable) // @ game+0xba65bb0
	bool ConnectToClearCoat(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToClearCoat // (Final|Native|Public|BlueprintCallable) // @ game+0xba66610
	bool ConnectToBaseColor(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToBaseColor // (Final|Native|Public|BlueprintCallable) // @ game+0xba6a450
	bool ConnectToAnisotropy(struct FString ExpressionNodeUid); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectToAnisotropy // (Final|Native|Public|BlueprintCallable) // @ game+0xba68f90
	bool ConnectOutputToTransmissionColor(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToTransmissionColor // (Final|Native|Public|BlueprintCallable) // @ game+0xba65480
	bool ConnectOutputToTangent(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToTangent // (Final|Native|Public|BlueprintCallable) // @ game+0xba67e00
	bool ConnectOutputToSubsurface(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToSubsurface // (Final|Native|Public|BlueprintCallable) // @ game+0xba678d0
	bool ConnectOutputToSpecular(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToSpecular // (Final|Native|Public|BlueprintCallable) // @ game+0xba697f0
	bool ConnectOutputToRoughness(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToRoughness // (Final|Native|Public|BlueprintCallable) // @ game+0xba692c0
	bool ConnectOutputToRefraction(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToRefraction // (Final|Native|Public|BlueprintCallable) // @ game+0xba66940
	bool ConnectOutputToOpacity(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToOpacity // (Final|Native|Public|BlueprintCallable) // @ game+0xba673a0
	bool ConnectOutputToOcclusion(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToOcclusion // (Final|Native|Public|BlueprintCallable) // @ game+0xba66e70
	bool ConnectOutputToNormal(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToNormal // (Final|Native|Public|BlueprintCallable) // @ game+0xba68330
	bool ConnectOutputToMetallic(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToMetallic // (Final|Native|Public|BlueprintCallable) // @ game+0xba69d20
	bool ConnectOutputToFuzzColor(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToFuzzColor // (Final|Native|Public|BlueprintCallable) // @ game+0xba64f50
	bool ConnectOutputToEmissiveColor(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToEmissiveColor // (Final|Native|Public|BlueprintCallable) // @ game+0xba68860
	bool ConnectOutputToCloth(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToCloth // (Final|Native|Public|BlueprintCallable) // @ game+0xba64a20
	bool ConnectOutputToClearCoatRoughness(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToClearCoatRoughness // (Final|Native|Public|BlueprintCallable) // @ game+0xba65ee0
	bool ConnectOutputToClearCoatNormal(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToClearCoatNormal // (Final|Native|Public|BlueprintCallable) // @ game+0xba659b0
	bool ConnectOutputToClearCoat(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToClearCoat // (Final|Native|Public|BlueprintCallable) // @ game+0xba66410
	bool ConnectOutputToBaseColor(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToBaseColor // (Final|Native|Public|BlueprintCallable) // @ game+0xba6a250
	bool ConnectOutputToAnisotropy(struct FString ExpressionNodeUid, struct FString OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFactoryNode.ConnectOutputToAnisotropy // (Final|Native|Public|BlueprintCallable) // @ game+0xba68d90
};

// Class InterchangeFactoryNodes.InterchangeMaterialExpressionFactoryNode
// Size: 0x150 (Inherited: 0x140)
struct UInterchangeMaterialExpressionFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x10]; // 0x140(0x10)

	bool SetCustomExpressionClassName(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialExpressionFactoryNode.SetCustomExpressionClassName // (Final|Native|Public|BlueprintCallable) // @ game+0xba6bbb0
	bool GetCustomExpressionClassName(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialExpressionFactoryNode.GetCustomExpressionClassName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba6bcd0
};

// Class InterchangeFactoryNodes.InterchangeMaterialInstanceFactoryNode
// Size: 0x160 (Inherited: 0x140)
struct UInterchangeMaterialInstanceFactoryNode : UInterchangeBaseMaterialFactoryNode {
	char pad_140[0x20]; // 0x140(0x20)

	bool SetCustomParent(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialInstanceFactoryNode.SetCustomParent // (Final|Native|Public|BlueprintCallable) // @ game+0xba6c140
	bool SetCustomInstanceClassName(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialInstanceFactoryNode.SetCustomInstanceClassName // (Final|Native|Public|BlueprintCallable) // @ game+0xba6c390
	bool GetCustomParent(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialInstanceFactoryNode.GetCustomParent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba6c260
	bool GetCustomInstanceClassName(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialInstanceFactoryNode.GetCustomInstanceClassName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba6c4b0
};

// Class InterchangeFactoryNodes.InterchangeMaterialFunctionCallExpressionFactoryNode
// Size: 0x160 (Inherited: 0x150)
struct UInterchangeMaterialFunctionCallExpressionFactoryNode : UInterchangeMaterialExpressionFactoryNode {
	char pad_150[0x10]; // 0x150(0x10)

	bool SetCustomMaterialFunctionDependency(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFunctionCallExpressionFactoryNode.SetCustomMaterialFunctionDependency // (Final|Native|Public|BlueprintCallable) // @ game+0xba6c7f0
	bool GetCustomMaterialFunctionDependency(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMaterialFunctionCallExpressionFactoryNode.GetCustomMaterialFunctionDependency // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba6c910
};

// Class InterchangeFactoryNodes.InterchangeMaterialFunctionFactoryNode
// Size: 0x140 (Inherited: 0x140)
struct UInterchangeMaterialFunctionFactoryNode : UInterchangeBaseMaterialFactoryNode {

	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeMaterialFunctionFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	bool GetInputConnection(struct FString InputName, struct FString& ExpressionNodeUid, struct FString& OutputName); // Function InterchangeFactoryNodes.InterchangeMaterialFunctionFactoryNode.GetInputConnection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba6cce0
};

// Class InterchangeFactoryNodes.InterchangeMeshActorFactoryNode
// Size: 0x208 (Inherited: 0x170)
struct UInterchangeMeshActorFactoryNode : UInterchangeActorFactoryNode {
	char pad_170[0x98]; // 0x170(0x98)

	bool SetSlotMaterialDependencyUid(struct FString SlotName, struct FString MaterialDependencyUid); // Function InterchangeFactoryNodes.InterchangeMeshActorFactoryNode.SetSlotMaterialDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0xb9df250
	bool SetCustomGeometricTransform(struct FTransform& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshActorFactoryNode.SetCustomGeometricTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba74ed0
	bool SetCustomAnimationAssetUidToPlay(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshActorFactoryNode.SetCustomAnimationAssetUidToPlay // (Final|Native|Public|BlueprintCallable) // @ game+0xba752c0
	bool RemoveSlotMaterialDependencyUid(struct FString SlotName); // Function InterchangeFactoryNodes.InterchangeMeshActorFactoryNode.RemoveSlotMaterialDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0xb9df120
	bool GetSlotMaterialDependencyUid(struct FString SlotName, struct FString& OutMaterialDependency); // Function InterchangeFactoryNodes.InterchangeMeshActorFactoryNode.GetSlotMaterialDependencyUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb9df470
	void GetSlotMaterialDependencies(struct TMap<struct FString, struct FString>& OutMaterialDependencies); // Function InterchangeFactoryNodes.InterchangeMeshActorFactoryNode.GetSlotMaterialDependencies // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb9df670
	bool GetCustomGeometricTransform(struct FTransform& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshActorFactoryNode.GetCustomGeometricTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba75030
	bool GetCustomAnimationAssetUidToPlay(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshActorFactoryNode.GetCustomAnimationAssetUidToPlay // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba75190
};

// Class InterchangeFactoryNodes.InterchangeMeshFactoryNode
// Size: 0x2b0 (Inherited: 0x140)
struct UInterchangeMeshFactoryNode : UInterchangeFactoryBaseNode {
	char pad_140[0x170]; // 0x140(0x170)

	bool SetSlotMaterialDependencyUid(struct FString SlotName, struct FString MaterialDependencyUid); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetSlotMaterialDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba78290
	bool SetCustomVertexColorReplace(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomVertexColorReplace // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba78d00
	bool SetCustomVertexColorOverride(struct FColor& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomVertexColorOverride // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba78900
	bool SetCustomVertexColorIgnore(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomVertexColorIgnore // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba78b00
	bool SetCustomUseMikkTSpace(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomUseMikkTSpace // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba77380
	bool SetCustomUseHighPrecisionTangentBasis(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomUseHighPrecisionTangentBasis // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba76c00
	bool SetCustomUseFullPrecisionUVs(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomUseFullPrecisionUVs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba76840
	bool SetCustomUseBackwardsCompatibleF16TruncUVs(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomUseBackwardsCompatibleF16TruncUVs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba76480
	bool SetCustomRemoveDegenerates(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomRemoveDegenerates // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba760c0
	bool SetCustomRecomputeTangents(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomRecomputeTangents // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba77740
	bool SetCustomRecomputeNormals(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomRecomputeNormals // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba77b00
	bool SetCustomLODGroup(struct FName& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomLODGroup // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba77ec0
	bool SetCustomComputeWeightedNormals(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.SetCustomComputeWeightedNormals // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba76fc0
	bool RemoveSlotMaterialDependencyUid(struct FString SlotName); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.RemoveSlotMaterialDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba78150
	bool RemoveLodDataUniqueId(struct FString LodDataUniqueId); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.RemoveLodDataUniqueId // (Final|Native|Public|BlueprintCallable) // @ game+0xba78f00
	bool GetSlotMaterialDependencyUid(struct FString SlotName, struct FString& OutMaterialDependency); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetSlotMaterialDependencyUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba784b0
	void GetSlotMaterialDependencies(struct TMap<struct FString, struct FString>& OutMaterialDependencies); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetSlotMaterialDependencies // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba786b0
	void GetLodDataUniqueIds(struct TArray<struct FString>& OutLodDataUniqueIds); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetLodDataUniqueIds // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba79160
	int32_t GetLodDataCount(); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetLodDataCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba792c0
	bool GetCustomVertexColorReplace(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomVertexColorReplace // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba78e00
	bool GetCustomVertexColorOverride(struct FColor& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomVertexColorOverride // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba78a00
	bool GetCustomVertexColorIgnore(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomVertexColorIgnore // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba78c00
	bool GetCustomUseMikkTSpace(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomUseMikkTSpace // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba77520
	bool GetCustomUseHighPrecisionTangentBasis(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomUseHighPrecisionTangentBasis // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba76da0
	bool GetCustomUseFullPrecisionUVs(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomUseFullPrecisionUVs // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba769e0
	bool GetCustomUseBackwardsCompatibleF16TruncUVs(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomUseBackwardsCompatibleF16TruncUVs // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba76620
	bool GetCustomRemoveDegenerates(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomRemoveDegenerates // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba76260
	bool GetCustomRecomputeTangents(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomRecomputeTangents // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba778e0
	bool GetCustomRecomputeNormals(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomRecomputeNormals // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba77ca0
	bool GetCustomLODGroup(struct FName& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomLODGroup // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba78050
	bool GetCustomComputeWeightedNormals(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.GetCustomComputeWeightedNormals // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba77160
	bool AddLodDataUniqueId(struct FString LodDataUniqueId); // Function InterchangeFactoryNodes.InterchangeMeshFactoryNode.AddLodDataUniqueId // (Final|Native|Public|BlueprintCallable) // @ game+0xba79030
};

// Class InterchangeFactoryNodes.InterchangeSceneImportAssetFactoryNode
// Size: 0x140 (Inherited: 0x140)
struct UInterchangeSceneImportAssetFactoryNode : UInterchangeFactoryBaseNode {
};

// Class InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode
// Size: 0x378 (Inherited: 0x2b0)
struct UInterchangeSkeletalMeshFactoryNode : UInterchangeMeshFactoryNode {
	char pad_2B0[0xc8]; // 0x2b0(0xc8)

	bool SetCustomUseHighPrecisionSkinWeights(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomUseHighPrecisionSkinWeights // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba808c0
	bool SetCustomThresholdUV(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomThresholdUV // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba7fd80
	bool SetCustomThresholdTangentNormal(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomThresholdTangentNormal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba80140
	bool SetCustomThresholdPosition(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomThresholdPosition // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba80500
	bool SetCustomSkeletonSoftObjectPath(struct FSoftObjectPath& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomSkeletonSoftObjectPath // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba81950
	bool SetCustomPhysicAssetSoftObjectPath(struct FSoftObjectPath& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomPhysicAssetSoftObjectPath // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba80f90
	bool SetCustomMorphThresholdPosition(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomMorphThresholdPosition // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba7f9c0
	bool SetCustomImportMorphTarget(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomImportMorphTarget // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba81630
	bool SetCustomImportContentType(enum class EInterchangeSkeletalMeshContentType& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomImportContentType // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba80c80
	bool SetCustomCreatePhysicsAsset(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomCreatePhysicsAsset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba81310
	bool SetCustomBoneInfluenceLimit(int32_t& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.SetCustomBoneInfluenceLimit // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba7f600
	void InitializeSkeletalMeshNode(struct FString UniqueID, struct FString DisplayLabel, struct FString InAssetClass); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.InitializeSkeletalMeshNode // (Final|Native|Public|BlueprintCallable) // @ game+0xba81cd0
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	bool GetCustomUseHighPrecisionSkinWeights(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomUseHighPrecisionSkinWeights // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba80a60
	bool GetCustomThresholdUV(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomThresholdUV // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba7ff20
	bool GetCustomThresholdTangentNormal(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomThresholdTangentNormal // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba802e0
	bool GetCustomThresholdPosition(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomThresholdPosition // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba806a0
	bool GetCustomSkeletonSoftObjectPath(struct FSoftObjectPath& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomSkeletonSoftObjectPath // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba81a80
	bool GetCustomPhysicAssetSoftObjectPath(struct FSoftObjectPath& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomPhysicAssetSoftObjectPath // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba810c0
	bool GetCustomMorphThresholdPosition(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomMorphThresholdPosition // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba7fb60
	bool GetCustomImportMorphTarget(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomImportMorphTarget // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba81730
	bool GetCustomImportContentType(enum class EInterchangeSkeletalMeshContentType& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomImportContentType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba80d80
	bool GetCustomCreatePhysicsAsset(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomCreatePhysicsAsset // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba81410
	bool GetCustomBoneInfluenceLimit(int32_t& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshFactoryNode.GetCustomBoneInfluenceLimit // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba7f7a0
};

// Class InterchangeFactoryNodes.InterchangeSkeletalMeshLodDataNode
// Size: 0x170 (Inherited: 0x140)
struct UInterchangeSkeletalMeshLodDataNode : UInterchangeFactoryBaseNode {
	char pad_140[0x30]; // 0x140(0x30)

	bool SetCustomSkeletonUid(struct FString AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshLodDataNode.SetCustomSkeletonUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba86320
	bool RemoveMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshLodDataNode.RemoveMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xb9df8c0
	bool RemoveAllMeshes(); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshLodDataNode.RemoveAllMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0xba862e0
	int32_t GetMeshUidsCount(); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshLodDataNode.GetMeshUidsCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb9dfe50
	void GetMeshUids(struct TArray<struct FString>& OutMeshNames); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshLodDataNode.GetMeshUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb9dfcf0
	bool GetCustomSkeletonUid(struct FString& AttributeValue); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshLodDataNode.GetCustomSkeletonUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba86440
	bool AddMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeSkeletalMeshLodDataNode.AddMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xb9df9f0
};

// Class InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode
// Size: 0x398 (Inherited: 0x2b0)
struct UInterchangeStaticMeshFactoryNode : UInterchangeMeshFactoryNode {
	char pad_2B0[0xe8]; // 0x2b0(0xe8)

	bool SetCustomSupportFaceRemap(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomSupportFaceRemap // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba891a0
	bool SetCustomSrcLightmapIndex(int32_t& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomSrcLightmapIndex // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba88a20
	bool SetCustomMinLightmapResolution(int32_t& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomMinLightmapResolution // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba88de0
	bool SetCustomMaxLumenMeshCards(int32_t& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomMaxLumenMeshCards // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba876f0
	bool SetCustomGenerateLightmapUVs(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomGenerateLightmapUVs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba89920
	bool SetCustomGenerateDistanceFieldAsIfTwoSided(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomGenerateDistanceFieldAsIfTwoSided // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba89560
	bool SetCustomDstLightmapIndex(int32_t& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomDstLightmapIndex // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba88660
	bool SetCustomDistanceFieldResolutionScale(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomDistanceFieldResolutionScale // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba87ef0
	bool SetCustomDistanceFieldReplacementMesh(struct FSoftObjectPath& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomDistanceFieldReplacementMesh // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba87ab0
	bool SetCustomBuildScale3D(struct FVector& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomBuildScale3D // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xba882b0
	bool SetCustomBuildReversedIndexBuffer(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomBuildReversedIndexBuffer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba89ce0
	bool SetCustomBuildNanite(bool& AttributeValue, bool bAddApplyDelegate); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.SetCustomBuildNanite // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba8a610
	bool RemoveSocketUd(struct FString SocketUid); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.RemoveSocketUd // (Final|Native|Public|BlueprintCallable) // @ game+0xba8a0a0
	void InitializeStaticMeshNode(struct FString UniqueID, struct FString DisplayLabel, struct FString InAssetClass); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.InitializeStaticMeshNode // (Final|Native|Public|BlueprintCallable) // @ game+0xba8a9a0
	void GetSocketUids(struct TArray<struct FString>& OutSocketUids); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetSocketUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba8a470
	int32_t GetSocketUidCount(); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetSocketUidCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba8a5d0
	struct UObject* GetObjectClass(); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetObjectClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x96bee40
	bool GetCustomSupportFaceRemap(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomSupportFaceRemap // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba89340
	bool GetCustomSrcLightmapIndex(int32_t& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomSrcLightmapIndex // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba88bc0
	bool GetCustomMinLightmapResolution(int32_t& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomMinLightmapResolution // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba88f80
	bool GetCustomMaxLumenMeshCards(int32_t& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomMaxLumenMeshCards // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba87890
	bool GetCustomGenerateLightmapUVs(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomGenerateLightmapUVs // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba89ac0
	bool GetCustomGenerateDistanceFieldAsIfTwoSided(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomGenerateDistanceFieldAsIfTwoSided // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba89700
	bool GetCustomDstLightmapIndex(int32_t& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomDstLightmapIndex // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba88800
	bool GetCustomDistanceFieldResolutionScale(float& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomDistanceFieldResolutionScale // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba88090
	bool GetCustomDistanceFieldReplacementMesh(struct FSoftObjectPath& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomDistanceFieldReplacementMesh // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba87ca0
	bool GetCustomBuildScale3D(struct FVector& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomBuildScale3D // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xba88440
	bool GetCustomBuildReversedIndexBuffer(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomBuildReversedIndexBuffer // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba89e80
	bool GetCustomBuildNanite(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.GetCustomBuildNanite // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba8a780
	bool AddSocketUids(struct TArray<struct FString>& InSocketUids); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.AddSocketUids // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xba8a1d0
	bool AddSocketUid(struct FString SocketUid); // Function InterchangeFactoryNodes.InterchangeStaticMeshFactoryNode.AddSocketUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba8a340
};

// Class InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode
// Size: 0x200 (Inherited: 0x140)
struct UInterchangeStaticMeshLodDataNode : UInterchangeFactoryBaseNode {
	char pad_140[0xc0]; // 0x140(0xc0)

	bool SetOneConvexHullPerUCX(bool AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.SetOneConvexHullPerUCX // (Final|Native|Public|BlueprintCallable) // @ game+0xba8fb20
	bool SetImportCollision(bool AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.SetImportCollision // (Final|Native|Public|BlueprintCallable) // @ game+0xba8f930
	bool RemoveSphereCollisionMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveSphereCollisionMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba90190
	bool RemoveMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba354e0
	bool RemoveConvexCollisionMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveConvexCollisionMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba8fd50
	bool RemoveCapsuleCollisionMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveCapsuleCollisionMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba905d0
	bool RemoveBoxCollisionMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveBoxCollisionMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba90a10
	bool RemoveAllSphereCollisionMeshes(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveAllSphereCollisionMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0xba90150
	bool RemoveAllMeshes(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveAllMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0xba90e10
	bool RemoveAllConvexCollisionMeshes(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveAllConvexCollisionMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0xba8fd10
	bool RemoveAllCapsuleCollisionMeshes(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveAllCapsuleCollisionMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0xba90590
	bool RemoveAllBoxCollisionMeshes(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.RemoveAllBoxCollisionMeshes // (Final|Native|Public|BlueprintCallable) // @ game+0xba909d0
	int32_t GetSphereCollisionMeshUidsCount(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetSphereCollisionMeshUidsCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba90550
	void GetSphereCollisionMeshUids(struct TArray<struct FString>& OutMeshNames); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetSphereCollisionMeshUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba903f0
	bool GetOneConvexHullPerUCX(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetOneConvexHullPerUCX // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba8fc10
	int32_t GetMeshUidsCount(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetMeshUidsCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba35a70
	void GetMeshUids(struct TArray<struct FString>& OutMeshNames); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetMeshUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba35910
	bool GetImportCollision(bool& AttributeValue); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetImportCollision // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba8fa20
	int32_t GetConvexCollisionMeshUidsCount(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetConvexCollisionMeshUidsCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba90110
	void GetConvexCollisionMeshUids(struct TArray<struct FString>& OutMeshNames); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetConvexCollisionMeshUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba8ffb0
	int32_t GetCapsuleCollisionMeshUidsCount(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetCapsuleCollisionMeshUidsCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba90990
	void GetCapsuleCollisionMeshUids(struct TArray<struct FString>& OutMeshNames); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetCapsuleCollisionMeshUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba90830
	int32_t GetBoxCollisionMeshUidsCount(); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetBoxCollisionMeshUidsCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xba90dd0
	void GetBoxCollisionMeshUids(struct TArray<struct FString>& OutMeshNames); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.GetBoxCollisionMeshUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xba90c70
	bool AddSphereCollisionMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.AddSphereCollisionMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba902c0
	bool AddMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.AddMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba35610
	bool AddConvexCollisionMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.AddConvexCollisionMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba8fe80
	bool AddCapsuleCollisionMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.AddCapsuleCollisionMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba90700
	bool AddBoxCollisionMeshUid(struct FString MeshName); // Function InterchangeFactoryNodes.InterchangeStaticMeshLodDataNode.AddBoxCollisionMeshUid // (Final|Native|Public|BlueprintCallable) // @ game+0xba90b40
};

