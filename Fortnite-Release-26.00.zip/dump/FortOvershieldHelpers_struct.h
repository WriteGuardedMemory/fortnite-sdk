// ScriptStruct FortOvershieldHelpers.FortOvershieldDelegateContainer
// Size: 0x48 (Inherited: 0x00)
struct FFortOvershieldDelegateContainer {
	struct FDelegate OnOvershieldChanged; // 0x00(0x0c)
	struct FDelegate OnShieldedDamage; // 0x0c(0x0c)
	struct FDelegate OnOvershieldedDamage; // 0x18(0x0c)
	struct FDelegate OnShieldDestroyed; // 0x24(0x0c)
	struct FDelegate OnOvershieldDestroyed; // 0x30(0x0c)
	struct FDelegate OnDamageReceived; // 0x3c(0x0c)
};

