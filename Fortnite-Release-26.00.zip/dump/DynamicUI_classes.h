// Class DynamicUI.DynamicUITransitionableWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct UDynamicUITransitionableWidgetInterface : UInterface {

	void BroadcastTransitionCompleted(); // Function DynamicUI.DynamicUITransitionableWidgetInterface.BroadcastTransitionCompleted // (Native|Protected|BlueprintCallable) // @ game+0x5dd6880
};

// Class DynamicUI.DynamicUIDirectorBase
// Size: 0x2b0 (Inherited: 0x290)
struct ADynamicUIDirectorBase : AActor {
	struct TArray<struct UDynamicUIScene*> DefaultScenes; // 0x290(0x10)
	struct TWeakObjectPtr<struct ULocalPlayer> OwningLocalPlayer; // 0x2a0(0x08)
	bool bEnabledDuringReplay; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)

	void RemoveScene(struct UDynamicUIScene* Scene); // Function DynamicUI.DynamicUIDirectorBase.RemoveScene // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd9900
	struct APlayerController* GetOwningLocalPlayerController(); // Function DynamicUI.DynamicUIDirectorBase.GetOwningLocalPlayerController // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dd9ae0
	struct ULocalPlayer* GetOwningLocalPlayer(); // Function DynamicUI.DynamicUIDirectorBase.GetOwningLocalPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dd9b10
	void AddScene(struct UDynamicUIScene* Scene); // Function DynamicUI.DynamicUIDirectorBase.AddScene // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd99f0
};

// Class DynamicUI.DynamicUIConstraintBase
// Size: 0x70 (Inherited: 0x28)
struct UDynamicUIConstraintBase : UObject {
	char pad_28[0x28]; // 0x28(0x28)
	struct FVector2D Offset; // 0x50(0x10)
	struct UDynamicUIConstraintOverrideBase* ConstraintOverride; // 0x60(0x08)
	char bUseOffset : 1; // 0x68(0x01)
	char bUseOverride : 1; // 0x68(0x01)
	char pad_68_2 : 6; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class DynamicUI.DynamicUIConstraintPosition
// Size: 0x88 (Inherited: 0x70)
struct UDynamicUIConstraintPosition : UDynamicUIConstraintBase {
	struct FVector2D Position; // 0x70(0x10)
	enum class EDynamicUIAnchor Anchor; // 0x80(0x04)
	char bUseSafeZone : 1; // 0x84(0x01)
	char pad_84_1 : 7; // 0x84(0x01)
	char pad_85[0x3]; // 0x85(0x03)
};

// Class DynamicUI.DynamicUIConstraintAlignment
// Size: 0x88 (Inherited: 0x70)
struct UDynamicUIConstraintAlignment : UDynamicUIConstraintBase {
	enum class EHorizontalAlignment HorizontalAlignment; // 0x70(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x71(0x01)
	char pad_72[0x2]; // 0x72(0x02)
	enum class EDynamicUIAnchor Anchor; // 0x74(0x04)
	struct FDynamicUIAspectRatio MaxAspectRatio; // 0x78(0x08)
	char bUseSafeZone : 1; // 0x80(0x01)
	char bUseMaxAspectRatio : 1; // 0x80(0x01)
	char pad_80_2 : 6; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// Class DynamicUI.DynamicUIConstraintWidget
// Size: 0xf8 (Inherited: 0x70)
struct UDynamicUIConstraintWidget : UDynamicUIConstraintBase {
	enum class EDynamicUIAnchor Anchor; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FDynamicUIWidgetTarget TargetWidget; // 0x78(0x60)
	enum class EDynamicUIAnchor TargetAnchor; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct TArray<struct UDynamicUIConstraintBase*> Fallbacks; // 0xe0(0x10)
	char bConstrainToUnallowedWidgets : 1; // 0xf0(0x01)
	char bUseFallbacks : 1; // 0xf0(0x01)
	char pad_F0_2 : 6; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
};

// Class DynamicUI.DynamicUIConstraintContainer
// Size: 0x98 (Inherited: 0x70)
struct UDynamicUIConstraintContainer : UDynamicUIConstraintBase {
	struct TArray<struct FDynamicUIWidgetTarget> WidgetsToContain; // 0x70(0x10)
	struct FMargin Padding; // 0x80(0x10)
	char bMustMatchAllWidgets : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class DynamicUI.DynamicUIConstraintReplace
// Size: 0xe8 (Inherited: 0x70)
struct UDynamicUIConstraintReplace : UDynamicUIConstraintBase {
	struct FDynamicUIWidgetTarget TargetWidget; // 0x70(0x60)
	struct TArray<struct UDynamicUIConstraintBase*> Fallbacks; // 0xd0(0x10)
	char bUseFallbacks : 1; // 0xe0(0x01)
	char pad_E0_1 : 7; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
};

// Class DynamicUI.DynamicUIConstraintOverrideBase
// Size: 0x28 (Inherited: 0x28)
struct UDynamicUIConstraintOverrideBase : UObject {
};

// Class DynamicUI.DynamicUIConstraintPlatformOverride
// Size: 0xd0 (Inherited: 0x28)
struct UDynamicUIConstraintPlatformOverride : UDynamicUIConstraintOverrideBase {
	struct TMap<struct FName, struct UDynamicUIConstraintBase*> PlatformVisibilityControls; // 0x28(0x50)
	struct TMap<enum class ECommonInputType, struct UDynamicUIConstraintBase*> InputTypeVisibilityControls; // 0x78(0x50)
	char pad_C8[0x8]; // 0xc8(0x08)
};

// Class DynamicUI.DynamicUIManager
// Size: 0x98 (Inherited: 0x30)
struct UDynamicUIManager : UWorldSubsystem {
	char pad_30[0x18]; // 0x30(0x18)
	struct TMap<struct TWeakObjectPtr<struct ULocalPlayer>, struct FDynamicUIPlayerData> PlayerDataMap; // 0x48(0x50)

	void RemoveScenes(struct TArray<struct UDynamicUIScene*> Scenes, struct APlayerController*& Player); // Function DynamicUI.DynamicUIManager.RemoveScenes // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x5ddfc00
	void RemoveSceneFromFirstLocalPlayer(struct UDynamicUIScene* Scene); // Function DynamicUI.DynamicUIManager.RemoveSceneFromFirstLocalPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x5ddfe80
	void RemoveScene(struct UDynamicUIScene* Scene, struct APlayerController*& Player); // Function DynamicUI.DynamicUIManager.RemoveScene // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x5de0440
	void AddSceneToFirstLocalPlayer(struct UDynamicUIScene* Scene); // Function DynamicUI.DynamicUIManager.AddSceneToFirstLocalPlayer // (Final|Native|Protected|BlueprintCallable) // @ game+0x5de0d00
	void AddScenes(struct TArray<struct UDynamicUIScene*> Scenes, struct APlayerController*& Player); // Function DynamicUI.DynamicUIManager.AddScenes // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x5de0a80
	void AddScene(struct UDynamicUIScene* Scene, struct APlayerController*& Player); // Function DynamicUI.DynamicUIManager.AddScene // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x5de1260
};

// Class DynamicUI.DynamicUIScene
// Size: 0x68 (Inherited: 0x30)
struct UDynamicUIScene : UDataAsset {
	char LayerID; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct FDynamicUIAllowed> Allowed; // 0x38(0x10)
	struct TArray<struct UDynamicUIUnallowBase*> Unallow; // 0x48(0x10)
	struct TArray<struct FDynamicUIPreload> Preload; // 0x58(0x10)
};

// Class DynamicUI.DynamicUISizeBase
// Size: 0x60 (Inherited: 0x28)
struct UDynamicUISizeBase : UObject {
	char pad_28[0x28]; // 0x28(0x28)
	struct UDynamicUISizeOverrideBase* SizeOverride; // 0x50(0x08)
	char bUseOverride : 1; // 0x58(0x01)
	char bUseRenderTransform : 1; // 0x58(0x01)
	char pad_58_2 : 6; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class DynamicUI.DynamicUISizeFixed
// Size: 0x68 (Inherited: 0x60)
struct UDynamicUISizeFixed : UDynamicUISizeBase {
	struct FVector2f Size; // 0x60(0x08)
};

// Class DynamicUI.DynamicUISizeScale
// Size: 0x68 (Inherited: 0x60)
struct UDynamicUISizeScale : UDynamicUISizeBase {
	struct FVector2f Scale; // 0x60(0x08)
};

// Class DynamicUI.DynamicUISizeMatchWidget
// Size: 0xe0 (Inherited: 0x60)
struct UDynamicUISizeMatchWidget : UDynamicUISizeBase {
	struct FDynamicUIWidgetTarget TargetWidget; // 0x60(0x60)
	enum class EDynamicUISizeMatch MatchType; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct TArray<struct UDynamicUISizeBase*> Fallbacks; // 0xc8(0x10)
	char bUseFallbacks : 1; // 0xd8(0x01)
	char pad_D8_1 : 7; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class DynamicUI.DynamicUISizeOverrideBase
// Size: 0x28 (Inherited: 0x28)
struct UDynamicUISizeOverrideBase : UObject {
};

// Class DynamicUI.DynamicUISizeOverridePlatform
// Size: 0xd0 (Inherited: 0x28)
struct UDynamicUISizeOverridePlatform : UDynamicUISizeOverrideBase {
	struct TMap<struct FName, struct UDynamicUISizeBase*> PlatformOverrides; // 0x28(0x50)
	struct TMap<enum class ECommonInputType, struct UDynamicUISizeBase*> InputTypeOverrides; // 0x78(0x50)
	char pad_C8[0x8]; // 0xc8(0x08)
};

// Class DynamicUI.DynamicUIUnallowBase
// Size: 0x30 (Inherited: 0x28)
struct UDynamicUIUnallowBase : UObject {
	enum class EDynamicUIUnallowedBehavior Behavior; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// Class DynamicUI.DynamicUIUnallowWidget
// Size: 0x98 (Inherited: 0x30)
struct UDynamicUIUnallowWidget : UDynamicUIUnallowBase {
	struct FDynamicUIWidgetTarget Widget; // 0x30(0x60)
	char bTargetAll : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class DynamicUI.DynamicUIUnallowLayer
// Size: 0x38 (Inherited: 0x30)
struct UDynamicUIUnallowLayer : UDynamicUIUnallowBase {
	char LayerID; // 0x30(0x01)
	enum class EDynamicUIUnallowLayerComparison Comparison; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
};

// Class DynamicUI.DynamicUIVisualizerWidget
// Size: 0x2d0 (Inherited: 0x2a8)
struct UDynamicUIVisualizerWidget : UUserWidget {
	struct TArray<struct UDynamicUIScene*> Scenes; // 0x2a8(0x10)
	bool bRefresh; // 0x2b8(0x01)
	char pad_2B9[0x17]; // 0x2b9(0x17)
};

