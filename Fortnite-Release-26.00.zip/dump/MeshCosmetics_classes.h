// Class MeshCosmetics.MeshCosmeticsStep_CompileCustomizableObjects
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_CompileCustomizableObjects : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsAdditionalData_SpecifyMaterialOnlyParams
// Size: 0x38 (Inherited: 0x28)
struct UMeshCosmeticsAdditionalData_SpecifyMaterialOnlyParams : UFortCosmeticItemAdditionalData {
	struct TArray<struct FName> MaterialOnlyParameterNames; // 0x28(0x10)
};

// Class MeshCosmetics.MeshCosmeticsStep_HandleGeneratedMesh
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_HandleGeneratedMesh : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsStep_PlaceComponent
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_PlaceComponent : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsApparelItemDefinition
// Size: 0x798 (Inherited: 0x770)
struct UMeshCosmeticsApparelItemDefinition : UFortApparelItemDefinition {
	struct FCosmeticSlotSelector SlotValidWithin; // 0x770(0x02)
	char pad_772[0x6]; // 0x772(0x06)
	struct FApparelCustomizableItemReference Parameter; // 0x778(0x20)
};

// Class MeshCosmetics.FortCustomizableObjectParameterVariant
// Size: 0x80 (Inherited: 0x70)
struct UFortCustomizableObjectParameterVariant : UFortCosmeticVariantBackedByArray {
	struct TArray<struct FCustomizableObjectParamsVariantDef> ParameterOptions; // 0x70(0x10)

	void ApplyVariants(struct AActor* Actor, struct FFortAthenaLoadout& Loadout); // Function MeshCosmetics.FortCustomizableObjectParameterVariant.ApplyVariants // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0xac54ad0
};

// Class MeshCosmetics.FortCustomizableObjectSprayVariant
// Size: 0x2a8 (Inherited: 0x70)
struct UFortCustomizableObjectSprayVariant : UFortCosmeticVariant {
	struct FGameplayTag ActiveSelectionTag; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FString EnabledParamName; // 0x78(0x10)
	struct FString ProjectorParamName; // 0x88(0x10)
	struct FString TextureParamName; // 0x98(0x10)
	struct FString SaturationParamName; // 0xa8(0x10)
	struct FString WearParamName; // 0xb8(0x10)
	struct FString ScaleParamName; // 0xc8(0x10)
	struct FGameplayTagQuery TagQueryForShouldOverrideCODefaultsWithFixedLocationParameters; // 0xd8(0x48)
	struct FCustomizableObjectSprayVariantFixedProperties FixedSprayLocation; // 0x120(0x68)
	struct FCustomizableObjectSprayVariantSelectablePayload DefaultSprayCustomization; // 0x188(0x98)
	struct FCustomizableObjectSprayVariantPayloadClamps SprayNumericConstraints; // 0x220(0x30)
	float TextureBaseScale; // 0x250(0x04)
	char pad_254[0x4]; // 0x254(0x04)
	struct FCustomizableObjectSprayVariantSlotImageProperties SpraySlotImageProperties; // 0x258(0x40)
	char pad_298[0x10]; // 0x298(0x10)
};

// Class MeshCosmetics.MeshCosmeticsStep_ComponentRemoval
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_ComponentRemoval : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsOption_ApplyAssembledMeshSchema
// Size: 0x30 (Inherited: 0x30)
struct UMeshCosmeticsOption_ApplyAssembledMeshSchema : UFortCosmeticFlowOption {
};

// Class MeshCosmetics.MeshCosmeticsOption_ApplyCustomizableObject
// Size: 0x30 (Inherited: 0x30)
struct UMeshCosmeticsOption_ApplyCustomizableObject : UFortCosmeticFlowOption {
};

// Class MeshCosmetics.MeshCosmeticsStep_RemoveCustomizableSkeletalComponents
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_RemoveCustomizableSkeletalComponents : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsVariance_ApplyParameters
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsVariance_ApplyParameters : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsVariance_CompileObjects
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsVariance_CompileObjects : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsVariance_ManageComponents
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsVariance_ManageComponents : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsVariance_ProcessVariantAssets
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsVariance_ProcessVariantAssets : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsStep_ChooseParameters
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_ChooseParameters : UFortCosmeticStep {
};

// Class MeshCosmetics.MeshCosmeticsStep_CommitChosenParams
// Size: 0x58 (Inherited: 0x58)
struct UMeshCosmeticsStep_CommitChosenParams : UFortCosmeticStep {
};

// Class MeshCosmetics.GameFeatureAction_MeshCosmeticsCompileSchemaDepenencies
// Size: 0x28 (Inherited: 0x28)
struct UGameFeatureAction_MeshCosmeticsCompileSchemaDepenencies : UGameFeatureAction {
};

// Class MeshCosmetics.MeshCosmeticTagInterface
// Size: 0x28 (Inherited: 0x28)
struct UMeshCosmeticTagInterface : UInterface {

	void OnPostCustomizationAnimGameplayTags_BP(struct FGameplayTagContainer& GameplayTags); // Function MeshCosmetics.MeshCosmeticTagInterface.OnPostCustomizationAnimGameplayTags_BP // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class MeshCosmetics.FortCustomizableInstanceLODManagement
// Size: 0x28 (Inherited: 0x28)
struct UFortCustomizableInstanceLODManagement : UCustomizableInstanceLODManagementBase {
};

// Class MeshCosmetics.MeshCosmeticsLayoutSchema
// Size: 0x418 (Inherited: 0x378)
struct UMeshCosmeticsLayoutSchema : UFortApparelLayoutItemDefinition {
	struct TMap<struct FCosmeticSlotSelector, struct FCosmeticsLayoutSlot> SlotDataConfig; // 0x378(0x50)
	struct TMap<struct FCosmeticSlotSelector, struct TSoftObjectPtr<UCustomizableObject>> SlottedCustomizableObjects; // 0x3c8(0x50)
};

// Class MeshCosmetics.MeshCosmeticsAppliedSchemaData
// Size: 0x48 (Inherited: 0x28)
struct UMeshCosmeticsAppliedSchemaData : UFortCosmeticItemAdditionalData {
	struct TSoftObjectPtr<UMeshCosmeticsLayoutSchema> SchemaAsset; // 0x28(0x20)
};

// Class MeshCosmetics.MeshCosmeticsSupportedSchemaData
// Size: 0x38 (Inherited: 0x28)
struct UMeshCosmeticsSupportedSchemaData : UFortCosmeticItemAdditionalData {
	struct TArray<struct TSoftObjectPtr<UMeshCosmeticsLayoutSchema>> SupportedSchemas; // 0x28(0x10)
};

