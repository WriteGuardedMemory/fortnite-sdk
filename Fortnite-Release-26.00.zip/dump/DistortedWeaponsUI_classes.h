// Class DistortedWeaponsUI.ChromeWeaponInfoWidget
// Size: 0x330 (Inherited: 0x310)
struct UChromeWeaponInfoWidget : UFortHUDElementWidget {
	struct UFortHUDContext* HUDContext; // 0x310(0x08)
	struct UFortWorldMultiItemXPComponent* CurrentXpComponent; // 0x318(0x08)
	struct UAthenaItemTierWidget* ItemTierWidget; // 0x320(0x08)
	struct UFortKeybindWidget* KeybindWidget; // 0x328(0x08)

	void OnWeaponUpgraded(); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponUpgraded // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnWeaponStartUpgrading(); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponStartUpgrading // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnWeaponRemoved(); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponRemoved // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnWeaponEquipped(); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnWeaponEquipped // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnReadyToUpgradeWeapon(enum class EFortRarity NextRarity); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnReadyToUpgradeWeapon // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnGainedXp(float CurrentXPPercentage); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.OnGainedXp // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandleXpChanged(float XPDelta, float CurrentXPPercentage); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleXpChanged // (Final|Native|Protected) // @ game+0xab8bea0
	void HandleWeaponUpgraded(); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponUpgraded // (Final|Native|Protected) // @ game+0xab8bcf0
	void HandleWeaponUnEquipped(); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponUnEquipped // (Final|Native|Protected) // @ game+0xab8c060
	void HandleWeaponEquipped(struct AFortWeapon* NewWeapon, struct AFortWeapon* PrevWeapon); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleWeaponEquipped // (Final|Native|Protected) // @ game+0xab8c080
	void HandleUpgradeTriggered(float ReloadTime, enum class EFortWeaponReloadType ReloadType); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandleUpgradeTriggered // (Final|Native|Protected) // @ game+0xab8bd10
	void HandlePowerUpPending(); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.HandlePowerUpPending // (Final|Native|Protected) // @ game+0xab8bcd0
	enum class EFortRarity GetCurrentWeaponRarity(); // Function DistortedWeaponsUI.ChromeWeaponInfoWidget.GetCurrentWeaponRarity // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xab8c5b0
};

