// Class MeshCosmeticsUI.FortVariantSprayCustomizerConfig
// Size: 0x80 (Inherited: 0x30)
struct UFortVariantSprayCustomizerConfig : UDataAsset {
	struct TMap<struct FGameplayTag, struct FFortVariantSprayCustomizerCosmeticOptions> SprayCustomizerOptions; // 0x30(0x50)
};

// Class MeshCosmeticsUI.FortVariantRedirectorTile
// Size: 0x480 (Inherited: 0x3a8)
struct UFortVariantRedirectorTile : UFortVariantEditorWidgetBase {
	struct UDynamicEntryBox* EntryBox_VariantOptions; // 0x3a8(0x08)
	struct UCommonTextBlock* Text_VariantName; // 0x3b0(0x08)
	struct TSoftClassPtr<UObject> SprayCustomizerClass; // 0x3b8(0x20)
	struct UFortVariantSprayCustomizerConfig* SprayCustomizerConfig; // 0x3d8(0x08)
	struct FDataTableRowHandle ClearAllSlotsInputAction; // 0x3e0(0x10)
	struct FDataTableRowHandle RandomizeSpraysInputAction; // 0x3f0(0x10)
	struct TWeakObjectPtr<struct UAthenaCosmeticItemDefinition> ItemDefinition; // 0x400(0x08)
	struct TArray<struct FFortVariantRedirectorTileLoadedEmoteToRandomize> LoadedEmotesToRandomize; // 0x408(0x10)
	char pad_418[0x68]; // 0x418(0x68)

	struct UWidget* HandleBoundaryNavigation(enum class EUINavigation InNavigation); // Function MeshCosmeticsUI.FortVariantRedirectorTile.HandleBoundaryNavigation // (Final|Native|Private) // @ game+0xac79790
};

// Class MeshCosmeticsUI.FortVariantRedirectorTileButton
// Size: 0x14d0 (Inherited: 0x1470)
struct UFortVariantRedirectorTileButton : UCommonButtonBase {
	struct UOverlay* ImageOverlay; // 0x1470(0x08)
	struct UFortLazyImage* LazyImage_TileIcon; // 0x1478(0x08)
	enum class ERedirectorTileDisplayMode DisplayMode; // 0x1480(0x04)
	float SlotOpacitySprayAssigned; // 0x1484(0x04)
	float SlotOpacitySprayNotAssigned; // 0x1488(0x04)
	char pad_148C[0x44]; // 0x148c(0x44)
};

// Class MeshCosmeticsUI.FortVariantSprayCustomizer
// Size: 0x868 (Inherited: 0x708)
struct UFortVariantSprayCustomizer : UFortItemPreviewScreen {
	struct UCommonButtonBase* Button_Back; // 0x708(0x08)
	struct UCommonButtonBase* Button_Confirm; // 0x710(0x08)
	struct UCommonButtonBase* Button_HideArchivedItems; // 0x718(0x08)
	struct UCommonButtonBase* Button_ShowArchivedItems; // 0x720(0x08)
	struct UWidget* Widget_ArchivedItemsButtons; // 0x728(0x08)
	struct UCommonButtonBase* Button_SpraysTab; // 0x730(0x08)
	struct UCommonButtonBase* Button_SettingsTab; // 0x738(0x08)
	struct UCommonButtonBase* Button_TouchClose; // 0x740(0x08)
	struct UCommonActionWidget* ActionWidget_TabLeft; // 0x748(0x08)
	struct UCommonActionWidget* ActionWidget_TabRight; // 0x750(0x08)
	struct UCommonActivatableWidgetSwitcher* Switcher_Tabs; // 0x758(0x08)
	struct UWidget* Widget_Sprays; // 0x760(0x08)
	struct UWidget* Widget_Settings; // 0x768(0x08)
	struct UFortVariantItemTexturePicker* TexturePicker_Sprays; // 0x770(0x08)
	struct UFortVariantSprayCustomizerSetting* Setting_Saturation; // 0x778(0x08)
	struct UFortVariantSprayCustomizerSetting* Setting_Wear; // 0x780(0x08)
	struct UFortVariantSprayCustomizerSetting* Setting_Scale; // 0x788(0x08)
	struct FDataTableRowHandle TabLeftAction; // 0x790(0x10)
	struct FDataTableRowHandle TabRightAction; // 0x7a0(0x10)
	struct FGameplayTag ItemShopPreviewSceneChangerTag; // 0x7b0(0x04)
	char pad_7B4[0x4]; // 0x7b4(0x04)
	struct UCommonButtonGroupLegacy* TabButtonGroup; // 0x7b8(0x08)
	struct TWeakObjectPtr<struct UAthenaCosmeticItemDefinition> ItemDefinition; // 0x7c0(0x08)
	struct UFortCustomizableObjectSprayVariant* SprayVariant; // 0x7c8(0x08)
	char pad_7D0[0x98]; // 0x7d0(0x98)

	void BP_SetVariantEditorMode(bool bIsLockerMode); // Function MeshCosmeticsUI.FortVariantSprayCustomizer.BP_SetVariantEditorMode // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BP_SetChannelSlotIcon(struct TSoftObjectPtr<UObject>& ChannelSlotIcon); // Function MeshCosmeticsUI.FortVariantSprayCustomizer.BP_SetChannelSlotIcon // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
};

// Class MeshCosmeticsUI.FortVariantSprayCustomizerSetting
// Size: 0x2e8 (Inherited: 0x2a8)
struct UFortVariantSprayCustomizerSetting : UUserWidget {
	struct UAnalogSlider* Slider_Value; // 0x2a8(0x08)
	float CommitDelay; // 0x2b0(0x04)
	char pad_2B4[0x34]; // 0x2b4(0x34)

	void HandleSliderValueChanged(float NormalizedValue); // Function MeshCosmeticsUI.FortVariantSprayCustomizerSetting.HandleSliderValueChanged // (Final|Native|Private) // @ game+0xac80190
	void BP_OnSetConstraints(struct FFloatRange& Constraints); // Function MeshCosmeticsUI.FortVariantSprayCustomizerSetting.BP_OnSetConstraints // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void BP_OnChangeValue(float Value, float NormalizedValue); // Function MeshCosmeticsUI.FortVariantSprayCustomizerSetting.BP_OnChangeValue // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

