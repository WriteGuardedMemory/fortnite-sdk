// Class GLTFExporter.GLTFExportOptions
// Size: 0xa0 (Inherited: 0x28)
struct UGLTFExportOptions : UObject {
	float ExportUniformScale; // 0x28(0x04)
	bool bExportPreviewMesh; // 0x2c(0x01)
	bool bSkipNearDefaultValues; // 0x2d(0x01)
	bool bIncludeCopyrightNotice; // 0x2e(0x01)
	bool bExportProxyMaterials; // 0x2f(0x01)
	bool bExportUnlitMaterials; // 0x30(0x01)
	bool bExportClearCoatMaterials; // 0x31(0x01)
	bool bExportEmissiveStrength; // 0x32(0x01)
	enum class EGLTFMaterialBakeMode BakeMaterialInputs; // 0x33(0x01)
	enum class EGLTFMaterialBakeSizePOT DefaultMaterialBakeSize; // 0x34(0x01)
	enum class TextureFilter DefaultMaterialBakeFilter; // 0x35(0x01)
	enum class TextureAddress DefaultMaterialBakeTiling; // 0x36(0x01)
	char pad_37[0x1]; // 0x37(0x01)
	struct TMap<enum class EGLTFMaterialPropertyGroup, struct FGLTFOverrideMaterialBakeSettings> DefaultInputBakeSettings; // 0x38(0x50)
	int32_t DefaultLevelOfDetail; // 0x88(0x04)
	bool bExportVertexColors; // 0x8c(0x01)
	bool bExportVertexSkinWeights; // 0x8d(0x01)
	bool bUseMeshQuantization; // 0x8e(0x01)
	bool bExportLevelSequences; // 0x8f(0x01)
	bool bExportAnimationSequences; // 0x90(0x01)
	enum class EGLTFTextureImageFormat TextureImageFormat; // 0x91(0x01)
	char pad_92[0x2]; // 0x92(0x02)
	int32_t TextureImageQuality; // 0x94(0x04)
	bool bExportTextureTransforms; // 0x98(0x01)
	bool bAdjustNormalmaps; // 0x99(0x01)
	bool bExportHiddenInGame; // 0x9a(0x01)
	bool bExportLights; // 0x9b(0x01)
	bool bExportCameras; // 0x9c(0x01)
	enum class EGLTFMaterialVariantMode ExportMaterialVariants; // 0x9d(0x01)
	char pad_9E[0x2]; // 0x9e(0x02)

	void ResetToDefault(); // Function GLTFExporter.GLTFExportOptions.ResetToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0xb90f750
};

// Class GLTFExporter.GLTFExporter
// Size: 0x78 (Inherited: 0x78)
struct UGLTFExporter : UExporter {

	bool ExportToGLTF(struct UObject* Object, struct FString FilePath, struct UGLTFExportOptions* Options, struct TSet<struct AActor*>& SelectedActors, struct FGLTFExportMessages& OutMessages); // Function GLTFExporter.GLTFExporter.ExportToGLTF // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb920a50
};

// Class GLTFExporter.GLTFAnimSequenceExporter
// Size: 0x78 (Inherited: 0x78)
struct UGLTFAnimSequenceExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFLevelExporter
// Size: 0x78 (Inherited: 0x78)
struct UGLTFLevelExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFLevelSequenceExporter
// Size: 0x78 (Inherited: 0x78)
struct UGLTFLevelSequenceExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFLevelVariantSetsExporter
// Size: 0x78 (Inherited: 0x78)
struct UGLTFLevelVariantSetsExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFMaterialExporter
// Size: 0x78 (Inherited: 0x78)
struct UGLTFMaterialExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFSkeletalMeshExporter
// Size: 0x78 (Inherited: 0x78)
struct UGLTFSkeletalMeshExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFStaticMeshExporter
// Size: 0x78 (Inherited: 0x78)
struct UGLTFStaticMeshExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFProxyOptions
// Size: 0x80 (Inherited: 0x28)
struct UGLTFProxyOptions : UObject {
	bool bBakeMaterialInputs; // 0x28(0x01)
	enum class EGLTFMaterialBakeSizePOT DefaultMaterialBakeSize; // 0x29(0x01)
	enum class TextureFilter DefaultMaterialBakeFilter; // 0x2a(0x01)
	enum class TextureAddress DefaultMaterialBakeTiling; // 0x2b(0x01)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TMap<enum class EGLTFMaterialPropertyGroup, struct FGLTFOverrideMaterialBakeSettings> DefaultInputBakeSettings; // 0x30(0x50)

	void ResetToDefault(); // Function GLTFExporter.GLTFProxyOptions.ResetToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0xb92c1c0
};

// Class GLTFExporter.GLTFMaterialExportOptions
// Size: 0x88 (Inherited: 0x28)
struct UGLTFMaterialExportOptions : UAssetUserData {
	struct UMaterialInterface* Proxy; // 0x28(0x08)
	struct FGLTFOverrideMaterialBakeSettings Default; // 0x30(0x06)
	char pad_36[0x2]; // 0x36(0x02)
	struct TMap<enum class EGLTFMaterialPropertyGroup, struct FGLTFOverrideMaterialBakeSettings> Inputs; // 0x38(0x50)
};

