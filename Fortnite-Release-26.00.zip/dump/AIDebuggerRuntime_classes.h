// Class AIDebuggerRuntime.AIDebuggerCheatManager
// Size: 0x28 (Inherited: 0x28)
struct UAIDebuggerCheatManager : UChildCheatManager {

	void StartAIDebugger(struct FString AIDebuggerSoftClassPath); // Function AIDebuggerRuntime.AIDebuggerCheatManager.StartAIDebugger // (Final|Exec|Native|Public) // @ game+0x7ff1010
	void NextNavMesh(); // Function AIDebuggerRuntime.AIDebuggerCheatManager.NextNavMesh // (Final|Exec|Native|Public) // @ game+0x3982d70
	void EnableNavMeshVisualizer(bool bEnable); // Function AIDebuggerRuntime.AIDebuggerCheatManager.EnableNavMeshVisualizer // (Final|Exec|Native|Public) // @ game+0x34b0aa0
};

// Class AIDebuggerRuntime.AIDebuggerRendererComponent
// Size: 0x610 (Inherited: 0x570)
struct UAIDebuggerRendererComponent : UPrimitiveComponent {
	char pad_570[0x90]; // 0x570(0x90)
	struct UMaterial* NavMeshMaterial; // 0x600(0x08)
	float NavLinkLineThickness; // 0x608(0x04)
	float NavLinkMaxDrawDistance; // 0x60c(0x04)
};

// Class AIDebuggerRuntime.FortControllerComponent_AIDebugger
// Size: 0xe0 (Inherited: 0xa8)
struct UFortControllerComponent_AIDebugger : UFortControllerComponent {
	struct APlayerController* OwnerPC; // 0xa8(0x08)
	struct UAIDebuggerRendererComponent* NavMeshRendererComponentClass; // 0xb0(0x08)
	char DefaultEnabledVisualizers; // 0xb8(0x01)
	char pad_B9[0x3]; // 0xb9(0x03)
	int32_t DefaultNavDataIndexToDisplay; // 0xbc(0x04)
	char EnabledVisualizers; // 0xc0(0x01)
	char NumNavMeshes; // 0xc1(0x01)
	char pad_C2[0x1e]; // 0xc2(0x1e)

	void VisualizeNextNavMesh(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.VisualizeNextNavMesh // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x73baa10
	void VisualizeNavMeshID(int32_t NavMeshID); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.VisualizeNavMeshID // (Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0x76b83c0
	void SetVisualizationEnable(enum class EAIDebuggerVisualization VisualizationType, bool bEnable); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.SetVisualizationEnable // (RequiredAPI|Net|NetReliableNative|Event|Public|NetServer|BlueprintCallable) // @ game+0xa69abb0
	void OnRep_EnabledVisualizers(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnRep_EnabledVisualizers // (Final|Native|Public) // @ game+0xa69aa70
	void OnPlayerExitedIsland(struct FEventMessageTag Channel, struct FPlayerExitSpatialActorContextWithPawn& PlayerExitSpatialActorContext); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.OnPlayerExitedIsland // (Final|Native|Public|HasOutParms) // @ game+0xa69a8c0
	bool IsVisualizationEnabled(enum class EAIDebuggerVisualization VisualizationType); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.IsVisualizationEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa69aac0
	struct UAIDebuggerRendererComponent* GetOrCreateRenderer(); // Function AIDebuggerRuntime.FortControllerComponent_AIDebugger.GetOrCreateRenderer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa69ad40
};

