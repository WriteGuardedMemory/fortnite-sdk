// ScriptStruct MidMatchAssignedGameplayRuntime.FortAssignedObjectiveSquadData
// Size: 0x20 (Inherited: 0x00)
struct FFortAssignedObjectiveSquadData {
	char SquadId; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector CachedSquadAvgLocation; // 0x08(0x18)
};

// ScriptStruct MidMatchAssignedGameplayRuntime.FortAssignedObjectiveData
// Size: 0x28 (Inherited: 0x00)
struct FFortAssignedObjectiveData {
	struct TArray<struct FFortAssignedObjectiveSquadData> AssignedSquadDataArray; // 0x00(0x10)
	struct FVector ObjectiveLocation; // 0x10(0x18)
};

