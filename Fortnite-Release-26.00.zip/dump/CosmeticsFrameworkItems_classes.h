// Class CosmeticsFrameworkItems.CosmeticDataComponent
// Size: 0xf0 (Inherited: 0xa0)
struct UCosmeticDataComponent : UActorComponent {
	struct TMap<struct FGameplayTag, struct FInstancedStructContainer> PropertyContainers; // 0xa0(0x50)

	void ResetProperties(); // Function CosmeticsFrameworkItems.CosmeticDataComponent.ResetProperties // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6f48c30
	bool BP_FindProperty(struct FGameplayTag SlotTag, struct FGameplayTag PropertyTag, struct FCosmeticPropertyBase& OutProperty); // Function CosmeticsFrameworkItems.CosmeticDataComponent.BP_FindProperty // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6f49a50
	bool BP_AddOrOverrideProperty(struct FGameplayTag SlotTag, struct FCosmeticPropertyBase& Property); // Function CosmeticsFrameworkItems.CosmeticDataComponent.BP_AddOrOverrideProperty // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6f49870
};

