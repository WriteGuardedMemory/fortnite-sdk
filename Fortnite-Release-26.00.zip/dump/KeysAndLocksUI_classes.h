// Class KeysAndLocksUI.KeyPlayerInfoWidget
// Size: 0x338 (Inherited: 0x310)
struct UKeyPlayerInfoWidget : UFortHUDElementWidget {
	char pad_310[0x8]; // 0x310(0x08)
	struct FGameplayTag KeyStatusTag; // 0x318(0x04)
	char pad_31C[0x1c]; // 0x31c(0x1c)

	void OnKeyStatusActivated(struct AFortPlayerStateAthena* InPlayerState, bool bActivated); // Function KeysAndLocksUI.KeyPlayerInfoWidget.OnKeyStatusActivated // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void HandleGameplayTagEvent(struct FGameplayTag UpdatedTag, int32_t TagCount); // Function KeysAndLocksUI.KeyPlayerInfoWidget.HandleGameplayTagEvent // (Final|Native|Protected) // @ game+0xac225e0
};

