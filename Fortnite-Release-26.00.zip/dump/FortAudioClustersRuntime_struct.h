// ScriptStruct FortAudioClustersRuntime.GameFeatureAudioClusterEntry
// Size: 0x18 (Inherited: 0x00)
struct FGameFeatureAudioClusterEntry {
	struct FGameplayTag ClusterTag; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct TSoftClassPtr<UObject>> ActorClasses; // 0x08(0x10)
};

