// Class CRDPlayerTrackerUI.CRDPlayerTrackerUIComponent
// Size: 0xa8 (Inherited: 0xa0)
struct UCRDPlayerTrackerUIComponent : UActorComponent {
	struct UCRDPlayerTrackerWidget* SpawnedWidget; // 0xa0(0x08)
};

// Class CRDPlayerTrackerUI.CRDPlayerTrackerWidget
// Size: 0x320 (Inherited: 0x310)
struct UCRDPlayerTrackerWidget : UFortHUDElementWidget {
	char pad_310[0x10]; // 0x310(0x10)
};

