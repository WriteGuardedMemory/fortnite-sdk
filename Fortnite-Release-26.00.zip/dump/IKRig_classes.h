// Class IKRig.IKGoalCreatorInterface
// Size: 0x28 (Inherited: 0x28)
struct UIKGoalCreatorInterface : UInterface {

	void AddIKGoals(struct TMap<struct FName, struct FIKRigGoal>& OutGoals); // Function IKRig.IKGoalCreatorInterface.AddIKGoals // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x6c70910
};

// Class IKRig.IKRigComponent
// Size: 0xb8 (Inherited: 0xa0)
struct UIKRigComponent : UActorComponent {
	char pad_A0[0x18]; // 0xa0(0x18)

	void SetIKRigGoalTransform(struct FName GoalName, struct FTransform Transform, float PositionAlpha, float RotationAlpha); // Function IKRig.IKRigComponent.SetIKRigGoalTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6c70f60
	void SetIKRigGoalPositionAndRotation(struct FName GoalName, struct FVector Position, struct FQuat Rotation, float PositionAlpha, float RotationAlpha); // Function IKRig.IKRigComponent.SetIKRigGoalPositionAndRotation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6c71320
	void SetIKRigGoal(struct FIKRigGoal& Goal); // Function IKRig.IKRigComponent.SetIKRigGoal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6c70df0
	void ClearAllGoals(); // Function IKRig.IKRigComponent.ClearAllGoals // (Final|Native|Public|BlueprintCallable) // @ game+0x6c70dc0
};

// Class IKRig.RetargetChainSettings
// Size: 0xd8 (Inherited: 0x28)
struct URetargetChainSettings : UObject {
	struct FName SourceChain; // 0x28(0x04)
	struct FName TargetChain; // 0x2c(0x04)
	struct FTargetChainSettings Settings; // 0x30(0xa8)
};

// Class IKRig.RetargetRootSettings
// Size: 0x90 (Inherited: 0x28)
struct URetargetRootSettings : UObject {
	struct FTargetRootSettings Settings; // 0x28(0x68)
};

// Class IKRig.IKRetargetGlobalSettings
// Size: 0x48 (Inherited: 0x28)
struct UIKRetargetGlobalSettings : UObject {
	struct FRetargetGlobalSettings Settings; // 0x28(0x1c)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class IKRig.IKRetargeter
// Size: 0x1f0 (Inherited: 0x28)
struct UIKRetargeter : UObject {
	struct TSoftObjectPtr<UIKRigDefinition> SourceIKRigAsset; // 0x28(0x20)
	struct TSoftObjectPtr<UIKRigDefinition> TargetIKRigAsset; // 0x48(0x20)
	struct TArray<struct FRetargetChainMap> ChainMapping; // 0x68(0x10)
	struct TArray<struct URetargetChainSettings*> ChainSettings; // 0x78(0x10)
	struct URetargetRootSettings* RootSettings; // 0x88(0x08)
	struct UIKRetargetGlobalSettings* GlobalSettings; // 0x90(0x08)
	struct TMap<struct FName, struct FRetargetProfile> Profiles; // 0x98(0x50)
	struct FName CurrentProfile; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct TMap<struct FName, struct FIKRetargetPose> SourceRetargetPoses; // 0xf0(0x50)
	struct TMap<struct FName, struct FIKRetargetPose> TargetRetargetPoses; // 0x140(0x50)
	struct FName CurrentSourceRetargetPose; // 0x190(0x04)
	struct FName CurrentTargetRetargetPose; // 0x194(0x04)
	struct TMap<struct FName, struct FIKRetargetPose> RetargetPoses; // 0x198(0x50)
	struct FName CurrentRetargetPose; // 0x1e8(0x04)
	char pad_1EC[0x4]; // 0x1ec(0x04)

	void SetRootSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetRootSettings& RootSettings); // Function IKRig.IKRetargeter.SetRootSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6c77610
	void SetGlobalSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FRetargetGlobalSettings& GlobalSettings); // Function IKRig.IKRetargeter.SetGlobalSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6c778f0
	void SetChainSpeedPlantSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainSpeedPlantSettings& SpeedPlantSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainSpeedPlantSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6c766e0
	void SetChainSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainSettings& ChainSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6c77290
	void SetChainIKSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainIKSettings& IKSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainIKSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6c76b40
	void SetChainFKSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainFKSettings& FKSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainFKSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6c76f30
	struct FTargetRootSettings GetRootSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile); // Function IKRig.IKRetargeter.GetRootSettingsFromRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6c77f70
	void GetRootSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName OptionalProfileName, struct FTargetRootSettings& OutSettings); // Function IKRig.IKRetargeter.GetRootSettingsFromRetargetAsset // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6c78120
	struct FRetargetGlobalSettings GetGlobalSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile); // Function IKRig.IKRetargeter.GetGlobalSettingsFromRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6c77b40
	void GetGlobalSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName OptionalProfileName, struct FRetargetGlobalSettings& OutSettings); // Function IKRig.IKRetargeter.GetGlobalSettingsFromRetargetAsset // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6c77cb0
	struct FTargetChainSettings GetChainUsingGoalFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName IKGoalName); // Function IKRig.IKRetargeter.GetChainUsingGoalFromRetargetAsset // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6c78dd0
	struct FTargetChainSettings GetChainSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FName TargetChainName); // Function IKRig.IKRetargeter.GetChainSettingsFromRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6c78500
	struct FTargetChainSettings GetChainSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName TargetChainName, struct FName OptionalProfileName); // Function IKRig.IKRetargeter.GetChainSettingsFromRetargetAsset // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6c78880
};

// Class IKRig.IKRetargetProcessor
// Size: 0x360 (Inherited: 0x28)
struct UIKRetargetProcessor : UObject {
	char pad_28[0x148]; // 0x28(0x148)
	struct UIKRigProcessor* IKRigProcessor; // 0x170(0x08)
	char pad_178[0x1e8]; // 0x178(0x1e8)
};

// Class IKRig.IKRigEffectorGoal
// Size: 0x100 (Inherited: 0x28)
struct UIKRigEffectorGoal : UObject {
	struct FName GoalName; // 0x28(0x04)
	struct FName BoneName; // 0x2c(0x04)
	float PositionAlpha; // 0x30(0x04)
	float RotationAlpha; // 0x34(0x04)
	char pad_38[0x8]; // 0x38(0x08)
	struct FTransform CurrentTransform; // 0x40(0x60)
	struct FTransform InitialTransform; // 0xa0(0x60)
};

// Class IKRig.IKRigDefinition
// Size: 0xf8 (Inherited: 0x28)
struct UIKRigDefinition : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TSoftObjectPtr<USkeletalMesh> PreviewSkeletalMesh; // 0x30(0x20)
	struct FIKRigSkeleton Skeleton; // 0x50(0x70)
	struct TArray<struct UIKRigEffectorGoal*> Goals; // 0xc0(0x10)
	struct TArray<struct UIKRigSolver*> Solvers; // 0xd0(0x10)
	struct FRetargetDefinition RetargetDefinition; // 0xe0(0x18)
};

// Class IKRig.IKRigProcessor
// Size: 0x148 (Inherited: 0x28)
struct UIKRigProcessor : UObject {
	char pad_28[0x38]; // 0x28(0x38)
	struct TArray<struct UIKRigSolver*> Solvers; // 0x60(0x10)
	char pad_70[0xd8]; // 0x70(0xd8)
};

// Class IKRig.IKRigSolver
// Size: 0x30 (Inherited: 0x28)
struct UIKRigSolver : UObject {
	bool bIsEnabled; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// Class IKRig.IKRig_BodyMoverEffector
// Size: 0x38 (Inherited: 0x28)
struct UIKRig_BodyMoverEffector : UObject {
	struct FName GoalName; // 0x28(0x04)
	struct FName BoneName; // 0x2c(0x04)
	float InfluenceMultiplier; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class IKRig.IKRig_BodyMover
// Size: 0x78 (Inherited: 0x30)
struct UIKRig_BodyMover : UIKRigSolver {
	struct FName RootBone; // 0x30(0x04)
	float PositionAlpha; // 0x34(0x04)
	float PositionPositiveX; // 0x38(0x04)
	float PositionNegativeX; // 0x3c(0x04)
	float PositionPositiveY; // 0x40(0x04)
	float PositionNegativeY; // 0x44(0x04)
	float PositionPositiveZ; // 0x48(0x04)
	float PositionNegativeZ; // 0x4c(0x04)
	float RotationAlpha; // 0x50(0x04)
	float RotateXAlpha; // 0x54(0x04)
	float RotateYAlpha; // 0x58(0x04)
	float RotateZAlpha; // 0x5c(0x04)
	struct TArray<struct UIKRig_BodyMoverEffector*> Effectors; // 0x60(0x10)
	char pad_70[0x8]; // 0x70(0x08)
};

// Class IKRig.IKRig_LimbEffector
// Size: 0x30 (Inherited: 0x28)
struct UIKRig_LimbEffector : UObject {
	struct FName GoalName; // 0x28(0x04)
	struct FName BoneName; // 0x2c(0x04)
};

// Class IKRig.IKRig_LimbSolver
// Size: 0x88 (Inherited: 0x30)
struct UIKRig_LimbSolver : UIKRigSolver {
	struct FName RootName; // 0x30(0x04)
	float ReachPrecision; // 0x34(0x04)
	enum class EAxis HingeRotationAxis; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t MaxIterations; // 0x3c(0x04)
	bool bEnableLimit; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	float MinRotationAngle; // 0x44(0x04)
	bool bAveragePull; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float PullDistribution; // 0x4c(0x04)
	float ReachStepAlpha; // 0x50(0x04)
	bool bEnableTwistCorrection; // 0x54(0x01)
	enum class EAxis EndBoneForwardAxis; // 0x55(0x01)
	char pad_56[0x2]; // 0x56(0x02)
	struct UIKRig_LimbEffector* Effector; // 0x58(0x08)
	char pad_60[0x28]; // 0x60(0x28)
};

// Class IKRig.IKRig_FBIKEffector
// Size: 0x40 (Inherited: 0x28)
struct UIKRig_FBIKEffector : UObject {
	struct FName GoalName; // 0x28(0x04)
	struct FName BoneName; // 0x2c(0x04)
	float StrengthAlpha; // 0x30(0x04)
	float PullChainAlpha; // 0x34(0x04)
	float PinRotation; // 0x38(0x04)
	int32_t IndexInSolver; // 0x3c(0x04)
};

// Class IKRig.IKRig_FBIKBoneSettings
// Size: 0x78 (Inherited: 0x28)
struct UIKRig_FBIKBoneSettings : UObject {
	struct FName bone; // 0x28(0x04)
	float RotationStiffness; // 0x2c(0x04)
	float PositionStiffness; // 0x30(0x04)
	enum class EPBIKLimitType X; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	float MinX; // 0x38(0x04)
	float MaxX; // 0x3c(0x04)
	enum class EPBIKLimitType Y; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	float MinY; // 0x44(0x04)
	float MaxY; // 0x48(0x04)
	enum class EPBIKLimitType Z; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	float MinZ; // 0x50(0x04)
	float MaxZ; // 0x54(0x04)
	bool bUsePreferredAngles; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FVector PreferredAngles; // 0x60(0x18)
};

// Class IKRig.IKRigFBIKSolver
// Size: 0xf8 (Inherited: 0x30)
struct UIKRigFBIKSolver : UIKRigSolver {
	struct FName RootBone; // 0x30(0x04)
	int32_t Iterations; // 0x34(0x04)
	float MassMultiplier; // 0x38(0x04)
	bool bAllowStretch; // 0x3c(0x01)
	enum class EPBIKRootBehavior RootBehavior; // 0x3d(0x01)
	char pad_3E[0x2]; // 0x3e(0x02)
	struct FRootPrePullSettings PrePullRootSettings; // 0x40(0x20)
	float PullChainAlpha; // 0x60(0x04)
	float MaxAngle; // 0x64(0x04)
	float OverRelaxation; // 0x68(0x04)
	bool bStartSolveFromInputPose; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	struct TArray<struct UIKRig_FBIKEffector*> Effectors; // 0x70(0x10)
	struct TArray<struct UIKRig_FBIKBoneSettings*> BoneSettings; // 0x80(0x10)
	char pad_90[0x68]; // 0x90(0x68)
};

// Class IKRig.IKRig_PoleSolverEffector
// Size: 0x38 (Inherited: 0x28)
struct UIKRig_PoleSolverEffector : UObject {
	struct FName GoalName; // 0x28(0x04)
	struct FName BoneName; // 0x2c(0x04)
	float Alpha; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class IKRig.IKRig_PoleSolver
// Size: 0x60 (Inherited: 0x30)
struct UIKRig_PoleSolver : UIKRigSolver {
	struct FName RootName; // 0x30(0x04)
	struct FName EndName; // 0x34(0x04)
	struct UIKRig_PoleSolverEffector* Effector; // 0x38(0x08)
	char pad_40[0x20]; // 0x40(0x20)
};

// Class IKRig.IKRig_SetTransformEffector
// Size: 0x30 (Inherited: 0x28)
struct UIKRig_SetTransformEffector : UObject {
	bool bEnablePosition; // 0x28(0x01)
	bool bEnableRotation; // 0x29(0x01)
	char pad_2A[0x2]; // 0x2a(0x02)
	float Alpha; // 0x2c(0x04)
};

// Class IKRig.IKRig_SetTransform
// Size: 0x48 (Inherited: 0x30)
struct UIKRig_SetTransform : UIKRigSolver {
	struct FName Goal; // 0x30(0x04)
	struct FName RootBone; // 0x34(0x04)
	struct UIKRig_SetTransformEffector* Effector; // 0x38(0x08)
	char pad_40[0x8]; // 0x40(0x08)
};

