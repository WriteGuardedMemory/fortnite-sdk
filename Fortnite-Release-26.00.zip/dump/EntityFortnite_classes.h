// Class EntityFortnite.EntityFortniteInterface
// Size: 0x28 (Inherited: 0x28)
struct UEntityFortniteInterface : UInterface {
};

// Class EntityFortnite.EntityFortnitePlayerComponent
// Size: 0xd0 (Inherited: 0xd0)
struct UEntityFortnitePlayerComponent : UEntityActorPlayerComponent {
};

// Class EntityFortnite.EntityFortniteStormControllerComponent
// Size: 0x68 (Inherited: 0x58)
struct UEntityFortniteStormControllerComponent : UEntityComponent {
	struct AEntityFortniteStormSpawner* StormSpawnerClass; // 0x58(0x08)
	struct AEntityFortniteStormSpawner* StormSpawner; // 0x60(0x08)
};

// Class EntityFortnite.EntityFortniteStormSpawner
// Size: 0x298 (Inherited: 0x290)
struct AEntityFortniteStormSpawner : AActor {
	struct USceneComponent* SceneComponent; // 0x290(0x08)

	void Stop(); // Function EntityFortnite.EntityFortniteStormSpawner.Stop // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void Start(float StartRadius, float BoundsRadius, struct TArray<struct FEntityFortniteStormPhase>& Phases); // Function EntityFortnite.EntityFortniteStormSpawner.Start // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void Pause(); // Function EntityFortnite.EntityFortniteStormSpawner.Pause // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	bool Exists(); // Function EntityFortnite.EntityFortniteStormSpawner.Exists // (Event|Public|BlueprintEvent|Const) // @ game+0x1b027f0
};

