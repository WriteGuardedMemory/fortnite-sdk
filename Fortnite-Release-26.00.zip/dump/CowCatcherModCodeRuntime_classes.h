// Class CowCatcherModCodeRuntime.CowCatcherBarricadeBase
// Size: 0x980 (Inherited: 0x978)
struct ACowCatcherBarricadeBase : ABuildingGameplayActor {
	char pad_978[0x8]; // 0x978(0x08)

	void OnPlacementBlockedByPawnChanged(bool bBlockedByPawn); // Function CowCatcherModCodeRuntime.CowCatcherBarricadeBase.OnPlacementBlockedByPawnChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void BeginCheckingForTouchingPawns(); // Function CowCatcherModCodeRuntime.CowCatcherBarricadeBase.BeginCheckingForTouchingPawns // (Final|BlueprintAuthorityOnly|Native|Protected|BlueprintCallable) // @ game+0xa9c0a20
};

