// Class HitTicksUI.FortUserWidget_HitTicks
// Size: 0x438 (Inherited: 0x2b8)
struct UFortUserWidget_HitTicks : UFortUserWidget {
	bool bShield; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)
	double HitTime; // 0x2c0(0x08)
	double ShieldHitTime; // 0x2c8(0x08)
	double TimeSinceHit; // 0x2d0(0x08)
	double HitInterval; // 0x2d8(0x08)
	double ShieldIconMaxAlpha; // 0x2e0(0x08)
	double FadeDuration; // 0x2e8(0x08)
	double AccumulatedDamage; // 0x2f0(0x08)
	struct UImage* HitMarker; // 0x2f8(0x08)
	struct UImage* ShieldIcon; // 0x300(0x08)
	enum class EHitFeedbackMode CurrentHitFeedbackMode; // 0x308(0x01)
	bool bUseNative; // 0x309(0x01)
	char pad_30A[0x6]; // 0x30a(0x06)
	struct AActor* PrevHitPawn; // 0x310(0x08)
	double Damage; // 0x318(0x08)
	struct UWidgetAnimation* Anim_Elimination2; // 0x320(0x08)
	struct UWidgetAnimation* Anim_ShieldCrack; // 0x328(0x08)
	struct FLinearColor BaseColor_BG1; // 0x330(0x10)
	struct FLinearColor ShieldColor_BG1; // 0x340(0x10)
	struct FLinearColor CritColor_BG1; // 0x350(0x10)
	struct FLinearColor ElimColor_BG1; // 0x360(0x10)
	struct FLinearColor BaseColor_BG2; // 0x370(0x10)
	struct FLinearColor ShieldColor_BG2; // 0x380(0x10)
	struct FLinearColor CritColor_BG2; // 0x390(0x10)
	struct FLinearColor ElimColor_BG2; // 0x3a0(0x10)
	struct FLinearColor BaseColor_Outline1; // 0x3b0(0x10)
	struct FLinearColor ShieldColor_Outline1; // 0x3c0(0x10)
	struct FLinearColor CritColor_Outline1; // 0x3d0(0x10)
	struct FLinearColor ElimColor_Outline1; // 0x3e0(0x10)
	struct FLinearColor BaseColor_Outline2; // 0x3f0(0x10)
	struct FLinearColor ShieldColor_Outline2; // 0x400(0x10)
	struct FLinearColor CritColor_Outline2; // 0x410(0x10)
	struct FLinearColor ElimColor_Outline2; // 0x420(0x10)
	struct FGameplayTag UseNativeMarkerTag; // 0x430(0x04)
	char pad_434[0x4]; // 0x434(0x04)

	void UpdateTickMarkerOpacity(float NewOpacity); // Function HitTicksUI.FortUserWidget_HitTicks.UpdateTickMarkerOpacity // (Final|Native|Protected|BlueprintCallable) // @ game+0xac0f260
	void OnShieldBreak(bool bInOverShield); // Function HitTicksUI.FortUserWidget_HitTicks.OnShieldBreak // (Final|Native|Protected) // @ game+0xac0efd0
	void OnReticleSettingsChanged(); // Function HitTicksUI.FortUserWidget_HitTicks.OnReticleSettingsChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0xac0f1d0
	void OnPawnSet(); // Function HitTicksUI.FortUserWidget_HitTicks.OnPawnSet // (Final|Native|Protected|BlueprintCallable) // @ game+0xac0f240
	void OnDisplayHitNotify(double InDamage, bool bInCritical, bool bInFatal, bool bInShield, struct AActor* InPawn, struct FVector HitLocation, struct FGameplayTagContainer Tags); // Function HitTicksUI.FortUserWidget_HitTicks.OnDisplayHitNotify // (Final|Native|Protected|HasDefaults|BlueprintCallable) // @ game+0xac0f350
	void HudScaleChanged(); // Function HitTicksUI.FortUserWidget_HitTicks.HudScaleChanged // (Final|Native|Protected|BlueprintCallable) // @ game+0xac0f0c0
};

