// Class CreativeEditCameraModeRuntime.FortCreativeEditCameraController
// Size: 0x398 (Inherited: 0x368)
struct AFortCreativeEditCameraController : AFortFirstPersonCameraController {
	struct FCreativeOptionVariableBase WantsToImmersiveEdit; // 0x368(0x08)
	char pad_370[0x28]; // 0x370(0x28)

	void ServerSetImmersiveEdit(bool bWantsToImmersiveEdit, bool bIsCreativeEditModeEnabled); // Function CreativeEditCameraModeRuntime.FortCreativeEditCameraController.ServerSetImmersiveEdit // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0xaa376c0
	void OnWantsToImmersiveEditChanged(struct UFortCreativeOption* CreativeOption, char IndexValue); // Function CreativeEditCameraModeRuntime.FortCreativeEditCameraController.OnWantsToImmersiveEditChanged // (Final|Native|Private) // @ game+0xaa37880
	void OnCreativeEditModeChanged(bool bIsCreativeEditModeEnabled); // Function CreativeEditCameraModeRuntime.FortCreativeEditCameraController.OnCreativeEditModeChanged // (Final|Native|Private) // @ game+0xaa37c20
	void HandleWeaponEquipped(struct AFortWeapon* NewWeapon, struct AFortWeapon* PrevWeapon); // Function CreativeEditCameraModeRuntime.FortCreativeEditCameraController.HandleWeaponEquipped // (Final|Native|Private) // @ game+0xaa37a70
};

