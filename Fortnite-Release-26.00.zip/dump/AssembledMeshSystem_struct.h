// ScriptStruct AssembledMeshSystem.AssembledMeshAttachmentRules
// Size: 0x50 (Inherited: 0x00)
struct FAssembledMeshAttachmentRules {
	struct FName AttachSocketName; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector AttachOffset; // 0x08(0x18)
	struct FRotator AttachRotation; // 0x20(0x18)
	struct FVector AttachScale; // 0x38(0x18)
};

// ScriptStruct AssembledMeshSystem.BaseParamData
// Size: 0x10 (Inherited: 0x00)
struct FBaseParamData {
	struct FString ParamName; // 0x00(0x10)
};

// ScriptStruct AssembledMeshSystem.IntParamData
// Size: 0x20 (Inherited: 0x10)
struct FIntParamData : FBaseParamData {
	struct TArray<struct FString> ParamOptions; // 0x10(0x10)
};

// ScriptStruct AssembledMeshSystem.FloatParamData
// Size: 0x20 (Inherited: 0x10)
struct FFloatParamData : FBaseParamData {
	float FloatValue; // 0x10(0x04)
	float MinFloatValue; // 0x14(0x04)
	float MaxFloatValue; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct AssembledMeshSystem.AssembledComponentReferences
// Size: 0x10 (Inherited: 0x00)
struct FAssembledComponentReferences {
	struct USkeletalMeshComponent* SkeletalMeshComponent; // 0x00(0x08)
	struct UCustomizableSkeletalComponent* CustomizableComponent; // 0x08(0x08)
};

