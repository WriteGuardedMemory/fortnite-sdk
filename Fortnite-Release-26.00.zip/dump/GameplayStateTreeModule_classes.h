// Class GameplayStateTreeModule.StateTreeComponent
// Size: 0x148 (Inherited: 0xf8)
struct UStateTreeComponent : UBrainComponent {
	char pad_F8[0x8]; // 0xf8(0x08)
	struct FMulticastInlineDelegate OnStateTreeRunStatusChanged; // 0x100(0x10)
	struct FStateTreeReference StateTreeRef; // 0x110(0x18)
	bool bStartLogicAutomatically; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
	struct FStateTreeInstanceData InstanceData; // 0x130(0x10)
	char pad_140[0x8]; // 0x140(0x08)

	void SetStartLogicAutomatically(bool bInStartLogicAutomatically); // Function GameplayStateTreeModule.StateTreeComponent.SetStartLogicAutomatically // (Final|Native|Public|BlueprintCallable) // @ game+0xab94b60
	void SendStateTreeEvent(struct FStateTreeEvent& Event); // Function GameplayStateTreeModule.StateTreeComponent.SendStateTreeEvent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xab949b0
	enum class EStateTreeRunStatus GetStateTreeRunStatus(); // Function GameplayStateTreeModule.StateTreeComponent.GetStateTreeRunStatus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xab94960
};

// Class GameplayStateTreeModule.StateTreeComponentSchema
// Size: 0x40 (Inherited: 0x28)
struct UStateTreeComponentSchema : UStateTreeSchema {
	struct AActor* ContextActorClass; // 0x28(0x08)
	struct FStateTreeExternalDataDesc ContextActorDataDesc; // 0x30(0x10)
};

