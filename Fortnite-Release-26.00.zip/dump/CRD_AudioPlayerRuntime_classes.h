// Class CRD_AudioPlayerRuntime.CreativeAudioComponent
// Size: 0x210 (Inherited: 0xa0)
struct UCreativeAudioComponent : UActorComponent {
	float StereoSpreadScaleFactor; // 0xa0(0x04)
	float FadeInDuration; // 0xa4(0x04)
	float FadeOutDuration; // 0xa8(0x04)
	bool bSyncPlayerAudio; // 0xac(0x01)
	bool bRestartAudioOnPlay; // 0xad(0x01)
	enum class ECreativeAudioPlayerTargetListener CanBeHeardBy; // 0xae(0x01)
	enum class ECreativeAudioPlayerTargetLocation PlayLocation; // 0xaf(0x01)
	enum class EAutoplayOptions AutoplayOptions; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct UFortMinigameProgressComponent* FortMinigameProgressComponent; // 0xb8(0x08)
	struct UCreativeProxyManagerComponent* CreativeProxyManager; // 0xc0(0x08)
	struct UCreativeRegisteredPlayersManagerComponent* CreativeRegisteredPlayersManagerComponent; // 0xc8(0x08)
	struct UAudioComponent* AudioComponent; // 0xd0(0x08)
	struct TMap<struct FUniqueNetIdRepl, struct UAudioComponent*> PlayerAudioComponents; // 0xd8(0x50)
	struct ACreativeAudioPlayerReplicationProxy* ClientCachedProxy; // 0x128(0x08)
	struct USoundBase* LastSoundPlayed; // 0x130(0x08)
	struct FCreativeAudioPlayerData ServerInstigatorData; // 0x138(0x40)
	bool bEnabled; // 0x178(0x01)
	char pad_179[0x27]; // 0x179(0x27)
	bool bAudioLoaded; // 0x1a0(0x01)
	char pad_1A1[0x7]; // 0x1a1(0x07)
	struct FCreativeAudioPlayerData CachedInstigatorData; // 0x1a8(0x40)
	struct TArray<struct FUniqueNetIdRepl> RegisteredPlayerIds; // 0x1e8(0x10)
	struct TArray<struct FUniqueNetIdRepl> NonRegisteredPlayerIds; // 0x1f8(0x10)
	enum class EAutoplayOptions CurrentAutoplayState; // 0x208(0x01)
	char pad_209[0x7]; // 0x209(0x07)

	void StopAudio(struct AController* Player); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.StopAudio // (Final|Native|Public|BlueprintCallable) // @ game+0x34e0930
	void SetProperties(struct TSoftObjectPtr<USoundBase>& Audio, float Volume, float PlaybackSpeed, float NewFadeInDuration, float NewFadeOutDuration, bool bEnableVolumeAttenuation, bool bEnableSpatialization, float StereoSpread, enum class EAttenuationDistanceModel DistanceModel, float AttenuationMinDistance, float AttenuationFalloffDistance, bool bNewSyncPlayerAudio, bool bNewRestartAudioOnPlay, int32_t NewCanBeHeardBy, int32_t NewPlayLocation, int32_t NewAutoplayOptions); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.SetProperties // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xaa8b150
	void RetryUpdateAutoplayStatusOnMinigameAdd(struct AFortMinigame* Minigame); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.RetryUpdateAutoplayStatusOnMinigameAdd // (Final|Native|Private) // @ game+0x34e0930
	void RetryClientPlayAudio(struct FCreativeAudioPlayerData& InstigatorData); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.RetryClientPlayAudio // (Final|Native|Private|HasOutParms) // @ game+0xaa8ac50
	void ResetDevice(); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.ResetDevice // (Final|Native|Public|BlueprintCallable) // @ game+0xaa8ac10
	void PlayAudio(struct AController* Player); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.PlayAudio // (Final|Native|Public|BlueprintCallable) // @ game+0x34e0930
	void OnRep_ServerInstigatorData(); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnRep_ServerInstigatorData // (Final|Native|Private) // @ game+0xaa8af00
	void OnRep_RegisteredPlayerIds(); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnRep_RegisteredPlayerIds // (Final|Native|Private) // @ game+0xaa8ac30
	void OnProxyDataChanged(struct ACreativePlayerReplicationProxy* ProxyData); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnProxyDataChanged // (Final|Native|Private) // @ game+0xaa8ae10
	void OnPlayerUnregistered(struct AFortPlayerState* PlayerState); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnPlayerUnregistered // (Final|Native|Private) // @ game+0x48d7580
	void OnPlayerRemoved(struct FUniqueNetIdRepl NetId, bool bIsLocalPlayer); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnPlayerRemoved // (Final|Native|Private) // @ game+0xaa8a950
	void OnPlayerRegistered(struct AFortPlayerState* PlayerState); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnPlayerRegistered // (Final|Native|Private) // @ game+0x44efc90
	void OnPlayerAdded(struct FUniqueNetIdRepl NetId, bool bIsLocalPlayer); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnPlayerAdded // (Final|Native|Private) // @ game+0x6f9ca70
	void OnMinigameStateChanged(struct AFortMinigame* Minigame, enum class EFortMinigameState NewMinigameState); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnMinigameStateChanged // (Final|Native|Private) // @ game+0x77d5090
	void OnMinigameStarted(); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnMinigameStarted // (Final|Native|Private) // @ game+0x3982d70
	void OnMinigameEnded(); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnMinigameEnded // (Final|Native|Private) // @ game+0xaa8ac10
	void OnEnabledStateChanged(bool bIsEnabled); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnEnabledStateChanged // (Final|Native|Public|BlueprintCallable) // @ game+0x34b0aa0
	void OnAudioLoadComplete(struct FSoftObjectPath Audio); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnAudioLoadComplete // (Final|Native|Private|HasDefaults) // @ game+0xaa8afe0
	void OnAllPlayersUnregistered(); // Function CRD_AudioPlayerRuntime.CreativeAudioComponent.OnAllPlayersUnregistered // (Final|Native|Private) // @ game+0x508d080
};

// Class CRD_AudioPlayerRuntime.CreativeAudioPlayerReplicationProxy
// Size: 0x2d8 (Inherited: 0x298)
struct ACreativeAudioPlayerReplicationProxy : ACreativePlayerReplicationProxy {
	struct FCreativeAudioPlayerData InstigatorData; // 0x298(0x40)
};

