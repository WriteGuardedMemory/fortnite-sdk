// Class EpicStreamMediaSource.EpicStreamMediaSource
// Size: 0x740 (Inherited: 0x98)
struct UEpicStreamMediaSource : UStreamMediaSource {
	struct FString VideoStreamSource; // 0x98(0x10)
	float VideoStreamSourceAB; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct TMap<struct FString, struct FString> VideoId; // 0xb0(0x50)
	bool bIsLive; // 0x100(0x01)
	bool bBlurlLive; // 0x101(0x01)
	char pad_102[0x2]; // 0x102(0x02)
	int32_t MaxResolution; // 0x104(0x04)
	int32_t MaxBandwidth; // 0x108(0x04)
	float AspectRatio; // 0x10c(0x04)
	bool bShareLock; // 0x110(0x01)
	bool bAudioOnly; // 0x111(0x01)
	bool bPartySync; // 0x112(0x01)
	char pad_113[0x1]; // 0x113(0x01)
	float MediaDuration; // 0x114(0x04)
	struct FString MimeType; // 0x118(0x10)
	struct FString StreamDenyHTTPCode; // 0x128(0x10)
	struct UEpicMediaMetadataResolver* MetadataResolver; // 0x138(0x08)
	struct UEpicMediaCDNHostnames* CDNHostNames; // 0x140(0x08)
	bool bEnableBLURLRetries; // 0x148(0x01)
	char pad_149[0x337]; // 0x149(0x337)
	struct FMulticastInlineDelegate OnVideoUrlSuccess; // 0x480(0x10)
	struct FMulticastInlineDelegate OnVideoUrlFailed; // 0x490(0x10)
	struct FMulticastInlineDelegate OnMetaDataFailure; // 0x4a0(0x10)
	struct FMulticastInlineDelegate OnMediaLicensedAudioTreatmentChanged; // 0x4b0(0x10)
	char pad_4C0[0x10]; // 0x4c0(0x10)
	struct UEpicMediaDownloadLocalizedOverlays* EpicMediaDownloadLocalizedOverlays; // 0x4d0(0x08)
	struct FString ProtectUserFromAVSettings; // 0x4d8(0x10)
	struct FString StreamID; // 0x4e8(0x10)
	struct FString StreamID_Development; // 0x4f8(0x10)
	struct UMediaSource* LocalFilePlaybackAsset; // 0x508(0x08)
	double HighestFramerate; // 0x510(0x08)
	char pad_518[0x228]; // 0x518(0x228)

	void UpdateStreamUrlArguments(); // Function EpicStreamMediaSource.EpicStreamMediaSource.UpdateStreamUrlArguments // (Final|Native|Public|BlueprintCallable) // @ game+0x6162ac0
	struct FMediaPlayerOptions UpdatePlayerOptions(struct FMediaPlayerOptions PlayerOptions); // Function EpicStreamMediaSource.EpicStreamMediaSource.UpdatePlayerOptions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6163050
	bool ShouldStreamBePlaying(struct UObject* WorldContextObject, struct UPrimitiveComponent* PrimitiveComponent, float CullRadius); // Function EpicStreamMediaSource.EpicStreamMediaSource.ShouldStreamBePlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6163390
	enum class UCPTypes ShouldProtectPlayerFromContent(); // Function EpicStreamMediaSource.EpicStreamMediaSource.ShouldProtectPlayerFromContent // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x3b35cb0
	void SetUrl(struct FString& InURL); // Function EpicStreamMediaSource.EpicStreamMediaSource.SetUrl // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6162e80
	void SetSyncTimes(struct FDateTime InNowTime, struct FDateTime InStartTime, bool DynamicStart, float InOffset_s, float InDelay_s); // Function EpicStreamMediaSource.EpicStreamMediaSource.SetSyncTimes // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6162b20
	void SetPlaybackStartTime(float StartTime); // Function EpicStreamMediaSource.EpicStreamMediaSource.SetPlaybackStartTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6163270
	void SetLocalizedOverlaysV2(struct UEpicMediaDownloadLocalizedOverlays* InOverlays); // Function EpicStreamMediaSource.EpicStreamMediaSource.SetLocalizedOverlaysV2 // (Final|Native|Public|BlueprintCallable) // @ game+0x46f2de0
	void RequestVideoUrl(struct APlayerController* FortPC); // Function EpicStreamMediaSource.EpicStreamMediaSource.RequestVideoUrl // (Final|Native|Public|BlueprintCallable) // @ game+0x6163910
	void ReinstateSharing(); // Function EpicStreamMediaSource.EpicStreamMediaSource.ReinstateSharing // (Native|Public|BlueprintCallable) // @ game+0x2740f50
	void MetadataResultHandler(struct FEpicMediaMetadataExt& MetaData, bool bSuccess); // Function EpicStreamMediaSource.EpicStreamMediaSource.MetadataResultHandler // (Final|Native|Public|HasOutParms) // @ game+0x6163a00
	bool IsScreenRecordingInProgress(); // Function EpicStreamMediaSource.EpicStreamMediaSource.IsScreenRecordingInProgress // (Final|Native|Public|BlueprintCallable) // @ game+0x42ab9f0
	bool HasLocalFilePlayback(); // Function EpicStreamMediaSource.EpicStreamMediaSource.HasLocalFilePlayback // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6162fa0
	void DisableSharing(); // Function EpicStreamMediaSource.EpicStreamMediaSource.DisableSharing // (Native|Public|BlueprintCallable) // @ game+0x2740f70
	void ClearSyncTimes(); // Function EpicStreamMediaSource.EpicStreamMediaSource.ClearSyncTimes // (Final|Native|Public|BlueprintCallable) // @ game+0x6162b00
	void CancelVideoUrlRequest(bool bInCancelled); // Function EpicStreamMediaSource.EpicStreamMediaSource.CancelVideoUrlRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x61637e0
};

