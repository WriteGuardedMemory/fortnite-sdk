// ScriptStruct AutoAimWeaponRuntime.AutoAimWeaponBoneSegmentData
// Size: 0x0c (Inherited: 0x00)
struct FAutoAimWeaponBoneSegmentData {
	struct FName BoneName1; // 0x00(0x04)
	struct FName BoneName2; // 0x04(0x04)
	float BoneCollisionCapsuleRadiusAproximation; // 0x08(0x04)
};

