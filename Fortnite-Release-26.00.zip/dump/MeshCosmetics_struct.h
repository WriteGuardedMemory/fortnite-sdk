// ScriptStruct MeshCosmetics.PartHandleControllers
// Size: 0x20 (Inherited: 0x00)
struct FPartHandleControllers {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct MeshCosmetics.ApparelCustomizableItemReference
// Size: 0x20 (Inherited: 0x00)
struct FApparelCustomizableItemReference {
	struct FString GroupName; // 0x00(0x10)
	struct FString ValueName; // 0x10(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectSprayVariantFixedProperties
// Size: 0x68 (Inherited: 0x00)
struct FCustomizableObjectSprayVariantFixedProperties {
	struct FVector Position; // 0x00(0x18)
	struct FVector Direction; // 0x18(0x18)
	struct FVector UpDirection; // 0x30(0x18)
	struct FVector BaseScale; // 0x48(0x18)
	float BaseRotation; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct MeshCosmetics.CustomizableObjectSprayVariantSelectablePayload
// Size: 0x98 (Inherited: 0x80)
struct FCustomizableObjectSprayVariantSelectablePayload : FBaseVariantDef {
	struct FPrimaryAssetId TextureSource; // 0x80(0x08)
	float Saturation; // 0x88(0x04)
	float Wear; // 0x8c(0x04)
	float Scale; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

// ScriptStruct MeshCosmetics.CustomizableObjectSprayVariantMCPPayload
// Size: 0x10 (Inherited: 0x00)
struct FCustomizableObjectSprayVariantMCPPayload {
	struct FPrimaryAssetId TextureAssetID; // 0x00(0x08)
	uint16_t CompactSaturation; // 0x08(0x02)
	uint16_t CompactWear; // 0x0a(0x02)
	uint16_t CompactScale; // 0x0c(0x02)
	char pad_E[0x2]; // 0x0e(0x02)
};

// ScriptStruct MeshCosmetics.CustomizableObjectSprayVariantPayloadClamps
// Size: 0x30 (Inherited: 0x00)
struct FCustomizableObjectSprayVariantPayloadClamps {
	struct FFloatRange Saturation; // 0x00(0x10)
	struct FFloatRange Wear; // 0x10(0x10)
	struct FFloatRange Scale; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectSprayVariantSlotImageProperties
// Size: 0x40 (Inherited: 0x00)
struct FCustomizableObjectSprayVariantSlotImageProperties {
	struct TSoftObjectPtr<UTexture2D> SprayNotAssignedImage; // 0x00(0x20)
	struct TSoftObjectPtr<UTexture2D> SprayAssignedImage; // 0x20(0x20)
};

// ScriptStruct MeshCosmetics.CustomizableObjectParamVariantBase
// Size: 0x20 (Inherited: 0x00)
struct FCustomizableObjectParamVariantBase {
	struct TSoftObjectPtr<UCustomizableObject> ObjectToModify; // 0x00(0x20)
};

// ScriptStruct MeshCosmetics.CustomizableObjectValueBase
// Size: 0x18 (Inherited: 0x00)
struct FCustomizableObjectValueBase {
	struct FString ParameterName; // 0x00(0x10)
	int32_t RangeIndex; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct MeshCosmetics.CustomizableObjectIntValue
// Size: 0x30 (Inherited: 0x18)
struct FCustomizableObjectIntValue : FCustomizableObjectValueBase {
	int32_t NumericValue; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString NamedValue; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectFloatValue
// Size: 0x20 (Inherited: 0x18)
struct FCustomizableObjectFloatValue : FCustomizableObjectValueBase {
	float Value; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct MeshCosmetics.CustomizableObjectBoolValue
// Size: 0x20 (Inherited: 0x18)
struct FCustomizableObjectBoolValue : FCustomizableObjectValueBase {
	bool Value; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct MeshCosmetics.CustomizableObjectVectorValue
// Size: 0x28 (Inherited: 0x18)
struct FCustomizableObjectVectorValue : FCustomizableObjectValueBase {
	struct FLinearColor Value; // 0x18(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectTextureValue
// Size: 0x20 (Inherited: 0x18)
struct FCustomizableObjectTextureValue : FCustomizableObjectValueBase {
	struct UTexture2D* Value; // 0x18(0x08)
};

// ScriptStruct MeshCosmetics.CustomizableObjectProjectorValue
// Size: 0x80 (Inherited: 0x18)
struct FCustomizableObjectProjectorValue : FCustomizableObjectValueBase {
	struct FVector Position; // 0x18(0x18)
	struct FVector Direction; // 0x30(0x18)
	struct FVector UpDirection; // 0x48(0x18)
	struct FVector Scale; // 0x60(0x18)
	float Angle; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// ScriptStruct MeshCosmetics.CustomizableObjectStateValue
// Size: 0x28 (Inherited: 0x18)
struct FCustomizableObjectStateValue : FCustomizableObjectValueBase {
	struct FString NewState; // 0x18(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectIntParamVariant
// Size: 0x30 (Inherited: 0x20)
struct FCustomizableObjectIntParamVariant : FCustomizableObjectParamVariantBase {
	struct TArray<struct FCustomizableObjectIntValue> Parameters; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectFloatParamVariant
// Size: 0x30 (Inherited: 0x20)
struct FCustomizableObjectFloatParamVariant : FCustomizableObjectParamVariantBase {
	struct TArray<struct FCustomizableObjectFloatValue> Parameters; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectBoolParamVariant
// Size: 0x30 (Inherited: 0x20)
struct FCustomizableObjectBoolParamVariant : FCustomizableObjectParamVariantBase {
	struct TArray<struct FCustomizableObjectBoolValue> Parameters; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectVectorParamVariant
// Size: 0x30 (Inherited: 0x20)
struct FCustomizableObjectVectorParamVariant : FCustomizableObjectParamVariantBase {
	struct TArray<struct FCustomizableObjectVectorValue> Parameters; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectTextureParamVariant
// Size: 0x30 (Inherited: 0x20)
struct FCustomizableObjectTextureParamVariant : FCustomizableObjectParamVariantBase {
	struct TArray<struct FCustomizableObjectTextureValue> Parameters; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectProjectorVariant
// Size: 0x30 (Inherited: 0x20)
struct FCustomizableObjectProjectorVariant : FCustomizableObjectParamVariantBase {
	struct TArray<struct FCustomizableObjectProjectorValue> Parameters; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectMultilayerProjectsVirtualLayer
// Size: 0x90 (Inherited: 0x00)
struct FCustomizableObjectMultilayerProjectsVirtualLayer {
	bool bModifyEnabled; // 0x00(0x01)
	bool bEnabled; // 0x01(0x01)
	bool bModifyProjection; // 0x02(0x01)
	char pad_3[0x5]; // 0x03(0x05)
	struct FVector Position; // 0x08(0x18)
	struct FVector Direction; // 0x20(0x18)
	struct FVector UpDirection; // 0x38(0x18)
	struct FVector Scale; // 0x50(0x18)
	float Angle; // 0x68(0x04)
	bool bModifyImage; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	struct FString Image; // 0x70(0x10)
	bool bModifyOpacity; // 0x80(0x01)
	char pad_81[0x3]; // 0x81(0x03)
	float Opacity; // 0x84(0x04)
	bool bModifyOrder; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	int32_t Order; // 0x8c(0x04)
};

// ScriptStruct MeshCosmetics.CustomizableObjectMultilayerProjectors
// Size: 0x50 (Inherited: 0x00)
struct FCustomizableObjectMultilayerProjectors {
	struct TMap<struct FName, struct FCustomizableObjectMultilayerProjectsVirtualLayer> VirtualLayers; // 0x00(0x50)
};

// ScriptStruct MeshCosmetics.CustomizableObjectMultilayerProjectorVariant
// Size: 0x70 (Inherited: 0x20)
struct FCustomizableObjectMultilayerProjectorVariant : FCustomizableObjectParamVariantBase {
	struct TMap<struct FName, struct FCustomizableObjectMultilayerProjectors> MultilayerProjectors; // 0x20(0x50)
};

// ScriptStruct MeshCosmetics.CustomizableObjectStateVariant
// Size: 0x30 (Inherited: 0x20)
struct FCustomizableObjectStateVariant : FCustomizableObjectParamVariantBase {
	struct TArray<struct FCustomizableObjectStateValue> States; // 0x20(0x10)
};

// ScriptStruct MeshCosmetics.CustomizableObjectParamsVariantDef
// Size: 0x100 (Inherited: 0x80)
struct FCustomizableObjectParamsVariantDef : FBaseVariantDef {
	struct TArray<struct FCustomizableObjectIntParamVariant> IntParams; // 0x80(0x10)
	struct TArray<struct FCustomizableObjectFloatParamVariant> FloatParams; // 0x90(0x10)
	struct TArray<struct FCustomizableObjectBoolParamVariant> BoolParams; // 0xa0(0x10)
	struct TArray<struct FCustomizableObjectVectorParamVariant> VectorParams; // 0xb0(0x10)
	struct TArray<struct FCustomizableObjectTextureParamVariant> TextureParams; // 0xc0(0x10)
	struct TArray<struct FCustomizableObjectProjectorVariant> ProjectorParams; // 0xd0(0x10)
	struct TArray<struct FCustomizableObjectMultilayerProjectorVariant> MultilayerProjectorParams; // 0xe0(0x10)
	struct TArray<struct FCustomizableObjectStateVariant> StateVariants; // 0xf0(0x10)
};

// ScriptStruct MeshCosmetics.MeshCosmeticsCustomizationPerSlotData
// Size: 0x08 (Inherited: 0x00)
struct FMeshCosmeticsCustomizationPerSlotData {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct MeshCosmetics.MeshCosmeticsCustomizableObjectEntry
// Size: 0x2a0 (Inherited: 0x00)
struct FMeshCosmeticsCustomizableObjectEntry {
	char pad_0[0x2a0]; // 0x00(0x2a0)
};

// ScriptStruct MeshCosmetics.MeshCosmeticsCustomizationCCV2Data
// Size: 0x20 (Inherited: 0x00)
struct FMeshCosmeticsCustomizationCCV2Data {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct MeshCosmetics.MeshCosmeticsImageProviderWrapper
// Size: 0x10 (Inherited: 0x00)
struct FMeshCosmeticsImageProviderWrapper {
	struct UDefaultImageProvider* ImageProvider; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct MeshCosmetics.PendingCustomizationComponentsList
// Size: 0x30 (Inherited: 0x00)
struct FPendingCustomizationComponentsList {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct MeshCosmetics.LoadedAthenaCosmeticAssets
// Size: 0x20 (Inherited: 0x00)
struct FLoadedAthenaCosmeticAssets {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct MeshCosmetics.PendingVariantAssetsToLoad
// Size: 0x58 (Inherited: 0x00)
struct FPendingVariantAssetsToLoad {
	char pad_0[0x58]; // 0x00(0x58)
};

// ScriptStruct MeshCosmetics.SkeletalComponentData
// Size: 0x18 (Inherited: 0x00)
struct FSkeletalComponentData {
	struct UMeshCosmeticsLayoutSchema* LayoutSchema; // 0x00(0x08)
	struct FCosmeticSlotSelector Slot; // 0x08(0x02)
	char pad_A[0x6]; // 0x0a(0x06)
	struct UCustomizableObject* CustomizableObject; // 0x10(0x08)
};

// ScriptStruct MeshCosmetics.CosmeticSlotSelector
// Size: 0x02 (Inherited: 0x00)
struct FCosmeticSlotSelector {
	enum class EFortCustomPartType LegacyPartType; // 0x00(0x01)
	enum class EAthenaCustomizationCategory SourceCategory; // 0x01(0x01)
};

// ScriptStruct MeshCosmetics.MeshCosmeticsPassDataCommon
// Size: 0x110 (Inherited: 0x00)
struct FMeshCosmeticsPassDataCommon {
	struct TMap<struct FCosmeticSlotSelector, struct FCosmeticsLayoutSlot> AllSlotDataConfigs; // 0x00(0x50)
	struct TMap<struct FCosmeticSlotSelector, struct UMeshCosmeticsLayoutSchema*> ProvidedSlotsToSchemaData; // 0x50(0x50)
	struct TArray<struct UAthenaCosmeticItemDefinition*> MeshCosmeticsItemDefs; // 0xa0(0x10)
	struct TArray<struct UObject*> KeepLoadedObjects; // 0xb0(0x10)
	struct TMap<struct UCustomizableSkeletalComponent*, struct FSkeletalComponentData> SkeletalComponentData; // 0xc0(0x50)
};

// ScriptStruct MeshCosmetics.CosmeticsLayoutSlot
// Size: 0x98 (Inherited: 0x00)
struct FCosmeticsLayoutSlot {
	struct TSoftObjectPtr<UCustomizableObject> SlottedObject; // 0x00(0x20)
	int32_t ComponentIndex; // 0x20(0x04)
	struct FCosmeticSlotSelector RequiredCosmeticPart; // 0x24(0x02)
	char pad_26[0x2]; // 0x26(0x02)
	struct TSoftClassPtr<UObject> ProportionalLayerAnimBP; // 0x28(0x20)
	struct TMap<int32_t, struct FName> LinkedAnimGraphTag; // 0x48(0x50)
};

