// Class BattlePassS26UI.BattlePassBulkBuyPageS26
// Size: 0x588 (Inherited: 0x588)
struct UBattlePassBulkBuyPageS26 : UFortBattlePassBulkBuyPageBase {
};

// Class BattlePassS26UI.BattlePassLandingPageS26
// Size: 0x5a0 (Inherited: 0x538)
struct UBattlePassLandingPageS26 : UBattlePassLandingPageBase {
	struct UBattlePassLandingPageButton* Button_Rewards; // 0x538(0x08)
	struct UBattlePassLandingPageButton* Button_CharacterCustomizer; // 0x540(0x08)
	struct UBattlePassLandingPageButton* Button_BonusRewards; // 0x548(0x08)
	struct UBattlePassLandingPageButton* Button_Quests; // 0x550(0x08)
	struct UBattlePassLandingPageButton* Button_JoinSubscription; // 0x558(0x08)
	struct UBattlePassLandingPageButton* Button_WeeklyRewards; // 0x560(0x08)
	struct UCommonTextBlock* Text_SeasonNumber; // 0x568(0x08)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0x570(0x08)
	char pad_578[0x28]; // 0x578(0x28)

	void OnBattlePassSubscriptionAllowed(bool bSubscriptionAllowed); // Function BattlePassS26UI.BattlePassLandingPageS26.OnBattlePassSubscriptionAllowed // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
};

// Class BattlePassS26UI.BattlePassRewardPageS26
// Size: 0x5a0 (Inherited: 0x500)
struct UBattlePassRewardPageS26 : UBattlePassRewardPageBase {
	struct UFortBattlePassRewardTrack* RewardsTrackClass; // 0x500(0x08)
	struct UFortBattlePassTile* FocusedReward; // 0x508(0x08)
	struct TArray<struct UFortBattlePassRewardTrack*> TrackPages; // 0x510(0x10)
	char pad_520[0x4]; // 0x520(0x04)
	enum class ERewardPageType RewardPageType; // 0x524(0x01)
	char pad_525[0x3]; // 0x525(0x03)
	int32_t HoldTileTooltip_ClaimedRewardsToHide; // 0x528(0x04)
	int32_t HoldTileTooltip_ClaimedBattlePassToHide; // 0x52c(0x04)
	int32_t HoldTileTooltip_RequiredBattleStarsToShow; // 0x530(0x04)
	int32_t LevelRequirementUnlockTooltip_RequiredLevel; // 0x534(0x04)
	int32_t ClaimAllRewardsTooltip_RequiredLevelToShow; // 0x538(0x04)
	char pad_53C[0x4]; // 0x53c(0x04)
	struct UCommonAnimatedSwitcher* Switcher_RewardTracks; // 0x540(0x08)
	struct UFortBattlePassTutorialTooltipS26* TutorialTooltip_LevelRequirementUnlock; // 0x548(0x08)
	struct UFortBattlePassTutorialTooltipS26* TutorialTooltip_ClaimAllRewards; // 0x550(0x08)
	struct UFortBattlePassTutorialTooltipS26* TutorialTooltip_HoldTile; // 0x558(0x08)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0x560(0x08)
	struct UBattlePassBulkBuyInputData* BulkBuyInputData; // 0x568(0x08)
	struct UCommonButtonBase* Button_NextPage; // 0x570(0x08)
	struct UCommonButtonBase* Button_PreviousPage; // 0x578(0x08)
	char pad_580[0x20]; // 0x580(0x20)

	void OnPageChanged(int32_t PageNumber, int32_t RewardPageTotal); // Function BattlePassS26UI.BattlePassRewardPageS26.OnPageChanged // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	void OnLoadingScreenSelectedChanged(bool bIsSelected); // Function BattlePassS26UI.BattlePassRewardPageS26.OnLoadingScreenSelectedChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnInputMethodChanged(enum class ECommonInputType InputType); // Function BattlePassS26UI.BattlePassRewardPageS26.OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnInitForPageType(enum class ERewardPageType InRewardPageType); // Function BattlePassS26UI.BattlePassRewardPageS26.OnInitForPageType // (Event|Public|BlueprintEvent) // @ game+0x1b027f0
	struct UWidget* HandleRewardTracksBoundaryNavigation(enum class EUINavigation InNavigation); // Function BattlePassS26UI.BattlePassRewardPageS26.HandleRewardTracksBoundaryNavigation // (Final|Native|Private) // @ game+0xa80d0f0
	struct FVaultWorldBackgroundData GetRewardPageBackgroundData(); // Function BattlePassS26UI.BattlePassRewardPageS26.GetRewardPageBackgroundData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa80d260
};

// Class BattlePassS26UI.BattlePassScreenS26
// Size: 0xda0 (Inherited: 0x8c8)
struct UBattlePassScreenS26 : UBattlePassScreenBase {
	struct UFortBattlePassPurchaseResourcesWidget* ResourcePurchaseScreenClass; // 0x8c8(0x08)
	char pad_8D0[0x8]; // 0x8d0(0x08)
	struct UCommonButtonBase* Button_Close; // 0x8d8(0x08)
	struct UCommonButtonLegacy* Button_TouchClose; // 0x8e0(0x08)
	struct UCommonButtonBase* Button_ToggleViewDetails; // 0x8e8(0x08)
	struct UCommonButtonBase* Button_ReplayTrailer; // 0x8f0(0x08)
	struct UCommonButtonBase* Button_ReplayTrailer_Mobile; // 0x8f8(0x08)
	struct UCommonButtonBase* Button_ShowAbout; // 0x900(0x08)
	struct UCommonButtonBase* Button_ShowAbout_Mobile; // 0x908(0x08)
	struct UCommonButtonBase* Button_ShowAboutCustomization; // 0x910(0x08)
	struct UCommonButtonBase* Button_ShowAboutCustomization_Mobile; // 0x918(0x08)
	struct UCommonButtonBase* Button_BulkBuyRewards; // 0x920(0x08)
	struct UCommonButtonBase* Button_PageComplete; // 0x928(0x08)
	struct UCommonButtonBase* Button_GiftBattlePass; // 0x930(0x08)
	struct UCommonVisibilitySwitcher* VisibilitySwitcher_PlatformBasedButtons; // 0x938(0x08)
	struct UFortBattlePassResourcesWidgetBase* BattlePassCurrencyPanel; // 0x940(0x08)
	struct UAthenaExclusiveRewardBanner* AthenaExclusiveRewardBanner; // 0x948(0x08)
	struct UCommonTextBlock* Text_Description; // 0x950(0x08)
	struct UCommonTextBlock* Text_ItemName; // 0x958(0x08)
	struct UAthenaRewardItemTypeRarityTag* ItemRewardTag; // 0x960(0x08)
	struct UCommonTextBlock* Text_SetDetails; // 0x968(0x08)
	struct UWidgetSwitcher* Switcher_PrerequisiteInfo; // 0x970(0x08)
	struct UCommonTextBlock* Text_Prerequisite; // 0x978(0x08)
	struct UWidget* Widget_PrerequisiteProgress; // 0x980(0x08)
	struct UWidget* Widget_LevelUpMessageFree; // 0x988(0x08)
	struct UWidget* Widget_LevelUpMessagePremium; // 0x990(0x08)
	struct UWidget* Widget_CustomResourceMessage; // 0x998(0x08)
	struct UWidgetSwitcher* Switcher_PrimaryAction; // 0x9a0(0x08)
	struct UFortCTAButton* Button_BuyLevels; // 0x9a8(0x08)
	struct UFortCTAButton* Button_BuyBattlePass; // 0x9b0(0x08)
	struct UFortCTAButton* Button_ClaimReward; // 0x9b8(0x08)
	struct UCommonButtonBase* Button_ViewQuests; // 0x9c0(0x08)
	struct UCommonButtonBase* Button_PreviewLoadingScreen; // 0x9c8(0x08)
	struct UBorder* Tag_RequiresBP; // 0x9d0(0x08)
	struct UBorder* Tag_PageLocked; // 0x9d8(0x08)
	struct UBorder* Tag_BaseItem; // 0x9e0(0x08)
	struct UBorder* Tag_Prerequisite; // 0x9e8(0x08)
	struct UBorder* Tag_CompletePage; // 0x9f0(0x08)
	struct UBorder* Tag_NotEnough_Currency; // 0x9f8(0x08)
	struct UBorder* Tag_Cost; // 0xa00(0x08)
	struct UBorder* Tag_Owned; // 0xa08(0x08)
	struct UBorder* Tag_Delayed; // 0xa10(0x08)
	struct FGameplayTag QuestCategoryParentTag; // 0xa18(0x04)
	char pad_A1C[0x4]; // 0xa1c(0x04)
	struct UAthenaLoadingScreenPreviewPanel* PreviewLoadingScreenWidgetClass; // 0xa20(0x08)
	char pad_A28[0x58]; // 0xa28(0x58)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0xa80(0x08)
	struct UAthenaSeasonItemEntryBase* CurrentSelectedEntry; // 0xa88(0x08)
	struct TArray<enum class EBattlePassView> SwitcherSubPageTypes; // 0xa90(0x10)
	struct UCommonVisibilitySwitcher* VisibilitySwitcher_SubPage; // 0xaa0(0x08)
	char pad_AA8[0x100]; // 0xaa8(0x100)
	struct UFortItemDefinition* SeasonalBaseCustomizationItem; // 0xba8(0x08)
	bool bHasSubscription; // 0xbb0(0x01)
	char pad_BB1[0x7]; // 0xbb1(0x07)
	struct UFortBattlePassTutorialTooltipS26* TutorialTooltip_BattleStars; // 0xbb8(0x08)
	struct UFortBattlePassTutorialTooltipS26* TutorialTooltip_StylePoints; // 0xbc0(0x08)
	struct UFortSwipePanel* SwipePanel_Navigation; // 0xbc8(0x08)
	char pad_BD0[0x1d0]; // 0xbd0(0x1d0)

	void OverviewShowAnimationFinished(); // Function BattlePassS26UI.BattlePassScreenS26.OverviewShowAnimationFinished // (Final|Native|Public|BlueprintCallable) // @ game+0x3982d70
	void OnUpdateStatusBar(struct FText& StatusText, enum class EBattlePassStatusBarTypeS26& BarType); // Function BattlePassS26UI.BattlePassScreenS26.OnUpdateStatusBar // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnUpdateBattlePassRequiredBar(bool bPassRequiredVisible); // Function BattlePassS26UI.BattlePassScreenS26.OnUpdateBattlePassRequiredBar // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnTransitionItemDetails(bool bTransitionForward); // Function BattlePassS26UI.BattlePassScreenS26.OnTransitionItemDetails // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSetWeeklyRewardsInfo(struct FTimespan& DelayTimespan, int32_t AvailableRewards, int32_t OwnedRewards, int32_t TotalRewards, int32_t AvailablePages, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS26UI.BattlePassScreenS26.OnSetWeeklyRewardsInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnSetResourcePrice(int32_t Cost, struct UFortPersistentResourceItemDefinition* PersistentResource); // Function BattlePassS26UI.BattlePassScreenS26.OnSetResourcePrice // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSetQuestRewardsInfo(struct FTimespan& DelayTimespan, int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS26UI.BattlePassScreenS26.OnSetQuestRewardsInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnSetPrerequisiteInfo(struct FText& Description, int32_t CurrentAmount, int32_t NeededAmount, enum class EBattlePassRewardPrerequisiteType PrerequisiteType, bool bShowPrerequisiteLock); // Function BattlePassS26UI.BattlePassScreenS26.OnSetPrerequisiteInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnSetItemPrice(int32_t Cost, enum class EBattlePassCurrencyType CurrencyType); // Function BattlePassS26UI.BattlePassScreenS26.OnSetItemPrice // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSetCrewInfo(bool bIsNextMonthRewards, struct FText& MonthText, struct FTimespan& NextMonthlyRewardTimespan, struct FText& CharacterDisplayName, struct FText& CharacterDescription); // Function BattlePassS26UI.BattlePassScreenS26.OnSetCrewInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnSetCoverPageData(struct FText& Title, struct FText& Description, bool bPageComplete); // Function BattlePassS26UI.BattlePassScreenS26.OnSetCoverPageData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x1b027f0
	void OnSetBonusRewardsInfo(bool bIsUnlocked, int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages, int32_t ClaimedOutfits, int32_t TotalOutfits); // Function BattlePassS26UI.BattlePassScreenS26.OnSetBonusRewardsInfo // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnSetBaseRewardsInfo(int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS26UI.BattlePassScreenS26.OnSetBaseRewardsInfo // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnItemDelayed(struct FTimespan Delay); // Function BattlePassS26UI.BattlePassScreenS26.OnItemDelayed // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x1b027f0
	void OnInsufficientResource(struct UFortPersistentResourceItemDefinition* PersistentResource); // Function BattlePassS26UI.BattlePassScreenS26.OnInsufficientResource // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnInsufficientFunds(enum class EBattlePassCurrencyType CurrencyType); // Function BattlePassS26UI.BattlePassScreenS26.OnInsufficientFunds // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnBattlePassOwned(); // Function BattlePassS26UI.BattlePassScreenS26.OnBattlePassOwned // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnBattlePassGiftingAllowed(bool bGiftingAllowed); // Function BattlePassS26UI.BattlePassScreenS26.OnBattlePassGiftingAllowed // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	bool IsSeasonalCustomizationItemOwned(); // Function BattlePassS26UI.BattlePassScreenS26.IsSeasonalCustomizationItemOwned // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xa812320
	void HandleSwitcherVisibilityShown(); // Function BattlePassS26UI.BattlePassScreenS26.HandleSwitcherVisibilityShown // (Final|Native|Public|BlueprintCallable) // @ game+0xa812570
	void HandleFullScreenMapToggled(bool bMapVisible); // Function BattlePassS26UI.BattlePassScreenS26.HandleFullScreenMapToggled // (Final|Native|Private) // @ game+0xa8125a0
	void HandleClaimRewardComplete(bool bSuccess, struct TArray<struct FString>& OfferTemplateIdList); // Function BattlePassS26UI.BattlePassScreenS26.HandleClaimRewardComplete // (Final|Native|Private|HasOutParms) // @ game+0xa8126c0
	void GoBackOneScreen(); // Function BattlePassS26UI.BattlePassScreenS26.GoBackOneScreen // (Final|Native|Public|BlueprintCallable) // @ game+0xa812540
	struct FTimespan GetQuestPageDelay(); // Function BattlePassS26UI.BattlePassScreenS26.GetQuestPageDelay // (Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa812420
};

// Class BattlePassS26UI.FortBattlePassCustomSkinPageS26
// Size: 0x5c8 (Inherited: 0x5b0)
struct UFortBattlePassCustomSkinPageS26 : UFortBattlePassCustomSkinPageBase {
	struct FString ClaimBaseItemTooltip_ClaimCheckTemplateId; // 0x5b0(0x10)
	struct UFortBattlePassTutorialTooltip* TutorialTooltip_ClaimBaseItem; // 0x5c0(0x08)
};

// Class BattlePassS26UI.FortBattlePassResourcesWidgetS26
// Size: 0x300 (Inherited: 0x2e0)
struct UFortBattlePassResourcesWidgetS26 : UFortBattlePassResourcesWidgetBase {
	struct UCommonTextBlock* Text_BattleStarsAmount; // 0x2e0(0x08)
	struct UCommonTextBlock* Text_StylePointsAmount; // 0x2e8(0x08)
	struct UBorder* Border_StylePointsRewardsTag; // 0x2f0(0x08)
	struct UBorder* Border_BattleStarsRewardsTag; // 0x2f8(0x08)

	void OnStylePointsRewardsSet(int32_t Rewards); // Function BattlePassS26UI.FortBattlePassResourcesWidgetS26.OnStylePointsRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void OnBattleStarRewardsSet(int32_t Rewards); // Function BattlePassS26UI.FortBattlePassResourcesWidgetS26.OnBattleStarRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

// Class BattlePassS26UI.FortBattlePassTutorialTooltipS26
// Size: 0x2e0 (Inherited: 0x2d0)
struct UFortBattlePassTutorialTooltipS26 : UCommonUserWidget {
	struct UCommonRichTextBlock* Text_Tooltip; // 0x2d0(0x08)
	char pad_2D8[0x8]; // 0x2d8(0x08)

	void ShowTooltip(); // Function BattlePassS26UI.FortBattlePassTutorialTooltipS26.ShowTooltip // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
	void SetText(struct FText Text); // Function BattlePassS26UI.FortBattlePassTutorialTooltipS26.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0xa7f2bc0
	void HideTooltip(); // Function BattlePassS26UI.FortBattlePassTutorialTooltipS26.HideTooltip // (Event|Protected|BlueprintEvent) // @ game+0x1b027f0
};

