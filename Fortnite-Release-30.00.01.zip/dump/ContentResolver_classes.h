// Class ContentResolver.PluginBatchLoaderHelper
// Size: 0xa8 (Inherited: 0x28)
struct UPluginBatchLoaderHelper : UObject {
	char pad_28[0x80]; // 0x28(0x80)
};

// Class ContentResolver.ExternalContentLoader
// Size: 0x48 (Inherited: 0x30)
struct UExternalContentLoader : UEngineSubsystem {
	char pad_30[0x18]; // 0x30(0x18)
};

