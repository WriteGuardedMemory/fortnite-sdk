// Enum AtomRuntime.EAtomModelMergedMeshSelection
enum class EAtomModelMergedMeshSelection : uint8 {
	AllMeshes = 0,
	OnlyOpaqueMeshes = 1,
	OnlyTransparentMeshes = 2,
	EAtomModelMergedMeshSelection_MAX = 3
};

// Enum AtomRuntime.EAtomMaterialType
enum class EAtomMaterialType : uint8 {
	None = 0,
	Standard = 1,
	Transparent = 2,
	Glitter = 3,
	Opalescent = 4,
	Metallic = 5,
	EAtomMaterialType_MAX = 6
};

// Enum AtomRuntime.EAtomPrimitiveCollisionVolumeType
enum class EAtomPrimitiveCollisionVolumeType : uint8 {
	Box = 0,
	Sphere = 1,
	Capsule = 2,
	Cylinder = 3,
	Tube = 4,
	Crate = 5,
	EAtomPrimitiveCollisionVolumeType_MAX = 6
};

// Enum AtomRuntime.EPrimitiveAutoCollisionType
enum class EPrimitiveAutoCollisionType : uint8 {
	Box = 0,
	Sphere = 1,
	NDOP10_X = 2,
	NDOP10_Y = 3,
	NDOP10_Z = 4,
	NDOP18 = 5,
	NDOP26 = 6,
	EPrimitiveAutoCollisionType_MAX = 7
};

// Enum AtomRuntime.EPrimitiveGeometryComplexity
enum class EPrimitiveGeometryComplexity : uint8 {
	JustShell = 0,
	ShellAndUncommonParts = 1,
	ShellWithInsideDetailsAndUncommonParts = 2,
	ShellWithInsideDetails = 3,
	ShellWithFlatCapAndUncommonParts = 4,
	ShellWithFlatCap = 5,
	EPrimitiveGeometryComplexity_MAX = 6
};

// Enum AtomRuntime.EPrimitiveGeometrySectionFlag
enum class EPrimitiveGeometrySectionFlag : uint8 {
	None = 0,
	Shell = 1,
	InsideDetails = 2,
	UndersideCap = 4,
	OtherCap = 8,
	UncommonParts = 16,
	OtherParts = 32,
	EPrimitiveGeometrySectionFlag_MAX = 33
};

// Enum AtomRuntime.EGetCommonPartDescriptionResult
enum class EGetCommonPartDescriptionResult : uint8 {
	Valid = 0,
	Invalid = 1,
	EGetCommonPartDescriptionResult_MAX = 2
};

// Enum AtomRuntime.EAtomShaderType
enum class EAtomShaderType : uint8 {
	Unknown = 0,
	ShinyPlastic = 1,
	MattePlastic = 2,
	Rubber = 3,
	ShinySteel = 4,
	BrushedSteel = 5,
	MatteSteel = 6,
	Glitter = 7,
	Metallic = 8,
	Opalescence = 9,
	EAtomShaderType_MAX = 10
};

// Enum AtomRuntime.EColorEffects
enum class EColorEffects : uint8 {
	None = 0,
	Metallic = 1,
	Glitter = 2,
	Opalescent = 3,
	EColorEffects_MAX = 4
};

// Enum AtomRuntime.EAtomModelCommonPartOptimizationFlag
enum class EAtomModelCommonPartOptimizationFlag : uint8 {
	None = 0,
	RemoveConnected = 1,
	RemoveKnobs = 2,
	RemoveTubes = 4,
	RemovePins = 8,
	All = 15,
	EAtomModelCommonPartOptimizationFlag_MAX = 16
};

// Enum AtomRuntime.EAtomModelPivotAnchor
enum class EAtomModelPivotAnchor : uint8 {
	Original = 0,
	TopCenter = 1,
	Center = 2,
	BottomCenter = 3,
	EAtomModelPivotAnchor_MAX = 4
};

// Enum AtomRuntime.EAtomIssue
enum class EAtomIssue : uint8 {
	None = 0,
	FailedToLoadModelFile = 1,
	UnsupportedLxFMLVersion = 2,
	UnsupportedLxFMLSticker = 3,
	MissingPrimitive = 4,
	MismatchedPrimitive = 5,
	UnsupportedPrimitive = 6,
	UnplacedPrimitive = 7,
	MissingPrimitiveSourceGeometry = 8,
	ExcludedByFilter = 9,
	UnsupportedCommonPart = 10,
	OldVersionPrimitive = 11,
	UnknownDecorationTexture = 12,
	UnknownDecorationSurface = 13,
	DuplicatedSelectionSet = 14,
	EmptySelectionSet = 15,
	EAtomIssue_MAX = 16
};

// Enum AtomRuntime.EAtomModelInstanceType
enum class EAtomModelInstanceType : uint8 {
	Components = 0,
	Actors = 1,
	HISM = 2,
	ComponentsWithVertexColor = 3,
	RenderStylesComponents = 4,
	EAtomModelInstanceType_MAX = 5
};

// Enum AtomRuntime.EAtomPlatform
enum class EAtomPlatform : uint8 {
	NA = 0,
	Duplo = 1,
	Atom = 2,
	Technic = 3,
	Clickits = 4,
	ActionFigures = 5,
	Outdoor = 6,
	SoftPrimitives = 7,
	ExtendedLine = 8,
	Scala = 9,
	Znap = 10,
	Toolo = 11,
	Storage = 12,
	MusicBuilder = 13,
	StoryBuilder = 14,
	Quatro = 15,
	Ccbs = 16,
	Primo1 = 17,
	AtomFoundation = 18,
	DieCutToStickers = 98,
	GeneralPlatform = 99,
	EAtomPlatform_MAX = 100
};

// Enum AtomRuntime.EAtomCommonPartType
enum class EAtomCommonPartType : uint8 {
	None = 0,
	Dknob_01_C = 1,
	Dknob_01_D = 2,
	Dpin_01_C = 3,
	Dtube_01_C = 4,
	Dtube_02_C = 5,
	Dtube_03_C = 6,
	Dtube_04_C = 7,
	knob_01_C = 8,
	knob_01_D = 9,
	knob_01_P = 10,
	knob_01_PC = 11,
	knob_02_P = 12,
	knob_02_PC = 13,
	knob_03_P = 14,
	knob_03_PC = 15,
	knob_04_P = 16,
	knob_04_PC = 17,
	pin_01_C = 18,
	pin_01_D = 19,
	pin_02_C = 20,
	pin_02_D = 21,
	tube_01_D = 22,
	tube_02_D = 23,
	tube_03_D = 24,
	EAtomCommonPartType_MAX = 25
};

// Enum AtomRuntime.EAtomCommonPartCategory
enum class EAtomCommonPartCategory : uint8 {
	None = 0,
	Knob = 1,
	Pin = 2,
	Tube = 3,
	EAtomCommonPartCategory_MAX = 4
};

// Enum AtomRuntime.EAtomPrimitiveImportWarningFlags
enum class EAtomPrimitiveImportWarningFlags : uint8 {
	None = 0,
	UnableToFindUnwrappedMeshUVSet = 1,
	BrokenPrincipalUVSet = 2,
	InvalidFBXFile = 4,
	InvalidMeshInFBXScene = 8,
	CommonPartMeshNotFound = 16,
	FullyTriangulated = 32,
	TransformedMeshes = 64,
	CommonPartRotationsInconsistent = 128,
	EAtomPrimitiveImportWarningFlags_MAX = 129
};

// Enum AtomRuntime.EAtomPrimitiveGeoOptimization
enum class EAtomPrimitiveGeoOptimization : uint8 {
	Default = 0,
	UseForDetailOnly = 1,
	UseApproximationForLODs = 2,
	EAtomPrimitiveGeoOptimization_MAX = 3
};

// Enum AtomRuntime.EAtomPrimitiveGeoOptimization_Old
enum class EAtomPrimitiveGeoOptimization_Old : uint8 {
	Default = 0,
	UseForDetailOnly = 1,
	UseApproximationForLODs = 2,
	EAtomPrimitiveGeoOptimization_MAX = 3
};

// Enum AtomRuntime.EAtomPrimitiveApproximationShapeType
enum class EAtomPrimitiveApproximationShapeType : uint8 {
	Auto = 0,
	OrientedBox = 1,
	ExtrudedConvexHull2D = 2,
	ConvexHull3D = 3,
	Extrusion = 4,
	EAtomPrimitiveApproximationShapeType_MAX = 5
};

// Enum AtomRuntime.EAtomPrimitiveApproximationShapeType_Old
enum class EAtomPrimitiveApproximationShapeType_Old : uint8 {
	Auto = 0,
	OrientedBox = 1,
	ExtrudedConvexHull2D = 2,
	ConvexHull3D = 3,
	Extrusion = 4,
	EAtomPrimitiveApproximationShapeType_MAX = 5
};

// Enum AtomRuntime.EAtomPrimitiveDetailTextureType
enum class EAtomPrimitiveDetailTextureType : uint8 {
	None = 0,
	NormapMap = 1,
	AlphaMap = 2,
	EAtomPrimitiveDetailTextureType_MAX = 3
};

// Enum AtomRuntime.EConnectionFieldType
enum class EConnectionFieldType : uint8 {
	Planar = 0,
	Hinge = 1,
	Axle = 2,
	Ball = 3,
	Cardan = 4,
	Fixed = 5,
	Rail = 6,
	Slider = 7,
	Gear = 8,
	User = 9,
	EConnectionFieldType_MAX = 10
};

// Enum AtomRuntime.EConnectionFieldSuperType
enum class EConnectionFieldSuperType : uint8 {
	Planar = 0,
	Line = 1,
	Point = 2,
	EConnectionFieldSuperType_MAX = 3
};

// Enum AtomRuntime.EConnectionFieldGender
enum class EConnectionFieldGender : uint8 {
	Receptor = 0,
	Connector = 1,
	Any = 2,
	EConnectionFieldGender_MAX = 3
};

// Enum AtomRuntime.EFieldConnectResult
enum class EFieldConnectResult : uint8 {
	NoConnection = 0,
	Rejection = 1,
	FixedConnection = 2,
	FreeConnection = 3,
	HingeConnection = 4,
	CardanConnection = 5,
	BallConnection = 6,
	PrismaticConnection = 7,
	CylindricalConnection = 8,
	PrismaticAPerpendicularHingeConnection = 9,
	PrismaticBPerpendicularHingeConnection = 10,
	ConnectResultMax = 11,
	FirstConnection = 2,
	LastConnection = 10,
	EFieldConnectResult_MAX = 12
};

// Enum AtomRuntime.EAxleDiameter
enum class EAxleDiameter : uint8 {
	Tiny = 0,
	Medium = 1,
	Large = 2,
	EAxleDiameter_MAX = 3
};

// Enum AtomRuntime.EConnectionAxleType
enum class EConnectionAxleType : uint8 {
	UnusedReceptor = 0,
	UnusedConnector = 1,
	RoundAxleReceptor = 2,
	RoundAxleConnector = 3,
	CrossAxleReceptor = 4,
	CrossAxleConnector = 5,
	SecondaryPinReceptor = 6,
	SecondaryPinConnector = 7,
	PlateRoundCrossAxleReceptor = 8,
	UnusedPlateRoundCrossAxleConnector = 9,
	MiniFigNeckReceptor = 10,
	MiniFigNeckConnector = 11,
	RoundCrossAxleReceptor = 12,
	RoundCrossAxleConnector = 13,
	TinyPinReceptor = 14,
	TinyPinConnector = 15,
	UnusedCrossAxlePegHoleCapAlignmentReceptor = 16,
	CrossAxlePegHoleCapAlignmentConnector = 17,
	UnusedRoundAxleReceptorDontRejectSecondaryPinConnector = 18,
	RoundAxleConnectorDontRejectSecondaryPinConnector = 19,
	UnusedSecondaryPinReceptorDontRejectTinyPinConnector = 20,
	SecondaryPinConnectorDontRejectTinyPinConnector = 21,
	SubTypeSize = 22,
	EConnectionAxleType_MAX = 23
};

// Enum AtomRuntime.EConnectionPointType
enum class EConnectionPointType : uint8 {
	Knob = 0,
	HollowKnob = 1,
	KnobFitInPegHole = 2,
	HollowKnobFitInPegHole = 3,
	SquareKnob = 4,
	Tube = 5,
	TubeWithRib = 6,
	BottomTube = 7,
	BottomTubeWithRib = 8,
	SecondaryPin = 9,
	SecondaryPinWithRib = 10,
	SecondaryPinWithTinyPinReceptor = 11,
	SecondaryPinWithRibAndTinyPinReceptor = 12,
	FixedTube = 13,
	FixedTubeWithAntiKnob = 14,
	AntiKnob = 15,
	PegHole = 16,
	SquareAntiKnob = 17,
	TubeGap = 18,
	TubeGrabber = 19,
	TinyPin = 20,
	TinyPinReceptor = 21,
	Edge = 22,
	EdgeGap = 23,
	KnobReject = 24,
	PowerFuncLeftTop = 25,
	PowerFuncRightTop = 26,
	PowerFuncLeftBottom = 27,
	PowerFuncRightBottom = 28,
	VoidFeature = 29,
	DuploKnob = 30,
	DuploHollowKnob = 31,
	DuploAntiKnob = 32,
	DuploTube = 33,
	DuploFixedTube = 34,
	DuploTubeGap = 35,
	DuploAnimalKnob = 36,
	DuploAnimalTube = 37,
	SecondaryPinReceptor = 38,
	DuploFixedAnimalTube = 39,
	DuploSecondaryPinWithRib = 40,
	DuploSecondaryPin = 41,
	DuploKnobReject = 42,
	_size = 43,
	_duploBegin = 30,
	_duploEnd = 42,
	EConnectionPointType_MAX = 44
};

// Enum AtomRuntime.EConnectionPointFlags
enum class EConnectionPointFlags : int32 {
	SquareFeature = 1,
	RoundFeature = 2,
	KnobWithHole = 4,
	KnobWithMiniFigHandHole = 8,
	KnobWithSingleCollision = 16,
	SingleFeature = 32,
	ReceptorDontRemoveKnobCollision = 64,
	KnobWithoutCollision = 128,
	CreationValidFlags = 255,
	ThisSideTransparent = 256,
	ThisSideHidden = 512,
	DynamicValidFlags = 768,
	InternalIsDuploSecondaryPin = 268435456,
	InternalIsQuadConnector = 536870912,
	InternalIsSecondaryPin = 1073741824,
	InternalIsAnyKnob = 2147483648,
	SquareOcclusionShapeIndex = 1,
	RoundOcclusionShapeIndex = 2,
	OtherOcclusionShapeIndex = 0,
	OcclusionShapeMask = 3,
	EConnectionPointFlags_MAX = 2147483649
};

// ScriptStruct AtomRuntime.AtomColorInfo
// Size: 0x28 (Inherited: 0x08)
struct FAtomColorInfo : FTableRowBase {
	struct FColor Color; // 0x08(0x04)
	enum class EAtomMaterialType MaterialType; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FString Name; // 0x10(0x10)
	bool bIsActive; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct AtomRuntime.AtomMergedMeshLODDistanceSettings
// Size: 0x20 (Inherited: 0x00)
struct FAtomMergedMeshLODDistanceSettings {
	bool bOverrideLODScreenSizes; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float BaseLODScreenSize; // 0x04(0x04)
	float BaseLODScreenSizeScaling; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<float> LODDistances; // 0x10(0x10)
};

// ScriptStruct AtomRuntime.CommonPartInstanceDescription
// Size: 0x08 (Inherited: 0x00)
struct FCommonPartInstanceDescription {
	int16_t MeshIdx; // 0x00(0x02)
	int16_t MaterialIdx; // 0x02(0x02)
	int16_t UUIDIdx; // 0x04(0x02)
	uint16_t ColorId; // 0x06(0x02)
};

// ScriptStruct AtomRuntime.AtomCommonPartInstancesCache
// Size: 0x50 (Inherited: 0x00)
struct FAtomCommonPartInstancesCache {
	struct TArray<struct UStaticMesh*> Meshes; // 0x00(0x10)
	struct TArray<struct UMaterialInterface*> Materials; // 0x10(0x10)
	struct TArray<struct FGuid> UUIDs; // 0x20(0x10)
	struct TArray<struct FCommonPartInstanceDescription> Instances; // 0x30(0x10)
	struct TArray<struct FTransform3f> InstanceTransforms; // 0x40(0x10)
};

// ScriptStruct AtomRuntime.AtomPrimitiveMaterialAssignement
// Size: 0x28 (Inherited: 0x00)
struct FAtomPrimitiveMaterialAssignement {
	struct FName SlotName; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UMaterialInterface> Material; // 0x08(0x20)
};

// ScriptStruct AtomRuntime.AtomPrimitiveInstanceData
// Size: 0x30 (Inherited: 0x00)
struct FAtomPrimitiveInstanceData {
	struct TArray<struct FAtomPrimitiveMaterialAssignement> MaterialAssignments; // 0x00(0x10)
	struct TSoftObjectPtr<UStaticMesh> MeshOverride; // 0x10(0x20)
};

// ScriptStruct AtomRuntime.AtomCommonPartAssetDescription
// Size: 0x0c (Inherited: 0x00)
struct FAtomCommonPartAssetDescription {
	enum class EAtomCommonPartType CommonPartType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName CommonPartStyle; // 0x04(0x04)
	float Scale; // 0x08(0x04)
};

// ScriptStruct AtomRuntime.AtomModelPartGuid
// Size: 0x14 (Inherited: 0x00)
struct FAtomModelPartGuid {
	struct FGuid Guid; // 0x00(0x10)
	int32_t PartIndex; // 0x10(0x04)
};

// ScriptStruct AtomRuntime.AtomModelPartColorInfo
// Size: 0x0c (Inherited: 0x00)
struct FAtomModelPartColorInfo {
	struct FColor Color; // 0x00(0x04)
	int32_t ColorId; // 0x04(0x04)
	enum class EAtomMaterialType MaterialType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct AtomRuntime.AtomModelPartDecorationInfo
// Size: 0x28 (Inherited: 0x00)
struct FAtomModelPartDecorationInfo {
	struct UMaterialInterface* Material; // 0x00(0x08)
	struct UTexture* Texture; // 0x08(0x08)
	struct FString PrimitiveSurfaceName; // 0x10(0x10)
	int32_t PrimitiveSurfaceIndex; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct AtomRuntime.AtomCommonPartAndTransform
// Size: 0x70 (Inherited: 0x00)
struct FAtomCommonPartAndTransform {
	enum class EAtomCommonPartType Type; // 0x00(0x01)
	char pad_1[0xf]; // 0x01(0x0f)
	struct FTransform Transform; // 0x10(0x60)
};

// ScriptStruct AtomRuntime.AtomModelPartInstanceInfo
// Size: 0xa0 (Inherited: 0x00)
struct FAtomModelPartInstanceInfo {
	struct FAtomModelPartGuid PartGuid; // 0x00(0x14)
	char pad_14[0x4]; // 0x14(0x04)
	int32_t PartId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct UAtomPrimitive* Primitive; // 0x20(0x08)
	struct TArray<struct FTransform> Transforms; // 0x28(0x10)
	struct TArray<struct FAtomModelPartDecorationInfo> Decorations; // 0x38(0x10)
	struct TArray<struct FAtomModelPartColorInfo> Colors; // 0x48(0x10)
	struct TArray<struct FString> SelectionSets; // 0x58(0x10)
	struct FString Group; // 0x68(0x10)
	struct FString ParentGroup; // 0x78(0x10)
	struct TArray<struct FAtomCommonPartAndTransform> CommonParts; // 0x88(0x10)
	bool bIsUndersideVisible; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// ScriptStruct AtomRuntime.AtomModelPartsCollection
// Size: 0x80 (Inherited: 0x00)
struct FAtomModelPartsCollection {
	struct FString Name; // 0x00(0x10)
	struct FTransform Pivot; // 0x10(0x60)
	struct TArray<struct FAtomModelPartInstanceInfo> Parts; // 0x70(0x10)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCollisionVolumeBase
// Size: 0x20 (Inherited: 0x00)
struct FAtomPrimitiveCollisionVolumeBase {
	struct FVector Location; // 0x00(0x18)
	uint16_t BoneIndex; // 0x18(0x02)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCollisionVolumeBox
// Size: 0x50 (Inherited: 0x20)
struct FAtomPrimitiveCollisionVolumeBox : FAtomPrimitiveCollisionVolumeBase {
	struct FRotator Rotation; // 0x20(0x18)
	struct FVector HalfExtent; // 0x38(0x18)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCollisionVolumeCapsule
// Size: 0x40 (Inherited: 0x20)
struct FAtomPrimitiveCollisionVolumeCapsule : FAtomPrimitiveCollisionVolumeBase {
	struct FRotator Rotation; // 0x20(0x18)
	float Radius; // 0x38(0x04)
	float HalfLength; // 0x3c(0x04)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCollisionVolumeCylinder
// Size: 0x40 (Inherited: 0x20)
struct FAtomPrimitiveCollisionVolumeCylinder : FAtomPrimitiveCollisionVolumeBase {
	struct FRotator Rotation; // 0x20(0x18)
	float Radius; // 0x38(0x04)
	float HalfLength; // 0x3c(0x04)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCollisionVolumeTube
// Size: 0x48 (Inherited: 0x20)
struct FAtomPrimitiveCollisionVolumeTube : FAtomPrimitiveCollisionVolumeBase {
	struct FRotator Rotation; // 0x20(0x18)
	float InnerRadius; // 0x38(0x04)
	float OuterRadius; // 0x3c(0x04)
	float HalfLength; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCollisionVolumeSphere
// Size: 0x28 (Inherited: 0x20)
struct FAtomPrimitiveCollisionVolumeSphere : FAtomPrimitiveCollisionVolumeBase {
	float Radius; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCollisionVolumeContainer
// Size: 0x50 (Inherited: 0x00)
struct FAtomPrimitiveCollisionVolumeContainer {
	struct TArray<struct FAtomPrimitiveCollisionVolumeBox> Boxes; // 0x00(0x10)
	struct TArray<struct FAtomPrimitiveCollisionVolumeSphere> Spheres; // 0x10(0x10)
	struct TArray<struct FAtomPrimitiveCollisionVolumeCapsule> Capsules; // 0x20(0x10)
	struct TArray<struct FAtomPrimitiveCollisionVolumeCylinder> Cylinders; // 0x30(0x10)
	struct TArray<struct FAtomPrimitiveCollisionVolumeTube> Tubes; // 0x40(0x10)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCollisionGeometry
// Size: 0x80 (Inherited: 0x00)
struct FAtomPrimitiveCollisionGeometry {
	struct FKAggregateGeom AggGeom; // 0x00(0x80)
};

// ScriptStruct AtomRuntime.AtomPrimitiveGeometryLODs
// Size: 0x98 (Inherited: 0x00)
struct FAtomPrimitiveGeometryLODs {
	struct TArray<struct UAtomPrimitiveGeometry*> GeometryLODs; // 0x00(0x10)
	struct UAtomPrimitiveGeometry* HiResNaniteGeomery; // 0x10(0x08)
	struct FAtomPrimitiveCollisionGeometry Collision; // 0x18(0x80)
};

// ScriptStruct AtomRuntime.AtomPrimitiveGeometryAndTransform
// Size: 0x40 (Inherited: 0x00)
struct FAtomPrimitiveGeometryAndTransform {
	struct UAtomPrimitiveGeometry* AtomPrimitiveGeometry; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform3f Transform; // 0x10(0x30)
};

// ScriptStruct AtomRuntime.ConnectionField
// Size: 0x40 (Inherited: 0x00)
struct FConnectionField {
	struct FQuat Rotation; // 0x00(0x20)
	struct FVector Location; // 0x20(0x18)
	uint32_t Subtype; // 0x38(0x04)
	uint16_t BoneIndex; // 0x3c(0x02)
	enum class EConnectionFieldType Type; // 0x3e(0x01)
	char pad_3F[0x1]; // 0x3f(0x01)
};

// ScriptStruct AtomRuntime.ConnectionFieldLine
// Size: 0x50 (Inherited: 0x40)
struct FConnectionFieldLine : FConnectionField {
	double Length; // 0x40(0x08)
	bool StartCapped; // 0x48(0x01)
	bool EndCapped; // 0x49(0x01)
	char pad_4A[0x6]; // 0x4a(0x06)
};

// ScriptStruct AtomRuntime.ConnectionFieldAxle
// Size: 0x60 (Inherited: 0x50)
struct FConnectionFieldAxle : FConnectionFieldLine {
	bool Grabbing; // 0x50(0x01)
	bool RequireGrabbing; // 0x51(0x01)
	char pad_52[0x2]; // 0x52(0x02)
	float DiscreteSnapInterval; // 0x54(0x04)
	char pad_58[0x8]; // 0x58(0x08)
};

// ScriptStruct AtomRuntime.ConnectionFieldPoint
// Size: 0x40 (Inherited: 0x40)
struct FConnectionFieldPoint : FConnectionField {
};

// ScriptStruct AtomRuntime.ConnectionFieldBall
// Size: 0x40 (Inherited: 0x40)
struct FConnectionFieldBall : FConnectionFieldPoint {
};

// ScriptStruct AtomRuntime.ConnectionFieldContainer
// Size: 0x30 (Inherited: 0x00)
struct FConnectionFieldContainer {
	struct TArray<struct FConnectionFieldPlanar> PlanarFields; // 0x00(0x10)
	struct TArray<struct FInstancedStruct> LineFields; // 0x10(0x10)
	struct TArray<struct FInstancedStruct> PointFields; // 0x20(0x10)
};

// ScriptStruct AtomRuntime.ConnectionFieldPlanar
// Size: 0x60 (Inherited: 0x40)
struct FConnectionFieldPlanar : FConnectionField {
	char Width; // 0x40(0x01)
	char Height; // 0x41(0x01)
	char pad_42[0x6]; // 0x42(0x06)
	struct TArray<struct FConnectionPoint> Points; // 0x48(0x10)
	char pad_58[0x8]; // 0x58(0x08)
};

// ScriptStruct AtomRuntime.ConnectionPoint
// Size: 0x08 (Inherited: 0x00)
struct FConnectionPoint {
	enum class EConnectionPointFlags Flags; // 0x00(0x04)
	enum class EConnectionPointType Type; // 0x04(0x01)
	char Size; // 0x05(0x01)
	char pad_6[0x2]; // 0x06(0x02)
};

// ScriptStruct AtomRuntime.ConnectionFieldFixed
// Size: 0x50 (Inherited: 0x40)
struct FConnectionFieldFixed : FConnectionFieldPoint {
	uint32_t Axes; // 0x40(0x04)
	char pad_44[0xc]; // 0x44(0x0c)
};

// ScriptStruct AtomRuntime.ConnectionFieldGear
// Size: 0x60 (Inherited: 0x50)
struct FConnectionFieldGear : FConnectionFieldLine {
	double Radius; // 0x50(0x08)
	uint32_t ToothCount; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// ScriptStruct AtomRuntime.ConnectionFieldHinge
// Size: 0x70 (Inherited: 0x40)
struct FConnectionFieldHinge : FConnectionFieldPoint {
	bool Oriented; // 0x40(0x01)
	bool Flip; // 0x41(0x01)
	bool HasLimits; // 0x42(0x01)
	bool RequireGrabbing; // 0x43(0x01)
	char pad_44[0x4]; // 0x44(0x04)
	double OrientedMin; // 0x48(0x08)
	double OrientedMax; // 0x50(0x08)
	double FlippedMin; // 0x58(0x08)
	double FlippedMax; // 0x60(0x08)
	char pad_68[0x8]; // 0x68(0x08)
};

// ScriptStruct AtomRuntime.ConnectionFieldSlider
// Size: 0x70 (Inherited: 0x50)
struct FConnectionFieldSlider : FConnectionFieldLine {
	bool Cylindrical; // 0x50(0x01)
	bool HasSpring; // 0x51(0x01)
	char pad_52[0x6]; // 0x52(0x06)
	double SpringRest; // 0x58(0x08)
	double SpringStrength; // 0x60(0x08)
	double SpringDamping; // 0x68(0x08)
};

// ScriptStruct AtomRuntime.SerializedPlanarConnection
// Size: 0x30 (Inherited: 0x00)
struct FSerializedPlanarConnection {
	struct FPlanarFieldConnectionInfo Connection; // 0x00(0x20)
	struct FConnectivityFieldReference FieldA; // 0x20(0x08)
	struct FConnectivityFieldReference FieldB; // 0x28(0x08)
};

// ScriptStruct AtomRuntime.ConnectivityFieldReference
// Size: 0x08 (Inherited: 0x00)
struct FConnectivityFieldReference {
	int32_t ObjectId; // 0x00(0x04)
	uint16_t FieldIndex; // 0x04(0x02)
	char pad_6[0x2]; // 0x06(0x02)
};

// ScriptStruct AtomRuntime.PlanarFieldConnectionInfo
// Size: 0x20 (Inherited: 0x00)
struct FPlanarFieldConnectionInfo {
	struct TArray<struct FPlanarFieldPointConnectionInfo> PointConnections; // 0x00(0x10)
	enum class EFieldConnectResult ConnectResult; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	uint32_t OverlapA; // 0x14(0x04)
	uint32_t OverlapB; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct AtomRuntime.PlanarFieldPointConnectionInfo
// Size: 0x04 (Inherited: 0x00)
struct FPlanarFieldPointConnectionInfo {
	uint16_t IndexA; // 0x00(0x02)
	uint16_t IndexB; // 0x02(0x02)
};

// ScriptStruct AtomRuntime.SerializedConnectivityObjects
// Size: 0x20 (Inherited: 0x00)
struct FSerializedConnectivityObjects {
	struct TArray<struct FConnectionFieldContainer> Fields; // 0x00(0x10)
	struct TArray<struct FSerializedPlanarConnection> PlanarConnections; // 0x10(0x10)
};

// ScriptStruct AtomRuntime.PlanarFieldPointInfo
// Size: 0x20 (Inherited: 0x00)
struct FPlanarFieldPointInfo {
	struct FVector PointLocation; // 0x00(0x18)
	enum class EConnectionPointType PointType; // 0x18(0x01)
	bool IsAvailable; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct AtomRuntime.PlanarFieldInfo
// Size: 0x90 (Inherited: 0x00)
struct FPlanarFieldInfo {
	struct FTransform Transform; // 0x00(0x60)
	struct FVector2D Size; // 0x60(0x10)
	enum class EConnectionFieldGender PlanarFieldType; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct TArray<struct FPlanarFieldPointInfo> PointInfo; // 0x78(0x10)
	char pad_88[0x8]; // 0x88(0x08)
};

// ScriptStruct AtomRuntime.WorldConnectivityHandle
// Size: 0x04 (Inherited: 0x00)
struct FWorldConnectivityHandle {
	char pad_0[0x4]; // 0x00(0x04)
};

// ScriptStruct AtomRuntime.ConnectivityQueryResult
// Size: 0xc0 (Inherited: 0x00)
struct FConnectivityQueryResult {
	bool bHasValidConnection; // 0x00(0x01)
	char pad_1[0xf]; // 0x01(0x0f)
	struct FTransform TargetTransformToConnect; // 0x10(0x60)
	struct FVector HitLocation; // 0x70(0x18)
	struct FVector OffsetToBestFit; // 0x88(0x18)
	int32_t SourceFieldIndex; // 0xa0(0x04)
	int32_t SourceFieldObjectId; // 0xa4(0x04)
	int32_t SourceFieldConnectionPointIndex; // 0xa8(0x04)
	int32_t TargetFieldIndex; // 0xac(0x04)
	int32_t TargetFieldObjectId; // 0xb0(0x04)
	int32_t TargetFieldConnectionPointIndex; // 0xb4(0x04)
	struct FName ErrorMessage; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
};

// ScriptStruct AtomRuntime.AtomColor
// Size: 0x18 (Inherited: 0x00)
struct FAtomColor {
	int32_t ID; // 0x00(0x04)
	enum class EColorEffects Effects; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FLinearColor Color; // 0x08(0x10)
};

// ScriptStruct AtomRuntime.AtomColorSurface
// Size: 0x08 (Inherited: 0x00)
struct FAtomColorSurface {
	int32_t ColorId; // 0x00(0x04)
	enum class EAtomShaderType ShaderType; // 0x04(0x04)
};

// ScriptStruct AtomRuntime.AtomDecorationAssignment
// Size: 0x30 (Inherited: 0x00)
struct FAtomDecorationAssignment {
	struct FString SurfaceName; // 0x00(0x10)
	struct FString TextureName; // 0x10(0x10)
	struct FString Version; // 0x20(0x10)
};

// ScriptStruct AtomRuntime.AtomModelPrimitiveInstance
// Size: 0x90 (Inherited: 0x00)
struct FAtomModelPrimitiveInstance {
	struct UAtomPrimitive* Primitive; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform PrimitiveTransform; // 0x10(0x60)
	struct FVector PivotOrigin; // 0x70(0x18)
	char pad_88[0x8]; // 0x88(0x08)
};

// ScriptStruct AtomRuntime.AtomModelPart
// Size: 0xb0 (Inherited: 0x00)
struct FAtomModelPart {
	struct TSoftObjectPtr<UAtomPrimitive> AtomPrimitive; // 0x00(0x20)
	struct TSoftObjectPtr<UMaterialInterface> MaterialInstance; // 0x20(0x20)
	struct TSoftObjectPtr<UMaterialInterface> MaterialWithPayload; // 0x40(0x20)
	struct TArray<struct FTransform> Transforms; // 0x60(0x10)
	uint32_t PartId; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FString PartRevision; // 0x78(0x10)
	struct TArray<struct FAtomColorSurface> ColorSurfaces; // 0x88(0x10)
	struct TArray<struct FAtomDecorationAssignment> Decorations; // 0x98(0x10)
	bool bIgnoreCommonPartCulling; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// ScriptStruct AtomRuntime.AtomModelSocket
// Size: 0x80 (Inherited: 0x00)
struct FAtomModelSocket {
	struct FGuid ID; // 0x00(0x10)
	struct FName Name; // 0x10(0x04)
	char pad_14[0xc]; // 0x14(0x0c)
	struct FTransform Transform; // 0x20(0x60)
};

// ScriptStruct AtomRuntime.AtomModelPrimitive
// Size: 0x28 (Inherited: 0x00)
struct FAtomModelPrimitive {
	struct TArray<struct FAtomModelPart> Parts; // 0x00(0x10)
	int32_t DesignId; // 0x10(0x04)
	struct FGuid UUID; // 0x14(0x10)
	struct FName DesignName; // 0x24(0x04)
};

// ScriptStruct AtomRuntime.AtomBoneReference
// Size: 0x0c (Inherited: 0x00)
struct FAtomBoneReference {
	int32_t PrimitiveIndex; // 0x00(0x04)
	int32_t PartIndex; // 0x04(0x04)
	int32_t BoneIndex; // 0x08(0x04)
};

// ScriptStruct AtomRuntime.AtomPrimitiveConnection
// Size: 0x18 (Inherited: 0x00)
struct FAtomPrimitiveConnection {
	struct FAtomBoneReference From; // 0x00(0x0c)
	struct FAtomBoneReference To; // 0x0c(0x0c)
};

// ScriptStruct AtomRuntime.AtomRigidElementConnection
// Size: 0x80 (Inherited: 0x00)
struct FAtomRigidElementConnection {
	struct FTransform Transform; // 0x00(0x60)
	int32_t OtherElementIndex; // 0x60(0x04)
	int32_t ConnectionUniqueId; // 0x64(0x04)
	struct TArray<struct FAtomPrimitiveConnection> PrimitiveConnections; // 0x68(0x10)
	char pad_78[0x8]; // 0x78(0x08)
};

// ScriptStruct AtomRuntime.AtomRigidElement
// Size: 0x28 (Inherited: 0x00)
struct FAtomRigidElement {
	struct TArray<struct FAtomBoneReference> BoneReferences; // 0x00(0x10)
	struct TArray<struct FAtomRigidElementConnection> Connections; // 0x10(0x10)
	struct FName Name; // 0x20(0x04)
	int32_t IndexOfMetaBone; // 0x24(0x04)
};

// ScriptStruct AtomRuntime.AtomHingedElement
// Size: 0x18 (Inherited: 0x00)
struct FAtomHingedElement {
	struct TArray<struct FAtomRigidElement> RigidElements; // 0x00(0x10)
	int32_t HierarchyRootIndex; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct AtomRuntime.AtomModelPartReference
// Size: 0x14 (Inherited: 0x00)
struct FAtomModelPartReference {
	struct FGuid PrimitiveUUID; // 0x00(0x10)
	int32_t PartIndex; // 0x10(0x04)
};

// ScriptStruct AtomRuntime.AtomGlueSet
// Size: 0x50 (Inherited: 0x00)
struct FAtomGlueSet {
	struct TSet<struct FAtomModelPartReference> Entries; // 0x00(0x50)
};

// ScriptStruct AtomRuntime.AtomPrimitiveGroup
// Size: 0x18 (Inherited: 0x00)
struct FAtomPrimitiveGroup {
	struct FVector PivotOrigin; // 0x00(0x18)
};

// ScriptStruct AtomRuntime.AtomModelGeometryOptimizationSettings
// Size: 0x18 (Inherited: 0x00)
struct FAtomModelGeometryOptimizationSettings {
	bool bEnforceLODBudgets; // 0x00(0x01)
	bool bUseTagBudget; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	int32_t TriangleBudget; // 0x04(0x04)
	double SimplifyBaseTolerance; // 0x08(0x08)
	double OptimizeBaseTriCost; // 0x10(0x08)
};

// ScriptStruct AtomRuntime.AtomSelectionSetPrimitiveGroup
// Size: 0x20 (Inherited: 0x18)
struct FAtomSelectionSetPrimitiveGroup : FAtomPrimitiveGroup {
	struct FName SelectionSetName; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct AtomRuntime.AtomModelPrimitiveGroup
// Size: 0x18 (Inherited: 0x18)
struct FAtomModelPrimitiveGroup : FAtomPrimitiveGroup {
};

// ScriptStruct AtomRuntime.AtomRigidElementIndices
// Size: 0x0c (Inherited: 0x00)
struct FAtomRigidElementIndices {
	int32_t HingedElementIndex; // 0x00(0x04)
	int32_t RigidElementIndex; // 0x04(0x04)
	int32_t BoneIndex; // 0x08(0x04)
};

// ScriptStruct AtomRuntime.AtomResolvedModelPartReference
// Size: 0x18 (Inherited: 0x00)
struct FAtomResolvedModelPartReference {
	struct FAtomBoneReference Indices; // 0x00(0x0c)
	struct FAtomRigidElementIndices ElementIndices; // 0x0c(0x0c)
};

// ScriptStruct AtomRuntime.AtomRigidElementSettings
// Size: 0x1c (Inherited: 0x00)
struct FAtomRigidElementSettings {
	struct FAtomModelPartReference ElementIdentifyingPart; // 0x00(0x14)
	struct FName RigidElementName; // 0x14(0x04)
	bool MergeWithParentElement; // 0x18(0x01)
	bool ShouldBeRootElement; // 0x19(0x01)
	char pad_1A[0x2]; // 0x1a(0x02)
};

// ScriptStruct AtomRuntime.AtomModelTags
// Size: 0x10 (Inherited: 0x00)
struct FAtomModelTags {
	struct TArray<struct FName> Tags; // 0x00(0x10)
};

// ScriptStruct AtomRuntime.AtomModelAssetSettings
// Size: 0x28 (Inherited: 0x00)
struct FAtomModelAssetSettings {
	float Scale; // 0x00(0x04)
	bool CreateRigidElementComponents; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FAtomModelGeometryOptimizationSettings OptimizationSettings; // 0x08(0x18)
	bool bEnableConnectivity; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct AtomRuntime.AtomModelSelectionSet
// Size: 0x68 (Inherited: 0x00)
struct FAtomModelSelectionSet {
	struct TSet<struct FGuid> PrimitiveIds; // 0x00(0x50)
	struct FName SelectionSetName; // 0x50(0x04)
	struct FName ImportedName; // 0x54(0x04)
	struct FGuid ID; // 0x58(0x10)
};

// ScriptStruct AtomRuntime.AtomModelConfigurationGroup
// Size: 0xf0 (Inherited: 0x00)
struct FAtomModelConfigurationGroup {
	struct FGuid ID; // 0x00(0x10)
	struct FName Name; // 0x10(0x04)
	struct FGuid ParentGroupId; // 0x14(0x10)
	char pad_24[0x4]; // 0x24(0x04)
	struct TSet<struct FGuid> PrimitiveIds; // 0x28(0x50)
	struct TArray<struct FAtomModelSocket> Sockets; // 0x78(0x10)
	bool bHasGroupPivot; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
	struct FTransform GroupPivot; // 0x90(0x60)
};

// ScriptStruct AtomRuntime.AtomModelHierarchicalSceneNode
// Size: 0x90 (Inherited: 0x00)
struct FAtomModelHierarchicalSceneNode {
	struct FString Name; // 0x00(0x10)
	struct FTransform WorldTransform; // 0x10(0x60)
	int32_t ParentIndex; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct TArray<struct FString> ItemNames; // 0x78(0x10)
	char pad_88[0x8]; // 0x88(0x08)
};

// ScriptStruct AtomRuntime.AtomModelHierarchicalScene
// Size: 0x10 (Inherited: 0x00)
struct FAtomModelHierarchicalScene {
	struct TArray<struct FAtomModelHierarchicalSceneNode> SceneNodes; // 0x00(0x10)
};

// ScriptStruct AtomRuntime.AtomSourceModel
// Size: 0xa0 (Inherited: 0x00)
struct FAtomSourceModel {
	struct TArray<struct FAtomModelPrimitive> Primitives; // 0x00(0x10)
	struct TArray<struct FAtomHingedElement> Elements; // 0x10(0x10)
	struct TArray<struct FAtomModelSelectionSet> SelectionSets; // 0x20(0x10)
	struct TArray<struct FAtomGlueSet> GlueSets; // 0x30(0x10)
	struct TArray<struct FAtomModelConfigurationGroup> Groups; // 0x40(0x10)
	struct FBox Bounds; // 0x50(0x38)
	struct FVector Pivot; // 0x88(0x18)
};

// ScriptStruct AtomRuntime.AtomModelIssue
// Size: 0x18 (Inherited: 0x00)
struct FAtomModelIssue {
	enum class EAtomIssue Issue; // 0x00(0x04)
	int32_t ID; // 0x04(0x04)
	struct FString StringData; // 0x08(0x10)
};

// ScriptStruct AtomRuntime.ModelPrimitiveEntry
// Size: 0x38 (Inherited: 0x00)
struct FModelPrimitiveEntry {
	struct TSoftObjectPtr<UPrimitiveComponent> Component; // 0x00(0x20)
	struct FAtomModelPartReference PartReference; // 0x20(0x14)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct AtomRuntime.AtomProcessorResult
// Size: 0x28 (Inherited: 0x00)
struct FAtomProcessorResult {
	bool bSuccess; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct UObject*> ProcessedObjects; // 0x08(0x10)
	struct TArray<struct UObject*> SharedAssets; // 0x18(0x10)
};

// ScriptStruct AtomRuntime.AtomOnProcessPrimitiveSettings
// Size: 0x18 (Inherited: 0x00)
struct FAtomOnProcessPrimitiveSettings {
	struct FString CustomLocation; // 0x00(0x10)
	bool bSupportDecorations; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct AtomRuntime.AtomModelProcessorInstance
// Size: 0x28 (Inherited: 0x00)
struct FAtomModelProcessorInstance {
	bool bUseCustomSettings; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UAtomModelProcessor* Processor; // 0x08(0x08)
	struct UAtomModelProcessor* InternalTransientPropStorage; // 0x10(0x08)
	struct TArray<struct TSoftObjectPtr<UObject>> ProcessedObjects; // 0x18(0x10)
};

// ScriptStruct AtomRuntime.AtomPrimitiveConnectionPointReference
// Size: 0x04 (Inherited: 0x00)
struct FAtomPrimitiveConnectionPointReference {
	int16_t PlanarFieldIndex; // 0x00(0x02)
	int16_t ConnectionPointIndex; // 0x02(0x02)
};

// ScriptStruct AtomRuntime.AtomCommonPartDescription
// Size: 0x10 (Inherited: 0x00)
struct FAtomCommonPartDescription {
	float Radius; // 0x00(0x04)
	float Height; // 0x04(0x04)
	float InnerRadius; // 0x08(0x04)
	char PlaneQuadrant; // 0x0c(0x01)
	bool bShowLogo; // 0x0d(0x01)
	char pad_E[0x2]; // 0x0e(0x02)
};

// ScriptStruct AtomRuntime.AtomCommonPartInstance
// Size: 0x40 (Inherited: 0x00)
struct FAtomCommonPartInstance {
	struct FTransform3f Transform; // 0x00(0x30)
	struct FAtomPrimitiveConnectionPointReference ConnectionPointReference; // 0x30(0x04)
	char pad_34[0xc]; // 0x34(0x0c)
};

// ScriptStruct AtomRuntime.AtomPrimitiveCommonPart
// Size: 0x10 (Inherited: 0x00)
struct FAtomPrimitiveCommonPart {
	struct TArray<struct FAtomCommonPartInstance> UnscaledInstances; // 0x00(0x10)
};

// ScriptStruct AtomRuntime.AtomPrimitivePhysicsAttributes
// Size: 0xa0 (Inherited: 0x00)
struct FAtomPrimitivePhysicsAttributes {
	struct FMatrix InertiaTensor; // 0x00(0x80)
	struct FVector CenterOfMass; // 0x80(0x18)
	float Mass; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// ScriptStruct AtomRuntime.AtomPrimitiveUserNote
// Size: 0x20 (Inherited: 0x00)
struct FAtomPrimitiveUserNote {
	struct FString Text; // 0x00(0x10)
	struct FString PartRevision; // 0x10(0x10)
};

// ScriptStruct AtomRuntime.AtomPrimitiveOptimizationSettings
// Size: 0x30 (Inherited: 0x00)
struct FAtomPrimitiveOptimizationSettings {
	enum class EAtomPrimitiveGeoOptimization OptimizationType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	enum class EAtomPrimitiveGeoOptimization_Old GeometryOptions; // 0x04(0x04)
	enum class EAtomPrimitiveApproximationShapeType ApproximationShapeType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	enum class EAtomPrimitiveApproximationShapeType_Old ApproximationStrategy; // 0x0c(0x04)
	bool bUseOptimizationAxisOverride; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FVector ApproximationAxisOverride; // 0x18(0x18)
};

// ScriptStruct AtomRuntime.AtomPrimitiveStyleImportData
// Size: 0x28 (Inherited: 0x00)
struct FAtomPrimitiveStyleImportData {
	struct FString Revision; // 0x00(0x10)
	struct FString SourceDatabase; // 0x10(0x10)
	int32_t ImportWarnings; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct AtomRuntime.AtomPrimitiveDetailTextureData
// Size: 0x28 (Inherited: 0x00)
struct FAtomPrimitiveDetailTextureData {
	struct TSoftObjectPtr<UTexture> Texture; // 0x00(0x20)
	struct FName style; // 0x20(0x04)
	enum class EAtomPrimitiveDetailTextureType TextureType; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
};

// ScriptStruct AtomRuntime.AtomPrimitiveBevelOptions
// Size: 0x01 (Inherited: 0x00)
struct FAtomPrimitiveBevelOptions {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct AtomRuntime.AtomPrimitiveBuildOptions
// Size: 0x01 (Inherited: 0x00)
struct FAtomPrimitiveBuildOptions {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct AtomRuntime.AtomPrimitiveBuildSettings
// Size: 0x01 (Inherited: 0x00)
struct FAtomPrimitiveBuildSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct AtomRuntime.ConnectivityFieldConnection
// Size: 0x0c (Inherited: 0x00)
struct FConnectivityFieldConnection {
	struct FConnectivityFieldReference Reference; // 0x00(0x08)
	enum class EFieldConnectResult ConnectResult; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct AtomRuntime.LineFieldConnectionInfo
// Size: 0x0c (Inherited: 0x00)
struct FLineFieldConnectionInfo {
	bool Flip; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	enum class EFieldConnectResult ConnectResult; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct AtomRuntime.PointFieldConnectionInfo
// Size: 0x10 (Inherited: 0x00)
struct FPointFieldConnectionInfo {
	double OneAxisRotation; // 0x00(0x08)
	enum class EFieldConnectResult ConnectResult; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct AtomRuntime.HingeFieldConnectionInfo
// Size: 0x18 (Inherited: 0x10)
struct FHingeFieldConnectionInfo : FPointFieldConnectionInfo {
	bool Flip; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

