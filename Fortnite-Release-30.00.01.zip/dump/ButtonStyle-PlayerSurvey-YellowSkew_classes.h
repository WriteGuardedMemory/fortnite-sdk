// BlueprintGeneratedClass ButtonStyle-PlayerSurvey-YellowSkew.ButtonStyle-PlayerSurvey-YellowSkew_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-PlayerSurvey-YellowSkew_C : UCommonButtonStyle {
};

