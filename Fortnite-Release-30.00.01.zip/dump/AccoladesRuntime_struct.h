// Enum AccoladesRuntime.EFortAccoladeTierType
enum class EFortAccoladeTierType : uint8 {
	None = 0,
	Tier1 = 1,
	Tier2 = 2,
	Tier3 = 3,
	EFortAccoladeTierType_MAX = 4
};

// ScriptStruct AccoladesRuntime.PFWAccoladeCollection_AchievedAccolade_PersistentInfoData
// Size: 0x18 (Inherited: 0x00)
struct FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData {
	struct FString AccoladeName; // 0x00(0x10)
	uint32_t AccoladeCount; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct AccoladesRuntime.PFWAccoladeCollection_PinnedAccolade_PersistentInfoData
// Size: 0x10 (Inherited: 0x00)
struct FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData {
	struct FString AccoladeName; // 0x00(0x10)
};

// ScriptStruct AccoladesRuntime.PFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData
// Size: 0x10 (Inherited: 0x00)
struct FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData {
	struct TArray<struct FString> AccoladeNames; // 0x00(0x10)
};

// ScriptStruct AccoladesRuntime.PFWAccoladeCollection_PersistentInfo
// Size: 0x30 (Inherited: 0x00)
struct FPFWAccoladeCollection_PersistentInfo {
	struct TArray<struct FPFWAccoladeCollection_AchievedAccolade_PersistentInfoData> AccoladeCollection_AchievedAccolades; // 0x00(0x10)
	struct FPFWAccoladeCollection_PinnedAccolade_PersistentInfoData AccoladeCollection_PinnedAccolade; // 0x10(0x10)
	struct FPFWAccoladeCollection_UnacknowledgedAccolades_PersistentInfoData AccoladeCollection_UnacknowledgedAccolades; // 0x20(0x10)
};

// ScriptStruct AccoladesRuntime.FortAccoladeCollectionDataItem
// Size: 0x18 (Inherited: 0x0c)
struct FFortAccoladeCollectionDataItem : FFastArraySerializerItem {
	struct FName AccoladeName; // 0x0c(0x04)
	struct FFortAccoladeCollectionData CollectionData; // 0x10(0x08)
};

// ScriptStruct AccoladesRuntime.FortAccoladeCollectionData
// Size: 0x08 (Inherited: 0x00)
struct FFortAccoladeCollectionData {
	uint32_t AchievedCount; // 0x00(0x04)
	bool bAcknowledged; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
};

// ScriptStruct AccoladesRuntime.FortAccoladeCollectionDataArray
// Size: 0x120 (Inherited: 0x108)
struct FFortAccoladeCollectionDataArray : FFastArraySerializer {
	char pad_108[0x8]; // 0x108(0x08)
	struct TArray<struct FFortAccoladeCollectionDataItem> AccoladeCollectionData; // 0x110(0x10)
};

// ScriptStruct AccoladesRuntime.FortAccoladeSessionData
// Size: 0x0c (Inherited: 0x00)
struct FFortAccoladeSessionData {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct AccoladesRuntime.FortUpdatedTrackedAccoladeData
// Size: 0x14 (Inherited: 0x0c)
struct FFortUpdatedTrackedAccoladeData : FFastArraySerializerItem {
	struct FName AccoladeRowName; // 0x0c(0x04)
	uint32_t Count; // 0x10(0x04)
};

// ScriptStruct AccoladesRuntime.FortUpdatedTrackedAccoladeDataArray
// Size: 0x120 (Inherited: 0x108)
struct FFortUpdatedTrackedAccoladeDataArray : FFastArraySerializer {
	char pad_108[0x8]; // 0x108(0x08)
	struct TArray<struct FFortUpdatedTrackedAccoladeData> UpdatedTrackedAccolades; // 0x110(0x10)
};

// ScriptStruct AccoladesRuntime.FortCompletedAccoladeData
// Size: 0x18 (Inherited: 0x0c)
struct FFortCompletedAccoladeData : FFastArraySerializerItem {
	struct FName AccoladeRowName; // 0x0c(0x04)
	uint32_t XPAwarded; // 0x10(0x04)
	enum class EFortAccoladeType AccoladeType; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct AccoladesRuntime.FortCompletedAccoladeDataArray
// Size: 0x120 (Inherited: 0x108)
struct FFortCompletedAccoladeDataArray : FFastArraySerializer {
	char pad_108[0x8]; // 0x108(0x08)
	struct TArray<struct FFortCompletedAccoladeData> CompletedAccolades; // 0x110(0x10)
};

// ScriptStruct AccoladesRuntime.FortAccoladesTableRow
// Size: 0xc8 (Inherited: 0x08)
struct FFortAccoladesTableRow : FTableRowBase {
	struct FInstancedStruct EventConditional; // 0x08(0x10)
	struct TArray<struct FInstancedStruct> EventRewards; // 0x18(0x10)
	struct TArray<struct FInstancedStruct> OneTimeEventRewards; // 0x28(0x10)
	struct FText DisplayName; // 0x38(0x10)
	struct FText DisplayDescription; // 0x48(0x10)
	int32_t DisplayOrder; // 0x58(0x04)
	enum class EFortAccoladeType AccoladeType; // 0x5c(0x01)
	enum class EXPEventPriorityType Priority; // 0x5d(0x01)
	enum class EFortAccoladeTierType AccoladeTier; // 0x5e(0x01)
	char pad_5F[0x1]; // 0x5f(0x01)
	struct TSoftObjectPtr<USoundCue> AwardedSoundCue; // 0x60(0x20)
	struct TSoftObjectPtr<UTexture2D> PreviewImage; // 0x80(0x20)
	int32_t MaxMatchCount; // 0xa0(0x04)
	int32_t MaxPlayerCount; // 0xa4(0x04)
	struct FGameplayTagContainer Tags; // 0xa8(0x20)
};

// ScriptStruct AccoladesRuntime.FortTriggeredAccoladeData
// Size: 0x70 (Inherited: 0x00)
struct FFortTriggeredAccoladeData {
	char pad_0[0x70]; // 0x00(0x70)
};

