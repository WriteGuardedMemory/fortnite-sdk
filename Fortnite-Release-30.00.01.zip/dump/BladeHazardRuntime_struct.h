// Enum BladeHazardRuntime.EFortSawBladeSpinningDirection
enum class EFortSawBladeSpinningDirection : uint8 {
	Clockwise = 0,
	Counterclockwise = 1,
	SnapToCustomDirections = 2,
	EFortSawBladeSpinningDirection_MAX = 3
};

