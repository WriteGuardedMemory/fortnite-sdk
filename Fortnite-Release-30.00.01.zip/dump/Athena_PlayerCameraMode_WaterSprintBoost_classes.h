// BlueprintGeneratedClass Athena_PlayerCameraMode_WaterSprintBoost.Athena_PlayerCameraMode_WaterSprintBoost_C
// Size: 0x1cd0 (Inherited: 0x1cd0)
struct UAthena_PlayerCameraMode_WaterSprintBoost_C : UAthena_PlayerCameraModeBase_C {
};

