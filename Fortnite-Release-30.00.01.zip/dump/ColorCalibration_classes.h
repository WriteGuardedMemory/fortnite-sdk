// WidgetBlueprintGeneratedClass ColorCalibration.ColorCalibration_C
// Size: 0x540 (Inherited: 0x538)
struct UColorCalibration_C : UFortColorCalibrationScreen {
	struct UImage* InputBlocker; // 0x538(0x08)
};

