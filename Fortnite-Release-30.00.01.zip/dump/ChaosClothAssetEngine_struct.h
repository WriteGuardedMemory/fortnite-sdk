// Enum ChaosClothAssetEngine.EClothAssetAsyncProperties
enum class EClothAssetAsyncProperties : int32 {
	None = 0,
	RenderData = 1,
	ThumbnailInfo = 2,
	ImportedModel = 4,
	ClothCollection = 8,
	RefSkeleton = 16,
	All = -1,
	EClothAssetAsyncProperties_MAX = 17
};

// ScriptStruct ChaosClothAssetEngine.ChaosClothAssetLodTransitionDataCache
// Size: 0x38 (Inherited: 0x00)
struct FChaosClothAssetLodTransitionDataCache {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct ChaosClothAssetEngine.ChaosClothSimulationLodModel
// Size: 0x1f0 (Inherited: 0x00)
struct FChaosClothSimulationLodModel {
	struct TArray<struct FVector3f> Positions; // 0x00(0x10)
	struct TArray<struct FVector3f> Normals; // 0x10(0x10)
	struct TArray<uint32_t> Indices; // 0x20(0x10)
	struct TArray<struct FClothVertBoneData> BoneData; // 0x30(0x10)
	struct TArray<uint16_t> RequiredExtraBoneIndices; // 0x40(0x10)
	char pad_50[0x20]; // 0x50(0x20)
	struct TArray<struct FVector2f> PatternPositions; // 0x70(0x10)
	struct TArray<uint32_t> PatternIndices; // 0x80(0x10)
	struct TArray<uint32_t> PatternToWeldedIndices; // 0x90(0x10)
	char pad_A0[0x50]; // 0xa0(0x50)
	struct FClothTetherData TetherData; // 0xf0(0x10)
	char pad_100[0xf0]; // 0x100(0xf0)
};

// ScriptStruct ChaosClothAssetEngine.ChaosClothSimulationModel
// Size: 0x38 (Inherited: 0x00)
struct FChaosClothSimulationModel {
	struct TArray<struct FChaosClothSimulationLodModel> ClothSimulationLodModels; // 0x00(0x10)
	struct TArray<struct FName> UsedBoneNames; // 0x10(0x10)
	struct TArray<int32_t> UsedBoneIndices; // 0x20(0x10)
	int32_t ReferenceBoneIndex; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

