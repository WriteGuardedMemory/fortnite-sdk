// BlueprintGeneratedClass B_HidingProp.B_HidingProp_C
// Size: 0x1200 (Inherited: 0xc28)
struct AB_HidingProp_C : AFortHidingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc28(0x08)
	struct USceneComponent* ProjectileLocation_ForwardVector; // 0xc30(0x08)
	struct UStaticMeshComponent* LandedOnCollisionMesh; // 0xc38(0x08)
	struct USphereComponent* Sphere; // 0xc40(0x08)
	struct USceneComponent* HideLocation_ForwardVector; // 0xc48(0x08)
	float Loot_MovementTimeline_Forward_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xc50(0x04)
	float Loot_MovementTimeline_Z_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xc54(0x04)
	enum class ETimelineDirection Loot_MovementTimeline__Direction_0FC694AE4A45D691CB6BD5A8CD00E521; // 0xc58(0x01)
	char pad_C59[0x7]; // 0xc59(0x07)
	struct UTimelineComponent* Loot_MovementTimeline; // 0xc60(0x08)
	struct FScalableFloat Enabled; // 0xc68(0x28)
	struct FScalableFloat HidingEnabled; // 0xc90(0x28)
	struct FScalableFloat PlayerLimit; // 0xcb8(0x28)
	struct FScalableFloat TeleportEnabled; // 0xce0(0x28)
	struct FScalableFloat CanTeleport; // 0xd08(0x28)
	struct TArray<struct AFortPawn*> HidingPlayers; // 0xd30(0x10)
	struct FGameplayTag EnterGameplayCue; // 0xd40(0x04)
	struct FGameplayTag ExitGameplayCue; // 0xd44(0x04)
	struct FGameplayTag LandedOnGameplayCue; // 0xd48(0x04)
	char pad_D4C[0x4]; // 0xd4c(0x04)
	struct UMaterialInstanceDynamic* Mid; // 0xd50(0x08)
	struct FGameplayTag RustleGameplayCue; // 0xd58(0x04)
	struct FGameplayTag ExitGameplayCue_Player; // 0xd5c(0x04)
	struct FGameplayTag WhileEnteringGameplayCue; // 0xd60(0x04)
	char pad_D64[0x4]; // 0xd64(0x04)
	double ObstructionTraceLength; // 0xd68(0x08)
	struct TArray<enum class EObjectTypeQuery> DestroyObjectTypes; // 0xd70(0x10)
	struct TArray<struct AFortPawn*> Array; // 0xd80(0x10)
	int32_t int; // 0xd90(0x04)
	char pad_D94[0x4]; // 0xd94(0x04)
	struct FVector DeimosPropSpawnerOffset; // 0xd98(0x18)
	bool FixedEntranceDirection; // 0xdb0(0x01)
	char pad_DB1[0x7]; // 0xdb1(0x07)
	double MaxInteractAngle; // 0xdb8(0x08)
	struct FVector WobbleLocationOffset; // 0xdc0(0x18)
	double InteractBelowPropDistance; // 0xdd8(0x08)
	struct TMap<struct AFortPawn*, double> HiddenPlayersAndEnterTimes; // 0xde0(0x50)
	struct AFortPawn* LastPawnToInteract; // 0xe30(0x08)
	struct AB_HidingProp_C* TargetTeleporter; // 0xe38(0x08)
	struct FGameplayTag TeleporterEnterGameplayCue; // 0xe40(0x04)
	struct FGameplayTag TeleporterExitGameplayCue; // 0xe44(0x04)
	struct FGameplayTag LoopingTeleportingCue; // 0xe48(0x04)
	struct FGameplayTag GC_Wobble; // 0xe4c(0x04)
	struct FTimerHandle WobbleTimerHandle; // 0xe50(0x08)
	struct TArray<struct FGameplayTag> BlockEntranceTags; // 0xe58(0x10)
	struct TArray<struct FGameplayTag> BlockExitTags; // 0xe68(0x10)
	struct UAnimMontage* EnterAnimMontage; // 0xe78(0x08)
	struct UAnimMontage* ExitAnimMontage; // 0xe80(0x08)
	struct AFortPawn* LastPawnToHide; // 0xe88(0x08)
	struct FGameplayTag TeleportingStateGC; // 0xe90(0x04)
	bool RandomWobbleNormal; // 0xe94(0x01)
	bool SingleOccupant; // 0xe95(0x01)
	bool Teleporting; // 0xe96(0x01)
	bool JumpOut; // 0xe97(0x01)
	struct UGameplayEffect* GE_OnExitingPropNoJump_BlockActions; // 0xe98(0x08)
	bool DestroyInNonSpyLTM; // 0xea0(0x01)
	bool ActiveInSpyLTM; // 0xea1(0x01)
	char pad_EA2[0x6]; // 0xea2(0x06)
	struct TArray<struct FGameplayTag> ForceAllowInteractTags; // 0xea8(0x10)
	struct FGameplayTag IsTeleporter; // 0xeb8(0x04)
	struct FGameplayTag ContainsPlayerRepNof; // 0xebc(0x04)
	struct FVector ObstructionTraceExtents; // 0xec0(0x18)
	struct FVector ObstructionTraceStartOffSet; // 0xed8(0x18)
	double ExitLaunchVelocity; // 0xef0(0x08)
	struct FVector AdditionalLaunchVelocity; // 0xef8(0x18)
	struct FVector Obstruction Trace End; // 0xf10(0x18)
	struct FVector FixedEntraceObstructionTraceEndOffset; // 0xf28(0x18)
	bool isActiveTeleportExit; // 0xf40(0x01)
	char pad_F41[0x7]; // 0xf41(0x07)
	struct UGameplayEffect* GE_TeleportAbilityGranted; // 0xf48(0x08)
	bool DisableWhenSubmergedInWater; // 0xf50(0x01)
	char pad_F51[0x7]; // 0xf51(0x07)
	struct FGameplayTagContainer DisableWhenSubmergedExceptionTags; // 0xf58(0x20)
	struct TArray<struct AFortPawn*> NonCosmeticPawns; // 0xf78(0x10)
	struct UCameraModifier* CameraModifier; // 0xf88(0x08)
	struct FVector ; // 0xf90(0x18)
	struct AActor* Pawn; // 0xfa8(0x08)
	struct FVector Loot_CachedActorForward; // 0xfb0(0x18)
	struct TArray<struct FVector> Loot_VectorOffsets; // 0xfc8(0x10)
	bool SpawnedLoot; // 0xfd8(0x01)
	char pad_FD9[0x7]; // 0xfd9(0x07)
	double Loot_MoveForwardDistance; // 0xfe0(0x08)
	double Loot_MoveUpDistance; // 0xfe8(0x08)
	double Loot_SpawnRadius; // 0xff0(0x08)
	struct FVector Loot_SpawnOffset; // 0xff8(0x18)
	bool ShouldSpawnLoot; // 0x1010(0x01)
	char pad_1011[0x7]; // 0x1011(0x07)
	struct FString Loot Tier Group; // 0x1018(0x10)
	bool SetEntranceRotation; // 0x1028(0x01)
	char pad_1029[0x7]; // 0x1029(0x07)
	struct UGameplayEffect* PropSpecificEffectToApplyToHiders; // 0x1030(0x08)
	struct FScalableFloat RustlesPerWobble; // 0x1038(0x28)
	struct FScalableFloat RustleWobbleRadius; // 0x1060(0x28)
	struct FScalableFloat EnterWobbleRadius; // 0x1088(0x28)
	double NonJumpExitDistance; // 0x10b0(0x08)
	struct UFortCameraMode* Camera Mode; // 0x10b8(0x08)
	bool MoveToActorOnEnter; // 0x10c0(0x01)
	bool IgnorePhysicsBodyCollisionOnEnter; // 0x10c1(0x01)
	bool bCanRustleAndWobble; // 0x10c2(0x01)
	bool SkipRestoreCameraViewTargetOnStopHiding; // 0x10c3(0x01)
	bool SkipRootMotionMovementOnStopHiding; // 0x10c4(0x01)
	char pad_10C5[0x3]; // 0x10c5(0x03)
	struct FRotator AddedSetEntranceRotation; // 0x10c8(0x18)
	double MoveToActorDelayOnEnter; // 0x10e0(0x08)
	double MoveToActorDurationOverride; // 0x10e8(0x08)
	struct FMarkedActorDisplayInfo MarkerDisplay; // 0x10f0(0xa0)
	struct FVector MarkerPositionOffset; // 0x1190(0x18)
	bool ObstructionTraceByObject; // 0x11a8(0x01)
	char pad_11A9[0x7]; // 0x11a9(0x07)
	struct FScalableFloat Hiding Enable From Landing; // 0x11b0(0x28)
	struct FScalableFloat ; // 0x11d8(0x28)

	bool BlueprintOnLocalInteract(struct AFortPlayerPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintOnLocalInteract // (BlueprintCosmetic|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void GetObstructionTraceParams(struct ACharacter* InCharacter, struct FVector& TraceStart, struct FVector& TraceEnd, struct FVector& TraceExtents, struct FRotator& TraceOrientation, struct TArray<struct AActor*>& ActorsToIgnore); // Function B_HidingProp.B_HidingProp_C.GetObstructionTraceParams // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
	void Get Obstruction Objects(bool TraceByChannel, struct FVector Start, struct FVector End, struct FVector HalfSize, struct FRotator orientation, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct FHitResult>& OutHits); // Function B_HidingProp.B_HidingProp_C.Get Obstruction Objects // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	struct FVector GetMarkerPositionOffset(); // Function B_HidingProp.B_HidingProp_C.GetMarkerPositionOffset // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	struct FMarkedActorDisplayInfo GetMarkerDisplayData(); // Function B_HidingProp.B_HidingProp_C.GetMarkerDisplayData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void GetTurnClientCameraCollisionOnDelayTime(double& Delay); // Function B_HidingProp.B_HidingProp_C.GetTurnClientCameraCollisionOnDelayTime // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
	void Can Hide by Falling(struct AActor* OtherActor, bool& CanHide, struct AFortPlayerPawn*& aFortPlayerPawn); // Function B_HidingProp.B_HidingProp_C.Can Hide by Falling // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Player Getting in Prop(struct AFortPawn* FortPawn, bool& Is Getting In); // Function B_HidingProp.B_HidingProp_C.Player Getting in Prop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void Player Hidden in Prop(struct AFortPawn* Fort Pawn, bool& IsHidden); // Function B_HidingProp.B_HidingProp_C.Player Hidden in Prop // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void LocalOnFailedInteract(struct AFortPlayerPawn* InteractingPawn); // Function B_HidingProp.B_HidingProp_C.LocalOnFailedInteract // (Event|Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0x18e3f1c
	float GetMinDistanceFromInteraction(); // Function B_HidingProp.B_HidingProp_C.GetMinDistanceFromInteraction // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x18e3f1c
	void GetPlayerLimit(int32_t& PlayerLimit); // Function B_HidingProp.B_HidingProp_C.GetPlayerLimit // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void Allow Cosmetics For Pawn(struct AFortPawn*& Pawn, bool& Allow); // Function B_HidingProp.B_HidingProp_C.Allow Cosmetics For Pawn // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnRep_ContainsPlayer(); // Function B_HidingProp.B_HidingProp_C.OnRep_ContainsPlayer // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnRep_IsTeleporter(); // Function B_HidingProp.B_HidingProp_C.OnRep_IsTeleporter // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	bool CheckCanUsePassage(struct UObject* Object); // Function B_HidingProp.B_HidingProp_C.CheckCanUsePassage // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	bool IsInInfiltrationLTM(); // Function B_HidingProp.B_HidingProp_C.IsInInfiltrationLTM // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
	void OnRep_Teleporting(); // Function B_HidingProp.B_HidingProp_C.OnRep_Teleporting // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	struct FText BlueprintGetFailedInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetFailedInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x18e3f1c
	void RemoveHiddenPlayer(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.RemoveHiddenPlayer // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void AddHiddenPlayer(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.AddHiddenPlayer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnRep_HidingPlayers(); // Function B_HidingProp.B_HidingProp_C.OnRep_HidingPlayers // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float& OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x18e3f1c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x18e3f1c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function B_HidingProp.B_HidingProp_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void Loot_MovementTimeline__FinishedFunc(); // Function B_HidingProp.B_HidingProp_C.Loot_MovementTimeline__FinishedFunc // (BlueprintEvent) // @ game+0x18e3f1c
	void Loot_MovementTimeline__UpdateFunc(); // Function B_HidingProp.B_HidingProp_C.Loot_MovementTimeline__UpdateFunc // (BlueprintEvent) // @ game+0x18e3f1c
	void OnReady_64CBF02E419FF250B433D5B2A6E5D744(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function B_HidingProp.B_HidingProp_C.OnReady_64CBF02E419FF250B433D5B2A6E5D744 // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnCurieActive_F2BFC8C54691C42FB5230BA7B7DEE141(); // Function B_HidingProp.B_HidingProp_C.OnCurieActive_F2BFC8C54691C42FB5230BA7B7DEE141 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_HidingProp.B_HidingProp_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function B_HidingProp.B_HidingProp_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__S_Athena_Launchpad_Collision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function B_HidingProp.B_HidingProp_C.BndEvt__S_Athena_Launchpad_Collision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void LandedOnHayStack(struct AFortPlayerPawn* PlayerPawn, double Z Velocity Mag); // Function B_HidingProp.B_HidingProp_C.LandedOnHayStack // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void LaunchPlayersOffTop(struct AFortPlayerPawn* PlayerPawn); // Function B_HidingProp.B_HidingProp_C.LaunchPlayersOffTop // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function B_HidingProp.B_HidingProp_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void StopHidingLoop(); // Function B_HidingProp.B_HidingProp_C.StopHidingLoop // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HidingPlayerCountChanged(); // Function B_HidingProp.B_HidingProp_C.HidingPlayerCountChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void InteractEnter(); // Function B_HidingProp.B_HidingProp_C.InteractEnter // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void EndHidingAnalyticSession(struct AFortPawn* FortPawn, enum class EEnvironmentalItemEndReason EndReason); // Function B_HidingProp.B_HidingProp_C.EndHidingAnalyticSession // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void WatchForPlayerDeath(struct AFortPawn* FortPawn); // Function B_HidingProp.B_HidingProp_C.WatchForPlayerDeath // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Pawn Died(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function B_HidingProp.B_HidingProp_C.Pawn Died // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void StopHiding(struct AFortPawn* Pawn); // Function B_HidingProp.B_HidingProp_C.StopHiding // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function B_HidingProp.B_HidingProp_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void Teleport(struct AActor* Pawn); // Function B_HidingProp.B_HidingProp_C.Teleport // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void IgnorePawnCollision(struct AFortPawn* Target, double InIgnoreDuration); // Function B_HidingProp.B_HidingProp_C.IgnorePawnCollision // (Net|NetReliableNetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ToggleCameraCollisionForClients(); // Function B_HidingProp.B_HidingProp_C.ToggleCameraCollisionForClients // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void StartHiding(struct AFortPawn* InteractingPawn); // Function B_HidingProp.B_HidingProp_C.StartHiding // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void TurnClientCameraCollisionOn(); // Function B_HidingProp.B_HidingProp_C.TurnClientCameraCollisionOn // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void AddGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.AddGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void RemoveGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.RemoveGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteGameplayCue(struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& CueParameters); // Function B_HidingProp.B_HidingProp_C.ExecuteGameplayCue // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnMatchStarted(); // Function B_HidingProp.B_HidingProp_C.OnMatchStarted // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void Launch Pickups(struct TArray<struct AFortPickup*>& Array, struct AActor* Pawn); // Function B_HidingProp.B_HidingProp_C.Launch Pickups // (Net|NetReliableNetMulticast|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void EntranceBlockedByUndamageable(struct AFortPlayerPawn* PlayerPawn); // Function B_HidingProp.B_HidingProp_C.EntranceBlockedByUndamageable // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void IgnorePhysicsCollisionDamage(struct AFortPawn* Target, double Ignore Duration); // Function B_HidingProp.B_HidingProp_C.IgnorePhysicsCollisionDamage // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void BP_HandleExitPressed(struct AFortPlayerPawn* TargetPlayerPawn); // Function B_HidingProp.B_HidingProp_C.BP_HandleExitPressed // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_B_HidingProp(int32_t EntryPoint); // Function B_HidingProp.B_HidingProp_C.ExecuteUbergraph_B_HidingProp // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

