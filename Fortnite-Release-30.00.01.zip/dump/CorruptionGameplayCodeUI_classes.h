// Class CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget
// Size: 0x360 (Inherited: 0x358)
struct UFortPowerupReticleExtensionWidget : UFortWeaponReticleExtensionWidgetBase {
	enum class EPowerupHeatState LastPowerupHeatState; // 0x358(0x01)
	char pad_359[0x7]; // 0x359(0x07)

	float GetOverheatingMaxValue(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetOverheatingMaxValue // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb8b7d20
	float GetCurrentOverheatValue(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetCurrentOverheatValue // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb8b7cf8
	float GetCurrentOverheatPercent(); // Function CorruptionGameplayCodeUI.FortPowerupReticleExtensionWidget.GetCurrentOverheatPercent // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb8b7cd0
};

