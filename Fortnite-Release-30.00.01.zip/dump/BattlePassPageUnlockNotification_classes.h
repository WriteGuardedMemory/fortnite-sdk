// BlueprintGeneratedClass BattlePassPageUnlockNotification.BattlePassPageUnlockNotification_C
// Size: 0x110 (Inherited: 0x110)
struct UBattlePassPageUnlockNotification_C : UFortUIBattlePassPageUnlockNotification {
};

