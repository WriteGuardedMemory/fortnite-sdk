// Class AtomRuntime.AtomAssetImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomAssetImportData : UAssetImportData {
};

// Class AtomRuntime.AtomModelMergedMeshImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomModelMergedMeshImportData : UAssetImportData {
};

// Class AtomRuntime.AtomModelGeometryCollectionImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomModelGeometryCollectionImportData : UAssetImportData {
};

// Class AtomRuntime.AtomColorLUTAtlas
// Size: 0x40 (Inherited: 0x28)
struct UAtomColorLUTAtlas : UObject {
	struct UTexture2D* AtlasTexture; // 0x28(0x08)
	struct TArray<struct UTexture2D*> Textures; // 0x30(0x10)

	int32_t GetLUTIndex(struct UTexture2D* InTexture); // Function AtomRuntime.AtomColorLUTAtlas.GetLUTIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef1df0
	int32_t GetAtlasSize(); // Function AtomRuntime.AtomColorLUTAtlas.GetAtlasSize // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef1654
	int32_t FindOrAddLUTIndex(struct UTexture2D* InTexture); // Function AtomRuntime.AtomColorLUTAtlas.FindOrAddLUTIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xbef14c8
};

// Class AtomRuntime.AtomDatabaseSubsystemBase
// Size: 0x30 (Inherited: 0x30)
struct UAtomDatabaseSubsystemBase : UEngineSubsystem {
};

// Class AtomRuntime.AtomModelActor
// Size: 0x2a8 (Inherited: 0x290)
struct AAtomModelActor : AActor {
	struct UAtomModel* AtomModel; // 0x290(0x08)
	struct FString PrimitiveStyleName; // 0x298(0x10)
};

// Class AtomRuntime.AtomModelAssetUserData
// Size: 0x58 (Inherited: 0x28)
struct UAtomModelAssetUserData : UAssetUserData {
	struct FSerializedConnectivityObjects AtomModelConnections; // 0x28(0x20)
	struct TArray<struct FName> Tags; // 0x48(0x10)
};

// Class AtomRuntime.AtomCommonPartModelAssetUserData
// Size: 0x38 (Inherited: 0x28)
struct UAtomCommonPartModelAssetUserData : UAssetUserData {
	struct FAtomCommonPartAssetDescription AssetDescription; // 0x28(0x0c)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class AtomRuntime.AtomPartsCollectionBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomPartsCollectionBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetName(struct FAtomModelPartsCollection& PartsCollection, struct FString Name); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.SetName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbef39fc
	void ReplacePartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartInstanceInfo& SourcePartInstance, struct FAtomModelPartGuid& TargetPartInstanceId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.ReplacePartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbef30dc
	void RemovePartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartGuid& PartInstanceId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.RemovePartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbef2fc8
	struct FAtomModelPartsCollection InitializeCommonParts(struct FAtomModelPartsCollection& PartsCollection, struct UAtomModel* Model, float Scale, int32_t CommonPartOptimizationFlags); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.InitializeCommonParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbef2d40
	struct TArray<struct FAtomCommonPartAndTransform> GetPrimitiveCommonParts(struct UAtomPrimitive* Primitive, double Scale); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetPrimitiveCommonParts // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbef2998
	struct TArray<struct FAtomModelPartInstanceInfo> GetParts(struct FAtomModelPartsCollection& PartsCollection); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbef28d0
	struct FString GetName(struct FAtomModelPartsCollection& PartsCollection); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbef1fdc
	int32_t GetModelPartGuidHash(struct FAtomModelPartGuid& InModelPartGuid); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetModelPartGuidHash // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbef1f1c
	struct FAtomModelPartsCollection FilterTransparent(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterTransparent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbef0cd4
	struct FAtomModelPartsCollection FilterSelectionSet(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString SelectionSetName, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterSelectionSet // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbef0424
	struct FAtomModelPartsCollection FilterNonTransparent(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterNonTransparent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbeefc30
	struct FAtomModelPartsCollection FilterGroup(struct UAtomModel* Model, struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString GroupName, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterGroup // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbeef31c
	struct FAtomModelPartColorInfo CreateColorInfoFromColorId(int32_t ColorId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.CreateColorInfoFromColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbeef198
	struct FAtomModelPartGuid Conv_StringToModelPartGuid(struct FString InString); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.Conv_StringToModelPartGuid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xbeee190
	struct FString Conv_ModelPartGuidToString(struct FAtomModelPartGuid& InModelPartGuid); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.Conv_ModelPartGuidToString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbeee0dc
	void AddPartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartInstanceInfo& PartInstance); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.AddPartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbeed1e0
};

// Class AtomRuntime.AtomPrimitiveBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomPrimitiveBlueprintLibrary : UBlueprintFunctionLibrary {

	float GetDefaultPrimitiveScale(); // Function AtomRuntime.AtomPrimitiveBlueprintLibrary.GetDefaultPrimitiveScale // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef1dc8
};

// Class AtomRuntime.AtomPrimitiveGeometry
// Size: 0x2e8 (Inherited: 0x28)
struct UAtomPrimitiveGeometry : UObject {
	char pad_28[0x2c0]; // 0x28(0x2c0)

	struct UStaticMesh* ToSimplifiedStaticMesh(float Scale, struct UObject* Outer, struct FString Name, bool bFastBuild); // Function AtomRuntime.AtomPrimitiveGeometry.ToSimplifiedStaticMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef43d8
	struct TArray<struct UAtomPrimitiveGeometry*> SplitByPolygonGroup(); // Function AtomRuntime.AtomPrimitiveGeometry.SplitByPolygonGroup // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef436c
	struct UAtomPrimitiveGeometry* SetVertexColor(struct FColor& Color); // Function AtomRuntime.AtomPrimitiveGeometry.SetVertexColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbef4298
	struct UAtomPrimitiveGeometry* SetTiledUVs(float TileSize); // Function AtomRuntime.AtomPrimitiveGeometry.SetTiledUVs // (Final|Native|Public|BlueprintCallable) // @ game+0xbef41c8
	struct UAtomPrimitiveGeometry* SetMaterialName(struct FString Name, int32_t PolygonGroupIndex); // Function AtomRuntime.AtomPrimitiveGeometry.SetMaterialName // (Final|Native|Public|BlueprintCallable) // @ game+0xbef3258
	int32_t GetNumberOfCommonPartLODs(struct FString ExportStyleName, enum class EAtomCommonPartType CommonPartType, struct FString CommonPartsMeshPath); // Function AtomRuntime.AtomPrimitiveGeometry.GetNumberOfCommonPartLODs // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef20b8
	struct TArray<struct FString> GetMaterialNames(); // Function AtomRuntime.AtomPrimitiveGeometry.GetMaterialNames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef1ee0
	int32_t GetBoneIndexForName(struct FString BoneName); // Function AtomRuntime.AtomPrimitiveGeometry.GetBoneIndexForName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef1684
	struct UAtomPrimitiveGeometry* DuplicateGeometry(); // Function AtomRuntime.AtomPrimitiveGeometry.DuplicateGeometry // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xbeef2e0
	struct UAtomPrimitiveGeometry* CreateEmptyAtomGeometry(); // Function AtomRuntime.AtomPrimitiveGeometry.CreateEmptyAtomGeometry // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbeef28c
	struct UAtomPrimitiveGeometry* CreateAtomGeometryFromCommonPart(struct FString ExportStyleName, enum class EAtomCommonPartType CommonPartType, int32_t LODIndex, struct FString CommonPartsMeshPath); // Function AtomRuntime.AtomPrimitiveGeometry.CreateAtomGeometryFromCommonPart // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbeee90c
	struct UAtomPrimitiveGeometry* CopyNormalMapsToUV0(); // Function AtomRuntime.AtomPrimitiveGeometry.CopyNormalMapsToUV0 // (Final|Native|Public|BlueprintCallable) // @ game+0xbeee8e8
	struct UAtomPrimitiveGeometry* BakeTransforms(struct TArray<struct FTransform3f>& Transforms); // Function AtomRuntime.AtomPrimitiveGeometry.BakeTransforms // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xbeee030
	struct UAtomPrimitiveGeometry* BakeTransform(struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.BakeTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbeedf64
	struct UAtomPrimitiveGeometry* BakeScale(float Scale); // Function AtomRuntime.AtomPrimitiveGeometry.BakeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xbeede94
	void AttachVerticesToNamedBone(struct FString BoneName); // Function AtomRuntime.AtomPrimitiveGeometry.AttachVerticesToNamedBone // (Final|Native|Public|BlueprintCallable) // @ game+0xbeed748
	void AttachVerticesToBoneIndex(int32_t BoneIndex); // Function AtomRuntime.AtomPrimitiveGeometry.AttachVerticesToBoneIndex // (Final|Native|Public|BlueprintCallable) // @ game+0xbeed688
	struct UAtomPrimitiveGeometry* AppendAndWeld(struct UAtomPrimitiveGeometry* GeometryToAppend, struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.AppendAndWeld // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbeed4a4
	struct UAtomPrimitiveGeometry* Append(struct UAtomPrimitiveGeometry* GeometryToAppend, struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.Append // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbeed310
};

// Class AtomRuntime.AtomPrimitiveGeometryContainer
// Size: 0x120 (Inherited: 0x28)
struct UAtomPrimitiveGeometryContainer : UObject {
	struct TSoftObjectPtr<UStaticMesh> SourceMesh; // 0x28(0x20)
	struct FString ExportStyleName; // 0x48(0x10)
	int32_t LOD; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct TMap<struct FString, int32_t> GeometryCount; // 0x60(0x50)
	struct FString AlphaMaskTextureName; // 0xb0(0x10)
	struct FString NormalMapTextureName; // 0xc0(0x10)
	char pad_D0[0x50]; // 0xd0(0x50)

	struct FAtomPrimitiveCollisionGeometry MakePrimitiveCollisionGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.MakePrimitiveCollisionGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef9c7c
	bool HasCollisionGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.HasCollisionGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef9c58
	struct FAtomPrimitiveGeometryAndTransform GetShellGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetShellGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef995c
	struct FAtomPrimitiveGeometryAndTransform GetScaledShellGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledShellGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef9868
	struct UAtomPrimitiveGeometry* GetScaledGeometry(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef9718
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetScaledDetailsGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledDetailsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef9630
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetScaledCollisionGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledCollisionGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef9548
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetScaledCapsGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledCapsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef9460
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetPartsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetPartsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef9190
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetOtherCapsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetOtherCapsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef8e7c
	int32_t GetLOD(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetLOD // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6b9674c
	struct UAtomPrimitiveGeometry* GetGeometryWithMaterialNames(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, struct FString ShellMaterial, struct FString UndersideMaterial); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometryWithMaterialNames // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef850c
	struct UAtomPrimitiveGeometry* GetGeometrySectionWithMaterialNames(int32_t PrimitiveGeometrySectionFlags, struct FString ShellMaterial, struct FString UndersideMaterial); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometrySectionWithMaterialNames // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef7c90
	struct UAtomPrimitiveGeometry* GetGeometrySection(int32_t PrimitiveGeometrySectionFlag); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometrySection // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef7ba4
	struct UAtomPrimitiveGeometry* GetGeometry(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef7ad4
	struct FString GetExportStyleName(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetExportStyleName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb3a17f0
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetDetailsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetDetailsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef7904
	struct TArray<struct FTransform> GetDefaultBoneTransforms(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetDefaultBoneTransforms // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef7820
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetCollisionGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetCollisionGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef6d48
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetCapsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetCapsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef6a98
};

// Class AtomRuntime.AtomRuntimeBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomRuntimeBlueprintLibrary : UBlueprintFunctionLibrary {

	struct FAtomColorInfo GetInfoForColorId(int32_t ColorId); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetInfoForColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbef8d90
	void GetCommonPartDescriptionFromType(enum class EAtomCommonPartType CommonPartType, struct FAtomCommonPartDescription& OutDescription); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartDescriptionFromType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbef7024
	enum class EAtomCommonPartCategory GetCommonPartCategoryFromType(enum class EAtomCommonPartType CommonPartType); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartCategoryFromType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xbef6f64
	void GetCommonPartAssetDescriptionFromStaticMesh(struct UStaticMesh* StaticMesh, struct FAtomCommonPartAssetDescription& OutDescription, enum class EGetCommonPartDescriptionResult& OutIsValid); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartAssetDescriptionFromStaticMesh // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbef6da8
	int32_t GetBitPackForColorId(int32_t AtomColorId); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbef69a0
	int32_t GetBitPackForColor(struct FColor& Color); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForColor // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xbef68cc
	struct TMap<int32_t, struct FAtomColorInfo> GetAllColorInfo(); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetAllColorInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbef65dc
};

// Class AtomRuntime.AtomRuntimeSettings
// Size: 0x60 (Inherited: 0x30)
struct UAtomRuntimeSettings : UDeveloperSettings {
	float PrimitiveGlobalScale; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TSoftObjectPtr<UDataTable> ColorDataTableOverride; // 0x38(0x20)
	bool bEnableWorldConnectivity; // 0x58(0x01)
	bool bCookContent; // 0x59(0x01)
	char pad_5A[0x6]; // 0x5a(0x06)

	struct UDataTable* GetColorDataTable(); // Function AtomRuntime.AtomRuntimeSettings.GetColorDataTable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef6d84
};

// Class AtomRuntime.WorldConnectivitySubsystem
// Size: 0x180 (Inherited: 0x30)
struct UWorldConnectivitySubsystem : UWorldSubsystem {
	char pad_30[0x150]; // 0x30(0x150)

	void UnregisterConnectivityActor(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.UnregisterConnectivityActor // (Final|Native|Public|BlueprintCallable) // @ game+0xbefb058
	bool TryConnectObjectAtLocation(struct FWorldConnectivityHandle ObjectToConnect, struct FTransform& DesiredObjectTransform, struct TArray<struct FWorldConnectivityHandle>& ConnectionCandidates, bool PerformConnection); // Function AtomRuntime.WorldConnectivitySubsystem.TryConnectObjectAtLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbefa784
	struct TArray<struct FConnectivityQueryResult> RunPlanarConnectivityQuery(struct AActor* AtomActorToPlace, struct AActor* AtomActorToConnect, struct FVector& QueryStartLocation, struct FVector& QueryEndLocation, enum class ECollisionChannel QueryCollisionChannel, int32_t QueryRadius, bool bSaveConnectionOnSuccess); // Function AtomRuntime.WorldConnectivitySubsystem.RunPlanarConnectivityQuery // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbefa150
	void RegisterModelActor(struct AActor* Actor, struct FSerializedConnectivityObjects& Connections); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterModelActor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xbefa020
	void RegisterCustomConnectivityActor(struct AActor* Actor, struct FSerializedConnectivityObjects& ConnectivityObject); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterCustomConnectivityActor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xbefa020
	bool RegisterConnectivityActor(struct AActor* Actor, struct UAtomModel* Model); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterConnectivityActor // (Final|Native|Public|BlueprintCallable) // @ game+0xbef9eb8
	bool RegisterAtomActor(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterAtomActor // (Final|Native|Public|BlueprintCallable) // @ game+0xbef9d94
	double PlanarGridStepSize(); // Function AtomRuntime.WorldConnectivitySubsystem.PlanarGridStepSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef9d74
	struct FTransform GetTransform(struct FWorldConnectivityHandle Handle); // Function AtomRuntime.WorldConnectivitySubsystem.GetTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef9b5c
	struct TArray<struct FPlanarFieldInfo> GetPlanarFields(struct FWorldConnectivityHandle Handle, enum class EConnectionFieldGender Type); // Function AtomRuntime.WorldConnectivitySubsystem.GetPlanarFields // (Final|Native|Public|BlueprintCallable) // @ game+0xbef92b8
	struct FVector GetPlanarFieldCenter(struct FPlanarFieldInfo& Field); // Function AtomRuntime.WorldConnectivitySubsystem.GetPlanarFieldCenter // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xbef91dc
	struct FVector GetOverlapPenetrationDepth(struct AStaticMeshActor* Actor1, struct AStaticMeshActor* Actor2, struct FVector Offset); // Function AtomRuntime.WorldConnectivitySubsystem.GetOverlapPenetrationDepth // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xbef8ec8
	struct TArray<struct FWorldConnectivityHandle> GetConnectivityHandles(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectivityHandles // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef759c
	struct FWorldConnectivityHandle GetConnectivityHandle(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectivityHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef7328
	struct TArray<struct FWorldConnectivityHandle> GetConnectedObjectsRecursively(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectedObjectsRecursively // (Final|Native|Public|BlueprintCallable) // @ game+0xbef7240
	struct TArray<struct FWorldConnectivityHandle> GetConnectedObjects(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectedObjects // (Final|Native|Public|BlueprintCallable) // @ game+0xbef7158
	struct FPlanarFieldInfo GetClosestFieldToPoint(struct FWorldConnectivityHandle Handle, struct FVector& WorldLocation, enum class EConnectionFieldGender Type, bool& bSuccess); // Function AtomRuntime.WorldConnectivitySubsystem.GetClosestFieldToPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xbef6ae4
	struct UAtomModelAssetUserData* GetAtomModelAssetUserData(struct UObject* Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetAtomModelAssetUserData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef6780
	struct UAtomModel* GetAtomModel(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.GetAtomModel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef6680
	struct AActor* GetActor(struct FWorldConnectivityHandle Handle); // Function AtomRuntime.WorldConnectivitySubsystem.GetActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbef650c
	void DisconnectObjects(struct FWorldConnectivityHandle ObjectA, struct FWorldConnectivityHandle ObjectB); // Function AtomRuntime.WorldConnectivitySubsystem.DisconnectObjects // (Final|Native|Public|BlueprintCallable) // @ game+0xbef627c
	void DisconnectAllObjectConnections(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.DisconnectAllObjectConnections // (Final|Native|Public|BlueprintCallable) // @ game+0xbef61bc
};

// Class AtomRuntime.WorldConnectivityBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UWorldConnectivityBlueprintLibrary : UBlueprintFunctionLibrary {

	bool IsValid(struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xb033cf4
	struct FTransform GetTransform(struct UObject* WorldContext, struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xbef99cc
	struct FVector GetFieldCenter(struct UObject* WorldContext, struct FPlanarFieldInfo& Field); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetFieldCenter // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xbef7950
	struct AActor* GetActor(struct UObject* WorldContext, struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xbef63d8
};

// Class AtomRuntime.AtomColorComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UAtomColorComponent : UActorComponent {
	struct UAtomColorLUTAtlas* ColorLUTAtlas; // 0xa0(0x08)
	struct UTexture2D* ColorLUTTexture; // 0xa8(0x08)

	int32_t GetColorLUTIndex(); // Function AtomRuntime.AtomColorComponent.GetColorLUTIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf255cc
};

// Class AtomRuntime.AtomISMPoolRenderer
// Size: 0x100 (Inherited: 0x28)
struct UAtomISMPoolRenderer : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct UGeometryCollectionISMPoolComponent* CachedISMPoolComponent; // 0x38(0x08)
	struct UGeometryCollectionISMPoolComponent* LocalISMPoolComponent; // 0x40(0x08)
	char pad_48[0xb8]; // 0x48(0xb8)
};

// Class AtomRuntime.AtomModel
// Size: 0x248 (Inherited: 0x28)
struct UAtomModel : UObject {
	struct FAtomModelAssetSettings Settings; // 0x28(0x28)
	struct TArray<struct FAtomModelPrimitive> Primitives; // 0x50(0x10)
	struct TArray<struct FAtomHingedElement> Elements; // 0x60(0x10)
	struct TArray<struct FAtomModelSelectionSet> SelectionSets; // 0x70(0x10)
	struct TArray<struct FAtomModelConfigurationGroup> Groups; // 0x80(0x10)
	struct TMap<enum class EAtomCommonPartType, struct TSoftObjectPtr<UStaticMesh>> CommonPartOverrides; // 0x90(0x50)
	char CommonPartOptimization; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
	struct FSerializedConnectivityObjects SerializedConnectivityObjects; // 0xe8(0x20)
	struct TMap<struct FString, struct TSoftObjectPtr<UTexture>> TextureNameToAsset; // 0x108(0x50)
	char pad_158[0x50]; // 0x158(0x50)
	struct FAtomSourceModel SourceModel; // 0x1a8(0xa0)

	struct UTexture* GetTextureForDecorationTextureName(struct FString TextureName); // Function AtomRuntime.AtomModel.GetTextureForDecorationTextureName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf26ba0
	void GetPrimitivesForChildArray(int32_t InChildIdx, struct TArray<struct FAtomModelPrimitiveInstance>& OutPrimitives); // Function AtomRuntime.AtomModel.GetPrimitivesForChildArray // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xbf262b0
	struct FAtomModelPartsCollection GetPartsCollection(); // Function AtomRuntime.AtomModel.GetPartsCollection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf2624c
	struct FString GetModelPath(); // Function AtomRuntime.AtomModel.GetModelPath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf260f0
	struct FString GetModelName(); // Function AtomRuntime.AtomModel.GetModelName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf260b0
	struct TArray<struct TSoftObjectPtr<UStaticMesh>> GetGeneratedMergedMeshes(); // Function AtomRuntime.AtomModel.GetGeneratedMergedMeshes // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf255f0
	struct FString GetChildIdentifier(int32_t InChildIdx); // Function AtomRuntime.AtomModel.GetChildIdentifier // (Final|Native|Public|BlueprintCallable) // @ game+0xbf24eb4
};

// Class AtomRuntime.AtomModelComponent
// Size: 0x2c0 (Inherited: 0x220)
struct UAtomModelComponent : USceneComponent {
	struct UAtomModel* AtomModel; // 0x220(0x08)
	enum class EAtomModelInstanceType InstanceType; // 0x228(0x01)
	char pad_229[0x7]; // 0x229(0x07)
	struct FString RenderStyle; // 0x230(0x10)
	struct FString FallbackRenderStyle; // 0x240(0x10)
	bool bUseRenderStyle; // 0x250(0x01)
	bool bUseFallbackRenderStyle; // 0x251(0x01)
	bool bUseCombinedMeshes; // 0x252(0x01)
	bool bUseColorPayload; // 0x253(0x01)
	bool bCreateRigidElements; // 0x254(0x01)
	bool bEnableConnectivity; // 0x255(0x01)
	bool bUseAtomDefaultMaterials; // 0x256(0x01)
	char pad_257[0x1]; // 0x257(0x01)
	struct FName SelectionSetFilter; // 0x258(0x04)
	char CommonPartOptimization; // 0x25c(0x01)
	char pad_25D[0x3]; // 0x25d(0x03)
	struct TArray<struct USceneComponent*> RigidElementComponents; // 0x260(0x10)
	struct TMap<struct FName, struct FModelPrimitiveEntry> ComponentToPrimitive; // 0x270(0x50)
};

// Class AtomRuntime.AtomPrimitiveComponent
// Size: 0x600 (Inherited: 0x5d0)
struct UAtomPrimitiveComponent : UStaticMeshComponent {
	struct UAtomPrimitive* AtomPrimitive; // 0x5d0(0x08)
	struct FString RenderStyle; // 0x5d8(0x10)
	struct FString FallbackRenderStyle; // 0x5e8(0x10)
	bool bUseCombinedMeshes; // 0x5f8(0x01)
	bool bUseRenderStyle; // 0x5f9(0x01)
	bool bUseFallbackRenderStyle; // 0x5fa(0x01)
	char pad_5FB[0x5]; // 0x5fb(0x05)
};

// Class AtomRuntime.AtomModelProcessor
// Size: 0x58 (Inherited: 0x28)
struct UAtomModelProcessor : UObject {
	bool bEnableRebuildProgress; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float DialogDelay; // 0x2c(0x04)
	int32_t NumProgressSteps; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FString ProgressMessage; // 0x38(0x10)
	char pad_48[0x10]; // 0x48(0x10)

	struct FAtomProcessorResult OnProcessPrimitive(struct UAtomModel* DummyModel, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct FAtomOnProcessPrimitiveSettings& Settings); // Function AtomRuntime.AtomModelProcessor.OnProcessPrimitive // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	struct FAtomProcessorResult OnProcessModel(struct UAtomModel* Model, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct TArray<struct TSoftObjectPtr<UObject>>& ExistingObjects); // Function AtomRuntime.AtomModelProcessor.OnProcessModel // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	struct FString OnGetTargetAssetPath(struct UAtomModel* Model, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection); // Function AtomRuntime.AtomModelProcessor.OnGetTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	struct FString OnGetProcessPrimitiveTargetAssetPath(struct UAtomModel* Model, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct FAtomOnProcessPrimitiveSettings& Settings); // Function AtomRuntime.AtomModelProcessor.OnGetProcessPrimitiveTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	struct FString OnGetProcessModelTargetAssetPath(struct UAtomModel* Model, struct FAtomModelPartsCollection& AtomModelPartsCollection); // Function AtomRuntime.AtomModelProcessor.OnGetProcessModelTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void IncrementProgress(int32_t NumSteps, struct FString Message); // Function AtomRuntime.AtomModelProcessor.IncrementProgress // (Final|Native|Public|BlueprintCallable) // @ game+0xbf272e0
};

// Class AtomRuntime.AtomProcessorBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomProcessorBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetModelProcessor(struct FAtomModelProcessorInstance& ProcessorInstance, struct UAtomModelProcessor* ModelProcessor, bool bUseCustomSettings); // Function AtomRuntime.AtomProcessorBlueprintLibrary.SetModelProcessor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbf28354
	bool IsValid(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbf27ae4
	struct UObject* GetProcessorClass(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.GetProcessorClass // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbf26a08
	struct UAtomModelProcessor* GetModelProcessor(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.GetModelProcessor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbf26154
	struct FAtomProcessorResult AppendAtomProcessorResult(struct FAtomProcessorResult& Result, struct FAtomProcessorResult& ResultToAppend); // Function AtomRuntime.AtomProcessorBlueprintLibrary.AppendAtomProcessorResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xbf24c28
};

// Class AtomRuntime.AtomPrimitive
// Size: 0x200 (Inherited: 0x28)
struct UAtomPrimitive : UObject {
	int32_t PartId; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FString PartRevision; // 0x30(0x10)
	struct FName DesignName; // 0x40(0x04)
	bool bIsFlex; // 0x44(0x01)
	bool bIsVariant; // 0x45(0x01)
	char pad_46[0x2]; // 0x46(0x02)
	struct TArray<struct FString> DecorationSurfaceNames; // 0x48(0x10)
	int32_t NumberOfColorSurfaces; // 0x58(0x04)
	enum class EAtomPlatform AtomPlatform; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	int32_t AtomMainGroupId; // 0x60(0x04)
	int32_t AtomSubMainGroupId; // 0x64(0x04)
	struct TMap<enum class EAtomCommonPartType, struct FAtomPrimitiveCommonPart> PrimitiveCommonParts; // 0x68(0x50)
	struct TMap<struct FName, struct FAtomPrimitiveCommonPart> CommonParts; // 0xb8(0x50)
	bool bOverrideConnectionFields; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
	struct FBoxSphereBounds Bounds; // 0x110(0x38)
	struct FBoxSphereBounds UnscaledBounds; // 0x148(0x38)
	struct TArray<struct UAtomPrimitiveGeometryContainer*> GeometryContainers; // 0x180(0x10)
	struct TArray<struct FAtomPrimitiveDetailTextureData> DetailTextures; // 0x190(0x10)
	struct FConnectionFieldContainer ConnectionFields; // 0x1a0(0x30)
	struct FConnectionFieldContainer ConnectionFieldsOverride; // 0x1d0(0x30)

	struct UTexture* LoadDetailTextureForExportStyle(struct FString ExportStyle, enum class EAtomPrimitiveDetailTextureType TextureType); // Function AtomRuntime.AtomPrimitive.LoadDetailTextureForExportStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf27bb0
	bool IsFlexElement(); // Function AtomRuntime.AtomPrimitive.IsFlexElement // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf27ad0
	struct FName GetSubMainGroupName(int32_t SubMainGroupId); // Function AtomRuntime.AtomPrimitive.GetSubMainGroupName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbf26adc
	struct FName GetMainGroupName(int32_t MainGroupId); // Function AtomRuntime.AtomPrimitive.GetMainGroupName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xbf25fec
	struct UAtomPrimitiveGeometryContainer* GetGeometryContainerForExportStyle(struct FString ExportStyleName, struct FString FallbackExportStyleName, int32_t LODIndex); // Function AtomRuntime.AtomPrimitive.GetGeometryContainerForExportStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf257bc
	struct UAtomPrimitiveGeometryContainer* GetGeometryContainerForBestExportStyle(struct TArray<struct FString>& GeometryStylePriorityList, int32_t LODIndex); // Function AtomRuntime.AtomPrimitive.GetGeometryContainerForBestExportStyle // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf2567c
	struct FBoxSphereBounds GetBounds(float Scale); // Function AtomRuntime.AtomPrimitive.GetBounds // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xbf24dc0
};

