// Class AudioExtensions.AudioPropertiesBindings
// Size: 0x78 (Inherited: 0x28)
struct UAudioPropertiesBindings : UObject {
	struct TMap<struct FName, struct FName> ObjectPropertyToSheetPropertyMap; // 0x28(0x50)
};

// Class AudioExtensions.AudioPropertiesSheetAssetBase
// Size: 0x28 (Inherited: 0x28)
struct UAudioPropertiesSheetAssetBase : UObject {
};

// Class AudioExtensions.SpatializationPluginSourceSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct USpatializationPluginSourceSettingsBase : UObject {
};

// Class AudioExtensions.SourceDataOverridePluginSourceSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct USourceDataOverridePluginSourceSettingsBase : UObject {
};

// Class AudioExtensions.OcclusionPluginSourceSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct UOcclusionPluginSourceSettingsBase : UObject {
};

// Class AudioExtensions.ReverbPluginSourceSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct UReverbPluginSourceSettingsBase : UObject {
};

// Class AudioExtensions.AudioPropertySheetBaseAsset
// Size: 0x28 (Inherited: 0x28)
struct UAudioPropertySheetBaseAsset : UObject {
};

// Class AudioExtensions.AudioParameterControllerInterface
// Size: 0x28 (Inherited: 0x28)
struct UAudioParameterControllerInterface : UInterface {

	void SetTriggerParameter(struct FName InName); // Function AudioExtensions.AudioParameterControllerInterface.SetTriggerParameter // (Native|Public|BlueprintCallable) // @ game+0x1fbacfc
	void SetStringParameter(struct FName InName, struct FString InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetStringParameter // (Native|Public|BlueprintCallable) // @ game+0x602ae38
	void SetStringArrayParameter(struct FName InName, struct TArray<struct FString>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetStringArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x602ad10
	void SetParameters_Blueprint(struct TArray<struct FAudioParameter>& InParameters); // Function AudioExtensions.AudioParameterControllerInterface.SetParameters_Blueprint // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3629728
	void SetObjectParameter(struct FName InName, struct UObject* InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetObjectParameter // (Native|Public|BlueprintCallable) // @ game+0x339aa80
	void SetObjectArrayParameter(struct FName InName, struct TArray<struct UObject*>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetObjectArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x602abe0
	void SetIntParameter(struct FName InName, int32_t inInt); // Function AudioExtensions.AudioParameterControllerInterface.SetIntParameter // (Native|Public|BlueprintCallable) // @ game+0x602aaa0
	void SetIntArrayParameter(struct FName InName, struct TArray<int32_t>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetIntArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x602a970
	void SetFloatParameter(struct FName InName, float InFloat); // Function AudioExtensions.AudioParameterControllerInterface.SetFloatParameter // (Native|Public|BlueprintCallable) // @ game+0x325c6f0
	void SetFloatArrayParameter(struct FName InName, struct TArray<float>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetFloatArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x602a7f0
	void SetBoolParameter(struct FName InName, bool InBool); // Function AudioExtensions.AudioParameterControllerInterface.SetBoolParameter // (Native|Public|BlueprintCallable) // @ game+0x3113fc0
	void SetBoolArrayParameter(struct FName InName, struct TArray<bool>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetBoolArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x602a6c0
	void ResetParameters(); // Function AudioExtensions.AudioParameterControllerInterface.ResetParameters // (Native|Public|BlueprintCallable) // @ game+0x2f3f074
};

// Class AudioExtensions.AudioEndpointSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct UAudioEndpointSettingsBase : UObject {
};

// Class AudioExtensions.DummyEndpointSettings
// Size: 0x28 (Inherited: 0x28)
struct UDummyEndpointSettings : UAudioEndpointSettingsBase {
};

// Class AudioExtensions.SoundModulatorBase
// Size: 0x30 (Inherited: 0x28)
struct USoundModulatorBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class AudioExtensions.SoundfieldEndpointSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct USoundfieldEndpointSettingsBase : UObject {
};

// Class AudioExtensions.SoundfieldEncodingSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct USoundfieldEncodingSettingsBase : UObject {
};

// Class AudioExtensions.SoundfieldEffectSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct USoundfieldEffectSettingsBase : UObject {
};

// Class AudioExtensions.SoundfieldEffectBase
// Size: 0x30 (Inherited: 0x28)
struct USoundfieldEffectBase : UObject {
	struct USoundfieldEffectSettingsBase* Settings; // 0x28(0x08)
};

// Class AudioExtensions.WaveformTransformationBase
// Size: 0x28 (Inherited: 0x28)
struct UWaveformTransformationBase : UObject {
};

// Class AudioExtensions.WaveformTransformationChain
// Size: 0x38 (Inherited: 0x28)
struct UWaveformTransformationChain : UObject {
	struct TArray<struct UWaveformTransformationBase*> Transformations; // 0x28(0x10)
};

