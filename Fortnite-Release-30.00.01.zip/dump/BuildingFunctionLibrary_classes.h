// BlueprintGeneratedClass BuildingFunctionLibrary.BuildingFunctionLibrary_C
// Size: 0x28 (Inherited: 0x28)
struct UBuildingFunctionLibrary_C : UBlueprintFunctionLibrary {

	void RequestComponentResource(struct UCreativeIslandResourceManagerComponent* ResourceManager, struct FName ResourceTag, struct UActorComponent* Component, struct FVector WorldLocation, struct UObject* __WorldContext); // Function BuildingFunctionLibrary.BuildingFunctionLibrary_C.RequestComponentResource // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SweepAgainstActorTypes(struct AActor* TestActor, struct FVector StartLocation, struct FVector EndLocation, double SweepRadius, struct TArray<enum class EObjectTypeQuery>& SweepObjectTypes, struct TArray<struct AActor*>& ActorClassFilters, struct UObject* __WorldContext, bool& Overlapped); // Function BuildingFunctionLibrary.BuildingFunctionLibrary_C.SweepAgainstActorTypes // (Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
	void ShouldLogForInstigator(enum class BlueprintLogLevel Instance Log Level, struct UObject* Instigator, struct UObject* __WorldContext, bool& Should Log?); // Function BuildingFunctionLibrary.BuildingFunctionLibrary_C.ShouldLogForInstigator // (Static|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void LogString(enum class BlueprintLogLevel Instance Log Level, struct FString LogString, bool PrintToScreen, struct UObject* Instigator, struct UObject* __WorldContext); // Function BuildingFunctionLibrary.BuildingFunctionLibrary_C.LogString // (Static|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
};

