// WidgetBlueprintGeneratedClass CorrectiveActionFlow.CorrectiveActionFlow_C
// Size: 0x460 (Inherited: 0x448)
struct UCorrectiveActionFlow_C : UFortCorrectiveActionFlow {
	struct UImage* FortniteLogo; // 0x448(0x08)
	struct USafeZone* SafeZone; // 0x450(0x08)
	struct UWBP_CaptureForPostBufferUpdate_C* WBP_CaptureForPostBufferUpdate; // 0x458(0x08)
};

