// BlueprintGeneratedClass BBE_RiderExit.BBE_RiderExit_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_RiderExit_C : UFortMobileActionButtonBehaviorExtension {
};

