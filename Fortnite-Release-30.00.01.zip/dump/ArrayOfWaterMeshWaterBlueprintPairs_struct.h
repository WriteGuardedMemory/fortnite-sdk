// UserDefinedStruct ArrayOfWaterMeshWaterBlueprintPairs.ArrayOfWaterMeshWaterBlueprintPairs
// Size: 0x10 (Inherited: 0x00)
struct FArrayOfWaterMeshWaterBlueprintPairs {
	struct TArray<struct FWaterMeshAssetsToReplace> ArrayOfPairedMeshesandBlueprints_3_66DC153A4804C5BFDF6D5187A0EEF992; // 0x00(0x10)
};

