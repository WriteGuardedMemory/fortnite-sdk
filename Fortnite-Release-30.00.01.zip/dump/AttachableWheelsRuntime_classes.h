// Class AttachableWheelsRuntime.AttachableWheel
// Size: 0x330 (Inherited: 0x290)
struct AAttachableWheel : AActor {
	struct UStaticMeshComponent* WheelMeshComponent; // 0x290(0x08)
	struct FRotator WheelOrientation; // 0x298(0x18)
	float WheelDistance; // 0x2b0(0x04)
	char pad_2B4[0x4]; // 0x2b4(0x04)
	struct UPhysicsConstraintComponent* AxleConstraint; // 0x2b8(0x08)
	struct FAttachableWheelAttachData AttachData; // 0x2c0(0x58)
	bool bAutoCreateAttachableWheelsComponent; // 0x318(0x01)
	bool bEnableWheelWheelCollision; // 0x319(0x01)
	bool bReplicateRuntimeData; // 0x31a(0x01)
	char pad_31B[0x1]; // 0x31b(0x01)
	struct FAttachableWheelRuntimeData RuntimeData; // 0x31c(0x0c)
	char pad_328[0x8]; // 0x328(0x08)

	void SetRuntimeData_Velocity(float Velocity); // Function AttachableWheelsRuntime.AttachableWheel.SetRuntimeData_Velocity // (Final|Native|Public|BlueprintCallable) // @ game+0xcb20584
	void SetRuntimeData_Torque(float Torque); // Function AttachableWheelsRuntime.AttachableWheel.SetRuntimeData_Torque // (Final|Native|Public|BlueprintCallable) // @ game+0xcb204c0
	void SetRuntimeData_SteerAngle(float SteerAngle); // Function AttachableWheelsRuntime.AttachableWheel.SetRuntimeData_SteerAngle // (Final|Native|Public|BlueprintCallable) // @ game+0xcb203fc
	void SetRuntimeData(float Torque, float Velocity, float SteerAngle); // Function AttachableWheelsRuntime.AttachableWheel.SetRuntimeData // (Final|Native|Public|BlueprintCallable) // @ game+0xcb20240
	void OnRep_RuntimeData(struct FAttachableWheelRuntimeData& RuntimeDataPrev); // Function AttachableWheelsRuntime.AttachableWheel.OnRep_RuntimeData // (Final|Native|Protected|HasOutParms) // @ game+0xcb200f8
	void OnRep_AttachData(struct FAttachableWheelAttachData& AttachDataPrev); // Function AttachableWheelsRuntime.AttachableWheel.OnRep_AttachData // (Final|Native|Protected|HasOutParms) // @ game+0xcb20038
	void OnPhysicsStateChanged(struct UPrimitiveComponent* PrimitiveComponent, enum class EComponentPhysicsStateChange StateChange); // Function AttachableWheelsRuntime.AttachableWheel.OnPhysicsStateChanged // (Native|Protected) // @ game+0xcb1fef4
	void OnDetached(struct UPrimitiveComponent* DetachedComponent); // Function AttachableWheelsRuntime.AttachableWheel.OnDetached // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnAttached(struct UPrimitiveComponent* AttachedComponent); // Function AttachableWheelsRuntime.AttachableWheel.OnAttached // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	bool GetWorldSpaceAttachData(struct FAttachableWheelAttachData& OutAttachData, struct UPrimitiveComponent* PrimitiveComponent, struct FName BodyName); // Function AttachableWheelsRuntime.AttachableWheel.GetWorldSpaceAttachData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xcb1fb80
	struct UPrimitiveComponent* GetAttachedComponent(); // Function AttachableWheelsRuntime.AttachableWheel.GetAttachedComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xcb1f8bc
	struct FAttachableWheelAttachData GetAttachData(); // Function AttachableWheelsRuntime.AttachableWheel.GetAttachData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xcb1f864
	void DrawDebug(); // Function AttachableWheelsRuntime.AttachableWheel.DrawDebug // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x3600a3c
	bool DetachFrom(struct UPrimitiveComponent* InComponent); // Function AttachableWheelsRuntime.AttachableWheel.DetachFrom // (Final|Native|Public|BlueprintCallable) // @ game+0xcb1f77c
	void Detach(); // Function AttachableWheelsRuntime.AttachableWheel.Detach // (Final|Native|Public|BlueprintCallable) // @ game+0xcb1f6d4
	bool AttachTo(struct UPrimitiveComponent* InComponent, struct FVector& WorldLocation, struct FVector& AxleDirection, struct FVector SteerAxis); // Function AttachableWheelsRuntime.AttachableWheel.AttachTo // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xcb1f458
	bool AttachInPlace(struct UPrimitiveComponent* InComponent); // Function AttachableWheelsRuntime.AttachableWheel.AttachInPlace // (Final|Native|Public|BlueprintCallable) // @ game+0xcb1f388
};

// Class AttachableWheelsRuntime.AttachableWheelsComponent
// Size: 0x108 (Inherited: 0xa0)
struct UAttachableWheelsComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	struct TSet<struct AAttachableWheel*> AttachedWheels; // 0xa8(0x50)
	float MaxChassisMassFraction; // 0xf8(0x04)
	char pad_FC[0xc]; // 0xfc(0x0c)

	void SetMaxChassisMassFraction(float InMaxChassisMassFraction); // Function AttachableWheelsRuntime.AttachableWheelsComponent.SetMaxChassisMassFraction // (Final|Native|Public|BlueprintCallable) // @ game+0xcb2017c
	void OnWheelDetached(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelDetached // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnWheelAttached(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelAttached // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	bool HandleWheelDetached_Internal(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelDetached_Internal // (Final|Native|Protected) // @ game+0xcb1fe24
	bool HandleWheelAttached_Internal(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelAttached_Internal // (Final|Native|Protected) // @ game+0xcb1fd54
	struct TArray<struct AAttachableWheel*> GetAttachedWheels(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheels // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xcb1fb14
	struct AAttachableWheel* GetAttachedWheelClosestOnAxis(struct FVector& Point, float& OutClosetDistanceToAxis, struct FVector& OutClosestPointOnAxis, struct FVector& OutClosestAxis); // Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheelClosestOnAxis // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xcb1f8e0
	void DrawDebug(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.DrawDebug // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x3600a3c
	int32_t DetachAllWheels(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.DetachAllWheels // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xcb1f6e8
};

