// Enum BattlePassS30UI.EBattlePassStatusBarTypeS30
enum class EBattlePassStatusBarTypeS30 : uint8 {
	Hidden = 0,
	Prerequisite = 1,
	Delayed = 2,
	Unclaimable = 3,
	Claimable = 4,
	Special = 5,
	Owned = 6,
	EBattlePassStatusBarTypeS30_MAX = 7
};

// Enum BattlePassS30UI.ERewardWarningTooltipType30
enum class ERewardWarningTooltipType30 : uint8 {
	None = 0,
	Custom = 1,
	AgeGating = 2,
	Sparks = 3,
	DelMar = 4,
	Juno = 5,
	Max = 6
};

