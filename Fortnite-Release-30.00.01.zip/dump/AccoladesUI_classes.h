// Class AccoladesUI.AthenaAccoladeWrapper
// Size: 0x38 (Inherited: 0x28)
struct UAthenaAccoladeWrapper : UObject {
	struct FName AccoladeRowName; // 0x28(0x04)
	struct FFortAccoladeSessionData AccoladeData; // 0x2c(0x0c)
};

// Class AccoladesUI.AthenaAccoladeListEntryWidget
// Size: 0x2e8 (Inherited: 0x2e0)
struct UAthenaAccoladeListEntryWidget : UCommonUserWidget {
	char pad_2E0[0x8]; // 0x2e0(0x08)

	void SetTitle(struct FText& TitleText); // Function AccoladesUI.AthenaAccoladeListEntryWidget.SetTitle // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetSource(struct FText& SourceText); // Function AccoladesUI.AthenaAccoladeListEntryWidget.SetSource // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetJustCompleted(bool bJustCompleted); // Function AccoladesUI.AthenaAccoladeListEntryWidget.SetJustCompleted // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetIconImage(struct TSoftObjectPtr<UTexture2D>& IconImage, enum class EFortAccoladeType AccoladeType, enum class EFortAccoladeTierType AccoladeTier); // Function AccoladesUI.AthenaAccoladeListEntryWidget.SetIconImage // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetIcon(struct UFortAccoladeItemDefinition* ItemDef); // Function AccoladesUI.AthenaAccoladeListEntryWidget.SetIcon // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetCount(int32_t Count); // Function AccoladesUI.AthenaAccoladeListEntryWidget.SetCount // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
};

// Class AccoladesUI.AthenaAccoladeListWidget
// Size: 0xbc0 (Inherited: 0xbc0)
struct UAthenaAccoladeListWidget : UCommonListView {

	void PopulateWidget(); // Function AccoladesUI.AthenaAccoladeListWidget.PopulateWidget // (Final|Native|Public|BlueprintCallable) // @ game+0xb67004c
};

