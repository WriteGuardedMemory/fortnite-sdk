// Enum Constraints.EHandleEvent
enum class EHandleEvent : uint8 {
	LocalTransformUpdated = 0,
	GlobalTransformUpdated = 1,
	ComponentUpdated = 2,
	UpperDependencyUpdated = 3,
	Max = 4
};

// ScriptStruct Constraints.ConstraintsInWorld
// Size: 0x28 (Inherited: 0x00)
struct FConstraintsInWorld {
	struct TWeakObjectPtr<struct UWorld> World; // 0x00(0x08)
	struct TArray<struct TWeakObjectPtr<struct UTickableConstraint>> Constraints; // 0x08(0x10)
	char pad_18[0x10]; // 0x18(0x10)
};

// ScriptStruct Constraints.MovieSceneConstraintChannel
// Size: 0x108 (Inherited: 0x108)
struct FMovieSceneConstraintChannel : FMovieSceneBoolChannel {
};

// ScriptStruct Constraints.ConstraintAndActiveChannel
// Size: 0x110 (Inherited: 0x00)
struct FConstraintAndActiveChannel {
	struct FMovieSceneConstraintChannel ActiveChannel; // 0x00(0x108)
	struct UTickableConstraint* ConstraintCopyToSpawn; // 0x108(0x08)
};

// ScriptStruct Constraints.ConstraintTickFunction
// Size: 0x40 (Inherited: 0x28)
struct FConstraintTickFunction : FTickFunction {
	char pad_28[0x18]; // 0x28(0x18)
};

