// Class ChallengeQuestsUI.AthenaInventoryGroupChallengeQuests
// Size: 0x360 (Inherited: 0x350)
struct UAthenaInventoryGroupChallengeQuests : UAthenaInventoryGroupBase {
	struct FGameplayTag ChallengeQuestsGameplayTag; // 0x350(0x04)
	char pad_354[0xc]; // 0x354(0x0c)
};

