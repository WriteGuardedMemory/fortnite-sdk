// BlueprintGeneratedClass Athena_PlayerCameraModeSkydiveGlide.Athena_PlayerCameraModeSkydiveGlide_C
// Size: 0x1cd0 (Inherited: 0x1cd0)
struct UAthena_PlayerCameraModeSkydiveGlide_C : UAthena_PlayerCameraModeBase_C {
};

