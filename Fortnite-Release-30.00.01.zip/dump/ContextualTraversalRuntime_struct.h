// ScriptStruct ContextualTraversalRuntime.FortMovementMode_TraversalBaseCreationData
// Size: 0x130 (Inherited: 0x08)
struct FFortMovementMode_TraversalBaseCreationData : FFortMovementMode_BaseExtCreationData {
	struct FSynchedActionInfo SynchedActionInfo; // 0x08(0x30)
	char pad_38[0x8]; // 0x38(0x08)
	struct FSynchedActionWarpPointInfo_Replicated SynchedActionWarpPointInfo; // 0x40(0xa0)
	struct FVector TargetLocation; // 0xe0(0x18)
	struct FRotator TargetRotation; // 0xf8(0x18)
	struct TWeakObjectPtr<struct AActor> RefActor; // 0x110(0x08)
	struct TWeakObjectPtr<struct UPrimitiveComponent> RefActorComponent; // 0x118(0x08)
	struct FName RefActorBoneName; // 0x120(0x04)
	enum class EFortSynchedActionEndMovementMode EndMovementMode; // 0x124(0x01)
	bool bIsWindow; // 0x125(0x01)
	char pad_126[0xa]; // 0x126(0x0a)
};

