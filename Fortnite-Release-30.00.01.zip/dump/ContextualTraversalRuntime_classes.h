// Class ContextualTraversalRuntime.FortMovementMode_TraversalBaseRuntimeData
// Size: 0x100 (Inherited: 0x38)
struct UFortMovementMode_TraversalBaseRuntimeData : UFortMovementMode_BaseExtRuntimeData {
	struct UAnimMontage* AnimMontage; // 0x38(0x08)
	struct FName MontageStartSectionName; // 0x40(0x04)
	struct FName MontageMiddleSectionName; // 0x44(0x04)
	char pad_48[0x8]; // 0x48(0x08)
	struct FSynchedActionWarpPointInfo_Replicated SynchedActionWarpPointInfo; // 0x50(0xa0)
	char pad_F0[0x10]; // 0xf0(0x10)
};

// Class ContextualTraversalRuntime.FortMovementMode_ExtLogicTraversalBase
// Size: 0x168 (Inherited: 0x110)
struct UFortMovementMode_ExtLogicTraversalBase : UFortMovementMode_BaseExtLogic {
	char pad_110[0x30]; // 0x110(0x30)
	struct FGameplayTag SynchedActionTag; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)
	struct UFortCameraMode* CameraMode; // 0x148(0x08)
	struct FGameplayTag CameraModeTag; // 0x150(0x04)
	struct FName MontageStartSectionName; // 0x154(0x04)
	bool bUseNextSectionAnimName; // 0x158(0x01)
	char pad_159[0x3]; // 0x159(0x03)
	float OverrideServerAllowablePositionError; // 0x15c(0x04)
	float OverrideAnimBlendOutTimeWhenLanding; // 0x160(0x04)
	char pad_164[0x4]; // 0x164(0x04)
};

