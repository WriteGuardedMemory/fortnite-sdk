// Enum ContextualActionCodeRuntime.EHijackingStatus
enum class EHijackingStatus : uint8 {
	WaitingForTarget = 0,
	AttachedToVehicle = 1,
	EHijackingStatus_MAX = 2
};

// Enum ContextualActionCodeRuntime.ERappellingState
enum class ERappellingState : uint8 {
	Targeting = 0,
	ConnectedAndWaiting = 1,
	Rappelling = 2,
	RappellingSwing = 3,
	ERappellingState_MAX = 4
};

// Enum ContextualActionCodeRuntime.ESwingingState
enum class ESwingingState : uint8 {
	Unattached = 0,
	Attached = 1,
	ESwingingState_MAX = 2
};

// ScriptStruct ContextualActionCodeRuntime.FortMovementMode_SwingingObjectCreationData
// Size: 0x28 (Inherited: 0x08)
struct FFortMovementMode_SwingingObjectCreationData : FFortMovementMode_BaseExtCreationData {
	struct FVector AttachLocation; // 0x08(0x18)
	struct TWeakObjectPtr<struct AFortSwingingObject> TargetSwingingObject; // 0x20(0x08)
};

// ScriptStruct ContextualActionCodeRuntime.FortMovementMode_SwingingRopeCreationData
// Size: 0x28 (Inherited: 0x08)
struct FFortMovementMode_SwingingRopeCreationData : FFortMovementMode_BaseExtCreationData {
	struct FVector AttachLocation; // 0x08(0x18)
	struct TWeakObjectPtr<struct AFortSwingingObject> TargetSwingingRope; // 0x20(0x08)
};

// ScriptStruct ContextualActionCodeRuntime.FortSwingingObjectClassData
// Size: 0x118 (Inherited: 0x118)
struct FFortSwingingObjectClassData : FBuildingGameplayActorClassData {
};

