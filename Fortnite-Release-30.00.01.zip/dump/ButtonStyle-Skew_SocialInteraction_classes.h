// BlueprintGeneratedClass ButtonStyle-Skew_SocialInteraction.ButtonStyle-Skew_SocialInteraction_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Skew_SocialInteraction_C : UCommonButtonStyle {
};

