// BlueprintGeneratedClass Border-SolidBG-DkBlue.Border-SolidBG-DkBlue_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-SolidBG-DkBlue_C : UCommonBorderStyle {
};

