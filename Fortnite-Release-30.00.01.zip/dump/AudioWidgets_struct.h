// Enum AudioWidgets.EAudioPanelLayoutType
enum class EAudioPanelLayoutType : uint8 {
	Basic = 0,
	Advanced = 1,
	EAudioPanelLayoutType_MAX = 2
};

// Enum AudioWidgets.EAudioOscilloscopeTriggerMode
enum class EAudioOscilloscopeTriggerMode : uint8 {
	None = 0,
	Rising = 1,
	Falling = 2,
	EAudioOscilloscopeTriggerMode_MAX = 3
};

// Enum AudioWidgets.EYAxisLabelsUnit
enum class EYAxisLabelsUnit : uint8 {
	Linear = 0,
	Db = 1,
	EYAxisLabelsUnit_MAX = 2
};

// Enum AudioWidgets.EXAxisLabelsUnit
enum class EXAxisLabelsUnit : uint8 {
	Samples = 0,
	Seconds = 1,
	EXAxisLabelsUnit_MAX = 2
};

// Enum AudioWidgets.EAudioColorGradient
enum class EAudioColorGradient : uint8 {
	BlackToWhite = 0,
	WhiteToBlack = 1,
	EAudioColorGradient_MAX = 2
};

// Enum AudioWidgets.EAudioMaterialEnvelopeType
enum class EAudioMaterialEnvelopeType : uint8 {
	AD = 0,
	ADSR = 1,
	EAudioMaterialEnvelopeType_MAX = 2
};

// Enum AudioWidgets.EAudioSpectrogramFrequencyAxisScale
enum class EAudioSpectrogramFrequencyAxisScale : uint8 {
	Linear = 0,
	Logarithmic = 1,
	EAudioSpectrogramFrequencyAxisScale_MAX = 2
};

// Enum AudioWidgets.EAudioSpectrogramFrequencyAxisPixelBucketMode
enum class EAudioSpectrogramFrequencyAxisPixelBucketMode : uint8 {
	Sample = 0,
	Peak = 1,
	Average = 2,
	EAudioSpectrogramFrequencyAxisPixelBucketMode_MAX = 3
};

// Enum AudioWidgets.EAudioSpectrumAnalyzerType
enum class EAudioSpectrumAnalyzerType : uint8 {
	FFT = 0,
	CQT = 1,
	EAudioSpectrumAnalyzerType_MAX = 2
};

// Enum AudioWidgets.EAudioUnitsValueType
enum class EAudioUnitsValueType : uint8 {
	Linear = 0,
	Frequency = 1,
	Volume = 2,
	EAudioUnitsValueType_MAX = 3
};

// Enum AudioWidgets.EAudioRadialSliderLayout
enum class EAudioRadialSliderLayout : uint8 {
	Layout_LabelTop = 0,
	Layout_LabelCenter = 1,
	Layout_LabelBottom = 2,
	Layout_MAX = 3
};

// Enum AudioWidgets.EAudioSpectrumPlotFrequencyAxisScale
enum class EAudioSpectrumPlotFrequencyAxisScale : uint8 {
	Linear = 0,
	Logarithmic = 1,
	EAudioSpectrumPlotFrequencyAxisScale_MAX = 2
};

// Enum AudioWidgets.EAudioSpectrumPlotFrequencyAxisPixelBucketMode
enum class EAudioSpectrumPlotFrequencyAxisPixelBucketMode : uint8 {
	Sample = 0,
	Peak = 1,
	Average = 2,
	EAudioSpectrumPlotFrequencyAxisPixelBucketMode_MAX = 3
};

// ScriptStruct AudioWidgets.MeterChannelInfo
// Size: 0x0c (Inherited: 0x00)
struct FMeterChannelInfo {
	float MeterValue; // 0x00(0x04)
	float PeakValue; // 0x04(0x04)
	float ClippingValue; // 0x08(0x04)
};

// ScriptStruct AudioWidgets.AudioMaterialWidgetStyle
// Size: 0x20 (Inherited: 0x08)
struct FAudioMaterialWidgetStyle : FSlateWidgetStyle {
	struct UMaterialInterface* Material; // 0x08(0x08)
	struct FVector2f DesiredSize; // 0x10(0x08)
	struct UMaterialInstanceDynamic* DynamicMaterial; // 0x18(0x08)
};

// ScriptStruct AudioWidgets.AudioMaterialMeterStyle
// Size: 0xf0 (Inherited: 0x20)
struct FAudioMaterialMeterStyle : FAudioMaterialWidgetStyle {
	struct FLinearColor MeterFillMinColor; // 0x20(0x10)
	struct FLinearColor MeterFillMidColor; // 0x30(0x10)
	struct FLinearColor MeterFillMaxColor; // 0x40(0x10)
	struct FLinearColor MeterOffFillColor; // 0x50(0x10)
	struct FVector2D MeterPadding; // 0x60(0x10)
	struct FVector2D ValueRangeDb; // 0x70(0x10)
	bool bShowScale; // 0x80(0x01)
	bool bScaleSide; // 0x81(0x01)
	char pad_82[0x2]; // 0x82(0x02)
	float ScaleHashOffset; // 0x84(0x04)
	float ScaleHashWidth; // 0x88(0x04)
	float ScaleHashHeight; // 0x8c(0x04)
	int32_t DecibelsPerHash; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FSlateFontInfo Font; // 0x98(0x58)
};

// ScriptStruct AudioWidgets.AudioMeterStyle
// Size: 0x480 (Inherited: 0x08)
struct FAudioMeterStyle : FSlateWidgetStyle {
	char pad_8[0x8]; // 0x08(0x08)
	struct FSlateBrush MeterValueImage; // 0x10(0xc0)
	struct FSlateBrush BackgroundImage; // 0xd0(0xc0)
	struct FSlateBrush MeterBackgroundImage; // 0x190(0xc0)
	struct FSlateBrush MeterValueBackgroundImage; // 0x250(0xc0)
	struct FSlateBrush MeterPeakImage; // 0x310(0xc0)
	struct FVector2D MeterSize; // 0x3d0(0x10)
	struct FVector2D MeterPadding; // 0x3e0(0x10)
	float MeterValuePadding; // 0x3f0(0x04)
	float PeakValueWidth; // 0x3f4(0x04)
	struct FVector2D ValueRangeDb; // 0x3f8(0x10)
	bool bShowScale; // 0x408(0x01)
	bool bScaleSide; // 0x409(0x01)
	char pad_40A[0x2]; // 0x40a(0x02)
	float ScaleHashOffset; // 0x40c(0x04)
	float ScaleHashWidth; // 0x410(0x04)
	float ScaleHashHeight; // 0x414(0x04)
	int32_t DecibelsPerHash; // 0x418(0x04)
	char pad_41C[0x4]; // 0x41c(0x04)
	struct FSlateFontInfo Font; // 0x420(0x58)
	char pad_478[0x8]; // 0x478(0x08)
};

// ScriptStruct AudioWidgets.AudioOscilloscopePanelStyle
// Size: 0x470 (Inherited: 0x08)
struct FAudioOscilloscopePanelStyle : FSlateWidgetStyle {
	char pad_8[0x8]; // 0x08(0x08)
	struct FFixedSampleSequenceRulerStyle TimeRulerStyle; // 0x10(0x250)
	struct FSampledSequenceValueGridOverlayStyle ValueGridStyle; // 0x260(0x98)
	char pad_2F8[0x8]; // 0x2f8(0x08)
	struct FSampledSequenceViewerStyle WaveViewerStyle; // 0x300(0x150)
	struct FTriggerThresholdLineStyle TriggerThresholdLineStyle; // 0x450(0x18)
	char pad_468[0x8]; // 0x468(0x08)
};

// ScriptStruct AudioWidgets.TriggerThresholdLineStyle
// Size: 0x18 (Inherited: 0x08)
struct FTriggerThresholdLineStyle : FSlateWidgetStyle {
	struct FLinearColor LineColor; // 0x08(0x10)
};

// ScriptStruct AudioWidgets.SampledSequenceViewerStyle
// Size: 0x150 (Inherited: 0x08)
struct FSampledSequenceViewerStyle : FSlateWidgetStyle {
	struct FSlateColor SequenceColor; // 0x08(0x14)
	float SequenceLineThickness; // 0x1c(0x04)
	struct FSlateColor MajorGridLineColor; // 0x20(0x14)
	struct FSlateColor MinorGridLineColor; // 0x34(0x14)
	struct FSlateColor ZeroCrossingLineColor; // 0x48(0x14)
	float ZeroCrossingLineThickness; // 0x5c(0x04)
	float SampleMarkersSize; // 0x60(0x04)
	struct FSlateColor SequenceBackgroundColor; // 0x64(0x14)
	char pad_78[0x8]; // 0x78(0x08)
	struct FSlateBrush BackgroundBrush; // 0x80(0xc0)
	float DesiredWidth; // 0x140(0x04)
	float DesiredHeight; // 0x144(0x04)
	char pad_148[0x8]; // 0x148(0x08)
};

// ScriptStruct AudioWidgets.SampledSequenceValueGridOverlayStyle
// Size: 0x98 (Inherited: 0x08)
struct FSampledSequenceValueGridOverlayStyle : FSlateWidgetStyle {
	struct FSlateColor GridColor; // 0x08(0x14)
	float GridThickness; // 0x1c(0x04)
	struct FSlateColor LabelTextColor; // 0x20(0x14)
	char pad_34[0x4]; // 0x34(0x04)
	struct FSlateFontInfo LabelTextFont; // 0x38(0x58)
	float DesiredWidth; // 0x90(0x04)
	float DesiredHeight; // 0x94(0x04)
};

// ScriptStruct AudioWidgets.FixedSampleSequenceRulerStyle
// Size: 0x250 (Inherited: 0x08)
struct FFixedSampleSequenceRulerStyle : FSlateWidgetStyle {
	float HandleWidth; // 0x08(0x04)
	struct FSlateColor HandleColor; // 0x0c(0x14)
	struct FSlateBrush HandleBrush; // 0x20(0xc0)
	struct FSlateColor TicksColor; // 0xe0(0x14)
	struct FSlateColor TicksTextColor; // 0xf4(0x14)
	struct FSlateFontInfo TicksTextFont; // 0x108(0x58)
	float TicksTextOffset; // 0x160(0x04)
	struct FSlateColor BackgroundColor; // 0x164(0x14)
	char pad_178[0x8]; // 0x178(0x08)
	struct FSlateBrush BackgroundBrush; // 0x180(0xc0)
	float DesiredWidth; // 0x240(0x04)
	float DesiredHeight; // 0x244(0x04)
	char pad_248[0x8]; // 0x248(0x08)
};

// ScriptStruct AudioWidgets.AudioVectorscopePanelStyle
// Size: 0x1a0 (Inherited: 0x08)
struct FAudioVectorscopePanelStyle : FSlateWidgetStyle {
	struct FSampledSequenceValueGridOverlayStyle ValueGridStyle; // 0x08(0x98)
	struct FSampledSequenceVectorViewerStyle VectorViewerStyle; // 0xa0(0x100)
};

// ScriptStruct AudioWidgets.SampledSequenceVectorViewerStyle
// Size: 0x100 (Inherited: 0x08)
struct FSampledSequenceVectorViewerStyle : FSlateWidgetStyle {
	struct FSlateColor BackgroundColor; // 0x08(0x14)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FSlateBrush BackgroundBrush; // 0x20(0xc0)
	struct FLinearColor LineColor; // 0xe0(0x10)
	float LineThickness; // 0xf0(0x04)
	char pad_F4[0xc]; // 0xf4(0x0c)
};

// ScriptStruct AudioWidgets.AudioMaterialEnvelopeSettings
// Size: 0x24 (Inherited: 0x00)
struct FAudioMaterialEnvelopeSettings {
	enum class EAudioMaterialEnvelopeType EnvelopeType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float AttackCurve; // 0x04(0x04)
	float AttackValue; // 0x08(0x04)
	float AttackTime; // 0x0c(0x04)
	float DecayCurve; // 0x10(0x04)
	float DecayTime; // 0x14(0x04)
	float SustainValue; // 0x18(0x04)
	float ReleaseCurve; // 0x1c(0x04)
	float ReleaseTime; // 0x20(0x04)
};

// ScriptStruct AudioWidgets.AudioMaterialButtonStyle
// Size: 0x80 (Inherited: 0x20)
struct FAudioMaterialButtonStyle : FAudioMaterialWidgetStyle {
	struct FLinearColor ButtonMainColor; // 0x20(0x10)
	struct FLinearColor ButtonShadowColor; // 0x30(0x10)
	struct FLinearColor ButtonAccentColor; // 0x40(0x10)
	struct FLinearColor ButtonPressedMainColor; // 0x50(0x10)
	struct FLinearColor ButtonPressedShadowColor; // 0x60(0x10)
	struct FLinearColor ButtonPressedOutlineColor; // 0x70(0x10)
};

// ScriptStruct AudioWidgets.AudioMaterialSliderStyle
// Size: 0x160 (Inherited: 0x20)
struct FAudioMaterialSliderStyle : FAudioMaterialWidgetStyle {
	struct FLinearColor BarMainColor; // 0x20(0x10)
	struct FLinearColor BarShadowColor; // 0x30(0x10)
	struct FLinearColor BarAccentColor; // 0x40(0x10)
	struct FLinearColor HandleMainColor; // 0x50(0x10)
	struct FLinearColor HandleOutlineColor; // 0x60(0x10)
	struct FAudioTextBoxStyle TextBoxStyle; // 0x70(0xf0)
};

// ScriptStruct AudioWidgets.AudioTextBoxStyle
// Size: 0xf0 (Inherited: 0x08)
struct FAudioTextBoxStyle : FSlateWidgetStyle {
	char pad_8[0x8]; // 0x08(0x08)
	struct FSlateBrush BackgroundImage; // 0x10(0xc0)
	struct FSlateColor BackgroundColor; // 0xd0(0x14)
	char pad_E4[0xc]; // 0xe4(0x0c)
};

// ScriptStruct AudioWidgets.AudioMaterialKnobStyle
// Size: 0x1a0 (Inherited: 0x20)
struct FAudioMaterialKnobStyle : FAudioMaterialWidgetStyle {
	struct FLinearColor KnobMainColor; // 0x20(0x10)
	struct FLinearColor KnobAccentColor; // 0x30(0x10)
	struct FLinearColor KnobIndicatorColor; // 0x40(0x10)
	struct FLinearColor KnobBarColor; // 0x50(0x10)
	struct FLinearColor KnobBarShadowColor; // 0x60(0x10)
	struct FLinearColor KnobBarFillMinColor; // 0x70(0x10)
	struct FLinearColor KnobBarFillMidColor; // 0x80(0x10)
	struct FLinearColor KnobBarFillMaxColor; // 0x90(0x10)
	struct FLinearColor KnobBarFillTintColor; // 0xa0(0x10)
	struct FAudioTextBoxStyle TextBoxStyle; // 0xb0(0xf0)
};

// ScriptStruct AudioWidgets.AudioMaterialEnvelopeStyle
// Size: 0x50 (Inherited: 0x20)
struct FAudioMaterialEnvelopeStyle : FAudioMaterialWidgetStyle {
	struct FLinearColor CurveColor; // 0x20(0x10)
	struct FLinearColor BackgroundColor; // 0x30(0x10)
	struct FLinearColor OutlineColor; // 0x40(0x10)
};

// ScriptStruct AudioWidgets.AudioSpectrumPlotStyle
// Size: 0xb8 (Inherited: 0x08)
struct FAudioSpectrumPlotStyle : FSlateWidgetStyle {
	struct FSlateColor BackgroundColor; // 0x08(0x14)
	struct FSlateColor GridColor; // 0x1c(0x14)
	struct FSlateColor AxisLabelColor; // 0x30(0x14)
	char pad_44[0x4]; // 0x44(0x04)
	struct FSlateFontInfo AxisLabelFont; // 0x48(0x58)
	struct FSlateColor SpectrumColor; // 0xa0(0x14)
	char pad_B4[0x4]; // 0xb4(0x04)
};

// ScriptStruct AudioWidgets.AudioSliderStyle
// Size: 0x6d0 (Inherited: 0x08)
struct FAudioSliderStyle : FSlateWidgetStyle {
	char pad_8[0x8]; // 0x08(0x08)
	struct FSliderStyle SliderStyle; // 0x10(0x4a0)
	struct FAudioTextBoxStyle TextBoxStyle; // 0x4b0(0xf0)
	struct FSlateBrush WidgetBackgroundImage; // 0x5a0(0xc0)
	struct FSlateColor SliderBackgroundColor; // 0x660(0x14)
	char pad_674[0x4]; // 0x674(0x04)
	struct FVector2D SliderBackgroundSize; // 0x678(0x10)
	float LabelPadding; // 0x688(0x04)
	struct FSlateColor SliderBarColor; // 0x68c(0x14)
	struct FSlateColor SliderThumbColor; // 0x6a0(0x14)
	struct FSlateColor WidgetBackgroundColor; // 0x6b4(0x14)
	char pad_6C8[0x8]; // 0x6c8(0x08)
};

// ScriptStruct AudioWidgets.AudioRadialSliderStyle
// Size: 0x150 (Inherited: 0x08)
struct FAudioRadialSliderStyle : FSlateWidgetStyle {
	char pad_8[0x8]; // 0x08(0x08)
	struct FAudioTextBoxStyle TextBoxStyle; // 0x10(0xf0)
	struct FSlateColor CenterBackgroundColor; // 0x100(0x14)
	struct FSlateColor SliderBarColor; // 0x114(0x14)
	struct FSlateColor SliderProgressColor; // 0x128(0x14)
	float LabelPadding; // 0x13c(0x04)
	float DefaultSliderRadius; // 0x140(0x04)
	char pad_144[0xc]; // 0x144(0x0c)
};

// ScriptStruct AudioWidgets.PlayheadOverlayStyle
// Size: 0x28 (Inherited: 0x08)
struct FPlayheadOverlayStyle : FSlateWidgetStyle {
	struct FSlateColor PlayheadColor; // 0x08(0x14)
	float PlayheadWidth; // 0x1c(0x04)
	float DesiredWidth; // 0x20(0x04)
	float DesiredHeight; // 0x24(0x04)
};

