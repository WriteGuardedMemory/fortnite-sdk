// VerseEnum CompanionAI.CompanionAI_PingCommand_command_type
enum class CompanionAI_PingCommand_command_type : uint8 {
	go_to = 0,
	back_to_me = 1,
	back_to_default = 2,
	hold_position = 3,
	revive = 4,
	invalid = 5,
	CompanionAI_PingCommand_command_MAX = 6
};

// VerseEnum CompanionAI.CompanionAI_PingCommand_entity_type
enum class CompanionAI_PingCommand_entity_type : uint8 {
	pawn = 0,
	pickup = 1,
	weapon = 2,
	container = 3,
	player_built_actor = 4,
	building_actor = 5,
	undefined = 6,
	CompanionAI_PingCommand_entity_MAX = 7
};

// VerseStruct CompanionAI.CompanionAI_ping_info
// Size: 0x38 (Inherited: 0x00)
struct FCompanionAI_ping_info {
	enum class CompanionAI_PingCommand_command_type __verse_0x72E298E9_Type; // 0x00(0x01)
	enum class CompanionAI_PingCommand_entity_type __verse_0x6CF7C7E8_EntityType; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FSpatialMath_vector3 __verse_0xB0C27E0A_Location; // 0x08(0x18)
	char __verse_0x0FA78E7E_LocationOnHorizontalSurface : 1; // 0x20(0x01)
	char pad_20_1 : 7; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	OptionalProperty __verse_0x459049A1_Target; // 0x28(0x08)
	OptionalProperty __verse_0xFD64D7AA_Emitter; // 0x30(0x08)
};

// VerseStruct CompanionAI.tuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R
// Size: 0x40 (Inherited: 0x00)
struct Ftuple_L_Kchar_M_Kchar_M_Kchar_M_Kchar_R {
	VerseStringProperty __verse_0x18E3F084_Elem0; // 0x00(0x10)
	VerseStringProperty __verse_0x7D844C3C_Elem1; // 0x10(0x10)
	VerseStringProperty __verse_0x932BF92E_Elem2; // 0x20(0x10)
	VerseStringProperty __verse_0xF64C4596_Elem3; // 0x30(0x10)
};

// VerseStruct CompanionAI.tuple_L_Kchar_M_Kchar_R
// Size: 0x20 (Inherited: 0x00)
struct Ftuple_L_Kchar_M_Kchar_R {
	VerseStringProperty __verse_0x18E3F084_Elem0; // 0x00(0x10)
	VerseStringProperty __verse_0x7D844C3C_Elem1; // 0x10(0x10)
};

// VerseStruct CompanionAI.tuple_L_Kchar_M_QColor_Ncolor_M_QDuration_Nfloat_R
// Size: 0x40 (Inherited: 0x00)
struct Ftuple_L_Kchar_M_QColor_Ncolor_M_QDuration_Nfloat_R {
	VerseStringProperty __verse_0x18E3F084_Elem0; // 0x00(0x10)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x10(0x20)
	OptionalProperty __verse_0x932BF92E_Elem2; // 0x30(0x10)
};

// VerseStruct CompanionAI.tuple_L_Kchar_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R
// Size: 0x40 (Inherited: 0x00)
struct Ftuple_L_Kchar_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_R {
	VerseStringProperty __verse_0x18E3F084_Elem0; // 0x00(0x10)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x10(0x10)
	OptionalProperty __verse_0x932BF92E_Elem2; // 0x20(0x20)
};

// VerseStruct CompanionAI.tuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_R
// Size: 0x12 (Inherited: 0x00)
struct Ftuple_L_Kchar_M_QLevel_Nlog__level_20_3d_20_2e_2e_2e_R {
	VerseStringProperty __verse_0x18E3F084_Elem0; // 0x00(0x10)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x10(0x02)
};

// VerseStruct CompanionAI.tuple_L_R
// Size: 0x01 (Inherited: 0x00)
struct Ftuple_L_R {
	char $StructPaddingDummy; // 0x00(0x01)
};

// VerseStruct CompanionAI.tuple_Lagent_Mfloat_Mfloat_R
// Size: 0x18 (Inherited: 0x00)
struct Ftuple_Lagent_Mfloat_Mfloat_R {
	struct USimulation_agent* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	double __verse_0x7D844C3C_Elem1; // 0x08(0x08)
	double __verse_0x932BF92E_Elem2; // 0x10(0x08)
};

// VerseStruct CompanionAI.tuple_Lagent_Mtuple_L_R_Mtuple_L_R_R
// Size: 0x0a (Inherited: 0x00)
struct Ftuple_Lagent_Mtuple_L_R_Mtuple_L_R_R {
	struct USimulation_agent* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x08(0x01)
	struct Ftuple_L_R __verse_0x932BF92E_Elem2; // 0x09(0x01)
};

// VerseStruct CompanionAI.tuple_Lentity_Mtuple_L_R_Mtuple_L_R_R
// Size: 0x0a (Inherited: 0x00)
struct Ftuple_Lentity_Mtuple_L_R_Mtuple_L_R_R {
	struct UEntity* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x08(0x01)
	struct Ftuple_L_R __verse_0x932BF92E_Elem2; // 0x09(0x01)
};

// VerseStruct CompanionAI.tuple_Lfloat_Mfloat_R
// Size: 0x10 (Inherited: 0x00)
struct Ftuple_Lfloat_Mfloat_R {
	double __verse_0x18E3F084_Elem0; // 0x00(0x08)
	double __verse_0x7D844C3C_Elem1; // 0x08(0x08)
};

// VerseStruct CompanionAI.tuple_Lfort__character_Mfloat_R
// Size: 0x10 (Inherited: 0x00)
struct Ftuple_Lfort__character_Mfloat_R {
	struct UObject* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	double __verse_0x7D844C3C_Elem1; // 0x08(0x08)
};

// VerseStruct CompanionAI.tuple_Lfort__character_Mtuple_L_R_Mtuple_L_R_R
// Size: 0x0a (Inherited: 0x00)
struct Ftuple_Lfort__character_Mtuple_L_R_Mtuple_L_R_R {
	struct UObject* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x08(0x01)
	struct Ftuple_L_R __verse_0x932BF92E_Elem2; // 0x09(0x01)
};

// VerseStruct CompanionAI.tuple_Lnavigation__target_M_QMovementType_Nmovement__type_20_3d_20_2e_2e_2e_M_QReachRadius_Nfloat_20_3d_20_2e_2e_2e_M_QAllowPartialPath_Nlogic_20_3d_20_2e_2e_2e_R
// Size: 0x22 (Inherited: 0x00)
struct Ftuple_Lnavigation__target_M_QMovementType_Nmovement__type_20_3d_20_2e_2e_2e_M_QReachRadius_Nfloat_20_3d_20_2e_2e_2e_M_QAllowPartialPath_Nlogic_20_3d_20_2e_2e_2e_R {
	struct UAI_navigation_target* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x08(0x08)
	OptionalProperty __verse_0x932BF92E_Elem2; // 0x10(0x10)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x20(0x02)
};

// VerseStruct CompanionAI.tuple_Lnavigation__target_M_QReachRadius_Nfloat_M_QAllowPartialPath_Nlogic_R
// Size: 0x1a (Inherited: 0x00)
struct Ftuple_Lnavigation__target_M_QReachRadius_Nfloat_M_QAllowPartialPath_Nlogic_R {
	struct UAI_navigation_target* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x08(0x10)
	OptionalProperty __verse_0x932BF92E_Elem2; // 0x18(0x02)
};

// VerseStruct CompanionAI.tuple_Ltarget__info_Mtuple_L_R_Mtuple_L_R_R
// Size: 0x32 (Inherited: 0x00)
struct Ftuple_Ltarget__info_Mtuple_L_R_Mtuple_L_R_R {
	struct FAI_target_info __verse_0x18E3F084_Elem0; // 0x00(0x30)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x30(0x01)
	struct Ftuple_L_R __verse_0x932BF92E_Elem2; // 0x31(0x01)
};

// VerseStruct CompanionAI.tuple_Ltype_7b5_2e000000e_2b01_7d_Mtype_7b2_2e000000e_2b02_7d_R
// Size: 0x10 (Inherited: 0x00)
struct Ftuple_Ltype_7b5_2e000000e_2b01_7d_Mtype_7b2_2e000000e_2b02_7d_R {
	double __verse_0x18E3F084_Elem0; // 0x00(0x08)
	double __verse_0x7D844C3C_Elem1; // 0x08(0x08)
};

// VerseStruct CompanionAI.tuple_Ltype_7b_2d1_2e000000e_2b03_7d_Mtype_7b1_2e000000e_2b03_7d_R
// Size: 0x10 (Inherited: 0x00)
struct Ftuple_Ltype_7b_2d1_2e000000e_2b03_7d_Mtype_7b1_2e000000e_2b03_7d_R {
	double __verse_0x18E3F084_Elem0; // 0x00(0x08)
	double __verse_0x7D844C3C_Elem1; // 0x08(0x08)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Nfloat_20_3d_20_2e_2e_2e_M_QAllowPartialPath_Nlogic_20_3d_20_2e_2e_2e_R
// Size: 0x3a (Inherited: 0x00)
struct Ftuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Nfloat_20_3d_20_2e_2e_2e_M_QAllowPartialPath_Nlogic_20_3d_20_2e_2e_2e_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	char __verse_0x932BF92E_Elem2 : 1; // 0x20(0x01)
	char pad_20_1 : 7; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x28(0x10)
	OptionalProperty __verse_0x4F74920B_Elem4; // 0x38(0x02)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b10_2e000000_7d_R
// Size: 0x38 (Inherited: 0x00)
struct Ftuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b10_2e000000_7d_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	char __verse_0x932BF92E_Elem2 : 1; // 0x20(0x01)
	char pad_20_1 : 7; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x28(0x10)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b1_2e000000e_2b02_7d_R
// Size: 0x38 (Inherited: 0x00)
struct Ftuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b1_2e000000e_2b02_7d_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	char __verse_0x932BF92E_Elem2 : 1; // 0x20(0x01)
	char pad_20_1 : 7; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x28(0x10)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b2_2e000000e_2b02_7d_M_QAllowPartialPath_Nlogic_R
// Size: 0x3a (Inherited: 0x00)
struct Ftuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b2_2e000000e_2b02_7d_M_QAllowPartialPath_Nlogic_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	char __verse_0x932BF92E_Elem2 : 1; // 0x20(0x01)
	char pad_20_1 : 7; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x28(0x10)
	OptionalProperty __verse_0x4F74920B_Elem4; // 0x38(0x02)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b4_2e000000e_2b02_7d_R
// Size: 0x38 (Inherited: 0x00)
struct Ftuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b4_2e000000e_2b02_7d_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	char __verse_0x932BF92E_Elem2 : 1; // 0x20(0x01)
	char pad_20_1 : 7; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x28(0x10)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b5_2e000000e_2b01_7d_M_QAllowPartialPath_Nlogic_R
// Size: 0x3a (Inherited: 0x00)
struct Ftuple_Lvector3_M_Qagent_Mlogic_M_QReachRadius_Ntype_7b5_2e000000e_2b01_7d_M_QAllowPartialPath_Nlogic_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	char __verse_0x932BF92E_Elem2 : 1; // 0x20(0x01)
	char pad_20_1 : 7; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x28(0x10)
	OptionalProperty __verse_0x4F74920B_Elem4; // 0x38(0x02)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_QColor_Ncolor_M_QRadius_Nfloat_M_QThickness_Ntype_7b3_2e000000_7d_M_QDrawDurationPolicy_Ndebug__draw__duration__policy_M_QNumSegments_Ntype_7b32_7d_R
// Size: 0x70 (Inherited: 0x00)
struct Ftuple_Lvector3_M_QColor_Ncolor_M_QRadius_Nfloat_M_QThickness_Ntype_7b3_2e000000_7d_M_QDrawDurationPolicy_Ndebug__draw__duration__policy_M_QNumSegments_Ntype_7b32_7d_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x18(0x20)
	OptionalProperty __verse_0x932BF92E_Elem2; // 0x38(0x10)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x48(0x10)
	OptionalProperty __verse_0x4F74920B_Elem4; // 0x58(0x02)
	char pad_5A[0x6]; // 0x5a(0x06)
	OptionalProperty __verse_0x2A132EB3_Elem5; // 0x60(0x10)
};

// VerseStruct CompanionAI.tuple_Lvector3_M_QRadius_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_M_QNumSegments_Nint_20_3d_20_2e_2e_2e_M_QThickness_Nfloat_20_3d_20_2e_2e_2e_M_QDrawDurationPolicy_Ndebug__draw__duration__policy_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_R
// Size: 0x80 (Inherited: 0x00)
struct Ftuple_Lvector3_M_QRadius_Nfloat_20_3d_20_2e_2e_2e_M_QColor_Ncolor_20_3d_20_2e_2e_2e_M_QNumSegments_Nint_20_3d_20_2e_2e_2e_M_QThickness_Nfloat_20_3d_20_2e_2e_2e_M_QDrawDurationPolicy_Ndebug__draw__duration__policy_20_3d_20_2e_2e_2e_M_QDuration_Nfloat_20_3d_20_2e_2e_2e_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	OptionalProperty __verse_0x7D844C3C_Elem1; // 0x18(0x10)
	OptionalProperty __verse_0x932BF92E_Elem2; // 0x28(0x20)
	OptionalProperty __verse_0xF64C4596_Elem3; // 0x48(0x10)
	OptionalProperty __verse_0x4F74920B_Elem4; // 0x58(0x10)
	OptionalProperty __verse_0x2A132EB3_Elem5; // 0x68(0x02)
	char pad_6A[0x6]; // 0x6a(0x06)
	OptionalProperty __verse_0xC4BC9BA1_Elem6; // 0x70(0x10)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mfloat_Magent_R
// Size: 0x28 (Inherited: 0x00)
struct Ftuple_Lvector3_Mfloat_Magent_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	double __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	struct USimulation_agent* __verse_0x932BF92E_Elem2; // 0x20(0x08)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mfloat_Mcolor_R
// Size: 0x38 (Inherited: 0x00)
struct Ftuple_Lvector3_Mfloat_Mcolor_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	double __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	struct FColors_color __verse_0x932BF92E_Elem2; // 0x20(0x18)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mfloat_Mfloat_R
// Size: 0x28 (Inherited: 0x00)
struct Ftuple_Lvector3_Mfloat_Mfloat_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	double __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	double __verse_0x932BF92E_Elem2; // 0x20(0x08)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mtype_7b0_2e500000_7d_Mtype_7b1_2e500000_7d_R
// Size: 0x28 (Inherited: 0x00)
struct Ftuple_Lvector3_Mtype_7b0_2e500000_7d_Mtype_7b1_2e500000_7d_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	double __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	double __verse_0x932BF92E_Elem2; // 0x20(0x08)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mtype_7b1_2e000000e_2b02_7d_Mfloat_R
// Size: 0x28 (Inherited: 0x00)
struct Ftuple_Lvector3_Mtype_7b1_2e000000e_2b02_7d_Mfloat_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	double __verse_0x7D844C3C_Elem1; // 0x18(0x08)
	double __verse_0x932BF92E_Elem2; // 0x20(0x08)
};

// VerseStruct CompanionAI.tuple_Lvector3_Mvector3_R
// Size: 0x30 (Inherited: 0x00)
struct Ftuple_Lvector3_Mvector3_R {
	struct FSpatialMath_vector3 __verse_0x18E3F084_Elem0; // 0x00(0x18)
	struct FSpatialMath_vector3 __verse_0x7D844C3C_Elem1; // 0x18(0x18)
};

