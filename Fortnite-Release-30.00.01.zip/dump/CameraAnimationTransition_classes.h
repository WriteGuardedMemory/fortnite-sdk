// BlueprintGeneratedClass CameraAnimationTransition.CameraAnimationTransition_C
// Size: 0x2b1 (Inherited: 0x290)
struct ACameraAnimationTransition_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)
	struct AFortnitePartyBackdrop_Camera_C* CameraBR; // 0x2a0(0x08)
	struct AFortnitePartyBackdrop_Camera_C* CameraBR16Player; // 0x2a8(0x08)
	enum class EFrontEndCamera CameraState; // 0x2b0(0x01)

	void CanChangeCamera(enum class EFrontEndCamera FromCamera, enum class EFrontEndCamera ToCamera, bool& CanChangeCamera); // Function CameraAnimationTransition.CameraAnimationTransition_C.CanChangeCamera // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void MoveCameraUp(); // Function CameraAnimationTransition.CameraAnimationTransition_C.MoveCameraUp // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void MoveCameraDown(); // Function CameraAnimationTransition.CameraAnimationTransition_C.MoveCameraDown // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_CameraAnimationTransition(int32_t EntryPoint); // Function CameraAnimationTransition.CameraAnimationTransition_C.ExecuteUbergraph_CameraAnimationTransition // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

