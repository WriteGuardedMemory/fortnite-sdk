// BlueprintGeneratedClass AnimNotify_FootStep_Left.AnimNotify_FootStep_Left_C
// Size: 0x80 (Inherited: 0x80)
struct UAnimNotify_FootStep_Left_C : UAnimNotify_FootStep_C {
};

