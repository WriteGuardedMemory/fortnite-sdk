// BlueprintGeneratedClass B_Ground_CameraShake_Heavy.B_Ground_CameraShake_Heavy_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UB_Ground_CameraShake_Heavy_C : ULegacyCameraShake {
};

