// WidgetBlueprintGeneratedClass ArrowCursorWidget.ArrowCursorWidget_C
// Size: 0x2b8 (Inherited: 0x2b8)
struct UArrowCursorWidget_C : UUserWidget {

	struct FSlateBrush (); // Function ArrowCursorWidget.ArrowCursorWidget_C. // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
};

