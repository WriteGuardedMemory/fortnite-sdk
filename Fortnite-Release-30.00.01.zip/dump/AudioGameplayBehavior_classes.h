// Class AudioGameplayBehavior.AudioGameplayBehavior
// Size: 0xf8 (Inherited: 0xa0)
struct UAudioGameplayBehavior : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	bool bKillOnSoundsFinished; // 0xa8(0x01)
	bool bTickWhileStopped; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
	struct FMulticastInlineDelegate OnAllSoundsFinished; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnSoundFinished; // 0xc0(0x10)
	struct TArray<struct FActiveVoice> PlayingSounds; // 0xd0(0x10)
	struct UAudioComponentGroup* ComponentGroupOwner; // 0xe0(0x08)
	char pad_E8[0x10]; // 0xe8(0x10)

	void SubscribeToStringParam(struct FName ParamName, struct FDelegate Delegate); // Function AudioGameplayBehavior.AudioGameplayBehavior.SubscribeToStringParam // (Final|Native|Public|BlueprintCallable) // @ game+0xcd0109c
	void SubscribeToEvent(struct FName EventName, struct FDelegate Delegate); // Function AudioGameplayBehavior.AudioGameplayBehavior.SubscribeToEvent // (Final|Native|Public|BlueprintCallable) // @ game+0xcd00f48
	void SubscribeToBoolParam(struct FName ParamName, struct FDelegate Delegate); // Function AudioGameplayBehavior.AudioGameplayBehavior.SubscribeToBoolParam // (Final|Native|Public|BlueprintCallable) // @ game+0xcd00df4
	void StopSound(struct USoundBase* Sound, float InFadeOutTime, enum class EAudioFaderCurve InFadeCurve); // Function AudioGameplayBehavior.AudioGameplayBehavior.StopSound // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0xcd00c38
	void StopComponent(struct UAudioComponent* Comp, float InFadeOutTime, enum class EAudioFaderCurve InFadeCurve); // Function AudioGameplayBehavior.AudioGameplayBehavior.StopComponent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x350d910
	void StopById(struct FPlayingId ID, float InFadeOutTime, enum class EAudioFaderCurve InFadeCurve); // Function AudioGameplayBehavior.AudioGameplayBehavior.StopById // (Final|Native|Public|BlueprintCallable) // @ game+0xcd00a54
	void StopAllPlayingVoices(float InFadeOutTime); // Function AudioGameplayBehavior.AudioGameplayBehavior.StopAllPlayingVoices // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0xcd00990
	void Stop(); // Function AudioGameplayBehavior.AudioGameplayBehavior.Stop // (BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x284f49c
	void Start(); // Function AudioGameplayBehavior.AudioGameplayBehavior.Start // (BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x18e3774
	void SetPlayState(enum class EAudioGameplayBehaviorPlayState NewState); // Function AudioGameplayBehavior.AudioGameplayBehavior.SetPlayState // (Native|Public|BlueprintCallable) // @ game+0xcd008cc
	struct FActiveVoice PlaySound(struct USoundBase* Sound, float InFadeInTime, float InTargetVolume, float InStartTime, bool bDisableAttenuation, enum class EAudioFaderCurve InFadeCurve, struct FVector InRelativeLocation, struct FRotator InRelativeRotation); // Function AudioGameplayBehavior.AudioGameplayBehavior.PlaySound // (Final|BlueprintCosmetic|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x26e3bb4
	void PlayFrom(struct UAudioComponentGroup* SoundGroup); // Function AudioGameplayBehavior.AudioGameplayBehavior.PlayFrom // (BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x93f9908
	void Kill(); // Function AudioGameplayBehavior.AudioGameplayBehavior.Kill // (BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x9d32140
	bool IsVirtualized(); // Function AudioGameplayBehavior.AudioGameplayBehavior.IsVirtualized // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1f4a4e0
	bool IsPlayingAny(); // Function AudioGameplayBehavior.AudioGameplayBehavior.IsPlayingAny // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x262c93c
	struct FString GetStringParamValue(struct FName ParamName); // Function AudioGameplayBehavior.AudioGameplayBehavior.GetStringParamValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xcd0018c
	enum class EAudioGameplayBehaviorPlayState GetStopState(); // Function AudioGameplayBehavior.AudioGameplayBehavior.GetStopState // (Native|Public|BlueprintCallable) // @ game+0x7586948
	struct UAudioComponentGroup* GetSoundGroup(); // Function AudioGameplayBehavior.AudioGameplayBehavior.GetSoundGroup // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8c1d394
	enum class EAudioGameplayBehaviorPlayState GetPlayState(); // Function AudioGameplayBehavior.AudioGameplayBehavior.GetPlayState // (Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x8aac904
	float GetFloatParamValue(struct FName ParamName); // Function AudioGameplayBehavior.AudioGameplayBehavior.GetFloatParamValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xcd000b4
	bool GetBoolParamValue(struct FName ParamName); // Function AudioGameplayBehavior.AudioGameplayBehavior.GetBoolParamValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x355e5dc
	void EnableVirtualization(); // Function AudioGameplayBehavior.AudioGameplayBehavior.EnableVirtualization // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0xcd000a0
	void DisableVirtualization(); // Function AudioGameplayBehavior.AudioGameplayBehavior.DisableVirtualization // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0xcd0008c
	void BP_OnVirtualized(); // Function AudioGameplayBehavior.AudioGameplayBehavior.BP_OnVirtualized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnUnvirtualized(); // Function AudioGameplayBehavior.AudioGameplayBehavior.BP_OnUnvirtualized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnStop(); // Function AudioGameplayBehavior.AudioGameplayBehavior.BP_OnStop // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnStart(); // Function AudioGameplayBehavior.AudioGameplayBehavior.BP_OnStart // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnGroupSet(struct UAudioComponentGroup* SoundGroup); // Function AudioGameplayBehavior.AudioGameplayBehavior.BP_OnGroupSet // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnFinished(); // Function AudioGameplayBehavior.AudioGameplayBehavior.BP_OnFinished // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
};

