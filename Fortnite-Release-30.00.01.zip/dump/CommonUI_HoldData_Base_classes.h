// BlueprintGeneratedClass CommonUI_HoldData_Base.CommonUI_HoldData_Base_C
// Size: 0x40 (Inherited: 0x40)
struct UCommonUI_HoldData_Base_C : UCommonUIHoldData {
};

