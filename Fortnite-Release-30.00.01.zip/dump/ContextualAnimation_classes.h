// Class ContextualAnimation.AnimNotifyState_EarlyOutContextualAnimWindow
// Size: 0x30 (Inherited: 0x30)
struct UAnimNotifyState_EarlyOutContextualAnimWindow : UAnimNotifyState {
};

// Class ContextualAnimation.AnimNotifyState_IKWindow
// Size: 0xa0 (Inherited: 0x30)
struct UAnimNotifyState_IKWindow : UAnimNotifyState {
	struct FName GoalName; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FAlphaBlend BlendIn; // 0x38(0x30)
	struct FAlphaBlend BlendOut; // 0x68(0x30)
	bool bEnable; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class ContextualAnimation.ContextualAnimActorInterface
// Size: 0x28 (Inherited: 0x28)
struct UContextualAnimActorInterface : UInterface {

	struct USkeletalMeshComponent* GetMesh(); // Function ContextualAnimation.ContextualAnimActorInterface.GetMesh // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x88698bc
};

// Class ContextualAnimation.ContextualAnimSceneActorComponent
// Size: 0x6b0 (Inherited: 0x510)
struct UContextualAnimSceneActorComponent : UPrimitiveComponent {
	struct FMulticastInlineDelegate OnJoinedSceneDelegate; // 0x510(0x10)
	struct FMulticastInlineDelegate OnLeftSceneDelegate; // 0x520(0x10)
	struct FMulticastInlineDelegate OnPlayMontageNotifyBeginDelegate; // 0x530(0x10)
	struct UContextualAnimSceneAsset* SceneAsset; // 0x540(0x08)
	bool bEnableDebug; // 0x548(0x01)
	char pad_549[0x7]; // 0x549(0x07)
	struct FContextualAnimRepBindingsData RepBindings; // 0x550(0x50)
	struct FContextualAnimRepLateJoinData RepLateJoinData; // 0x5a0(0x38)
	struct FContextualAnimRepTransitionData RepTransitionData; // 0x5d8(0x28)
	struct FContextualAnimRepTransitionData RepTransitionSingleActorData; // 0x600(0x28)
	struct FContextualAnimSceneBindings Bindings; // 0x628(0x28)
	struct TArray<struct FContextualAnimIKTarget> IKTargets; // 0x650(0x10)
	char pad_660[0x50]; // 0x660(0x50)

	bool TransitionSingleActor(int32_t SectionIdx, int32_t AnimSetIdx); // Function ContextualAnimation.ContextualAnimSceneActorComponent.TransitionSingleActor // (Final|Native|Public|BlueprintCallable) // @ game+0x886a5b4
	bool TransitionContextualAnimScene(struct FName SectionName); // Function ContextualAnimation.ContextualAnimSceneActorComponent.TransitionContextualAnimScene // (Final|Native|Public|BlueprintCallable) // @ game+0x886a4e8
	bool StartContextualAnimScene(struct FContextualAnimSceneBindings& InBindings); // Function ContextualAnimation.ContextualAnimSceneActorComponent.StartContextualAnimScene // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x886a430
	void ServerStartContextualAnimScene(struct FContextualAnimSceneBindings InBindings); // Function ContextualAnimation.ContextualAnimSceneActorComponent.ServerStartContextualAnimScene // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x886a324
	void ServerEarlyOutContextualAnimScene(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.ServerEarlyOutContextualAnimScene // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x886a2d8
	void OnTickPose(struct USkinnedMeshComponent* SkinnedMeshComponent, float DeltaTime, bool bNeedsValidRootMotion); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnTickPose // (Native|Protected) // @ game+0x8869ecc
	void OnRep_TransitionData(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnRep_TransitionData // (Final|Native|Protected) // @ game+0x8869eb8
	void OnRep_RepTransitionSingleActor(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnRep_RepTransitionSingleActor // (Final|Native|Protected) // @ game+0x8869ea4
	void OnRep_LateJoinData(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnRep_LateJoinData // (Final|Native|Protected) // @ game+0x8869e90
	void OnRep_Bindings(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnRep_Bindings // (Final|Native|Protected) // @ game+0x8869e7c
	void OnPlayMontageNotifyBegin(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnPlayMontageNotifyBegin // (Final|Native|Protected|HasOutParms) // @ game+0x8869d54
	void OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnMontageBlendingOut // (Final|Native|Protected) // @ game+0x8869c14
	void OnLeftScene(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnLeftScene // (Final|Native|Public|BlueprintCallable) // @ game+0x3600a3c
	void OnJoinedScene(struct FContextualAnimSceneBindings& InBindings); // Function ContextualAnimation.ContextualAnimSceneActorComponent.OnJoinedScene // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8869b8c
	bool LateJoinContextualAnimScene(struct AActor* Actor, struct FName Role); // Function ContextualAnimation.ContextualAnimSceneActorComponent.LateJoinContextualAnimScene // (Final|Native|Public|BlueprintCallable) // @ game+0x8869a3c
	bool IsInActiveScene(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.IsInActiveScene // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x88699e4
	struct TArray<struct FContextualAnimIKTarget> GetIKTargets(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.GetIKTargets // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8869844
	struct FContextualAnimIKTarget GetIKTargetByGoalName(struct FName GoalName); // Function ContextualAnimation.ContextualAnimSceneActorComponent.GetIKTargetByGoalName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x886971c
	void EarlyOutContextualAnimScene(); // Function ContextualAnimation.ContextualAnimSceneActorComponent.EarlyOutContextualAnimScene // (Final|Native|Public|BlueprintCallable) // @ game+0x886848c
};

// Class ContextualAnimation.ContextualAnimRolesAsset
// Size: 0x40 (Inherited: 0x30)
struct UContextualAnimRolesAsset : UDataAsset {
	struct TArray<struct FContextualAnimRoleDefinition> Roles; // 0x30(0x10)
};

// Class ContextualAnimation.ContextualAnimSceneAsset
// Size: 0x80 (Inherited: 0x30)
struct UContextualAnimSceneAsset : UDataAsset {
	struct UContextualAnimRolesAsset* RolesAsset; // 0x30(0x08)
	struct FName PrimaryRole; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct TArray<struct FContextualAnimSceneSection> Sections; // 0x40(0x10)
	float Radius; // 0x50(0x04)
	enum class EContextualAnimCollisionBehavior CollisionBehavior; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	struct TArray<struct FContextualAnimIgnoreChannelsParam> CollisionChannelsToIgnoreParams; // 0x58(0x10)
	struct TArray<struct FContextualAnimAttachmentParams> AttachmentParams; // 0x68(0x10)
	bool bPrecomputeAlignmentTracks; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	int32_t SampleRate; // 0x7c(0x04)

	bool Query(struct FName Role, struct FContextualAnimQueryResult& OutResult, struct FContextualAnimQueryParams& QueryParams, struct FTransform& ToWorldTransform); // Function ContextualAnimation.ContextualAnimSceneAsset.Query // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x886a08c
	struct TArray<struct FName> GetRoles(); // Function ContextualAnimation.ContextualAnimSceneAsset.GetRoles // (Final|Native|Public|Const) // @ game+0x88698e4
	void GetAlignmentPointsForSecondaryRoleConsideringSelectionCriteria(enum class EContextualAnimPointType Type, int32_t SectionIdx, struct FContextualAnimSceneBindingContext& Primary, struct FContextualAnimSceneBindingContext& Querier, enum class EContextualAnimCriterionToConsider CriterionToConsider, struct TArray<struct FContextualAnimPoint>& OutResult); // Function ContextualAnimation.ContextualAnimSceneAsset.GetAlignmentPointsForSecondaryRoleConsideringSelectionCriteria // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8868d44
	void GetAlignmentPointsForSecondaryRole(enum class EContextualAnimPointType Type, int32_t SectionIdx, struct FContextualAnimSceneBindingContext& Primary, struct TArray<struct FContextualAnimPoint>& OutResult); // Function ContextualAnimation.ContextualAnimSceneAsset.GetAlignmentPointsForSecondaryRole // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x88684a0
	void BP_GetStartAndEndTimeForWarpSection(int32_t SectionIdx, int32_t AnimSetIdx, struct FName Role, struct FName WarpSectionName, float& OutStartTime, float& OutEndTime); // Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetStartAndEndTimeForWarpSection // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8865684
	struct FTransform BP_GetIKTargetTransformForRoleAtTime(int32_t SectionIdx, int32_t AnimSetIdx, struct FName Role, struct FName TrackName, float Time); // Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetIKTargetTransformForRoleAtTime // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x8865390
	struct FTransform BP_GetAlignmentTransformForRoleRelativeToWarpPoint(int32_t SectionIdx, int32_t AnimSetIdx, struct FName Role, float Time); // Function ContextualAnimation.ContextualAnimSceneAsset.BP_GetAlignmentTransformForRoleRelativeToWarpPoint // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x88650fc
	int32_t BP_FindAnimSetIndexByAnimation(int32_t SectionIdx, struct UAnimSequenceBase* Animation); // Function ContextualAnimation.ContextualAnimSceneAsset.BP_FindAnimSetIndexByAnimation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8864d78
	struct UAnimSequenceBase* BP_FindAnimationForRole(int32_t SectionIdx, int32_t AnimSetIdx, struct FName Role); // Function ContextualAnimation.ContextualAnimSceneAsset.BP_FindAnimationForRole // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8864f24
};

// Class ContextualAnimation.ContextualAnimSelectionCriterion
// Size: 0x30 (Inherited: 0x28)
struct UContextualAnimSelectionCriterion : UObject {
	enum class EContextualAnimCriterionType Type; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// Class ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint
// Size: 0x30 (Inherited: 0x30)
struct UContextualAnimSelectionCriterion_Blueprint : UContextualAnimSelectionCriterion {

	struct UContextualAnimSceneAsset* GetSceneAsset(); // Function ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint.GetSceneAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x886999c
	bool BP_DoesQuerierPassCondition(struct FContextualAnimSceneBindingContext& Primary, struct FContextualAnimSceneBindingContext& Querier); // Function ContextualAnimation.ContextualAnimSelectionCriterion_Blueprint.BP_DoesQuerierPassCondition // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x18e3f1c
};

// Class ContextualAnimation.ContextualAnimSelectionCriterion_TriggerArea
// Size: 0x48 (Inherited: 0x30)
struct UContextualAnimSelectionCriterion_TriggerArea : UContextualAnimSelectionCriterion {
	struct TArray<struct FVector> PolygonPoints; // 0x30(0x10)
	float Height; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class ContextualAnimation.ContextualAnimSelectionCriterion_Cone
// Size: 0x40 (Inherited: 0x30)
struct UContextualAnimSelectionCriterion_Cone : UContextualAnimSelectionCriterion {
	enum class EContextualAnimCriterionConeMode Mode; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float Distance; // 0x34(0x04)
	float HalfAngle; // 0x38(0x04)
	float Offset; // 0x3c(0x04)
};

// Class ContextualAnimation.ContextualAnimSelectionCriterion_Distance
// Size: 0x40 (Inherited: 0x30)
struct UContextualAnimSelectionCriterion_Distance : UContextualAnimSelectionCriterion {
	enum class EContextualAnimCriterionDistanceMode Mode; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float MinDistance; // 0x34(0x04)
	float MaxDistance; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class ContextualAnimation.ContextualAnimUtilities
// Size: 0x28 (Inherited: 0x28)
struct UContextualAnimUtilities : UBlueprintFunctionLibrary {

	void BP_SceneBindings_GetSectionAndAnimSetIndices(struct FContextualAnimSceneBindings& Bindings, int32_t& SectionIdx, int32_t& AnimSetIdx); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetSectionAndAnimSetIndices // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x88682a8
	struct UContextualAnimSceneAsset* BP_SceneBindings_GetSceneAsset(struct FContextualAnimSceneBindings& Bindings); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetSceneAsset // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x88681fc
	struct TArray<struct FContextualAnimSceneBinding> BP_SceneBindings_GetBindings(struct FContextualAnimSceneBindings& Bindings); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x886814c
	struct FContextualAnimSceneBinding BP_SceneBindings_GetBindingByRole(struct FContextualAnimSceneBindings& Bindings, struct FName Role); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindingByRole // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8867fbc
	struct FContextualAnimSceneBinding BP_SceneBindings_GetBindingByActor(struct FContextualAnimSceneBindings& Bindings, struct AActor* Actor); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetBindingByActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8867e30
	struct FTransform BP_SceneBindings_GetAlignmentTransformFromBinding(struct FContextualAnimSceneBindings& Bindings, struct FContextualAnimSceneBinding& Binding, struct FContextualAnimWarpPoint& WarpPoint); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformFromBinding // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x8867c34
	struct FTransform BP_SceneBindings_GetAlignmentTransformForRoleRelativeToWarpPoint(struct FContextualAnimSceneBindings& Bindings, struct FName Role, struct FContextualAnimWarpPoint& WarpPoint, float Time); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformForRoleRelativeToWarpPoint // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x886798c
	struct FTransform BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole(struct FContextualAnimSceneBindings& Bindings, struct FName Role, struct FName RelativeToRole, float Time); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_GetAlignmentTransformForRoleRelativeToOtherRole // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x88676f0
	void BP_SceneBindings_CalculateWarpPoints(struct FContextualAnimSceneBindings& Bindings, struct TArray<struct FContextualAnimWarpPoint>& OutWarpPoints); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_CalculateWarpPoints // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8866f90
	void BP_SceneBindings_AddOrUpdateWarpTargetsForBindings(struct FContextualAnimSceneBindings& Bindings); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindings_AddOrUpdateWarpTargetsForBindings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8866ef4
	struct FContextualAnimSceneBindingContext BP_SceneBindingContext_MakeFromActorWithExternalTransform(struct AActor* Actor, struct FTransform ExternalTransform); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_MakeFromActorWithExternalTransform // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x88667e4
	struct FContextualAnimSceneBindingContext BP_SceneBindingContext_MakeFromActor(struct AActor* Actor); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_MakeFromActor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x88666c8
	bool BP_SceneBindingContext_HasMatchingGameplayTag(struct FContextualAnimSceneBindingContext& BindingContext, struct FGameplayTag& TagToCheck); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_HasMatchingGameplayTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x88664f0
	bool BP_SceneBindingContext_HasAnyMatchingGameplayTags(struct FContextualAnimSceneBindingContext& BindingContext, struct FGameplayTagContainer& TagContainer); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_HasAnyMatchingGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8866368
	bool BP_SceneBindingContext_HasAllMatchingGameplayTags(struct FContextualAnimSceneBindingContext& BindingContext, struct FGameplayTagContainer& TagContainer); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_HasAllMatchingGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x88661e0
	struct FVector BP_SceneBindingContext_GetVelocity(struct FContextualAnimSceneBindingContext& BindingContext); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x88660a8
	struct FTransform BP_SceneBindingContext_GetTransform(struct FContextualAnimSceneBindingContext& BindingContext); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x8865f98
	struct FGameplayTagContainer BP_SceneBindingContext_GetGameplayTags(struct FContextualAnimSceneBindingContext& BindingContext); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8865eac
	struct AActor* BP_SceneBindingContext_GetActor(struct FContextualAnimSceneBindingContext& BindingContext); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBindingContext_GetActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8865dc8
	struct USkeletalMeshComponent* BP_SceneBinding_GetSkeletalMesh(struct FContextualAnimSceneBinding& Binding); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetSkeletalMesh // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8866db4
	struct FName BP_SceneBinding_GetRoleFromBinding(struct FContextualAnimSceneBindings& Bindings, struct FContextualAnimSceneBinding& Binding); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetRoleFromBinding // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8866c44
	struct UAnimSequenceBase* BP_SceneBinding_GetAnimationFromBinding(struct FContextualAnimSceneBindings& Bindings, struct FContextualAnimSceneBinding& Binding); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetAnimationFromBinding // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8866adc
	struct AActor* BP_SceneBinding_GetActor(struct FContextualAnimSceneBinding& Binding); // Function ContextualAnimation.ContextualAnimUtilities.BP_SceneBinding_GetActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x88669f4
	float BP_Montage_GetSectionTimeLeftFromPos(struct UAnimMontage* Montage, float Position); // Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionTimeLeftFromPos // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8865c70
	void BP_Montage_GetSectionStartAndEndTime(struct UAnimMontage* Montage, int32_t SectionIndex, float& OutStartTime, float& OutEndTime); // Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionStartAndEndTime // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8865aa0
	float BP_Montage_GetSectionLength(struct UAnimMontage* Montage, int32_t SectionIndex); // Function ContextualAnimation.ContextualAnimUtilities.BP_Montage_GetSectionLength // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8865948
	void BP_DrawDebugPose(struct UObject* WorldContextObject, struct UAnimSequenceBase* Animation, float Time, struct FTransform LocalToWorldTransform, struct FLinearColor Color, float Lifetime, float Thickness); // Function ContextualAnimation.ContextualAnimUtilities.BP_DrawDebugPose // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x8864914
	bool BP_CreateContextualAnimSceneBindingsForTwoActors(struct UContextualAnimSceneAsset* SceneAsset, struct FContextualAnimSceneBindingContext& Primary, struct FContextualAnimSceneBindingContext& Secondary, struct FContextualAnimSceneBindings& OutBindings); // Function ContextualAnimation.ContextualAnimUtilities.BP_CreateContextualAnimSceneBindingsForTwoActors // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8864698
	bool BP_CreateContextualAnimSceneBindings(struct UContextualAnimSceneAsset* SceneAsset, struct TMap<struct FName, struct FContextualAnimSceneBindingContext>& Params, struct FContextualAnimSceneBindings& OutBindings); // Function ContextualAnimation.ContextualAnimUtilities.BP_CreateContextualAnimSceneBindings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x88644d8
};

