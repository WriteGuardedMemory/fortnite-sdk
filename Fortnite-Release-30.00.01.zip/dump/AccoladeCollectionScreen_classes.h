// Class AccoladeCollectionScreen.FortAccoladeStageListEntry
// Size: 0x300 (Inherited: 0x2e0)
struct UFortAccoladeStageListEntry : UCommonUserWidget {
	char pad_2E0[0x18]; // 0x2e0(0x18)
	struct UAthenaChallengeRewards* UserWidget_Rewards; // 0x2f8(0x08)

	void BP_PopulateAchievedCount(int32_t AchievedCount); // Function AccoladeCollectionScreen.FortAccoladeStageListEntry.BP_PopulateAchievedCount // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

// Class AccoladeCollectionScreen.FortAccoladeStagesListView
// Size: 0x390 (Inherited: 0x280)
struct UFortAccoladeStagesListView : UListViewBase {
	char pad_280[0x108]; // 0x280(0x108)
	float EntrySpacing; // 0x388(0x04)
	char pad_38C[0x4]; // 0x38c(0x04)
};

// Class AccoladeCollectionScreen.PinnedAccoladeWidget
// Size: 0x330 (Inherited: 0x320)
struct UPinnedAccoladeWidget : UFortHUDElementWidget {
	struct UFortLazyImage* LazyImage_PinColor; // 0x320(0x08)
	int32_t NumAllowedDescCharacters; // 0x328(0x04)
	char pad_32C[0x4]; // 0x32c(0x04)

	void BP_PopulateAccoladeInfo(struct FText& Description, int32_t Achieved, int32_t Total); // Function AccoladeCollectionScreen.PinnedAccoladeWidget.BP_PopulateAccoladeInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
};

// Class AccoladeCollectionScreen.FortCollectionDataEntryAccolade
// Size: 0x40 (Inherited: 0x30)
struct UFortCollectionDataEntryAccolade : UFortCollectionDataEntry {
	char pad_30[0x10]; // 0x30(0x10)
};

// Class AccoladeCollectionScreen.FortPlayerAccoladeCollectionListEntry
// Size: 0x1580 (Inherited: 0x1570)
struct UFortPlayerAccoladeCollectionListEntry : UAthenaCollectionListEntry {
	struct UImage* Image_Background; // 0x1570(0x08)
	struct FName ParamName_ItemIcon; // 0x1578(0x04)
	struct FName ParamName_IsDiscovered; // 0x157c(0x04)

	void BP_UpdateCompletedCount(int32_t CompletedCount); // Function AccoladeCollectionScreen.FortPlayerAccoladeCollectionListEntry.BP_UpdateCompletedCount // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_UpdateAccoladeTier(enum class EFortAccoladeTierType Tier); // Function AccoladeCollectionScreen.FortPlayerAccoladeCollectionListEntry.BP_UpdateAccoladeTier // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnSelectionSuppressionChanged(bool bShouldBeSuppressed); // Function AccoladeCollectionScreen.FortPlayerAccoladeCollectionListEntry.BP_OnSelectionSuppressionChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnPinnedChanged(bool bPinned); // Function AccoladeCollectionScreen.FortPlayerAccoladeCollectionListEntry.BP_OnPinnedChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

// Class AccoladeCollectionScreen.FortPlayerAccoladeCollectionScreen
// Size: 0x6c0 (Inherited: 0x638)
struct UFortPlayerAccoladeCollectionScreen : UAthenaCollectionScreenBase {
	char pad_638[0x30]; // 0x638(0x30)
	struct FScalableFloat AccoladesEnabledViaHotfix; // 0x668(0x28)
	struct UCommonTextBlock* Text_CategoryTitle; // 0x690(0x08)
	struct UCommonButtonBase* Button_ClearBangs; // 0x698(0x08)
	char pad_6A0[0x18]; // 0x6a0(0x18)
	bool bUserProgressSuccessfullyRetrieved; // 0x6b8(0x01)
	char pad_6B9[0x7]; // 0x6b9(0x07)
};

// Class AccoladeCollectionScreen.FortPlayerAccoladeCollectionScreenContainer
// Size: 0x548 (Inherited: 0x530)
struct UFortPlayerAccoladeCollectionScreenContainer : UAthenaCollectionScreenContainer {
	struct UAccoladeProductData* BRProductData; // 0x530(0x08)
	char pad_538[0x10]; // 0x538(0x10)

	void BP_PopulateProgress(int32_t Current, int32_t Total); // Function AccoladeCollectionScreen.FortPlayerAccoladeCollectionScreenContainer.BP_PopulateProgress // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

// Class AccoladeCollectionScreen.FortPlayerAccoladeCollectionScreenInfoOverlay
// Size: 0x4c0 (Inherited: 0x4b0)
struct UFortPlayerAccoladeCollectionScreenInfoOverlay : UAthenaCollectionScreenInfoOverlay {
	struct UFortCTAButton* Button_TrackAccolade; // 0x4b0(0x08)
	struct UFortAccoladeStagesListView* ListView_AccoladesStages; // 0x4b8(0x08)

	void BP_UpdateTrackButtonText(bool bTracked); // Function AccoladeCollectionScreen.FortPlayerAccoladeCollectionScreenInfoOverlay.BP_UpdateTrackButtonText // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_UpdateAccoladeTier(enum class EFortAccoladeTierType Tier); // Function AccoladeCollectionScreen.FortPlayerAccoladeCollectionScreenInfoOverlay.BP_UpdateAccoladeTier // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_PopulateAccoladeInfo(int32_t CompletionCount); // Function AccoladeCollectionScreen.FortPlayerAccoladeCollectionScreenInfoOverlay.BP_PopulateAccoladeInfo // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

