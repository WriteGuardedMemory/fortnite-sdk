// Enum ComputeFramework.EComputeKernelFlags
enum class EComputeKernelFlags : uint8 {
	IsDefaultKernel = 1,
	IsolatedMemoryWrites = 2,
	EComputeKernelFlags_MAX = 3
};

// Enum ComputeFramework.EShaderFundamentalType
enum class EShaderFundamentalType : uint8 {
	Bool = 0,
	Int = 1,
	Uint = 2,
	Float = 3,
	Struct = 4,
	None = 255,
	EShaderFundamentalType_MAX = 256
};

// Enum ComputeFramework.EShaderFundamentalDimensionType
enum class EShaderFundamentalDimensionType : uint8 {
	Scalar = 0,
	Vector = 1,
	Matrix = 2,
	EShaderFundamentalDimensionType_MAX = 3
};

// Enum ComputeFramework.EShaderParamBindingType
enum class EShaderParamBindingType : uint8 {
	None = 0,
	ConstantParameter = 1,
	ReadOnlyResource = 2,
	ReadWriteResource = 3,
	EShaderParamBindingType_MAX = 4
};

// Enum ComputeFramework.EShaderResourceType
enum class EShaderResourceType : uint8 {
	None = 0,
	Texture1D = 1,
	Texture2D = 2,
	Texture3D = 3,
	TextureCube = 4,
	Buffer = 5,
	StructuredBuffer = 6,
	ByteAddressBuffer = 7,
	EShaderResourceType_MAX = 8
};

// ScriptStruct ComputeFramework.ComputeGraphEdge
// Size: 0x38 (Inherited: 0x00)
struct FComputeGraphEdge {
	int32_t KernelIndex; // 0x00(0x04)
	int32_t KernelBindingIndex; // 0x04(0x04)
	int32_t DataInterfaceIndex; // 0x08(0x04)
	int32_t DataInterfaceBindingIndex; // 0x0c(0x04)
	bool bKernelInput; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString BindingFunctionNameOverride; // 0x18(0x10)
	struct FString BindingFunctionNamespace; // 0x28(0x10)
};

// ScriptStruct ComputeFramework.ComputeGraphInstance
// Size: 0x18 (Inherited: 0x00)
struct FComputeGraphInstance {
	struct TArray<struct UComputeDataProvider*> DataProviders; // 0x00(0x10)
	char pad_10[0x8]; // 0x10(0x08)
};

// ScriptStruct ComputeFramework.ComputeKernelPermutationBool
// Size: 0x18 (Inherited: 0x00)
struct FComputeKernelPermutationBool {
	struct FString Name; // 0x00(0x10)
	bool Value; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct ComputeFramework.ComputeKernelPermutationSet
// Size: 0x10 (Inherited: 0x00)
struct FComputeKernelPermutationSet {
	struct TArray<struct FComputeKernelPermutationBool> BooleanOptions; // 0x00(0x10)
};

// ScriptStruct ComputeFramework.ComputeKernelDefinition
// Size: 0x20 (Inherited: 0x00)
struct FComputeKernelDefinition {
	struct FString Symbol; // 0x00(0x10)
	struct FString Define; // 0x10(0x10)
};

// ScriptStruct ComputeFramework.ComputeKernelDefinitionSet
// Size: 0x10 (Inherited: 0x00)
struct FComputeKernelDefinitionSet {
	struct TArray<struct FComputeKernelDefinition> Defines; // 0x00(0x10)
};

// ScriptStruct ComputeFramework.ComputeKernelPermutationVector
// Size: 0x58 (Inherited: 0x00)
struct FComputeKernelPermutationVector {
	struct TMap<struct FString, uint32_t> Permutations; // 0x00(0x50)
	uint32_t BitCount; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct ComputeFramework.ShaderValueTypeHandle
// Size: 0x08 (Inherited: 0x00)
struct FShaderValueTypeHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct ComputeFramework.ShaderValueType
// Size: 0x20 (Inherited: 0x00)
struct FShaderValueType {
	enum class EShaderFundamentalType Type; // 0x00(0x01)
	enum class EShaderFundamentalDimensionType DimensionType; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	struct FName Name; // 0x04(0x04)
	bool bIsDynamicArray; // 0x08(0x01)
	char pad_9[0x17]; // 0x09(0x17)
};

// ScriptStruct ComputeFramework.ShaderParamTypeDefinition
// Size: 0x30 (Inherited: 0x00)
struct FShaderParamTypeDefinition {
	struct FString TypeDeclaration; // 0x00(0x10)
	struct FString Name; // 0x10(0x10)
	struct FShaderValueTypeHandle ValueType; // 0x20(0x08)
	uint16_t ArrayElementCount; // 0x28(0x02)
	enum class EShaderParamBindingType BindingType; // 0x2a(0x01)
	enum class EShaderResourceType ResourceType; // 0x2b(0x01)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct ComputeFramework.ShaderFunctionDefinition
// Size: 0x28 (Inherited: 0x00)
struct FShaderFunctionDefinition {
	struct FString Name; // 0x00(0x10)
	struct TArray<struct FShaderParamTypeDefinition> ParamTypes; // 0x10(0x10)
	bool bHasReturnType; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

