// BlueprintGeneratedClass Border-SolidBG-RewardBack.Border-SolidBG-RewardBack_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-SolidBG-RewardBack_C : UBorder-ShellTopBar_C {
};

