// Class Account.ExternalAccountProvider
// Size: 0x38 (Inherited: 0x28)
struct UExternalAccountProvider : UObject {
	struct TArray<struct FExternalAccountServiceConfig> Services; // 0x28(0x10)
};

// Class Account.OnlineAccountCommon
// Size: 0xa40 (Inherited: 0x28)
struct UOnlineAccountCommon : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct FString AvailabilityServiceGameName; // 0x38(0x10)
	bool bRequireLightswitchAtStartup; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FString EulaKey; // 0x50(0x10)
	struct TArray<struct FString> EulaKeys; // 0x60(0x10)
	struct TMap<struct FString, struct FString> EulaKeyMapping; // 0x70(0x50)
	bool bEnableWaitingRoom; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct TArray<struct FWebEnvUrl> WebCreateEpicAccountUrl; // 0xc8(0x10)
	bool bAllowLocalLogout; // 0xd8(0x01)
	char pad_D9[0x37]; // 0xd9(0x37)
	float DefaultLoginStepTimeout; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
	struct TMap<struct FName, float> CustomLoginStepTimeouts; // 0x118(0x50)
	bool bEnableDevLoginStepTimeouts; // 0x168(0x01)
	char pad_169[0x57]; // 0x169(0x57)
	float DefaultLogoutStepTimeout; // 0x1c0(0x04)
	char pad_1C4[0x4]; // 0x1c4(0x04)
	struct TMap<struct FName, float> CustomLogoutStepTimeouts; // 0x1c8(0x50)
	bool bEnableDevLogoutStepTimeouts; // 0x218(0x01)
	char pad_219[0x77]; // 0x219(0x77)
	struct FServiceLoginMethodConfig ServiceLoginMethodConfig; // 0x290(0x05)
	char pad_295[0x3]; // 0x295(0x03)
	struct FString RedeemAccessUrl; // 0x298(0x10)
	struct FString RequestFreeAccessUrl; // 0x2a8(0x10)
	struct FString RealGameAccessUrl; // 0x2b8(0x10)
	float SkipRedeemOfflinePurchasesChance; // 0x2c8(0x04)
	bool bUseFreeAccessInsteadOfGameAccess; // 0x2cc(0x01)
	bool bShouldGrantFreeAccess; // 0x2cd(0x01)
	char pad_2CE[0x1]; // 0x2ce(0x01)
	bool bAllowHomeSharingAccess; // 0x2cf(0x01)
	bool bRequireUGCPrivilege; // 0x2d0(0x01)
	char pad_2D1[0x21f]; // 0x2d1(0x21f)
	float AccessGrantDelaySeconds; // 0x4f0(0x04)
	char pad_4F4[0x4]; // 0x4f4(0x04)
	struct UWaitingRoomState* WaitingRoomState; // 0x4f8(0x08)
	char pad_500[0x540]; // 0x500(0x540)
};

// Class Account.WaitingRoomState
// Size: 0x88 (Inherited: 0x28)
struct UWaitingRoomState : UObject {
	char pad_28[0x34]; // 0x28(0x34)
	int32_t GracePeriodMins; // 0x5c(0x04)
	char pad_60[0x28]; // 0x60(0x28)
};

