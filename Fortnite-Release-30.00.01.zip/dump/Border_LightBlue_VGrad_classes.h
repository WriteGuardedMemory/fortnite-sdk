// BlueprintGeneratedClass Border_LightBlue_VGrad.Border_LightBlue_VGrad_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder_LightBlue_VGrad_C : UCommonBorderStyle {
};

