// ScriptStruct CharacterDynamicsControlRuntime.BinaryDecisionTreeElement
// Size: 0x18 (Inherited: 0x00)
struct FBinaryDecisionTreeElement {
	int32_t Value; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	int64_t BitMask; // 0x08(0x08)
	int64_t BitSet; // 0x10(0x08)
};

// ScriptStruct CharacterDynamicsControlRuntime.BinaryDecisionTree
// Size: 0x10 (Inherited: 0x00)
struct FBinaryDecisionTree {
	struct TArray<struct FBinaryDecisionTreeElement> TreeStructure; // 0x00(0x10)
};

// ScriptStruct CharacterDynamicsControlRuntime.FortGravityOverrideParameters
// Size: 0x68 (Inherited: 0x00)
struct FFortGravityOverrideParameters {
	struct FVector WindFrequency; // 0x00(0x18)
	struct FVector WindAmplitude; // 0x18(0x18)
	struct FVector WindOffset; // 0x30(0x18)
	struct FVector GravityOverride; // 0x48(0x18)
	struct FName JointName; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct CharacterDynamicsControlRuntime.FortRigidBodyAnimNodeParameters
// Size: 0x90 (Inherited: 0x00)
struct FFortRigidBodyAnimNodeParameters {
	struct FVector ComponentLinearAccScale; // 0x00(0x18)
	struct FVector ComponentLinearVelScale; // 0x18(0x18)
	struct FSimSpaceSettings SimSpaceSettings; // 0x30(0x60)
};

// ScriptStruct CharacterDynamicsControlRuntime.FortRigidBodyWithControlStateTransitionParameters
// Size: 0x38 (Inherited: 0x00)
struct FFortRigidBodyWithControlStateTransitionParameters {
	struct FPhysicsControlControlAndModifierParameters ControlAndModifierParameters; // 0x00(0x30)
	float TransitionTimeSeconds; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

