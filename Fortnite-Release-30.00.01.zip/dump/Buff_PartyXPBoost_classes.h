// BlueprintGeneratedClass Buff_PartyXPBoost.Buff_PartyXPBoost_C
// Size: 0xa68 (Inherited: 0xa68)
struct UBuff_PartyXPBoost_C : UGameplayEffect {
};

