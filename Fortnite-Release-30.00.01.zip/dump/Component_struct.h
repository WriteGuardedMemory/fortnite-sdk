// VerseEnum Component.collision_channel_response
enum class collision_channel_response : uint8 {
	Ignore = 0,
	Overlap = 1,
	Block = 2,
	collision_channel_MAX = 3
};

// VerseStruct Component.hit_result
// Size: 0x50 (Inherited: 0x00)
struct Fhit_result {
	OptionalProperty __verse_0x9C8E9A95_ThisEntity; // 0x00(0x08)
	OptionalProperty __verse_0x0170A73A_ThisComponent; // 0x08(0x08)
	OptionalProperty __verse_0x9E548E88_OtherEntity; // 0x10(0x08)
	OptionalProperty __verse_0x15DAA648_OtherComponent; // 0x18(0x08)
	struct FSpatialMath_vector3 __verse_0xA0175DA6_HitNormal; // 0x20(0x18)
	struct FSpatialMath_vector3 __verse_0xE16733E1_HitLocation; // 0x38(0x18)
};

// VerseStruct Component.tuple_L_Kany_Mtuple_L_R_Many_R
// Size: 0x28 (Inherited: 0x00)
struct Ftuple_L_Kany_Mtuple_L_R_Many_R {
	struct TArray<VerseDynamicProperty> __verse_0x18E3F084_Elem0; // 0x00(0x10)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	VerseDynamicProperty __verse_0x932BF92E_Elem2; // 0x18(0x10)
};

// VerseStruct Component.tuple_L_Kany_Mtuple_L_R_Mint_R
// Size: 0x20 (Inherited: 0x00)
struct Ftuple_L_Kany_Mtuple_L_R_Mint_R {
	struct TArray<VerseDynamicProperty> __verse_0x18E3F084_Elem0; // 0x00(0x10)
	struct Ftuple_L_R __verse_0x7D844C3C_Elem1; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	int64_t __verse_0x932BF92E_Elem2; // 0x18(0x08)
};

// VerseStruct Component.tuple_L_R
// Size: 0x01 (Inherited: 0x00)
struct Ftuple_L_R {
	char $StructPaddingDummy; // 0x00(0x01)
};

// VerseStruct Component.tuple_Lcanvas_Mplayer__ui__slot_R
// Size: 0x18 (Inherited: 0x00)
struct Ftuple_Lcanvas_Mplayer__ui__slot_R {
	struct UUI_canvas* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct FUI_player_ui_slot __verse_0x7D844C3C_Elem1; // 0x08(0x10)
};

// VerseStruct Component.tuple_Lentity_Mtransform_R
// Size: 0x70 (Inherited: 0x00)
struct Ftuple_Lentity_Mtransform_R {
	struct UEntity* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct FSpatialMath_transform __verse_0x7D844C3C_Elem1; // 0x10(0x60)
};

// VerseStruct Component.tuple_Lwidget_Mplayer__ui__slot_R
// Size: 0x18 (Inherited: 0x00)
struct Ftuple_Lwidget_Mplayer__ui__slot_R {
	struct UUI_widget* __verse_0x18E3F084_Elem0; // 0x00(0x08)
	struct FUI_player_ui_slot __verse_0x7D844C3C_Elem1; // 0x08(0x10)
};

