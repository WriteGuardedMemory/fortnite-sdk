// BlueprintGeneratedClass CommonUI_PS5BrushData.CommonUI_PS5BrushData_C
// Size: 0xd0 (Inherited: 0xd0)
struct UCommonUI_PS5BrushData_C : UFortInputControllerData {
};

