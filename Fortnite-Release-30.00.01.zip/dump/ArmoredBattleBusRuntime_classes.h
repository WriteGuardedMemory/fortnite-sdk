// Class ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance
// Size: 0x1490 (Inherited: 0x13d0)
struct UFortArmoredBattleBusPassengerAnimInstance : UFortPlayerAnimInstanceProxy {
	struct FRotator PreviousVehicleRotator; // 0x13c8(0x18)
	float SmoothedVehicleYawRate; // 0x13e0(0x04)
	int32_t PawnSeat; // 0x13e4(0x04)
	bool bIsFrontTurretPassenger; // 0x13e8(0x01)
	bool bIsRearTurretPassenger; // 0x13e9(0x01)
	float Speed; // 0x13ec(0x04)
	float YawDelta; // 0x13f0(0x04)
	float TurretYaw; // 0x13f4(0x04)
	float TurretPitch; // 0x13f8(0x04)
	struct FRotator TurretYawRotator; // 0x1400(0x18)
	float SlopeRollDegreeAngle; // 0x1418(0x04)
	float SlopePitchDegreeAngle; // 0x141c(0x04)
	struct FVector HandAttachL; // 0x1420(0x18)
	struct FVector HandAttachR; // 0x1438(0x18)
	enum class ERelativeTransformSpace TransformSpace; // 0x1450(0x01)
	char pad_1453[0x1]; // 0x1453(0x01)
	float UpdateYawDeltaSmoothedLerpRate; // 0x1454(0x04)
	int32_t TurretPassengerFront; // 0x1458(0x04)
	int32_t TurretPassengerRear; // 0x145c(0x04)
	struct FName FrontFootBoneName; // 0x1460(0x04)
	struct FName RearFootBoneName; // 0x1464(0x04)
	struct FName GunHandAttachBoneName_FrontLeft; // 0x1468(0x04)
	struct FName GunHandAttachBoneName_RearLeft; // 0x146c(0x04)
	struct FName GunHandAttachBoneName_FrontRight; // 0x1470(0x04)
	struct FName GunHandAttachBoneName_RearRight; // 0x1474(0x04)
	struct FName PassengerBoneName_Front; // 0x1478(0x04)
	struct FName PassengerBoneName_Rear; // 0x147c(0x04)
	float TurretPitchDegMin; // 0x1480(0x04)
	float TurretPitchDegMax; // 0x1484(0x04)
	float LocalPlayerTurretPitchEaseRate; // 0x1488(0x04)
	char pad_148C[0x4]; // 0x148c(0x04)

	void UpdateYawDeltaSmoothed(struct AFortAthenaVehicle* VehicleActor, struct FName SocketName, struct FRotator& NewRotation, float& SmoothedYawValue); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateYawDeltaSmoothed // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb6e5c0c
	void UpdateSmoothedVehicleYawRate(struct AFortAthenaVehicle* VehicleActor); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateSmoothedVehicleYawRate // (Final|Native|Public|BlueprintCallable) // @ game+0xb6e55c0
	void UpdateHandPositionsSlopeValues(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateHandPositionsSlopeValues // (Final|Native|Public|BlueprintCallable) // @ game+0xb6e5500
	struct FVector UnrotateHandAttachLocation(struct FVector& HandLocation, struct FVector& FootLocation, struct FRotator& FootRotation); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UnrotateHandAttachLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb6e533c
	struct FTransform GetPassengerTransform(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetPassengerTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xb6e4fbc
	struct FVector GetHandAttachLocation(struct USkeletalMeshComponent* BusMeshComponent, struct FName FrontHandAttachBoneName, struct FName RearHandAttachBoneName); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetHandAttachLocation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xb6e4dec
	struct FTransform GetFootAttachTransform(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetFootAttachTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xb6e4cd0
	void GenerateCharacterPitchAndYawForSlopedTerrain(struct AFortAthenaVehicle* VehicleActor, float& TurretYaw, float& TurretPitch, struct FRotator& PawnYawRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GenerateCharacterPitchAndYawForSlopedTerrain // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb6e4b28
};

// Class ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance
// Size: 0x6b0 (Inherited: 0x620)
struct UFortArmoredBattleBusVehicleAnimInstance : UFortVehicleAnimInstance {
	float FrontTurretAimPitch; // 0x618(0x04)
	float RearTurretAimPitch; // 0x61c(0x04)
	float FrontYawDeltaSmoothed; // 0x620(0x04)
	float RearYawDeltaSmoothed; // 0x624(0x04)
	float SmoothedVehicleYawRate; // 0x628(0x04)
	float FrontYawDeltaSmoothedAlpha; // 0x62c(0x04)
	float RearYawDeltaSmoothedAlpha; // 0x630(0x04)
	struct FRotator FrontWeaponYaw; // 0x638(0x18)
	struct FRotator RearWeaponYaw; // 0x650(0x18)
	struct FRotator PreviousVehicleRotator; // 0x668(0x18)
	bool bHasFrontTurretPassenger; // 0x680(0x01)
	bool bHasRearTurretPassenger; // 0x681(0x01)
	float NetworkEaseRate; // 0x684(0x04)
	float UpdateYawDeltaSmoothedLerpRate; // 0x688(0x04)
	int32_t FrontPassengerSeatIndex; // 0x68c(0x04)
	int32_t RearPassengerSeatIndex; // 0x690(0x04)
	float FrontPassengerYawOffset; // 0x694(0x04)
	float RearPassengerYawOffset; // 0x698(0x04)
	struct FName FrontPassengerBoneName; // 0x69c(0x04)
	struct FName RearPassengerBoneName; // 0x6a0(0x04)
	char pad_6A6[0xa]; // 0x6a6(0x0a)

	float UpdateYawDeltaSmoothed(struct AFortAthenaVehicle* VehicleActor, struct FName SocketName, struct FRotator NewRotation, float SmoothedYawValue); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateYawDeltaSmoothed // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xb6e5ddc
	void UpdateTurretAimPitchWeaponYaw(struct AFortAthenaVehicle* OwnerVehicle, struct AFortPlayerPawn* GunnerActor, struct FName SocketName, float YawOffset, float& TurretAimPitch, float& YawDeltaSmoothed, struct FRotator& WeaponYaw); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateTurretAimPitchWeaponYaw // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb6e58f0
	float UpdateSmoothedVehicleYawRate(struct AFortAthenaVehicle* VehicleActor, struct FRotator PreviousRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateSmoothedVehicleYawRate // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xb6e5708
	void GetPitchAndYaw(struct AFortAthenaVehicle* VehicleActor, struct AFortPlayerPawn* GunnerActor, float& AdjustedPitch, float& AdjustedYaw, bool& bIsLocalPlayerControlled, struct FRotator& YawRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.GetPitchAndYaw // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb6e50d8
};

