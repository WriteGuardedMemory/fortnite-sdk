// BlueprintGeneratedClass B_Ranged_Generic.B_Ranged_Generic_C
// Size: 0x2130 (Inherited: 0x1d68)
struct AB_Ranged_Generic_C : AFortWeaponRanged {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1d68(0x08)
	float AnimateScopePostProcess_DownSightPostProcessAmount_393D8BA5486879173797EF8C9B8D4642; // 0x1d70(0x04)
	enum class ETimelineDirection AnimateScopePostProcess__Direction_393D8BA5486879173797EF8C9B8D4642; // 0x1d74(0x01)
	char pad_1D75[0x3]; // 0x1d75(0x03)
	struct UTimelineComponent* AnimateScopePostProcess; // 0x1d78(0x08)
	struct UNiagaraSystem* OpticGlint; // 0x1d80(0x08)
	bool UseDestroyEffect; // 0x1d88(0x01)
	char pad_1D89[0x7]; // 0x1d89(0x07)
	struct UParticleSystem* WeaponDurabilityDestroyEffect; // 0x1d90(0x08)
	struct UParticleSystem* WeaponDurabilityDestroyEffectIcon; // 0x1d98(0x08)
	bool Use Reload Particles; // 0x1da0(0x01)
	bool UseShellsOnFire?; // 0x1da1(0x01)
	bool UseShellsOnReload?; // 0x1da2(0x01)
	bool UseShellsOnPump?; // 0x1da3(0x01)
	char pad_1DA4[0x4]; // 0x1da4(0x04)
	struct UNiagaraSystem* Shell Burst FX; // 0x1da8(0x08)
	struct UNiagaraSystem* Shell Looping FX; // 0x1db0(0x08)
	struct UNiagaraSystem* Reload_System; // 0x1db8(0x08)
	struct UMaterialInterface* Reload Smoke Material; // 0x1dc0(0x08)
	struct FName ReloadSocketName; // 0x1dc8(0x04)
	struct FGameplayTag TagToApplyOpticGlint; // 0x1dcc(0x04)
	struct TArray<struct AFortAIPawn*> Array Of Active Enemy AI; // 0x1dd0(0x10)
	bool Scope - Render Enemies To Custom Depth Buffer; // 0x1de0(0x01)
	char pad_1DE1[0x3]; // 0x1de1(0x03)
	struct FName Shells Socket Name; // 0x1de4(0x04)
	enum class En_ShellTypes_01 ShellTypeSelect; // 0x1de8(0x01)
	char pad_1DE9[0x7]; // 0x1de9(0x07)
	double Shells Spawn Rate Scale; // 0x1df0(0x08)
	struct FVector ShellsRotationRate; // 0x1df8(0x18)
	struct FVector Shells Velocity; // 0x1e10(0x18)
	struct FVector Shells Gravity; // 0x1e28(0x18)
	struct FVector Shells Size; // 0x1e40(0x18)
	double Target Scope Vignette Blur Screen Percentage; // 0x1e58(0x08)
	double ScopeCameraOffsetX; // 0x1e60(0x08)
	double ScopeCameraOffsetY; // 0x1e68(0x08)
	double Scope Camera Offset Amount; // 0x1e70(0x08)
	double Inherit Parent Velocity; // 0x1e78(0x08)
	double Cylindrical Radius; // 0x1e80(0x08)
	double Cylindrical Height; // 0x1e88(0x08)
	struct FLinearColor Shell Color; // 0x1e90(0x10)
	struct UNiagaraComponent* Spawned_Shells; // 0x1ea0(0x08)
	bool DebugShellsSocket?; // 0x1ea8(0x01)
	char pad_1EA9[0x7]; // 0x1ea9(0x07)
	struct USoundBase* Sound_ScopeZoomIn; // 0x1eb0(0x08)
	struct USoundBase* Sound_ScopeZoomOut; // 0x1eb8(0x08)
	struct UNiagaraComponent* Alteration Ambient PS; // 0x1ec0(0x08)
	struct FGameplayTagContainer ReticleHUDElementTags; // 0x1ec8(0x20)
	bool Is Wind Enabled; // 0x1ee8(0x01)
	char pad_1EE9[0x7]; // 0x1ee9(0x07)
	struct UParticleSystem* MuzzleWindParticleSystem; // 0x1ef0(0x08)
	bool ShouldHideReticleAfterDelay; // 0x1ef8(0x01)
	char pad_1EF9[0x7]; // 0x1ef9(0x07)
	struct UParticleSystemComponent* MuzzleWindParticleSpawned; // 0x1f00(0x08)
	int32_t StencilBufferValue; // 0x1f08(0x04)
	char pad_1F0C[0x4]; // 0x1f0c(0x04)
	struct UCurveFloat* Curve_PitchOffset; // 0x1f10(0x08)
	struct USoundBase* Sound_ScopedInLoop; // 0x1f18(0x08)
	struct UAudioComponent* ScopeZoomInComp; // 0x1f20(0x08)
	struct UAudioComponent* ScopedInLoopComp; // 0x1f28(0x08)
	struct UAudioComponent* ScopeZoomOutComp; // 0x1f30(0x08)
	double Alteration Ambient PS Max Draw Distance; // 0x1f38(0x08)
	double Muzzle PS Max Draw Distance; // 0x1f40(0x08)
	double Beam PS Max Draw Distance; // 0x1f48(0x08)
	double Reload PS Max Draw Distance; // 0x1f50(0x08)
	double Shells PS Max Draw Distance; // 0x1f58(0x08)
	struct FMulticastInlineDelegate onAimDownSightsChanged; // 0x1f60(0x10)
	struct UNiagaraComponent* MuzzleNiagaraComponentInstance; // 0x1f70(0x08)
	struct FTimerHandle ScopeEffectDelay1Handle; // 0x1f78(0x08)
	struct FTimerHandle ScopeEffectDelay2Handle; // 0x1f80(0x08)
	struct FScalableFloat UseUpdatedFeedback; // 0x1f88(0x28)
	struct FMulticastInlineDelegate OnStartFiring; // 0x1fb0(0x10)
	struct FMulticastInlineDelegate OnPersistentFireStopped; // 0x1fc0(0x10)
	struct UStaticMesh* ScopeMesh; // 0x1fd0(0x08)
	struct UStaticMeshComponent* ScopeMesh1P_Spawned; // 0x1fd8(0x08)
	struct TArray<struct UMaterialInterface*> ScopeMaterialOverrides; // 0x1fe0(0x10)
	float Reload Smoke Lifetime; // 0x1ff0(0x04)
	float Reload Smoke Width Scale; // 0x1ff4(0x04)
	struct FLinearColor BaseColorAlpha; // 0x1ff8(0x10)
	bool Use Emissive in Reload; // 0x2008(0x01)
	char pad_2009[0x3]; // 0x2009(0x03)
	struct FLinearColor Reload Emissive Color; // 0x200c(0x10)
	bool Is Rocket Launcher; // 0x201c(0x01)
	char pad_201D[0x3]; // 0x201d(0x03)
	struct FLinearColor Rocket Launcher Spark Color; // 0x2020(0x10)
	bool Reload Ejects Shells; // 0x2030(0x01)
	char pad_2031[0x7]; // 0x2031(0x07)
	struct UNiagaraComponent* OpticGlintComp; // 0x2038(0x08)
	struct UFXSystemAsset* Muzzle System; // 0x2040(0x08)
	float Muzzle Hue Control; // 0x2048(0x04)
	float Muzzle Core Cap Scale; // 0x204c(0x04)
	struct FVector Muzzle Core Scale; // 0x2050(0x18)
	float Spark Amount Scale; // 0x2068(0x04)
	float Smoke Size Scale; // 0x206c(0x04)
	struct FLinearColor MuzzleSmokeInitialColor; // 0x2070(0x10)
	float Smoke Initial Color Scale Variance; // 0x2080(0x04)
	float Smoke Emissive Scale; // 0x2084(0x04)
	bool Use Heated Elements; // 0x2088(0x01)
	char pad_2089[0x3]; // 0x2089(0x03)
	float Decal Size; // 0x208c(0x04)
	struct FVector Decal Offset; // 0x2090(0x18)
	float Decal Alpha; // 0x20a8(0x04)
	char pad_20AC[0x4]; // 0x20ac(0x04)
	struct UFXSystemComponent* Spawned Muzzle System; // 0x20b0(0x08)
	int32_t Burst Loops; // 0x20b8(0x04)
	bool Muzzle_BakedSupressor (Always Suppressed); // 0x20bc(0x01)
	bool Baked Optics (Always has Optics element); // 0x20bd(0x01)
	char pad_20BE[0x2]; // 0x20be(0x02)
	double MinPlayFXTime; // 0x20c0(0x08)
	double LastPlayFXTime; // 0x20c8(0x08)
	struct FScalableFloat UseNativeFX; // 0x20d0(0x28)
	bool bIsLocal; // 0x20f8(0x01)
	char pad_20F9[0x7]; // 0x20f9(0x07)
	struct UNiagaraSystem* Magazine Eject System; // 0x2100(0x08)
	struct FName Magazine Eject Socket Name; // 0x2108(0x04)
	bool Use Magazine Eject; // 0x210c(0x01)
	char pad_210D[0x3]; // 0x210d(0x03)
	struct UMaterialInterface* Magazine Eject Material; // 0x2110(0x08)
	struct UStaticMesh* Magazine Eject Model; // 0x2118(0x08)
	float ScopeEffectDelay1Time; // 0x2120(0x04)
	float ScopeEffectDelay2Time; // 0x2124(0x04)
	bool bUseShellSmoke; // 0x2128(0x01)
	bool Burst Activated Muzzle; // 0x2129(0x01)
	char pad_212A[0x2]; // 0x212a(0x02)
	int32_t MuzzleInt; // 0x212c(0x04)

	void Try Show Reticle(); // Function B_Ranged_Generic.B_Ranged_Generic_C.Try Show Reticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Activate Magazine Eject FX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.Activate Magazine Eject FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void MuzzleModCheck(bool& IsMuzzleBrake, bool& IsMuzzleSupressor, bool& IsMuzzleBreacher); // Function B_Ranged_Generic.B_Ranged_Generic_C.MuzzleModCheck // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void MuzzleADSCheck(bool& Return ADS Bool); // Function B_Ranged_Generic.B_Ranged_Generic_C.MuzzleADSCheck // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ShowOpticGlint(bool AimDownsights); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowOpticGlint // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void StopLocalForceFeedback(struct UForceFeedbackEffect* ForceFeedbackEffect, struct FName tag); // Function B_Ranged_Generic.B_Ranged_Generic_C.StopLocalForceFeedback // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void PlayLocalForceFeedback(struct UForceFeedbackEffect* ForceFeedbackEffect, struct FName tag, bool bLooping); // Function B_Ranged_Generic.B_Ranged_Generic_C.PlayLocalForceFeedback // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void getScopeComp(struct UStaticMeshComponent*& ScopeComponent); // Function B_Ranged_Generic.B_Ranged_Generic_C.getScopeComp // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void initScope(); // Function B_Ranged_Generic.B_Ranged_Generic_C.initScope // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void IsNewFeedbackEnabled(bool& Enabled); // Function B_Ranged_Generic.B_Ranged_Generic_C.IsNewFeedbackEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void LocalReloadStarted(float ReloadTime, enum class EFortWeaponReloadType ReloadType); // Function B_Ranged_Generic.B_Ranged_Generic_C.LocalReloadStarted // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void PlayScopeOutAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.PlayScopeOutAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void GetScopeParameters(struct UStaticMeshComponent*& ScopeComponent, struct FVector2D& DepthOfFieldVignetteRange, struct FVector& WeaponSightsOffset); // Function B_Ranged_Generic.B_Ranged_Generic_C.GetScopeParameters // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void StopScopedAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.StopScopedAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void StartScopedAudio(); // Function B_Ranged_Generic.B_Ranged_Generic_C.StartScopedAudio // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetPostProcessParams(double InputPin); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetPostProcessParams // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetActiveAlterationIdleParticles(bool Active); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetActiveAlterationIdleParticles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ShowReticle(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HideReticle(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideReticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ActivateOrDeactivateWindParticle(bool bNewActive); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateOrDeactivateWindParticle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void DeactivateMuzzleFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.DeactivateMuzzleFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ActivateReloadSmokeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateReloadSmokeFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ActivateShellsFX(bool bool); // Function B_Ranged_Generic.B_Ranged_Generic_C.ActivateShellsFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void DeactivateShellsFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.DeactivateShellsFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetupShellFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetupShellFX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UpdateShellEmittersFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UpdateShellEmittersFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Muzzle Play Reload FX(enum class EFortReloadFXState Selection); // Function B_Ranged_Generic.B_Ranged_Generic_C.Muzzle Play Reload FX // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Muzzle Flash FX(bool Persistent Fire); // Function B_Ranged_Generic.B_Ranged_Generic_C.Muzzle Flash FX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetWpnRarity(); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWpnRarity // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UserConstructionScript(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void AnimateScopePostProcess__FinishedFunc(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AnimateScopePostProcess__FinishedFunc // (BlueprintEvent) // @ game+0x18e3f1c
	void AnimateScopePostProcess__UpdateFunc(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AnimateScopePostProcess__UpdateFunc // (BlueprintEvent) // @ game+0x18e3f1c
	void AnimateScopePostProcess__Toggle Scope__EventFunc(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AnimateScopePostProcess__Toggle Scope__EventFunc // (BlueprintEvent) // @ game+0x18e3f1c
	void OnLoaded_F0DCFB40496C39D956D872BA984FA1F2(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_F0DCFB40496C39D956D872BA984FA1F2 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnLoaded_3A9BBE884A5C5966375089938B7DC0CA(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_3A9BBE884A5C5966375089938B7DC0CA // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnLoaded_83457BA843174AC6288682A342EBEAD9(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_83457BA843174AC6288682A342EBEAD9 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnLoaded_5B08633343C4DA6FF40449A8A36357E4(struct UObject* Loaded); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnLoaded_5B08633343C4DA6FF40449A8A36357E4 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnPlayWeaponFireFX(bool bPersistentFire, bool bSecondaryFire); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnStopWeaponFireFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnStopWeaponFireFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnPlayReloadFX(enum class EFortReloadFXState ReloadStage); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayReloadFX // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetTargeting(bool bNewIsTargeting); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnSetTargeting // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void K2_OnUnEquip(); // Function B_Ranged_Generic.B_Ranged_Generic_C.K2_OnUnEquip // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void InitializeScopeVariables(); // Function B_Ranged_Generic.B_Ranged_Generic_C.InitializeScopeVariables // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Update Enemy Custom Depths(bool Enable Or Disable, int32_t StencilBufferValue); // Function B_Ranged_Generic.B_Ranged_Generic_C.Update Enemy Custom Depths // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnWeaponAttached(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnWeaponAttached // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnInitAlteration(struct UFortAlterationItemDefinition* NewAlteration); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnInitAlteration // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnInitCosmeticAlterations(struct FFortCosmeticModification CosmeticMod); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnInitCosmeticAlterations // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ShellsON_(onPump)(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellsON_(onPump) // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnEquippedWeaponDestory(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnEquippedWeaponDestory // (BlueprintCosmetic|Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void SetWeaponPierceThrough(bool Enable, int32_t TargetLimit); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWeaponPierceThrough // (Net|NetReliableNetServer|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetWeaponPierceThrough_ClientRep(bool Enable, int32_t TargetLimit); // Function B_Ranged_Generic.B_Ranged_Generic_C.SetWeaponPierceThrough_ClientRep // (Net|NetReliableNetClient|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnWeaponVisibilityChanged(bool bVisible, bool bSetForLocalControllerOnly); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnWeaponVisibilityChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void HideWeaponMesh(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideWeaponMesh // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ShowWeaponMesh(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowWeaponMesh // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HideWeapon(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ShowWeapon(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShowWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReverseScopePP(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReverseScopePP // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ResetDoonceScopeSound(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ResetDoonceScopeSound // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UnhideThirdPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideThirdPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void PlayScopePP(); // Function B_Ranged_Generic.B_Ranged_Generic_C.PlayScopePP // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HideFirstPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideFirstPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void AbortScopeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.AbortScopeFX // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void HideThirdPersonStuff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.HideThirdPersonStuff // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UnhideFirstPersonStuffPart2(int32_t Which Call); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideFirstPersonStuffPart2 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UnhideFirstPersonStuffPart1(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UnhideFirstPersonStuffPart1 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ForceScopeFX(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ForceScopeFX // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void BindFireRateChange(); // Function B_Ranged_Generic.B_Ranged_Generic_C.BindFireRateChange // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void PitchUpOnRateOfFireChange(float NewRateOfFire); // Function B_Ranged_Generic.B_Ranged_Generic_C.PitchUpOnRateOfFireChange // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ShellEjectionFixOn(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellEjectionFixOn // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Bind on Effects Quality(); // Function B_Ranged_Generic.B_Ranged_Generic_C.Bind on Effects Quality // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ShellEjectionOff(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ShellEjectionOff // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ForceScopeBackImmediatly(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ForceScopeBackImmediatly // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnPlayImpactFX(struct FHitResult& HitResult, enum class EPhysicalSurface ImpactPhysicalSurface, struct UFXSystemComponent* SpawnedPSC); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPlayImpactFX // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnStartOverheated(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnStartOverheated // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnApplyFireModeData(struct UFortWeaponFireModeData* FireModeData); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnApplyFireModeData // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ScopeEffectDelay2(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ScopeEffectDelay2 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ScopeEffectDelay1(); // Function B_Ranged_Generic.B_Ranged_Generic_C.ScopeEffectDelay1 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ModAddedtoWeapon(struct UFortWeaponModItemDefinition* Mod, struct AFortWeapon* Weapon); // Function B_Ranged_Generic.B_Ranged_Generic_C.ModAddedtoWeapon // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void CancelScopeTargeting(); // Function B_Ranged_Generic.B_Ranged_Generic_C.CancelScopeTargeting // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void UpdateModMagazine(); // Function B_Ranged_Generic.B_Ranged_Generic_C.UpdateModMagazine // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveParticleData(struct TArray<struct FBasicParticleData>& Data, struct UNiagaraSystem* NiagaraSystem, struct FVector& SimulationPositionOffset); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReceiveParticleData // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnWeaponDetached(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnWeaponDetached // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function B_Ranged_Generic.B_Ranged_Generic_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_B_Ranged_Generic(int32_t EntryPoint); // Function B_Ranged_Generic.B_Ranged_Generic_C.ExecuteUbergraph_B_Ranged_Generic // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
	void OnPersistentFireStopped__DelegateSignature(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnPersistentFireStopped__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnStartFiring__DelegateSignature(); // Function B_Ranged_Generic.B_Ranged_Generic_C.OnStartFiring__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void onAimDownSightsChanged__DelegateSignature(bool AimDownsights); // Function B_Ranged_Generic.B_Ranged_Generic_C.onAimDownSightsChanged__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
};

