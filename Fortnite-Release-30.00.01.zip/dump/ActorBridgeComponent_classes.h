// VerseClass ActorBridgeComponent.$SolarisSignatureFunctionOuter
// Size: 0x28 (Inherited: 0x28)
struct U$SolarisSignatureFunctionOuter : UObject {
};

// VerseClass ActorBridgeComponent.ActorBridgeComponent_actor_bridge_component
// Size: 0x208 (Inherited: 0x160)
struct UActorBridgeComponent_actor_bridge_component : UComponent {
	char pad_160[0x40]; // 0x160(0x40)
	struct URestricted_sticky_event* __verse_0x52EA49BD_ActorSpawnFinishedEventInternal; // 0x1a0(0x08)
	char pad_1A8[0x10]; // 0x1a8(0x10)
	OptionalProperty __verse_0x3AB9B23E_SaveRecord; // 0x1b8(0x08)
	VerseFunctionProperty __verse_0x13390F6F_RequestRootActorAsDevice_L_NType_20where_20Type_R; // 0x160(0x10)
	VerseFunctionProperty __verse_0xBC667065__L_2fUnrealEngine_2ecom_2fEntityFramework_2fActorBridgeComponent_2factor__bridge__component_N_RRequestRootActorAsDeviceInternal_L_NType_20where_20Type_R; // 0x170(0x10)
	char pad_1E0[0x28]; // 0x1e0(0x28)

	OptionalProperty _L_2fUnrealEngine_2ecom_2fEntityFramework_2fActorBridgeComponent_2factor__bridge__component_N_RRequestRootActorAsDeviceInternal_L_NType_20where_20Type_R(struct UDevices_creative_device_base* __verse_0xB2CDDD72_Argument); // Function ActorBridgeComponent.ActorBridgeComponent_actor_bridge_component._L_2fUnrealEngine_2ecom_2fEntityFramework_2fActorBridgeComponent_2factor__bridge__component_N_RRequestRootActorAsDeviceInternal_L_NType_20where_20Type_R // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0xd63b784
	struct UConcurrency_task* RequestRootActorAsDevice_L_NType_20where_20Type_R(struct UConcurrency_task* __verse_0xC1E81372_CallingTask, int64_t __verse_0xA3A00DDB_CallerResumeState, int64_t __verse_0x2AC0E4D8_CallerCancelState, struct UDevices_creative_device_base* __verse_0xB2CDDD72_Argument); // Function ActorBridgeComponent.ActorBridgeComponent_actor_bridge_component.RequestRootActorAsDevice_L_NType_20where_20Type_R // (Public|HasOutParms|BlueprintCallable) // @ game+0x18e3f1c
	char _L_2fUnrealEngine_2ecom_2fTemporary_2fSceneGraph_2fcomponent_N_RIsAllowedOnClient(struct Ftuple_L_R __verse_0xB2CDDD72_Argument); // Function ActorBridgeComponent.ActorBridgeComponent_actor_bridge_component._L_2fUnrealEngine_2ecom_2fTemporary_2fSceneGraph_2fcomponent_N_RIsAllowedOnClient // (Public|HasOutParms|BlueprintCallable) // @ game+0x18e3f1c
	void $InitInstance(); // Function ActorBridgeComponent.ActorBridgeComponent_actor_bridge_component.$InitInstance // (None) // @ game+0x18e3f1c
	void $Block(); // Function ActorBridgeComponent.ActorBridgeComponent_actor_bridge_component.$Block // (None) // @ game+0x18e3f1c
	void $InitCDO(); // Function ActorBridgeComponent.ActorBridgeComponent_actor_bridge_component.$InitCDO // (HasDefaults) // @ game+0x18e3f1c
};

// VerseClass ActorBridgeComponent.task_ActorBridgeComponent_actor_bridge_component$RequestRootActorAsDevice_L_NType_20where_20Type_R
// Size: 0x21d (Inherited: 0x158)
struct Utask_ActorBridgeComponent_actor_bridge_component$RequestRootActorAsDevice_L_NType_20where_20Type_R : UConcurrency_task {
	struct UActorBridgeComponent_actor_bridge_component* _Self; // 0x158(0x08)
	struct UDevices_creative_device_base* __verse_0xB2CDDD72_Argument; // 0x160(0x08)
	OptionalProperty _RetVal; // 0x168(0x08)
	struct URestricted_sticky_event* ; // 0x170(0x08)
	struct UConcurrency_task* ; // 0x178(0x08)
	VerseFunctionProperty ; // 0x180(0x10)
	struct Ftuple_L_R ; // 0x190(0x01)
	char pad_191[0x7]; // 0x191(0x07)
	int64_t ; // 0x198(0x08)
	struct UDevices_creative_device_base* ; // 0x1a0(0x08)
	OptionalProperty ; // 0x1a8(0x08)
	VerseFunctionProperty ; // 0x1b0(0x10)
	OptionalProperty ; // 0x1c0(0x02)
	char  : 1; // 0x1c2(0x01)
	char pad_1C2_1 : 7; // 0x1c2(0x01)
	OptionalProperty ; // 0x1c3(0x02)
	char pad_1C5[0x3]; // 0x1c5(0x03)
	struct URestricted_sticky_event* ; // 0x1c8(0x08)
	struct UConcurrency_task* ; // 0x1d0(0x08)
	VerseFunctionProperty ; // 0x1d8(0x10)
	struct Ftuple_L_R ; // 0x1e8(0x01)
	char pad_1E9[0x7]; // 0x1e9(0x07)
	int64_t ; // 0x1f0(0x08)
	struct UDevices_creative_device_base* ; // 0x1f8(0x08)
	OptionalProperty ; // 0x200(0x08)
	VerseFunctionProperty ; // 0x208(0x10)
	OptionalProperty ; // 0x218(0x02)
	char  : 1; // 0x21a(0x01)
	char pad_21A_1 : 7; // 0x21a(0x01)
	OptionalProperty ; // 0x21b(0x02)

	int64_t Update(); // Function ActorBridgeComponent.task_ActorBridgeComponent_actor_bridge_component$RequestRootActorAsDevice_L_NType_20where_20Type_R.Update // (Public|HasOutParms) // @ game+0x18e3f1c
};

