// Class CinematicCamera.CameraRig_Crane
// Size: 0x2c0 (Inherited: 0x290)
struct ACameraRig_Crane : AActor {
	float CranePitch; // 0x290(0x04)
	float CraneYaw; // 0x294(0x04)
	float CraneArmLength; // 0x298(0x04)
	bool bLockMountPitch; // 0x29c(0x01)
	bool bLockMountYaw; // 0x29d(0x01)
	char pad_29E[0x2]; // 0x29e(0x02)
	struct USceneComponent* TransformComponent; // 0x2a0(0x08)
	struct USceneComponent* CraneYawControl; // 0x2a8(0x08)
	struct USceneComponent* CranePitchControl; // 0x2b0(0x08)
	struct USceneComponent* CraneCameraMount; // 0x2b8(0x08)
};

// Class CinematicCamera.CameraRig_Rail
// Size: 0x2b0 (Inherited: 0x290)
struct ACameraRig_Rail : AActor {
	float CurrentPositionOnRail; // 0x290(0x04)
	bool bLockOrientationToRail; // 0x294(0x01)
	char pad_295[0x3]; // 0x295(0x03)
	struct USceneComponent* TransformComponent; // 0x298(0x08)
	struct USplineComponent* RailSplineComponent; // 0x2a0(0x08)
	struct USceneComponent* RailCameraMount; // 0x2a8(0x08)

	struct USplineComponent* GetRailSplineComponent(); // Function CinematicCamera.CameraRig_Rail.GetRailSplineComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x6800fe8
};

// Class CinematicCamera.CineCameraActor
// Size: 0xa20 (Inherited: 0x9b0)
struct ACineCameraActor : ACameraActor {
	struct FCameraLookatTrackingSettings LookatTrackingSettings; // 0x9b0(0x60)
	char pad_A10[0x10]; // 0xa10(0x10)

	struct UCineCameraComponent* GetCineCameraComponent(); // Function CinematicCamera.CineCameraActor.GetCineCameraComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67fd4dc
};

// Class CinematicCamera.CineCameraComponent
// Size: 0xae0 (Inherited: 0x9d0)
struct UCineCameraComponent : UCameraComponent {
	struct FCameraFilmbackSettings FilmbackSettings; // 0x9d0(0x0c)
	struct FCameraFilmbackSettings Filmback; // 0x9dc(0x0c)
	struct FCameraLensSettings LensSettings; // 0x9e8(0x1c)
	char pad_A04[0x4]; // 0xa04(0x04)
	struct FCameraFocusSettings FocusSettings; // 0xa08(0x58)
	struct FPlateCropSettings CropSettings; // 0xa60(0x04)
	float CurrentFocalLength; // 0xa64(0x04)
	float CurrentAperture; // 0xa68(0x04)
	float CurrentFocusDistance; // 0xa6c(0x04)
	char bOverride_CustomNearClippingPlane : 1; // 0xa70(0x01)
	char pad_A70_1 : 7; // 0xa70(0x01)
	char pad_A71[0x3]; // 0xa71(0x03)
	float CustomNearClippingPlane; // 0xa74(0x04)
	char pad_A78[0x8]; // 0xa78(0x08)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0xa80(0x10)
	struct TArray<struct FNamedLensPreset> LensPresets; // 0xa90(0x10)
	struct FString DefaultFilmbackPresetName; // 0xaa0(0x10)
	struct FString DefaultFilmbackPreset; // 0xab0(0x10)
	struct FString DefaultLensPresetName; // 0xac0(0x10)
	float DefaultLensFocalLength; // 0xad0(0x04)
	float DefaultLensFStop; // 0xad4(0x04)
	char pad_AD8[0x8]; // 0xad8(0x08)

	void SetLensSettings(struct FCameraLensSettings& NewLensSettings); // Function CinematicCamera.CineCameraComponent.SetLensSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x68050f8
	void SetLensPresetByName(struct FString InPresetName); // Function CinematicCamera.CineCameraComponent.SetLensPresetByName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x680429c
	void SetFocusSettings(struct FCameraFocusSettings& NewFocusSettings); // Function CinematicCamera.CineCameraComponent.SetFocusSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x68041ec
	void SetFilmbackPresetByName(struct FString InPresetName); // Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6803390
	void SetFilmback(struct FCameraFilmbackSettings& NewFilmback); // Function CinematicCamera.CineCameraComponent.SetFilmback // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x68032e0
	void SetCustomNearClippingPlane(float NewCustomNearClippingPlane); // Function CinematicCamera.CineCameraComponent.SetCustomNearClippingPlane // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6801a5c
	void SetCurrentFocalLength(float InFocalLength); // Function CinematicCamera.CineCameraComponent.SetCurrentFocalLength // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6801990
	void SetCurrentAperture(float NewCurrentAperture); // Function CinematicCamera.CineCameraComponent.SetCurrentAperture // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x68018c4
	void SetCropSettings(struct FPlateCropSettings& NewCropSettings); // Function CinematicCamera.CineCameraComponent.SetCropSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x680182c
	void SetCropPresetByName(struct FString InPresetName); // Function CinematicCamera.CineCameraComponent.SetCropPresetByName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x6801028
	float GetVerticalFieldOfView(); // Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6801000
	struct TArray<struct FNamedLensPreset> GetLensPresetsCopy(); // Function CinematicCamera.CineCameraComponent.GetLensPresetsCopy // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x68008d8
	struct FString GetLensPresetName(); // Function CinematicCamera.CineCameraComponent.GetLensPresetName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x680085c
	float GetHorizontalFieldOfView(); // Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6800098
	struct TArray<struct FNamedFilmbackPreset> GetFilmbackPresetsCopy(); // Function CinematicCamera.CineCameraComponent.GetFilmbackPresetsCopy // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x67ff988
	struct FString GetFilmbackPresetName(); // Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67ff240
	struct FString GetDefaultFilmbackPresetName(); // Function CinematicCamera.CineCameraComponent.GetDefaultFilmbackPresetName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67fe3dc
	struct FString GetCropPresetName(); // Function CinematicCamera.CineCameraComponent.GetCropPresetName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67fdc9c
};

// Class CinematicCamera.CineCameraSettings
// Size: 0xa8 (Inherited: 0x30)
struct UCineCameraSettings : UDeveloperSettings {
	struct FString DefaultLensPresetName; // 0x30(0x10)
	float DefaultLensFocalLength; // 0x40(0x04)
	float DefaultLensFStop; // 0x44(0x04)
	struct TArray<struct FNamedLensPreset> LensPresets; // 0x48(0x10)
	struct FString DefaultFilmbackPreset; // 0x58(0x10)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0x68(0x10)
	struct FString DefaultCropPresetName; // 0x78(0x10)
	struct TArray<struct FNamedPlateCropPreset> CropPresets; // 0x88(0x10)
	char pad_98[0x10]; // 0x98(0x10)

	void SetLensPresets(struct TArray<struct FNamedLensPreset>& InLensPresets); // Function CinematicCamera.CineCameraSettings.SetLensPresets // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x68049e0
	void SetFilmbackPresets(struct TArray<struct FNamedFilmbackPreset>& InFilmbackPresets); // Function CinematicCamera.CineCameraSettings.SetFilmbackPresets // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x6803ad4
	void SetDefaultLensPresetName(struct FString InDefaultLensPresetName); // Function CinematicCamera.CineCameraSettings.SetDefaultLensPresetName // (Final|Native|Private|BlueprintCallable) // @ game+0x6802b88
	void SetDefaultLensFStop(float InDefaultLensFStop); // Function CinematicCamera.CineCameraSettings.SetDefaultLensFStop // (Final|Native|Private|BlueprintCallable) // @ game+0x68029d0
	void SetDefaultLensFocalLength(float InDefaultLensFocalLength); // Function CinematicCamera.CineCameraSettings.SetDefaultLensFocalLength // (Final|Native|Private|BlueprintCallable) // @ game+0x6802aac
	void SetDefaultFilmbackPreset(struct FString InDefaultFilmbackPreset); // Function CinematicCamera.CineCameraSettings.SetDefaultFilmbackPreset // (Final|Native|Private|BlueprintCallable) // @ game+0x6802278
	void SetDefaultCropPresetName(struct FString InDefaultCropPresetName); // Function CinematicCamera.CineCameraSettings.SetDefaultCropPresetName // (Final|Native|Private|BlueprintCallable) // @ game+0x6801b20
	void SetCropPresets(struct TArray<struct FNamedPlateCropPreset>& InCropPresets); // Function CinematicCamera.CineCameraSettings.SetCropPresets // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x6801774
	struct TArray<struct FString> GetLensPresetNames(); // Function CinematicCamera.CineCameraSettings.GetLensPresetNames // (Final|Native|Private|Const) // @ game+0x680089c
	bool GetLensPresetByName(struct FString PresetName, struct FCameraLensSettings& LensSettings); // Function CinematicCamera.CineCameraSettings.GetLensPresetByName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x68000c0
	struct TArray<struct FString> GetFilmbackPresetNames(); // Function CinematicCamera.CineCameraSettings.GetFilmbackPresetNames // (Final|Native|Private|Const) // @ game+0x67ff94c
	bool GetFilmbackPresetByName(struct FString PresetName, struct FCameraFilmbackSettings& FilmbackSettings); // Function CinematicCamera.CineCameraSettings.GetFilmbackPresetByName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67feab4
	struct TArray<struct FString> GetCropPresetNames(); // Function CinematicCamera.CineCameraSettings.GetCropPresetNames // (Final|Native|Private|Const) // @ game+0x67fe3a0
	bool GetCropPresetByName(struct FString PresetName, struct FPlateCropSettings& CropSettings); // Function CinematicCamera.CineCameraSettings.GetCropPresetByName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67fd524
	struct UCineCameraSettings* GetCineCameraSettings(); // Function CinematicCamera.CineCameraSettings.GetCineCameraSettings // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x67fd4f4
};

