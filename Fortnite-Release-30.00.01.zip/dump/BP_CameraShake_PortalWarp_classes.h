// BlueprintGeneratedClass BP_CameraShake_PortalWarp.BP_CameraShake_PortalWarp_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UBP_CameraShake_PortalWarp_C : ULegacyCameraShake {
};

