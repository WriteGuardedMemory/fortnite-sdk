// BlueprintGeneratedClass Border-TabM-Solid.Border-TabM-Solid_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-TabM-Solid_C : UBorder-TabM_C {
};

