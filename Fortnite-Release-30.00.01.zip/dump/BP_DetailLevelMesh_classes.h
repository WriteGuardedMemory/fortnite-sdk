// BlueprintGeneratedClass BP_DetailLevelMesh.BP_DetailLevelMesh_C
// Size: 0x2aa (Inherited: 0x290)
struct ABP_DetailLevelMesh_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x298(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2a0(0x08)
	bool AlwaysVisible; // 0x2a8(0x01)
	bool NotVisibleOnSwitch; // 0x2a9(0x01)

	void ExecuteUbergraph_BP_DetailLevelMesh(int32_t EntryPoint); // Function BP_DetailLevelMesh.BP_DetailLevelMesh_C.ExecuteUbergraph_BP_DetailLevelMesh // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

