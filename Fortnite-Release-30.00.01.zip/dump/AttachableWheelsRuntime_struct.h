// ScriptStruct AttachableWheelsRuntime.AttachableWheelAttachData
// Size: 0x58 (Inherited: 0x00)
struct FAttachableWheelAttachData {
	struct TWeakObjectPtr<struct UPrimitiveComponent> PrimitiveComponent; // 0x00(0x08)
	struct FVector Pos; // 0x08(0x18)
	struct FVector Axis1; // 0x20(0x18)
	struct FVector Axis2; // 0x38(0x18)
	float Damping; // 0x50(0x04)
	struct FName AttachmentName; // 0x54(0x04)
};

// ScriptStruct AttachableWheelsRuntime.AttachableWheelRuntimeData
// Size: 0x0c (Inherited: 0x00)
struct FAttachableWheelRuntimeData {
	float Torque; // 0x00(0x04)
	float Velocity; // 0x04(0x04)
	float SteerAngle; // 0x08(0x04)
};

