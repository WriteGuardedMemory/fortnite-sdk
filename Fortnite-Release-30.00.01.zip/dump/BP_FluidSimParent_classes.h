// BlueprintGeneratedClass BP_FluidSimParent.BP_FluidSimParent_C
// Size: 0x298 (Inherited: 0x290)
struct ABP_FluidSimParent_C : AActor {
	struct USceneComponent* DefaultSceneRoot; // 0x290(0x08)

	void GetNormalRT(struct UTextureRenderTarget2D*& RT); // Function BP_FluidSimParent.BP_FluidSimParent_C.GetNormalRT // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
};

