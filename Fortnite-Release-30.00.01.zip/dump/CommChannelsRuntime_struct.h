// ScriptStruct CommChannelsRuntime.CommChannelNode
// Size: 0x68 (Inherited: 0x00)
struct FCommChannelNode {
	char pad_0[0x68]; // 0x00(0x68)
};

