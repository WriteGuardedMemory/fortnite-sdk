// BlueprintGeneratedClass BP_PhoebePlayerController.BP_PhoebePlayerController_C
// Size: 0x1720 (Inherited: 0x1700)
struct ABP_PhoebePlayerController_C : AFortAthenaAIBotController {
	struct UFortControllerComponent_RechargeWeapons* RechargingWeaponsComponent; // 0x1700(0x08)
	struct UFortBlackboardComponent* Blackboard1; // 0x1708(0x08)
	struct UFortAthenaAIBotBuildingComponent* FortAthenaAIBotBuilding; // 0x1710(0x08)
	struct UAIPerceptionComponent* AIPerception; // 0x1718(0x08)
};

