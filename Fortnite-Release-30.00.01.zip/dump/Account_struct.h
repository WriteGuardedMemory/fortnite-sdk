// Enum Account.EExternalAccountType
enum class EExternalAccountType : uint8 {
	None = 0,
	Facebook = 1,
	Google = 2,
	Epic_PSN = 3,
	Epic_XBL = 4,
	Epic_Erebus = 5,
	Epic_Facebook = 6,
	Epic_Google = 7,
	Epic_Portal = 8,
	EExternalAccountType_MAX = 9
};

// Enum Account.EConsoleAuthLinkState
enum class EConsoleAuthLinkState : uint8 {
	NotOnConsole = 0,
	ConsoleNotLoggedIn = 1,
	EpicNotLoggedIn = 2,
	ThisEpicAccountLinked = 3,
	OtherEpicAccountLinked = 4,
	NoEpicAccountLinked = 5,
	PrimaryIdNotLinked = 6,
	SecondaryIdNotLinked = 7,
	EConsoleAuthLinkState_MAX = 8
};

// Enum Account.ELoginResult
enum class ELoginResult : uint8 {
	NotStarted = 0,
	Pending = 1,
	Success = 2,
	Console_LoginFailed = 3,
	Console_AuthFailed = 4,
	Console_MissingAuthAssociation = 5,
	Console_DuplicateAuthAssociation = 6,
	Console_AddedAuthAssociation = 7,
	Console_AuthAssociationFailure = 8,
	Console_NotEntitled = 9,
	Console_EntitlementCheckFailed = 10,
	Console_PrivilegeCheck = 11,
	Console_PatchOrUpdateRequired = 12,
	AuthFailed = 13,
	AuthFailed_RefreshInvalid = 14,
	AuthFailed_InvalidMFA = 15,
	AuthFailed_RequiresMFA = 16,
	AuthFailed_AgeVerificationIncomplete = 17,
	AuthFailed_LoginLockout = 18,
	AuthFailed_InvalidCredentials = 19,
	AuthFailed_CorrectiveActionRequired = 20,
	AuthParentalLock = 21,
	PlatformNotAllowed = 22,
	NotEntitled = 23,
	Banned = 24,
	EULACheckFailed = 25,
	EULADeclined = 26,
	WaitingRoomFailed = 27,
	ServiceUnavailable = 28,
	GenericError = 29,
	RegisterSecondaryPlayerInPrimaryPartyFailed = 30,
	RejoinCheckFailure = 31,
	ConnectionFailed = 32,
	NetworkConnectionUnavailable = 33,
	AlreadyLoggingIn = 34,
	ExternalAuth_AddedAuthAssociation = 35,
	ExternalAuth_ConnectionTimeout = 36,
	ExternalAuth_AuthFailure = 37,
	ExternalAuth_AssociationFailure = 38,
	ExternalAuth_MissingAuthAssociation = 39,
	ExternalAuth_Canceled = 40,
	FailedToCreateParty = 41,
	ProfileQueryFailed = 42,
	QueryKeychainFailed = 43,
	ClientSettingsDownloadFailed = 44,
	SupervisedSettingsDownloadFailed = 45,
	PinGrantFailure = 46,
	PinGrantTimeout = 47,
	PinGrantCanceled = 48,
	LoginStepTimeout = 49,
	Console_LoginCanceled = 50,
	ELoginResult_MAX = 51
};

// Enum Account.ECreateAccountResult
enum class ECreateAccountResult : uint8 {
	NotStarted = 0,
	Pending = 1,
	Success = 2,
	Console_LoginFailed = 3,
	Console_DuplicateAuthAssociation = 4,
	DuplicateAccount = 5,
	GenericError = 6,
	ECreateAccountResult_MAX = 7
};

// ScriptStruct Account.WebEnvUrl
// Size: 0x30 (Inherited: 0x00)
struct FWebEnvUrl {
	struct FString URL; // 0x00(0x10)
	struct FString RedirectUrl; // 0x10(0x10)
	struct FString Environment; // 0x20(0x10)
};

// ScriptStruct Account.ExternalAccountServiceConfig
// Size: 0x08 (Inherited: 0x00)
struct FExternalAccountServiceConfig {
	enum class EExternalAccountType Type; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName ExternalServiceName; // 0x04(0x04)
};

// ScriptStruct Account.ExchangeAccessParams
// Size: 0x40 (Inherited: 0x00)
struct FExchangeAccessParams {
	struct FString EntitlementId; // 0x00(0x10)
	struct FString ReceiptId; // 0x10(0x10)
	struct FString VendorReceipt; // 0x20(0x10)
	struct FString AppStore; // 0x30(0x10)
};

// ScriptStruct Account.GiftMessage
// Size: 0x30 (Inherited: 0x00)
struct FGiftMessage {
	struct FString GiftCode; // 0x00(0x10)
	struct FString SenderName; // 0x10(0x10)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct Account.ServiceLoginMethodConfig
// Size: 0x05 (Inherited: 0x00)
struct FServiceLoginMethodConfig {
	bool bAutologinEnabled; // 0x00(0x01)
	bool bPrimaryPlatformTokenEnabled; // 0x01(0x01)
	bool bSecondaryPlatformTokenEnabled; // 0x02(0x01)
	bool bAccountPortalEnabled; // 0x03(0x01)
	bool bPersistentTokenEnabled; // 0x04(0x01)
};

// ScriptStruct Account.OnlineAccountTexts_FailedLoginConsole
// Size: 0xf0 (Inherited: 0x00)
struct FOnlineAccountTexts_FailedLoginConsole {
	struct FText AgeRestriction; // 0x00(0x10)
	struct FText Generic; // 0x10(0x10)
	struct FText MissingAuthAssociation; // 0x20(0x10)
	struct FText NeedPremiumAccount; // 0x30(0x10)
	struct FText OnlinePlayRestriction; // 0x40(0x10)
	struct FText PatchAvailable; // 0x50(0x10)
	struct FText PatchAvailableInstruction_Default; // 0x60(0x10)
	struct FText PatchAvailableInstruction_Xbox; // 0x70(0x10)
	struct FText PleaseSignIn; // 0x80(0x10)
	struct FText SystemUpdateAvailable; // 0x90(0x10)
	struct FText UI; // 0xa0(0x10)
	struct FText UnableToComplete; // 0xb0(0x10)
	struct FText UnableToSignIn; // 0xc0(0x10)
	struct FText UnableToStartPrivCheck; // 0xd0(0x10)
	struct FText UnexpectedError; // 0xe0(0x10)
};

// ScriptStruct Account.OnlineAccountTexts
// Size: 0x660 (Inherited: 0x00)
struct FOnlineAccountTexts {
	struct FText AllGiftCodesUsed; // 0x00(0x10)
	struct FText AssociateConsoleAuth; // 0x10(0x10)
	struct FText AutoLoginFailed; // 0x20(0x10)
	struct FText AutoLoginFailedMobile; // 0x30(0x10)
	struct FText BannedFromGame; // 0x40(0x10)
	struct FText CheckEntitledToPlay; // 0x50(0x10)
	struct FText CheckingRejoin; // 0x60(0x10)
	struct FText CheckServiceAvailability; // 0x70(0x10)
	struct FText ConsolePrivileges; // 0x80(0x10)
	struct FText CreateAccountCompleted; // 0x90(0x10)
	struct FText CreateAccountFailure; // 0xa0(0x10)
	struct FText CreateHeadless; // 0xb0(0x10)
	struct FText DoQosPingTests; // 0xc0(0x10)
	struct FText DowntimeMinutesWarningText; // 0xd0(0x10)
	struct FText DowntimeSecondsWarningText; // 0xe0(0x10)
	struct FText DuplicateAuthAssociaton; // 0xf0(0x10)
	struct FText EulaCheck; // 0x100(0x10)
	struct FText ExchangeConsoleGiftsForAccess; // 0x110(0x10)
	struct FText FailedAccountCreate; // 0x120(0x10)
	struct FText FailedEulaCheck_EulaAcceptanceFailed; // 0x130(0x10)
	struct FText FailedEulaCheck_MustAcceptEula; // 0x140(0x10)
	struct FText FailedLoginCredentialsMsg; // 0x150(0x10)
	struct FText FailedLoginAgeVerificationIncomplete; // 0x160(0x10)
	struct FText FailedLoginParentalLock; // 0x170(0x10)
	struct FText FailedLoginNoRealId; // 0x180(0x10)
	struct FText FailedLoginLockoutMsg; // 0x190(0x10)
	struct FText FailedLoginRequiresMFA; // 0x1a0(0x10)
	struct FText FailedLoginRequiresAuthAppMFA; // 0x1b0(0x10)
	struct FText FailedInvalidMFA; // 0x1c0(0x10)
	struct FText FailedLoginRequiresCorrectiveAction; // 0x1d0(0x10)
	struct FText FailedLoginMsg; // 0x1e0(0x10)
	struct FText FailedLoginMsg_InvalidRefreshToken; // 0x1f0(0x10)
	struct FText FailedStartLogin; // 0x200(0x10)
	struct FText FounderChatExitedText; // 0x210(0x10)
	struct FText FounderChatJoinedText; // 0x220(0x10)
	struct FText GameDisplayName; // 0x230(0x10)
	struct FText GeneralLoginFailure; // 0x240(0x10)
	struct FText GlobalChatExitedText; // 0x250(0x10)
	struct FText GlobalChatJoinedText; // 0x260(0x10)
	struct FText HeadlessAccountFailed; // 0x270(0x10)
	struct FText InMatchShutdownTimeWarningText; // 0x280(0x10)
	struct FText InvalidUser; // 0x290(0x10)
	struct FText LoggedOutofMCP; // 0x2a0(0x10)
	struct FText DisconnectedFromMCP; // 0x2b0(0x10)
	struct FText LoggedOutReturnedToTitle; // 0x2c0(0x10)
	struct FText LoggedOutSwitchedProfile; // 0x2d0(0x10)
	struct FText LoggingIn; // 0x2e0(0x10)
	struct FText LoggingInConsoleAuth; // 0x2f0(0x10)
	struct FText LoggingOut; // 0x300(0x10)
	struct FText LoginConsole; // 0x310(0x10)
	struct FText LoginFailure; // 0x320(0x10)
	struct FText Logout_Unlink; // 0x330(0x10)
	struct FText LogoutCompleted; // 0x340(0x10)
	struct FText LostConnection; // 0x350(0x10)
	struct FText LoginStepTimeout; // 0x360(0x10)
	struct FText MCPTimeout; // 0x370(0x10)
	struct FText LightswitchCheckNetworkFailureMsg; // 0x380(0x10)
	struct FText NetworkConnectionUnavailable; // 0x390(0x10)
	struct FText NoPlayEntitlement; // 0x3a0(0x10)
	struct FText NoServerAccess; // 0x3b0(0x10)
	struct FText PlayAccessRevoked; // 0x3c0(0x10)
	struct FText PremiumAccountName_Default; // 0x3d0(0x10)
	struct FText PremiumAccountName_Sony; // 0x3e0(0x10)
	struct FText PremiumAccountName_Switch; // 0x3f0(0x10)
	struct FText PremiumAccountName_XboxOne; // 0x400(0x10)
	struct FText RedeemOfflinePurchases; // 0x410(0x10)
	struct FText ServiceDowntime; // 0x420(0x10)
	struct FText SignInCompleting; // 0x430(0x10)
	struct FText SignIntoConsoleServices; // 0x440(0x10)
	struct FText TokenExpired; // 0x450(0x10)
	struct FText UnableToConnect; // 0x460(0x10)
	struct FText UnableToJoinWaitingRoomLoginQueue; // 0x470(0x10)
	struct FText UnexpectedConsoleAuthFailure; // 0x480(0x10)
	struct FText UnlinkConsoleFailed; // 0x490(0x10)
	struct FText UserLoginFailed; // 0x4a0(0x10)
	struct FText WaitingRoom; // 0x4b0(0x10)
	struct FText WaitingRoomError; // 0x4c0(0x10)
	struct FText WaitingRoomFailure; // 0x4d0(0x10)
	struct FText WaitingRoomWaiting; // 0x4e0(0x10)
	struct FOnlineAccountTexts_FailedLoginConsole FailedLoginConsole; // 0x4f0(0xf0)
	struct FText LoggingInExternalAuth; // 0x5e0(0x10)
	struct FText CreateDeviceAuth; // 0x5f0(0x10)
	struct FText ExtAuthCanceled; // 0x600(0x10)
	struct FText ExtAuthFailure; // 0x610(0x10)
	struct FText ExtAuthAssociationFailure; // 0x620(0x10)
	struct FText ExtAuthTimeout; // 0x630(0x10)
	struct FText ExtAuthMissingAuthAssociation; // 0x640(0x10)
	struct FText UnableToQueryReceipts; // 0x650(0x10)
};

