// BlueprintGeneratedClass Athena_PlayerCameraMode_Interrogation_Map.Athena_PlayerCameraMode_Interrogation_Map_C
// Size: 0x1cd0 (Inherited: 0x1cd0)
struct UAthena_PlayerCameraMode_Interrogation_Map_C : UAthena_PlayerCameraModeBase_C {
};

