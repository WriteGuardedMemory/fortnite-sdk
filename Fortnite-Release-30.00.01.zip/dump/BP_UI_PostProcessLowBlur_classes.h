// BlueprintGeneratedClass BP_UI_PostProcessLowBlur.BP_UI_PostProcessLowBlur_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_UI_PostProcessLowBlur_C : USlatePostBufferBlur {
};

