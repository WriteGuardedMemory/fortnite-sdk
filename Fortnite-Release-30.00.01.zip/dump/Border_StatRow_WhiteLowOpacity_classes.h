// BlueprintGeneratedClass Border_StatRow_WhiteLowOpacity.Border_StatRow_WhiteLowOpacity_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder_StatRow_WhiteLowOpacity_C : UCommonBorderStyle {
};

