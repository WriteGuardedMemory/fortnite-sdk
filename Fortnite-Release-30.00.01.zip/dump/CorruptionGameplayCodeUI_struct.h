// Enum CorruptionGameplayCodeUI.EPowerupHeatState
enum class EPowerupHeatState : uint8 {
	Normal = 0,
	Superheated = 1,
	Overheated = 2,
	EPowerupHeatState_MAX = 3
};

