// BlueprintGeneratedClass BP_ProjectileTrajectorySplineMesh.BP_ProjectileTrajectorySplineMesh_C
// Size: 0x710 (Inherited: 0x710)
struct UBP_ProjectileTrajectorySplineMesh_C : USplineMeshComponent {
};

