// WidgetBlueprintGeneratedClass AccountNotFound.AccountNotFound_C
// Size: 0x560 (Inherited: 0x558)
struct UAccountNotFound_C : UFortAccountNotFound {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x558(0x08)

	void BndEvt__AccountNotFound_Button_Back_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function AccountNotFound.AccountNotFound_C.BndEvt__AccountNotFound_Button_Back_K2Node_ComponentBoundEvent_0_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__AccountNotFound_Button_Web_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function AccountNotFound.AccountNotFound_C.BndEvt__AccountNotFound_Button_Web_K2Node_ComponentBoundEvent_1_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_AccountNotFound(int32_t EntryPoint); // Function AccountNotFound.AccountNotFound_C.ExecuteUbergraph_AccountNotFound // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

