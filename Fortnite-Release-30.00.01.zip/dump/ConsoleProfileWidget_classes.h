// WidgetBlueprintGeneratedClass ConsoleProfileWidget.ConsoleProfileWidget_C
// Size: 0x2d0 (Inherited: 0x2d0)
struct UConsoleProfileWidget_C : UFortConsoleProfileWidget {
};

