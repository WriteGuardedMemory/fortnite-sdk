// Class BattlePassS30UI.BattlePassBulkBuyPageS30
// Size: 0x598 (Inherited: 0x598)
struct UBattlePassBulkBuyPageS30 : UFortBattlePassBulkBuyPageBase {
};

// Class BattlePassS30UI.BattlePassLandingPageS30
// Size: 0x5b8 (Inherited: 0x550)
struct UBattlePassLandingPageS30 : UBattlePassLandingPageBase {
	struct UBattlePassLandingPageButton* Button_Rewards; // 0x550(0x08)
	struct UBattlePassLandingPageButton* Button_CharacterCustomizer; // 0x558(0x08)
	struct UBattlePassLandingPageButton* Button_BonusRewards; // 0x560(0x08)
	struct UBattlePassLandingPageButton* Button_Quests; // 0x568(0x08)
	struct UBattlePassLandingPageButton* Button_JoinSubscription; // 0x570(0x08)
	struct UBattlePassLandingPageButton* Button_WeeklyRewards; // 0x578(0x08)
	struct UCommonTextBlock* Text_SeasonNumber; // 0x580(0x08)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0x588(0x08)
	char pad_590[0x28]; // 0x590(0x28)

	void OnBattlePassSubscriptionAllowed(bool bSubscriptionAllowed); // Function BattlePassS30UI.BattlePassLandingPageS30.OnBattlePassSubscriptionAllowed // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
};

// Class BattlePassS30UI.BattlePassRewardPageS30
// Size: 0x5b0 (Inherited: 0x510)
struct UBattlePassRewardPageS30 : UBattlePassRewardPageBase {
	struct UFortBattlePassRewardTrack* RewardsTrackClass; // 0x510(0x08)
	struct UFortBattlePassTile* FocusedReward; // 0x518(0x08)
	struct TArray<struct UFortBattlePassRewardTrack*> TrackPages; // 0x520(0x10)
	char pad_530[0x4]; // 0x530(0x04)
	enum class ERewardPageType RewardPageType; // 0x534(0x01)
	char pad_535[0x3]; // 0x535(0x03)
	int32_t HoldTileTooltip_ClaimedRewardsToHide; // 0x538(0x04)
	int32_t HoldTileTooltip_ClaimedBattlePassToHide; // 0x53c(0x04)
	int32_t HoldTileTooltip_RequiredBattleStarsToShow; // 0x540(0x04)
	int32_t LevelRequirementUnlockTooltip_RequiredLevel; // 0x544(0x04)
	int32_t ClaimAllRewardsTooltip_RequiredLevelToShow; // 0x548(0x04)
	char pad_54C[0x4]; // 0x54c(0x04)
	struct UCommonAnimatedSwitcher* Switcher_RewardTracks; // 0x550(0x08)
	struct UFortBattlePassTutorialTooltipS30* TutorialTooltip_LevelRequirementUnlock; // 0x558(0x08)
	struct UFortBattlePassTutorialTooltipS30* TutorialTooltip_ClaimAllRewards; // 0x560(0x08)
	struct UFortBattlePassTutorialTooltipS30* TutorialTooltip_HoldTile; // 0x568(0x08)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0x570(0x08)
	struct UBattlePassBulkBuyInputData* BulkBuyInputData; // 0x578(0x08)
	struct UCommonButtonBase* Button_NextPage; // 0x580(0x08)
	struct UCommonButtonBase* Button_PreviousPage; // 0x588(0x08)
	char pad_590[0x20]; // 0x590(0x20)

	void OnPageChanged(int32_t PageNumber, int32_t RewardPageTotal); // Function BattlePassS30UI.BattlePassRewardPageS30.OnPageChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnLoadingScreenSelectedChanged(bool bIsSelected); // Function BattlePassS30UI.BattlePassRewardPageS30.OnLoadingScreenSelectedChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnInputMethodChanged(enum class ECommonInputType InputType); // Function BattlePassS30UI.BattlePassRewardPageS30.OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnInitForPageType(enum class ERewardPageType InRewardPageType); // Function BattlePassS30UI.BattlePassRewardPageS30.OnInitForPageType // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	struct UWidget* HandleRewardTracksBoundaryNavigation(enum class EUINavigation InNavigation); // Function BattlePassS30UI.BattlePassRewardPageS30.HandleRewardTracksBoundaryNavigation // (Final|Native|Private) // @ game+0xb7b9284
	struct FVaultWorldBackgroundData GetRewardPageBackgroundData(); // Function BattlePassS30UI.BattlePassRewardPageS30.GetRewardPageBackgroundData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7b8ec0
};

// Class BattlePassS30UI.BattlePassScreenS30
// Size: 0xe68 (Inherited: 0x938)
struct UBattlePassScreenS30 : UBattlePassScreenBase {
	struct UFortBattlePassPurchaseResourcesWidget* ResourcePurchaseScreenClass; // 0x938(0x08)
	char pad_940[0x8]; // 0x940(0x08)
	struct UCommonButtonBase* Button_Close; // 0x948(0x08)
	struct UCommonButtonLegacy* Button_TouchClose; // 0x950(0x08)
	struct UCommonButtonBase* Button_ToggleViewDetails; // 0x958(0x08)
	struct UCommonButtonBase* Button_ReplayTrailer; // 0x960(0x08)
	struct UCommonButtonBase* Button_ReplayTrailer_Mobile; // 0x968(0x08)
	struct UCommonButtonBase* Button_ShowAbout; // 0x970(0x08)
	struct UCommonButtonBase* Button_RewardDetails; // 0x978(0x08)
	struct UCommonButtonBase* Button_ShowAbout_Mobile; // 0x980(0x08)
	struct UCommonButtonBase* Button_ShowAboutCustomization; // 0x988(0x08)
	struct UCommonButtonBase* Button_ShowAboutCustomization_Mobile; // 0x990(0x08)
	struct UCommonButtonBase* Button_BulkBuyRewards; // 0x998(0x08)
	struct UCommonButtonBase* Button_PageComplete; // 0x9a0(0x08)
	struct UCommonButtonBase* Button_GiftBattlePass; // 0x9a8(0x08)
	struct UCommonVisibilitySwitcher* VisibilitySwitcher_PlatformBasedButtons; // 0x9b0(0x08)
	struct UFortBattlePassResourcesWidgetBase* BattlePassCurrencyPanel; // 0x9b8(0x08)
	struct UAthenaExclusiveRewardBanner* AthenaExclusiveRewardBanner; // 0x9c0(0x08)
	struct UCommonTextBlock* Text_Description; // 0x9c8(0x08)
	struct UCommonTextBlock* Text_ItemName; // 0x9d0(0x08)
	struct UAthenaRewardItemTypeRarityTag* ItemRewardTag; // 0x9d8(0x08)
	struct UCommonTextBlock* Text_SetDetails; // 0x9e0(0x08)
	struct UWidgetSwitcher* Switcher_PrerequisiteInfo; // 0x9e8(0x08)
	struct UCommonTextBlock* Text_Prerequisite; // 0x9f0(0x08)
	struct UWidget* Widget_PrerequisiteProgress; // 0x9f8(0x08)
	struct UWidget* Widget_LevelUpMessageFree; // 0xa00(0x08)
	struct UWidget* Widget_LevelUpMessagePremium; // 0xa08(0x08)
	struct UWidget* Widget_CustomResourceMessage; // 0xa10(0x08)
	struct UWidgetSwitcher* Switcher_PrimaryAction; // 0xa18(0x08)
	struct UFortCTAButton* Button_BuyLevels; // 0xa20(0x08)
	struct UFortCTAButton* Button_BuyBattlePass; // 0xa28(0x08)
	struct UFortCTAButton* Button_ClaimReward; // 0xa30(0x08)
	struct UCommonButtonBase* Button_ViewQuests; // 0xa38(0x08)
	struct UCommonButtonBase* Button_PreviewLoadingScreen; // 0xa40(0x08)
	struct UFortDynamicEntryBox* ItemVMCards; // 0xa48(0x08)
	struct UBorder* Tag_RequiresBP; // 0xa50(0x08)
	struct UBorder* Tag_PageLocked; // 0xa58(0x08)
	struct UBorder* Tag_BaseItem; // 0xa60(0x08)
	struct UBorder* Tag_Prerequisite; // 0xa68(0x08)
	struct UBorder* Tag_CompletePage; // 0xa70(0x08)
	struct UBorder* Tag_NotEnough_Currency; // 0xa78(0x08)
	struct UBorder* Tag_Cost; // 0xa80(0x08)
	struct UBorder* Tag_Owned; // 0xa88(0x08)
	struct UBorder* Tag_Delayed; // 0xa90(0x08)
	struct FGameplayTag QuestCategoryParentTag; // 0xa98(0x04)
	char pad_A9C[0x4]; // 0xa9c(0x04)
	struct UAthenaLoadingScreenPreviewPanel* PreviewLoadingScreenWidgetClass; // 0xaa0(0x08)
	char pad_AA8[0x58]; // 0xaa8(0x58)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0xb00(0x08)
	struct UAthenaSeasonItemEntryBase* CurrentSelectedEntry; // 0xb08(0x08)
	struct TArray<enum class EBattlePassView> SwitcherSubPageTypes; // 0xb10(0x10)
	struct UCommonVisibilitySwitcher* VisibilitySwitcher_SubPage; // 0xb20(0x08)
	char pad_B28[0x108]; // 0xb28(0x108)
	struct UFortItemDefinition* SeasonalBaseCustomizationItem; // 0xc30(0x08)
	bool bHasSubscription; // 0xc38(0x01)
	char pad_C39[0x7]; // 0xc39(0x07)
	struct UFortBattlePassTutorialTooltipS30* TutorialTooltip_BattleStars; // 0xc40(0x08)
	struct UFortBattlePassTutorialTooltipS30* TutorialTooltip_StylePoints; // 0xc48(0x08)
	struct UFortSwipePanel* SwipePanel_Navigation; // 0xc50(0x08)
	char pad_C58[0x1c0]; // 0xc58(0x1c0)
	struct TMap<enum class EBattlePassFeatures, struct UCommonButtonBase*> FeatureButtons; // 0xe18(0x50)

	void SetFocusToFirstItemDetailsCard(); // Function BattlePassS30UI.BattlePassScreenS30.SetFocusToFirstItemDetailsCard // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OverviewShowAnimationFinished(); // Function BattlePassS30UI.BattlePassScreenS30.OverviewShowAnimationFinished // (Final|Native|Public|BlueprintCallable) // @ game+0x3600a3c
	void OnUpdateStatusBar(struct FText& StatusText, enum class EBattlePassStatusBarTypeS30& BarType); // Function BattlePassS30UI.BattlePassScreenS30.OnUpdateStatusBar // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnUpdateOwnedOrEquippedTag(struct FText& StatusText); // Function BattlePassS30UI.BattlePassScreenS30.OnUpdateOwnedOrEquippedTag // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnUpdateBattlePassRequiredBar(bool bPassRequiredVisible); // Function BattlePassS30UI.BattlePassScreenS30.OnUpdateBattlePassRequiredBar // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnTransitionItemDetails(bool bTransitionForward); // Function BattlePassS30UI.BattlePassScreenS30.OnTransitionItemDetails // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetWeeklyRewardsInfo(struct FTimespan& DelayTimespan, int32_t AvailableRewards, int32_t OwnedRewards, int32_t TotalRewards, int32_t AvailablePages, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS30UI.BattlePassScreenS30.OnSetWeeklyRewardsInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetWarningToolTip(enum class ERewardWarningTooltipType30& WarningTooltipType, struct FText& Description); // Function BattlePassS30UI.BattlePassScreenS30.OnSetWarningToolTip // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetResourcePrice(int32_t Cost, struct UFortPersistentResourceItemDefinition* PersistentResource); // Function BattlePassS30UI.BattlePassScreenS30.OnSetResourcePrice // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetQuestRewardsInfo(struct FTimespan& DelayTimespan, int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS30UI.BattlePassScreenS30.OnSetQuestRewardsInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetPrerequisiteInfo(struct FText& Description, int32_t CurrentAmount, int32_t NeededAmount, enum class EBattlePassRewardPrerequisiteType PrerequisiteType, bool bShowPrerequisiteLock); // Function BattlePassS30UI.BattlePassScreenS30.OnSetPrerequisiteInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetItemPrice(int32_t Cost, enum class EBattlePassCurrencyType CurrencyType); // Function BattlePassS30UI.BattlePassScreenS30.OnSetItemPrice // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetEquipButtonEnable(bool bIsEnable); // Function BattlePassS30UI.BattlePassScreenS30.OnSetEquipButtonEnable // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetCrewInfo(bool bIsNextMonthRewards, struct FText& MonthText, struct FTimespan& NextMonthlyRewardTimespan, struct FText& CharacterDisplayName, struct FText& CharacterDescription); // Function BattlePassS30UI.BattlePassScreenS30.OnSetCrewInfo // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetCoverPageData(struct FText& Title, struct FText& Description, bool bPageComplete); // Function BattlePassS30UI.BattlePassScreenS30.OnSetCoverPageData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetBonusRewardsInfo(bool bIsUnlocked, int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages, int32_t ClaimedOutfits, int32_t TotalOutfits); // Function BattlePassS30UI.BattlePassScreenS30.OnSetBonusRewardsInfo // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetBonusInfo(struct FBonusInfoMiniTagData& BonusInfo); // Function BattlePassS30UI.BattlePassScreenS30.OnSetBonusInfo // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetBaseRewardsInfo(int32_t OwnedRewards, int32_t TotalRewards, int32_t CompletedPages, int32_t TotalPages); // Function BattlePassS30UI.BattlePassScreenS30.OnSetBaseRewardsInfo // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnJunoCustomBannerUpdate(struct UUserWidget* BannerClassReference, struct TArray<struct UFortItemVM*>& ItemVMs); // Function BattlePassS30UI.BattlePassScreenS30.OnJunoCustomBannerUpdate // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnItemVmCardUpdate(struct FExpandedItemVM ItemVMs, struct UAthenaSeasonItemEntryBase* EntrySelected); // Function BattlePassS30UI.BattlePassScreenS30.OnItemVmCardUpdate // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnItemDetailsClicked(); // Function BattlePassS30UI.BattlePassScreenS30.OnItemDetailsClicked // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnItemDelayed(struct FTimespan Delay); // Function BattlePassS30UI.BattlePassScreenS30.OnItemDelayed // (Event|Protected|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
	void OnInsufficientResource(struct UFortPersistentResourceItemDefinition* PersistentResource); // Function BattlePassS30UI.BattlePassScreenS30.OnInsufficientResource // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnInsufficientFunds(enum class EBattlePassCurrencyType CurrencyType); // Function BattlePassS30UI.BattlePassScreenS30.OnInsufficientFunds // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnHideItemDetails(); // Function BattlePassS30UI.BattlePassScreenS30.OnHideItemDetails // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnGameModeCompatibilityTagUpdate(struct UFortItemVM* FortItem); // Function BattlePassS30UI.BattlePassScreenS30.OnGameModeCompatibilityTagUpdate // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnCreateViewRewardCard(struct UFortItemVM* ItemVM, struct UFortItemDefinition* EffectiveActivedef, struct TArray<struct FMcpVariantChannelInfo>& Variants, bool bForceEffectiveImage); // Function BattlePassS30UI.BattlePassScreenS30.OnCreateViewRewardCard // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnBattlePassOwned(); // Function BattlePassS30UI.BattlePassScreenS30.OnBattlePassOwned // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnBattlePassGiftingAllowed(bool bGiftingAllowed); // Function BattlePassS30UI.BattlePassScreenS30.OnBattlePassGiftingAllowed // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	bool IsSeasonalCustomizationItemOwned(); // Function BattlePassS30UI.BattlePassScreenS30.IsSeasonalCustomizationItemOwned // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7b937c
	void HandleSwitcherVisibilityShown(); // Function BattlePassS30UI.BattlePassScreenS30.HandleSwitcherVisibilityShown // (Final|Native|Public|BlueprintCallable) // @ game+0xb7b9354
	void HandleItemVMCardClicked(struct UFortItemVM* ItemVM, struct TArray<struct FMcpVariantChannelInfo>& Variants); // Function BattlePassS30UI.BattlePassScreenS30.HandleItemVMCardClicked // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xb7b915c
	void HandleFullScreenMapToggled(bool bMapVisible); // Function BattlePassS30UI.BattlePassScreenS30.HandleFullScreenMapToggled // (Final|Native|Private) // @ game+0xb7b9098
	void HandleClaimRewardComplete(bool bSuccess, struct TArray<struct FString>& OfferTemplateIdList); // Function BattlePassS30UI.BattlePassScreenS30.HandleClaimRewardComplete // (Final|Native|Private|HasOutParms) // @ game+0xb7b8f70
	void GoBackOneScreen(); // Function BattlePassS30UI.BattlePassScreenS30.GoBackOneScreen // (Final|Native|Public|BlueprintCallable) // @ game+0xb7b8f5c
	struct FTimespan GetQuestPageDelay(); // Function BattlePassS30UI.BattlePassScreenS30.GetQuestPageDelay // (Final|Native|Protected|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7b8e94
	bool GetEquipButtonEnable(); // Function BattlePassS30UI.BattlePassScreenS30.GetEquipButtonEnable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7b8e78
};

// Class BattlePassS30UI.FortBattlePassCustomSkinPageS30
// Size: 0x5d8 (Inherited: 0x5c0)
struct UFortBattlePassCustomSkinPageS30 : UFortBattlePassCustomSkinPageBase {
	struct FString ClaimBaseItemTooltip_ClaimCheckTemplateId; // 0x5c0(0x10)
	struct UFortBattlePassTutorialTooltip* TutorialTooltip_ClaimBaseItem; // 0x5d0(0x08)
};

// Class BattlePassS30UI.FortBattlePassResourcesWidgetS30
// Size: 0x310 (Inherited: 0x2f0)
struct UFortBattlePassResourcesWidgetS30 : UFortBattlePassResourcesWidgetBase {
	struct UCommonTextBlock* Text_BattleStarsAmount; // 0x2f0(0x08)
	struct UCommonTextBlock* Text_StylePointsAmount; // 0x2f8(0x08)
	struct UBorder* Border_StylePointsRewardsTag; // 0x300(0x08)
	struct UBorder* Border_BattleStarsRewardsTag; // 0x308(0x08)

	void OnStylePointsRewardsSet(int32_t Rewards); // Function BattlePassS30UI.FortBattlePassResourcesWidgetS30.OnStylePointsRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnBattleStarRewardsSet(int32_t Rewards); // Function BattlePassS30UI.FortBattlePassResourcesWidgetS30.OnBattleStarRewardsSet // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

// Class BattlePassS30UI.FortBattlePassTutorialTooltipS30
// Size: 0x2f0 (Inherited: 0x2e0)
struct UFortBattlePassTutorialTooltipS30 : UCommonUserWidget {
	struct UCommonRichTextBlock* Text_Tooltip; // 0x2e0(0x08)
	char pad_2E8[0x8]; // 0x2e8(0x08)

	void ShowTooltip(); // Function BattlePassS30UI.FortBattlePassTutorialTooltipS30.ShowTooltip // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void SetText(struct FText Text); // Function BattlePassS30UI.FortBattlePassTutorialTooltipS30.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0xb78d3e8
	void HideTooltip(); // Function BattlePassS30UI.FortBattlePassTutorialTooltipS30.HideTooltip // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

