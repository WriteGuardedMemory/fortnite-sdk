// BlueprintGeneratedClass B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C
// Size: 0xc94 (Inherited: 0xc3e)
struct AB_Prj_Athena_FragGrenade_C : AB_Prj_Athena_Grenade_Base_C {
	char pad_C3E[0x2]; // 0xc3e(0x02)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc40(0x08)
	struct UNiagaraComponent* NS_Object_FloatingInWater; // 0xc48(0x08)
	struct UBP_SurfaceTypeSoundComponent_C* BP_SurfaceTypeSoundComponent; // 0xc50(0x08)
	float PreExploWarning_PreExplo_E5859FFE443F57359EC2C0AB73DFA4CD; // 0xc58(0x04)
	enum class ETimelineDirection PreExploWarning__Direction_E5859FFE443F57359EC2C0AB73DFA4CD; // 0xc5c(0x01)
	char pad_C5D[0x3]; // 0xc5d(0x03)
	struct UTimelineComponent* PreExploWarning; // 0xc60(0x08)
	struct FGameplayTag FeedbackCue; // 0xc68(0x04)
	char pad_C6C[0x4]; // 0xc6c(0x04)
	struct UNiagaraSystem* Niagara_Bounse; // 0xc70(0x08)
	enum class PreExplodeRampType PreExplodeOptimization; // 0xc78(0x01)
	char pad_C79[0x7]; // 0xc79(0x07)
	double PreExplodeRampTime; // 0xc80(0x08)
	struct FName GrenadeFuseParamName; // 0xc88(0x04)
	float PreExplodeTimerRampFrequency; // 0xc8c(0x04)
	float PreExplodeTimerAccumulatedRampTime; // 0xc90(0x04)

	void PreExploWarning__FinishedFunc(); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.PreExploWarning__FinishedFunc // (BlueprintEvent) // @ game+0x18e3f1c
	void PreExploWarning__UpdateFunc(); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.PreExploWarning__UpdateFunc // (BlueprintEvent) // @ game+0x18e3f1c
	void FuseEnded(); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.FuseEnded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnExploded(struct TArray<struct AActor*>& HitActors, struct TArray<struct FHitResult>& HitResults); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnBounce(struct FHitResult& Hit); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.OnBounce // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void Pre Explo Audio Tell(); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.Pre Explo Audio Tell // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_1_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_1_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_3_WaterInteractionOnExitWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsLastBody); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_3_WaterInteractionOnExitWater__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void TimerPreExplode(); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.TimerPreExplode // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_B_Prj_Athena_FragGrenade(int32_t EntryPoint); // Function B_Prj_Athena_FragGrenade.B_Prj_Athena_FragGrenade_C.ExecuteUbergraph_B_Prj_Athena_FragGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

