// Class CareerUI.FortUIGameFeatureAction_CompeteTab
// Size: 0x38 (Inherited: 0x28)
struct UFortUIGameFeatureAction_CompeteTab : UFortUIGameFeatureAction {
	struct UCommonActivatableWidget* OldCareerStatsScreenClass; // 0x28(0x08)
	struct UCommonActivatableWidget* NewCareerStatsScreenClass; // 0x30(0x08)
};

