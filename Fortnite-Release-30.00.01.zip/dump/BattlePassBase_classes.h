// Class BattlePassBase.FortBattlePassCustomSkinPageTab
// Size: 0x620 (Inherited: 0x3f8)
struct UFortBattlePassCustomSkinPageTab : UCommonActivatableWidget {
	char pad_3F8[0x1a0]; // 0x3f8(0x1a0)
	struct UScrollBox* ScrollBox_Categories; // 0x598(0x08)
	char pad_5A0[0x10]; // 0x5a0(0x10)
	struct UBattlePassEnabledInputData* EquipEnabledData; // 0x5b0(0x08)
	char pad_5B8[0x8]; // 0x5b8(0x08)
	struct UCommonVisibilitySwitcher* VisibilitySwitcher_Content; // 0x5c0(0x08)
	struct TArray<struct FBattlePassCharaterRewardTabInfo> TabInfos; // 0x5c8(0x10)
	struct UDynamicEntryBox* ListView_PrimaryTabs; // 0x5d8(0x08)
	struct TArray<struct FBattlePassCharaterRewardTabInfo> ActiveTabInfos; // 0x5e0(0x10)
	struct UCommonActivatableWidget* CustomizationRowClass; // 0x5f0(0x08)
	struct FDataTableRowHandle NextTabInputAction; // 0x5f8(0x10)
	struct FDataTableRowHandle PreviousTabInputAction; // 0x608(0x10)
	char pad_618[0x8]; // 0x618(0x08)

	void EnableTabActions(); // Function BattlePassBase.FortBattlePassCustomSkinPageTab.EnableTabActions // (Final|Native|Protected|BlueprintCallable) // @ game+0xb78b7ec
};

// Class BattlePassBase.FortBattlePassCustomSkinTab
// Size: 0x14b0 (Inherited: 0x1490)
struct UFortBattlePassCustomSkinTab : UCommonButtonBase {
	struct UCommonLazyImage* LazyImage_Icon; // 0x1490(0x08)
	struct FVector2D ImageSize_Mobile; // 0x1498(0x10)
	char pad_14A8[0x8]; // 0x14a8(0x08)

	void SetIcon(struct TSoftObjectPtr<UObject> LazyObject); // Function BattlePassBase.FortBattlePassCustomSkinTab.SetIcon // (Final|Native|Public|BlueprintCallable) // @ game+0xb78cfe8
	void BP_ShowBang(bool bShow); // Function BattlePassBase.FortBattlePassCustomSkinTab.BP_ShowBang // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
};

// Class BattlePassBase.FortBattlePassSkinCategoriesTile
// Size: 0x400 (Inherited: 0x3f8)
struct UFortBattlePassSkinCategoriesTile : UCommonActivatableWidget {
	struct UDynamicEntryBox* FortDynamicEntryBox_Categories; // 0x3f8(0x08)
};

// Class BattlePassBase.BattlePassLandingPageBase
// Size: 0x550 (Inherited: 0x3f8)
struct UBattlePassLandingPageBase : UCommonActivatableWidget {
	char pad_3F8[0x120]; // 0x3f8(0x120)
	struct UBattlePassLandingPageButton* LastHoveredPageButton; // 0x518(0x08)
	struct UCommonButtonGroupBase* LandingPageButtonGroupBase; // 0x520(0x08)
	char pad_528[0x28]; // 0x528(0x28)
};

// Class BattlePassBase.BattlePassLandingPageButton
// Size: 0x16b0 (Inherited: 0x1490)
struct UBattlePassLandingPageButton : UCommonButtonBase {
	enum class EBattlePassView SubPageType; // 0x1490(0x01)
	enum class EBattlePassFeatures FeatureType; // 0x1491(0x01)
	char pad_1492[0x6]; // 0x1492(0x06)
	struct FBattlePassLandingPageEntryPreviewInfo PreviewInfo; // 0x1498(0x90)
	bool bNeedsBattlePass; // 0x1528(0x01)
	char pad_1529[0x7]; // 0x1529(0x07)
	struct UFortChallengeBundleScheduleDefinition* DelayQuestSchedule; // 0x1530(0x08)
	int32_t DelayDaysSinceSeasonStart; // 0x1538(0x04)
	char pad_153C[0x4]; // 0x153c(0x04)
	struct UFortItemDefinition* RequiredItem; // 0x1540(0x08)
	struct UFortBangWrapper_NUI* BangWrapper; // 0x1548(0x08)
	bool bUsesTelemetry; // 0x1550(0x01)
	char pad_1551[0x3]; // 0x1551(0x03)
	struct FIntPoint Telemetry_Size; // 0x1554(0x08)
	struct FIntPoint Telemetry_Position; // 0x155c(0x08)
	char pad_1564[0x4]; // 0x1564(0x04)
	struct FBattlePassLandingPageButtonTexts DefaultTexts; // 0x1568(0x30)
	struct FBattlePassLandingPageButtonTexts DelayedTexts; // 0x1598(0x30)
	struct FBattlePassLandingPageButtonTexts SubscribedTexts; // 0x15c8(0x30)
	struct FBattlePassLandingPageButtonDisplayBehaviorData DisplayBehaviorData; // 0x15f8(0x18)
	char pad_1610[0xa0]; // 0x1610(0xa0)

	void OnSubscriptionTextureLoaded(struct UTexture2D* Texture); // Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionTextureLoaded // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSubscriptionOwnershipUpdated(bool bOwnsSubsciption); // Function BattlePassBase.BattlePassLandingPageButton.OnSubscriptionOwnershipUpdated // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnShowDisplayDetails(); // Function BattlePassBase.BattlePassLandingPageButton.OnShowDisplayDetails // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetTileImageMaterial(struct UMaterialInstance* Material); // Function BattlePassBase.BattlePassLandingPageButton.OnSetTileImageMaterial // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnDisplayDetailsUpdated(struct FBattlePassLandingPageButtonDisplayDetails& NewDisplayDetails); // Function BattlePassBase.BattlePassLandingPageButton.OnDisplayDetailsUpdated // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	struct FBattlePassLandingPageButtonDisplayDetails GetBattlePassDisplayDetails(); // Function BattlePassBase.BattlePassLandingPageButton.GetBattlePassDisplayDetails // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78b8fc
};

// Class BattlePassBase.BattlePassRewardPageBase
// Size: 0x510 (Inherited: 0x3f8)
struct UBattlePassRewardPageBase : UCommonActivatableWidget {
	char pad_3F8[0x118]; // 0x3f8(0x118)
};

// Class BattlePassBase.BattlePassUIGameFeatureAction
// Size: 0x88 (Inherited: 0x28)
struct UBattlePassUIGameFeatureAction : UFortUIGameFeatureAction {
	struct TSoftClassPtr<UObject> BattlePassScreenClass; // 0x28(0x20)
	struct TSoftClassPtr<UObject> BattlePassResourceWidgetClass; // 0x48(0x20)
	struct TSoftClassPtr<UObject> BattlePassInfoModalClass; // 0x68(0x20)
};

// Class BattlePassBase.FortBattlePassCustomSkinCategoryTile
// Size: 0x370 (Inherited: 0x2b8)
struct UFortBattlePassCustomSkinCategoryTile : UUserWidget {
	char pad_2B8[0x20]; // 0x2b8(0x20)
	struct UProgressBar* ProgressBar; // 0x2d8(0x08)
	struct UFortDynamicEntryBox* FortDynamicEntryBox_Items; // 0x2e0(0x08)
	struct URichTextBlock* Text_CategoryTitle; // 0x2e8(0x08)
	struct UFortBattlePassTile* PreviewedTile; // 0x2f0(0x08)
	int32_t OwnedRewards; // 0x2f8(0x04)
	char pad_2FC[0x74]; // 0x2fc(0x74)

	void SetPreviewedTile(int32_t Index); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.SetPreviewedTile // (Final|Native|Public|BlueprintCallable) // @ game+0xb78d11c
	void OnOwnedTilesUpdated(int32_t CurrentlyOwnedRewards, int32_t TotalRewards, float CategoryProgress); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnOwnedTilesUpdated // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnLockedStateChanged(bool bCategoryLocked); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnLockedProgressUpdated(int32_t CurrentlyOwnedBeforeCategory, int32_t TotalRewardsBeforeCategory, float LockedProgress); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.OnLockedProgressUpdated // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void FocusTile(int32_t Index); // Function BattlePassBase.FortBattlePassCustomSkinCategoryTile.FocusTile // (Final|Native|Public|BlueprintCallable) // @ game+0xb78b800
};

// Class BattlePassBase.FortBattlePassCustomSkinPageBase
// Size: 0x5c0 (Inherited: 0x3f8)
struct UFortBattlePassCustomSkinPageBase : UCommonActivatableWidget {
	char pad_3F8[0x1a0]; // 0x3f8(0x1a0)
	struct UScrollBox* ScrollBox_Categories; // 0x598(0x08)
	struct UFortDynamicEntryBox* FortDynamicEntryBox_Categories; // 0x5a0(0x08)
	char pad_5A8[0x8]; // 0x5a8(0x08)
	struct UBattlePassEnabledInputData* EquipEnabledData; // 0x5b0(0x08)
	char pad_5B8[0x8]; // 0x5b8(0x08)
};

// Class BattlePassBase.FortBattlePassBulkBuyPageBase
// Size: 0x598 (Inherited: 0x3f8)
struct UFortBattlePassBulkBuyPageBase : UCommonActivatableWidget {
	char pad_3F8[0x118]; // 0x3f8(0x118)
	struct UCommonButtonBase* Button_Addition; // 0x510(0x08)
	struct UCommonButtonBase* Button_Subtraction; // 0x518(0x08)
	struct UDynamicEntryBox* DynamicEntryBox_TilesEntries; // 0x520(0x08)
	struct UCommonVisibilitySwitcher* Switcher_BottomButtons; // 0x528(0x08)
	struct UFortCTAButton* Button_BuyLevels; // 0x530(0x08)
	struct UFortCTAButton* Button_ClaimReward; // 0x538(0x08)
	struct UWidget* Widget_LevelUpMessagePremium; // 0x540(0x08)
	struct UAthenaSeasonItemData_BattleStar* SeasonData_BattleStar; // 0x548(0x08)
	char pad_550[0x18]; // 0x550(0x18)
	struct UAthenaSeasonItemDefinition* SeasonItemDefinition; // 0x568(0x08)
	struct UFortBattlePassTile* FocusedReward; // 0x570(0x08)
	char pad_578[0x18]; // 0x578(0x18)
	struct UScrollBox* ScrollBox_Pages; // 0x590(0x08)

	void OnRewardCountChanged(int32_t Count); // Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnRewardCountChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnPageRangeChanged(int32_t FromPage, int32_t ToPage); // Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnPageRangeChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnCostChanged(int32_t Cost); // Function BattlePassBase.FortBattlePassBulkBuyPageBase.OnCostChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void HandleUserScrolled(float ScrollAmount); // Function BattlePassBase.FortBattlePassBulkBuyPageBase.HandleUserScrolled // (Final|Native|Protected) // @ game+0xb78cda0
};

// Class BattlePassBase.FortBattlePassCheckBoxButton
// Size: 0x14a0 (Inherited: 0x1490)
struct UFortBattlePassCheckBoxButton : UCommonButtonBase {
	char pad_1490[0x10]; // 0x1490(0x10)

	void OnStateChanged(bool bNewIsChecked); // Function BattlePassBase.FortBattlePassCheckBoxButton.OnStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

// Class BattlePassBase.FortBattlePassContext
// Size: 0xa8 (Inherited: 0x30)
struct UFortBattlePassContext : UBlueprintContextBase {
	char pad_30[0x8]; // 0x30(0x08)
	struct TArray<struct UFortPersistentResourceItemDefinition*> CustomizationPageSeasonalResources; // 0x38(0x10)
	struct TArray<struct UFortPersistentResourceItemDefinition*> AllSeasonalResources; // 0x48(0x10)
	struct TMap<enum class ERewardPageType, struct FSeasonalResourceList> RewardPageSeasonalResources; // 0x58(0x50)

	struct TArray<struct FSeasonCurrencyMcpData> GetSeasonalCurrencies(); // Function BattlePassBase.FortBattlePassContext.GetSeasonalCurrencies // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78bc88
	struct FText GetLevelPurchaseDisclaimerText(); // Function BattlePassBase.FortBattlePassContext.GetLevelPurchaseDisclaimerText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78bbe4
	struct FText GetDefaultDisclaimerText(); // Function BattlePassBase.FortBattlePassContext.GetDefaultDisclaimerText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78bb40
	struct FText GetCurrentSeasonNumberAsText(bool bFullText); // Function BattlePassBase.FortBattlePassContext.GetCurrentSeasonNumberAsText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78ba2c
	struct FText GetCurrentChapterAsText(bool bFullText); // Function BattlePassBase.FortBattlePassContext.GetCurrentChapterAsText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78b918
	bool CanPurchaseBattlePassLevel(); // Function BattlePassBase.FortBattlePassContext.CanPurchaseBattlePassLevel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78b7c8
};

// Class BattlePassBase.FortBattlePassResourcesWidgetBase
// Size: 0x2f0 (Inherited: 0x2e0)
struct UFortBattlePassResourcesWidgetBase : UFortGlobalSeasonResourceWidget {
	struct UFortBattlePassResourceCounter* ResourceCounterClass; // 0x2e0(0x08)
	struct UDynamicEntryBox* EntryBox_ResourceCounters; // 0x2e8(0x08)

	void ShowResourcesInfoModal(); // Function BattlePassBase.FortBattlePassResourcesWidgetBase.ShowResourcesInfoModal // (Final|Native|Protected|BlueprintCallable) // @ game+0xb78d59c
	void OnShowMoreInfo(bool bShouldShowMoreInfo); // Function BattlePassBase.FortBattlePassResourcesWidgetBase.OnShowMoreInfo // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

// Class BattlePassBase.FortBattlePassCurrencyPanel
// Size: 0x330 (Inherited: 0x2f0)
struct UFortBattlePassCurrencyPanel : UFortBattlePassResourcesWidgetBase {
	struct UHorizontalBox* HBox_BattleStarContainer; // 0x2f0(0x08)
	struct UCommonTextBlock* Text_BattleStar; // 0x2f8(0x08)
	struct UHorizontalBox* HBox_CustomSkinContainer; // 0x300(0x08)
	struct UCommonTextBlock* Text_CustomSkin; // 0x308(0x08)
	char pad_310[0x20]; // 0x310(0x20)
};

// Class BattlePassBase.FortBattlePassDynamicIcon
// Size: 0x300 (Inherited: 0x2b8)
struct UFortBattlePassDynamicIcon : UUserWidget {
	struct TSoftObjectPtr<UObject> BattlePassDefaultIcon; // 0x2b8(0x20)
	struct TSoftObjectPtr<UObject> BattlePassOwnedIcon; // 0x2d8(0x20)
	struct UFortLazyImage* LazyImage_BattlePassIcon; // 0x2f8(0x08)

	void OnBattlePassInfoUpdated(bool bOwnsBattlePass); // Function BattlePassBase.FortBattlePassDynamicIcon.OnBattlePassInfoUpdated // (Event|Protected|BlueprintEvent|Const) // @ game+0x18e3f1c
};

// Class BattlePassBase.FortBattlePassLevelCount
// Size: 0x2c8 (Inherited: 0x2b8)
struct UFortBattlePassLevelCount : UUserWidget {
	struct UCommonTextBlock* Text_LevelCount; // 0x2b8(0x08)
	char pad_2C0[0x8]; // 0x2c0(0x08)
};

// Class BattlePassBase.FortBattlePassPrerequisiteHeader
// Size: 0x2c0 (Inherited: 0x2b8)
struct UFortBattlePassPrerequisiteHeader : UUserWidget {
	struct UTextBlock* Text_Prerequisite; // 0x2b8(0x08)
};

// Class BattlePassBase.FortBattlePassPurchaseResourcesWidget
// Size: 0x4b8 (Inherited: 0x3f8)
struct UFortBattlePassPurchaseResourcesWidget : UCommonActivatableWidget {
	char pad_3F8[0x8]; // 0x3f8(0x08)
	struct UCommonButtonBase* Button_Addition; // 0x400(0x08)
	struct UCommonButtonBase* Button_BatchAddition; // 0x408(0x08)
	struct UCommonButtonBase* Button_Subtraction; // 0x410(0x08)
	struct UCommonButtonBase* Button_BatchSubtraction; // 0x418(0x08)
	struct UCommonVisibilitySwitcher* Switcher_PurchaseButtons; // 0x420(0x08)
	struct UFortHoldableButton* Button_Purchase; // 0x428(0x08)
	struct UCommonButtonBase* Button_GetVBucks; // 0x430(0x08)
	struct UCommonButtonBase* Button_ReloadMtx; // 0x438(0x08)
	struct UCommonButtonBase* Button_Back; // 0x440(0x08)
	struct UFortBattlePassCheckBoxButton* CheckBox_Bundle; // 0x448(0x08)
	struct UCommonButtonBase* Button_CloseTouch; // 0x450(0x08)
	int32_t CurrentLevel; // 0x458(0x04)
	bool bIsOfferActive; // 0x45c(0x01)
	char pad_45D[0x3]; // 0x45d(0x03)
	int32_t CurrentVBucks; // 0x460(0x04)
	int32_t CurrentBattleStars; // 0x464(0x04)
	int32_t BatchNum; // 0x468(0x04)
	bool bOfferUnavailable; // 0x46c(0x01)
	char pad_46D[0x3]; // 0x46d(0x03)
	int32_t MaxBundleLevel; // 0x470(0x04)
	int32_t MaxLevel; // 0x474(0x04)
	int32_t MaxLevelPurchases; // 0x478(0x04)
	int32_t BundleAmount; // 0x47c(0x04)
	struct UFortItemDefinition* LevelPreviewItem; // 0x480(0x08)
	struct UAthenaSeasonItemData_BattleStar* BattleStarData; // 0x488(0x08)
	char pad_490[0x28]; // 0x490(0x28)

	void OnUpdatePageUnlockText(struct FText& PageUnlockText); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnUpdatePageUnlockText // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnTotalPriceChanged(int32_t NewPrice); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnTotalPriceChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnPurchaseAmountChanged(int32_t NewAmount, int32_t LevelsLeft); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnPurchaseAmountChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnOfferUnavailable(); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnOfferUnavailable // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnAmountChangeButtonClicked(); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.OnAmountChangeButtonClicked // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	bool IsReloadMtxEnabled(); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.IsReloadMtxEnabled // (Final|Native|Protected|BlueprintCallable) // @ game+0xb78cf5c
	void HandlePurchaseMultiComplete(bool bSuccess, struct TArray<struct FPurchasedItemInfo>& PurchasedItems, struct TArray<struct FString>& OfferIdList); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseMultiComplete // (Final|Native|Private|HasOutParms) // @ game+0xb78c5cc
	void HandlePurchaseComplete(bool bSuccess, struct TArray<struct FPurchasedItemInfo>& PurchasedItems, struct FString OfferId); // Function BattlePassBase.FortBattlePassPurchaseResourcesWidget.HandlePurchaseComplete // (Final|Native|Private|HasOutParms) // @ game+0xb78bd98
};

// Class BattlePassBase.FortBattlePassResourceCounter
// Size: 0x300 (Inherited: 0x2e0)
struct UFortBattlePassResourceCounter : UCommonUserWidget {
	struct UCommonTextBlock* Text_ResourceName; // 0x2e0(0x08)
	struct UFortLazyImage* LazyImage_ResourceIcon; // 0x2e8(0x08)
	struct UCommonTextBlock* Text_ResourceCount; // 0x2f0(0x08)
	struct UFortPersistentResourceItemDefinition* CurrentResource; // 0x2f8(0x08)
};

// Class BattlePassBase.FortBattlePassRewardGrid
// Size: 0x4c0 (Inherited: 0x3f8)
struct UFortBattlePassRewardGrid : UCommonActivatableWidget {
	char pad_3F8[0x68]; // 0x3f8(0x68)
	struct UFortBattlePassTileBase* GridTileClass; // 0x460(0x08)
	struct UFortBattlePassTileBase* GridEmptyTileClass; // 0x468(0x08)
	struct FVector2D GridCellPadding; // 0x470(0x10)
	struct UFortBattlePassRewardGridHeader* PageHeader; // 0x480(0x08)
	struct UGridPanel* GridPanel_Rewards; // 0x488(0x08)
	struct UFortBattlePassTileBase* DefaultFocusTile; // 0x490(0x08)
	struct TWeakObjectPtr<struct UCommonButtonBase> LastFocusedTile; // 0x498(0x08)
	char pad_4A0[0x20]; // 0x4a0(0x20)

	void OnPageUnselected(); // Function BattlePassBase.FortBattlePassRewardGrid.OnPageUnselected // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnPageSelected(); // Function BattlePassBase.FortBattlePassRewardGrid.OnPageSelected // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
};

// Class BattlePassBase.FortBattlePassRewardGridHeader
// Size: 0x2c0 (Inherited: 0x2b8)
struct UFortBattlePassRewardGridHeader : UUserWidget {
	char pad_2B8[0x8]; // 0x2b8(0x08)

	void OnSetPageType(enum class ERewardPageType PageType); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageType // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetPageCustomName(struct FText& CustomName); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnSetPageCustomName // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnPageUnlocked(int32_t PurchasedRewards, int32_t TotalRewards); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageUnlocked // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnPageNumberSet(int32_t InPageNumber); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageNumberSet // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnPageLocked(int32_t RequiredLevel, int32_t RequiredRewards, bool IsTimeLocked, struct FTimespan TimeRemaining); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnPageLocked // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
	void OnBattlePassLevelSet(int32_t BattlePassLevel); // Function BattlePassBase.FortBattlePassRewardGridHeader.OnBattlePassLevelSet // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	int32_t GetPageNumber(); // Function BattlePassBase.FortBattlePassRewardGridHeader.GetPageNumber // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8e77810
};

// Class BattlePassBase.FortBattlePassRewardTrack
// Size: 0x498 (Inherited: 0x3f8)
struct UFortBattlePassRewardTrack : UCommonActivatableWidget {
	char pad_3F8[0x50]; // 0x3f8(0x50)
	struct UFortBattlePassTileBase* RewardTileClass; // 0x448(0x08)
	struct UFortBattlePassTileBase* RewardEmptyTileClass; // 0x450(0x08)
	struct UFortBattlePassPrerequisiteHeader* PrerequisiteHeaderClass; // 0x458(0x08)
	struct FVector2D GridCellPadding; // 0x460(0x10)
	struct UGridPanel* GridPanel_Rewards; // 0x470(0x08)
	struct UFortBattlePassTileBase* DefaultFocusTile; // 0x478(0x08)
	struct TWeakObjectPtr<struct UCommonButtonBase> LastFocusedTile; // 0x480(0x08)
	char pad_488[0x10]; // 0x488(0x10)

	void OnPageUnselected(); // Function BattlePassBase.FortBattlePassRewardTrack.OnPageUnselected // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnPageSelected(); // Function BattlePassBase.FortBattlePassRewardTrack.OnPageSelected // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
};

// Class BattlePassBase.FortBattlePassTileBase
// Size: 0x15f0 (Inherited: 0x1530)
struct UFortBattlePassTileBase : UFortHoldableButton {
	enum class ERewardPageType RewardPageType; // 0x1530(0x01)
	char pad_1531[0x7]; // 0x1531(0x07)
	struct USizeBox* SizeBox_Content; // 0x1538(0x08)
	struct TMap<struct FName, struct FLinearColor> TileColors; // 0x1540(0x50)
	struct FLinearColor OverlayDimColor; // 0x1590(0x10)
	struct FVector2D TileDesiredCellSpan; // 0x15a0(0x10)
	float UnitHeight; // 0x15b0(0x04)
	float UnitWidth; // 0x15b4(0x04)
	char pad_15B8[0x38]; // 0x15b8(0x38)

	void SetState(enum class BattlePassTileAvailabilityStates NewState); // Function BattlePassBase.FortBattlePassTileBase.SetState // (Final|Native|Protected|BlueprintCallable) // @ game+0xb78d324
	void SetSize(enum class EPageItemTileSize TileSize, struct FVector2D& CellSpacing); // Function BattlePassBase.FortBattlePassTileBase.SetSize // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb78d20c
	void OnStateChanged(enum class BattlePassTileAvailabilityStates NewState); // Function BattlePassBase.FortBattlePassTileBase.OnStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSizeChanged(struct FVector2D& NewSize); // Function BattlePassBase.FortBattlePassTileBase.OnSizeChanged // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetTileColors(); // Function BattlePassBase.FortBattlePassTileBase.OnSetTileColors // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetRequiresBattlePass(bool bRequiresBP); // Function BattlePassBase.FortBattlePassTileBase.OnSetRequiresBattlePass // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnRevealed(); // Function BattlePassBase.FortBattlePassTileBase.OnRevealed // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnPeeked(); // Function BattlePassBase.FortBattlePassTileBase.OnPeeked // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	bool IsOwned(); // Function BattlePassBase.FortBattlePassTileBase.IsOwned // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78cf40
	bool IsLocked(); // Function BattlePassBase.FortBattlePassTileBase.IsLocked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78cf24
	bool IsAvailable(); // Function BattlePassBase.FortBattlePassTileBase.IsAvailable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78cf08
	enum class BattlePassTileAvailabilityStates GetState(); // Function BattlePassBase.FortBattlePassTileBase.GetState // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x403a254
	bool AreAnyGrantedItemsEquipped(); // Function BattlePassBase.FortBattlePassTileBase.AreAnyGrantedItemsEquipped // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78b79c
};

// Class BattlePassBase.FortBattlePassTile
// Size: 0x1670 (Inherited: 0x15f0)
struct UFortBattlePassTile : UFortBattlePassTileBase {
	char pad_15F0[0x18]; // 0x15f0(0x18)
	struct UFortLazyImage* Image_RewardItem; // 0x1608(0x08)
	struct UImage* Image_Currency; // 0x1610(0x08)
	struct UImage* Age_Gating_Item; // 0x1618(0x08)
	bool bIsOnBulkBuyMode; // 0x1620(0x01)
	char pad_1621[0x4f]; // 0x1621(0x4f)

	void OnUnpreviewed(); // Function BattlePassBase.FortBattlePassTile.OnUnpreviewed // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnUnhighlighted(); // Function BattlePassBase.FortBattlePassTile.OnUnhighlighted // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnTilePreviewCycled(); // Function BattlePassBase.FortBattlePassTile.OnTilePreviewCycled // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetTrack(bool bIsFreeTrack, bool bOwnsBattlePass); // Function BattlePassBase.FortBattlePassTile.OnSetTrack // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetCurrencyAndPrice(enum class EBattlePassCurrencyType Currency, int32_t Price); // Function BattlePassBase.FortBattlePassTile.OnSetCurrencyAndPrice // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnPreviewed(); // Function BattlePassBase.FortBattlePassTile.OnPreviewed // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnLockedStateUpdated(bool OwnsBattlePass, bool ParentUnlocked, bool HasRemainingPrerequisites, bool bIsDelayed); // Function BattlePassBase.FortBattlePassTile.OnLockedStateUpdated // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnLockedProgressUpdated(float Progress, int32_t CurrentlyOwnedRewards, int32_t NeededRewards); // Function BattlePassBase.FortBattlePassTile.OnLockedProgressUpdated // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnHighlighted(); // Function BattlePassBase.FortBattlePassTile.OnHighlighted // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnAffordabilityChanged(bool bHasEnougCurrency); // Function BattlePassBase.FortBattlePassTile.OnAffordabilityChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	bool IsAffordable(); // Function BattlePassBase.FortBattlePassTile.IsAffordable // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78ce80
	bool HasPrerequisites(); // Function BattlePassBase.FortBattlePassTile.HasPrerequisites // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb78ce5c
};

// Class BattlePassBase.FortBattlePassTutorialTooltip
// Size: 0x2f0 (Inherited: 0x2e0)
struct UFortBattlePassTutorialTooltip : UCommonUserWidget {
	struct UCommonRichTextBlock* Text_Tooltip; // 0x2e0(0x08)
	char pad_2E8[0x8]; // 0x2e8(0x08)

	void ShowTooltip(); // Function BattlePassBase.FortBattlePassTutorialTooltip.ShowTooltip // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void SetTooltipEnabled(bool bEnable); // Function BattlePassBase.FortBattlePassTutorialTooltip.SetTooltipEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb78d4d8
	void SetText(struct FText Text); // Function BattlePassBase.FortBattlePassTutorialTooltip.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0xb78d3e8
	void HideTooltip(); // Function BattlePassBase.FortBattlePassTutorialTooltip.HideTooltip // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

// Class BattlePassBase.RebootRallyQuestPanel
// Size: 0x2b8 (Inherited: 0x2b8)
struct URebootRallyQuestPanel : UUserWidget {

	void OnRebootRallyEligibilityUpdated(bool bEligible); // Function BattlePassBase.RebootRallyQuestPanel.OnRebootRallyEligibilityUpdated // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
};

