// BlueprintGeneratedClass BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C
// Size: 0xdc0 (Inherited: 0xc98)
struct ABP_Athena_Environmental_ZipLine_Spline_C : AFortAthenaSplineZipline {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xc98(0x08)
	struct USphereComponent* EndPointInteractSphere; // 0xca0(0x08)
	struct USphereComponent* StartPointInteractSphere; // 0xca8(0x08)
	struct UStaticMesh* SplineStaticMesh; // 0xcb0(0x08)
	double TangentSmoothStrength; // 0xcb8(0x08)
	bool AutoSmoothTangents; // 0xcc0(0x01)
	enum class ESplineMeshAxis ForwardMeshAxis; // 0xcc1(0x01)
	char pad_CC2[0x6]; // 0xcc2(0x06)
	struct FVector MotorOffset; // 0xcc8(0x18)
	struct ABuildingActor* PoleA; // 0xce0(0x08)
	struct ABuildingActor* PoleB; // 0xce8(0x08)
	struct FVector PoleASocketLocation; // 0xcf0(0x18)
	struct FVector PoleBSocketLocation; // 0xd08(0x18)
	int32_t LowerPointID; // 0xd20(0x04)
	int32_t HigherPointID; // 0xd24(0x04)
	struct FVector HigherEndLocation; // 0xd28(0x18)
	struct FVector LowerEndLocation; // 0xd40(0x18)
	double AutoLinearFactorLow; // 0xd58(0x08)
	double AutoLinearFactorHigh; // 0xd60(0x08)
	double AutoSplineTangentLengthCoef; // 0xd68(0x08)
	double AutoSplineTangentHorizCoef; // 0xd70(0x08)
	double AutoSplineTangentVertCoef; // 0xd78(0x08)
	bool Auto Set Spline Ends; // 0xd80(0x01)
	bool Auto Set Spline Mids; // 0xd81(0x01)
	char pad_D82[0x6]; // 0xd82(0x06)
	struct TArray<struct UMaterialInstanceDynamic*> SplineMaterials; // 0xd88(0x10)
	struct FGameplayTagContainer BlockInteractTags; // 0xd98(0x20)
	double TilingDivisor; // 0xdb8(0x08)

	void GetMIDForSplineMeshComp(struct USplineMeshComponent* SplineMeshComp, int32_t ElementIndex, struct UMaterialInstanceDynamic*& Mid); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.GetMIDForSplineMeshComp // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UpdateSplineMeshMaterials(struct USplineMeshComponent* SplineMeshComp, int32_t SplineIndex); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.UpdateSplineMeshMaterials // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void CreateSplineMesh(int32_t FirstPoint, int32_t SecondPoint); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.CreateSplineMesh // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetInteractionCollision(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.SetInteractionCollision // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetCableTilingBySplineLength(struct UMeshComponent* Target); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.SetCableTilingBySplineLength // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void GetAutoHorizAndVertVectors(struct FVector highVector, struct FVector LowVector, struct FVector& VertVec, struct FVector& HorizVec); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.GetAutoHorizAndVertVectors // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Calc Auto Location At Alpha(double InAlpha, bool DrawDebug, struct FVector& PointLocation); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.Calc Auto Location At Alpha // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetSplinePositionAndTangent(bool SetPosition, bool SetTangent, int32_t ID); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.SetSplinePositionAndTangent // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void CalculatePositionOfPoles(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.CalculatePositionOfPoles // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void AutoSmoothTanget(struct FVector Tangent, struct FVector PointA, struct FVector PointB, struct FVector& SmoothedTangent); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.AutoSmoothTanget // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
	void AddSplineMeshSegment(struct USplineMeshComponent*& SplineMeshSegment); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.AddSplineMeshSegment // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UserConstructionScript(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void HandlePoleDied(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.HandlePoleDied // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnZipliningStarted(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.OnZipliningStarted // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnZipliningStopped(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent, float ZiplineUsageDuration); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.OnZipliningStopped // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_BP_Athena_Environmental_ZipLine_Spline(int32_t EntryPoint); // Function BP_Athena_Environmental_ZipLine_Spline.BP_Athena_Environmental_ZipLine_Spline_C.ExecuteUbergraph_BP_Athena_Environmental_ZipLine_Spline // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

