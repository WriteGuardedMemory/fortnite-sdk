// BlueprintGeneratedClass BulletWhipTrackerComponent_Crossbow.BulletWhipTrackerComponent_Crossbow_C
// Size: 0xf8 (Inherited: 0xf8)
struct UBulletWhipTrackerComponent_Crossbow_C : UBulletWhipTrackerComponentBase {
};

