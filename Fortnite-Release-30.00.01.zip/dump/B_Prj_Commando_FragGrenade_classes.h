// BlueprintGeneratedClass B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C
// Size: 0xdac (Inherited: 0xab8)
struct AB_Prj_Commando_FragGrenade_C : AFortProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xab8(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0xac0(0x08)
	struct UParticleSystemComponent* Fuse_Particle; // 0xac8(0x08)
	struct UStaticMeshComponent* Mesh; // 0xad0(0x08)
	struct UAudioComponent* GrenadeFuse_AudioComponent; // 0xad8(0x08)
	struct UParticleSystemComponent* Effect_Distance; // 0xae0(0x08)
	struct UParticleSystem* P_Explosion; // 0xae8(0x08)
	struct USoundBase* Cue_DistantSound; // 0xaf0(0x08)
	struct USoundBase* Cue_CloseSound; // 0xaf8(0x08)
	double ExplosionRadius; // 0xb00(0x08)
	int32_t NumberOfBouncesTillExplode; // 0xb08(0x04)
	int32_t CurrentNumberOfBounces; // 0xb0c(0x04)
	struct USoundBase* Cue_GrenadeFuseSound; // 0xb10(0x08)
	double BouncePawnAgainstPawnGravityScale; // 0xb18(0x08)
	struct UForceFeedbackEffect* ExplosionForceFeedbackNear; // 0xb20(0x08)
	struct UForceFeedbackEffect* ExplosionForceFeedbackFar; // 0xb28(0x08)
	int32_t MaxClusterGrenades; // 0xb30(0x04)
	struct FGameplayTag EC_ClusterExplosion; // 0xb34(0x04)
	bool bHasCluster; // 0xb38(0x01)
	char pad_B39[0x7]; // 0xb39(0x07)
	struct AFortProjectileBase* Prj_Cluster; // 0xb40(0x08)
	struct FFortGameplayEffectContainerSpec ClusterContainerSpec; // 0xb48(0xb8)
	bool bHasKeepOut; // 0xc00(0x01)
	char pad_C01[0x7]; // 0xc01(0x07)
	struct FFortGameplayEffectContainerSpec KeepOutContainerSpec; // 0xc08(0xb8)
	struct AFortAreaOfEffectCloud* AOE_KeepOut; // 0xcc0(0x08)
	bool bHasClusterTactical; // 0xcc8(0x01)
	char pad_CC9[0x7]; // 0xcc9(0x07)
	struct FFortGameplayEffectContainerSpec Cluster_Tactical_Container_Spec; // 0xcd0(0xb8)
	struct FGameplayTagContainer TC_ActorTagsThatShouldExplodeOnOverlap; // 0xd88(0x20)
	struct FGameplayTag T_Event_GrenadeExploded; // 0xda8(0x04)

	void SpawnKeepOut(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.SpawnKeepOut // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SpawnClusters(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.SpawnClusters // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	double CalcGrenadeSpeed(double Angle); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.CalcGrenadeSpeed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
	void OnRep_StoredHit(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.OnRep_StoredHit // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UserConstructionScript(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnStop(struct FHitResult& Hit); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void Stop_Rotation(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.Stop_Rotation // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnExploded(struct TArray<struct AActor*>& HitActors, struct TArray<struct FHitResult>& HitResults); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ReceiveAnyDamage // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnBounce(struct FHitResult& Hit); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.OnBounce // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void On Destroy Grenade(struct AActor* DestroyedActor); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.On Destroy Grenade // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Bind Destroy Grenade(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.Bind Destroy Grenade // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Force On Exploded Effects(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.Force On Exploded Effects // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Unbind Destroy Grenade(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.Unbind Destroy Grenade // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void TriggerDoExplsoion(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.TriggerDoExplsoion // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveDestroyed(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void CheckKeepOutAndCluster(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.CheckKeepOutAndCluster // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void SendExplodedEvent(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.SendExplodedEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_B_Prj_Commando_FragGrenade(int32_t EntryPoint); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ExecuteUbergraph_B_Prj_Commando_FragGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

