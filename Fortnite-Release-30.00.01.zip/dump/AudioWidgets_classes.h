// Class AudioWidgets.AudioMaterialButton
// Size: 0x208 (Inherited: 0x160)
struct UAudioMaterialButton : UWidget {
	struct FAudioMaterialButtonStyle WidgetStyle; // 0x160(0x80)
	struct FMulticastInlineDelegate OnButtonPressedChangedEvent; // 0x1e0(0x10)
	bool bIsPressed; // 0x1f0(0x01)
	char pad_1F1[0x17]; // 0x1f1(0x17)

	void SetIsPressed(bool InPressed); // Function AudioWidgets.AudioMaterialButton.SetIsPressed // (Final|Native|Public|BlueprintCallable) // @ game+0x855eed8
	bool GetIsPressed(); // Function AudioWidgets.AudioMaterialButton.GetIsPressed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855d8e8
};

// Class AudioWidgets.AudioMaterialEnvelope
// Size: 0x1e8 (Inherited: 0x160)
struct UAudioMaterialEnvelope : UWidget {
	struct FAudioMaterialEnvelopeStyle WidgetStyle; // 0x160(0x50)
	struct FAudioMaterialEnvelopeSettings EnvelopeSettings; // 0x1b0(0x24)
	char pad_1D4[0x14]; // 0x1d4(0x14)
};

// Class AudioWidgets.AudioMaterialKnob
// Size: 0x340 (Inherited: 0x160)
struct UAudioMaterialKnob : UWidget {
	struct FAudioMaterialKnobStyle WidgetStyle; // 0x160(0x1a0)
	struct FMulticastInlineDelegate OnKnobValueChanged; // 0x300(0x10)
	float Value; // 0x310(0x04)
	float TuneSpeed; // 0x314(0x04)
	float FineTuneSpeed; // 0x318(0x04)
	bool bLocked; // 0x31c(0x01)
	bool bMouseUsesStep; // 0x31d(0x01)
	char pad_31E[0x2]; // 0x31e(0x02)
	float StepSize; // 0x320(0x04)
	char pad_324[0x1c]; // 0x324(0x1c)

	void SetValue(float InValue); // Function AudioWidgets.AudioMaterialKnob.SetValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8561808
	void SetTuneSpeed(float InValue); // Function AudioWidgets.AudioMaterialKnob.SetTuneSpeed // (Final|Native|Public|BlueprintCallable) // @ game+0x8561328
	void SetStepSize(float InValue); // Function AudioWidgets.AudioMaterialKnob.SetStepSize // (Final|Native|Public|BlueprintCallable) // @ game+0x8560fe0
	void SetMouseUsesStep(bool InUsesStep); // Function AudioWidgets.AudioMaterialKnob.SetMouseUsesStep // (Final|Native|Public|BlueprintCallable) // @ game+0x85604e8
	void SetLocked(bool InLocked); // Function AudioWidgets.AudioMaterialKnob.SetLocked // (Final|Native|Public|BlueprintCallable) // @ game+0x855efb8
	void SetFineTuneSpeed(float InValue); // Function AudioWidgets.AudioMaterialKnob.SetFineTuneSpeed // (Final|Native|Public|BlueprintCallable) // @ game+0x855ec80
	float GetValue(); // Function AudioWidgets.AudioMaterialKnob.GetValue // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x855ea90
	float GetTuneSpeed(); // Function AudioWidgets.AudioMaterialKnob.GetTuneSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855ea60
	float GetStepSize(); // Function AudioWidgets.AudioMaterialKnob.GetStepSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x834412c
	bool GetMouseUsesStep(); // Function AudioWidgets.AudioMaterialKnob.GetMouseUsesStep // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855e784
	bool GetIsLocked(); // Function AudioWidgets.AudioMaterialKnob.GetIsLocked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855d8b8
	float GetFineTuneSpeed(); // Function AudioWidgets.AudioMaterialKnob.GetFineTuneSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855d888
};

// Class AudioWidgets.AudioMaterialMeter
// Size: 0x280 (Inherited: 0x160)
struct UAudioMaterialMeter : UWidget {
	struct FAudioMaterialMeterStyle WidgetStyle; // 0x160(0xf0)
	enum class EOrientation orientation; // 0x250(0x01)
	char pad_251[0x3]; // 0x251(0x03)
	struct FDelegate MeterChannelInfoDelegate; // 0x254(0x0c)
	char pad_260[0x10]; // 0x260(0x10)
	struct TArray<struct FMeterChannelInfo> MeterChannelInfo; // 0x270(0x10)

	void SetMeterChannelInfo(struct TArray<struct FMeterChannelInfo>& InMeterChannelInfo); // Function AudioWidgets.AudioMaterialMeter.SetMeterChannelInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x855f250
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo__DelegateSignature(); // DelegateFunction AudioWidgets.AudioMaterialMeter.GetMeterChannelInfo__DelegateSignature // (Public|Delegate) // @ game+0x18e3f1c
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo(); // Function AudioWidgets.AudioMaterialMeter.GetMeterChannelInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855d9d4
};

// Class AudioWidgets.AudioMaterialSlider
// Size: 0x300 (Inherited: 0x160)
struct UAudioMaterialSlider : UWidget {
	struct FAudioMaterialSliderStyle WidgetStyle; // 0x160(0x160)
	struct FMulticastInlineDelegate OnValueChanged; // 0x2c0(0x10)
	float Value; // 0x2d0(0x04)
	enum class EOrientation orientation; // 0x2d4(0x01)
	char pad_2D5[0x3]; // 0x2d5(0x03)
	float TuneSpeed; // 0x2d8(0x04)
	float FineTuneSpeed; // 0x2dc(0x04)
	bool bLocked; // 0x2e0(0x01)
	bool bMouseUsesStep; // 0x2e1(0x01)
	char pad_2E2[0x2]; // 0x2e2(0x02)
	float StepSize; // 0x2e4(0x04)
	char pad_2E8[0x18]; // 0x2e8(0x18)

	void SetValue(float InValue); // Function AudioWidgets.AudioMaterialSlider.SetValue // (Final|Native|Public|BlueprintCallable) // @ game+0x85618cc
	void SetTuneSpeed(float InValue); // Function AudioWidgets.AudioMaterialSlider.SetTuneSpeed // (Final|Native|Public|BlueprintCallable) // @ game+0x85613ec
	void SetStepSize(float InValue); // Function AudioWidgets.AudioMaterialSlider.SetStepSize // (Final|Native|Public|BlueprintCallable) // @ game+0x85610a4
	void SetMouseUsesStep(bool bInUsesStep); // Function AudioWidgets.AudioMaterialSlider.SetMouseUsesStep // (Final|Native|Public|BlueprintCallable) // @ game+0x85605c4
	void SetLocked(bool bInLocked); // Function AudioWidgets.AudioMaterialSlider.SetLocked // (Final|Native|Public|BlueprintCallable) // @ game+0x855f094
	void SetFineTuneSpeed(float InValue); // Function AudioWidgets.AudioMaterialSlider.SetFineTuneSpeed // (Final|Native|Public|BlueprintCallable) // @ game+0x855ed44
	float GetValue(); // Function AudioWidgets.AudioMaterialSlider.GetValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855eaa8
	float GetTuneSpeed(); // Function AudioWidgets.AudioMaterialSlider.GetTuneSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855ea78
	float GetStepSize(); // Function AudioWidgets.AudioMaterialSlider.GetStepSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855ea48
	bool GetMouseUsesStep(); // Function AudioWidgets.AudioMaterialSlider.GetMouseUsesStep // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855e79c
	bool GetIsLocked(); // Function AudioWidgets.AudioMaterialSlider.GetIsLocked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855d8d0
	float GetFineTuneSpeed(); // Function AudioWidgets.AudioMaterialSlider.GetFineTuneSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855d8a0
};

// Class AudioWidgets.AudioMaterialKnobWidgetStyle
// Size: 0x1d0 (Inherited: 0x30)
struct UAudioMaterialKnobWidgetStyle : USlateWidgetStyleContainerBase {
	struct FAudioMaterialKnobStyle KnobStyle; // 0x30(0x1a0)
};

// Class AudioWidgets.AudioMaterialMeterWidgetStyle
// Size: 0x120 (Inherited: 0x30)
struct UAudioMaterialMeterWidgetStyle : USlateWidgetStyleContainerBase {
	struct FAudioMaterialMeterStyle MeterStyle; // 0x30(0xf0)
};

// Class AudioWidgets.AudioMaterialButtonWidgetStyle
// Size: 0xb0 (Inherited: 0x30)
struct UAudioMaterialButtonWidgetStyle : USlateWidgetStyleContainerBase {
	struct FAudioMaterialButtonStyle ButtonStyle; // 0x30(0x80)
};

// Class AudioWidgets.AudioMaterialSliderWidgetStyle
// Size: 0x190 (Inherited: 0x30)
struct UAudioMaterialSliderWidgetStyle : USlateWidgetStyleContainerBase {
	struct FAudioMaterialSliderStyle SliderStyle; // 0x30(0x160)
};

// Class AudioWidgets.AudioMaterialEnvelopeWidgetStyle
// Size: 0x80 (Inherited: 0x30)
struct UAudioMaterialEnvelopeWidgetStyle : USlateWidgetStyleContainerBase {
	struct FAudioMaterialEnvelopeStyle EnvelopeStyle; // 0x30(0x50)
};

// Class AudioWidgets.AudioMeter
// Size: 0x690 (Inherited: 0x160)
struct UAudioMeter : UWidget {
	struct TArray<struct FMeterChannelInfo> MeterChannelInfo; // 0x160(0x10)
	struct FDelegate MeterChannelInfoDelegate; // 0x170(0x0c)
	char pad_17C[0x4]; // 0x17c(0x04)
	struct FAudioMeterStyle WidgetStyle; // 0x180(0x480)
	enum class EOrientation orientation; // 0x600(0x01)
	char pad_601[0x3]; // 0x601(0x03)
	struct FLinearColor BackgroundColor; // 0x604(0x10)
	struct FLinearColor MeterBackgroundColor; // 0x614(0x10)
	struct FLinearColor MeterValueColor; // 0x624(0x10)
	struct FLinearColor MeterPeakColor; // 0x634(0x10)
	struct FLinearColor MeterClippingColor; // 0x644(0x10)
	struct FLinearColor MeterScaleColor; // 0x654(0x10)
	struct FLinearColor MeterScaleLabelColor; // 0x664(0x10)
	char pad_674[0x1c]; // 0x674(0x1c)

	void SetMeterValueColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterValueColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560408
	void SetMeterScaleLabelColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560328
	void SetMeterScaleColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterScaleColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560248
	void SetMeterPeakColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterPeakColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560168
	void SetMeterClippingColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterClippingColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560088
	void SetMeterChannelInfo(struct TArray<struct FMeterChannelInfo>& InMeterChannelInfo); // Function AudioWidgets.AudioMeter.SetMeterChannelInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x855f96c
	void SetMeterBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x855f170
	void SetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x855eac0
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo__DelegateSignature(); // DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature // (Public|Delegate) // @ game+0x18e3f1c
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo(); // Function AudioWidgets.AudioMeter.GetMeterChannelInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x855e0ac
};

// Class AudioWidgets.AudioOscilloscope
// Size: 0x650 (Inherited: 0x160)
struct UAudioOscilloscope : UWidget {
	struct FAudioOscilloscopePanelStyle OscilloscopeStyle; // 0x160(0x470)
	struct UAudioBus* AudioBus; // 0x5d0(0x08)
	float MaxTimeWindowMs; // 0x5d8(0x04)
	float TimeWindowMs; // 0x5dc(0x04)
	float AnalysisPeriodMs; // 0x5e0(0x04)
	bool bShowTimeGrid; // 0x5e4(0x01)
	enum class EXAxisLabelsUnit TimeGridLabelsUnit; // 0x5e5(0x01)
	bool bShowAmplitudeGrid; // 0x5e6(0x01)
	bool bShowAmplitudeLabels; // 0x5e7(0x01)
	enum class EYAxisLabelsUnit AmplitudeGridLabelsUnit; // 0x5e8(0x01)
	enum class EAudioOscilloscopeTriggerMode TriggerMode; // 0x5e9(0x01)
	char pad_5EA[0x2]; // 0x5ea(0x02)
	float TriggerThreshold; // 0x5ec(0x04)
	enum class EAudioPanelLayoutType PanelLayoutType; // 0x5f0(0x01)
	char pad_5F1[0x3]; // 0x5f1(0x03)
	int32_t ChannelToAnalyze; // 0x5f4(0x04)
	char pad_5F8[0x58]; // 0x5f8(0x58)

	void StopProcessing(); // Function AudioWidgets.AudioOscilloscope.StopProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0x8561d28
	void StartProcessing(); // Function AudioWidgets.AudioOscilloscope.StartProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0x8561cd8
	struct TArray<float> GetOscilloscopeAudioSamples__DelegateSignature(); // DelegateFunction AudioWidgets.AudioOscilloscope.GetOscilloscopeAudioSamples__DelegateSignature // (Public|Delegate) // @ game+0x18e3f1c
	bool CanTriggeringBeSet(); // Function AudioWidgets.AudioOscilloscope.CanTriggeringBeSet // (Final|Native|Private) // @ game+0x855d868
};

// Class AudioWidgets.AudioRadialSlider
// Size: 0x360 (Inherited: 0x160)
struct UAudioRadialSlider : UWidget {
	float Value; // 0x160(0x04)
	struct FDelegate ValueDelegate; // 0x164(0x0c)
	enum class EAudioRadialSliderLayout WidgetLayout; // 0x170(0x01)
	char pad_171[0x3]; // 0x171(0x03)
	struct FLinearColor CenterBackgroundColor; // 0x174(0x10)
	struct FLinearColor SliderProgressColor; // 0x184(0x10)
	struct FLinearColor SliderBarColor; // 0x194(0x10)
	char pad_1A4[0x4]; // 0x1a4(0x04)
	struct FVector2D HandStartEndRatio; // 0x1a8(0x10)
	struct FText UnitsText; // 0x1b8(0x10)
	struct FLinearColor TextLabelBackgroundColor; // 0x1c8(0x10)
	bool ShowLabelOnlyOnHover; // 0x1d8(0x01)
	bool ShowUnitsText; // 0x1d9(0x01)
	bool IsUnitsTextReadOnly; // 0x1da(0x01)
	bool IsValueTextReadOnly; // 0x1db(0x01)
	float SliderThickness; // 0x1dc(0x04)
	struct FVector2D OutputRange; // 0x1e0(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x1f0(0x10)
	char pad_200[0x160]; // 0x200(0x160)

	void SetWidgetLayout(enum class EAudioRadialSliderLayout InLayout); // Function AudioWidgets.AudioRadialSlider.SetWidgetLayout // (Final|Native|Public|BlueprintCallable) // @ game+0x8561c10
	void SetValueTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioRadialSlider.SetValueTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8561990
	void SetUnitsTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8561668
	void SetUnitsText(struct FText Units); // Function AudioWidgets.AudioRadialSlider.SetUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0x85614b0
	void SetTextLabelBackgroundColor(struct FSlateColor InColor); // Function AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor // (Final|Native|Public|BlueprintCallable) // @ game+0x8561168
	void SetSliderThickness(float InThickness); // Function AudioWidgets.AudioRadialSlider.SetSliderThickness // (Final|Native|Public|BlueprintCallable) // @ game+0x8560e34
	void SetSliderProgressColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560d54
	void SetSliderBarColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetSliderBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560b94
	void SetShowUnitsText(bool bShowUnitsText); // Function AudioWidgets.AudioRadialSlider.SetShowUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0x8560914
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // Function AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover // (Final|Native|Public|BlueprintCallable) // @ game+0x8560774
	void SetOutputRange(struct FVector2D InOutputRange); // Function AudioWidgets.AudioRadialSlider.SetOutputRange // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x85606a0
	void SetHandStartEndRatio(struct FVector2D InHandStartEndRatio); // Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x855ee08
	void SetCenterBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x855eba0
	float GetSliderValue(float OutputValue); // Function AudioWidgets.AudioRadialSlider.GetSliderValue // (Final|Native|Public|BlueprintCallable) // @ game+0x855e96c
	float GetOutputValue(float InSliderValue); // Function AudioWidgets.AudioRadialSlider.GetOutputValue // (Final|Native|Public|BlueprintCallable) // @ game+0x855e7b4
};

// Class AudioWidgets.AudioVolumeRadialSlider
// Size: 0x360 (Inherited: 0x360)
struct UAudioVolumeRadialSlider : UAudioRadialSlider {
};

// Class AudioWidgets.AudioFrequencyRadialSlider
// Size: 0x360 (Inherited: 0x360)
struct UAudioFrequencyRadialSlider : UAudioRadialSlider {
};

// Class AudioWidgets.AudioSliderBase
// Size: 0x910 (Inherited: 0x160)
struct UAudioSliderBase : UWidget {
	float Value; // 0x160(0x04)
	char pad_164[0x4]; // 0x164(0x04)
	struct FText UnitsText; // 0x168(0x10)
	struct FLinearColor TextLabelBackgroundColor; // 0x178(0x10)
	struct FDelegate TextLabelBackgroundColorDelegate; // 0x188(0x0c)
	bool ShowLabelOnlyOnHover; // 0x194(0x01)
	bool ShowUnitsText; // 0x195(0x01)
	bool IsUnitsTextReadOnly; // 0x196(0x01)
	bool IsValueTextReadOnly; // 0x197(0x01)
	struct FDelegate ValueDelegate; // 0x198(0x0c)
	struct FLinearColor SliderBackgroundColor; // 0x1a4(0x10)
	struct FDelegate SliderBackgroundColorDelegate; // 0x1b4(0x0c)
	struct FLinearColor SliderBarColor; // 0x1c0(0x10)
	struct FDelegate SliderBarColorDelegate; // 0x1d0(0x0c)
	struct FLinearColor SliderThumbColor; // 0x1dc(0x10)
	struct FDelegate SliderThumbColorDelegate; // 0x1ec(0x0c)
	struct FLinearColor WidgetBackgroundColor; // 0x1f8(0x10)
	struct FDelegate WidgetBackgroundColorDelegate; // 0x208(0x0c)
	enum class EOrientation orientation; // 0x214(0x01)
	char pad_215[0x3]; // 0x215(0x03)
	struct FMulticastInlineDelegate OnValueChanged; // 0x218(0x10)
	char pad_228[0x6e8]; // 0x228(0x6e8)

	void SetWidgetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8561b30
	void SetValueTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8561a60
	void SetUnitsTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8561738
	void SetUnitsText(struct FText Units); // Function AudioWidgets.AudioSliderBase.SetUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0x856158c
	void SetTextLabelBackgroundColor(struct FSlateColor InColor); // Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor // (Final|Native|Public|BlueprintCallable) // @ game+0x8561248
	void SetSliderThumbColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderThumbColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560f00
	void SetSliderBarColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560c74
	void SetSliderBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8560ab4
	void SetShowUnitsText(bool bShowUnitsText); // Function AudioWidgets.AudioSliderBase.SetShowUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0x85609e4
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover // (Final|Native|Public|BlueprintCallable) // @ game+0x8560844
	float GetSliderValue(float OutputValue); // Function AudioWidgets.AudioSliderBase.GetSliderValue // (Final|Native|Public|BlueprintCallable) // @ game+0x855d900
	float GetOutputValue(float InSliderValue); // Function AudioWidgets.AudioSliderBase.GetOutputValue // (Final|Native|Public|BlueprintCallable) // @ game+0x855e890
	float GetLinValue(float OutputValue); // Function AudioWidgets.AudioSliderBase.GetLinValue // (Final|Native|Public|BlueprintCallable) // @ game+0x855d900
};

// Class AudioWidgets.AudioSlider
// Size: 0x920 (Inherited: 0x910)
struct UAudioSlider : UAudioSliderBase {
	struct TWeakObjectPtr<struct UCurveFloat> LinToOutputCurve; // 0x910(0x08)
	struct TWeakObjectPtr<struct UCurveFloat> OutputToLinCurve; // 0x918(0x08)
};

// Class AudioWidgets.AudioVolumeSlider
// Size: 0x920 (Inherited: 0x920)
struct UAudioVolumeSlider : UAudioSlider {
};

// Class AudioWidgets.AudioFrequencySlider
// Size: 0x920 (Inherited: 0x910)
struct UAudioFrequencySlider : UAudioSliderBase {
	struct FVector2D OutputRange; // 0x910(0x10)
};

// Class AudioWidgets.AudioVectorscope
// Size: 0x370 (Inherited: 0x160)
struct UAudioVectorscope : UWidget {
	struct FAudioVectorscopePanelStyle VectorscopeStyle; // 0x160(0x1a0)
	struct UAudioBus* AudioBus; // 0x300(0x08)
	bool bShowGrid; // 0x308(0x01)
	char pad_309[0x3]; // 0x309(0x03)
	int32_t GridDivisions; // 0x30c(0x04)
	float MaxDisplayPersistenceMs; // 0x310(0x04)
	float DisplayPersistenceMs; // 0x314(0x04)
	float Scale; // 0x318(0x04)
	enum class EAudioPanelLayoutType PanelLayoutType; // 0x31c(0x01)
	char pad_31D[0x53]; // 0x31d(0x53)

	void StopProcessing(); // Function AudioWidgets.AudioVectorscope.StopProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0x8561d50
	void StartProcessing(); // Function AudioWidgets.AudioVectorscope.StartProcessing // (Final|Native|Public|BlueprintCallable) // @ game+0x8561d00
	struct TArray<float> GetVectorscopeAudioSamples__DelegateSignature(); // DelegateFunction AudioWidgets.AudioVectorscope.GetVectorscopeAudioSamples__DelegateSignature // (Public|Delegate) // @ game+0x18e3f1c
};

