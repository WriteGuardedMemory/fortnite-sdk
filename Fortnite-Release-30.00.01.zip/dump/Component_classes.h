// Class Component.CameraEntityProxyActor
// Size: 0x9b0 (Inherited: 0x9b0)
struct ACameraEntityProxyActor : ACameraActor {
};

// Class Component.LightProxyActor
// Size: 0x298 (Inherited: 0x290)
struct ALightProxyActor : AActor {
	struct ULightComponent* LightComponent; // 0x290(0x08)
};

// Class Component.ParticleSystemProxyActor
// Size: 0x298 (Inherited: 0x290)
struct AParticleSystemProxyActor : AActor {
	struct UNiagaraComponent* NiagaraComponent; // 0x290(0x08)
};

// Class Component.PhysicsEntityComponent_Implementation
// Size: 0x1d0 (Inherited: 0x28)
struct UPhysicsEntityComponent_Implementation : UObject {
	struct FBodyInstance BodyInstance; // 0x28(0x198)
	char pad_1C0[0x10]; // 0x1c0(0x10)
};

// Class Component.SoundProxyActor
// Size: 0x2a0 (Inherited: 0x290)
struct ASoundProxyActor : AActor {
	float StartTime; // 0x290(0x04)
	char pad_294[0x4]; // 0x294(0x04)
	struct UAudioComponent* AudioComponent; // 0x298(0x08)

	void OnRep_StartTime(); // Function Component.SoundProxyActor.OnRep_StartTime // (Final|Native|Private) // @ game+0x7f575c0
};

// Class Component.StaticMeshEntityComponent_Implementation
// Size: 0x200 (Inherited: 0x28)
struct UStaticMeshEntityComponent_Implementation : UObject {
	char pad_28[0x1d8]; // 0x28(0x1d8)
};

// Class Component.TextDisplayProxyActor
// Size: 0x2a0 (Inherited: 0x290)
struct ATextDisplayProxyActor : AActor {
	struct UTextRenderComponent* TextRenderComponent; // 0x290(0x08)
	struct UMaterialInterface* TextMaterial; // 0x298(0x08)
};

