// BlueprintGeneratedClass Athena_ButtonStyle_CollectionTab.Athena_ButtonStyle_CollectionTab_C
// Size: 0x730 (Inherited: 0x730)
struct UAthena_ButtonStyle_CollectionTab_C : UCommonButtonStyle {
};

