// BlueprintGeneratedClass BlueprintDebuggingInterface.BlueprintDebuggingInterface_C
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintDebuggingInterface_C : UInterface {

	void GetBlueprintLogLevel(enum class BlueprintLogLevel& BlueprintLogLevel); // Function BlueprintDebuggingInterface.BlueprintDebuggingInterface_C.GetBlueprintLogLevel // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
};

