// BlueprintGeneratedClass CommonUI_Guitar_Xbox_BrushData.CommonUI_Guitar_Xbox_BrushData_C
// Size: 0xd0 (Inherited: 0xd0)
struct UCommonUI_Guitar_Xbox_BrushData_C : UFortInputControllerData {
};

