// BlueprintGeneratedClass ButtonStyle-Tab-Main-Recolor.ButtonStyle-Tab-Main-Recolor_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Tab-Main-Recolor_C : UCommonButtonStyle {
};

