// ScriptStruct BlendStack.BlendStackAnimNodeReference
// Size: 0x10 (Inherited: 0x10)
struct FBlendStackAnimNodeReference : FAnimNodeReference {
};

// ScriptStruct BlendStack.BlendStackInputAnimNodeReference
// Size: 0x10 (Inherited: 0x10)
struct FBlendStackInputAnimNodeReference : FAnimNodeReference {
};

// ScriptStruct BlendStack.BlendStackAnimPlayer
// Size: 0x388 (Inherited: 0x00)
struct FBlendStackAnimPlayer {
	char pad_0[0x20]; // 0x00(0x20)
	struct FAnimNode_SequencePlayer_Standalone SequencePlayerNode; // 0x20(0x90)
	struct FAnimNode_BlendSpacePlayer_Standalone BlendSpacePlayerNode; // 0xb0(0x90)
	struct FAnimNode_Mirror_Standalone MirrorNode; // 0x140(0x60)
	char pad_1A0[0x1e8]; // 0x1a0(0x1e8)
};

// ScriptStruct BlendStack.AnimNode_BlendStack_Standalone
// Size: 0xb0 (Inherited: 0x38)
struct FAnimNode_BlendStack_Standalone : FAnimNode_AssetPlayerBase {
	char pad_38[0x10]; // 0x38(0x10)
	struct TArray<struct FPoseLink> PerSampleGraphPoseLinks; // 0x48(0x10)
	char pad_58[0x8]; // 0x58(0x08)
	struct TArray<struct FBlendStackAnimPlayer> AnimPlayers; // 0x60(0x10)
	bool bShouldFilterNotifies; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	int32_t MaxActiveBlends; // 0x74(0x04)
	bool bStoreBlendedPose; // 0x78(0x01)
	char pad_79[0x27]; // 0x79(0x27)
	float NotifyRecencyTimeOut; // 0xa0(0x04)
	float MaxBlendInTimeToOverrideAnimation; // 0xa4(0x04)
	float PlayerDepthBlendInTimeMultiplier; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// ScriptStruct BlendStack.AnimNode_BlendStack
// Size: 0x120 (Inherited: 0xb0)
struct FAnimNode_BlendStack : FAnimNode_BlendStack_Standalone {
	struct UAnimationAsset* AnimationAsset; // 0xb0(0x08)
	float AnimationTime; // 0xb8(0x04)
	bool bLoop; // 0xbc(0x01)
	bool bMirrored; // 0xbd(0x01)
	char pad_BE[0x2]; // 0xbe(0x02)
	float WantedPlayRate; // 0xc0(0x04)
	float BlendTime; // 0xc4(0x04)
	float MaxAnimationDeltaTime; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct UBlendProfile* BlendProfile; // 0xd0(0x08)
	enum class EAlphaBlendOption BlendOption; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct FVector BlendParameters; // 0xe0(0x18)
	struct UMirrorDataTable* MirrorDataTable; // 0xf8(0x08)
	bool bUseInertialBlend; // 0x100(0x01)
	bool bResetOnBecomingRelevant; // 0x101(0x01)
	char pad_102[0x1e]; // 0x102(0x1e)
};

// ScriptStruct BlendStack.AnimNode_BlendStackInput
// Size: 0x28 (Inherited: 0x10)
struct FAnimNode_BlendStackInput : FAnimNode_Base {
	int32_t SampleIndex; // 0x10(0x04)
	int32_t BlendStackAllocationIndex; // 0x14(0x04)
	bool bOverridePlayRate; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float PlayRate; // 0x1c(0x04)
	char pad_20[0x8]; // 0x20(0x08)
};

