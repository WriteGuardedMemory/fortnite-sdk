// WidgetBlueprintGeneratedClass CorrectiveActionUnsupportedActionScreen.CorrectiveActionUnsupportedActionScreen_C
// Size: 0x430 (Inherited: 0x430)
struct UCorrectiveActionUnsupportedActionScreen_C : UFortCorrectiveActionUnsupportedActionScreen {
};

