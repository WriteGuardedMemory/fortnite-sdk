// Class CameraModesRuntime.CameraModes_FirstPersonCameraController
// Size: 0x410 (Inherited: 0x3e8)
struct ACameraModes_FirstPersonCameraController : AFortFirstPersonCameraController {
	struct FGameplayTag PreventWeaponHolsterTag; // 0x3e8(0x04)
	float HeadMotionScalar; // 0x3ec(0x04)
	struct TArray<struct AFortWeapon*> AllowedWeaponClassList; // 0x3f0(0x10)
	struct USkeletalMeshComponent* FirstPersonSkeletalMeshComp; // 0x400(0x08)
	char pad_408[0x8]; // 0x408(0x08)

	void UpdateFirstPersonFOV(float FOV); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.UpdateFirstPersonFOV // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void SetFovOverride(float FOV, float TransitionTime); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.SetFovOverride // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnLocalPlayerVisibilityChanged(bool bShouldBeVisible); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.OnLocalPlayerVisibilityChanged // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HandleWeaponEquipped(struct AFortWeapon* NewWeapon, struct AFortWeapon* PrevWeapon); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.HandleWeaponEquipped // (Final|Native|Private) // @ game+0xcb77e44
	void ClearFovOverride(float TransitionTime); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.ClearFovOverride // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
};

// Class CameraModesRuntime.FortCheatManager_CameraModes
// Size: 0x30 (Inherited: 0x28)
struct UFortCheatManager_CameraModes : UChildCheatManager {
	struct AFortCustomCameraController* CameraControllerClass; // 0x28(0x08)

	void EnableFpCameraForAllPlayers(bool bEnable); // Function CameraModesRuntime.FortCheatManager_CameraModes.EnableFpCameraForAllPlayers // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x69a0760
	void EnableFpCamera(bool bEnable); // Function CameraModesRuntime.FortCheatManager_CameraModes.EnableFpCamera // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x69a0760
};

