// Class AccoladesRuntime.PFWAccoladeCollection_Container
// Size: 0x160 (Inherited: 0x140)
struct UPFWAccoladeCollection_Container : UPersistenceFrameworkContainer {
	char pad_140[0x20]; // 0x140(0x20)
};

// Class AccoladesRuntime.PFWAccoladeCollection_Module
// Size: 0xe0 (Inherited: 0xe0)
struct UPFWAccoladeCollection_Module : UPersistenceFrameworkModule {
};

// Class AccoladesRuntime.PFWAccoladeCollection_Trigger
// Size: 0xc0 (Inherited: 0xc0)
struct UPFWAccoladeCollection_Trigger : UPersistenceFrameworkSaveTrigger_Manual {
};

// Class AccoladesRuntime.PFWAccoladeCollection_FilteredListContainer
// Size: 0x160 (Inherited: 0x150)
struct UPFWAccoladeCollection_FilteredListContainer : UPersistenceFrameworkFilteredListContainer {
	char pad_150[0x10]; // 0x150(0x10)
};

// Class AccoladesRuntime.FortAccoladeCollectionFeatureCollector
// Size: 0x38 (Inherited: 0x28)
struct UFortAccoladeCollectionFeatureCollector : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class AccoladesRuntime.GameFeatureAction_AddAccoladeTable
// Size: 0x48 (Inherited: 0x28)
struct UGameFeatureAction_AddAccoladeTable : UGameFeatureAction {
	struct TSoftObjectPtr<UDataTable> AccoladeTable; // 0x28(0x20)
};

// Class AccoladesRuntime.FortCheatManager_Accolades
// Size: 0x28 (Inherited: 0x28)
struct UFortCheatManager_Accolades : UChildCheatManager {

	void TriggerAccolade(struct FString AccoladeName); // Function AccoladesRuntime.FortCheatManager_Accolades.TriggerAccolade // (Final|BlueprintAuthorityOnly|Exec|Native|Private) // @ game+0x6de75f4
	void ResetAccoladeData(); // Function AccoladesRuntime.FortCheatManager_Accolades.ResetAccoladeData // (Final|BlueprintAuthorityOnly|Exec|Native|Private) // @ game+0x3600a3c
};

// Class AccoladesRuntime.FortControllerComponent_AccoladeCollection
// Size: 0x320 (Inherited: 0xa8)
struct UFortControllerComponent_AccoladeCollection : UFortControllerComponent {
	char pad_A8[0xd0]; // 0xa8(0xd0)
	struct FName PinnedAccoladeName; // 0x178(0x04)
	char pad_17C[0x74]; // 0x17c(0x74)
	struct FPersistenceFrameworkSaveControl SaveControl; // 0x1f0(0x10)
	struct FFortAccoladeCollectionDataArray AccoladeCollectionDataArray; // 0x200(0x120)

	void ServerPinAccolade(struct FName AccoladeName); // Function AccoladesRuntime.FortControllerComponent_AccoladeCollection.ServerPinAccolade // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0xb6631b4
	void ServerMarkAccoladesAsSeen(struct TArray<struct FName> AccoladeNames); // Function AccoladesRuntime.FortControllerComponent_AccoladeCollection.ServerMarkAccoladesAsSeen // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x9723064
	void OnRep_PinnedAccoladeName(struct FName OldPinnedAccoladeName); // Function AccoladesRuntime.FortControllerComponent_AccoladeCollection.OnRep_PinnedAccoladeName // (Final|Native|Private) // @ game+0xb6630e8
	void OnEndMatchForPlayer(struct UFortControllerComponent_EndMatchPersistence* EndMatchPersistence); // Function AccoladesRuntime.FortControllerComponent_AccoladeCollection.OnEndMatchForPlayer // (Final|Native|Private) // @ game+0x655e588
	void HandlePlayerProfileInitialized(); // Function AccoladesRuntime.FortControllerComponent_AccoladeCollection.HandlePlayerProfileInitialized // (Final|Native|Private) // @ game+0xb66309c
	void HandlePinnedQuestChanged(struct FAthenaPinnedQuestData& PinnedQuestData); // Function AccoladesRuntime.FortControllerComponent_AccoladeCollection.HandlePinnedQuestChanged // (Final|Native|Private|HasOutParms) // @ game+0xb663010
	void ClientResetAccoladeData(); // Function AccoladesRuntime.FortControllerComponent_AccoladeCollection.ClientResetAccoladeData // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x8bf0a18
	void ClientNotifyRestored(enum class EPersistenceFrameworkResult Result); // Function AccoladesRuntime.FortControllerComponent_AccoladeCollection.ClientNotifyRestored // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x8eb6400
};

// Class AccoladesRuntime.FortControllerComponent_Accolades
// Size: 0x520 (Inherited: 0xa8)
struct UFortControllerComponent_Accolades : UFortControllerComponent {
	char pad_A8[0x1e8]; // 0xa8(0x1e8)
	struct FFortUpdatedTrackedAccoladeDataArray UpdatedTrackedAccoladeDataArray; // 0x290(0x120)
	struct FFortCompletedAccoladeDataArray CompletedAccoladeDataArray; // 0x3b0(0x120)
	char pad_4D0[0x50]; // 0x4d0(0x50)
};

// Class AccoladesRuntime.FortGameStateComponent_AccoladeCollection
// Size: 0xb0 (Inherited: 0xa0)
struct UFortGameStateComponent_AccoladeCollection : UFortGameStateComponent {
	char pad_A0[0x10]; // 0xa0(0x10)
};

// Class AccoladesRuntime.FortGameStateComponent_Accolades
// Size: 0x198 (Inherited: 0xa0)
struct UFortGameStateComponent_Accolades : UFortGameStateComponent {
	char pad_A0[0xf8]; // 0xa0(0xf8)
};

