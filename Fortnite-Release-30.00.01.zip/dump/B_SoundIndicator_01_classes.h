// BlueprintGeneratedClass B_SoundIndicator_01.B_SoundIndicator_01_C
// Size: 0x800 (Inherited: 0x440)
struct AB_SoundIndicator_01_C : AFortSoundCameraLensEffect {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)
	struct FRuntimeFloatCurve Gunshot Falloff Long Range; // 0x448(0x88)
	struct FRuntimeFloatCurve Chest Falloff; // 0x4d0(0x88)
	struct FRuntimeFloatCurve Footsteps Falloff; // 0x558(0x88)
	struct FRuntimeFloatCurve Gunshot Falloff Mid Range; // 0x5e0(0x88)
	struct FRuntimeFloatCurve Gunshot Falloff Melee; // 0x668(0x88)
	struct FRuntimeFloatCurve Glider Falloff; // 0x6f0(0x88)
	struct FRuntimeFloatCurve Plane Falloff; // 0x778(0x88)

	struct FRuntimeFloatCurve GetStrengthCurveForActiveType(); // Function B_SoundIndicator_01.B_SoundIndicator_01_C.GetStrengthCurveForActiveType // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	struct FLinearColor GetDefaultTint(); // Function B_SoundIndicator_01.B_SoundIndicator_01_C.GetDefaultTint // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	struct UTexture* GetDefaultIcon(); // Function B_SoundIndicator_01.B_SoundIndicator_01_C.GetDefaultIcon // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	struct FRuntimeFloatCurve GetWeaponCurve(); // Function B_SoundIndicator_01.B_SoundIndicator_01_C.GetWeaponCurve // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void ExecuteUbergraph_B_SoundIndicator_01(int32_t EntryPoint); // Function B_SoundIndicator_01.B_SoundIndicator_01_C.ExecuteUbergraph_B_SoundIndicator_01 // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

