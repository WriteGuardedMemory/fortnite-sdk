// Enum ActorEntity.EConsideredForActorEntityInterop
enum class EConsideredForActorEntityInterop : uint8 {
	No = 0,
	Partial = 1,
	Yes = 2,
	EConsideredForActorEntityInterop_MAX = 3
};

// ScriptStruct ActorEntity.ActorEntityMappingArrayItem
// Size: 0x20 (Inherited: 0x0c)
struct FActorEntityMappingArrayItem : FFastArraySerializerItem {
	char pad_C[0x4]; // 0x0c(0x04)
	struct UBaseEntity* Entity; // 0x10(0x08)
	struct UObject* Object; // 0x18(0x08)
};

// ScriptStruct ActorEntity.ActorEntityMappingArray
// Size: 0x130 (Inherited: 0x108)
struct FActorEntityMappingArray : FFastArraySerializer {
	char pad_108[0x18]; // 0x108(0x18)
	struct TArray<struct FActorEntityMappingArrayItem> Entities; // 0x120(0x10)
};

// ScriptStruct ActorEntity.SubEntityInteropRules
// Size: 0x18 (Inherited: 0x00)
struct FSubEntityInteropRules {
	struct FName ComponentName; // 0x00(0x04)
	enum class EConsideredForActorEntityInterop Considered; // 0x04(0x04)
	struct TArray<struct TSoftClassPtr<UObject>> AllowedEntityComponents; // 0x08(0x10)
};

// ScriptStruct ActorEntity.ActorEntityInteropRules
// Size: 0x58 (Inherited: 0x00)
struct FActorEntityInteropRules {
	struct TSoftClassPtr<UObject> ActorClass; // 0x00(0x20)
	enum class EConsideredForActorEntityInterop ActorEntityConsidered; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TArray<struct TSoftClassPtr<UObject>> AllowedEntityComponents; // 0x28(0x10)
	enum class EConsideredForActorEntityInterop SubEntitiesConsidered; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct TArray<struct FSubEntityInteropRules> SubEntityRules; // 0x40(0x10)
	bool bEnableEntityReplication; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

