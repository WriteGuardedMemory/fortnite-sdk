// BlueprintGeneratedClass B_PlayerShieldDamage_LensEffect_Direction.B_PlayerShieldDamage_LensEffect_Direction_C
// Size: 0x3c0 (Inherited: 0x3c0)
struct AB_PlayerShieldDamage_LensEffect_Direction_C : AFortEmitterCameraLensEffectDirectional {
};

