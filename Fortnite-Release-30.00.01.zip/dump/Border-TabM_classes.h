// BlueprintGeneratedClass Border-TabM.Border-TabM_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-TabM_C : UCommonBorderStyle {
};

