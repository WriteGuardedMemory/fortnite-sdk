// BlueprintGeneratedClass Athena_PlayerCameraMode_HidingProp_Teleport.Athena_PlayerCameraMode_HidingProp_Teleport_C
// Size: 0x1cd0 (Inherited: 0x1cd0)
struct UAthena_PlayerCameraMode_HidingProp_Teleport_C : UAthena_PlayerCameraModeBase_C {
};

