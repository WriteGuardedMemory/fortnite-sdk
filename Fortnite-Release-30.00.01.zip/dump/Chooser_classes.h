// Class Chooser.ChooserParameterBool_ContextProperty
// Size: 0x40 (Inherited: 0x28)
struct UChooserParameterBool_ContextProperty : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct FName> PropertyBindingChain; // 0x30(0x10)
};

// Class Chooser.ChooserColumnBool
// Size: 0x50 (Inherited: 0x28)
struct UChooserColumnBool : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TScriptInterface<IChooserParameterBool> InputValue; // 0x30(0x10)
	struct TArray<bool> RowValues; // 0x40(0x10)
};

// Class Chooser.ChooserParameterEnum_ContextProperty
// Size: 0x40 (Inherited: 0x28)
struct UChooserParameterEnum_ContextProperty : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct FName> PropertyBindingChain; // 0x30(0x10)
};

// Class Chooser.ChooserColumnEnum
// Size: 0x50 (Inherited: 0x28)
struct UChooserColumnEnum : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TScriptInterface<IChooserParameterEnum> InputValue; // 0x30(0x10)
	struct TArray<struct FChooserEnumRowData> RowValues; // 0x40(0x10)
};

// Class Chooser.FloatAutoPopulator
// Size: 0x28 (Inherited: 0x28)
struct UFloatAutoPopulator : UObject {

	void AutoPopulate(struct UObject* Object, bool& Success, float& Value); // Function Chooser.FloatAutoPopulator.AutoPopulate // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
};

// Class Chooser.ChooserParameterFloat_ContextProperty
// Size: 0x40 (Inherited: 0x28)
struct UChooserParameterFloat_ContextProperty : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct FName> PropertyBindingChain; // 0x30(0x10)
};

// Class Chooser.ChooserColumnFloatRange
// Size: 0x50 (Inherited: 0x28)
struct UChooserColumnFloatRange : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TScriptInterface<IChooserParameterFloat> InputValue; // 0x30(0x10)
	struct TArray<struct FChooserFloatRangeRowData> RowValues; // 0x40(0x10)
};

// Class Chooser.ChooserParameterGameplayTag_ContextProperty
// Size: 0x40 (Inherited: 0x28)
struct UChooserParameterGameplayTag_ContextProperty : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct FName> PropertyBindingChain; // 0x30(0x10)
};

// Class Chooser.ChooserColumnGameplayTag
// Size: 0x58 (Inherited: 0x28)
struct UChooserColumnGameplayTag : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TScriptInterface<IChooserParameterGameplayTag> InputValue; // 0x30(0x10)
	enum class EGameplayContainerMatchType TagMatchType; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct TArray<struct FGameplayTagContainer> RowValues; // 0x48(0x10)
};

// Class Chooser.ChooserColumn
// Size: 0x28 (Inherited: 0x28)
struct UChooserColumn : UInterface {
};

// Class Chooser.ChooserParameterBool
// Size: 0x28 (Inherited: 0x28)
struct UChooserParameterBool : UInterface {
};

// Class Chooser.ChooserParameterEnum
// Size: 0x28 (Inherited: 0x28)
struct UChooserParameterEnum : UInterface {
};

// Class Chooser.ChooserParameterFloat
// Size: 0x28 (Inherited: 0x28)
struct UChooserParameterFloat : UInterface {
};

// Class Chooser.ChooserParameterGameplayTag
// Size: 0x28 (Inherited: 0x28)
struct UChooserParameterGameplayTag : UInterface {
};

// Class Chooser.HasContextClass
// Size: 0x28 (Inherited: 0x28)
struct UHasContextClass : UInterface {
};

// Class Chooser.ObjectChooser
// Size: 0x28 (Inherited: 0x28)
struct UObjectChooser : UInterface {
};

// Class Chooser.ObjectChooser_Asset
// Size: 0x38 (Inherited: 0x28)
struct UObjectChooser_Asset : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UObject* Asset; // 0x30(0x08)
};

// Class Chooser.ChooserTable
// Size: 0xa0 (Inherited: 0x28)
struct UChooserTable : UObject {
	char pad_28[0x20]; // 0x28(0x20)
	struct UChooserTable* ParentTable; // 0x48(0x08)
	struct FInstancedStruct FallbackResult; // 0x50(0x10)
	struct TArray<struct FInstancedStruct> CookedResults; // 0x60(0x10)
	struct TArray<struct FInstancedStruct> ColumnsStructs; // 0x70(0x10)
	struct TArray<struct FInstancedStruct> ContextData; // 0x80(0x10)
	struct UObject* OutputObjectType; // 0x90(0x08)
	enum class EObjectChooserResultType ResultType; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class Chooser.ObjectChooser_EvaluateChooser
// Size: 0x38 (Inherited: 0x28)
struct UObjectChooser_EvaluateChooser : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UChooserTable* Chooser; // 0x30(0x08)
};

// Class Chooser.ChooserColumnMenuContext
// Size: 0x40 (Inherited: 0x28)
struct UChooserColumnMenuContext : UObject {
	char pad_28[0x18]; // 0x28(0x18)
};

// Class Chooser.ChooserFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UChooserFunctionLibrary : UBlueprintFunctionLibrary {

	struct FInstancedStruct MakeEvaluateChooser(struct UChooserTable* Chooser); // Function Chooser.ChooserFunctionLibrary.MakeEvaluateChooser // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x816d590
	struct FChooserEvaluationContext MakeChooserEvaluationContext(); // Function Chooser.ChooserFunctionLibrary.MakeChooserEvaluationContext // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x816d514
	void GetChooserStructOutput(struct FChooserEvaluationContext& Context, int32_t Index, int32_t& Value); // Function Chooser.ChooserFunctionLibrary.GetChooserStructOutput // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x816cf78
	struct TArray<struct UObject*> EvaluateObjectChooserBaseMulti(struct FChooserEvaluationContext& Context, struct FInstancedStruct& ObjectChooser, struct UObject* ObjectClass, bool bResultIsClass); // Function Chooser.ChooserFunctionLibrary.EvaluateObjectChooserBaseMulti // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x816ccc8
	struct UObject* EvaluateObjectChooserBase(struct FChooserEvaluationContext& Context, struct FInstancedStruct& ObjectChooser, struct UObject* ObjectClass, bool bResultIsClass); // Function Chooser.ChooserFunctionLibrary.EvaluateObjectChooserBase // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x816ca38
	struct TArray<struct UObject*> EvaluateChooserMulti(struct UObject* ContextObject, struct UChooserTable* ChooserTable, struct UObject* ObjectClass); // Function Chooser.ChooserFunctionLibrary.EvaluateChooserMulti // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x816c83c
	struct UObject* EvaluateChooser(struct UObject* ContextObject, struct UChooserTable* ChooserTable, struct UObject* ObjectClass); // Function Chooser.ChooserFunctionLibrary.EvaluateChooser // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x816c668
	void AddChooserStructInput(struct FChooserEvaluationContext& Context, int32_t Value); // Function Chooser.ChooserFunctionLibrary.AddChooserStructInput // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x816c180
	void AddChooserObjectInput(struct FChooserEvaluationContext& Context, struct UObject* Object); // Function Chooser.ChooserFunctionLibrary.AddChooserObjectInput // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x816c018
};

