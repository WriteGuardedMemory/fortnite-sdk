// BlueprintGeneratedClass BP_CharacterRimlightDisabler.BP_CharacterRimlightDisabler_C
// Size: 0x2a0 (Inherited: 0x290)
struct ABP_CharacterRimlightDisabler_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)

	void ReceiveBeginPlay(); // Function BP_CharacterRimlightDisabler.BP_CharacterRimlightDisabler_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_CharacterRimlightDisabler.BP_CharacterRimlightDisabler_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_BP_CharacterRimlightDisabler(int32_t EntryPoint); // Function BP_CharacterRimlightDisabler.BP_CharacterRimlightDisabler_C.ExecuteUbergraph_BP_CharacterRimlightDisabler // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

