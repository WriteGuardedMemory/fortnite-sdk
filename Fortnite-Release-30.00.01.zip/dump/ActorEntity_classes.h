// Class ActorEntity.ActorEntityComponent
// Size: 0x240 (Inherited: 0xa0)
struct UActorEntityComponent : UActorComponent {
	struct FActorEntityMappingArray EntityMappingArray; // 0xa0(0x130)
	char pad_1D0[0x70]; // 0x1d0(0x70)
};

// Class ActorEntity.ActorEntitySubsystem
// Size: 0x98 (Inherited: 0x30)
struct UActorEntitySubsystem : UWorldSubsystem {
	char pad_30[0x68]; // 0x30(0x68)
};

// Class ActorEntity.PhysicsComponentBridgeHelper
// Size: 0x38 (Inherited: 0x28)
struct UPhysicsComponentBridgeHelper : UObject {
	char pad_28[0x10]; // 0x28(0x10)

	void HandleActorComponentHit(struct UPrimitiveComponent* PrimitiveComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComponent, struct FVector NormalImpulse, struct FHitResult& Hit); // Function ActorEntity.PhysicsComponentBridgeHelper.HandleActorComponentHit // (Final|Native|Private|HasOutParms|HasDefaults) // @ game+0x7f68a4c
};

