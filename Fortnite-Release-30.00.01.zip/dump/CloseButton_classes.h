// WidgetBlueprintGeneratedClass CloseButton.CloseButton_C
// Size: 0x1539 (Inherited: 0x14f0)
struct UCloseButton_C : UBacchusCloseButton {
	struct UBorder* Border_Container; // 0x14f0(0x08)
	struct UImage* CloseIcon; // 0x14f8(0x08)
	struct USizeBox* SizeBox_Control; // 0x1500(0x08)
	struct UCommonTextBlock* Text_ButtonAction; // 0x1508(0x08)
	struct FText Button Description; // 0x1510(0x10)
	bool FontSizeOveride; // 0x1520(0x01)
	char pad_1521[0x3]; // 0x1521(0x03)
	int32_t FontSize; // 0x1524(0x04)
	struct FMargin Padding Overide; // 0x1528(0x10)
	bool PaddingOveride; // 0x1538(0x01)

	void SetText(struct FText Text); // Function CloseButton.CloseButton_C.SetText // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HandleSize(); // Function CloseButton.CloseButton_C.HandleSize // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
};

