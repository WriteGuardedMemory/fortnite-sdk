// Class AudioMetadata.AudioMetadataDeveloperSettings
// Size: 0x40 (Inherited: 0x30)
struct UAudioMetadataDeveloperSettings : UDeveloperSettings {
	struct FAudioMetadataModulationSettings ModulationSettings; // 0x30(0x10)
};

// Class AudioMetadata.AudioMetadataSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UAudioMetadataSubsystem : UAudioEngineSubsystem {
	char pad_30[0x10]; // 0x30(0x10)

	bool HasTag(struct USoundBase* InSound, struct FGameplayTag InTag, bool bExactMatch); // Function AudioMetadata.AudioMetadataSubsystem.HasTag // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8982888
};

