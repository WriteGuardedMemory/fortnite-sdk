// BlueprintGeneratedClass CommonUI_KeyboardBrushData.CommonUI_KeyboardBrushData_C
// Size: 0xd0 (Inherited: 0xd0)
struct UCommonUI_KeyboardBrushData_C : UFortInputControllerData {
};

