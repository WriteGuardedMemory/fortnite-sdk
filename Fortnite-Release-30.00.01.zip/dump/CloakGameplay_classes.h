// Class CloakGameplay.FortGameCueNotifyLoop_Cloak
// Size: 0xa28 (Inherited: 0x9b0)
struct AFortGameCueNotifyLoop_Cloak : AFortGameplayCueNotify_Loop {
	struct AFortPlayerPawn* TargetPlayer; // 0x9b0(0x08)
	float VisibilityLevel; // 0x9b8(0x04)
	float StationaryVisMult; // 0x9bc(0x04)
	float MaxSpeedVisMult; // 0x9c0(0x04)
	float SpeedForMaxVis; // 0x9c4(0x04)
	float VisibilityMinFriendly; // 0x9c8(0x04)
	float VisibilityMinNonfriendly; // 0x9cc(0x04)
	float VisibilityLevelChangeRate; // 0x9d0(0x04)
	char pad_9D4[0x4]; // 0x9d4(0x04)
	struct TMap<struct FName, struct FFortGameCueCloakModifier> CloakModifiersByNameMap; // 0x9d8(0x50)

	float TickVisibilityLevel(float DeltaSeconds); // Function CloakGameplay.FortGameCueNotifyLoop_Cloak.TickVisibilityLevel // (Final|Native|Protected|BlueprintCallable) // @ game+0xb8c52e8
	bool SetModifierEnabled(struct FName& ModifierName, bool bNewEnabled); // Function CloakGameplay.FortGameCueNotifyLoop_Cloak.SetModifierEnabled // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0xb8c51c8
	bool SetModifierCanBeEnabled(struct FName& ModifierName, bool bNewCanBeEnabled); // Function CloakGameplay.FortGameCueNotifyLoop_Cloak.SetModifierCanBeEnabled // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0xb8c50a8
	bool GetCurrentModifierValues(float& OutVisibilityMultiplier, float& OutVisibilityAddition, struct FName& ModifierName); // Function CloakGameplay.FortGameCueNotifyLoop_Cloak.GetCurrentModifierValues // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb8c4f7c
};

