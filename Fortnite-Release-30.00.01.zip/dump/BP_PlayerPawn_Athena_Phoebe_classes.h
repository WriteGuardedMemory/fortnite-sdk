// BlueprintGeneratedClass BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C
// Size: 0x6a04 (Inherited: 0x69ec)
struct ABP_PlayerPawn_Athena_Phoebe_C : APlayerPawn_Athena_C {
	char pad_69EC[0x4]; // 0x69ec(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x69f0(0x08)
	struct FName AIEvaluator_CharacterLaunchedKeyName; // 0x69f8(0x04)
	bool bUseCosmeticVariants; // 0x69fc(0x01)
	char pad_69FD[0x3]; // 0x69fd(0x03)
	int32_t CosmeticVariantID; // 0x6a00(0x04)

	void ComputeCosmeticVariantID(); // Function BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C.ComputeCosmeticVariantID // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void AssignCosmeticVariant(); // Function BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C.AssignCosmeticVariant // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnCharacterCustomizationCompleted(struct AFortPlayerPawn* Pawn); // Function BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C.OnCharacterCustomizationCompleted // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_BP_PlayerPawn_Athena_Phoebe(int32_t EntryPoint); // Function BP_PlayerPawn_Athena_Phoebe.BP_PlayerPawn_Athena_Phoebe_C.ExecuteUbergraph_BP_PlayerPawn_Athena_Phoebe // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

