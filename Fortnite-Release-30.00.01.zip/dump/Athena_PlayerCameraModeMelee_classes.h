// BlueprintGeneratedClass Athena_PlayerCameraModeMelee.Athena_PlayerCameraModeMelee_C
// Size: 0x1cd0 (Inherited: 0x1cd0)
struct UAthena_PlayerCameraModeMelee_C : UAthena_PlayerCameraModeBase_C {
};

