// BlueprintGeneratedClass B_PlayerHealthDamage_LensEffect_Direction.B_PlayerHealthDamage_LensEffect_Direction_C
// Size: 0x3c0 (Inherited: 0x3c0)
struct AB_PlayerHealthDamage_LensEffect_Direction_C : AFortEmitterCameraLensEffectDirectional {
};

