// BlueprintGeneratedClass B_FortGlobalAbilityTargetingActor.B_FortGlobalAbilityTargetingActor_C
// Size: 0x290 (Inherited: 0x290)
struct AB_FortGlobalAbilityTargetingActor_C : AFortGlobalAbilityTargetingActor {
};

