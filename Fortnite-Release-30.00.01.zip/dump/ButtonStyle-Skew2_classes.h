// BlueprintGeneratedClass ButtonStyle-Skew2.ButtonStyle-Skew2_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Skew2_C : UCommonButtonStyle {
};

