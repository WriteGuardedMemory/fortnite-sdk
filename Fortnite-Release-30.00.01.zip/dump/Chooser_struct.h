// Enum Chooser.EBoolColumnCellValue
enum class EBoolColumnCellValue : uint8 {
	MatchFalse = 0,
	MatchTrue = 1,
	MatchAny = 2,
	EBoolColumnCellValue_MAX = 3
};

// Enum Chooser.EContextObjectDirection
enum class EContextObjectDirection : uint8 {
	Read = 0,
	Write = 1,
	ReadWrite = 2,
	EContextObjectDirection_MAX = 3
};

// Enum Chooser.EEnumColumnCellValueComparison
enum class EEnumColumnCellValueComparison : uint8 {
	MatchEqual = 0,
	MatchNotEqual = 1,
	MatchAny = 2,
	Modulus = 3,
	EEnumColumnCellValueComparison_MAX = 4
};

// Enum Chooser.EObjectChooserResultType
enum class EObjectChooserResultType : uint8 {
	ObjectResult = 0,
	ClassResult = 1,
	EObjectChooserResultType_MAX = 2
};

// Enum Chooser.EObjectColumnCellValueComparison
enum class EObjectColumnCellValueComparison : uint8 {
	MatchEqual = 0,
	MatchNotEqual = 1,
	MatchAny = 2,
	Modulus = 3,
	EObjectColumnCellValueComparison_MAX = 4
};

// Enum Chooser.EChooserEvaluationFrequency
enum class EChooserEvaluationFrequency : uint8 {
	OnInitialUpdate = 0,
	OnBecomeRelevant = 1,
	OnLoop = 2,
	OnUpdate = 3,
	EChooserEvaluationFrequency_MAX = 4
};

// ScriptStruct Chooser.ChooserParameterBase
// Size: 0x08 (Inherited: 0x00)
struct FChooserParameterBase {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Chooser.ChooserParameterBoolBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterBoolBase : FChooserParameterBase {
};

// ScriptStruct Chooser.BoolContextProperty
// Size: 0x40 (Inherited: 0x08)
struct FBoolContextProperty : FChooserParameterBoolBase {
	struct TArray<struct FName> PropertyBindingChain; // 0x08(0x10)
	struct FChooserPropertyBinding Binding; // 0x18(0x28)
};

// ScriptStruct Chooser.ChooserPropertyBinding
// Size: 0x28 (Inherited: 0x00)
struct FChooserPropertyBinding {
	struct TArray<struct FName> PropertyBindingChain; // 0x00(0x10)
	int32_t ContextIndex; // 0x10(0x04)
	bool IsBoundToRoot; // 0x14(0x01)
	char pad_15[0x13]; // 0x15(0x13)
};

// ScriptStruct Chooser.ChooserColumnBase
// Size: 0x08 (Inherited: 0x00)
struct FChooserColumnBase {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Chooser.BoolColumn
// Size: 0x28 (Inherited: 0x08)
struct FBoolColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<enum class EBoolColumnCellValue> RowValuesWithAny; // 0x18(0x10)
};

// ScriptStruct Chooser.ChooserEnumPropertyBinding
// Size: 0x28 (Inherited: 0x28)
struct FChooserEnumPropertyBinding : FChooserPropertyBinding {
};

// ScriptStruct Chooser.ChooserObjectPropertyBinding
// Size: 0x28 (Inherited: 0x28)
struct FChooserObjectPropertyBinding : FChooserPropertyBinding {
};

// ScriptStruct Chooser.ChooserStructPropertyBinding
// Size: 0x28 (Inherited: 0x28)
struct FChooserStructPropertyBinding : FChooserPropertyBinding {
};

// ScriptStruct Chooser.ContextObjectTypeBase
// Size: 0x04 (Inherited: 0x00)
struct FContextObjectTypeBase {
	enum class EContextObjectDirection Direction; // 0x00(0x04)
};

// ScriptStruct Chooser.ContextObjectTypeClass
// Size: 0x10 (Inherited: 0x04)
struct FContextObjectTypeClass : FContextObjectTypeBase {
	char pad_4[0x4]; // 0x04(0x04)
	struct UObject* Class; // 0x08(0x08)
};

// ScriptStruct Chooser.ContextObjectTypeStruct
// Size: 0x10 (Inherited: 0x04)
struct FContextObjectTypeStruct : FContextObjectTypeBase {
	char pad_4[0x4]; // 0x04(0x04)
	struct UScriptStruct* Struct; // 0x08(0x08)
};

// ScriptStruct Chooser.ChooserParameterEnumBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterEnumBase : FChooserParameterBase {
};

// ScriptStruct Chooser.EnumContextProperty
// Size: 0x40 (Inherited: 0x08)
struct FEnumContextProperty : FChooserParameterEnumBase {
	struct TArray<struct FName> PropertyBindingChain; // 0x08(0x10)
	struct FChooserEnumPropertyBinding Binding; // 0x18(0x28)
};

// ScriptStruct Chooser.ChooserEnumRowData
// Size: 0x08 (Inherited: 0x00)
struct FChooserEnumRowData {
	enum class EEnumColumnCellValueComparison Comparison; // 0x00(0x04)
	char Value; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
};

// ScriptStruct Chooser.EnumColumn
// Size: 0x28 (Inherited: 0x08)
struct FEnumColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FChooserEnumRowData> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.ChooserFloatDistanceRowData
// Size: 0x04 (Inherited: 0x00)
struct FChooserFloatDistanceRowData {
	float Value; // 0x00(0x04)
};

// ScriptStruct Chooser.FloatDistanceColumn
// Size: 0x48 (Inherited: 0x08)
struct FFloatDistanceColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	double MaxDistance; // 0x18(0x08)
	float CostMultiplier; // 0x20(0x04)
	bool bFilterOverMaxDistance; // 0x24(0x01)
	bool bWrapInput; // 0x25(0x01)
	char pad_26[0x2]; // 0x26(0x02)
	double MinValue; // 0x28(0x08)
	double MaxValue; // 0x30(0x08)
	struct TArray<struct FChooserFloatDistanceRowData> RowValues; // 0x38(0x10)
};

// ScriptStruct Chooser.ChooserParameterFloatBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterFloatBase : FChooserParameterBase {
};

// ScriptStruct Chooser.FloatContextProperty
// Size: 0x40 (Inherited: 0x08)
struct FFloatContextProperty : FChooserParameterFloatBase {
	struct TArray<struct FName> PropertyBindingChain; // 0x08(0x10)
	struct FChooserPropertyBinding Binding; // 0x18(0x28)
};

// ScriptStruct Chooser.ChooserFloatRangeRowData
// Size: 0x0c (Inherited: 0x00)
struct FChooserFloatRangeRowData {
	float Min; // 0x00(0x04)
	float Max; // 0x04(0x04)
	bool bNoMin; // 0x08(0x01)
	bool bNoMax; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
};

// ScriptStruct Chooser.FloatRangeColumn
// Size: 0x40 (Inherited: 0x08)
struct FFloatRangeColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	bool bWrapInput; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	double MinValue; // 0x20(0x08)
	double MaxValue; // 0x28(0x08)
	struct TArray<struct FChooserFloatRangeRowData> RowValues; // 0x30(0x10)
};

// ScriptStruct Chooser.ChooserParameterGameplayTagBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterGameplayTagBase : FChooserParameterBase {
};

// ScriptStruct Chooser.GameplayTagContextProperty
// Size: 0x40 (Inherited: 0x08)
struct FGameplayTagContextProperty : FChooserParameterGameplayTagBase {
	struct TArray<struct FName> PropertyBindingChain; // 0x08(0x10)
	struct FChooserPropertyBinding Binding; // 0x18(0x28)
};

// ScriptStruct Chooser.GameplayTagColumn
// Size: 0x30 (Inherited: 0x08)
struct FGameplayTagColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	enum class EGameplayContainerMatchType TagMatchType; // 0x18(0x01)
	bool bMatchExact; // 0x19(0x01)
	bool bInvertMatchingLogic; // 0x1a(0x01)
	char pad_1B[0x5]; // 0x1b(0x05)
	struct TArray<struct FGameplayTagContainer> RowValues; // 0x20(0x10)
};

// ScriptStruct Chooser.ChooserParameterObjectBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterObjectBase : FChooserParameterBase {
};

// ScriptStruct Chooser.ChooserRandomizationContext
// Size: 0x50 (Inherited: 0x00)
struct FChooserRandomizationContext {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct Chooser.ChooserParameterRandomizeBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterRandomizeBase : FChooserParameterBase {
};

// ScriptStruct Chooser.ChooserParameterStructBase
// Size: 0x08 (Inherited: 0x08)
struct FChooserParameterStructBase : FChooserParameterBase {
};

// ScriptStruct Chooser.ChooserEvaluationInputObject
// Size: 0x08 (Inherited: 0x00)
struct FChooserEvaluationInputObject {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Chooser.ChooserEvaluationContext
// Size: 0x78 (Inherited: 0x00)
struct FChooserEvaluationContext {
	char pad_0[0x78]; // 0x00(0x78)
};

// ScriptStruct Chooser.ObjectChooserBase
// Size: 0x08 (Inherited: 0x00)
struct FObjectChooserBase {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct Chooser.ChooserMultiEnumRowData
// Size: 0x04 (Inherited: 0x00)
struct FChooserMultiEnumRowData {
	uint32_t Value; // 0x00(0x04)
};

// ScriptStruct Chooser.MultiEnumColumn
// Size: 0x28 (Inherited: 0x08)
struct FMultiEnumColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FChooserMultiEnumRowData> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.AssetChooser
// Size: 0x10 (Inherited: 0x08)
struct FAssetChooser : FObjectChooserBase {
	struct UObject* Asset; // 0x08(0x08)
};

// ScriptStruct Chooser.SoftAssetChooser
// Size: 0x28 (Inherited: 0x08)
struct FSoftAssetChooser : FObjectChooserBase {
	struct TSoftObjectPtr<UObject> Asset; // 0x08(0x20)
};

// ScriptStruct Chooser.ClassChooser
// Size: 0x10 (Inherited: 0x08)
struct FClassChooser : FObjectChooserBase {
	struct UObject* Class; // 0x08(0x08)
};

// ScriptStruct Chooser.ObjectContextProperty
// Size: 0x30 (Inherited: 0x08)
struct FObjectContextProperty : FChooserParameterObjectBase {
	struct FChooserObjectPropertyBinding Binding; // 0x08(0x28)
};

// ScriptStruct Chooser.ChooserObjectRowData
// Size: 0x28 (Inherited: 0x00)
struct FChooserObjectRowData {
	enum class EObjectColumnCellValueComparison Comparison; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UObject> Value; // 0x08(0x20)
};

// ScriptStruct Chooser.ObjectColumn
// Size: 0x28 (Inherited: 0x08)
struct FObjectColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FChooserObjectRowData> RowValues; // 0x18(0x10)
};

// ScriptStruct Chooser.OutputBoolColumn
// Size: 0x30 (Inherited: 0x08)
struct FOutputBoolColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	bool bFallbackValue; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<bool> RowValues; // 0x20(0x10)
};

// ScriptStruct Chooser.ChooserOutputEnumRowData
// Size: 0x01 (Inherited: 0x00)
struct FChooserOutputEnumRowData {
	char Value; // 0x00(0x01)
};

// ScriptStruct Chooser.OutputEnumColumn
// Size: 0x30 (Inherited: 0x08)
struct FOutputEnumColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct FChooserOutputEnumRowData FallbackValue; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FChooserOutputEnumRowData> RowValues; // 0x20(0x10)
};

// ScriptStruct Chooser.OutputFloatColumn
// Size: 0x30 (Inherited: 0x08)
struct FOutputFloatColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	double FallbackValue; // 0x18(0x08)
	struct TArray<double> RowValues; // 0x20(0x10)
};

// ScriptStruct Chooser.ChooserOutputObjectRowData
// Size: 0x10 (Inherited: 0x00)
struct FChooserOutputObjectRowData {
	struct FInstancedStruct Value; // 0x00(0x10)
};

// ScriptStruct Chooser.OutputObjectColumn
// Size: 0x38 (Inherited: 0x08)
struct FOutputObjectColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct TArray<struct FChooserOutputObjectRowData> RowValues; // 0x18(0x10)
	struct FChooserOutputObjectRowData FallbackValue; // 0x28(0x10)
};

// ScriptStruct Chooser.StructContextProperty
// Size: 0x30 (Inherited: 0x08)
struct FStructContextProperty : FChooserParameterStructBase {
	struct FChooserStructPropertyBinding Binding; // 0x08(0x28)
};

// ScriptStruct Chooser.OutputStructColumn
// Size: 0x38 (Inherited: 0x08)
struct FOutputStructColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	struct FInstancedStruct FallbackValue; // 0x18(0x10)
	struct TArray<struct FInstancedStruct> RowValues; // 0x28(0x10)
};

// ScriptStruct Chooser.RandomizeContextProperty
// Size: 0x30 (Inherited: 0x08)
struct FRandomizeContextProperty : FChooserParameterRandomizeBase {
	struct FChooserPropertyBinding Binding; // 0x08(0x28)
};

// ScriptStruct Chooser.RandomizeColumn
// Size: 0x30 (Inherited: 0x08)
struct FRandomizeColumn : FChooserColumnBase {
	struct FInstancedStruct InputValue; // 0x08(0x10)
	float RepeatProbabilityMultiplier; // 0x18(0x04)
	float EqualCostThreshold; // 0x1c(0x04)
	struct TArray<float> RowValues; // 0x20(0x10)
};

// ScriptStruct Chooser.AnimCurveOverride
// Size: 0x08 (Inherited: 0x00)
struct FAnimCurveOverride {
	struct FName CurveName; // 0x00(0x04)
	float CurveValue; // 0x04(0x04)
};

// ScriptStruct Chooser.AnimCurveOverrideList
// Size: 0x18 (Inherited: 0x00)
struct FAnimCurveOverrideList {
	struct TArray<struct FAnimCurveOverride> Values; // 0x00(0x10)
	uint32_t Hash; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct Chooser.ChooserPlayerSettings
// Size: 0x40 (Inherited: 0x00)
struct FChooserPlayerSettings {
	bool bMirror; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float StartTime; // 0x04(0x04)
	bool bForceLooping; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float PlaybackRate; // 0x0c(0x04)
	struct FAnimCurveOverrideList CurveOverrides; // 0x10(0x18)
	float BlendTime; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct UBlendProfile* BlendProfile; // 0x30(0x08)
	enum class EAlphaBlendOption BlendOption; // 0x38(0x01)
	bool bUseInertialBlend; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
};

// ScriptStruct Chooser.AnimNode_ChooserPlayer
// Size: 0x238 (Inherited: 0xb0)
struct FAnimNode_ChooserPlayer : FAnimNode_BlendStack_Standalone {
	char pad_B0[0x20]; // 0xb0(0x20)
	enum class EChooserEvaluationFrequency EvaluationFrequency; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct FInstancedStruct Chooser; // 0xd8(0x10)
	struct UMirrorDataTable* MirrorDataTable; // 0xe8(0x08)
	float BlendSpaceX; // 0xf0(0x04)
	float BlendSpaceY; // 0xf4(0x04)
	char pad_F8[0x8]; // 0xf8(0x08)
	struct FChooserPlayerSettings DefaultSettings; // 0x100(0x40)
	struct TArray<struct FInstancedStruct> ChooserContextDefinition; // 0x140(0x10)
	bool bStartFromMatchingPose; // 0x150(0x01)
	char pad_151[0xe7]; // 0x151(0xe7)
};

// ScriptStruct Chooser.NestedChooser
// Size: 0x10 (Inherited: 0x08)
struct FNestedChooser : FObjectChooserBase {
	struct UChooserTable* Chooser; // 0x08(0x08)
};

// ScriptStruct Chooser.EvaluateChooser
// Size: 0x10 (Inherited: 0x08)
struct FEvaluateChooser : FObjectChooserBase {
	struct UChooserTable* Chooser; // 0x08(0x08)
};

