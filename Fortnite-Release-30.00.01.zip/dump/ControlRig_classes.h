// Class ControlRig.ControlRigShapeLibraryLink
// Size: 0x138 (Inherited: 0x100)
struct UControlRigShapeLibraryLink : UNameSpacedUserData {
	struct TSoftObjectPtr<UControlRigShapeLibrary> ShapeLibrary; // 0x100(0x20)
	struct TArray<struct FName> ShapeNames; // 0x120(0x10)
	struct UControlRigShapeLibrary* ShapeLibraryCached; // 0x130(0x08)

	void SetShapeLibrary(struct TSoftObjectPtr<UControlRigShapeLibrary> InShapeLibrary); // Function ControlRig.ControlRigShapeLibraryLink.SetShapeLibrary // (Final|Native|Public|BlueprintCallable) // @ game+0x8006980
	struct TSoftObjectPtr<UControlRigShapeLibrary> GetShapeLibrary(); // Function ControlRig.ControlRigShapeLibraryLink.GetShapeLibrary // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7601208
};

// Class ControlRig.ControlRig
// Size: 0xaa0 (Inherited: 0x278)
struct UControlRig : URigVMHost {
	char pad_278[0x10]; // 0x278(0x10)
	enum class ERigExecutionType ExecutionType; // 0x288(0x01)
	char pad_289[0x3]; // 0x289(0x03)
	struct FRigHierarchySettings HierarchySettings; // 0x28c(0x04)
	struct TMap<struct FRigElementKey, struct FRigControlElementCustomization> ControlCustomizations; // 0x290(0x50)
	struct URigHierarchy* DynamicHierarchy; // 0x2e0(0x08)
	struct TArray<struct TSoftObjectPtr<UControlRigShapeLibrary>> ShapeLibraries; // 0x2e8(0x10)
	struct TMap<struct FString, struct FString> ShapeLibraryNameMap; // 0x2f8(0x50)
	char pad_348[0x10]; // 0x348(0x10)
	struct FRigVMExtendedExecuteContext RigVMExtendedExecuteContext; // 0x358(0x228)
	char pad_580[0x8]; // 0x580(0x08)
	struct UAnimationDataSourceRegistry* DataSourceRegistry; // 0x588(0x08)
	char pad_590[0xa8]; // 0x590(0xa8)
	struct FRigInfluenceMapPerEvent Influences; // 0x638(0x60)
	char pad_698[0xb8]; // 0x698(0xb8)
	struct TMap<struct FName, struct UDataAssetLink*> ExternalVariableDataAssetLinks; // 0x750(0x50)
	char pad_7A0[0xd0]; // 0x7a0(0xd0)
	struct FMulticastSparseDelegate OnControlSelected_BP; // 0x870(0x01)
	char pad_871[0x17]; // 0x871(0x17)
	bool bIsAdditive; // 0x888(0x01)
	char pad_889[0x18f]; // 0x889(0x18f)
	struct FRigModuleSettings RigModuleSettings; // 0xa18(0x78)
	struct FString RigModuleNameSpace; // 0xa90(0x10)

	bool SupportsBackwardsSolve(); // Function ControlRig.ControlRig.SupportsBackwardsSolve // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x805195c
	void SetInteractionRigClass(struct UControlRig* InInteractionRigClass); // Function ControlRig.ControlRig.SetInteractionRigClass // (Final|Native|Public|BlueprintCallable) // @ game+0x688d534
	void SetInteractionRig(struct UControlRig* InInteractionRig); // Function ControlRig.ControlRig.SetInteractionRig // (Final|Native|Public|BlueprintCallable) // @ game+0x655e588
	void SelectControl(struct FName& InControlName, bool bSelect); // Function ControlRig.ControlRig.SelectControl // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x804e440
	void RequestConstruction(); // Function ControlRig.ControlRig.RequestConstruction // (Final|Native|Public|BlueprintCallable) // @ game+0x804e418
	void OnControlSelectedBP__DelegateSignature(struct UControlRig* Rig, struct FRigControlElement& Control, bool bSelected); // SparseDelegateFunction ControlRig.ControlRig.OnControlSelectedBP__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x18e3f1c
	bool IsControlSelected(struct FName& InControlName); // Function ControlRig.ControlRig.IsControlSelected // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x804c3b8
	struct UControlRig* GetInteractionRigClass(); // Function ControlRig.ControlRig.GetInteractionRigClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804c0c0
	struct UControlRig* GetInteractionRig(); // Function ControlRig.ControlRig.GetInteractionRig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c11ce4
	struct AActor* GetHostingActor(); // Function ControlRig.ControlRig.GetHostingActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804bd50
	struct URigHierarchy* GetHierarchy(); // Function ControlRig.ControlRig.GetHierarchy // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x804bd38
	struct TArray<struct UControlRig*> FindControlRigs(struct UObject* Outer, struct UControlRig* OptionalClass); // Function ControlRig.ControlRig.FindControlRigs // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x804aaec
	struct TArray<struct FName> CurrentControlSelection(); // Function ControlRig.ControlRig.CurrentControlSelection // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8049efc
	struct UTransformableControlHandle* CreateTransformableControlHandle(struct FName& ControlName); // Function ControlRig.ControlRig.CreateTransformableControlHandle // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8049e64
	bool ClearControlSelection(); // Function ControlRig.ControlRig.ClearControlSelection // (Native|Public|BlueprintCallable) // @ game+0x80490dc
};

// Class ControlRig.ModularRig
// Size: 0xc30 (Inherited: 0xaa0)
struct UModularRig : UControlRig {
	struct TArray<struct FRigModuleInstance> Modules; // 0xaa0(0x10)
	char pad_AB0[0x20]; // 0xab0(0x20)
	struct FModularRigSettings ModularRigSettings; // 0xad0(0x01)
	char pad_AD1[0x7]; // 0xad1(0x07)
	struct FModularRigModel ModularRigModel; // 0xad8(0xa0)
	struct TArray<struct FRigModuleExecutionElement> ExecutionQueue; // 0xb78(0x10)
	char pad_B88[0xa8]; // 0xb88(0xa8)
};

// Class ControlRig.RigHierarchy
// Size: 0x4c0 (Inherited: 0x28)
struct URigHierarchy : UObject {
	char pad_28[0x18]; // 0x28(0x18)
	struct FMulticastInlineDelegate ModifiedEventDynamic; // 0x40(0x10)
	char pad_50[0x48]; // 0x50(0x48)
	uint32_t TopologyVersion; // 0x98(0x04)
	uint32_t MetadataVersion; // 0x9c(0x04)
	uint16_t MetadataTagVersion; // 0xa0(0x02)
	bool bEnableDirtyPropagation; // 0xa2(0x01)
	char pad_A3[0x131]; // 0xa3(0x131)
	int32_t TransformStackIndex; // 0x1d4(0x04)
	char pad_1D8[0x70]; // 0x1d8(0x70)
	struct URigHierarchyController* HierarchyController; // 0x248(0x08)
	char pad_250[0x8]; // 0x250(0x08)
	struct UModularRigRuleManager* RuleManager; // 0x258(0x08)
	char pad_260[0x50]; // 0x260(0x50)
	struct TMap<struct FRigElementKey, struct FRigElementKey> PreviousNameMap; // 0x2b0(0x50)
	char pad_300[0xf8]; // 0x300(0xf8)
	struct URigHierarchy* HierarchyForCacheValidation; // 0x3f8(0x08)
	char pad_400[0xc0]; // 0x400(0xc0)

	void UnsetCurveValueByIndex(int32_t InElementIndex, bool bSetupUndo); // Function ControlRig.RigHierarchy.UnsetCurveValueByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8007cac
	void UnsetCurveValue(struct FRigElementKey InKey, bool bSetupUndo); // Function ControlRig.RigHierarchy.UnsetCurveValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8007b5c
	bool SwitchToWorldSpace(struct FRigElementKey InChild, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SwitchToWorldSpace // (Final|Native|Public|BlueprintCallable) // @ game+0x8007974
	bool SwitchToParent(struct FRigElementKey InChild, struct FRigElementKey InParent, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SwitchToParent // (Final|Native|Public|BlueprintCallable) // @ game+0x8007720
	bool SwitchToDefaultParent(struct FRigElementKey InChild, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SwitchToDefaultParent // (Final|Native|Public|BlueprintCallable) // @ game+0x800754c
	struct TArray<struct FRigElementKey> SortKeys(struct TArray<struct FRigElementKey>& InKeys); // Function ControlRig.RigHierarchy.SortKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8007484
	bool SetVectorMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FVector InValue); // Function ControlRig.RigHierarchy.SetVectorMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x80072a4
	bool SetVectorArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<struct FVector> InValue); // Function ControlRig.RigHierarchy.SetVectorArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8007088
	bool SetTransformMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FTransform InValue); // Function ControlRig.RigHierarchy.SetTransformMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8006e24
	bool SetTransformArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<struct FTransform> InValue); // Function ControlRig.RigHierarchy.SetTransformArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8006c08
	bool SetTag(struct FRigElementKey InItem, struct FName InTag); // Function ControlRig.RigHierarchy.SetTag // (Final|Native|Public|BlueprintCallable) // @ game+0x8006ab4
	bool SetRotatorMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FRotator InValue); // Function ControlRig.RigHierarchy.SetRotatorMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x80067a0
	bool SetRotatorArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<struct FRotator> InValue); // Function ControlRig.RigHierarchy.SetRotatorArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8005f60
	bool SetRigElementKeyMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FRigElementKey InValue); // Function ControlRig.RigHierarchy.SetRigElementKeyMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8005d9c
	bool SetRigElementKeyArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<struct FRigElementKey> InValue); // Function ControlRig.RigHierarchy.SetRigElementKeyArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8005b9c
	bool SetQuatMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FQuat InValue); // Function ControlRig.RigHierarchy.SetQuatMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x80059c0
	bool SetQuatArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<struct FQuat> InValue); // Function ControlRig.RigHierarchy.SetQuatArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x80057c0
	void SetPose_ForBlueprint(struct FRigPose InPose); // Function ControlRig.RigHierarchy.SetPose_ForBlueprint // (Final|Native|Public|BlueprintCallable) // @ game+0x8005688
	bool SetParentWeightArray(struct FRigElementKey InChild, struct TArray<struct FRigElementWeight> InWeights, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SetParentWeightArray // (Final|Native|Public|BlueprintCallable) // @ game+0x80053e0
	bool SetParentWeight(struct FRigElementKey InChild, struct FRigElementKey InParent, struct FRigElementWeight InWeight, bool bInitial, bool bAffectChildren); // Function ControlRig.RigHierarchy.SetParentWeight // (Final|Native|Public|BlueprintCallable) // @ game+0x80050f0
	bool SetNameMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FName InValue); // Function ControlRig.RigHierarchy.SetNameMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8004f30
	bool SetNameArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<struct FName> InValue); // Function ControlRig.RigHierarchy.SetNameArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8004d18
	void SetLocalTransformByIndex(int32_t InElementIndex, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetLocalTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8004930
	void SetLocalTransform(struct FRigElementKey InKey, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetLocalTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8004544
	bool SetLinearColorMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FLinearColor InValue); // Function ControlRig.RigHierarchy.SetLinearColorMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8004370
	bool SetLinearColorArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<struct FLinearColor> InValue); // Function ControlRig.RigHierarchy.SetLinearColorArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8004170
	bool SetInt32Metadata(struct FRigElementKey InItem, struct FName InMetadataName, int32_t InValue); // Function ControlRig.RigHierarchy.SetInt32Metadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8003fb0
	bool SetInt32ArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<int32_t> InValue); // Function ControlRig.RigHierarchy.SetInt32ArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8003d98
	void SetGlobalTransformByIndex(int32_t InElementIndex, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchy.SetGlobalTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x80039b0
	void SetGlobalTransform(struct FRigElementKey InKey, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchy.SetGlobalTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x80035c4
	bool SetFloatMetadata(struct FRigElementKey InItem, struct FName InMetadataName, float InValue); // Function ControlRig.RigHierarchy.SetFloatMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x8003404
	bool SetFloatArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<float> InValue); // Function ControlRig.RigHierarchy.SetFloatArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x80031ec
	void SetCurveValueByIndex(int32_t InElementIndex, float InValue, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetCurveValueByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x800302c
	void SetCurveValue(struct FRigElementKey InKey, float InValue, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetCurveValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8002e74
	void SetControlVisibilityByIndex(int32_t InElementIndex, bool bVisibility); // Function ControlRig.RigHierarchy.SetControlVisibilityByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8002d34
	void SetControlVisibility(struct FRigElementKey InKey, bool bVisibility); // Function ControlRig.RigHierarchy.SetControlVisibility // (Final|Native|Public|BlueprintCallable) // @ game+0x8002bd8
	void SetControlValueByIndex(int32_t InElementIndex, struct FRigControlValue InValue, enum class ERigControlValueType InValueType, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlValueByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x800289c
	void SetControlValue(struct FRigElementKey InKey, struct FRigControlValue InValue, enum class ERigControlValueType InValueType, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlValue // (Final|Native|Public|BlueprintCallable) // @ game+0x800255c
	void SetControlShapeTransformByIndex(int32_t InElementIndex, struct FTransform InTransform, bool bInitial, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetControlShapeTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8002278
	void SetControlShapeTransform(struct FRigElementKey InKey, struct FTransform InTransform, bool bInitial, bool bSetupUndo); // Function ControlRig.RigHierarchy.SetControlShapeTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8001f8c
	void SetControlSettingsByIndex(int32_t InElementIndex, struct FRigControlSettings InSettings, bool bSetupUndo, bool bForce, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlSettingsByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8001c84
	void SetControlSettings(struct FRigElementKey InKey, struct FRigControlSettings InSettings, bool bSetupUndo, bool bForce, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x8001944
	void SetControlPreferredRotatorByIndex(int32_t InElementIndex, struct FRotator& InRotator, bool bInitial, bool bFixEulerFlips); // Function ControlRig.RigHierarchy.SetControlPreferredRotatorByIndex // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x8001734
	void SetControlPreferredRotator(struct FRigElementKey InKey, struct FRotator& InRotator, bool bInitial, bool bFixEulerFlips); // Function ControlRig.RigHierarchy.SetControlPreferredRotator // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x800150c
	void SetControlPreferredRotationOrderByIndex(int32_t InElementIndex, enum class EEulerRotationOrder InRotationOrder); // Function ControlRig.RigHierarchy.SetControlPreferredRotationOrderByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x80013d0
	void SetControlPreferredRotationOrder(struct FRigElementKey InKey, enum class EEulerRotationOrder InRotationOrder); // Function ControlRig.RigHierarchy.SetControlPreferredRotationOrder // (Final|Native|Public|BlueprintCallable) // @ game+0x8001278
	void SetControlPreferredEulerAnglesByIndex(int32_t InElementIndex, struct FVector& InEulerAngles, enum class EEulerRotationOrder InRotationOrder, bool bInitial, bool bFixEulerFlips); // Function ControlRig.RigHierarchy.SetControlPreferredEulerAnglesByIndex // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x8000fb0
	void SetControlPreferredEulerAngles(struct FRigElementKey InKey, struct FVector& InEulerAngles, enum class EEulerRotationOrder InRotationOrder, bool bInitial, bool bFixEulerFlips); // Function ControlRig.RigHierarchy.SetControlPreferredEulerAngles // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x8000ccc
	void SetControlOffsetTransformByIndex(int32_t InElementIndex, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlOffsetTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x80008e4
	void SetControlOffsetTransform(struct FRigElementKey InKey, struct FTransform InTransform, bool bInitial, bool bAffectChildren, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetControlOffsetTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x80004f8
	void SetConnectorSettingsByIndex(int32_t InElementIndex, struct FRigConnectorSettings InSettings, bool bSetupUndo, bool bForce, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetConnectorSettingsByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x8000210
	void SetConnectorSettings(struct FRigElementKey InKey, struct FRigConnectorSettings InSettings, bool bSetupUndo, bool bForce, bool bPrintPythonCommands); // Function ControlRig.RigHierarchy.SetConnectorSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x7ffff20
	bool SetBoolMetadata(struct FRigElementKey InItem, struct FName InMetadataName, bool InValue); // Function ControlRig.RigHierarchy.SetBoolMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x7fffd60
	bool SetBoolArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct TArray<bool> InValue); // Function ControlRig.RigHierarchy.SetBoolArrayMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x7fffb4c
	void SendAutoKeyEvent(struct FRigElementKey InElement, float InOffsetInSeconds, bool bAsynchronous); // Function ControlRig.RigHierarchy.SendAutoKeyEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff98c
	struct TArray<struct FRigElementKey> RestoreSocketsFromStates(struct TArray<struct FRigSocketState> InStates, bool bSetupUndoRedo); // Function ControlRig.RigHierarchy.RestoreSocketsFromStates // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff7fc
	struct TArray<struct FRigElementKey> RestoreConnectorsFromStates(struct TArray<struct FRigConnectorState> InStates, bool bSetupUndoRedo); // Function ControlRig.RigHierarchy.RestoreConnectorsFromStates // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff624
	void ResetToDefault(); // Function ControlRig.RigHierarchy.ResetToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff610
	void ResetPoseToInitial(enum class ERigElementType InTypeFilter); // Function ControlRig.RigHierarchy.ResetPoseToInitial // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff550
	void ResetCurveValues(); // Function ControlRig.RigHierarchy.ResetCurveValues // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff4f8
	void Reset(); // Function ControlRig.RigHierarchy.Reset // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff4e4
	bool RemoveMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.RemoveMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff390
	bool RemoveAllMetadata(struct FRigElementKey InItem); // Function ControlRig.RigHierarchy.RemoveAllMetadata // (Final|Native|Public|BlueprintCallable) // @ game+0x7fff2b4
	int32_t Num(); // Function ControlRig.RigHierarchy.Num // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x65be4f8
	struct FRigControlValue MakeControlValueFromVector2D(struct FVector2D InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromVector2D // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7fff020
	struct FRigControlValue MakeControlValueFromVector(struct FVector InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromVector // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7fff164
	struct FRigControlValue MakeControlValueFromTransformNoScale(struct FTransformNoScale InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromTransformNoScale // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ffeec4
	struct FRigControlValue MakeControlValueFromTransform(struct FTransform InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromTransform // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7ffecd8
	struct FRigControlValue MakeControlValueFromRotator(struct FRotator InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromRotator // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7ffebb0
	struct FRigControlValue MakeControlValueFromInt(int32_t InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromInt // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ffea7c
	struct FRigControlValue MakeControlValueFromFloat(float InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromFloat // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ffe940
	struct FRigControlValue MakeControlValueFromEulerTransform(struct FEulerTransform InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromEulerTransform // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ffe7c4
	struct FRigControlValue MakeControlValueFromBool(bool InValue); // Function ControlRig.RigHierarchy.MakeControlValueFromBool // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ffe678
	bool IsValidIndex(int32_t InElementIndex); // Function ControlRig.RigHierarchy.IsValidIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffe5a0
	bool IsSelectedByIndex(int32_t InIndex); // Function ControlRig.RigHierarchy.IsSelectedByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffe4b0
	bool IsSelected(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.IsSelected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffe3dc
	bool IsProcedural(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.IsProcedural // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffe334
	bool IsParentedTo(struct FRigElementKey InChild, struct FRigElementKey InParent); // Function ControlRig.RigHierarchy.IsParentedTo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffe1dc
	bool IsCurveValueSetByIndex(int32_t InElementIndex); // Function ControlRig.RigHierarchy.IsCurveValueSetByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffe110
	bool IsCurveValueSet(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.IsCurveValueSet // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffe034
	bool IsControllerAvailable(); // Function ControlRig.RigHierarchy.IsControllerAvailable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffe01c
	bool HasTag(struct FRigElementKey InItem, struct FName InTag); // Function ControlRig.RigHierarchy.HasTag // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffdec8
	struct FVector GetVectorMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FVector DefaultValue); // Function ControlRig.RigHierarchy.GetVectorMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffdcc8
	struct FVector GetVectorFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetVectorFromControlValue // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7ffdbd4
	struct TArray<struct FVector> GetVectorArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetVectorArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffda6c
	struct FVector2D GetVector2DFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetVector2DFromControlValue // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7ffd988
	struct FTransformNoScale GetTransformNoScaleFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetTransformNoScaleFromControlValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ffd834
	struct FTransform GetTransformMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FTransform DefaultValue); // Function ControlRig.RigHierarchy.GetTransformMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffd598
	struct FTransform GetTransformFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetTransformFromControlValue // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7ffd414
	struct TArray<struct FTransform> GetTransformArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetTransformArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffd2ac
	struct TArray<struct FName> GetTags(struct FRigElementKey InItem); // Function ControlRig.RigHierarchy.GetTags // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffd1bc
	struct TArray<struct FRigSocketState> GetSocketStates(); // Function ControlRig.RigHierarchy.GetSocketStates // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffd11c
	struct TArray<struct FRigElementKey> GetSocketKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetSocketKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffd030
	struct TArray<struct FRigElementKey> GetSelectedKeys(enum class ERigElementType InTypeFilter); // Function ControlRig.RigHierarchy.GetSelectedKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffcf4c
	struct UModularRigRuleManager* GetRuleManager(bool bCreateIfNeeded); // Function ControlRig.RigHierarchy.GetRuleManager // (Final|Native|Public|BlueprintCallable) // @ game+0x7ffce7c
	struct FRotator GetRotatorMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FRotator DefaultValue); // Function ControlRig.RigHierarchy.GetRotatorMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffcc7c
	struct FRotator GetRotatorFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetRotatorFromControlValue // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7ffcb80
	struct TArray<struct FRotator> GetRotatorArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetRotatorArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffc36c
	struct TArray<struct FRigElementKey> GetRootElementKeys(); // Function ControlRig.RigHierarchy.GetRootElementKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffc308
	struct TArray<struct FRigElementKey> GetRigidBodyKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetRigidBodyKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffc21c
	struct FRigElementKey GetRigElementKeyMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FRigElementKey DefaultValue); // Function ControlRig.RigHierarchy.GetRigElementKeyMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffc04c
	struct TArray<struct FRigElementKey> GetRigElementKeyArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetRigElementKeyArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffbe70
	struct TArray<struct FRigElementKey> GetReferenceKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetReferenceKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffbd84
	struct FQuat GetQuatMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FQuat DefaultValue); // Function ControlRig.RigHierarchy.GetQuatMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffbb88
	struct TArray<struct FQuat> GetQuatArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetQuatArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffb9ac
	struct FRigElementKey GetPreviousParent(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.GetPreviousParent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffb914
	struct FName GetPreviousName(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.GetPreviousName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffb880
	struct FRigPose GetPose(bool bInitial, bool bIncludeTransientControls); // Function ControlRig.RigHierarchy.GetPose // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffb6ec
	struct TArray<struct FRigElementWeight> GetParentWeightArray(struct FRigElementKey InChild, bool bInitial); // Function ControlRig.RigHierarchy.GetParentWeightArray // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffb414
	struct FRigElementWeight GetParentWeight(struct FRigElementKey InChild, struct FRigElementKey InParent, bool bInitial); // Function ControlRig.RigHierarchy.GetParentWeight // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffb210
	struct FTransform GetParentTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetParentTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffb074
	struct FTransform GetParentTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetParentTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffaed4
	struct TArray<struct FRigElementKey> GetParents(struct FRigElementKey InKey, bool bRecursive); // Function ControlRig.RigHierarchy.GetParents // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffb580
	int32_t GetNumberOfParents(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetNumberOfParents // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffadfc
	struct TArray<struct FRigElementKey> GetNullKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetNullKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffad10
	struct FName GetNameSpaceFName(struct FRigElementKey InItem); // Function ControlRig.RigHierarchy.GetNameSpaceFName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffac44
	struct FString GetNameSpace(struct FRigElementKey InItem); // Function ControlRig.RigHierarchy.GetNameSpace // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffab5c
	struct FName GetNameMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FName DefaultValue); // Function ControlRig.RigHierarchy.GetNameMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa994
	struct TArray<struct FName> GetNameArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetNameArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa82c
	struct FName GetModulePathFName(struct FRigElementKey InItem); // Function ControlRig.RigHierarchy.GetModulePathFName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa760
	struct FString GetModulePath(struct FRigElementKey InItem); // Function ControlRig.RigHierarchy.GetModulePath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa678
	enum class ERigMetadataType GetMetadataType(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetMetadataType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa524
	struct TArray<struct FName> GetMetadataNames(struct FRigElementKey InItem); // Function ControlRig.RigHierarchy.GetMetadataNames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa43c
	struct FTransform GetLocalTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetLocalTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa29c
	struct FTransform GetLocalTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetLocalTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa0f8
	int32_t GetLocalIndex_ForBlueprint(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetLocalIndex_ForBlueprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ffa01c
	struct FTransform GetLocalControlShapeTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetLocalControlShapeTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff9e7c
	struct FTransform GetLocalControlShapeTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetLocalControlShapeTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff9cdc
	struct FLinearColor GetLinearColorMetadata(struct FRigElementKey InItem, struct FName InMetadataName, struct FLinearColor DefaultValue); // Function ControlRig.RigHierarchy.GetLinearColorMetadata // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff9af8
	struct TArray<struct FLinearColor> GetLinearColorArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetLinearColorArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff9938
	struct TArray<struct FRigElementKey> GetKeys(struct TArray<int32_t> InElementIndices); // Function ControlRig.RigHierarchy.GetKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff9794
	struct FRigElementKey GetKey(int32_t InElementIndex); // Function ControlRig.RigHierarchy.GetKey // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff96cc
	int32_t GetIntFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetIntFromControlValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ff95fc
	int32_t GetInt32Metadata(struct FRigElementKey InItem, struct FName InMetadataName, int32_t DefaultValue); // Function ControlRig.RigHierarchy.GetInt32Metadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff943c
	struct TArray<int32_t> GetInt32ArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetInt32ArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff92d4
	int32_t GetIndex_ForBlueprint(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetIndex_ForBlueprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff9204
	struct FTransform GetGlobalTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff9064
	struct FTransform GetGlobalTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff8ec0
	struct FTransform GetGlobalControlShapeTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalControlShapeTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff8d20
	struct FTransform GetGlobalControlShapeTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalControlShapeTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff8b80
	struct FTransform GetGlobalControlOffsetTransformByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransformByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff89e0
	struct FTransform GetGlobalControlOffsetTransform(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetGlobalControlOffsetTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff883c
	float GetFloatMetadata(struct FRigElementKey InItem, struct FName InMetadataName, float DefaultValue); // Function ControlRig.RigHierarchy.GetFloatMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff867c
	float GetFloatFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetFloatFromControlValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ff85a8
	struct TArray<float> GetFloatArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetFloatArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff8440
	struct FRigElementKey GetFirstParent(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetFirstParent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff8374
	struct FEulerTransform GetEulerTransformFromControlValue(struct FRigControlValue InValue); // Function ControlRig.RigHierarchy.GetEulerTransformFromControlValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7ff8218
	struct FRigElementKey GetDefaultParent(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetDefaultParent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff814c
	float GetCurveValueByIndex(int32_t InElementIndex); // Function ControlRig.RigHierarchy.GetCurveValueByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff807c
	float GetCurveValue(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.GetCurveValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff7fa0
	struct TArray<struct FRigElementKey> GetCurveKeys(); // Function ControlRig.RigHierarchy.GetCurveKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff7f5c
	struct FRigControlValue GetControlValueByIndex(int32_t InElementIndex, enum class ERigControlValueType InValueType); // Function ControlRig.RigHierarchy.GetControlValueByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff7ccc
	struct FRigControlValue GetControlValue(struct FRigElementKey InKey, enum class ERigControlValueType InValueType); // Function ControlRig.RigHierarchy.GetControlValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff7b08
	struct FRotator GetControlPreferredRotatorByIndex(int32_t InElementIndex, bool bInitial); // Function ControlRig.RigHierarchy.GetControlPreferredRotatorByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff79a4
	struct FRotator GetControlPreferredRotator(struct FRigElementKey InKey, bool bInitial); // Function ControlRig.RigHierarchy.GetControlPreferredRotator // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff7830
	enum class EEulerRotationOrder GetControlPreferredEulerRotationOrderByIndex(int32_t InElementIndex, bool bFromSettings); // Function ControlRig.RigHierarchy.GetControlPreferredEulerRotationOrderByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff76e0
	enum class EEulerRotationOrder GetControlPreferredEulerRotationOrder(struct FRigElementKey InKey, bool bFromSettings); // Function ControlRig.RigHierarchy.GetControlPreferredEulerRotationOrder // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff7584
	struct FVector GetControlPreferredEulerAnglesByIndex(int32_t InElementIndex, enum class EEulerRotationOrder InRotationOrder, bool bInitial); // Function ControlRig.RigHierarchy.GetControlPreferredEulerAnglesByIndex // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff73b0
	struct FVector GetControlPreferredEulerAngles(struct FRigElementKey InKey, enum class EEulerRotationOrder InRotationOrder, bool bInitial); // Function ControlRig.RigHierarchy.GetControlPreferredEulerAngles // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff71c0
	struct URigHierarchyController* GetController(bool bCreateIfNeeded); // Function ControlRig.RigHierarchy.GetController // (Final|Native|Public|BlueprintCallable) // @ game+0x7ff7e8c
	struct TArray<struct FRigElementKey> GetControlKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetControlKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff70d4
	struct TArray<struct FRigConnectorState> GetConnectorStates(); // Function ControlRig.RigHierarchy.GetConnectorStates // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff7034
	struct TArray<struct FRigElementKey> GetConnectorKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetConnectorKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff6f48
	struct TArray<struct FRigElementKey> GetChildren(struct FRigElementKey InKey, bool bRecursive); // Function ControlRig.RigHierarchy.GetChildren // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff6ddc
	bool GetBoolMetadata(struct FRigElementKey InItem, struct FName InMetadataName, bool DefaultValue); // Function ControlRig.RigHierarchy.GetBoolMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff6c1c
	struct TArray<bool> GetBoolArrayMetadata(struct FRigElementKey InItem, struct FName InMetadataName); // Function ControlRig.RigHierarchy.GetBoolArrayMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff6ab4
	struct TArray<struct FRigElementKey> GetBoneKeys(bool bTraverse); // Function ControlRig.RigHierarchy.GetBoneKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff69c8
	struct TArray<struct FRigElementKey> GetAllKeys_ForBlueprint(bool bTraverse); // Function ControlRig.RigHierarchy.GetAllKeys_ForBlueprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff68dc
	struct FRigNullElement FindNull_ForBlueprintOnly(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.FindNull_ForBlueprintOnly // (Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff6784
	struct FRigControlElement FindControl_ForBlueprintOnly(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.FindControl_ForBlueprintOnly // (Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff66a4
	struct FRigBoneElement FindBone_ForBlueprintOnly(struct FRigElementKey& InKey); // Function ControlRig.RigHierarchy.FindBone_ForBlueprintOnly // (Final|Native|Private|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff6560
	void CopyPose(struct URigHierarchy* InHierarchy, bool bCurrent, bool bInitial, bool bWeights, bool bMatchPoseInGlobalIfNeeded); // Function ControlRig.RigHierarchy.CopyPose // (Final|Native|Public|BlueprintCallable) // @ game+0x7ff6294
	void CopyHierarchy(struct URigHierarchy* InHierarchy); // Function ControlRig.RigHierarchy.CopyHierarchy // (Final|Native|Public|BlueprintCallable) // @ game+0x7ff61d4
	bool Contains_ForBlueprint(struct FRigElementKey InKey); // Function ControlRig.RigHierarchy.Contains_ForBlueprint // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7ff6100
};

// Class ControlRig.RigHierarchyProvider
// Size: 0x28 (Inherited: 0x28)
struct URigHierarchyProvider : UInterface {
};

// Class ControlRig.AnimNodeControlRigLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimNodeControlRigLibrary : UBlueprintFunctionLibrary {

	struct FControlRigReference SetControlRigClass(struct FControlRigReference& Node, struct UControlRig* ControlRigClass); // Function ControlRig.AnimNodeControlRigLibrary.SetControlRigClass // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x804fa6c
	void ConvertToControlRigPure(struct FAnimNodeReference& Node, struct FControlRigReference& ControlRig, bool& Result); // Function ControlRig.AnimNodeControlRigLibrary.ConvertToControlRigPure // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x80494f8
	struct FControlRigReference ConvertToControlRig(struct FAnimNodeReference& Node, enum class EAnimNodeReferenceConversionResult& Result); // Function ControlRig.AnimNodeControlRigLibrary.ConvertToControlRig // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x80493cc
};

// Class ControlRig.TransformableControlHandle
// Size: 0x88 (Inherited: 0x60)
struct UTransformableControlHandle : UTransformableHandle {
	struct TSoftObjectPtr<UControlRig> ControlRig; // 0x60(0x20)
	struct FName ControlName; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
};

// Class ControlRig.ControlRigAnimInstance
// Size: 0x370 (Inherited: 0x370)
struct UControlRigAnimInstance : UAnimInstance {
};

// Class ControlRig.ControlRigBlueprintGeneratedClass
// Size: 0x388 (Inherited: 0x388)
struct UControlRigBlueprintGeneratedClass : URigVMBlueprintGeneratedClass {
};

// Class ControlRig.ControlRigComponent
// Size: 0x670 (Inherited: 0x510)
struct UControlRigComponent : UPrimitiveComponent {
	struct UControlRig* ControlRigClass; // 0x508(0x08)
	struct FMulticastInlineDelegate OnPreInitializeDelegate; // 0x510(0x10)
	struct FMulticastInlineDelegate OnPostInitializeDelegate; // 0x520(0x10)
	struct FMulticastInlineDelegate OnPreConstructionDelegate; // 0x530(0x10)
	struct FMulticastInlineDelegate OnPostConstructionDelegate; // 0x540(0x10)
	struct FMulticastInlineDelegate OnPreForwardsSolveDelegate; // 0x550(0x10)
	struct FMulticastInlineDelegate OnPostForwardsSolveDelegate; // 0x560(0x10)
	struct TArray<struct FControlRigComponentMappedElement> UserDefinedElements; // 0x570(0x10)
	struct TArray<struct FControlRigComponentMappedElement> MappedElements; // 0x580(0x10)
	bool bEnableLazyEvaluation; // 0x590(0x01)
	float LazyEvaluationPositionThreshold; // 0x594(0x04)
	float LazyEvaluationRotationThreshold; // 0x598(0x04)
	float LazyEvaluationScaleThreshold; // 0x59c(0x04)
	bool bResetTransformBeforeTick; // 0x5a0(0x01)
	bool bResetInitialsBeforeConstruction; // 0x5a1(0x01)
	bool bUpdateRigOnTick; // 0x5a2(0x01)
	bool bUpdateInEditor; // 0x5a3(0x01)
	bool bDrawBones; // 0x5a4(0x01)
	bool bShowDebugDrawing; // 0x5a5(0x01)
	struct UControlRig* ControlRig; // 0x5a8(0x08)
	char pad_5B3[0xbd]; // 0x5b3(0xbd)

	void Update(float DeltaTime); // Function ControlRig.ControlRigComponent.Update // (Final|Native|Public|BlueprintCallable) // @ game+0x8052c00
	void SetObjectBinding(struct UObject* InObjectToBind); // Function ControlRig.ControlRigComponent.SetObjectBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x80514f4
	void SetMappedElements(struct TArray<struct FControlRigComponentMappedElement> NewMappedElements); // Function ControlRig.ControlRigComponent.SetMappedElements // (Final|Native|Public|BlueprintCallable) // @ game+0x8050bac
	void SetInitialSpaceTransform(struct FName SpaceName, struct FTransform InitialTransform, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.SetInitialSpaceTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x80508e0
	void SetInitialBoneTransform(struct FName BoneName, struct FTransform InitialTransform, enum class EControlRigComponentSpace Space, bool bPropagateToChildren); // Function ControlRig.ControlRigComponent.SetInitialBoneTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8050600
	void SetControlVector2D(struct FName ControlName, struct FVector2D Value); // Function ControlRig.ControlRigComponent.SetControlVector2D // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x805029c
	void SetControlTransform(struct FName ControlName, struct FTransform Value, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.SetControlTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8050040
	void SetControlScale(struct FName ControlName, struct FVector Value, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.SetControlScale // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x804fe78
	void SetControlRotator(struct FName ControlName, struct FRotator Value, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.SetControlRotator // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x804fcb0
	void SetControlRigClass(struct UControlRig* InControlRigClass); // Function ControlRig.ControlRigComponent.SetControlRigClass // (Final|Native|Public|BlueprintCallable) // @ game+0x804fbc4
	void SetControlPosition(struct FName ControlName, struct FVector Value, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.SetControlPosition // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x804f8a4
	void SetControlOffset(struct FName ControlName, struct FTransform OffsetTransform, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.SetControlOffset // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x804f648
	void SetControlInt(struct FName ControlName, int32_t Value); // Function ControlRig.ControlRigComponent.SetControlInt // (Final|Native|Public|BlueprintCallable) // @ game+0x804f4cc
	void SetControlFloat(struct FName ControlName, float Value); // Function ControlRig.ControlRigComponent.SetControlFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x804f390
	void SetControlBool(struct FName ControlName, bool Value); // Function ControlRig.ControlRigComponent.SetControlBool // (Final|Native|Public|BlueprintCallable) // @ game+0x804f210
	void SetBoneTransform(struct FName BoneName, struct FTransform Transform, enum class EControlRigComponentSpace Space, float Weight, bool bPropagateToChildren); // Function ControlRig.ControlRigComponent.SetBoneTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x804e630
	void SetBoneInitialTransformsFromSkeletalMesh(struct USkeletalMesh* InSkeletalMesh); // Function ControlRig.ControlRigComponent.SetBoneInitialTransformsFromSkeletalMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x804e554
	void OnPreInitialize(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPreInitialize // (Native|Event|Public|BlueprintEvent) // @ game+0x804d054
	void OnPreForwardsSolve(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPreForwardsSolve // (Native|Event|Public|BlueprintEvent) // @ game+0x804cf90
	void OnPreConstruction(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPreConstruction // (Native|Event|Public|BlueprintEvent) // @ game+0x804cecc
	void OnPostInitialize(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPostInitialize // (Native|Event|Public|BlueprintEvent) // @ game+0x804ce08
	void OnPostForwardsSolve(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPostForwardsSolve // (Native|Event|Public|BlueprintEvent) // @ game+0x6895300
	void OnPostConstruction(struct UControlRigComponent* Component); // Function ControlRig.ControlRigComponent.OnPostConstruction // (Native|Event|Public|BlueprintEvent) // @ game+0x804cd44
	void Initialize(); // Function ControlRig.ControlRigComponent.Initialize // (Final|Native|Public|BlueprintCallable) // @ game+0x804c3a4
	struct FTransform GetSpaceTransform(struct FName SpaceName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetSpaceTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804c12c
	struct FTransform GetInitialSpaceTransform(struct FName SpaceName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetInitialSpaceTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804bf24
	struct FTransform GetInitialBoneTransform(struct FName BoneName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetInitialBoneTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804bd88
	struct TArray<struct FName> GetElementNames(enum class ERigElementType ElementType); // Function ControlRig.ControlRigComponent.GetElementNames // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x804ba40
	struct FVector2D GetControlVector2D(struct FName ControlName); // Function ControlRig.ControlRigComponent.GetControlVector2D // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804b968
	struct FTransform GetControlTransform(struct FName ControlName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetControlTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804b7cc
	struct FVector GetControlScale(struct FName ControlName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetControlScale // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804b650
	struct FRotator GetControlRotator(struct FName ControlName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetControlRotator // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804b4b4
	struct UControlRig* GetControlRig(); // Function ControlRig.ControlRigComponent.GetControlRig // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x804b490
	struct FVector GetControlPosition(struct FName ControlName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetControlPosition // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804b314
	struct FTransform GetControlOffset(struct FName ControlName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetControlOffset // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x804b178
	int32_t GetControlInt(struct FName ControlName); // Function ControlRig.ControlRigComponent.GetControlInt // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x804b04c
	float GetControlFloat(struct FName ControlName); // Function ControlRig.ControlRigComponent.GetControlFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x804af7c
	bool GetControlBool(struct FName ControlName); // Function ControlRig.ControlRigComponent.GetControlBool // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x804ae4c
	struct FTransform GetBoneTransform(struct FName BoneName, enum class EControlRigComponentSpace Space); // Function ControlRig.ControlRigComponent.GetBoneTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x804acb0
	float GetAbsoluteTime(); // Function ControlRig.ControlRigComponent.GetAbsoluteTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804ac84
	bool DoesElementExist(struct FName Name, enum class ERigElementType ElementType); // Function ControlRig.ControlRigComponent.DoesElementExist // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x804a984
	void ClearMappedElements(); // Function ControlRig.ControlRigComponent.ClearMappedElements // (Final|Native|Public|BlueprintCallable) // @ game+0x8049104
	bool CanExecute(); // Function ControlRig.ControlRigComponent.CanExecute // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x80490a4
	void AddMappedSkeletalMesh(struct USkeletalMeshComponent* SkeletalMeshComponent, struct TArray<struct FControlRigComponentMappedBone> Bones, struct TArray<struct FControlRigComponentMappedCurve> Curves, enum class EControlRigComponentMapDirection InDirection); // Function ControlRig.ControlRigComponent.AddMappedSkeletalMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x80471e0
	void AddMappedElements(struct TArray<struct FControlRigComponentMappedElement> NewMappedElements); // Function ControlRig.ControlRigComponent.AddMappedElements // (Final|Native|Public|BlueprintCallable) // @ game+0x80470f8
	void AddMappedComponents(struct TArray<struct FControlRigComponentMappedComponent> Components); // Function ControlRig.ControlRigComponent.AddMappedComponents // (Final|Native|Public|BlueprintCallable) // @ game+0x804696c
	void AddMappedCompleteSkeletalMesh(struct USkeletalMeshComponent* SkeletalMeshComponent, enum class EControlRigComponentMapDirection InDirection); // Function ControlRig.ControlRigComponent.AddMappedCompleteSkeletalMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x8046808
};

// Class ControlRig.ControlRigControlActor
// Size: 0x338 (Inherited: 0x290)
struct AControlRigControlActor : AActor {
	struct AActor* ActorToTrack; // 0x290(0x08)
	struct UControlRig* ControlRigClass; // 0x298(0x08)
	bool bRefreshOnTick; // 0x2a0(0x01)
	bool bIsSelectable; // 0x2a1(0x01)
	char pad_2A2[0x6]; // 0x2a2(0x06)
	struct UMaterialInterface* MaterialOverride; // 0x2a8(0x08)
	struct FString ColorParameter; // 0x2b0(0x10)
	bool bCastShadows; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct USceneComponent* ActorRootComponent; // 0x2c8(0x08)
	struct TSoftObjectPtr<UControlRig> ControlRig; // 0x2d0(0x20)
	struct TArray<struct FName> ControlNames; // 0x2f0(0x10)
	struct TArray<struct FTransform> ShapeTransforms; // 0x300(0x10)
	struct TArray<struct UStaticMeshComponent*> Components; // 0x310(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> Materials; // 0x320(0x10)
	struct FName ColorParameterName; // 0x330(0x04)
	char pad_334[0x4]; // 0x334(0x04)

	void ResetControlActor(); // Function ControlRig.ControlRigControlActor.ResetControlActor // (Final|Native|Public|BlueprintCallable) // @ game+0x804e42c
	void Refresh(); // Function ControlRig.ControlRigControlActor.Refresh // (Final|Native|Public|BlueprintCallable) // @ game+0x804d3ac
	void Clear(); // Function ControlRig.ControlRigControlActor.Clear // (Final|Native|Public|BlueprintCallable) // @ game+0x80490c8
};

// Class ControlRig.ControlRigShapeActor
// Size: 0x340 (Inherited: 0x290)
struct AControlRigShapeActor : AActor {
	struct USceneComponent* ActorRootComponent; // 0x290(0x08)
	struct UStaticMeshComponent* StaticMeshComponent; // 0x298(0x08)
	uint32_t ControlRigIndex; // 0x2a0(0x04)
	struct TWeakObjectPtr<struct UControlRig> ControlRig; // 0x2a4(0x08)
	struct FName ControlName; // 0x2ac(0x04)
	struct FName ShapeName; // 0x2b0(0x04)
	struct FName ColorParameterName; // 0x2b4(0x04)
	char pad_2B8[0x78]; // 0x2b8(0x78)
	char bSelected : 1; // 0x330(0x01)
	char bHovered : 1; // 0x330(0x01)
	char pad_330_2 : 6; // 0x330(0x01)
	char pad_331[0xf]; // 0x331(0x0f)

	void SetSelected(bool bInSelected); // Function ControlRig.ControlRigShapeActor.SetSelected // (Native|Public|BlueprintCallable) // @ game+0x68f1c3c
	void SetSelectable(bool bInSelectable); // Function ControlRig.ControlRigShapeActor.SetSelectable // (Native|Public|BlueprintCallable) // @ game+0x80515b4
	void SetHovered(bool bInHovered); // Function ControlRig.ControlRigShapeActor.SetHovered // (Native|Public|BlueprintCallable) // @ game+0x8050538
	void SetGlobalTransform(struct FTransform& InTransform); // Function ControlRig.ControlRigShapeActor.SetGlobalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x8050428
	void SetEnabled(bool bInEnabled); // Function ControlRig.ControlRigShapeActor.SetEnabled // (Native|Public|BlueprintCallable) // @ game+0x65cd42c
	void OnTransformChanged(struct FTransform& NewTransform); // Function ControlRig.ControlRigShapeActor.OnTransformChanged // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
	void OnSelectionChanged(bool bIsSelected); // Function ControlRig.ControlRigShapeActor.OnSelectionChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnManipulatingChanged(bool bIsManipulating); // Function ControlRig.ControlRigShapeActor.OnManipulatingChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnHoveredChanged(bool bIsSelected); // Function ControlRig.ControlRigShapeActor.OnHoveredChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnEnabledChanged(bool bIsEnabled); // Function ControlRig.ControlRigShapeActor.OnEnabledChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	bool IsSelectedInEditor(); // Function ControlRig.ControlRigShapeActor.IsSelectedInEditor // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6b967c0
	bool IsHovered(); // Function ControlRig.ControlRigShapeActor.IsHovered // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804c480
	bool IsEnabled(); // Function ControlRig.ControlRigShapeActor.IsEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804c458
	struct FTransform GetGlobalTransform(); // Function ControlRig.ControlRigShapeActor.GetGlobalTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x804bc7c
};

// Class ControlRig.ControlRigShapeLibrary
// Size: 0x140 (Inherited: 0x28)
struct UControlRigShapeLibrary : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FControlRigShapeDefinition DefaultShape; // 0x30(0xa0)
	struct TSoftObjectPtr<UMaterial> DefaultMaterial; // 0xd0(0x20)
	struct TSoftObjectPtr<UMaterial> XRayMaterial; // 0xf0(0x20)
	struct FName MaterialColorParameter; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
	struct TArray<struct FControlRigShapeDefinition> Shapes; // 0x118(0x10)
	char pad_128[0x18]; // 0x128(0x18)
};

// Class ControlRig.ControlRigTestData
// Size: 0x148 (Inherited: 0x28)
struct UControlRigTestData : UObject {
	struct FSoftObjectPath ControlRigObjectPath; // 0x28(0x18)
	struct FControlRigTestDataFrame Initial; // 0x40(0x90)
	struct TArray<struct FControlRigTestDataFrame> InputFrames; // 0xd0(0x10)
	struct TArray<struct FControlRigTestDataFrame> OutputFrames; // 0xe0(0x10)
	struct TArray<int32_t> FramesToSkip; // 0xf0(0x10)
	double Tolerance; // 0x100(0x08)
	char pad_108[0x40]; // 0x108(0x40)

	bool SetupReplay(struct UControlRig* InControlRig, bool bGroundTruth); // Function ControlRig.ControlRigTestData.SetupReplay // (Final|Native|Public|BlueprintCallable) // @ game+0x805167c
	void ReleaseReplay(); // Function ControlRig.ControlRigTestData.ReleaseReplay // (Final|Native|Public|BlueprintCallable) // @ game+0x804d3c0
	bool Record(struct UControlRig* InControlRig, double InRecordingDuration); // Function ControlRig.ControlRigTestData.Record // (Final|Native|Public|BlueprintCallable) // @ game+0x804d118
	bool IsReplaying(); // Function ControlRig.ControlRigTestData.IsReplaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804c4cc
	bool IsRecording(); // Function ControlRig.ControlRigTestData.IsRecording // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804c4a8
	struct FVector2D GetTimeRange(bool bInput); // Function ControlRig.ControlRigTestData.GetTimeRange // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x804c2c8
	enum class EControlRigTestDataPlaybackMode GetPlaybackMode(); // Function ControlRig.ControlRigTestData.GetPlaybackMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804c0ec
	int32_t GetFrameIndexForTime(double InSeconds, bool bInput); // Function ControlRig.ControlRigTestData.GetFrameIndexForTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x804bb24
	struct UControlRigTestData* CreateNewAsset(struct FString InDesiredPackagePath, struct FString InBlueprintPathName); // Function ControlRig.ControlRigTestData.CreateNewAsset // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8049688
};

// Class ControlRig.ControlRigValidator
// Size: 0x68 (Inherited: 0x28)
struct UControlRigValidator : UObject {
	struct TArray<struct UControlRigValidationPass*> Passes; // 0x28(0x10)
	char pad_38[0x30]; // 0x38(0x30)
};

// Class ControlRig.ControlRigValidationPass
// Size: 0x28 (Inherited: 0x28)
struct UControlRigValidationPass : UObject {
};

// Class ControlRig.ModularRigController
// Size: 0x50 (Inherited: 0x28)
struct UModularRigController : UObject {
	char pad_28[0x28]; // 0x28(0x28)

	bool UnBindModuleVariable(struct FString InModulePath, struct FName& InVariableName, bool bSetupUndo); // Function ControlRig.ModularRigController.UnBindModuleVariable // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8052420
	bool SwapModulesOfClass(struct UControlRig* InOldClass, struct UControlRig* InNewClass, bool bSetupUndo); // Function ControlRig.ModularRigController.SwapModulesOfClass // (Final|Native|Public|BlueprintCallable) // @ game+0x80521ec
	bool SwapModuleClass(struct FString InModulePath, struct UControlRig* InNewClass, bool bSetupUndo); // Function ControlRig.ModularRigController.SwapModuleClass // (Final|Native|Public|BlueprintCallable) // @ game+0x80519b8
	bool SetModuleShortName(struct FString InModulePath, struct FString InNewShortName, bool bSetupUndo); // Function ControlRig.ModularRigController.SetModuleShortName // (Final|Native|Public|BlueprintCallable) // @ game+0x8050cc8
	bool SetConfigValueInModule(struct FString InModulePath, struct FName& InVariableName, struct FString InValue, bool bSetupUndo); // Function ControlRig.ModularRigController.SetConfigValueInModule // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x804e994
	struct FString ReparentModule(struct FString InModulePath, struct FString InNewParentModulePath, bool bSetupUndo); // Function ControlRig.ModularRigController.ReparentModule // (Final|Native|Public|BlueprintCallable) // @ game+0x804dbd4
	struct FString RenameModule(struct FString InModulePath, struct FName& InNewName, bool bSetupUndo); // Function ControlRig.ModularRigController.RenameModule // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x804d3d4
	struct FString MirrorModule(struct FString InModulePath, struct FRigVMMirrorSettings& InSettings, bool bSetupUndo); // Function ControlRig.ModularRigController.MirrorModule // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x804c4f0
	struct TArray<struct FRigElementKey> DisconnectCyclicConnectors(bool bSetupUndo); // Function ControlRig.ModularRigController.DisconnectCyclicConnectors // (Final|Native|Public|BlueprintCallable) // @ game+0x804a8ac
	bool DisconnectConnector(struct FRigElementKey& InConnectorKey, bool bDisconnectSubModules, bool bSetupUndo); // Function ControlRig.ModularRigController.DisconnectConnector // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x804a6e8
	bool DeleteModule(struct FString InModulePath, bool bSetupUndo); // Function ControlRig.ModularRigController.DeleteModule // (Final|Native|Public|BlueprintCallable) // @ game+0x8049f40
	bool ConnectConnectorToElement(struct FRigElementKey& InConnectorKey, struct FRigElementKey& InTargetKey, bool bSetupUndo, bool bAutoResolveOtherConnectors, bool bCheckValidConnection); // Function ControlRig.ModularRigController.ConnectConnectorToElement // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8049118
	bool CanConnectConnectorToElement(struct FRigElementKey& InConnectorKey, struct FRigElementKey& InTargetKey, struct FText& OutErrorMessage); // Function ControlRig.ModularRigController.CanConnectConnectorToElement // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8048f3c
	bool BindModuleVariable(struct FString InModulePath, struct FName& InVariableName, struct FString InSourcePath, bool bSetupUndo); // Function ControlRig.ModularRigController.BindModuleVariable // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x80486c0
	bool AutoConnectSecondaryConnectors(struct TArray<struct FRigElementKey>& InConnectorKeys, bool bReplaceExistingConnections, bool bSetupUndo); // Function ControlRig.ModularRigController.AutoConnectSecondaryConnectors // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8048510
	bool AutoConnectModules(struct TArray<struct FString>& InModulePaths, bool bReplaceExistingConnections, bool bSetupUndo); // Function ControlRig.ModularRigController.AutoConnectModules // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8048368
	struct FString AddModule(struct FName& InModuleName, struct UControlRig* InClass, struct FString InParentModulePath, bool bSetupUndo); // Function ControlRig.ModularRigController.AddModule // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8047ac8
};

// Class ControlRig.ModularRigRuleManager
// Size: 0x30 (Inherited: 0x28)
struct UModularRigRuleManager : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class ControlRig.AdditiveControlRig
// Size: 0xab0 (Inherited: 0xaa0)
struct UAdditiveControlRig : UControlRig {
	char pad_AA0[0x10]; // 0xaa0(0x10)
};

// Class ControlRig.FKControlRig
// Size: 0xae0 (Inherited: 0xaa0)
struct UFKControlRig : UControlRig {
	struct TArray<bool> IsControlActive; // 0xaa0(0x10)
	enum class EControlRigFKRigExecuteMode ApplyMode; // 0xab0(0x01)
	char pad_AB1[0x2f]; // 0xab1(0x2f)
};

// Class ControlRig.RigHierarchyController
// Size: 0x90 (Inherited: 0x28)
struct URigHierarchyController : UObject {
	bool bReportWarningsAndErrors; // 0x28(0x01)
	char pad_29[0x67]; // 0x29(0x67)

	bool SetSelection(struct TArray<struct FRigElementKey>& InKeys, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.SetSelection // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x808ef14
	bool SetParent(struct FRigElementKey InChild, struct FRigElementKey InParent, bool bMaintainGlobalTransform, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.SetParent // (Final|Native|Public|BlueprintCallable) // @ game+0x808ec54
	void SetHierarchy(struct URigHierarchy* InHierarchy); // Function ControlRig.RigHierarchyController.SetHierarchy // (Final|Native|Public|BlueprintCallable) // @ game+0x808eb94
	struct FName SetDisplayName(struct FRigElementKey InControl, struct FName InDisplayName, bool bRenameElement, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.SetDisplayName // (Final|Native|Public|BlueprintCallable) // @ game+0x808e8d0
	bool SetControlSettings(struct FRigElementKey InKey, struct FRigControlSettings InSettings, bool bSetupUndo); // Function ControlRig.RigHierarchyController.SetControlSettings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x808e6c0
	bool SelectElement(struct FRigElementKey InKey, bool bSelect, bool bClearSelection); // Function ControlRig.RigHierarchyController.SelectElement // (Final|Native|Public|BlueprintCallable) // @ game+0x808e4ec
	bool ReorderElement(struct FRigElementKey InElement, int32_t InIndex, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.ReorderElement // (Final|Native|Public|BlueprintCallable) // @ game+0x808e2bc
	struct FRigElementKey RenameElement(struct FRigElementKey InElement, struct FName InName, bool bSetupUndo, bool bPrintPythonCommand, bool bClearSelection); // Function ControlRig.RigHierarchyController.RenameElement // (Final|Native|Public|BlueprintCallable) // @ game+0x808e008
	bool RemoveParent(struct FRigElementKey InChild, struct FRigElementKey InParent, bool bMaintainGlobalTransform, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.RemoveParent // (Final|Native|Public|BlueprintCallable) // @ game+0x808dd48
	bool RemoveElement(struct FRigElementKey InElement, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.RemoveElement // (Final|Native|Public|BlueprintCallable) // @ game+0x808db88
	bool RemoveAllParents(struct FRigElementKey InChild, bool bMaintainGlobalTransform, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.RemoveAllParents // (Final|Native|Public|BlueprintCallable) // @ game+0x808d944
	struct TArray<struct FRigElementKey> MirrorElements(struct TArray<struct FRigElementKey> InKeys, struct FRigVMMirrorSettings InSettings, bool bSelectNewElements, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchyController.MirrorElements // (Final|Native|Public|BlueprintCallable) // @ game+0x808cf8c
	struct TArray<struct FRigElementKey> ImportFromText(struct FString InContent, bool bReplaceExistingElements, bool bSelectNewElements, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchyController.ImportFromText // (Final|Native|Public|BlueprintCallable) // @ game+0x808c630
	struct TArray<struct FRigElementKey> ImportCurves(struct USkeleton* InSkeleton, struct FName InNameSpace, bool bSelectCurves, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.ImportCurves // (Final|Native|Public|BlueprintCallable) // @ game+0x808c2b0
	struct TArray<struct FRigElementKey> ImportBones(struct USkeleton* InSkeleton, struct FName InNameSpace, bool bReplaceExistingBones, bool bRemoveObsoleteBones, bool bSelectBones, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.ImportBones // (Final|Native|Public|BlueprintCallable) // @ game+0x808be50
	struct URigHierarchy* GetHierarchy(); // Function ControlRig.RigHierarchyController.GetHierarchy // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x808be2c
	struct FRigControlSettings GetControlSettings(struct FRigElementKey InKey); // Function ControlRig.RigHierarchyController.GetControlSettings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x808bcf4
	struct FString ExportToText(struct TArray<struct FRigElementKey> InKeys); // Function ControlRig.RigHierarchyController.ExportToText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x808b59c
	struct FString ExportSelectionToText(); // Function ControlRig.RigHierarchyController.ExportSelectionToText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x808aed0
	struct TArray<struct FRigElementKey> DuplicateElements(struct TArray<struct FRigElementKey> InKeys, bool bSelectNewElements, bool bSetupUndo, bool bPrintPythonCommands); // Function ControlRig.RigHierarchyController.DuplicateElements // (Final|Native|Public|BlueprintCallable) // @ game+0x808ac38
	bool DeselectElement(struct FRigElementKey InKey); // Function ControlRig.RigHierarchyController.DeselectElement // (Final|Native|Public|BlueprintCallable) // @ game+0x808ab60
	bool ClearSelection(); // Function ControlRig.RigHierarchyController.ClearSelection // (Final|Native|Public|BlueprintCallable) // @ game+0x808ab3c
	struct FRigElementKey AddSocket(struct FName InName, struct FRigElementKey InParent, struct FTransform InTransform, bool bTransformInGlobal, struct FLinearColor& InColor, struct FString InDescription, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddSocket // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x8089fe8
	struct FRigElementKey AddRigidBody(struct FName InName, struct FRigElementKey InParent, struct FRigRigidBodySettings InSettings, struct FTransform InLocalTransform, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddRigidBody // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8089c04
	bool AddParent(struct FRigElementKey InChild, struct FRigElementKey InParent, float InWeight, bool bMaintainGlobalTransform, bool bSetupUndo); // Function ControlRig.RigHierarchyController.AddParent // (Final|Native|Public|BlueprintCallable) // @ game+0x8089940
	struct FRigElementKey AddNull(struct FName InName, struct FRigElementKey InParent, struct FTransform InTransform, bool bTransformInGlobal, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddNull // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8089550
	struct FRigElementKey AddCurve(struct FName InName, float InValue, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddCurve // (Final|Native|Public|BlueprintCallable) // @ game+0x808931c
	struct FRigElementKey AddControl_ForBlueprint(struct FName InName, struct FRigElementKey InParent, struct FRigControlSettings InSettings, struct FRigControlValue InValue, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddControl_ForBlueprint // (Final|Native|Public|BlueprintCallable) // @ game+0x8088ee0
	struct FRigElementKey AddConnector(struct FName InName, struct FRigConnectorSettings InSettings, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddConnector // (Final|Native|Public|BlueprintCallable) // @ game+0x8088c80
	struct FRigElementKey AddBone(struct FName InName, struct FRigElementKey InParent, struct FTransform InTransform, bool bTransformInGlobal, enum class ERigBoneType InBoneType, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddBone // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8088814
	struct FRigElementKey AddAnimationChannel_ForBlueprint(struct FName InName, struct FRigElementKey InParentControl, struct FRigControlSettings InSettings, bool bSetupUndo, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.AddAnimationChannel_ForBlueprint // (Final|Native|Public|BlueprintCallable) // @ game+0x80884f0
};

// Class ControlRig.ControlRigLayerInstance
// Size: 0x370 (Inherited: 0x370)
struct UControlRigLayerInstance : UAnimInstance {
};

// Class ControlRig.MovieSceneControlRigParameterSection
// Size: 0x3d0 (Inherited: 0x158)
struct UMovieSceneControlRigParameterSection : UMovieSceneParameterSection {
	char pad_158[0x48]; // 0x158(0x48)
	struct UControlRig* ControlRig; // 0x1a0(0x08)
	struct UControlRig* ControlRigClass; // 0x1a8(0x08)
	struct TArray<bool> ControlsMask; // 0x1b0(0x10)
	struct FMovieSceneTransformMask TransformMask; // 0x1c0(0x04)
	char pad_1C4[0x4]; // 0x1c4(0x04)
	struct FMovieSceneFloatChannel Weight; // 0x1c8(0x110)
	struct TMap<struct FName, struct FChannelMapInfo> ControlChannelMap; // 0x2d8(0x50)
	struct TArray<struct FEnumParameterNameAndCurve> EnumParameterNamesAndCurves; // 0x328(0x10)
	struct TArray<struct FIntegerParameterNameAndCurve> IntegerParameterNamesAndCurves; // 0x338(0x10)
	struct TArray<struct FSpaceControlNameAndChannel> SpaceChannels; // 0x348(0x10)
	struct TArray<struct FConstraintAndActiveChannel> ConstraintsChannels; // 0x358(0x10)
	char pad_368[0x68]; // 0x368(0x68)
};

// Class ControlRig.MovieSceneControlRigParameterTrack
// Size: 0x1a8 (Inherited: 0x98)
struct UMovieSceneControlRigParameterTrack : UMovieSceneNameableTrack {
	char pad_98[0x40]; // 0x98(0x40)
	struct UControlRig* ControlRig; // 0xd8(0x08)
	struct UMovieSceneSection* SectionToKey; // 0xe0(0x08)
	struct TArray<struct UMovieSceneSection*> Sections; // 0xe8(0x10)
	struct FName TrackName; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
	struct TMap<struct FName, struct FControlRotationOrder> ControlsRotationOrder; // 0x100(0x50)
	int32_t PriorityOrder; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct TMap<struct TWeakObjectPtr<struct UWorld>, struct UControlRig*> GameWorldControlRigs; // 0x158(0x50)
};

// Class ControlRig.ControlRigSettings
// Size: 0x30 (Inherited: 0x30)
struct UControlRigSettings : UDeveloperSettings {
};

// Class ControlRig.ControlRigEditorSettings
// Size: 0x30 (Inherited: 0x30)
struct UControlRigEditorSettings : URigVMEditorSettings {
};

// Class ControlRig.ControlRigPoseAsset
// Size: 0x88 (Inherited: 0x28)
struct UControlRigPoseAsset : UObject {
	struct FControlRigControlPose Pose; // 0x28(0x60)

	void SelectControls(struct UControlRig* InControlRig, bool bDoMirror); // Function ControlRig.ControlRigPoseAsset.SelectControls // (Final|Native|Public|BlueprintCallable) // @ game+0x8111404
	void SavePose(struct UControlRig* InControlRig, bool bUseAll); // Function ControlRig.ControlRigPoseAsset.SavePose // (Final|Native|Public|BlueprintCallable) // @ game+0x81112c4
	void ReplaceControlName(struct FName& CurrentName, struct FName& NewName); // Function ControlRig.ControlRigPoseAsset.ReplaceControlName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x81111ec
	void PastePose(struct UControlRig* InControlRig, bool bDoKey, bool bDoMirror); // Function ControlRig.ControlRigPoseAsset.PastePose // (Final|Native|Public|BlueprintCallable) // @ game+0x8110ef8
	void GetCurrentPose(struct UControlRig* InControlRig, struct FControlRigControlPose& OutPose); // Function ControlRig.ControlRigPoseAsset.GetCurrentPose // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8110d94
	struct TArray<struct FName> GetControlNames(); // Function ControlRig.ControlRigPoseAsset.GetControlNames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8110d4c
	bool DoesMirrorMatch(struct UControlRig* ControlRig, struct FName& ControlName); // Function ControlRig.ControlRigPoseAsset.DoesMirrorMatch // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8110bcc
};

// Class ControlRig.ControlRigPoseMirrorSettings
// Size: 0x50 (Inherited: 0x28)
struct UControlRigPoseMirrorSettings : UObject {
	struct FString RightSide; // 0x28(0x10)
	struct FString LeftSide; // 0x38(0x10)
	enum class EAxis MirrorAxis; // 0x48(0x01)
	enum class EAxis AxisToFlip; // 0x49(0x01)
	char pad_4A[0x6]; // 0x4a(0x06)
};

// Class ControlRig.ControlRigPoseProjectSettings
// Size: 0x38 (Inherited: 0x28)
struct UControlRigPoseProjectSettings : UObject {
	struct TArray<struct FDirectoryPath> RootSaveDirs; // 0x28(0x10)
};

// Class ControlRig.ControlRigWorkflowOptions
// Size: 0xb0 (Inherited: 0x98)
struct UControlRigWorkflowOptions : URigVMUserWorkflowOptions {
	struct URigHierarchy* Hierarchy; // 0x98(0x08)
	struct TArray<struct FRigElementKey> Selection; // 0xa0(0x10)

	bool EnsureAtLeastOneRigElementSelected(); // Function ControlRig.ControlRigWorkflowOptions.EnsureAtLeastOneRigElementSelected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8110cd8
};

// Class ControlRig.ControlRigTransformWorkflowOptions
// Size: 0xb8 (Inherited: 0xb0)
struct UControlRigTransformWorkflowOptions : UControlRigWorkflowOptions {
	enum class ERigTransformType TransformType; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)

	struct TArray<struct FRigVMUserWorkflow> ProvideWorkflows(struct UObject* InSubject); // Function ControlRig.ControlRigTransformWorkflowOptions.ProvideWorkflows // (Final|Native|Public) // @ game+0x81110dc
};

// Class ControlRig.ControlRigNumericalValidationPass
// Size: 0xb8 (Inherited: 0x28)
struct UControlRigNumericalValidationPass : UControlRigValidationPass {
	bool bCheckControls; // 0x28(0x01)
	bool bCheckBones; // 0x29(0x01)
	bool bCheckCurves; // 0x2a(0x01)
	char pad_2B[0x1]; // 0x2b(0x01)
	float TranslationPrecision; // 0x2c(0x04)
	float RotationPrecision; // 0x30(0x04)
	float ScalePrecision; // 0x34(0x04)
	float CurvePrecision; // 0x38(0x04)
	struct FName EventNameA; // 0x3c(0x04)
	struct FName EventNameB; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FRigPose Pose; // 0x48(0x70)
};

