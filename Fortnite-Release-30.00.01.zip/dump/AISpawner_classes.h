// Class AISpawner.AISpawnerPreviewerComponent
// Size: 0x280 (Inherited: 0x270)
struct UAISpawnerPreviewerComponent : UChildActorComponent {
	struct AFortPlayerMannequin* PlayerMannequinClass; // 0x270(0x08)
	struct UAnimInstance* DefaultCustomAnimationBPClass; // 0x278(0x08)

	void SetCIDForPreview(struct UAthenaCharacterItemDefinition* InCID); // Function AISpawner.AISpawnerPreviewerComponent.SetCIDForPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xcb6d968
	void SetActorForPreview(struct AActor* InActorClass); // Function AISpawner.AISpawnerPreviewerComponent.SetActorForPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xcb6d798
	void ClearCIDPreview(); // Function AISpawner.AISpawnerPreviewerComponent.ClearCIDPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xcb6d784
	void ClearActorPreview(); // Function AISpawner.AISpawnerPreviewerComponent.ClearActorPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xcb6d784
};

// Class AISpawner.FortAthenaMutator_AISpawner
// Size: 0x490 (Inherited: 0x488)
struct AFortAthenaMutator_AISpawner : AFortAthenaMutator_GameModeBase {
	char pad_488[0x8]; // 0x488(0x08)
};

