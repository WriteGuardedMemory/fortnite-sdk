// BlueprintGeneratedClass CommonUI_XboxBrushData.CommonUI_XboxBrushData_C
// Size: 0xd0 (Inherited: 0xd0)
struct UCommonUI_XboxBrushData_C : UFortInputControllerData {
};

