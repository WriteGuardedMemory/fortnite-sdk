// WidgetBlueprintGeneratedClass CorrectiveActionDateOfBirthScreen.CorrectiveActionDateOfBirthScreen_C
// Size: 0x458 (Inherited: 0x448)
struct UCorrectiveActionDateOfBirthScreen_C : UFortCorrectiveActionDateOfBirthScreen {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x448(0x08)
	struct UCommonTextBlock* Text_AgeEntryChallengeError; // 0x450(0x08)

	void OnShowFailureReason(struct FText& FailureReason); // Function CorrectiveActionDateOfBirthScreen.CorrectiveActionDateOfBirthScreen_C.OnShowFailureReason // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnShowCorrectiveActionProcessing(bool bShowProcessing); // Function CorrectiveActionDateOfBirthScreen.CorrectiveActionDateOfBirthScreen_C.OnShowCorrectiveActionProcessing // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__CorrectiveActionDateOfBirthScreen_Button_Continue_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function CorrectiveActionDateOfBirthScreen.CorrectiveActionDateOfBirthScreen_C.BndEvt__CorrectiveActionDateOfBirthScreen_Button_Continue_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__CorrectiveActionDateOfBirthScreen_Button_PrivacyPolicy_K2Node_ComponentBoundEvent_1_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function CorrectiveActionDateOfBirthScreen.CorrectiveActionDateOfBirthScreen_C.BndEvt__CorrectiveActionDateOfBirthScreen_Button_PrivacyPolicy_K2Node_ComponentBoundEvent_1_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_CorrectiveActionDateOfBirthScreen(int32_t EntryPoint); // Function CorrectiveActionDateOfBirthScreen.CorrectiveActionDateOfBirthScreen_C.ExecuteUbergraph_CorrectiveActionDateOfBirthScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

