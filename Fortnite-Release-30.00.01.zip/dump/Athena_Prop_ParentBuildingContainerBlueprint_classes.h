// BlueprintGeneratedClass Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C
// Size: 0xce0 (Inherited: 0xbd0)
struct AAthena_Prop_ParentBuildingContainerBlueprint_C : ABuildingProp {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbd0(0x08)
	bool DebugWind; // 0xbd8(0x01)
	char pad_BD9[0x7]; // 0xbd9(0x07)
	struct TArray<struct UMaterialInterface*> IntenseWindMaterialsForPreview; // 0xbe0(0x10)
	struct UStaticMeshComponent* Wind Intensity Debug Mesh; // 0xbf0(0x08)
	struct TArray<struct UMaterialInterface*> OriginalMaterials; // 0xbf8(0x10)
	struct UMaterialInstanceDynamic* Debug_TempMaterial; // 0xc08(0x08)
	double DebugWindYaw; // 0xc10(0x08)
	double Debug Wind Intensity; // 0xc18(0x08)
	bool Set Max Actor Scale; // 0xc20(0x01)
	char pad_C21[0x7]; // 0xc21(0x07)
	double Max Scale; // 0xc28(0x08)
	bool Disable TOD Lights and Material Emissive Values; // 0xc30(0x01)
	bool Disable Static Mesh Shadow Casting When Lights Are Active; // 0xc31(0x01)
	bool Use An Alternate Shadow Mesh When The Light is On ; // 0xc32(0x01)
	char pad_C33[0x5]; // 0xc33(0x05)
	struct UStaticMesh* AlternateShadowStaticMesh; // 0xc38(0x08)
	bool Animate Emissive and Lights Over Time; // 0xc40(0x01)
	char pad_C41[0x7]; // 0xc41(0x07)
	struct TArray<struct FLinearColor> CodeControlled_EmissiveColor; // 0xc48(0x10)
	struct TArray<double> CodeControlled_LightConeOpacity; // 0xc58(0x10)
	struct FDayPhaseFloats Light Intensity Over Time of Day ; // 0xc68(0x10)
	double Day Phase Transition Length; // 0xc78(0x08)
	struct FDayPhaseFloats Emissive Intensity Over Time of Day; // 0xc80(0x10)
	double Volumetric Light Scattering Intensity; // 0xc90(0x08)
	bool Cast Volumetric Shadows; // 0xc98(0x01)
	bool Animate Lights With A Curve - Disables time of day light controls; // 0xc99(0x01)
	bool Animate Mesh MID Emissive Value with a Curve - Disables time of day light controls; // 0xc9a(0x01)
	char pad_C9B[0x5]; // 0xc9b(0x05)
	struct UCurveFloat* LightAnimationCurve; // 0xca0(0x08)
	double CodeControlled_Animation Curve Animation Length; // 0xca8(0x08)
	int32_t CodeControlled_NumberOfMaterials; // 0xcb0(0x04)
	char pad_CB4[0x4]; // 0xcb4(0x04)
	struct TArray<double> ; // 0xcb8(0x10)
	double Random Time Scale Percent; // 0xcc8(0x08)
	double CodeControlled_CurrentPlayLength; // 0xcd0(0x08)
	double Snow Coverage Amount; // 0xcd8(0x08)

	void GetTimeOfDayBlueprintDefaultVariables(struct FTimeOfDayBlueprintDefaultVariables& OutVariables); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.GetTimeOfDayBlueprintDefaultVariables // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UserConstructionScript(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnDayPhaseChanged(enum class EFortDayPhase CurrentDayPhase, enum class EFortDayPhase PreviousDayPhase, bool bAtCreation); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnDayPhaseChanged // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void Loop Animation Curve(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.Loop Animation Curve // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnBounceAnimationUpdate(struct FFortBounceData& Data); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnBounceAnimationUpdate // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnSetSearched(); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.OnSetSearched // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint(int32_t EntryPoint); // Function Athena_Prop_ParentBuildingContainerBlueprint.Athena_Prop_ParentBuildingContainerBlueprint_C.ExecuteUbergraph_Athena_Prop_ParentBuildingContainerBlueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

