// Class AnimationWarpingRuntime.AnimationWarpingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimationWarpingLibrary : UBlueprintFunctionLibrary {

	struct FTransform GetOffsetRootTransform(struct FAnimNodeReference& Node); // Function AnimationWarpingRuntime.AnimationWarpingLibrary.GetOffsetRootTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xd639928
	bool GetCurveValueFromAnimation(struct UAnimSequenceBase* Animation, struct FName CurveName, float Time, float& OutValue); // Function AnimationWarpingRuntime.AnimationWarpingLibrary.GetCurveValueFromAnimation // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd639678
};

