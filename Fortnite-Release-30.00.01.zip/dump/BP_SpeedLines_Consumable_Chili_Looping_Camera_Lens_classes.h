// BlueprintGeneratedClass BP_SpeedLines_Consumable_Chili_Looping_Camera_Lens.BP_SpeedLines_Consumable_Chili_Looping_Camera_Lens_C
// Size: 0x380 (Inherited: 0x380)
struct ABP_SpeedLines_Consumable_Chili_Looping_Camera_Lens_C : AEmitterCameraLensEffectBase {
};

