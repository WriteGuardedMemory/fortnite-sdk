// BlueprintGeneratedClass Athena_PlayerCameraHoisted.Athena_PlayerCameraHoisted_C
// Size: 0x1cd0 (Inherited: 0x1cd0)
struct UAthena_PlayerCameraHoisted_C : UAthena_PlayerCameraModeBase_C {
};

