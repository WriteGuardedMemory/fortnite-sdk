// ScriptStruct AudioMetadata.AudioMetadataModulationSettings
// Size: 0x10 (Inherited: 0x00)
struct FAudioMetadataModulationSettings {
	struct USoundControlBus* ControlBusLicensedAudioMuteAll; // 0x00(0x08)
	struct USoundControlBus* ControlBusLicensedAudioMuteOthers; // 0x08(0x08)
};

