// WidgetBlueprintGeneratedClass CampaignPurchaseScreen.CampaignPurchaseScreen_C
// Size: 0x4d0 (Inherited: 0x490)
struct UCampaignPurchaseScreen_C : UFortCampaignPurchaseScreen {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x490(0x08)
	struct UWidgetAnimation* SwitchTextures; // 0x498(0x08)
	struct UMaterialInstanceDynamic* MID-Keyart; // 0x4a0(0x08)
	struct FTimerHandle CycleTimer; // 0x4a8(0x08)
	struct TArray<struct UTexture*> TextureCycle; // 0x4b0(0x10)
	int32_t TextureCycleIndex; // 0x4c0(0x04)
	char pad_4C4[0x4]; // 0x4c4(0x04)
	struct USoundBase* WhooshSound; // 0x4c8(0x08)

	void IsMinorShutdownWarningEnabled(bool& Enabled); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.IsMinorShutdownWarningEnabled // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
	void InitializeRedeemButton(); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.InitializeRedeemButton // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	bool IsBusyMatchmaking(); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.IsBusyMatchmaking // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x18e3f1c
	void Update(); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.Update // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void AdvanceTextureCycle(); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.AdvanceTextureCycle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void InitializeTextureCycle(); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.InitializeTextureCycle // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ToggleTimer(bool Enabled); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.ToggleTimer // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__ButtonBack_K2Node_ComponentBoundEvent_128_CommonButtonClicked__DelegateSignature(struct UCommonButtonLegacy* Button); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.BndEvt__ButtonBack_K2Node_ComponentBoundEvent_128_CommonButtonClicked__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void Construct(); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnActivated(); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnImageCycleTimeElapsed(); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.OnImageCycleTimeElapsed // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnStoreScreenCreated(struct UFortMtxStoreRootBase_Legacy* StoreScreen); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.OnStoreScreenCreated // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_CampaignPurchaseScreen(int32_t EntryPoint); // Function CampaignPurchaseScreen.CampaignPurchaseScreen_C.ExecuteUbergraph_CampaignPurchaseScreen // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

