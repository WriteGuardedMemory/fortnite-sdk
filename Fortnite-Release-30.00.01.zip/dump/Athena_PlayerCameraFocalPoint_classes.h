// BlueprintGeneratedClass Athena_PlayerCameraFocalPoint.Athena_PlayerCameraFocalPoint_C
// Size: 0x1ce0 (Inherited: 0x1ce0)
struct UAthena_PlayerCameraFocalPoint_C : UFortCameraMode_FocalPoint {
};

