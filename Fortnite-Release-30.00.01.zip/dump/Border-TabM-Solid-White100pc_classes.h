// BlueprintGeneratedClass Border-TabM-Solid-White100pc.Border-TabM-Solid-White100pc_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-TabM-Solid-White100pc_C : UBorder-TabM-Solid_C {
};

