// BlueprintGeneratedClass AnimNotify_FootStep.AnimNotify_FootStep_C
// Size: 0x80 (Inherited: 0x80)
struct UAnimNotify_FootStep_C : UFortAnimNotify_Footstep {

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, struct FAnimNotifyEventReference& EventReference); // Function AnimNotify_FootStep.AnimNotify_FootStep_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x18e3f1c
};

