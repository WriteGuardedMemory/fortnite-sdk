// Class ClamberingCodeRuntime.FortMovementMode_ClamberingRuntimeData
// Size: 0x130 (Inherited: 0x100)
struct UFortMovementMode_ClamberingRuntimeData : UFortMovementMode_TraversalBaseRuntimeData {
	char pad_100[0x30]; // 0x100(0x30)

	struct FVector GetSyncPosition(); // Function ClamberingCodeRuntime.FortMovementMode_ClamberingRuntimeData.GetSyncPosition // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x358c6e4
};

// Class ClamberingCodeRuntime.FortMovementMode_ExtClambering
// Size: 0x1d0 (Inherited: 0x168)
struct UFortMovementMode_ExtClambering : UFortMovementMode_ExtLogicTraversalBase {
	struct UFortCameraMode* LedgeLaunchCameraMode; // 0x168(0x08)
	struct UFortCameraMode* WindowClamberCameraMode; // 0x170(0x08)
	struct FGameplayTagContainer ClamberingTag; // 0x178(0x20)
	struct FGameplayTag ClamberingStartedTag; // 0x198(0x04)
	char pad_19C[0x4]; // 0x19c(0x04)
	struct FGameplayTagContainer ClamberingFinishedTag; // 0x1a0(0x20)
	struct UCameraShakeBase* CameraShake; // 0x1c0(0x08)
	float LedgeLaunchSyncPointInterpSpeed; // 0x1c8(0x04)
	float LedgeLaunchPlayerCollideBounceSpeed; // 0x1cc(0x04)

	void BP_GetAnimationMontageInformation(struct FClamberMontageInput& Context, struct UAnimMontage*& AnimMontage, struct FName& StartSectionName, struct FName& MontageMiddleSectionName); // Function ClamberingCodeRuntime.FortMovementMode_ExtClambering.BP_GetAnimationMontageInformation // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
};

// Class ClamberingCodeRuntime.InstancedLedgeActor
// Size: 0x2f0 (Inherited: 0x298)
struct AInstancedLedgeActor : AFortClientOnlyActor {
	struct UInstancedStaticMeshComponent* InstancedStaticMeshComponent; // 0x298(0x08)
	char pad_2A0[0x50]; // 0x2a0(0x50)

	void BP_OnRemoveInstance(struct FTransform& LedgeTransform, int32_t InstanceIndex); // Function ClamberingCodeRuntime.InstancedLedgeActor.BP_OnRemoveInstance // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnAddInstance(struct FTransform& LedgeTransform, int32_t InstanceIndex); // Function ClamberingCodeRuntime.InstancedLedgeActor.BP_OnAddInstance // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x18e3f1c
};

// Class ClamberingCodeRuntime.LedgeLaunchWorldSubsystem
// Size: 0x150 (Inherited: 0x30)
struct ULedgeLaunchWorldSubsystem : UBuildingWallSubsystem {
	struct TSoftObjectPtr<UPBWLedgeConfigurationData> ConfigurationData; // 0x30(0x20)
	struct TSoftClassPtr<UObject> InstancedLedgeActorClass; // 0x50(0x20)
	struct UPBWLedgeConfigurationData* CachedConfigurationData; // 0x70(0x08)
	struct AInstancedLedgeActor* InstancedLedgeActor; // 0x78(0x08)
	struct TMap<struct UObject*, struct FLedgeLaunchConfigEntry> CachedLedgeLaunchMap; // 0x80(0x50)
	char pad_D0[0x80]; // 0xd0(0x80)

	void OnWallDied(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function ClamberingCodeRuntime.LedgeLaunchWorldSubsystem.OnWallDied // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x24170dc
};

// Class ClamberingCodeRuntime.PBWLedgeConfigurationData
// Size: 0x1c0 (Inherited: 0x30)
struct UPBWLedgeConfigurationData : UDataAsset {
	struct TMap<enum class EPlayerBuiltWallType, struct TSoftClassPtr<UObject>> MetalWalls; // 0x30(0x50)
	struct TMap<enum class EPlayerBuiltWallType, struct TSoftClassPtr<UObject>> StoneWalls; // 0x80(0x50)
	struct TMap<enum class EPlayerBuiltWallType, struct TSoftClassPtr<UObject>> WoodWalls; // 0xd0(0x50)
	struct TMap<enum class EPlayerBuiltWallType, struct FLedgeLaunchConfigEntry> Transforms; // 0x120(0x50)
	struct TMap<enum class EPlayerBuiltWallMaterialType, struct FLedgeLaunchTransformConfigEntry> PerMaterialTransforms; // 0x170(0x50)
};

// Class ClamberingCodeRuntime.ClamberingAnalytics
// Size: 0x28 (Inherited: 0x28)
struct UClamberingAnalytics : UObject {
};

// Class ClamberingCodeRuntime.ClamberingComponent
// Size: 0xea0 (Inherited: 0xa8)
struct UClamberingComponent : UFortPawnOverrideComponent {
	char pad_A8[0x8]; // 0xa8(0x08)
	enum class EClamberingState LocalClamberingState; // 0xb0(0x01)
	enum class EClamberingState ReplicatedClamberingState; // 0xb1(0x01)
	char pad_B2[0x6]; // 0xb2(0x06)
	struct FClamberingTargetingData LockedTargetingData; // 0xb8(0xe0)
	struct FReplicatedClamberingTargetingData_SimClient ReplicatedTargetingData; // 0x198(0x38)
	char pad_1D0[0x8]; // 0x1d0(0x08)
	struct FScalableFloat ClamberingEnabled; // 0x1d8(0x28)
	struct FScalableFloat ClamberIndicatorEnabled; // 0x200(0x28)
	char pad_228[0x8]; // 0x228(0x08)
	struct FScalableFloat ClamberStartMaxFallingDamageFraction; // 0x230(0x28)
	bool bPerformTargetingWhileWalking; // 0x258(0x01)
	bool bPerformTargetingWhileSwimming; // 0x259(0x01)
	char pad_25A[0x6]; // 0x25a(0x06)
	struct FScalableFloat ServerFailDelay; // 0x260(0x28)
	struct FScalableFloat ServerValidatePlayerMaxDistance; // 0x288(0x28)
	struct FClamberingInputConfig InputConfig; // 0x2b0(0x350)
	struct FClamberingTargetingConfig_Ledge TargetingConfig_Ledge; // 0x600(0x4b0)
	struct FClamberingInputConfig_CachedValues InputConfigCachedValues; // 0xab0(0x5c)
	struct FClamberingTargetingConfig_Ledge_CachedContextualValues TargetingConfig_Ledge_CachedContextualValues; // 0xb0c(0x7c)
	struct FClamberingMovementConfig_Ledge MoveConfig_Ledge; // 0xb88(0x50)
	struct FScalableFloat ClamberSyncTargetLedgeOffset; // 0xbd8(0x28)
	struct FScalableFloat ClamberingMaxAnalyticsEvents; // 0xc00(0x28)
	struct FScalableFloat SynchedActionFailDelay; // 0xc28(0x28)
	struct UFortMovementMode_ExtClambering* MovementModeExtension; // 0xc50(0x08)
	struct FGameplayTag SynchedActionMMETag; // 0xc58(0x04)
	struct FName LedgeLaunchSyncPointName; // 0xc5c(0x04)
	double LastTeleportTime; // 0xc60(0x08)
	bool bTutorialModeEnabled; // 0xc68(0x01)
	char pad_C69[0x7]; // 0xc69(0x07)
	struct FClamberingTargetingData LocalTargetingData; // 0xc70(0xe0)
	struct FClamberingTargetingData ParallelTargetingData; // 0xd50(0xe0)
	float QueuedInputTimer; // 0xe30(0x04)
	float InputEnabledTimer; // 0xe34(0x04)
	bool bJumpInputPressed; // 0xe38(0x01)
	char pad_E39[0x3]; // 0xe39(0x03)
	float JumpHeldInAirTime; // 0xe3c(0x04)
	char pad_E40[0x50]; // 0xe40(0x50)
	struct FGameplayTag Tag_DisableClambering; // 0xe90(0x04)
	char pad_E94[0xc]; // 0xe94(0x0c)

	void UnregisterMutatorUpdatedDelegate(); // Function ClamberingCodeRuntime.ClamberingComponent.UnregisterMutatorUpdatedDelegate // (Final|Native|Protected) // @ game+0xb7a58c0
	bool ShouldShowClamberIndicator(); // Function ClamberingCodeRuntime.ClamberingComponent.ShouldShowClamberIndicator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7a589c
	void SetTutorialModeEnabled(bool bEnabled); // Function ClamberingCodeRuntime.ClamberingComponent.SetTutorialModeEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0xb7a57d8
	void ServerStartClambering(struct FReplicatedClamberingTargetingData InReplicatedTargetingData, double ClientLastTeleportTime); // Function ClamberingCodeRuntime.ClamberingComponent.ServerStartClambering // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xb7a561c
	void RegisterMutatorUpdatedDelegate(struct APawn* AffectedPawn); // Function ClamberingCodeRuntime.ClamberingComponent.RegisterMutatorUpdatedDelegate // (Final|Native|Protected) // @ game+0xb7a540c
	void OnRep_ReplicatedTargetingData(); // Function ClamberingCodeRuntime.ClamberingComponent.OnRep_ReplicatedTargetingData // (Final|Native|Protected) // @ game+0xb7a529c
	void OnPlayerStatePawnSet(struct APlayerState* Player, struct APawn* NewPawn, struct APawn* OldPawn); // Function ClamberingCodeRuntime.ClamberingComponent.OnPlayerStatePawnSet // (Final|Native|Protected) // @ game+0x3450044
	void OnMutatorUpdated(); // Function ClamberingCodeRuntime.ClamberingComponent.OnMutatorUpdated // (Final|Native|Protected) // @ game+0x3a3d72c
	void NetMulticast_ClamberingLedgeFailed(enum class EClamberingFailedReason FailedReason, enum class EClamberingState FailedState); // Function ClamberingCodeRuntime.ClamberingComponent.NetMulticast_ClamberingLedgeFailed // (Net|NetReliableNative|Event|NetMulticast|Protected) // @ game+0xb7a5158
	bool IsTutorialModeEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.IsTutorialModeEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7a5134
	bool IsClamberingEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.IsClamberingEnabled // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7a5110
	bool IsAutoClamberingEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.IsAutoClamberingEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7a50ec
	void HandleTargetingDataValid(struct FClamberingTargetingData& TargetingData); // Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataValid // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void HandleTargetingDataInvalid(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetingDataInvalid // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void HandleTargetActorHealthChanged(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorHealthChanged // (Final|Native|Protected) // @ game+0xb7a50d8
	void HandleTargetActorDestroyed(struct AActor* Actor); // Function ClamberingCodeRuntime.ClamberingComponent.HandleTargetActorDestroyed // (Final|Native|Protected) // @ game+0xb7a5018
	void HandleOwnerTeleported(struct AFortPawn* TeleportedOwner); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerTeleported // (Final|Native|Protected|BlueprintCallable) // @ game+0x35e0500
	void HandleOwnerMovementModeChanged(struct ACharacter* Character, enum class EMovementMode PreviousMovementMode, char PreviousCustomMode); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerMovementModeChanged // (Final|Native|Protected) // @ game+0x1911e20
	void HandleOwnerJumpInput(bool bPressed); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerJumpInput // (Final|Native|Protected) // @ game+0xb7a4f54
	void HandleOwnerDied(struct AFortPawn* DeadPawn); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDied // (Final|Native|Protected) // @ game+0xb7a4e94
	void HandleOwnerDBNO(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerDBNO // (Final|Native|Protected) // @ game+0x333c828
	void HandleOwnerASCInvalidated(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInvalidated // (Final|Native|Protected) // @ game+0x333c864
	void HandleOwnerASCInitialized(struct UFortAbilitySystemComponent* AbilitySystemComponent, struct AFortPlayerPawn* AffectedPawn); // Function ClamberingCodeRuntime.ClamberingComponent.HandleOwnerASCInitialized // (Final|Native|Protected) // @ game+0x3388284
	void HandleClamberingTargetOutOfActivationRange(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetOutOfActivationRange // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void HandleClamberingTargetInActivationRange(); // Function ClamberingCodeRuntime.ClamberingComponent.HandleClamberingTargetInActivationRange // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void DrawDebugHUD(struct AHUD* HUD, struct UCanvas* Canvas); // Function ClamberingCodeRuntime.ClamberingComponent.DrawDebugHUD // (Final|Native|Protected) // @ game+0x6f47d8c
	void BP_TutorialModeEnabled(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeEnabled // (Event|Protected|BlueprintEvent|Const) // @ game+0x18e3f1c
	void BP_TutorialModeDisabled(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_TutorialModeDisabled // (Event|Protected|BlueprintEvent|Const) // @ game+0x18e3f1c
	void BP_OnMMEStarted(); // Function ClamberingCodeRuntime.ClamberingComponent.BP_OnMMEStarted // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_IsValidTargetActor(struct AActor* TargetActor, bool& bIsValidTargetActor); // Function ClamberingCodeRuntime.ClamberingComponent.BP_IsValidTargetActor // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x18e3f1c
	void BP_HandleSynchedActionStarted(struct FSynchedActionInfo& SynchedActionInfo); // Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleSynchedActionStarted // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void BP_HandleClamberingStateChanged(enum class EClamberingState OldClamberingState, enum class EClamberingState NewClamberingState); // Function ClamberingCodeRuntime.ClamberingComponent.BP_HandleClamberingStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_CanStartTargeting(bool& bCanStartTargeting); // Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartTargeting // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x18e3f1c
	void BP_CanStartClambering(bool& bCanStartClambering); // Function ClamberingCodeRuntime.ClamberingComponent.BP_CanStartClambering // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x18e3f1c
};

// Class ClamberingCodeRuntime.ClamberingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UClamberingLibrary : UBlueprintFunctionLibrary {

	bool PerformClamberingTargeting(struct ACharacter* Character, struct FClamberingTargetingData& OutTargetingData); // Function ClamberingCodeRuntime.ClamberingLibrary.PerformClamberingTargeting // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xb7a52d0
};

// Class ClamberingCodeRuntime.FortAthenaMutator_LedgeLaunch
// Size: 0x500 (Inherited: 0x338)
struct AFortAthenaMutator_LedgeLaunch : AFortAthenaMutator {
	char pad_338[0x1a8]; // 0x338(0x1a8)
	struct TArray<struct TWeakObjectPtr<struct ABuildingWall>> CurrentWalls; // 0x4e0(0x10)
	bool bShouldSpawnLedge; // 0x4f0(0x01)
	char pad_4F1[0xf]; // 0x4f1(0x0f)

	void OnRep_bShouldSpawnLedge(); // Function ClamberingCodeRuntime.FortAthenaMutator_LedgeLaunch.OnRep_bShouldSpawnLedge // (Final|Native|Private) // @ game+0xb7a52b0
};

