// WidgetBlueprintGeneratedClass AthenaRichColorVariantPicker.AthenaRichColorVariantPicker_C
// Size: 0x400 (Inherited: 0x400)
struct UAthenaRichColorVariantPicker_C : UFortVariantRichColorPicker {
};

