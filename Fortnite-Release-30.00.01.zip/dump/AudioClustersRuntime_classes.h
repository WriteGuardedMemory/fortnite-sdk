// Class AudioClustersRuntime.AudioClusterConfig
// Size: 0x30 (Inherited: 0x28)
struct UAudioClusterConfig : UObject {
	struct UAudioClusterBehavior* Behavior; // 0x28(0x08)
};

// Class AudioClustersRuntime.AudioClusterConfigMap
// Size: 0x78 (Inherited: 0x28)
struct UAudioClusterConfigMap : UObject {
	struct TMap<struct FGameplayTag, struct UAudioClusterConfig*> TagConfigMap; // 0x28(0x50)
};

// Class AudioClustersRuntime.AudioClusterBehavior
// Size: 0x30 (Inherited: 0x28)
struct UAudioClusterBehavior : UObject {
	char pad_28[0x8]; // 0x28(0x08)

	void OnStop(); // Function AudioClustersRuntime.AudioClusterBehavior.OnStop // (Native|Event|Protected|BlueprintEvent) // @ game+0x68953c4
	void OnStart(); // Function AudioClustersRuntime.AudioClusterBehavior.OnStart // (Native|Event|Protected|BlueprintEvent) // @ game+0x2220548
	void OnSizeUpdated(int32_t Size); // Function AudioClustersRuntime.AudioClusterBehavior.OnSizeUpdated // (Native|Event|Protected|BlueprintEvent) // @ game+0x2e57df0
	void OnPositionUpdated(struct FVector& Position); // Function AudioClustersRuntime.AudioClusterBehavior.OnPositionUpdated // (Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0xc87638c
	void OnActorRemoved(struct AActor* Actor); // Function AudioClustersRuntime.AudioClusterBehavior.OnActorRemoved // (Native|Event|Protected|BlueprintEvent) // @ game+0x767a660
	void OnActorAdded(struct AActor* Actor); // Function AudioClustersRuntime.AudioClusterBehavior.OnActorAdded // (Native|Event|Protected|BlueprintEvent) // @ game+0x8152ad8
};

// Class AudioClustersRuntime.AudioClustersSubsystem
// Size: 0x38 (Inherited: 0x30)
struct UAudioClustersSubsystem : UWorldSubsystem {
	char pad_30[0x8]; // 0x30(0x08)

	void UpdateClusters(float DeltaTimeSeconds); // Function AudioClustersRuntime.AudioClustersSubsystem.UpdateClusters // (Final|Native|Public|BlueprintCallable) // @ game+0xc8769f8
	bool Unregister(struct FAudioClusterActorInfo& ActorInfo); // Function AudioClustersRuntime.AudioClustersSubsystem.Unregister // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc87695c
	bool SetParam(struct FGameplayTag& tag, double Value); // Function AudioClustersRuntime.AudioClustersSubsystem.SetParam // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc876800
	void SetListenerPosition(struct FVector& InListenerPosition); // Function AudioClustersRuntime.AudioClustersSubsystem.SetListenerPosition // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xc87673c
	bool RemoveConfigMap(struct UAudioClusterConfigMap* Map); // Function AudioClustersRuntime.AudioClustersSubsystem.RemoveConfigMap // (Final|Native|Public|BlueprintCallable) // @ game+0xc8765a8
	bool RegisterOneShot(struct FAudioClusterOneShotInfo& OneShotInfo); // Function AudioClustersRuntime.AudioClustersSubsystem.RegisterOneShot // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc8764f0
	bool Register(struct FAudioClusterActorInfo& ActorInfo); // Function AudioClustersRuntime.AudioClustersSubsystem.Register // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc876454
	bool AddConfigMap(struct UAudioClusterConfigMap* Map); // Function AudioClustersRuntime.AudioClustersSubsystem.AddConfigMap // (Final|Native|Public|BlueprintCallable) // @ game+0xc8762bc
};

