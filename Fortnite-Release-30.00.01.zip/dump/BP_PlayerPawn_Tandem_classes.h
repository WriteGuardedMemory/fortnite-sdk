// BlueprintGeneratedClass BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C
// Size: 0x6ce0 (Inherited: 0x6c58)
struct ABP_PlayerPawn_Tandem_C : ABP_PlayerPawn_NonParticipant_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6c58(0x08)
	struct UFortWidgetComponent* NPCStatusWidget; // 0x6c60(0x08)
	bool IsConverted; // 0x6c68(0x01)
	char Leader Team; // 0x6c69(0x01)
	char pad_6C6A[0x6]; // 0x6c6a(0x06)
	struct FStruct_NPC_HealthInfo HealthInfo; // 0x6c70(0x20)
	bool NPCStatusWidgetHealthBarDisabled; // 0x6c90(0x01)
	char pad_6C91[0x7]; // 0x6c91(0x07)
	struct FScalableFloat ShowHealth; // 0x6c98(0x28)
	double NPCHealthBarHideTimeAfterDeath; // 0x6cc0(0x08)
	double NPCMaxDistanceFromDamageINstigatorToDrawHealthBar; // 0x6cc8(0x08)
	bool IsHealthCheatEnabled; // 0x6cd0(0x01)
	bool IsTandemHealthEnabled; // 0x6cd1(0x01)
	char pad_6CD2[0x6]; // 0x6cd2(0x06)
	struct FTimerHandle UpdateOffsetTimerHandle; // 0x6cd8(0x08)

	void UpdatePawnHealthHUD(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.UpdatePawnHealthHUD // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnRep_HealthInfo(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.OnRep_HealthInfo // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HandlePawnUnconverted(struct AFortPawn* UnconvertedPawn); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.HandlePawnUnconverted // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HandlePawnConverted(struct AFortPawn* InstigatorPawn, struct AFortPawn* ConvertedPawn); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.HandlePawnConverted // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UpdateConvertIndicator(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.UpdateConvertIndicator // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void StartHealthBar(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.StartHealthBar // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void StartUpdatingHealthWidget(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.StartUpdatingHealthWidget // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void StopUpdatingHealthWidget(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.StopUpdatingHealthWidget // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void PawnHealthChanged(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.PawnHealthChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnDeathPlayEffects(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AFortPawn* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.OnDeathPlayEffects // (BlueprintCosmetic|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void NPCSetupHealthBarOnDeath(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.NPCSetupHealthBarOnDeath // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void WidgetVisibilityChanged(bool bVisible); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.WidgetVisibilityChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void NPCTandemDisableHealthBar(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.NPCTandemDisableHealthBar // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void NPCTandemEnableHealthBars(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.NPCTandemEnableHealthBars // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void EnableHiredTandemHealthBar(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.EnableHiredTandemHealthBar // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void EnableTandemHealthBar(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.EnableTandemHealthBar // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UpdateWidgetOffset(); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.UpdateWidgetOffset // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_BP_PlayerPawn_Tandem(int32_t EntryPoint); // Function BP_PlayerPawn_Tandem.BP_PlayerPawn_Tandem_C.ExecuteUbergraph_BP_PlayerPawn_Tandem // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

