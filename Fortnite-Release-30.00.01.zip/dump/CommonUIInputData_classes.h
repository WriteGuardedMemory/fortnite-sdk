// BlueprintGeneratedClass CommonUIInputData.CommonUIInputData_C
// Size: 0x78 (Inherited: 0x78)
struct UCommonUIInputData_C : UCommonUIInputData {
};

