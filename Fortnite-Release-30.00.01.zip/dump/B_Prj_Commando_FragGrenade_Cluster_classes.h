// BlueprintGeneratedClass B_Prj_Commando_FragGrenade_Cluster.B_Prj_Commando_FragGrenade_Cluster_C
// Size: 0xb10 (Inherited: 0xab8)
struct AB_Prj_Commando_FragGrenade_Cluster_C : AFortProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xab8(0x08)
	struct UParticleSystemComponent* ParticleSystem1; // 0xac0(0x08)
	struct UAudioComponent* Audio1; // 0xac8(0x08)
	struct USoundBase* BounceSound; // 0xad0(0x08)
	struct UParticleSystem* P_Explosion; // 0xad8(0x08)
	struct USoundBase* ExplosionSound; // 0xae0(0x08)
	struct FVector ExplosionLocation; // 0xae8(0x18)
	double MinExplosionDelay; // 0xb00(0x08)
	double MaxExplosionDelay; // 0xb08(0x08)

	void OnStop(struct FHitResult& Hit); // Function B_Prj_Commando_FragGrenade_Cluster.B_Prj_Commando_FragGrenade_Cluster_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function B_Prj_Commando_FragGrenade_Cluster.B_Prj_Commando_FragGrenade_Cluster_C.ReceiveAnyDamage // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function B_Prj_Commando_FragGrenade_Cluster.B_Prj_Commando_FragGrenade_Cluster_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnExploded(struct TArray<struct AActor*>& HitActors, struct TArray<struct FHitResult>& HitResults); // Function B_Prj_Commando_FragGrenade_Cluster.B_Prj_Commando_FragGrenade_Cluster_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_B_Prj_Commando_FragGrenade_Cluster(int32_t EntryPoint); // Function B_Prj_Commando_FragGrenade_Cluster.B_Prj_Commando_FragGrenade_Cluster_C.ExecuteUbergraph_B_Prj_Commando_FragGrenade_Cluster // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

