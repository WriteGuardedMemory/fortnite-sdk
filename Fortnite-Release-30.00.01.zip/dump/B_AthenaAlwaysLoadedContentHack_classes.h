// BlueprintGeneratedClass B_AthenaAlwaysLoadedContentHack.B_AthenaAlwaysLoadedContentHack_C
// Size: 0x2b8 (Inherited: 0x290)
struct AB_AthenaAlwaysLoadedContentHack_C : AActor {
	struct USceneComponent* DefaultSceneRoot; // 0x290(0x08)
	struct TArray<struct UObject*> HardObjectList; // 0x298(0x10)
	struct TArray<struct UObject*> HardClassList; // 0x2a8(0x10)
};

