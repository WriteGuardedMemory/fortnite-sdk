// Class ChaosCaching.ChaosCacheCollection
// Size: 0x38 (Inherited: 0x28)
struct UChaosCacheCollection : UObject {
	struct TArray<struct UChaosCache*> Caches; // 0x28(0x10)
};

// Class ChaosCaching.ChaosCacheManager
// Size: 0x340 (Inherited: 0x290)
struct AChaosCacheManager : AActor {
	struct UChaosCacheCollection* CacheCollection; // 0x290(0x08)
	enum class ECacheMode CacheMode; // 0x298(0x01)
	enum class EStartMode StartMode; // 0x299(0x01)
	char pad_29A[0x2]; // 0x29a(0x02)
	float StartTime; // 0x29c(0x04)
	char pad_2A0[0x8]; // 0x2a0(0x08)
	struct TArray<struct FObservedComponent> ObservedComponents; // 0x2a8(0x10)
	char pad_2B8[0x88]; // 0x2b8(0x88)

	void TriggerComponentByCache(struct FName InCacheName); // Function ChaosCaching.ChaosCacheManager.TriggerComponentByCache // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0xc771ca0
	void TriggerComponent(struct UPrimitiveComponent* InComponent); // Function ChaosCaching.ChaosCacheManager.TriggerComponent // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0xc771be0
	void TriggerAll(); // Function ChaosCaching.ChaosCacheManager.TriggerAll // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0xc771b58
	void SetStartTime(float InStartTime); // Function ChaosCaching.ChaosCacheManager.SetStartTime // (Final|RequiredAPI|Native|Public) // @ game+0xc771a94
	void SetCurrentTime(float CurrentTime); // Function ChaosCaching.ChaosCacheManager.SetCurrentTime // (Final|Native|Public|BlueprintCallable) // @ game+0xc771a94
	void SetCacheCollection(struct UChaosCacheCollection* InCacheCollection); // Function ChaosCaching.ChaosCacheManager.SetCacheCollection // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0xc7719d4
	void ResetSingleTransform(int32_t InIndex); // Function ChaosCaching.ChaosCacheManager.ResetSingleTransform // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xc7718bc
	void ResetAllComponentTransforms(); // Function ChaosCaching.ChaosCacheManager.ResetAllComponentTransforms // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xc7718a8
	void EnablePlaybackByCache(struct FName InCacheName, bool bEnable); // Function ChaosCaching.ChaosCacheManager.EnablePlaybackByCache // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0xc771734
	void EnablePlayback(int32_t Index, bool bEnable); // Function ChaosCaching.ChaosCacheManager.EnablePlayback // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0xc7715d8
};

// Class ChaosCaching.ChaosCachePlayer
// Size: 0x340 (Inherited: 0x340)
struct AChaosCachePlayer : AChaosCacheManager {
};

// Class ChaosCaching.ChaosCache
// Size: 0x360 (Inherited: 0x28)
struct UChaosCache : UObject {
	float RecordedDuration; // 0x28(0x04)
	uint32_t NumRecordedFrames; // 0x2c(0x04)
	struct TArray<int32_t> TrackToParticle; // 0x30(0x10)
	struct TArray<struct FPerParticleCacheData> ParticleTracks; // 0x40(0x10)
	struct TArray<int32_t> ChannelCurveToParticle; // 0x50(0x10)
	struct TMap<struct FName, struct FRichCurves> ChannelsTracks; // 0x60(0x50)
	struct TMap<struct FName, struct FCompressedRichCurves> CompressedChannelsTracks; // 0xb0(0x50)
	struct TMap<struct FName, struct FRichCurve> CurveData; // 0x100(0x50)
	struct TMap<struct FName, struct FParticleTransformTrack> NamedTransformTracks; // 0x150(0x50)
	bool bCompressChannels; // 0x1a0(0x01)
	char pad_1A1[0x3]; // 0x1a1(0x03)
	float ChannelsCompressionErrorThreshold; // 0x1a4(0x04)
	float ChannelsCompressionSampleRate; // 0x1a8(0x04)
	char pad_1AC[0x4]; // 0x1ac(0x04)
	struct TMap<struct FName, struct FCacheEventTrack> EventTracks; // 0x1b0(0x50)
	struct FCacheSpawnableTemplate Spawnable; // 0x200(0xd0)
	struct FGuid AdapterGuid; // 0x2d0(0x10)
	int32_t Version; // 0x2e0(0x04)
	char pad_2E4[0x7c]; // 0x2e4(0x7c)
};

// Class ChaosCaching.MovieSceneChaosCacheSection
// Size: 0x120 (Inherited: 0xf8)
struct UMovieSceneChaosCacheSection : UMovieSceneBaseCacheSection {
	struct FMovieSceneChaosCacheParams Params; // 0xf8(0x28)
};

// Class ChaosCaching.MovieSceneChaosCacheTrack
// Size: 0xb0 (Inherited: 0x98)
struct UMovieSceneChaosCacheTrack : UMovieSceneNameableTrack {
	char pad_98[0x8]; // 0x98(0x08)
	struct TArray<struct UMovieSceneSection*> AnimationSections; // 0xa0(0x10)
};

