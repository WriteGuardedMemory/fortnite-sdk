// BlueprintGeneratedClass BP_UI_PostProcessBlur.BP_UI_PostProcessBlur_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_UI_PostProcessBlur_C : USlatePostBufferBlur {
};

