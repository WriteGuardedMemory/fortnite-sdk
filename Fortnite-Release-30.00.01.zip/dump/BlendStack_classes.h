// Class BlendStack.BlendStackAnimNodeLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlendStackAnimNodeLibrary : UBlueprintFunctionLibrary {

	float GetCurrentBlendStackAnimAssetTime(struct FAnimNodeReference& Node); // Function BlendStack.BlendStackAnimNodeLibrary.GetCurrentBlendStackAnimAssetTime // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8166014
	struct UAnimationAsset* GetCurrentBlendStackAnimAsset(struct FAnimNodeReference& Node); // Function BlendStack.BlendStackAnimNodeLibrary.GetCurrentBlendStackAnimAsset // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8165f28
	void ForceBlendNextUpdate(struct FBlendStackAnimNodeReference& BlendStackNode); // Function BlendStack.BlendStackAnimNodeLibrary.ForceBlendNextUpdate // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8165e84
	void ConvertToBlendStackNodePure(struct FAnimNodeReference& Node, struct FBlendStackAnimNodeReference& BlendStackNode, bool& Result); // Function BlendStack.BlendStackAnimNodeLibrary.ConvertToBlendStackNodePure // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8165cf4
	struct FBlendStackAnimNodeReference ConvertToBlendStackNode(struct FAnimNodeReference& Node, enum class EAnimNodeReferenceConversionResult& Result); // Function BlendStack.BlendStackAnimNodeLibrary.ConvertToBlendStackNode // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8165bc8
	void BlendTo(struct FAnimUpdateContext& Context, struct FBlendStackAnimNodeReference& BlendStackNode, struct UAnimationAsset* AnimationAsset, float AnimationTime, bool bLoop, bool bMirrored, float BlendTime, struct FVector BlendParameters, float WantedPlayRate, float ActivationDelay); // Function BlendStack.BlendStackAnimNodeLibrary.BlendTo // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x8165248
};

// Class BlendStack.BlendStackInputAnimNodeLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlendStackInputAnimNodeLibrary : UBlueprintFunctionLibrary {

	void GetProperties(struct FBlendStackInputAnimNodeReference& BlendStackInputNode, struct UAnimationAsset*& AnimationAsset, float& AccumulatedTime); // Function BlendStack.BlendStackInputAnimNodeLibrary.GetProperties // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x81660e0
	void ConvertToBlendStackInputNodePure(struct FAnimNodeReference& Node, struct FBlendStackInputAnimNodeReference& BlendStackInputNode, bool& Result); // Function BlendStack.BlendStackInputAnimNodeLibrary.ConvertToBlendStackInputNodePure // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8165a38
	struct FBlendStackInputAnimNodeReference ConvertToBlendStackInputNode(struct FAnimNodeReference& Node, enum class EAnimNodeReferenceConversionResult& Result); // Function BlendStack.BlendStackInputAnimNodeLibrary.ConvertToBlendStackInputNode // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x816590c
};

