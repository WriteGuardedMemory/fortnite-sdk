// BlueprintGeneratedClass ButtonStyle_Feature_M_Yellow.ButtonStyle_Feature_M_Yellow_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_Feature_M_Yellow_C : UCommonButtonStyle {
};

