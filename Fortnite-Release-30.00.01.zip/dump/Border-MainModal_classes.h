// BlueprintGeneratedClass Border-MainModal.Border-MainModal_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-MainModal_C : UCommonBorderStyle {
};

