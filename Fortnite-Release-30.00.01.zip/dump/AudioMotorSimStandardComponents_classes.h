// Class AudioMotorSimStandardComponents.BoostMotorSimComponent
// Size: 0x158 (Inherited: 0xb0)
struct UBoostMotorSimComponent : UAudioMotorSimComponent {
	float ThrottleScale; // 0xb0(0x04)
	float InterpExp; // 0xb4(0x04)
	float InterpTime; // 0xb8(0x04)
	bool ScaleThrottleWithBoostStrength; // 0xbc(0x01)
	bool bModifyPitch; // 0xbd(0x01)
	char pad_BE[0x2]; // 0xbe(0x02)
	float PitchModifierInterpSpeed; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct FRuntimeFloatCurve BoostToPitchCurve; // 0xc8(0x88)
	char pad_150[0x8]; // 0x150(0x08)
};

// Class AudioMotorSimStandardComponents.MotorPhysicsSimComponent
// Size: 0x118 (Inherited: 0xb0)
struct UMotorPhysicsSimComponent : UAudioMotorSimComponent {
	float Weight; // 0xb0(0x04)
	float EngineTorque; // 0xb4(0x04)
	float BrakingHorsePower; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
	struct TArray<float> GearRatios; // 0xc0(0x10)
	float ClutchedGearRatio; // 0xd0(0x04)
	bool bUseInfiniteGears; // 0xd4(0x01)
	bool bAlwaysDownshiftToZerothGear; // 0xd5(0x01)
	char pad_D6[0x2]; // 0xd6(0x02)
	float InfiniteGearRatio; // 0xd8(0x04)
	float UpShiftMaxRpm; // 0xdc(0x04)
	float DownShiftStartRpm; // 0xe0(0x04)
	float ClutchedForceModifier; // 0xe4(0x04)
	float ClutchedDecelScale; // 0xe8(0x04)
	float EngineGearRatio; // 0xec(0x04)
	float EngineFriction; // 0xf0(0x04)
	float GroundFriction; // 0xf4(0x04)
	float WindResistancePerVelocity; // 0xf8(0x04)
	float ThrottleInterpolationTime; // 0xfc(0x04)
	float RpmInterpSpeed; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	struct FMulticastInlineDelegate OnGearChangedEvent; // 0x108(0x10)
};

// Class AudioMotorSimStandardComponents.ResistanceMotorSimComponent
// Size: 0x140 (Inherited: 0xb0)
struct UResistanceMotorSimComponent : UAudioMotorSimComponent {
	float UpSpeedMaxFriction; // 0xb0(0x04)
	float MinSpeed; // 0xb4(0x04)
	struct FRuntimeFloatCurve SideSpeedFrictionCurve; // 0xb8(0x88)
};

// Class AudioMotorSimStandardComponents.ReverseMotorSimComponent
// Size: 0xb8 (Inherited: 0xb0)
struct UReverseMotorSimComponent : UAudioMotorSimComponent {
	float ReverseEngineResistanceModifier; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
};

// Class AudioMotorSimStandardComponents.RevLimiterMotorSimComponent
// Size: 0xf8 (Inherited: 0xb0)
struct URevLimiterMotorSimComponent : UAudioMotorSimComponent {
	float LimitTime; // 0xb0(0x04)
	float DecelScale; // 0xb4(0x04)
	float AirMaxThrottleTime; // 0xb8(0x04)
	float SideSpeedThreshold; // 0xbc(0x04)
	float LimiterMaxRpm; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct FMulticastInlineDelegate OnRevLimiterHit; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnRevLimiterStateChanged; // 0xd8(0x10)
	char pad_E8[0x10]; // 0xe8(0x10)
};

// Class AudioMotorSimStandardComponents.RpmCurveMotorSimComponent
// Size: 0xe8 (Inherited: 0xb0)
struct URpmCurveMotorSimComponent : UAudioMotorSimComponent {
	struct TArray<struct FMotorSimGearCurve> Gears; // 0xb0(0x10)
	float InterpSpeed; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct FMulticastInlineDelegate OnUpShift; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnDownShift; // 0xd8(0x10)
};

// Class AudioMotorSimStandardComponents.ThrottleStateMotorSimComponent
// Size: 0xf0 (Inherited: 0xb0)
struct UThrottleStateMotorSimComponent : UAudioMotorSimComponent {
	struct FMulticastInlineDelegate OnThrottleEngaged; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnThrottleReleased; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnEngineBlowoff; // 0xd0(0x10)
	float BlowoffMinThrottleTime; // 0xe0(0x04)
	char pad_E4[0xc]; // 0xe4(0x0c)
};

// Class AudioMotorSimStandardComponents.VelocitySyncMotorSimComponent
// Size: 0x158 (Inherited: 0xb0)
struct UVelocitySyncMotorSimComponent : UAudioMotorSimComponent {
	float NoThrottleTime; // 0xb0(0x04)
	float SpeedThreshold; // 0xb4(0x04)
	struct FRuntimeFloatCurve SpeedToRpmCurve; // 0xb8(0x88)
	float InterpSpeed; // 0x140(0x04)
	float InterpTime; // 0x144(0x04)
	float FirstGearThrottleThreshold; // 0x148(0x04)
	char pad_14C[0xc]; // 0x14c(0x0c)
};

