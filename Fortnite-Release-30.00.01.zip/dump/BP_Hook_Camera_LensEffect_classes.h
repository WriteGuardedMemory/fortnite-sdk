// BlueprintGeneratedClass BP_Hook_Camera_LensEffect.BP_Hook_Camera_LensEffect_C
// Size: 0x380 (Inherited: 0x380)
struct ABP_Hook_Camera_LensEffect_C : AEmitterCameraLensEffectBase {
};

