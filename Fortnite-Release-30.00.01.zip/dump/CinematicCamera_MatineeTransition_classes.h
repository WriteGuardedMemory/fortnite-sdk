// BlueprintGeneratedClass CinematicCamera_MatineeTransition.CinematicCamera_MatineeTransition_C
// Size: 0x70 (Inherited: 0x70)
struct UCinematicCamera_MatineeTransition_C : UFortCinematicCamera {
};

