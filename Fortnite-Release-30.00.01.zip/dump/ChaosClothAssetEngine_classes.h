// Class ChaosClothAssetEngine.ChaosClothComponent
// Size: 0x8f0 (Inherited: 0x8b0)
struct UChaosClothComponent : USkinnedMeshComponent {
	char bUseAttachedParentAsPoseComponent : 1; // 0x8a8(0x01)
	char bWaitForParallelTask : 1; // 0x8a8(0x01)
	char bEnableSimulation : 1; // 0x8a8(0x01)
	char bSuspendSimulation : 1; // 0x8a8(0x01)
	char bBindToLeaderComponent : 1; // 0x8a8(0x01)
	char bTeleport : 1; // 0x8a8(0x01)
	char bReset : 1; // 0x8a8(0x01)
	float BlendWeight; // 0x8ac(0x04)
	struct UChaosClothAssetInteractor* ClothOutfitInteractor; // 0x8b0(0x08)
	char pad_8BC_7 : 1; // 0x8bc(0x01)
	char pad_8BD[0x33]; // 0x8bd(0x33)

	void SuspendSimulation(); // Function ChaosClothAssetEngine.ChaosClothComponent.SuspendSimulation // (Final|Native|Public|BlueprintCallable) // @ game+0xd65a5a0
	void SetEnableSimulation(bool bEnable); // Function ChaosClothAssetEngine.ChaosClothComponent.SetEnableSimulation // (Final|Native|Public|BlueprintCallable) // @ game+0xd65713c
	void SetClothAsset(struct UChaosClothAsset* InClothAsset); // Function ChaosClothAssetEngine.ChaosClothComponent.SetClothAsset // (Final|Native|Public|BlueprintCallable) // @ game+0xd657074
	void ResumeSimulation(); // Function ChaosClothAssetEngine.ChaosClothComponent.ResumeSimulation // (Final|Native|Public|BlueprintCallable) // @ game+0xd65705c
	void ResetTeleportMode(); // Function ChaosClothAssetEngine.ChaosClothComponent.ResetTeleportMode // (Final|Native|Public|BlueprintCallable) // @ game+0xd657044
	void ResetConfigProperties(); // Function ChaosClothAssetEngine.ChaosClothComponent.ResetConfigProperties // (Final|Native|Public|BlueprintCallable) // @ game+0xd657030
	void RecreateClothSimulationProxy(); // Function ChaosClothAssetEngine.ChaosClothComponent.RecreateClothSimulationProxy // (Final|Native|Public|BlueprintCallable) // @ game+0xd65701c
	bool IsSimulationSuspended(); // Function ChaosClothAssetEngine.ChaosClothComponent.IsSimulationSuspended // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd656ff8
	bool IsSimulationEnabled(); // Function ChaosClothAssetEngine.ChaosClothComponent.IsSimulationEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd656fd4
	struct UChaosClothAssetInteractor* GetClothOutfitInteractor(); // Function ChaosClothAssetEngine.ChaosClothComponent.GetClothOutfitInteractor // (Final|Native|Public|BlueprintCallable) // @ game+0xd653df4
	struct UChaosClothAsset* GetClothAsset(); // Function ChaosClothAssetEngine.ChaosClothComponent.GetClothAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd653dd0
	void ForceNextUpdateTeleportAndReset(); // Function ChaosClothAssetEngine.ChaosClothComponent.ForceNextUpdateTeleportAndReset // (Final|Native|Public|BlueprintCallable) // @ game+0xd653cd0
	void ForceNextUpdateTeleport(); // Function ChaosClothAssetEngine.ChaosClothComponent.ForceNextUpdateTeleport // (Final|Native|Public|BlueprintCallable) // @ game+0xd653cb0
};

// Class ChaosClothAssetEngine.ChaosClothAsset
// Size: 0x350 (Inherited: 0xd0)
struct UChaosClothAsset : USkinnedAsset {
	struct UDataflow* DataflowAsset; // 0xd0(0x08)
	struct FString DataflowTerminal; // 0xd8(0x10)
	struct TArray<struct FSkeletalMaterial> Materials; // 0xe8(0x10)
	struct USkeleton* Skeleton; // 0xf8(0x08)
	struct UPhysicsAsset* PhysicsAsset; // 0x100(0x08)
	struct TArray<struct FSkeletalMeshLODInfo> LODInfo; // 0x108(0x10)
	struct FPerQualityLevelInt MinQualityLevelLOD; // 0x118(0x68)
	struct FPerPlatformBool DisableBelowMinLodStripping; // 0x180(0x01)
	char pad_181[0x3]; // 0x181(0x03)
	struct FPerPlatformInt MinLOD; // 0x184(0x04)
	char bSupportRayTracing : 1; // 0x188(0x01)
	char pad_188_1 : 7; // 0x188(0x01)
	char pad_189[0x3]; // 0x189(0x03)
	int32_t RayTracingMinLOD; // 0x18c(0x04)
	bool bSmoothTransition; // 0x190(0x01)
	bool bUseMultipleInfluences; // 0x191(0x01)
	char pad_192[0x2]; // 0x192(0x02)
	float SkinningKernelRadius; // 0x194(0x04)
	struct UPhysicsAsset* ShadowPhysicsAsset; // 0x198(0x08)
	struct FGuid AssetGuid; // 0x1a0(0x10)
	char pad_1B0[0x1a0]; // 0x1b0(0x1a0)

	struct UPhysicsAsset* GetShadowPhysicsAsset(); // Function ChaosClothAssetEngine.ChaosClothAsset.GetShadowPhysicsAsset // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e59384
};

// Class ChaosClothAssetEngine.ChaosClothAssetInteractor
// Size: 0x38 (Inherited: 0x28)
struct UChaosClothAssetInteractor : UObject {
	char pad_28[0x10]; // 0x28(0x10)

	void SetWeightedFloatValue(struct FString PropertyName, int32_t LODIndex, struct FVector2D Value); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.SetWeightedFloatValue // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xd659c8c
	void SetVectorValue(struct FString PropertyName, int32_t LODIndex, struct FVector Value); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.SetVectorValue // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xd659350
	void SetLowFloatValue(struct FString PropertyName, int32_t LODIndex, float Value); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.SetLowFloatValue // (Final|Native|Public|BlueprintCallable) // @ game+0xd658b2c
	void SetIntValue(struct FString PropertyName, int32_t LODIndex, int32_t Value); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.SetIntValue // (Final|Native|Public|BlueprintCallable) // @ game+0xd658254
	void SetHighFloatValue(struct FString PropertyName, int32_t LODIndex, float Value); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.SetHighFloatValue // (Final|Native|Public|BlueprintCallable) // @ game+0xd657a30
	void SetFloatValue(struct FString PropertyName, int32_t LODIndex, float Value); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.SetFloatValue // (Final|Native|Public|BlueprintCallable) // @ game+0xd65720c
	struct FVector2D GetWeightedFloatValue(struct FString PropertyName, int32_t LODIndex, struct FVector2D DefaultValue); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.GetWeightedFloatValue // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xd65679c
	struct FVector GetVectorValue(struct FString PropertyName, int32_t LODIndex, struct FVector DefaultValue); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.GetVectorValue // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xd655f50
	struct FString GetStringValue(struct FString PropertyName, int32_t LODIndex, struct FString DefaultValue); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.GetStringValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd6556ac
	float GetLowFloatValue(struct FString PropertyName, int32_t LODIndex, float DefaultValue); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.GetLowFloatValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd653e0c
	int32_t GetIntValue(struct FString PropertyName, int32_t LODIndex, int32_t DefaultValue); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.GetIntValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd654e4c
	float GetHighFloatValue(struct FString PropertyName, int32_t LODIndex, float DefaultValue); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.GetHighFloatValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd65462c
	float GetFloatValue(struct FString PropertyName, int32_t LODIndex, float DefaultValue); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.GetFloatValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd653e0c
	struct TArray<struct FString> GetAllProperties(int32_t LODIndex); // Function ChaosClothAssetEngine.ChaosClothAssetInteractor.GetAllProperties // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xd653ce8
};

