// BlueprintGeneratedClass BBE_RiderUse.BBE_RiderUse_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_RiderUse_C : UFortMobileActionButtonBehaviorExtension {
};

