// BlueprintGeneratedClass ButtonStyle-Skew_LDarkBlue.ButtonStyle-Skew_LDarkBlue_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Skew_LDarkBlue_C : UCommonButtonStyle {
};

