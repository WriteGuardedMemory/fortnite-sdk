// Class Constraints.ConstraintSubsystem
// Size: 0x50 (Inherited: 0x30)
struct UConstraintSubsystem : UEngineSubsystem {
	struct FMulticastSparseDelegate OnConstraintAddedToSystem_BP; // 0x30(0x01)
	struct FMulticastSparseDelegate OnConstraintRemovedFromSystem_BP; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
	struct TArray<struct FConstraintsInWorld> ConstraintsInWorld; // 0x38(0x10)
	char pad_48[0x8]; // 0x48(0x08)

	void OnConstraintRemovedFromSystem__DelegateSignature(struct UConstraintSubsystem* Mananger, struct UTickableConstraint* Constraint, bool bDoNotCompensate); // SparseDelegateFunction Constraints.ConstraintSubsystem.OnConstraintRemovedFromSystem__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x18e3f1c
	void OnConstraintAddedToSystem__DelegateSignature(struct UConstraintSubsystem* Mananger, struct UTickableConstraint* Constraint); // SparseDelegateFunction Constraints.ConstraintSubsystem.OnConstraintAddedToSystem__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x18e3f1c
};

// Class Constraints.ConstraintsActor
// Size: 0x298 (Inherited: 0x290)
struct AConstraintsActor : AActor {
	struct UConstraintsManager* ConstraintsManager; // 0x290(0x08)
};

// Class Constraints.TickableConstraint
// Size: 0x90 (Inherited: 0x28)
struct UTickableConstraint : UObject {
	bool Active; // 0x28(0x01)
	bool bValid; // 0x29(0x01)
	char pad_2A[0x66]; // 0x2a(0x66)
};

// Class Constraints.ConstraintsManager
// Size: 0x48 (Inherited: 0x28)
struct UConstraintsManager : UObject {
	struct FMulticastSparseDelegate OnConstraintAdded_BP; // 0x28(0x01)
	struct FMulticastSparseDelegate OnConstraintRemoved_BP; // 0x29(0x01)
	char pad_2A[0xe]; // 0x2a(0x0e)
	struct TArray<struct UTickableConstraint*> Constraints; // 0x38(0x10)

	void OnConstraintRemoved__DelegateSignature(struct UConstraintsManager* Mananger, struct UTickableConstraint* Constraint, bool bDoNotCompensate); // SparseDelegateFunction Constraints.ConstraintsManager.OnConstraintRemoved__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x18e3f1c
	void OnConstraintAdded__DelegateSignature(struct UConstraintsManager* Mananger, struct UTickableConstraint* Constraint); // SparseDelegateFunction Constraints.ConstraintsManager.OnConstraintAdded__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x18e3f1c
};

// Class Constraints.ConstraintsScriptingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UConstraintsScriptingLibrary : UBlueprintFunctionLibrary {

	bool RemoveThisConstraint(struct UWorld* InWorld, struct UTickableConstraint* InTickableConstraint); // Function Constraints.ConstraintsScriptingLibrary.RemoveThisConstraint // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x667df14
	bool RemoveConstraint(struct UWorld* InWorld, int32_t InIndex); // Function Constraints.ConstraintsScriptingLibrary.RemoveConstraint // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x667ddc8
	struct TArray<struct UTickableConstraint*> GetConstraintsArray(struct UWorld* InWorld); // Function Constraints.ConstraintsScriptingLibrary.GetConstraintsArray // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x667dcd0
	struct UTransformableHandle* CreateTransformableHandle(struct UWorld* InWorld, struct UObject* InObject, struct FName& InAttachmentName); // Function Constraints.ConstraintsScriptingLibrary.CreateTransformableHandle // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x667db4c
	struct UTransformableComponentHandle* CreateTransformableComponentHandle(struct UWorld* InWorld, struct USceneComponent* InSceneComponent, struct FName& InSocketName); // Function Constraints.ConstraintsScriptingLibrary.CreateTransformableComponentHandle // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x667d90c
	struct UTickableTransformConstraint* CreateFromType(struct UWorld* InWorld, enum class ETransformConstraintType InType); // Function Constraints.ConstraintsScriptingLibrary.CreateFromType // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x667d694
	bool AddConstraint(struct UWorld* InWorld, struct UTransformableHandle* InParentHandle, struct UTransformableHandle* InChildHandle, struct UTickableTransformConstraint* InConstraint, bool bMaintainOffset); // Function Constraints.ConstraintsScriptingLibrary.AddConstraint // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x667d1e8
};

// Class Constraints.TransformableHandle
// Size: 0x60 (Inherited: 0x28)
struct UTransformableHandle : UObject {
	char pad_28[0x4]; // 0x28(0x04)
	struct FMovieSceneObjectBindingID ConstraintBindingID; // 0x2c(0x18)
	char pad_44[0x1c]; // 0x44(0x1c)
};

// Class Constraints.TransformableComponentHandle
// Size: 0x70 (Inherited: 0x60)
struct UTransformableComponentHandle : UTransformableHandle {
	struct TWeakObjectPtr<struct USceneComponent> Component; // 0x60(0x08)
	struct FName SocketName; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class Constraints.TickableTransformConstraint
// Size: 0xb0 (Inherited: 0x90)
struct UTickableTransformConstraint : UTickableConstraint {
	struct UTransformableHandle* ParentTRSHandle; // 0x90(0x08)
	struct UTransformableHandle* ChildTRSHandle; // 0x98(0x08)
	bool bMaintainOffset; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	float Weight; // 0xa4(0x04)
	bool bDynamicOffset; // 0xa8(0x01)
	enum class ETransformConstraintType Type; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
};

// Class Constraints.TickableTranslationConstraint
// Size: 0xd8 (Inherited: 0xb0)
struct UTickableTranslationConstraint : UTickableTransformConstraint {
	char pad_B0[0x8]; // 0xb0(0x08)
	struct FVector OffsetTranslation; // 0xb8(0x18)
	struct FFilterOptionPerAxis AxisFilter; // 0xd0(0x03)
	char pad_D3[0x5]; // 0xd3(0x05)
};

// Class Constraints.TickableRotationConstraint
// Size: 0xf0 (Inherited: 0xb0)
struct UTickableRotationConstraint : UTickableTransformConstraint {
	char pad_B0[0x10]; // 0xb0(0x10)
	struct FQuat OffsetRotation; // 0xc0(0x20)
	struct FFilterOptionPerAxis AxisFilter; // 0xe0(0x03)
	char pad_E3[0xd]; // 0xe3(0x0d)
};

// Class Constraints.TickableScaleConstraint
// Size: 0xd8 (Inherited: 0xb0)
struct UTickableScaleConstraint : UTickableTransformConstraint {
	char pad_B0[0x8]; // 0xb0(0x08)
	struct FVector OffsetScale; // 0xb8(0x18)
	struct FFilterOptionPerAxis AxisFilter; // 0xd0(0x03)
	char pad_D3[0x5]; // 0xd3(0x05)
};

// Class Constraints.TickableParentConstraint
// Size: 0x130 (Inherited: 0xb0)
struct UTickableParentConstraint : UTickableTransformConstraint {
	char pad_B0[0x10]; // 0xb0(0x10)
	struct FTransform OffsetTransform; // 0xc0(0x60)
	bool bScaling; // 0x120(0x01)
	struct FTransformFilter TransformFilter; // 0x121(0x09)
	char pad_12A[0x6]; // 0x12a(0x06)
};

// Class Constraints.TickableLookAtConstraint
// Size: 0xc8 (Inherited: 0xb0)
struct UTickableLookAtConstraint : UTickableTransformConstraint {
	struct FVector Axis; // 0xb0(0x18)
};

