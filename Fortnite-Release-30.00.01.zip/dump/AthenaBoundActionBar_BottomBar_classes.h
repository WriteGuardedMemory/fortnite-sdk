// BlueprintGeneratedClass AthenaBoundActionBar_BottomBar.AthenaBoundActionBar_BottomBar_C
// Size: 0x270 (Inherited: 0x270)
struct UAthenaBoundActionBar_BottomBar_C : UAthenaBoundActionBar {
};

