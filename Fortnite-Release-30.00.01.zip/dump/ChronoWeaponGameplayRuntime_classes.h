// Class ChronoWeaponGameplayRuntime.AnimInstance_ChronoPanRifle
// Size: 0x380 (Inherited: 0x370)
struct UAnimInstance_ChronoPanRifle : UAnimInstance {
	bool bIsFiring; // 0x368(0x01)
	bool bIsReloading; // 0x369(0x01)
	float MagRotationValue; // 0x36c(0x04)
	struct FName ResetMagRotationCurveName; // 0x370(0x04)
	char pad_37A[0x6]; // 0x37a(0x06)
};

