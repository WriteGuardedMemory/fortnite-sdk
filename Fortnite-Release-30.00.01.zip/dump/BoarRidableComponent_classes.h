// BlueprintGeneratedClass BoarRidableComponent.BoarRidableComponent_C
// Size: 0xe3c (Inherited: 0xdf1)
struct UBoarRidableComponent_C : UCreatureBaseRidableComponent_C {
	char pad_DF1[0x7]; // 0xdf1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xdf8(0x08)
	struct USoundBase* BurtChargeStartSound; // 0xe00(0x08)
	struct UAudioComponent* ChargeSoundComp; // 0xe08(0x08)
	double SprintCooldDownTime; // 0xe10(0x08)
	struct UGameplayEffect* GESprintImpactPawn; // 0xe18(0x08)
	struct FGameplayTag SprintImpactGameplayCueTag; // 0xe20(0x04)
	char pad_E24[0x4]; // 0xe24(0x04)
	struct UGameplayEffect* GESprintImpactVehicle; // 0xe28(0x08)
	struct FGameplayTag SprintChargeImpact_Default_CueTag; // 0xe30(0x04)
	struct FGameplayTag SprintChargeImpact_Pawn_CueTag; // 0xe34(0x04)
	struct FGameplayTag SprintChargeImpact_DestroyBuild_CueTag; // 0xe38(0x04)

	void OnReaction(struct UObject* Object, struct FHitResult HitResult); // Function BoarRidableComponent.BoarRidableComponent_C.OnReaction // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void HandleRiderStoppedRiding(struct URiderComponent* Rider); // Function BoarRidableComponent.BoarRidableComponent_C.HandleRiderStoppedRiding // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void HandleRiderStartedRiding(struct URiderComponent* Rider); // Function BoarRidableComponent.BoarRidableComponent_C.HandleRiderStartedRiding // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void HandleAbilityStarted(); // Function BoarRidableComponent.BoarRidableComponent_C.HandleAbilityStarted // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function BoarRidableComponent.BoarRidableComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnReactionEvent(struct AActor* HitActor, bool bFromAsyncSweepBox, enum class FCollisionReactionType CollisionReactionType, bool bIsFirstContinuousReactionOnDelayableActor, struct FHitResult& HitResult); // Function BoarRidableComponent.BoarRidableComponent_C.OnReactionEvent // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BoarRidableComponent.BoarRidableComponent_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_BoarRidableComponent(int32_t EntryPoint); // Function BoarRidableComponent.BoarRidableComponent_C.ExecuteUbergraph_BoarRidableComponent // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

