// WidgetBlueprintGeneratedClass CorrectiveActionDisplayNameScreen.CorrectiveActionDisplayNameScreen_C
// Size: 0x440 (Inherited: 0x428)
struct UCorrectiveActionDisplayNameScreen_C : UFortCorrectiveActionDisplayNameScreen {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x428(0x08)
	struct UImage* Image_DisplayNameEntrySpinner; // 0x430(0x08)
	struct UCommonTextBlock* Text_DisplayNameEntryError; // 0x438(0x08)

	void OnShowFailureReason(struct FText& FailureReason); // Function CorrectiveActionDisplayNameScreen.CorrectiveActionDisplayNameScreen_C.OnShowFailureReason // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnShowCorrectiveActionProcessing(bool bShowProcessing); // Function CorrectiveActionDisplayNameScreen.CorrectiveActionDisplayNameScreen_C.OnShowCorrectiveActionProcessing // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnShowDisplayNameDownloading(bool bShowDownloading); // Function CorrectiveActionDisplayNameScreen.CorrectiveActionDisplayNameScreen_C.OnShowDisplayNameDownloading // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__CorrectiveActionDisplayNameScreen_Button_Continue_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function CorrectiveActionDisplayNameScreen.CorrectiveActionDisplayNameScreen_C.BndEvt__CorrectiveActionDisplayNameScreen_Button_Continue_K2Node_ComponentBoundEvent_0_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__CorrectiveActionDisplayNameScreen_Button_PrivacyPolicy_K2Node_ComponentBoundEvent_1_CommonButtonBaseClicked__DelegateSignature(struct UCommonButtonBase* Button); // Function CorrectiveActionDisplayNameScreen.CorrectiveActionDisplayNameScreen_C.BndEvt__CorrectiveActionDisplayNameScreen_Button_PrivacyPolicy_K2Node_ComponentBoundEvent_1_CommonButtonBaseClicked__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_CorrectiveActionDisplayNameScreen(int32_t EntryPoint); // Function CorrectiveActionDisplayNameScreen.CorrectiveActionDisplayNameScreen_C.ExecuteUbergraph_CorrectiveActionDisplayNameScreen // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

