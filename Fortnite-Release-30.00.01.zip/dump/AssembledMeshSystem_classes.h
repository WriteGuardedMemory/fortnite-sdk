// Class AssembledMeshSystem.AssembledMeshSchema
// Size: 0x1e0 (Inherited: 0x30)
struct UAssembledMeshSchema : UPrimaryDataAsset {
	struct FGameplayTag MeshSchemaTag; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TSoftObjectPtr<UCustomizableObjectInstance> CustomizableObjectInstance; // 0x38(0x20)
	struct TSoftObjectPtr<UCustomizableObject> CustomizableObject; // 0x58(0x20)
	int32_t ComponentIndex; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TSoftObjectPtr<USkeletalMesh> SkeletalMesh; // 0x80(0x20)
	struct TMap<struct FString, struct FString> SelectedIntParams; // 0xa0(0x50)
	struct TMap<struct FString, float> SelectedFloatParams; // 0xf0(0x50)
	struct FAssembledMeshAttachmentRules AttachmentRules; // 0x140(0x50)
	struct TSoftClassPtr<UObject> AnimClass; // 0x190(0x20)
	struct FGameplayTagContainer SoundLibraryTags; // 0x1b0(0x20)
	struct TArray<struct FInstancedStruct> AdditionalData; // 0x1d0(0x10)
};

// Class AssembledMeshSystem.HeadAccDataAssetLink
// Size: 0x128 (Inherited: 0x128)
struct UHeadAccDataAssetLink : UDataAssetLink {
};

// Class AssembledMeshSystem.NeckAccDataAssetLink
// Size: 0x128 (Inherited: 0x128)
struct UNeckAccDataAssetLink : UDataAssetLink {
};

// Class AssembledMeshSystem.HipAccDataAssetLink
// Size: 0x128 (Inherited: 0x128)
struct UHipAccDataAssetLink : UDataAssetLink {
};

// Class AssembledMeshSystem.AssembledMeshUserComponent
// Size: 0xe8 (Inherited: 0xa0)
struct UAssembledMeshUserComponent : UActorComponent {
	struct TArray<struct UObject*> LoadedAssets; // 0xa0(0x10)
	char pad_B0[0x10]; // 0xb0(0x10)
	struct TArray<struct UAssembledMeshSchema*> MeshParts; // 0xc0(0x10)
	struct TArray<struct FAssembledComponentReferences> MeshPartComponents; // 0xd0(0x10)
	bool bAssignMeshPartsOnBeginPlay; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)

	void SetMeshParts(struct TArray<struct UAssembledMeshSchema*> InMeshParts); // Function AssembledMeshSystem.AssembledMeshUserComponent.SetMeshParts // (Final|Native|Private|BlueprintCallable) // @ game+0x784bb54
	void SetMeshPart(struct UAssembledMeshSchema* InMeshPart); // Function AssembledMeshSystem.AssembledMeshUserComponent.SetMeshPart // (Final|Native|Private|BlueprintCallable) // @ game+0x784ba4c
	void OnRep_MeshParts(); // Function AssembledMeshSystem.AssembledMeshUserComponent.OnRep_MeshParts // (Native|Protected) // @ game+0x2597ae4
	struct UAssembledMeshSchema* GetMeshPart(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GetMeshPart // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x6c11ce4
	struct USkeletalMeshComponent* GetAttachToComponent(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GetAttachToComponent // (Native|Event|Protected|BlueprintEvent) // @ game+0x3691c38
	void GatherAndAssignAssembledMeshParts(); // Function AssembledMeshSystem.AssembledMeshUserComponent.GatherAndAssignAssembledMeshParts // (Native|Public) // @ game+0x24a8e20
	void CustomizationCompleted(int32_t PartIndex); // Function AssembledMeshSystem.AssembledMeshUserComponent.CustomizationCompleted // (Native|Protected) // @ game+0x784b988
};

