// Class CollectionMapShared.AthenaCollectionScreenMapBase
// Size: 0x6c0 (Inherited: 0x638)
struct UAthenaCollectionScreenMapBase : UAthenaCollectionScreenBase {
	struct UAthenaFullScreenMapBase* MapWidget; // 0x638(0x08)
	char pad_640[0x8]; // 0x640(0x08)
	struct UAthenaMapCollectionIcon* CollectionIconType; // 0x648(0x08)
	struct TMap<struct FGameplayTag, struct UAthenaMapCollectionIcon*> MapCollectionIcons; // 0x650(0x50)
	char pad_6A0[0x20]; // 0x6a0(0x20)
};

// Class CollectionMapShared.AthenaMapCollectionIcon
// Size: 0x378 (Inherited: 0x378)
struct UAthenaMapCollectionIcon : UAthenaMapNavigableIconCustom {

	void SetSecondaryIcon(struct TSoftObjectPtr<UObject>& SecondaryIcon); // Function CollectionMapShared.AthenaMapCollectionIcon.SetSecondaryIcon // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void SetIsKnown(bool bIsKnown); // Function CollectionMapShared.AthenaMapCollectionIcon.SetIsKnown // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
};

