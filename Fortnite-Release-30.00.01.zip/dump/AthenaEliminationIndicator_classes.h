// WidgetBlueprintGeneratedClass AthenaEliminationIndicator.AthenaEliminationIndicator_C
// Size: 0x5e8 (Inherited: 0x5c0)
struct UAthenaEliminationIndicator_C : UAthenaEliminationIndicator {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5c0(0x08)
	struct UWidgetAnimation* Outro; // 0x5c8(0x08)
	struct UWidgetAnimation* Intro; // 0x5d0(0x08)
	struct UImage* Arrow; // 0x5d8(0x08)
	struct UImage* Image_Diamondpulse; // 0x5e0(0x08)

	void Construct(); // Function AthenaEliminationIndicator.AthenaEliminationIndicator_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_AthenaEliminationIndicator(int32_t EntryPoint); // Function AthenaEliminationIndicator.AthenaEliminationIndicator_C.ExecuteUbergraph_AthenaEliminationIndicator // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

