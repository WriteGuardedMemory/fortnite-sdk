// Class AnimPresetsRuntime.AnimPreset
// Size: 0x28 (Inherited: 0x28)
struct UAnimPreset : UObject {

	void HandleAnimInstance(struct UAnimInstance* Instance); // Function AnimPresetsRuntime.AnimPreset.HandleAnimInstance // (Native|Event|Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0x8152ad8
	struct TSoftClassPtr<UObject> GetPresetClass(); // Function AnimPresetsRuntime.AnimPreset.GetPresetClass // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x8152a90
};

// Class AnimPresetsRuntime.AnimPresetComponent
// Size: 0xc0 (Inherited: 0xa0)
struct UAnimPresetComponent : UActorComponent {
	struct TSoftClassPtr<UObject> AnimPreset; // 0xa0(0x20)
};

// Class AnimPresetsRuntime.AnimPreset_BasicLocomotion
// Size: 0x78 (Inherited: 0x28)
struct UAnimPreset_BasicLocomotion : UAnimPreset {
	struct FAnimPreset_SingleAnimationData Idle; // 0x28(0x10)
	struct FAnimPreset_SingleAnimationData MoveForward; // 0x38(0x10)
	struct FAnimPreset_SingleAnimationData MoveBackward; // 0x48(0x10)
	struct FAnimPreset_SingleAnimationData MoveLeft; // 0x58(0x10)
	struct FAnimPreset_SingleAnimationData MoveRight; // 0x68(0x10)
};

// Class AnimPresetsRuntime.GameFeatureAction_AnimPreset
// Size: 0x88 (Inherited: 0x28)
struct UGameFeatureAction_AnimPreset : UGameFeatureAction {
	struct TSoftClassPtr<UObject> AnimBP_Preset_BasicLocomotion; // 0x28(0x20)
	struct TSoftClassPtr<UObject> AnimBP_CopyPoseFromMesh; // 0x48(0x20)
	struct TSoftClassPtr<UObject> AnimBP_RetargetPoseFromMesh; // 0x68(0x20)
};

