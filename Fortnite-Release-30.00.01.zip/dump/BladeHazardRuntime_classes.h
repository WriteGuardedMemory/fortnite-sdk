// Class BladeHazardRuntime.FortBladeHazard
// Size: 0x998 (Inherited: 0x980)
struct AFortBladeHazard : ABuildingGameplayActor {
	enum class EFortSawBladeSpinningDirection SpinningDirection; // 0x980(0x01)
	char pad_981[0x7]; // 0x981(0x07)
	struct TArray<struct FTransform> CustomForceDirections; // 0x988(0x10)

	struct FVector GetForceDirectionForHit(struct FHitResult& Hit); // Function BladeHazardRuntime.FortBladeHazard.GetForceDirectionForHit // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3870504
};

