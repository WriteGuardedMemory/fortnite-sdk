// Class ContextualActionCodeRuntime.FortMovementMode_ExtLogicBaseSwinging
// Size: 0x148 (Inherited: 0x110)
struct UFortMovementMode_ExtLogicBaseSwinging : UFortMovementMode_BaseExtLogic {
	char pad_110[0x8]; // 0x110(0x08)
	struct UFortPlayerAnimInstance_SwingingObject* SwingingAnimationLayer; // 0x118(0x08)
	float GravitationalAcceleration; // 0x120(0x04)
	float MinimumInitialSpeed; // 0x124(0x04)
	float AccelerationMultiplier; // 0x128(0x04)
	float DefaultAcceleration; // 0x12c(0x04)
	float NonBrakingFriction; // 0x130(0x04)
	float BrakingFriction; // 0x134(0x04)
	float BrakingDeceleration; // 0x138(0x04)
	float MaxSpeed; // 0x13c(0x04)
	struct FGameplayTag SwingingTag; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)

	void OnOwnerDBNO(); // Function ContextualActionCodeRuntime.FortMovementMode_ExtLogicBaseSwinging.OnOwnerDBNO // (Final|Native|Protected) // @ game+0xc81d5ec
};

// Class ContextualActionCodeRuntime.FortMovementMode_SwingingObjectRuntimeData
// Size: 0x100 (Inherited: 0x38)
struct UFortMovementMode_SwingingObjectRuntimeData : UFortMovementMode_BaseExtRuntimeData {
	char pad_38[0xc8]; // 0x38(0xc8)
};

// Class ContextualActionCodeRuntime.FortMovementMode_ExtLogicSwingingObject
// Size: 0x180 (Inherited: 0x148)
struct UFortMovementMode_ExtLogicSwingingObject : UFortMovementMode_ExtLogicBaseSwinging {
	struct FVector AttachOffset; // 0x148(0x18)
	struct FVector HandIKOffset; // 0x160(0x18)
	bool bAlignCharacterToObject; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)
};

// Class ContextualActionCodeRuntime.FortMovementMode_SwingingRopeRuntimeData
// Size: 0x60 (Inherited: 0x38)
struct UFortMovementMode_SwingingRopeRuntimeData : UFortMovementMode_BaseExtRuntimeData {
	char pad_38[0x28]; // 0x38(0x28)
};

// Class ContextualActionCodeRuntime.FortMovementMode_ExtLogicSwingingRope
// Size: 0x180 (Inherited: 0x148)
struct UFortMovementMode_ExtLogicSwingingRope : UFortMovementMode_ExtLogicBaseSwinging {
	struct UFortInputMappingContext* InputMappingContext; // 0x148(0x08)
	struct UInputAction* SwingingAscendAction; // 0x150(0x08)
	struct UInputAction* SwingingAscendActionRelease; // 0x158(0x08)
	float MinimumAscendRange; // 0x160(0x04)
	float AscendMaxSpeed; // 0x164(0x04)
	float DescendMaxSpeed; // 0x168(0x04)
	float AscendingSettleInterpSpeed; // 0x16c(0x04)
	float AscendingSettleAngleThreshold; // 0x170(0x04)
	char pad_174[0xc]; // 0x174(0x0c)
};

// Class ContextualActionCodeRuntime.FortPlayerAnimInstance_Hijacker
// Size: 0x470 (Inherited: 0x470)
struct UFortPlayerAnimInstance_Hijacker : UFortBaseLayerAnimInstance {
};

// Class ContextualActionCodeRuntime.FortPlayerAnimInstance_SwingingObject
// Size: 0x4b0 (Inherited: 0x470)
struct UFortPlayerAnimInstance_SwingingObject : UFortBaseLayerAnimInstance {
	struct FVector2D RelativeVelocity2D; // 0x468(0x10)
	struct FVector HandAttachLocation; // 0x478(0x18)
	float LeftHandIKAlpha; // 0x490(0x04)
	char pad_49C[0x14]; // 0x49c(0x14)
};

// Class ContextualActionCodeRuntime.FortSwingingObject
// Size: 0x9d0 (Inherited: 0x980)
struct AFortSwingingObject : ABuildingGameplayActor {
	float MaxSwingAngle; // 0x980(0x04)
	bool bUseCharacterSwingMovementMode; // 0x984(0x01)
	bool bCanAscend; // 0x985(0x01)
	char pad_986[0x2]; // 0x986(0x02)
	struct FVector FixedSwingDirection; // 0x988(0x18)
	bool bUseFixedSwingDirection; // 0x9a0(0x01)
	char pad_9A1[0x3]; // 0x9a1(0x03)
	float ForwardInteractOffset; // 0x9a4(0x04)
	float RightInteractOffset; // 0x9a8(0x04)
	bool bUseClientTransformSmoothing; // 0x9ac(0x01)
	char pad_9AD[0x3]; // 0x9ad(0x03)
	float SmoothingWindow; // 0x9b0(0x04)
	char pad_9B4[0x4]; // 0x9b4(0x04)
	struct USceneComponent* AttachPoint; // 0x9b8(0x08)
	char pad_9C0[0x10]; // 0x9c0(0x10)

	void OnStartSwing_BP(struct AFortPlayerPawn* AttachedActor); // Function ContextualActionCodeRuntime.FortSwingingObject.OnStartSwing_BP // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnEndSwing_BP(struct AFortPlayerPawn* AttachedActor); // Function ContextualActionCodeRuntime.FortSwingingObject.OnEndSwing_BP // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
};

// Class ContextualActionCodeRuntime.FortSwingingRope
// Size: 0xa08 (Inherited: 0x9d0)
struct AFortSwingingRope : AFortSwingingObject {
	struct UCableComponent* CableComponent; // 0x9d0(0x08)
	float UnattachedCableGravityScale; // 0x9d8(0x04)
	float UnattachedSolverIterations; // 0x9dc(0x04)
	float CableLengthMultiplier; // 0x9e0(0x04)
	char pad_9E4[0x24]; // 0x9e4(0x24)
};

// Class ContextualActionCodeRuntime.HijackerComponent
// Size: 0x190 (Inherited: 0xa8)
struct UHijackerComponent : UFortPawnComponent {
	struct FVector HijackOffset; // 0xa8(0x18)
	struct FText StartHijackInteractText; // 0xc0(0x10)
	struct FText StartHijackInteractSubText; // 0xd0(0x10)
	struct FText CompleteHijackInteractText; // 0xe0(0x10)
	struct FText CompleteHijackInteractSubText; // 0xf0(0x10)
	struct UFortPlayerAnimInstance_Hijacker* HijackerAnimInstanceClass; // 0x100(0x08)
	float RequiredInteractionDuration; // 0x108(0x04)
	float HijackCooldown; // 0x10c(0x04)
	struct FVector BaseThrownVelocity; // 0x110(0x18)
	float AccelerationThresholdForEjectingHijacker; // 0x128(0x04)
	float MinimumSpeedForEjectingHijacker; // 0x12c(0x04)
	enum class EHijackingStatus HijackingStatus; // 0x130(0x01)
	char pad_131[0x5f]; // 0x131(0x5f)

	bool TryHijack(struct AActor* VehicleTarget, struct FInteractionType& InteractionType); // Function ContextualActionCodeRuntime.HijackerComponent.TryHijack // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc81da18
	void OnStartHijack(struct AActor* VehicleTarget); // Function ContextualActionCodeRuntime.HijackerComponent.OnStartHijack // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x9c34b8c
	void OnCompleteHijack(); // Function ContextualActionCodeRuntime.HijackerComponent.OnCompleteHijack // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x284f49c
	void HandleOwnerJumpInput(bool bPressed); // Function ContextualActionCodeRuntime.HijackerComponent.HandleOwnerJumpInput // (Final|Native|Private) // @ game+0xc81d160
	void EjectHijacker(struct AActor* DamageCauser, float Damage, struct FVector EventLocation); // Function ContextualActionCodeRuntime.HijackerComponent.EjectHijacker // (Final|Net|NetReliableNative|Event|NetMulticast|Private|HasDefaults) // @ game+0xc81ce40
	void CancelHijack_Server(); // Function ContextualActionCodeRuntime.HijackerComponent.CancelHijack_Server // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x24a8e20
	void CancelHijack_NetMulticast(); // Function ContextualActionCodeRuntime.HijackerComponent.CancelHijack_NetMulticast // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x26dd440
	void BP_OnStartHijack(); // Function ContextualActionCodeRuntime.HijackerComponent.BP_OnStartHijack // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnHijackInterrupted(); // Function ContextualActionCodeRuntime.HijackerComponent.BP_OnHijackInterrupted // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnHijackCancelled(); // Function ContextualActionCodeRuntime.HijackerComponent.BP_OnHijackCancelled // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnCompleteHijack(); // Function ContextualActionCodeRuntime.HijackerComponent.BP_OnCompleteHijack // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnCleanup(); // Function ContextualActionCodeRuntime.HijackerComponent.BP_OnCleanup // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_GetThrownVelocity(struct AActor* DamageCauser, float Damage, struct FVector& EventLocation, struct FVector& OutVelocity); // Function ContextualActionCodeRuntime.HijackerComponent.BP_GetThrownVelocity // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent|Const) // @ game+0x18e3f1c
	void BP_CanStartHijack(bool& OutCanStartHijack); // Function ContextualActionCodeRuntime.HijackerComponent.BP_CanStartHijack // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x18e3f1c
	void BP_CanCompleteHijack(bool& OutCanCompleteHijack); // Function ContextualActionCodeRuntime.HijackerComponent.BP_CanCompleteHijack // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x18e3f1c
};

// Class ContextualActionCodeRuntime.Hijack_InteractionOverrideComponent
// Size: 0xb0 (Inherited: 0xb0)
struct UHijack_InteractionOverrideComponent : UFortVehicleInteractionOverrideComponent {
};

// Class ContextualActionCodeRuntime.RappellingComponent
// Size: 0x898 (Inherited: 0xa8)
struct URappellingComponent : UFortPawnComponent {
	struct UInputAction* RappelInputAction; // 0xa8(0x08)
	struct UInputAction* RappelEndInputAction; // 0xb0(0x08)
	struct UInputMappingContext* RappelInputMappingContext; // 0xb8(0x08)
	float ForwardTraceOffset; // 0xc0(0x04)
	float DownwardTraceLength; // 0xc4(0x04)
	float ConnectionTraceOffset; // 0xc8(0x04)
	float MaxDistanceToRappellingEdge; // 0xcc(0x04)
	float InitiateSwingAngleThreshold; // 0xd0(0x04)
	float InitiateSwingSpeedThreshold; // 0xd4(0x04)
	float MinDistanceFromRappelPointToSwing; // 0xd8(0x04)
	float RappellingSwingTraceLength; // 0xdc(0x04)
	float RappellingSwingRecoveryForce; // 0xe0(0x04)
	float RappellingSwingLaunchSpeed; // 0xe4(0x04)
	float RappellingSwingVerticalAttachOffset; // 0xe8(0x04)
	float RappellingSwingVerticalDistanceThresholdToSlow; // 0xec(0x04)
	float RappellingSwingVerticalMaxSpeedWhileSlowing; // 0xf0(0x04)
	float RappellingSwingVerticalMinDistanceToAttach; // 0xf4(0x04)
	float RappellingSwingVerticalMaxDistanceToAttach; // 0xf8(0x04)
	struct FGameplayTag RappellingSwingParametersTag; // 0xfc(0x04)
	struct FSwingingControlParams RappellingSwingParameters; // 0x100(0x738)
	enum class ERappellingState ReplicatedRappellingState; // 0x838(0x01)
	char pad_839[0x7]; // 0x839(0x07)
	struct FVector RappellingEdge; // 0x840(0x18)
	struct FVector RappellingNormal; // 0x858(0x18)
	struct URappellingSwingMovementControls* MovementControls; // 0x870(0x08)
	char pad_878[0x20]; // 0x878(0x20)

	void TestToggleGravity_Server(); // Function ContextualActionCodeRuntime.RappellingComponent.TestToggleGravity_Server // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x1e9fa78
	void TestToggleGravity(); // Function ContextualActionCodeRuntime.RappellingComponent.TestToggleGravity // (Final|Native|Public|BlueprintCallable) // @ game+0xc81d9c8
	void StartRappellingSwing_Server(); // Function ContextualActionCodeRuntime.RappellingComponent.StartRappellingSwing_Server // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x18e3774
	void StartRappelling_Server(struct FVector NewGravityDirection, struct FVector ClientRappellingEdge, struct FVector ClientRappellingNormal); // Function ContextualActionCodeRuntime.RappellingComponent.StartRappelling_Server // (Net|NetReliableNative|Event|Protected|NetServer|HasDefaults) // @ game+0xc81d7fc
	void StartRappelling(); // Function ContextualActionCodeRuntime.RappellingComponent.StartRappelling // (Final|Native|Public|BlueprintCallable) // @ game+0xc81d7e8
	void RappellingCorrectFallingRotation_Client(); // Function ContextualActionCodeRuntime.RappellingComponent.RappellingCorrectFallingRotation_Client // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x26dd440
	void OnValidTargeting(); // Function ContextualActionCodeRuntime.RappellingComponent.OnValidTargeting // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnStartRappelling(); // Function ContextualActionCodeRuntime.RappellingComponent.OnStartRappelling // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnRep_RappellingState(); // Function ContextualActionCodeRuntime.RappellingComponent.OnRep_RappellingState // (Final|Native|Protected) // @ game+0xc81d7bc
	void OnOwnerMovementModeChanged(struct ACharacter* Character, enum class EMovementMode PreviousMovementMode, char PreviousCustomMode); // Function ContextualActionCodeRuntime.RappellingComponent.OnOwnerMovementModeChanged // (Final|Native|Protected) // @ game+0xc81d600
	void OnInvalidTargeting(); // Function ContextualActionCodeRuntime.RappellingComponent.OnInvalidTargeting // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnEndRappelling(); // Function ContextualActionCodeRuntime.RappellingComponent.OnEndRappelling // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnCapsuleHit(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function ContextualActionCodeRuntime.RappellingComponent.OnCapsuleHit // (Final|Native|Protected|HasOutParms|HasDefaults) // @ game+0xc81d2e8
	void EndRappellingSwing_Server(); // Function ContextualActionCodeRuntime.RappellingComponent.EndRappellingSwing_Server // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x24a8e20
	void EndRappelling_Server(); // Function ContextualActionCodeRuntime.RappellingComponent.EndRappelling_Server // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x284f49c
	void EndRappelling(); // Function ContextualActionCodeRuntime.RappellingComponent.EndRappelling // (Final|Native|Public|BlueprintCallable) // @ game+0xc81d008
};

// Class ContextualActionCodeRuntime.RappellingSwingMovementControls
// Size: 0x30 (Inherited: 0x30)
struct URappellingSwingMovementControls : UFortMovementControls {
};

// Class ContextualActionCodeRuntime.SwingingObjectCameraMode
// Size: 0x1d00 (Inherited: 0x1cd0)
struct USwingingObjectCameraMode : UFortCameraMode_ThirdPerson {
	struct FVector MaxSwingAdditionalViewTargetOffset; // 0x1cd0(0x18)
	float MaxSwingFOV; // 0x1ce8(0x04)
	char pad_1CEC[0x14]; // 0x1cec(0x14)
};

// Class ContextualActionCodeRuntime.SwingingObjectComponent
// Size: 0x120 (Inherited: 0xa8)
struct USwingingObjectComponent : UFortPawnComponent {
	float JumpHorizontalSpeedBoost; // 0xa8(0x04)
	float JumpVerticalSpeedBoost; // 0xac(0x04)
	float MinimumAscendRange; // 0xb0(0x04)
	float AscendMaxSpeed; // 0xb4(0x04)
	float DescendMaxSpeed; // 0xb8(0x04)
	float AscendingSettleInterpSpeed; // 0xbc(0x04)
	float AscendingSettleAngleThreshold; // 0xc0(0x04)
	float MinimumTimeBetweenRepeatSwings; // 0xc4(0x04)
	float MaximumAngleForAutoAttach; // 0xc8(0x04)
	float MinimumSpeedForAutoAttach; // 0xcc(0x04)
	struct UFortMovementMode_BaseExtLogic* SwingingRopeMovementModeExtension; // 0xd0(0x08)
	struct UFortMovementMode_BaseExtLogic* SwingingObjectMovementModeExtension; // 0xd8(0x08)
	enum class ESwingingState SwingingState; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	struct TWeakObjectPtr<struct AFortSwingingObject> ReplicatedSwingingObject; // 0xe4(0x08)
	char pad_EC[0x34]; // 0xec(0x34)

	void OnRep_SwingingObject(); // Function ContextualActionCodeRuntime.SwingingObjectComponent.OnRep_SwingingObject // (Final|Native|Private) // @ game+0xc81d7d4
	void HandleOwnerJumpInput(bool bPressed); // Function ContextualActionCodeRuntime.SwingingObjectComponent.HandleOwnerJumpInput // (Final|Native|Private) // @ game+0xc81d224
	void GetSwingDeltaAngle(struct FRotator& OutSwingRotation, struct FRotator& OutDeltaRotation); // Function ContextualActionCodeRuntime.SwingingObjectComponent.GetSwingDeltaAngle // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xc81d080
	struct FRotator GetAimRotation(); // Function ContextualActionCodeRuntime.SwingingObjectComponent.GetAimRotation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xc81d01c
	void DetachFromObject_Server(bool bJumpExit); // Function ContextualActionCodeRuntime.SwingingObjectComponent.DetachFromObject_Server // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0xb72b684
	void BP_OnStartSwing(); // Function ContextualActionCodeRuntime.SwingingObjectComponent.BP_OnStartSwing // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnEndSwing(); // Function ContextualActionCodeRuntime.SwingingObjectComponent.BP_OnEndSwing // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_CanStartSwing(struct AFortSwingingObject* SwingTarget, bool& bCanStartSwing); // Function ContextualActionCodeRuntime.SwingingObjectComponent.BP_CanStartSwing // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x18e3f1c
	void AttachToObject_Server(struct AFortSwingingObject* Object); // Function ContextualActionCodeRuntime.SwingingObjectComponent.AttachToObject_Server // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x6f615c4
};

