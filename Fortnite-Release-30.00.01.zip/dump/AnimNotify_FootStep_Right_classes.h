// BlueprintGeneratedClass AnimNotify_FootStep_Right.AnimNotify_FootStep_Right_C
// Size: 0x80 (Inherited: 0x80)
struct UAnimNotify_FootStep_Right_C : UAnimNotify_FootStep_C {
};

