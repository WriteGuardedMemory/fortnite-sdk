// ScriptStruct CloakGameplay.FortGameCueCloakModifier
// Size: 0xd0 (Inherited: 0x00)
struct FFortGameCueCloakModifier {
	struct FScalableFloat bCanBeEnabled; // 0x00(0x28)
	struct FScalableFloat VisibilityModifierMultiplicative; // 0x28(0x28)
	struct FScalableFloat VisibilityModifierAdditive; // 0x50(0x28)
	struct FScalableFloat AlphaTimeToEnabled; // 0x78(0x28)
	struct FScalableFloat AlphaTimeToDisabled; // 0xa0(0x28)
	char bCurrentlyEnabled : 1; // 0xc8(0x01)
	char pad_C8_1 : 7; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	float CurrentAlpha; // 0xcc(0x04)
};

