// Enum AudioShapes.EAudioShapeComponentState
enum class EAudioShapeComponentState : uint8 {
	Inactive = 0,
	Active = 1,
	Count = 2,
	EAudioShapeComponentState_MAX = 3
};

