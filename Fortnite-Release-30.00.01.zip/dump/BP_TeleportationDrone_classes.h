// BlueprintGeneratedClass BP_TeleportationDrone.BP_TeleportationDrone_C
// Size: 0x360 (Inherited: 0x318)
struct ABP_TeleportationDrone_C : APawn {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x318(0x08)
	struct USkeletalMeshComponentBudgeted* SkeletalMeshComponentBudgeted; // 0x320(0x08)
	struct USceneComponent* Scene; // 0x328(0x08)
	double AnimPlayRate; // 0x330(0x08)
	struct UMaterialInstanceDynamic* StaticMeshMID; // 0x338(0x08)
	bool TeleportIn; // 0x340(0x01)
	char pad_341[0x7]; // 0x341(0x07)
	struct UParticleSystemComponent* CharacterAttached; // 0x348(0x08)
	bool InLobby; // 0x350(0x01)
	char pad_351[0x7]; // 0x351(0x07)
	struct USkeletalMeshComponent* Mesh for Attachment; // 0x358(0x08)

	struct UAnimationAsset* Get Spawn Animation(); // Function BP_TeleportationDrone.BP_TeleportationDrone_C.Get Spawn Animation // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void PlaySpawnAnim(); // Function BP_TeleportationDrone.BP_TeleportationDrone_C.PlaySpawnAnim // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function BP_TeleportationDrone.BP_TeleportationDrone_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnSpawnOutAnimEnded(struct UAnimMontage* Montage, bool bInterrupted); // Function BP_TeleportationDrone.BP_TeleportationDrone_C.OnSpawnOutAnimEnded // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function BP_TeleportationDrone.BP_TeleportationDrone_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveTick(float DeltaSeconds); // Function BP_TeleportationDrone.BP_TeleportationDrone_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_BP_TeleportationDrone(int32_t EntryPoint); // Function BP_TeleportationDrone.BP_TeleportationDrone_C.ExecuteUbergraph_BP_TeleportationDrone // (Final|UbergraphFunction) // @ game+0x18e3f1c
};

