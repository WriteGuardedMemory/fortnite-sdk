// BlueprintGeneratedClass CameraShake_Riding_BoarSprintImpact_Default.CameraShake_Riding_BoarSprintImpact_Default_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_Riding_BoarSprintImpact_Default_C : ULegacyCameraShake {
};

