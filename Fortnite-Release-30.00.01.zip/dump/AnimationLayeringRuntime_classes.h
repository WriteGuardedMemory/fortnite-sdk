// Class AnimationLayeringRuntime.BoneMaskDefinitionDataAsset
// Size: 0x40 (Inherited: 0x30)
struct UBoneMaskDefinitionDataAsset : UDataAsset {
	struct FBoneMaskDefinition BoneMaskDefinition; // 0x30(0x10)
};

// Class AnimationLayeringRuntime.BoneMaskFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBoneMaskFunctionLibrary : UBlueprintFunctionLibrary {

	void BP_BoneMask_UpdateBodyPartWeightsMulti(struct FBoneMask& BoneMask, struct TArray<struct FBoneMaskUpdateMultiParam>& Params); // Function AnimationLayeringRuntime.BoneMaskFunctionLibrary.BP_BoneMask_UpdateBodyPartWeightsMulti // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x88bc62c
	void BP_BoneMask_UpdateBodyPartWeights(struct FBoneMask& BoneMask, struct FName Name, float LocalSpaceWeight, float MeshSpaceWeight); // Function AnimationLayeringRuntime.BoneMaskFunctionLibrary.BP_BoneMask_UpdateBodyPartWeights // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x88bc3c0
	void BP_BoneMask_UpdateBodyPartMeshSpaceWeight(struct FBoneMask& BoneMask, struct FName Name, float MeshSpaceWeight); // Function AnimationLayeringRuntime.BoneMaskFunctionLibrary.BP_BoneMask_UpdateBodyPartMeshSpaceWeight // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x88bc1dc
	void BP_BoneMask_UpdateBodyPartLocalSpaceWeight(struct FBoneMask& BoneMask, struct FName Name, float LocalSpaceWeight); // Function AnimationLayeringRuntime.BoneMaskFunctionLibrary.BP_BoneMask_UpdateBodyPartLocalSpaceWeight // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x88bc1dc
	void BP_BoneMask_GetBodyPartWeights(struct FBoneMask& BoneMask, struct FName Name, float& LocalSpaceWeight, float& MeshSpaceWeight); // Function AnimationLayeringRuntime.BoneMaskFunctionLibrary.BP_BoneMask_GetBodyPartWeights // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x88bc014
};

