// Class BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow
// Size: 0x140 (Inherited: 0x28)
struct UBattleRoyaleFrontendExperienceFlow : UObject {
	char pad_28[0x20]; // 0x28(0x20)
	struct TArray<struct FString> DefaultFlowStepArray; // 0x48(0x10)
	struct TArray<struct FString> FirstTimeSeasonFlowStepArray; // 0x58(0x10)
	struct TMap<struct FString, struct FString> BRVideoRating; // 0x68(0x50)
	char pad_B8[0x18]; // 0xb8(0x18)
	struct TSoftClassPtr<UObject> VideoPlayerClass; // 0xd0(0x20)
	char pad_F0[0x8]; // 0xf0(0x08)
	struct UHabaneroIntroModal* HabaneroIntroModalClass; // 0xf8(0x08)
	struct TSoftClassPtr<UObject> FireModeSelectionReminderModalClass; // 0x100(0x20)
	struct TSoftClassPtr<UObject> FireModeSelectionScreenClass; // 0x120(0x20)

	void HandleVideoTerminalError(enum class EBaseMediaTerminalErrorReason Reason); // Function BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow.HandleVideoTerminalError // (Final|Native|Private) // @ game+0xc7313a0
	void HandleSeasonTrailerEnded(); // Function BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow.HandleSeasonTrailerEnded // (Final|Native|Private) // @ game+0xc73138c
	void FinishTrailerStep(); // Function BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow.FinishTrailerStep // (Final|Native|Private) // @ game+0xc731378
};

