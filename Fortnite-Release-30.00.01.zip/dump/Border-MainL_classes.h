// BlueprintGeneratedClass Border-MainL.Border-MainL_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-MainL_C : UCommonBorderStyle {
};

