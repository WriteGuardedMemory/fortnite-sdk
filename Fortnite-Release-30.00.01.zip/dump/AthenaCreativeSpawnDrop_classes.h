// BlueprintGeneratedClass AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C
// Size: 0xba9 (Inherited: 0xb18)
struct AAthenaCreativeSpawnDrop_C : AFortAthenaCreativeSupplyDrop {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xb18(0x08)
	struct UAudioComponent* treasure_pinata_loop_Cue; // 0xb20(0x08)
	struct UStaticMeshComponent* LlamaStaticMesh; // 0xb28(0x08)
	struct UBoxComponent* BoxCollision; // 0xb30(0x08)
	struct UProjectileMovementComponent* ProjectileMovement; // 0xb38(0x08)
	struct FName LootTableName; // 0xb40(0x04)
	char pad_B44[0x4]; // 0xb44(0x04)
	struct FVector LootSpawnOffset; // 0xb48(0x18)
	struct UParticleSystem* LlamaLootFX; // 0xb60(0x08)
	struct FName FXSocketName; // 0xb68(0x04)
	char pad_B6C[0x4]; // 0xb6c(0x04)
	struct USoundBase* Sound_Looted; // 0xb70(0x08)
	struct USoundBase* Sound_Destroyed; // 0xb78(0x08)
	struct USoundBase* Sound_Ambient; // 0xb80(0x08)
	bool Looted; // 0xb88(0x01)
	char pad_B89[0x7]; // 0xb89(0x07)
	struct AFortPlayerController* ControllerWhoOpenedLlama; // 0xb90(0x08)
	struct FName ObjBackendName; // 0xb98(0x04)
	char pad_B9C[0x4]; // 0xb9c(0x04)
	struct UFortQuestItemDefinition* QuestItem; // 0xba0(0x08)
	bool CreativeMode; // 0xba8(0x01)

	void OnSetCustomDepthStencilValue(struct TArray<struct UPrimitiveComponent*>& PrimComponents, bool bUseCustomDepth, int32_t StencilValue, bool& bOutConsume); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.OnSetCustomDepthStencilValue // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void PlayLootedFX(); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.PlayLootedFX // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnRep_Looted(); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.OnRep_Looted // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void Setup Bind To Building Actor(struct UObject* Object); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.Setup Bind To Building Actor // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x18e3f1c
	void SpawnAllLoot(); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.SpawnAllLoot // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void OnLandingLocationChanged(struct AActor* DamagedActor, float Damage, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FVector HitLocation, struct UPrimitiveComponent* FHitComponent, struct FName BoneName, struct FVector Momentum); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.OnLandingLocationChanged // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void Multicast_ApplyGravityForFall(); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.Multicast_ApplyGravityForFall // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature(struct FHitResult& ImpactResult); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void PlaylistLoaded(struct FName PlaylistName, struct FGameplayTagContainer& PlaylistContextTags); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.PlaylistLoaded // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_AthenaCreativeSpawnDrop(int32_t EntryPoint); // Function AthenaCreativeSpawnDrop.AthenaCreativeSpawnDrop_C.ExecuteUbergraph_AthenaCreativeSpawnDrop // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

