// WidgetBlueprintGeneratedClass AthenaVariantNumericalCustomizationSelector.AthenaVariantNumericalCustomizationSelector_C
// Size: 0x400 (Inherited: 0x400)
struct UAthenaVariantNumericalCustomizationSelector_C : UFortVariantNumericalPicker {
};

