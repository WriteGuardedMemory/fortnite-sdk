// UserDefinedStruct CharacterPartMidArrayStruct.CharacterPartMidArrayStruct
// Size: 0x18 (Inherited: 0x00)
struct FCharacterPartMidArrayStruct {
	enum class EFortCustomPartType PartType_5_EBDFFF5740627902CC51DD966B8EE419; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct UMaterialInstanceDynamic*> MID_7_A0D19AC74319389A5DF2019166F976F0; // 0x08(0x10)
};

