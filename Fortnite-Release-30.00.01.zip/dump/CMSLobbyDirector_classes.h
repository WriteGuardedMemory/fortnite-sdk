// BlueprintGeneratedClass CMSLobbyDirector.CMSLobbyDirector_C
// Size: 0x488 (Inherited: 0x480)
struct ACMSLobbyDirector_C : ADynamicBackgroundDirector {
	struct USceneComponent* DefaultSceneRoot; // 0x480(0x08)
};

