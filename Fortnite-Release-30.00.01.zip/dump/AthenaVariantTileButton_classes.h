// WidgetBlueprintGeneratedClass AthenaVariantTileButton.AthenaVariantTileButton_C
// Size: 0x15b0 (Inherited: 0x1580)
struct UAthenaVariantTileButton_C : UFortVariantTileButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1580(0x08)
	struct UWidgetAnimation* Test; // 0x1588(0x08)
	struct UWBP_UIKit_Block_Outline_C* Block_Outline; // 0x1590(0x08)
	struct UImage* ImageBackground; // 0x1598(0x08)
	struct FMulticastInlineDelegate OnConflictStatusUpdated; // 0x15a0(0x10)

	void BP_OnClicked(); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.BP_OnClicked // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void Construct(); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnListItemObjectSet(struct UObject* ListItemObject); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.OnListItemObjectSet // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void UpdateConflictStatus(bool bIsConflicting, struct FText& ConflictReason); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.UpdateConflictStatus // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnHovered(); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void BP_OnUnhovered(); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_AthenaVariantTileButton(int32_t EntryPoint); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.ExecuteUbergraph_AthenaVariantTileButton // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
	void OnConflictStatusUpdated__DelegateSignature(bool IsConflicting, struct FText ConflictReason); // Function AthenaVariantTileButton.AthenaVariantTileButton_C.OnConflictStatusUpdated__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
};

