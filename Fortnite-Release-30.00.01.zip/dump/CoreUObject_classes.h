// Class CoreUObject.Object
// Size: 0x28 (Inherited: 0x00)
struct UObject {
	char pad_0[0x28]; // 0x00(0x28)

	void ExecuteUbergraph(int32_t EntryPoint); // Function CoreUObject.Object.ExecuteUbergraph // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
};

// Class CoreUObject.OptionalPropertyTestObject
// Size: 0x60 (Inherited: 0x28)
struct UOptionalPropertyTestObject : UObject {
	OptionalProperty OptionalString; // 0x28(0x18)
	OptionalProperty OptionalText; // 0x40(0x10)
	OptionalProperty OptionalName; // 0x50(0x04)
	OptionalProperty OptionalInt; // 0x54(0x08)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// Class CoreUObject.TestPropertyBag1Int
// Size: 0x30 (Inherited: 0x28)
struct UTestPropertyBag1Int : UObject {
	int32_t TheInt; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// Class CoreUObject.TestPropertyBagABCD
// Size: 0x48 (Inherited: 0x28)
struct UTestPropertyBagABCD : UObject {
	struct FString A; // 0x28(0x10)
	enum class ETestPropertyBagEnum B; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t C; // 0x3c(0x04)
	float D; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class CoreUObject.TestPropertyBagABEF
// Size: 0x48 (Inherited: 0x28)
struct UTestPropertyBagABEF : UObject {
	struct FString A; // 0x28(0x10)
	enum class ETestPropertyBagEnum B; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int32_t E; // 0x3c(0x04)
	float F; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class CoreUObject.TestPropertyBagABCDABEF
// Size: 0x58 (Inherited: 0x28)
struct UTestPropertyBagABCDABEF : UObject {
	struct FString A; // 0x28(0x10)
	struct UTestPropertyBagABCD* ABCD; // 0x38(0x08)
	int32_t E; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct UTestPropertyBagABEF* ABEF; // 0x48(0x08)
	float F; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class CoreUObject.TestPropertyBagArrayOfString
// Size: 0x38 (Inherited: 0x28)
struct UTestPropertyBagArrayOfString : UObject {
	struct TArray<struct FString> Arr; // 0x28(0x10)
};

// Class CoreUObject.TestPropertyBagAllSupportedTypes
// Size: 0xc8 (Inherited: 0x28)
struct UTestPropertyBagAllSupportedTypes : UObject {
	struct TArray<struct UTestPropertyBagAllSupportedTypes*> Arr; // 0x28(0x10)
	struct TMap<struct FString, int32_t> Map; // 0x38(0x50)
	struct FString A; // 0x88(0x10)
	int32_t B; // 0x98(0x04)
	int8_t B8; // 0x9c(0x01)
	char pad_9D[0x1]; // 0x9d(0x01)
	int16_t B16; // 0x9e(0x02)
	int64_t B64; // 0xa0(0x08)
	float C; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	double D; // 0xb0(0x08)
	uint32_t E; // 0xb8(0x04)
	char E8; // 0xbc(0x01)
	char pad_BD[0x1]; // 0xbd(0x01)
	uint16_t E16; // 0xbe(0x02)
	uint64_t E64; // 0xc0(0x08)
};

// Class CoreUObject.Package
// Size: 0x78 (Inherited: 0x28)
struct UPackage : UObject {
	char pad_28[0x50]; // 0x28(0x50)
};

// Class CoreUObject.Field
// Size: 0x30 (Inherited: 0x28)
struct UField : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class CoreUObject.Struct
// Size: 0xb0 (Inherited: 0x30)
struct UStruct : UField {
	char pad_30[0x80]; // 0x30(0x80)
};

// Class CoreUObject.Class
// Size: 0x200 (Inherited: 0xb0)
struct UClass : UStruct {
	char pad_B0[0x150]; // 0xb0(0x150)
};

// Class CoreUObject.VerseVMClass
// Size: 0x200 (Inherited: 0x200)
struct UVerseVMClass : UClass {
};

// Class CoreUObject.Interface
// Size: 0x28 (Inherited: 0x28)
struct UInterface : UObject {
};

// Class CoreUObject.EditorPathObjectInterface
// Size: 0x28 (Inherited: 0x28)
struct UEditorPathObjectInterface : UInterface {
};

// Class CoreUObject.GCObjectReferencer
// Size: 0x38 (Inherited: 0x28)
struct UGCObjectReferencer : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class CoreUObject.TextBuffer
// Size: 0x50 (Inherited: 0x28)
struct UTextBuffer : UObject {
	char pad_28[0x28]; // 0x28(0x28)
};

// Class CoreUObject.ScriptStruct
// Size: 0xc0 (Inherited: 0xb0)
struct UScriptStruct : UStruct {
	char pad_B0[0x10]; // 0xb0(0x10)
};

// Class CoreUObject.Function
// Size: 0xe0 (Inherited: 0xb0)
struct UFunction : UStruct {
	char pad_B0[0x30]; // 0xb0(0x30)
};

// Class CoreUObject.DelegateFunction
// Size: 0xe0 (Inherited: 0xe0)
struct UDelegateFunction : UFunction {
};

// Class CoreUObject.SparseDelegateFunction
// Size: 0xe8 (Inherited: 0xe0)
struct USparseDelegateFunction : UDelegateFunction {
	char pad_E0[0x8]; // 0xe0(0x08)
};

// Class CoreUObject.Enum
// Size: 0x68 (Inherited: 0x30)
struct UEnum : UField {
	char pad_30[0x38]; // 0x30(0x38)
};

// Class CoreUObject.EnumCookedMetaData
// Size: 0x78 (Inherited: 0x28)
struct UEnumCookedMetaData : UObject {
	struct FObjectCookedMetaDataStore EnumMetaData; // 0x28(0x50)
};

// Class CoreUObject.StructCookedMetaData
// Size: 0xc8 (Inherited: 0x28)
struct UStructCookedMetaData : UObject {
	struct FStructCookedMetaDataStore StructMetaData; // 0x28(0xa0)
};

// Class CoreUObject.ClassCookedMetaData
// Size: 0x118 (Inherited: 0x28)
struct UClassCookedMetaData : UObject {
	struct FStructCookedMetaDataStore ClassMetaData; // 0x28(0xa0)
	struct TMap<struct FName, struct FStructCookedMetaDataStore> FunctionsMetaData; // 0xc8(0x50)
};

// Class CoreUObject.PackageMap
// Size: 0xe0 (Inherited: 0x28)
struct UPackageMap : UObject {
	char pad_28[0xb8]; // 0x28(0xb8)
};

// Class CoreUObject.ObjectReachabilityStressData
// Size: 0x38 (Inherited: 0x28)
struct UObjectReachabilityStressData : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class CoreUObject.InstanceDataObjectStruct
// Size: 0xd0 (Inherited: 0xc0)
struct UInstanceDataObjectStruct : UScriptStruct {
	char pad_C0[0x10]; // 0xc0(0x10)
};

// Class CoreUObject.LinkerPlaceholderClass
// Size: 0x3c0 (Inherited: 0x200)
struct ULinkerPlaceholderClass : UClass {
	char pad_200[0x1c0]; // 0x200(0x1c0)
};

// Class CoreUObject.LinkerPlaceholderExportObject
// Size: 0xf8 (Inherited: 0x28)
struct ULinkerPlaceholderExportObject : UObject {
	char pad_28[0xd0]; // 0x28(0xd0)
};

// Class CoreUObject.LinkerPlaceholderFunction
// Size: 0x2a0 (Inherited: 0xe0)
struct ULinkerPlaceholderFunction : UFunction {
	char pad_E0[0x1c0]; // 0xe0(0x1c0)
};

// Class CoreUObject.MetaData
// Size: 0xc8 (Inherited: 0x28)
struct UMetaData : UObject {
	char pad_28[0xa0]; // 0x28(0xa0)
};

// Class CoreUObject.ObjectRedirector
// Size: 0x30 (Inherited: 0x28)
struct UObjectRedirector : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class CoreUObject.Property
// Size: 0x70 (Inherited: 0x30)
struct UProperty : UField {
	char pad_30[0x40]; // 0x30(0x40)
};

// Class CoreUObject.EnumProperty
// Size: 0x80 (Inherited: 0x70)
struct UEnumProperty : UProperty {
	char pad_70[0x10]; // 0x70(0x10)
};

// Class CoreUObject.ArrayProperty
// Size: 0x78 (Inherited: 0x70)
struct UArrayProperty : UProperty {
	char pad_70[0x8]; // 0x70(0x08)
};

// Class CoreUObject.ObjectPropertyBase
// Size: 0x78 (Inherited: 0x70)
struct UObjectPropertyBase : UProperty {
	char pad_70[0x8]; // 0x70(0x08)
};

// Class CoreUObject.BoolProperty
// Size: 0x78 (Inherited: 0x70)
struct UBoolProperty : UProperty {
	char pad_70[0x8]; // 0x70(0x08)
};

// Class CoreUObject.NumericProperty
// Size: 0x70 (Inherited: 0x70)
struct UNumericProperty : UProperty {
};

// Class CoreUObject.ByteProperty
// Size: 0x78 (Inherited: 0x70)
struct UByteProperty : UNumericProperty {
	char pad_70[0x8]; // 0x70(0x08)
};

// Class CoreUObject.ObjectProperty
// Size: 0x78 (Inherited: 0x78)
struct UObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.ClassProperty
// Size: 0x80 (Inherited: 0x78)
struct UClassProperty : UObjectProperty {
	char pad_78[0x8]; // 0x78(0x08)
};

// Class CoreUObject.DelegateProperty
// Size: 0x78 (Inherited: 0x70)
struct UDelegateProperty : UProperty {
	char pad_70[0x8]; // 0x70(0x08)
};

// Class CoreUObject.DoubleProperty
// Size: 0x70 (Inherited: 0x70)
struct UDoubleProperty : UNumericProperty {
};

// Class CoreUObject.FloatProperty
// Size: 0x70 (Inherited: 0x70)
struct UFloatProperty : UNumericProperty {
};

// Class CoreUObject.IntProperty
// Size: 0x70 (Inherited: 0x70)
struct UIntProperty : UNumericProperty {
};

// Class CoreUObject.Int8Property
// Size: 0x70 (Inherited: 0x70)
struct UInt8Property : UNumericProperty {
};

// Class CoreUObject.Int16Property
// Size: 0x70 (Inherited: 0x70)
struct UInt16Property : UNumericProperty {
};

// Class CoreUObject.Int64Property
// Size: 0x70 (Inherited: 0x70)
struct UInt64Property : UNumericProperty {
};

// Class CoreUObject.InterfaceProperty
// Size: 0x78 (Inherited: 0x70)
struct UInterfaceProperty : UProperty {
	char pad_70[0x8]; // 0x70(0x08)
};

// Class CoreUObject.LazyObjectProperty
// Size: 0x78 (Inherited: 0x78)
struct ULazyObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.MapProperty
// Size: 0x98 (Inherited: 0x70)
struct UMapProperty : UProperty {
	char pad_70[0x28]; // 0x70(0x28)
};

// Class CoreUObject.MulticastDelegateProperty
// Size: 0x78 (Inherited: 0x70)
struct UMulticastDelegateProperty : UProperty {
	char pad_70[0x8]; // 0x70(0x08)
};

// Class CoreUObject.MulticastInlineDelegateProperty
// Size: 0x78 (Inherited: 0x78)
struct UMulticastInlineDelegateProperty : UMulticastDelegateProperty {
};

// Class CoreUObject.MulticastSparseDelegateProperty
// Size: 0x78 (Inherited: 0x78)
struct UMulticastSparseDelegateProperty : UMulticastDelegateProperty {
};

// Class CoreUObject.NameProperty
// Size: 0x70 (Inherited: 0x70)
struct UNameProperty : UProperty {
};

// Class CoreUObject.SetProperty
// Size: 0x90 (Inherited: 0x70)
struct USetProperty : UProperty {
	char pad_70[0x20]; // 0x70(0x20)
};

// Class CoreUObject.SoftObjectProperty
// Size: 0x78 (Inherited: 0x78)
struct USoftObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.SoftClassProperty
// Size: 0x80 (Inherited: 0x78)
struct USoftClassProperty : USoftObjectProperty {
	char pad_78[0x8]; // 0x78(0x08)
};

// Class CoreUObject.StrProperty
// Size: 0x70 (Inherited: 0x70)
struct UStrProperty : UProperty {
};

// Class CoreUObject.StructProperty
// Size: 0x78 (Inherited: 0x70)
struct UStructProperty : UProperty {
	char pad_70[0x8]; // 0x70(0x08)
};

// Class CoreUObject.UInt16Property
// Size: 0x70 (Inherited: 0x70)
struct UUInt16Property : UNumericProperty {
};

// Class CoreUObject.UInt32Property
// Size: 0x70 (Inherited: 0x70)
struct UUInt32Property : UNumericProperty {
};

// Class CoreUObject.UInt64Property
// Size: 0x70 (Inherited: 0x70)
struct UUInt64Property : UNumericProperty {
};

// Class CoreUObject.WeakObjectProperty
// Size: 0x78 (Inherited: 0x78)
struct UWeakObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.TextProperty
// Size: 0x70 (Inherited: 0x70)
struct UTextProperty : UProperty {
};

// Class CoreUObject.PropertyWrapper
// Size: 0x30 (Inherited: 0x28)
struct UPropertyWrapper : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class CoreUObject.MulticastDelegatePropertyWrapper
// Size: 0x30 (Inherited: 0x30)
struct UMulticastDelegatePropertyWrapper : UPropertyWrapper {
};

// Class CoreUObject.MulticastInlineDelegatePropertyWrapper
// Size: 0x30 (Inherited: 0x30)
struct UMulticastInlineDelegatePropertyWrapper : UMulticastDelegatePropertyWrapper {
};

