// BlueprintGeneratedClass B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C
// Size: 0xc3e (Inherited: 0xab8)
struct AB_Prj_Athena_Grenade_Base_C : AFortProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xab8(0x08)
	struct UNiagaraComponent* NS_Fuse_Particle; // 0xac0(0x08)
	struct UFortCollisionAudioComponent* FortCollisionAudio; // 0xac8(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0xad0(0x08)
	struct UStaticMeshComponent* Mesh; // 0xad8(0x08)
	struct UAudioComponent* GrenadeFuse_AudioComponent; // 0xae0(0x08)
	struct UParticleSystemComponent* Effect_Distance; // 0xae8(0x08)
	struct TSoftObjectPtr<UParticleSystem> P_Explosion; // 0xaf0(0x20)
	struct USoundBase* Cue_ExplosionSound; // 0xb10(0x08)
	struct TSoftObjectPtr<UParticleSystem> P_Explosion_Water; // 0xb18(0x20)
	int32_t NumberOfBouncesTillExplode; // 0xb38(0x04)
	int32_t CurrentNumberOfBounces; // 0xb3c(0x04)
	struct USoundBase* Cue_GrenadeFuseSound; // 0xb40(0x08)
	double BouncePawnAgainstPawnGravityScale; // 0xb48(0x08)
	struct UForceFeedbackEffect* ExplosionForceFeedbackNear; // 0xb50(0x08)
	struct UForceFeedbackEffect* ExplosionForceFeedbackFar; // 0xb58(0x08)
	struct USoundBase* Cue_Bounce; // 0xb60(0x08)
	struct ULegacyCameraShake* ExplosionCameraShake; // 0xb68(0x08)
	double FuseTime; // 0xb70(0x08)
	double ExplosionRadius; // 0xb78(0x08)
	struct FRotator Explosion Rotation; // 0xb80(0x18)
	struct UAudioComponent* WaterFuseAudioComponent; // 0xb98(0x08)
	struct USoundBase* Water Debris Explosion; // 0xba0(0x08)
	struct USoundBase* Splash Sound; // 0xba8(0x08)
	struct UTexture* SoundIndicatorIcon; // 0xbb0(0x08)
	struct FTimerHandle FuseIndicatorTimer; // 0xbb8(0x08)
	struct TSoftObjectPtr<UNiagaraSystem> NS_Explosion; // 0xbc0(0x20)
	struct TSoftObjectPtr<UNiagaraSystem> NS_Explosion_Water; // 0xbe0(0x20)
	enum class EFXType FXType; // 0xc00(0x01)
	char pad_C01[0x7]; // 0xc01(0x07)
	struct UFXSystemAsset* VFX_Explosion; // 0xc08(0x08)
	struct UFXSystemAsset* VFX_Explosion_Water; // 0xc10(0x08)
	struct FTimerHandle FuseTimer_; // 0xc18(0x08)
	struct UNiagaraSystem* NS_HitWater; // 0xc20(0x08)
	struct USoundBase* WaterFuseSound; // 0xc28(0x08)
	struct UFXSystemAsset* FX_Physical Surface; // 0xc30(0x08)
	int32_t PhysicalSurfaceID; // 0xc38(0x04)
	bool bShowFuseSoundIndicator; // 0xc3c(0x01)
	enum class EPhysicalSurface E_Surface_Type; // 0xc3d(0x01)

	void PhysicalSurfaceCheck(int32_t Physical Surface ID, bool& CheckedPhysicalSurfaceID); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.PhysicalSurfaceCheck // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void GetExplosion(bool InWater, struct UFXSystemAsset*& FX System); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.GetExplosion // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x18e3f1c
	void FuseEnded(); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.FuseEnded // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void UserConstructionScript(); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnLoaded_6A6D02914DCE95902837C994D84D08EA(struct UObject* Loaded); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.OnLoaded_6A6D02914DCE95902837C994D84D08EA // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnLoaded_6A6D02914DCE95902837C994C3BE7DC5(struct UObject* Loaded); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.OnLoaded_6A6D02914DCE95902837C994C3BE7DC5 // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveBeginPlay(); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x18e3f1c
	void OnStop(struct FHitResult& Hit); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void Stop_Rotation(); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.Stop_Rotation // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void OnExploded(struct TArray<struct AActor*>& HitActors, struct TArray<struct FHitResult>& HitResults); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void OnBounce(struct FHitResult& Hit); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.OnBounce // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.ReceiveAnyDamage // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void OnResumeSimulation(); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.OnResumeSimulation // (Event|Public|BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x18e3f1c
	void Splash(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.Splash // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_2_WaterInteractionOnEnterWater__DelegateSignature(struct AFortWaterBodyActor* WaterBody, struct UFortWaterInteractionComponent* WaterInteractionComponent, bool bIsFirstBody); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.BndEvt__WaterInteractionComponent_K2Node_ComponentBoundEvent_2_WaterInteractionOnEnterWater__DelegateSignature // (BlueprintEvent) // @ game+0x18e3f1c
	void Held Water Impact(); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.Held Water Impact // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ShowFuseIndicator(); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.ShowFuseIndicator // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void AysncLoad(); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.AysncLoad // (BlueprintCallable|BlueprintEvent) // @ game+0x18e3f1c
	void ExecuteUbergraph_B_Prj_Athena_Grenade_Base(int32_t EntryPoint); // Function B_Prj_Athena_Grenade_Base.B_Prj_Athena_Grenade_Base_C.ExecuteUbergraph_B_Prj_Athena_Grenade_Base // (Final|UbergraphFunction|HasDefaults) // @ game+0x18e3f1c
};

