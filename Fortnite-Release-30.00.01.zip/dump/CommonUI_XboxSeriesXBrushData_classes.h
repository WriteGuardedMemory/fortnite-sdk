// BlueprintGeneratedClass CommonUI_XboxSeriesXBrushData.CommonUI_XboxSeriesXBrushData_C
// Size: 0xd0 (Inherited: 0xd0)
struct UCommonUI_XboxSeriesXBrushData_C : UFortInputControllerData {
};

