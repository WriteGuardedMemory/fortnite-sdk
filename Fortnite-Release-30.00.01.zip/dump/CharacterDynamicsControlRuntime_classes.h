// Class CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCharacterDynamicsControlBPLibrary : UBlueprintFunctionLibrary {

	struct FRigidBodyWithControlReference UpdateRigidBodyWithControlNodeParametersFromAsset(struct FAnimUpdateContext& UpdateContext, struct FRigidBodyWithControlReference& RigidBodyWithControl, struct UFortCharacterDynamicsParameters* Parameters); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.UpdateRigidBodyWithControlNodeParametersFromAsset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xc7f1b58
	struct FRigidBodyWithControlReference UpdateRigidBodyWithControlNodeParametersForLayer(struct FAnimUpdateContext& UpdateContext, struct FRigidBodyWithControlReference& RigidBodyWithControl, struct FName StateLogicLayerName, struct UFortCharacterDynamicsParameters* Parameters); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.UpdateRigidBodyWithControlNodeParametersForLayer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xc7f18ac
	struct FRigidBodyWithControlReference UpdateRigidBodyWithControlNodeParameters(struct FAnimUpdateContext& UpdateContext, struct FRigidBodyWithControlReference& RigidBodyWithControl); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.UpdateRigidBodyWithControlNodeParameters // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xc7f1734
	void SetProperty(struct UFortAnimInstance* InAnimInstance, struct FName InPropertyName, bool InValue); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.SetProperty // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xc7f143c
	void RequestFullBodyPBALayer(struct UFortAnimInstance* InAnimInstance, struct FName ReasonForRequest); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.RequestFullBodyPBALayer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xc7f1304
	void RemoveCharacterDynamicsControlLogicLayer(struct UFortAnimInstance* InAnimInstance, struct FName LayerName); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.RemoveCharacterDynamicsControlLogicLayer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xc7f10f4
	bool HasCharacterDynamicsControlLogicLayer(struct UFortAnimInstance* InAnimInstance, struct FName LayerName); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.HasCharacterDynamicsControlLogicLayer // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xc7f0ddc
	bool GetPropertyForLayer(struct UFortAnimInstance* InAnimInstance, struct FName InStateLogicLayerName, struct FName InPropertyName); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.GetPropertyForLayer // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xc7f09cc
	bool GetProperty(struct UFortAnimInstance* InAnimInstance, struct FName InPropertyName); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.GetProperty // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xc7f07ac
	struct FName GetCharacterStateForLayer(struct UFortAnimInstance* InAnimInstance, struct FName StateLogicLayerName); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.GetCharacterStateForLayer // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xc7f0654
	struct FName GetCharacterState(struct UFortAnimInstance* InAnimInstance); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.GetCharacterState // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xc7f058c
	void AddCharacterDynamicsControlLogicLayer(struct UFortAnimInstance* InAnimInstance, struct FName LayerName, struct UFortCharacterDynamicsStateLogic* LayerStateLogic); // Function CharacterDynamicsControlRuntime.CharacterDynamicsControlBPLibrary.AddCharacterDynamicsControlLogicLayer // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xc7f0194
};

// Class CharacterDynamicsControlRuntime.CharacterDynamicsControlGameFeatureData
// Size: 0x550 (Inherited: 0x540)
struct UCharacterDynamicsControlGameFeatureData : UFortGameFeatureData {
	struct UFortCharacterDynamicsStateLogic* DefaultStateLogic; // 0x540(0x08)
	struct UFortCharacterDynamicsParameters* DefaultParameters; // 0x548(0x08)
};

// Class CharacterDynamicsControlRuntime.FortCharacterDynamicsParameters
// Size: 0xa0 (Inherited: 0x30)
struct UFortCharacterDynamicsParameters : UPrimaryDataAsset {
	struct TArray<struct FName> StateNames; // 0x30(0x10)
	struct TArray<struct FClothParameters> ClothParameters; // 0x40(0x10)
	struct TArray<struct FWindGustParameters> WindGustParameters; // 0x50(0x10)
	struct TArray<struct FPhysicsControlControlAndModifierParameters> RBWCControlAndModifierParameters; // 0x60(0x10)
	struct TArray<struct FFortRigidBodyWithControlStateTransitionParameters> RBWCTransitionParameters; // 0x70(0x10)
	struct TArray<struct FFortGravityOverrideParameters> GravityOverrideParameters; // 0x80(0x10)
	struct TArray<struct FFortRigidBodyAnimNodeParameters> RigidBodyAnimNodeParameters; // 0x90(0x10)
};

// Class CharacterDynamicsControlRuntime.FortCharacterDynamicsStateLogic
// Size: 0x78 (Inherited: 0x30)
struct UFortCharacterDynamicsStateLogic : UPrimaryDataAsset {
	struct TArray<struct FName> BlueprintCharacterPropertyNames; // 0x30(0x10)
	struct TArray<struct FName> ActivityStateNames; // 0x40(0x10)
	struct FBinaryDecisionTree ActivityStateBinaryDecisionTree; // 0x50(0x10)
	float MinMovementSpeed; // 0x60(0x04)
	float MinRidingMovementSpeed; // 0x64(0x04)
	float MinUpwardVelocityThreshold; // 0x68(0x04)
	float MaxFallingThreshold; // 0x6c(0x04)
	float HighRevolutionsPerSecondThreshold; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent
// Size: 0x150 (Inherited: 0xa0)
struct UFortCharacterDynamicsComponent : UActorComponent {
	struct UFortCharacterDynamicsStateLogic* DefaultStateLogic; // 0xa0(0x08)
	struct UFortCharacterDynamicsParameters* DefaultParameters; // 0xa8(0x08)
	char pad_B0[0xa0]; // 0xb0(0xa0)

	void SetProperty(struct FName PropertyName, bool PropertyValue); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.SetProperty // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f15f4
	void RemoveLayer(struct FName LayerName); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.RemoveLayer // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f1240
	struct FName PreviousStateNameForLayer(struct FName LayerName); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.PreviousStateNameForLayer // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f102c
	struct FName PreviousStateName(); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.PreviousStateName // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f0ffc
	bool HasLayer(struct FName LayerName); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.HasLayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc7f0f30
	float GetTimeInCurrentStateSecondsForLayer(struct FName LayerName); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.GetTimeInCurrentStateSecondsForLayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc7f0d0c
	float GetTimeInCurrentStateSeconds(); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.GetTimeInCurrentStateSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xc7f0ce4
	bool GetPropertyForLayer(struct FName LayerName, struct FName PropertyName); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.GetPropertyForLayer // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f0b98
	bool GetProperty(struct FName PropertyName); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.GetProperty // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f0900
	struct FName CurrentStateNameForLayer(struct FName LayerName); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.CurrentStateNameForLayer // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f04c4
	struct FName CurrentStateName(); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.CurrentStateName // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f0498
	void AddLayer(struct FName LayerName, struct UFortCharacterDynamicsStateLogic* LayerStateLogic); // Function CharacterDynamicsControlRuntime.FortCharacterDynamicsComponent.AddLayer // (Final|Native|Public|BlueprintCallable) // @ game+0xc7f035c
};

