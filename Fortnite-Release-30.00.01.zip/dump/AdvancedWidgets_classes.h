// Class AdvancedWidgets.RadialSlider
// Size: 0x780 (Inherited: 0x160)
struct URadialSlider : UWidget {
	float Value; // 0x160(0x04)
	struct FDelegate ValueDelegate; // 0x164(0x0c)
	bool bUseCustomDefaultValue; // 0x170(0x01)
	char pad_171[0x3]; // 0x171(0x03)
	float CustomDefaultValue; // 0x174(0x04)
	struct FRuntimeFloatCurve SliderRange; // 0x178(0x88)
	struct TArray<float> ValueTags; // 0x200(0x10)
	float SliderHandleStartAngle; // 0x210(0x04)
	float SliderHandleEndAngle; // 0x214(0x04)
	float AngularOffset; // 0x218(0x04)
	char pad_21C[0x4]; // 0x21c(0x04)
	struct FVector2D HandStartEndRatio; // 0x220(0x10)
	struct FSliderStyle WidgetStyle; // 0x230(0x4a0)
	struct FLinearColor SliderBarColor; // 0x6d0(0x10)
	struct FLinearColor SliderProgressColor; // 0x6e0(0x10)
	struct FLinearColor SliderHandleColor; // 0x6f0(0x10)
	struct FLinearColor CenterBackgroundColor; // 0x700(0x10)
	bool Locked; // 0x710(0x01)
	bool MouseUsesStep; // 0x711(0x01)
	bool RequiresControllerLock; // 0x712(0x01)
	char pad_713[0x1]; // 0x713(0x01)
	float StepSize; // 0x714(0x04)
	bool IsFocusable; // 0x718(0x01)
	bool UseVerticalDrag; // 0x719(0x01)
	bool ShowSliderHandle; // 0x71a(0x01)
	bool ShowSliderHand; // 0x71b(0x01)
	char pad_71C[0x4]; // 0x71c(0x04)
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // 0x720(0x10)
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // 0x730(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // 0x740(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // 0x750(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x760(0x10)
	char pad_770[0x10]; // 0x770(0x10)

	void SetValueTags(struct TArray<float>& InValueTags); // Function AdvancedWidgets.RadialSlider.SetValueTags // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x852cc74
	void SetValue(float InValue); // Function AdvancedWidgets.RadialSlider.SetValue // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852cbb0
	void SetUseVerticalDrag(bool InUseVerticalDrag); // Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852cae4
	void SetStepSize(float InValue); // Function AdvancedWidgets.RadialSlider.SetStepSize // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852ca20
	void SetSliderRange(struct FRuntimeFloatCurve& InSliderRange); // Function AdvancedWidgets.RadialSlider.SetSliderRange // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x852c934
	void SetSliderProgressColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderProgressColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x852c854
	void SetSliderHandleStartAngle(float InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852c780
	void SetSliderHandleEndAngle(float InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852c6ac
	void SetSliderHandleColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x852c5cc
	void SetSliderBarColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderBarColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x852c4ec
	void SetShowSliderHandle(bool InShowSliderHandle); // Function AdvancedWidgets.RadialSlider.SetShowSliderHandle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852c420
	void SetShowSliderHand(bool InShowSliderHand); // Function AdvancedWidgets.RadialSlider.SetShowSliderHand // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852c354
	void SetLocked(bool InValue); // Function AdvancedWidgets.RadialSlider.SetLocked // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852c254
	void SetHandStartEndRatio(struct FVector2D InValue); // Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x852c14c
	void SetCustomDefaultValue(float InValue); // Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852c088
	void SetCenterBackgroundColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x852bfa8
	void SetAngularOffset(float InValue); // Function AdvancedWidgets.RadialSlider.SetAngularOffset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x852bedc
	float GetValue(); // Function AdvancedWidgets.RadialSlider.GetValue // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x852beb4
	float GetNormalizedSliderHandlePosition(); // Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x852be7c
	float GetCustomDefaultValue(); // Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x852be54
};

